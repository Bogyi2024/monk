from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path

from dotenv import load_dotenv

from services.story_carousel_service import StoryCarouselService
from services.story_image_sheet_service import StoryImageSheetService
from story_motion_production_test import ProductionTest, read_json


ROOT=Path(__file__).resolve().parent
for stream in (sys.stdout,sys.stderr):
    try: stream.reconfigure(encoding='utf-8',errors='replace')
    except Exception: pass


async def main() -> None:
    load_dotenv(ROOT/'.env')
    stamp=time.strftime('%Y%m%d_%H%M%S')
    out=ROOT/'outputs'/f'{stamp}_sheet_prompt_v2_qa'
    out.mkdir(parents=True,exist_ok=True)

    drama_root=ROOT/'outputs'/'story_carousel'/'20260824_193106_drama'
    drama=read_json(drama_root/'story.json',{})
    carousel=StoryCarouselService('config/story_carousel.json')
    prompt=StoryImageSheetService.build_prompt(
        scene_prompts=[x.get('visual_prompt','') for x in drama['slides'][:4]],
        character_bible=str(drama.get('character_bible') or ''),
        global_style=(
            'Consistent realistic Burmese emotional drama, natural anatomy and wardrobe, '
            'cinematic believable night lighting. Exact assigned action and object details.'
        ),
    )
    drama_sheet=out/'drama_sheet.jpg'
    await carousel._generate_fal_sheet_image(
        prompt=prompt,save_path=drama_sheet,width=1152,height=2048,
    )
    StoryImageSheetService.crop_sheet(
        sheet_path=drama_sheet,
        output_paths=[out/f'drama_{i:02d}.jpg' for i in range(1,5)],
        output_size=(720,1280),overwrite=True,
    )

    story_root=ROOT/'outputs'/'story_motion'/'20260824_130010_thriller'
    story=read_json(story_root/'story_plan.json',{})
    engine=ProductionTest()
    prompt=StoryImageSheetService.build_prompt(
        scene_prompts=[x.get('visual_prompt','') for x in story['scenes'][:4]],
        character_bible=str(story.get('character_bible') or ''),
        global_style=(
            'Polished dark 2D psychological-thriller comic frames; clean ink outlines, '
            'cel shading, cold blue-green and charcoal, moody lighting. Never photo or 3D.'
        ),
    )
    story_sheet=out/'story_sheet.jpg'
    await engine._generate_locked_fal_with_policy_rewrite(
        prompt,story_sheet,width=1152,height=2048,
    )
    StoryImageSheetService.crop_sheet(
        sheet_path=story_sheet,
        output_paths=[out/f'story_{i:02d}.jpg' for i in range(1,5)],
        output_size=(720,1280),overwrite=True,
    )
    print('PROMPT_V2_QA='+str(out))


if __name__=='__main__':
    asyncio.run(main())
