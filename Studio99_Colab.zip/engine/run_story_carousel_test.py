from __future__ import annotations

import asyncio
import json
import os
import re

from dotenv import load_dotenv

from services.story_carousel_service import StoryCarouselService

load_dotenv()


def _discover_api_aliases() -> list[str]:
    found: list[tuple[int, str]] = []
    pat = re.compile(r"^GEMINI_IMAGE_PROJECT_(\d+)_KEY$", re.I)
    for name, value in os.environ.items():
        m = pat.match(str(name))
        if m and str(value or "").strip():
            n = int(m.group(1))
            found.append((n, f"project_{n}"))
    found.sort(key=lambda x: x[0])
    aliases = [alias for _, alias in found]
    if str(os.getenv("GEMINI_IMAGE_PAID_KEY") or "").strip():
        aliases.append("paid")
    return aliases


async def main():
    print("\n📚 STORY CAROUSEL — Dynamic API Pool manual test")
    print("   1 = Drama")
    print("   2 = Ghost / Horror")
    print("   3 = Thriller")
    raw = input("Genre [1/2/3] > ").strip()
    genre = {"1": "drama", "2": "ghost", "3": "thriller"}.get(raw, "drama")

    topic = input(
        "Topic/idea (Enter = Gemini ကို original idea ကိုယ်တိုင်ဖန်တီးခိုင်းမယ်) > "
    ).strip()

    aliases = _discover_api_aliases()
    chain = " → ".join(aliases) if aliases else "NO KEYS FOUND"

    print("\n🖼️ IMAGE PROVIDER / KEY")
    print(f"   1 = AUTO API POOL  [{chain}]  ← recommended")
    print("   2 = Choose one discovered API key only")
    print("   3 = Gemini Web")
    print("   4 = FAL")
    image_choice = input("Image mode [Enter/1-4] > ").strip() or "1"

    svc = StoryCarouselService()

    if image_choice == "3":
        svc.config["image_provider"] = "gemini_web"
    elif image_choice == "4":
        svc.config["image_provider"] = "fal"
    else:
        svc.config["image_provider"] = "gemini_api_pool"
        if image_choice == "2":
            if not aliases:
                raise RuntimeError(
                    "No Gemini image API keys discovered. Add "
                    "GEMINI_IMAGE_PROJECT_<N>_KEY or GEMINI_IMAGE_PAID_KEY to .env"
                )
            print("\n🔑 DISCOVERED API KEYS")
            for i, alias in enumerate(aliases, 1):
                suffix = " [PAID]" if alias == "paid" else ""
                print(f"   {i} = {alias}{suffix}")
            selected_raw = input(f"Key [1-{len(aliases)}] > ").strip()
            try:
                selected = aliases[int(selected_raw) - 1]
            except Exception:
                selected = aliases[0]
            svc.config["gemini_api_key_mode"] = selected
        else:
            svc.config["gemini_api_key_mode"] = "auto"

    print(
        "\n🚀 Story image mode: "
        f"{svc.config.get('image_provider')}"
        + (
            f" / {svc.config.get('gemini_api_key_mode')}"
            if svc.config.get("image_provider") == "gemini_api_pool"
            else ""
        )
    )

    result = await svc.build_story(genre=genre, topic=topic)

    print("\n✅ DONE")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
