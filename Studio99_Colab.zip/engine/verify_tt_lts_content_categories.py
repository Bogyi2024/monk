from __future__ import annotations
import json, py_compile, re, subprocess, sys
from pathlib import Path

ROOT=Path.cwd().resolve(); LTS=(ROOT.parent/'long_to_short').resolve()
REQUIRED_CATS={'motivation','psychology','horror','crime','knowledge','comedy'}
TT_FILES=[ROOT/'services/tt_settings_service.py',ROOT/'services/tt_long_to_short_night_service.py',ROOT/'bridges/long_to_short_bridge.py',ROOT/'tt_web_manager.py']
LTS_FILES=[LTS/'run_long_to_short_test.py',LTS/'tt_bridge_runner.py',LTS/'services/gemini_moment_selector.py',LTS/'services/commentary_service.py',LTS/'services/tt_source_scanner.py']

def fail(msg): print('FAIL:',msg); raise SystemExit(1)

def _verify_lts_modules_in_lts_process():
    # IMPORTANT: recap_personal itself has a regular `services` package while
    # standalone long_to_short/services is intentionally standalone.  Import
    # LTS modules from a subprocess whose cwd is the LTS root so Python cannot
    # accidentally resolve recap_personal/services first.
    code = r'''
from services.tt_source_scanner import TTSourceScanner
if TTSourceScanner._scan_url("https://www.youtube.com/@Example") != "https://www.youtube.com/@Example/videos":
    raise SystemExit("channel URL normalizer did not target long-form /videos")
if TTSourceScanner._scan_url("https://www.youtube.com/watch?v=abcDEF123") != "https://www.youtube.com/watch?v=abcDEF123":
    raise SystemExit("direct video URL should stay direct")
from services.gemini_moment_selector import _profile_guidance
required={"motivation","psychology","horror","crime","knowledge","comedy"}
for key in required:
    if not _profile_guidance(key):
        raise SystemExit(f"empty selector guidance for {key}")
from services.commentary_service import _profile_guidance as cguide
if not cguide("horror") or not cguide("motivation"):
    raise SystemExit("commentary profile guidance missing")
print("LTS_MODULE_CHECK_OK")
'''
    r=subprocess.run([sys.executable,'-c',code],cwd=str(LTS),capture_output=True,text=True)
    if r.returncode!=0:
        fail('standalone LTS module check: '+((r.stderr or r.stdout).strip()))
    if 'LTS_MODULE_CHECK_OK' not in r.stdout:
        fail('standalone LTS module check returned no success marker')

def main():
    for p in TT_FILES+LTS_FILES:
        if not p.exists(): fail(f'missing {p}')
        py_compile.compile(str(p),doraise=True)
    data=json.loads((ROOT/'config/tt_categories.json').read_text(encoding='utf-8'))
    cat=(data.get('categories') or {}).get('long_to_short') or {}
    profiles=cat.get('content_categories') or {}
    missing=REQUIRED_CATS-set(profiles)
    if missing: fail('missing LTS content categories: '+', '.join(sorted(missing)))
    routes=cat.get('routes') or {}
    if not routes: fail('Long-to-Short has no routes')
    for rk,r in routes.items():
        ck=str((r or {}).get('lts_category') or '')
        if not ck: fail(f'route {rk} missing lts_category')
        if ck not in profiles: fail(f'route {rk} points to unknown LTS content category {ck}')

    _verify_lts_modules_in_lts_process()

    # Night-plan semantics: same category+reuse group shares candidates across
    # output variants; categories stay separate.
    import importlib.util
    nspec=importlib.util.spec_from_file_location('tt_lts_night_verify',str(ROOT/'services/tt_long_to_short_night_service.py'))
    nmod=importlib.util.module_from_spec(nspec); nspec.loader.exec_module(nmod)
    class FakeSettings:
        def categories(self):
            return {'categories':{'long_to_short':{'enabled':True,'production_rules':{},'content_categories':{
                'motivation':{'enabled':True,'selector_profile':'motivation','source_urls':['https://www.youtube.com/@mot']},
                'horror':{'enabled':True,'selector_profile':'horror','source_urls':['https://www.youtube.com/@horror']},},'routes':{
                'mvo':{'enabled':True,'daily_limit':5,'output_type':'transformative_envo_mm','lts_category':'motivation','content_group':'main'},
                'morig':{'enabled':True,'daily_limit':5,'output_type':'original_audio_mm','lts_category':'motivation','content_group':'main'},
                'hvo':{'enabled':True,'daily_limit':3,'output_type':'transformative_envo_mm','lts_category':'horror','content_group':'main'},}}}}
        def resolve_route(self,category,route): return {'facebook':{'enabled':True},'tiktok':None}
    plan=nmod.TTLongToShortNightService(FakeSettings(),ROOT).plan()
    if plan.get('motivation::main',{}).get('requirements')!={'transformative_envo_mm':5,'original_audio_mm':5}: fail('Motivation output variants are not sharing one candidate requirement bucket')
    if plan.get('horror::main',{}).get('requirements')!={'transformative_envo_mm':3}: fail('Horror category did not stay separate')

    ui=(ROOT/'tt_web/index.html').read_text(encoding='utf-8')
    for token in ('openLtsHub','openLtsContentCategory','rLtsCategory','/api/lts-content-category'):
        if token not in ui: fail(f'UI missing {token}')
    try:
        js='\n'.join(re.findall(r'<script>([\\s\\S]*?)</script>',ui))
        tmp=ROOT/'state'/'_tt_lts_ui_verify.js'; tmp.parent.mkdir(parents=True,exist_ok=True); tmp.write_text(js,encoding='utf-8')
        r=subprocess.run(['node','--check',str(tmp)],capture_output=True,text=True)
        tmp.unlink(missing_ok=True)
        if r.returncode!=0: fail('UI JS syntax: '+(r.stderr or r.stdout))
    except FileNotFoundError:
        pass
    print('PASS: TT Master V2.0.19 Long-to-Short content-category bridge verified.')
    print(' - standalone Long-to-Short remains sibling project')
    print(' - sources are category-owned, routes are destination/output-owned')
    print(' - Motivation/Psychology/Horror/Crime/Knowledge/Comedy profiles present')
    print(' - no network/API/render job was started by this verifier')

if __name__=='__main__': main()
