from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path

from playwright.async_api import async_playwright
from services.browser_service import BrowserService, _fb_proxy_config
from services.fb_group_service import auto_share_all_accounts, get_share_accounts

CONFIG_PATH = os.getenv("RECAP_CONFIG_PATH", "config/recap_pages.json")


def load_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(path: str, data):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(p)


def normalize_destinations(page):
    raw = page.get("destinations")
    if isinstance(raw, list) and raw:
        out = [dict(x) for x in raw if isinstance(x, dict) and x.get("enabled", True)]
    else:
        out = [dict(page)]
    stream_key = str(page.get("page_key") or "recap")
    for i, d in enumerate(out, 1):
        platform = str(d.get("platform", "fb")).lower()
        if platform in {"facebook", "meta"}:
            platform = "fb"
        d["platform"] = platform
        d.setdefault("destination_key", f"{stream_key}_{platform}_{i}")
    return out


def parse_selection(raw: str, names: list[str]) -> list[str]:
    raw = (raw or "").strip().lower()
    if not raw or raw in {"all", "a", "*"}:
        return list(names)
    if raw in {"0", "none", "n", "skip"}:
        return []
    chosen = []
    for tok in [x.strip() for x in raw.split(",") if x.strip()]:
        if "-" in tok:
            try:
                a, b = map(int, tok.split("-", 1))
                if a > b:
                    a, b = b, a
                for idx in range(a, b + 1):
                    if 1 <= idx <= len(names) and names[idx - 1] not in chosen:
                        chosen.append(names[idx - 1])
                continue
            except Exception:
                pass
        try:
            idx = int(tok)
            if 1 <= idx <= len(names) and names[idx - 1] not in chosen:
                chosen.append(names[idx - 1])
        except Exception:
            pass
    return chosen


def get_latest_fb_target(registry_path: str, destination_key: str):
    data = load_json(registry_path)
    rows = (data.get("posted_by_page") or {}).get(destination_key) or []
    fb_rows = [x for x in rows if str(x.get("platform", "")).lower() == "fb"]
    return data, (fb_rows[-1] if fb_rows else None)


def overwrite_exact_target(registry_path: str, destination_key: str, video_id: str, link: str):
    data = load_json(registry_path)
    updated = False

    rows = (data.get("posted_by_page") or {}).get(destination_key) or []
    for row in rows:
        if str(row.get("platform", "")).lower() == "fb" and str(row.get("video_id") or "") == video_id:
            row["post_link"] = link
            updated = True

    posted = (((data.get("videos") or {}).get(video_id) or {}).get("posted_pages") or {}).get(destination_key)
    if isinstance(posted, dict):
        posted["post_link"] = link
        updated = True

    if updated:
        save_json(registry_path, data)
        print(f"✅ Registry exact target overwritten: {video_id} → {link}")
    return updated


async def choose_exact_reel(profile: str, page_id: str) -> str:
    browser_service = BrowserService()

    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            f"{browser_service.user_data_dir}/{profile}",
            headless=False,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--disable-notifications",
            ],
            proxy=_fb_proxy_config(),
        )
        try:
            while True:
                print("\n🔎 Recent Reel permalinks စုနေပါတယ်...")
                links = await browser_service._collect_page_reel_links(
                    context,
                    str(page_id),
                    max_links=20,
                    quick=False,
                )

                if not links:
                    print("❌ Reel links မတွေ့ပါ။")
                    return ""

                print("\n⚠️ အောက်က order ကို 'newest order' လို့ မယူပါနဲ့။ Facebook DOM order မတည်ငြိမ်ပါ။")
                for i, link in enumerate(links, 1):
                    print(f" {i:>2}. {link}")

                print("\nရွေးချယ်မှု:")
                print(" number = browser မှာ preview ဖွင့်ပြီး စစ်မယ်")
                print(" m      = exact Reel URL ကို manual paste")
                print(" r      = list refresh")
                print(" 0      = cancel")

                raw = input("Reel > ").strip().lower()

                if raw in {"0", "q", "quit", "cancel"}:
                    return ""

                if raw in {"r", "refresh"}:
                    continue

                if raw in {"m", "manual"}:
                    pasted = input("Exact Facebook Reel URL paste > ").strip()
                    link = browser_service._normalize_fb_permalink(pasted)
                    if not link:
                        print("⚠️ Valid actual Reel permalink မဟုတ်ပါ။")
                        continue
                else:
                    try:
                        idx = int(raw)
                    except Exception:
                        print("⚠️ number / m / r / 0 တစ်ခုရွေးပါ။")
                        continue
                    if not 1 <= idx <= len(links):
                        print("⚠️ List ထဲက number ကိုရွေးပါ။")
                        continue
                    link = links[idx - 1]

                preview = await context.new_page()
                try:
                    print(f"\n👀 Preview: {link}")
                    await preview.goto(link, timeout=90000, wait_until="domcontentloaded")
                    await preview.wait_for_timeout(4000)
                    ans = input("ဒီဟာ target Reel အတိအကျလား? [y/N] > ").strip().lower()
                    if ans in {"y", "yes"}:
                        return link
                finally:
                    try:
                        await preview.close()
                    except Exception:
                        pass
        finally:
            await context.close()


def build_share_text_from_target(target: dict, max_chars: int = 420) -> str:
    output_path = str(target.get("output_path") or "").strip()
    candidates = []
    if output_path:
        out = Path(output_path)
        if not out.is_absolute():
            out = Path.cwd() / out
        candidates.append(out.parent / "smart_sync_plan.json")

    plan = {}
    for plan_path in candidates:
        if plan_path.exists():
            try:
                plan = load_json(str(plan_path))
                print(f"🧠 Group share text source plan: {plan_path}")
                break
            except Exception:
                pass

    title = str(plan.get("title") or "").strip()
    body = str(plan.get("caption") or "").strip()
    if body:
        body = " ".join(part for part in body.split() if not part.startswith("#")).strip()

    parts = []
    if title:
        parts.append(title)
    if body and body != title:
        parts.append(body)
    value = "\n\n".join(parts).strip()

    # If the old job plan is unavailable, let the user provide a natural caption
    # instead of silently posting an English source title.
    if not value:
        print("⚠️ Burmese smart_sync_plan.json မတွေ့ပါ။")
        value = input("Group share text (blank = permalink only) > ").strip()

    if max_chars > 0 and len(value) > max_chars:
        value = value[: max_chars - 1].rstrip() + "…"
    return value


async def main():
    print("🧪 Recovery V6.7 — modal-scoped group-share test")
    config = load_json(CONFIG_PATH)

    fb_items = []
    for page in config.get("pages") or []:
        if not page.get("enabled", True):
            continue
        for d in normalize_destinations(page):
            if d.get("platform") != "fb":
                continue
            if not (d.get("group_share") or {}).get("enabled", False):
                continue
            fb_items.append((page, d))

    if not fb_items:
        print("❌ Group-share enabled Facebook destination မတွေ့ပါ။")
        return

    print("\nFacebook destination ရွေးပါ:")
    for i, (page, d) in enumerate(fb_items, 1):
        print(
            f" {i}. {d.get('destination_key')} | "
            f"page_id={d.get('page_id') or page.get('page_id')} | "
            f"profile={d.get('browser_profile') or page.get('browser_profile') or 'Main_FB_Account'}"
        )

    raw = input("Destination [1] > ").strip()
    try:
        choice = int(raw or "1")
    except Exception:
        choice = 1
    choice = min(max(choice, 1), len(fb_items))
    page, dest = fb_items[choice - 1]

    page_id = str(dest.get("page_id") or page.get("page_id") or "").strip()
    profile = str(dest.get("browser_profile") or page.get("browser_profile") or "Main_FB_Account")
    destination_key = str(dest.get("destination_key"))
    registry_path = str(config.get("registry_path", "downloads/recap_source_registry.json"))

    _, target = get_latest_fb_target(registry_path, destination_key)
    if not target:
        print("❌ Registry ထဲ FB posted history မတွေ့ပါ။")
        return

    video_id = str(target.get("video_id") or "")
    print("\n🎯 Registry target:")
    print(f"   video_id : {video_id}")
    print(f"   title    : {target.get('title') or ''}")
    print(f"   posted_at: {target.get('posted_at') or ''}")
    print(f"   old link : {target.get('post_link') or '(blank)'}")
    print("\nℹ️ Old link valid ဖြစ်နေတောင် WRONG ဖြစ်နိုင်လို့ ဒီ script က exact Reel ကို ပြန်ရွေးခွင့်ပေးပါတယ်။")

    link = await choose_exact_reel(profile, page_id)
    if not link:
        print("⏭️ Cancelled.")
        return

    print(f"\n🔗 CONFIRMED EXACT REEL: {link}")
    overwrite_exact_target(registry_path, destination_key, video_id, link)

    accounts = get_share_accounts(enabled_only=True)
    names = list(accounts.keys())
    if not names:
        print("⚠️ Enabled share account မရှိပါ။ Registry correction ပဲပြီးပါပြီ။")
        return

    print("\nဒီ Reel ကို share မယ့် accounts ရွေးပါ:")
    for i, name in enumerate(names, 1):
        print(f" {i}. {name} | groups={len(accounts[name].get('groups') or [])}")

    raw = input("Accounts [Enter=all, 0=skip, e.g. 1,3,5-7] > ").strip()
    selected = parse_selection(raw, names)
    if not selected:
        print("⏭️ Group share skip. Registry correction ပဲပြီးပါပြီ။")
        return

    group_cfg = dest.get("group_share") or {}
    share_text = build_share_text_from_target(
        target,
        max_chars=int(group_cfg.get("share_text_max_chars", 420)),
    )
    if share_text:
        print(f"📝 Group share text: {share_text[:160]}{'…' if len(share_text) > 160 else ''}")

    await auto_share_all_accounts(
        link,
        account_names=selected,
        share_text=share_text,
        headless=bool(group_cfg.get("headless", False)),
        delay_between_groups_seconds=float(group_cfg.get("delay_between_groups_seconds", 20)),
        delay_between_accounts_seconds=float(group_cfg.get("delay_between_accounts_seconds", 120)),
    )
    print("🎉 Exact Reel correction + group share complete.")


if __name__ == "__main__":
    asyncio.run(main())
