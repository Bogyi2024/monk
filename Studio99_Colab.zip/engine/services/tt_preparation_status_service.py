from __future__ import annotations

import json
import os
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from services.tt_worker_lease_service import running_lease_status, pid_is_alive
from services.tt_novel_bridge import TTNovelBridge


class TTPreparationStatusService:
    """Read-only preparation/inventory view for prepared-content categories.

    V2.0.21 keeps standalone projects decoupled while fixing two important LTS
    semantics:
      1) relative output paths are resolved against the standalone LTS root, so
         generated files immediately become visible to TT posting/prep gating;
      2) preparation status aggregates the configurable future date buffer.
    """

    LTS = "long_to_short"
    ES = "episode_splitter"
    NOVEL = "novel"
    LTS_POST_COPY_SCHEMA = "lts_social_metadata_mm_title_en_hashtags_v2"
    OUTPUT_ALIASES = {
        "video": "transformative_envo_mm",
        "transformative_envo_mm": "transformative_envo_mm",
        "voiceover_mm_sub": "transformative_envo_mm",
        "original_audio_mm": "original_audio_mm",
        "original_sound_mm_sub": "original_audio_mm",
        "transformative_envo_en": "transformative_envo_en",
        "voiceover_en_sub": "transformative_envo_en",
        "original_audio_en": "original_audio_en",
        "original_sound_en_sub": "original_audio_en",
    }

    def __init__(self, settings_service, project_root: str | Path | None = None):
        self.settings = settings_service
        self.root = Path(project_root or getattr(settings_service, "root", ".")).resolve()
        lts_env = str(os.getenv("TT_LONG_TO_SHORT_DIR") or "").strip()
        es_env = str(os.getenv("TT_EPISODE_SPLITTER_DIR") or "").strip()
        self.lts_root = Path(lts_env).expanduser().resolve() if lts_env else (self.root.parent / "long_to_short").resolve()
        self.es_root = Path(es_env).expanduser().resolve() if es_env else (self.root.parent / "episode_splitter").resolve()
        self.lts_night_state = self.root / "state" / "tt_long_to_short_night.json"
        self.lts_pending_dir = self.root / "state" / "tt_long_to_short_pending"
        self.es_night_state = self.root / "state" / "tt_episode_splitter_night.json"
        self.source_auth_state = self.root / "state" / "tt_source_download_auth.json"
        self.novel_generation_state = self.root / "state" / "tt_novel_generation.json"
        self.novel_generation_lock = self.root / "state" / "tt_novel_generation.lock.json"

    @staticmethod
    def _read_json(path: Path, default: Any) -> Any:
        try:
            data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else default
            return data
        except Exception:
            return default

    @staticmethod
    def _existing(path_value: Any) -> bool:
        raw = str(path_value or "").strip()
        return bool(raw and Path(raw).exists())

    @staticmethod
    def _existing_under(root: Path, path_value: Any) -> bool:
        """Resolve standalone-relative manifest paths without coupling imports.

        Long-to-Short manifests may store project-relative ``outputs/...`` paths
        instead of an absolute Windows path. TT Master runs from recap_personal,
        so blindly calling Path(relative).exists() checks the wrong project.
        """
        raw = str(path_value or "").strip()
        if not raw:
            return False
        p = Path(raw)
        if p.is_absolute() and p.exists():
            return True
        if not p.is_absolute():
            if (root / p).exists():
                return True
            # Some older manifests contain a bare candidate filename although the
            # real file lives somewhere below standalone outputs/. Keep this as a
            # bounded fallback only; exact relative/absolute paths win first.
            if len(p.parts) == 1:
                out = root / "outputs"
                try:
                    return any(x.is_file() for x in out.rglob(p.name)) if out.exists() else False
                except OSError:
                    return False
        return False

    def _lts_existing(self, path_value: Any) -> bool:
        return self._existing_under(self.lts_root, path_value)

    @classmethod
    def _lts_copy_ready(cls, item: dict[str, Any]) -> bool:
        tags = item.get("hashtags") or []
        return bool(
            str((item.get("social_metadata") or {}).get("schema") or "") == cls.LTS_POST_COPY_SCHEMA
            and str(item.get("title") or "").strip()
            and str(item.get("fb_caption") or "").strip()
            and str(item.get("tt_caption") or "").strip()
            and isinstance(tags, list)
            and any(re.fullmatch(r"#[A-Za-z0-9_]+", str(tag or "").strip()) for tag in tags)
        )

    @classmethod
    def _lts_mode(cls, route: dict[str, Any]) -> str | None:
        raw = str(route.get("output_type") or "transformative_envo_mm").strip().lower()
        mode = cls.OUTPUT_ALIASES.get(raw, raw)
        return mode if mode in {"transformative_envo_mm", "original_audio_mm", "transformative_envo_en", "original_audio_en"} else None

    @staticmethod
    def _lts_category(route: dict[str, Any]) -> str:
        return str(route.get("lts_category") or route.get("content_type") or "motivation").strip().lower().replace("-", "_") or "motivation"

    @classmethod
    def _lts_bucket(cls, route: dict[str, Any]) -> str:
        return f"{cls._lts_category(route)}::{str(route.get('content_group') or 'main').strip() or 'main'}"

    @staticmethod
    def _episode_pool(route_key: str, route: dict[str, Any]) -> str:
        return str(route.get("episode_pool") or route.get("pool_name") or route.get("content_type") or route_key or "main").strip() or "main"

    def _enabled_routable(self, category_key: str) -> dict[str, dict[str, Any]]:
        cat = ((self.settings.categories().get("categories") or {}).get(category_key) or {})
        out: dict[str, dict[str, Any]] = {}
        for rk, route in (cat.get("routes") or {}).items():
            if not isinstance(route, dict) or not route.get("enabled", True):
                continue
            if max(0, int(route.get("daily_limit") or 0)) <= 0:
                continue
            try:
                resolved = self.settings.resolve_route(category_key, str(rk))
                fb, tt = resolved.get("facebook"), resolved.get("tiktok")
                if not ((fb and fb.get("enabled", True)) or (tt and tt.get("enabled", True))):
                    continue
            except Exception:
                continue
            out[str(rk)] = route
        return out

    # ---------------- Long-to-Short ----------------
    def _lts_inventory(self, date: str) -> dict[str, Any]:
        path = self.lts_root / "state" / "tt_bridge" / "inventory" / f"{date}.json"
        data = self._read_json(path, {})
        if not isinstance(data, dict) or str(data.get("date") or "") != str(date):
            data = {"date": str(date), "groups": {}}
        data.setdefault("groups", {})
        return data

    def _lts_pending_path(self, route_key: str) -> Path:
        safe = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in str(route_key or "default"))
        return self.lts_pending_dir / f"{safe}.json"

    def lts_route_active_count(self, route_key: str) -> int:
        """Read-only primary-upload activity derived from TT's existing pending file.

        A pending file remains during group-share/permalink maintenance after the
        primary destinations are already complete. That secondary-only state must
        NOT appear as an active/unposted primary item, so inventory_primary_marked
        is the boundary. No claim/reservation state is created here.
        """
        data = self._read_json(self._lts_pending_path(route_key), {})
        if not isinstance(data, dict) or not data:
            return 0
        return 0 if bool(data.get("inventory_primary_marked")) else 1

    def lts_route_ready_count(self, date: str, route_key: str) -> int:
        routes = self._enabled_routable(self.LTS)
        route = routes.get(str(route_key))
        if not route:
            return 0
        mode = self._lts_mode(route)
        if not mode:
            return 0
        bucket = self._lts_bucket(route)
        inv = self._lts_inventory(date)
        row = (inv.get("groups") or {}).get(bucket) or {}
        ready = 0
        for item in row.get("items") or []:
            if not isinstance(item, dict):
                continue
            if not self._lts_copy_ready(item):
                continue
            if str(route_key) in (item.get("primary_by_route") or {}):
                continue
            if self._lts_existing((item.get("outputs") or {}).get(mode)):
                ready += 1
        return ready

    def _lts_plan(self) -> dict[str, dict[str, Any]]:
        cat = ((self.settings.categories().get("categories") or {}).get(self.LTS) or {})
        profiles = cat.get("content_categories") or {}
        groups: dict[str, dict[str, Any]] = {}
        for rk, route in self._enabled_routable(self.LTS).items():
            mode = self._lts_mode(route)
            if not mode:
                continue
            category = self._lts_category(route)
            profile = profiles.get(category) or {}
            if profile and not profile.get("enabled", True):
                continue
            bucket = self._lts_bucket(route)
            row = groups.setdefault(bucket, {
                "bucket": bucket,
                "content_category": category,
                "content_label": str(profile.get("label") or category),
                "reuse_group": bucket.split("::", 1)[1] if "::" in bucket else "main",
                "prep_buffer_days": max(1, min(7, int(profile.get("prep_buffer_days") or 3))),
                "daily_requirements": {},
                "routes": [],
            })
            row["routes"].append(rk)
            target = max(0, int(route.get("daily_limit") or 0))
            row["daily_requirements"][mode] = max(int(row["daily_requirements"].get(mode, 0)), target)
        return groups

    def _lts_group_counts(self, date: str, bucket: str, requirements: dict[str, int]) -> dict[str, Any]:
        inv = self._lts_inventory(date)
        items = list((((inv.get("groups") or {}).get(bucket) or {}).get("items") or []))
        ready_by_mode = {mode: 0 for mode in requirements}
        complete_items = 0
        for item in items:
            if not isinstance(item, dict):
                continue
            if not self._lts_copy_ready(item):
                continue
            outputs = item.get("outputs") or {}
            for mode in ready_by_mode:
                if self._lts_existing(outputs.get(mode)):
                    ready_by_mode[mode] += 1
            if requirements and all(self._lts_existing(outputs.get(mode)) for mode, need in requirements.items() if int(need) > 0):
                complete_items += 1
        unique_target = max([int(v) for v in requirements.values()] or [0])
        files_target = sum(max(0, int(v)) for v in requirements.values())
        files_ready = sum(min(ready_by_mode.get(mode, 0), max(0, int(need))) for mode, need in requirements.items())
        complete = all(ready_by_mode.get(mode, 0) >= max(0, int(need)) for mode, need in requirements.items())
        return {
            "date": date,
            "unique_target": unique_target,
            "unique_ready": min(complete_items, unique_target) if unique_target else complete_items,
            "files_target": files_target,
            "files_ready": files_ready,
            "ready_by_mode": ready_by_mode,
            "complete": complete,
        }

    def active_preparation(self, now: datetime | None = None) -> dict[str, Any] | None:
        """Read worker activity independently from posting locks and buffer dates."""
        now = now or datetime.now().astimezone()
        pending = self.root / 'state' / 'tt_long_to_short_pending'
        for path in sorted(pending.glob('*.activity.json')):
            activity = self._read_json(path, {})
            if activity.get('worker_pid') and pid_is_alive(activity['worker_pid']):
                return {**activity, 'status': 'RUNNING'}
        for category, path in [(self.LTS, self.lts_night_state), (self.ES, self.es_night_state)]:
            night = self._read_json(path, {})
            if running_lease_status(night, now)[0]:
                return {'category': category, 'status': 'RUNNING',
                        'started_at': night.get('last_attempt_at', ''),
                        'target_date': night.get('current_target_date') or night.get('target_date', ''),
                        'groups': list(night.get('requirements') or night.get('pools') or [])}
        return None

    def lts_snapshot(self, now: datetime) -> dict[str, Any]:
        today = now.date().isoformat()
        plan = self._lts_plan()
        night = self._read_json(self.lts_night_state, {})
        groups = []
        all_dates: set[str] = set()
        for bucket, row in plan.items():
            days = max(1, int(row.get("prep_buffer_days") or 1))
            daily_req = dict(row.get("daily_requirements") or {})
            date_rows = []
            aggregate_ready = {mode: 0 for mode in daily_req}
            for offset in range(1, days + 1):
                date = (now.date() + timedelta(days=offset)).isoformat()
                all_dates.add(date)
                counts = self._lts_group_counts(date, bucket, daily_req)
                date_rows.append(counts)
                for mode in aggregate_ready:
                    aggregate_ready[mode] += min(int(counts.get("ready_by_mode", {}).get(mode, 0)), int(daily_req.get(mode, 0)))
            total_requirements = {mode: int(need) * days for mode, need in daily_req.items()}
            unique_target = sum(int(x.get("unique_target") or 0) for x in date_rows)
            unique_ready = sum(int(x.get("unique_ready") or 0) for x in date_rows)
            files_target = sum(int(x.get("files_target") or 0) for x in date_rows)
            files_ready = sum(int(x.get("files_ready") or 0) for x in date_rows)
            complete_days = sum(1 for x in date_rows if x.get("complete"))
            complete = bool(date_rows) and complete_days == days
            first_missing = next((str(x.get("date") or "") for x in date_rows if not x.get("complete")), "")
            groups.append({
                **row,
                "requirements": total_requirements,
                "ready_by_mode": aggregate_ready,
                "date_rows": date_rows,
                "unique_target": unique_target, "unique_ready": unique_ready,
                "files_target": files_target, "files_ready": files_ready,
                "complete_days": complete_days, "coverage_days": complete_days,
                "complete": complete, "first_missing_date": first_missing,
            })

        today_routes = []
        for rk, route in self._enabled_routable(self.LTS).items():
            today_routes.append({
                "route_key": rk,
                "route_label": str(route.get("label") or rk),
                "target": max(0, int(route.get("daily_limit") or 0)),
                "ready": self.lts_route_ready_count(today, rk),
                "active": self.lts_route_active_count(rk),
                "bucket": self._lts_bucket(route),
                "output_mode": self._lts_mode(route) or "",
            })
        total_files_target = sum(int(x.get("files_target") or 0) for x in groups)
        total_files_ready = sum(int(x.get("files_ready") or 0) for x in groups)
        total_unique_target = sum(int(x.get("unique_target") or 0) for x in groups)
        total_unique_ready = sum(int(x.get("unique_ready") or 0) for x in groups)
        complete = bool(groups) and all(bool(x.get("complete")) for x in groups)
        target_dates = sorted(all_dates)
        night_dates = list(night.get("target_dates") or ([night.get("target_date")] if night.get("target_date") else []))
        night_matches = bool(target_dates) and night_dates == target_dates
        activity = self.active_preparation(now)
        running = bool(activity and activity.get('category') == self.LTS)
        any_ready = total_files_ready > 0
        if running:
            status = "RUNNING"
        elif not groups:
            status = "NO ENABLED ROUTES"
        elif complete:
            status = "READY"
        elif night_matches and str(night.get("status") or "").lower() == "running":
            live, _reason = running_lease_status(night, now)
            status = "RUNNING" if live else "INTERRUPTED"
        elif any_ready:
            status = "REFILL NEEDED"
        elif night_matches and str(night.get("status") or "").lower() in {"error", "shortfall", "interrupted"}:
            status = str(night.get("status") or "").upper()
        else:
            status = "WAITING FOR IDLE"
        return {
            "category": self.LTS,
            "label": "Long-to-Short",
            "today": today,
            "target_date": target_dates[0] if target_dates else "",
            "target_dates": target_dates,
            "buffer_days": max([int(x.get("prep_buffer_days") or 1) for x in groups] or [0]),
            "status": status,
            "groups": groups,
            "today_routes": today_routes,
            "unique_target": total_unique_target,
            "unique_ready": total_unique_ready,
            "files_target": total_files_target,
            "files_ready": total_files_ready,
            "last_attempt_at": str(activity.get('started_at') or '') if running else (str(night.get("last_attempt_at") or "") if night_matches else ""),
            "last_error": "" if running else (str(night.get("last_error") or "") if night_matches else ""),
            "activity": activity if running else None,
        }

    # ---------------- Episode Splitter ----------------
    @staticmethod
    def _parse_time(value: Any) -> datetime | None:
        raw = str(value or "").strip()
        if not raw:
            return None
        try:
            parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
            return parsed if parsed.tzinfo is not None else parsed.astimezone()
        except (TypeError, ValueError):
            return None

    def _episode_source_diagnostic(self, pool: str) -> dict[str, Any]:
        registry = self._read_json(self.es_root / "pools" / str(pool) / "state" / "youtube_sources.json", {})
        items = (registry.get("items") or {}) if isinstance(registry, dict) else {}
        failed = [row for row in items.values() if isinstance(row, dict) and str(row.get("status") or "").upper() == "FAILED"]
        failed.sort(key=lambda row: str(row.get("last_attempt_at") or ""), reverse=True)
        if not failed:
            return {"source_failure_kind": "", "source_error": "", "source_failed_count": 0, "source_last_attempt_at": ""}
        latest = failed[0]
        raw_error = str(latest.get("last_error") or "").strip()
        lowered = raw_error.casefold()
        if "sign in to confirm you’re not a bot" in lowered or "sign in to confirm you're not a bot" in lowered:
            kind = "source_auth_required"
            message = "YouTube source login expired or was rejected. Refresh Source Download Auth before retrying."
        else:
            kind = "source_download_failed"
            message = raw_error[-500:] if raw_error else "Episode source download failed."
        last_attempt = str(latest.get("last_attempt_at") or "")
        auth = self._read_json(self.source_auth_state, {})
        refreshed_at = str(auth.get("youtube_last_refresh_at") or "") if isinstance(auth, dict) else ""
        attempted_dt = self._parse_time(last_attempt)
        refreshed_dt = self._parse_time(refreshed_at)
        refreshed_after = bool(attempted_dt and refreshed_dt and refreshed_dt.astimezone(attempted_dt.tzinfo) > attempted_dt)
        return {
            "source_failure_kind": kind,
            "source_error": message,
            "source_failed_count": len(failed),
            "source_last_attempt_at": last_attempt,
            "source_auth_refreshed_at": refreshed_at,
            "source_auth_refreshed_after_failure": refreshed_after,
        }

    def _episode_inventory(self, pool: str) -> dict[str, Any]:
        pool_dir = self.es_root / "pools" / str(pool)
        inv_path = pool_dir / "state" / "inventory.json"
        data = self._read_json(inv_path, {})
        if not isinstance(data, dict):
            data = {}
        pool_cfg = self._read_json(pool_dir / "pool.json", {})
        defaults = self._read_json(self.es_root / "config" / "config.json", {}).get("inventory") or {}
        ready_dir = pool_dir / "ready"
        posted_dir = pool_dir / "posted"
        ready = sum(1 for p in ready_dir.rglob("*.mp4")) if ready_dir.exists() else 0
        posted = sum(1 for p in posted_dir.rglob("*.mp4")) if posted_dir.exists() else 0
        return {
            "pool": pool,
            "exists": pool_dir.exists(),
            "display_name": str(data.get("display_name") or pool_cfg.get("display_name") or pool),
            "ready_parts": ready if pool_dir.exists() else int(data.get("ready_parts") or 0),
            "posted_parts": posted if pool_dir.exists() else int(data.get("posted_parts") or 0),
            "min_ready_parts": int(data.get("min_ready_parts") or pool_cfg.get("min_ready_parts") or defaults.get("min_ready_parts") or 4),
            "target_ready_parts": int(data.get("target_ready_parts") or pool_cfg.get("target_ready_parts") or defaults.get("target_ready_parts") or 6),
            "queue": list(data.get("queue") or []),
            "updated_at": str(data.get("updated_at") or ""),
            **self._episode_source_diagnostic(pool),
        }

    def episode_route_ready_count(self, route_key: str) -> int:
        routes = self._enabled_routable(self.ES)
        route = routes.get(str(route_key))
        if not route:
            return 0
        return int(self._episode_inventory(self._episode_pool(route_key, route)).get("ready_parts") or 0)

    def episode_snapshot(self, now: datetime) -> dict[str, Any]:
        night = self._read_json(self.es_night_state, {})
        night_running = str(night.get("status") or "").lower() == "running"
        if night_running:
            night_running, _lease_reason = running_lease_status(night, now)
        active_pools = {str(x) for x in (night.get("pools") or []) if str(x).strip()}
        cat = ((self.settings.categories().get("categories") or {}).get(self.ES) or {})
        rules = cat.get("production_rules") or {}
        prep_buffer_days = max(1, min(14, int(rules.get("prep_buffer_days") or 3)))
        pool_rows: dict[str, dict[str, Any]] = {}
        for rk, route in self._enabled_routable(self.ES).items():
            pool = self._episode_pool(rk, route)
            row = pool_rows.setdefault(pool, {
                "pool": pool,
                "routes": [],
                "posting_target": 0,
                "source_urls": [],
            })
            row["routes"].append(rk)
            row["posting_target"] += max(0, int(route.get("daily_limit") or 0))
            row["prep_buffer_days"] = prep_buffer_days
            for raw in route.get("source_urls") or []:
                url = str(raw or "").strip()
                if url and url not in row["source_urls"]:
                    row["source_urls"].append(url)
        rows = []
        for pool, base in pool_rows.items():
            inv = self._episode_inventory(pool)
            ready = int(inv.get("ready_parts") or 0)
            buffer_target = max(1, int(base.get("posting_target") or 1)) * prep_buffer_days
            minimum = buffer_target
            target = buffer_target
            pool_running = bool(night_running and (not active_pools or pool in active_pools))
            auth_action_required = bool(
                inv.get("source_failure_kind") == "source_auth_required"
                and not inv.get("source_auth_refreshed_after_failure")
            )
            if pool_running and ready < minimum:
                # A FAILED source row remains durable until the active retry
                # finishes. Do not present that stale history as the live state.
                status = "RUNNING"
            elif auth_action_required and ready < minimum:
                status = "ACTION REQUIRED"
            elif not inv.get("exists"):
                status = "POOL MISSING"
            elif ready < minimum:
                status = "NEEDS PREP"
            else:
                status = "READY"
            queue = inv.get("queue") or []
            current_source = str((queue[0] or {}).get("source_folder") or "") if queue else ""
            rows.append({
                **base,
                **inv,
                "status": status,
                "current_source": current_source,
                "prep_buffer_days": prep_buffer_days,
                "buffer_target_parts": buffer_target,
                "min_ready_parts": minimum,
                "target_ready_parts": target,
                # FAILED source rows are durable history. Once inventory is
                # healthy (or an active retry is running), they must not be
                # presented as the pool's current operational state.
                "source_failure_kind": "" if pool_running or status == "READY" else str(inv.get("source_failure_kind") or ""),
                "source_error": "" if pool_running or status == "READY" else str(inv.get("source_error") or ""),
            })
        status = "NO ENABLED ROUTES" if not rows else ("READY" if all(x.get("status") == "READY" for x in rows) else "NEEDS PREP")
        if rows and night_running:
            status = "RUNNING"
        elif any(x.get("status") == "ACTION REQUIRED" for x in rows):
            status = "ACTION REQUIRED"
        retry_minutes = max(5, int(rules.get("night_retry_minutes") or 60))
        finished = None if night_running else self._parse_time(night.get("finished_at") or night.get("last_attempt_at"))
        retry_at = finished + timedelta(minutes=retry_minutes) if finished else None
        auth_recovered = any(bool(x.get("source_auth_refreshed_after_failure")) for x in rows)
        if status == "NEEDS PREP" and retry_at and now < retry_at.astimezone(now.tzinfo) and not auth_recovered:
            status = "RETRY SCHEDULED"
        derived_error = "" if night_running else next((str(x.get("source_error") or "") for x in rows if x.get("source_error")), "")
        healthy = status == "READY"
        return {
            "category": self.ES,
            "label": "Episode Splitter",
            "status": status,
            "pools": rows,
            "last_attempt_at": str(night.get("last_attempt_at") or ""),
            "finished_at": str(night.get("finished_at") or ""),
            "retry_at": retry_at.isoformat(timespec="seconds") if retry_at and status == "RETRY SCHEDULED" else "",
            "retry_minutes": retry_minutes,
            "failure_kind": "" if night_running or healthy else str(night.get("failure_kind") or next((x.get("source_failure_kind") for x in rows if x.get("source_failure_kind")), "") or ""),
            "last_error": "" if night_running or healthy else str(night.get("last_error") or derived_error),
            "action_required": status == "ACTION REQUIRED",
            "running_pools": sorted(active_pools) if night_running else [],
        }

    # ---------------- Novel (read-only; generation stays on-demand) ----------------
    def novel_snapshot(self, now: datetime) -> dict[str, Any]:
        category = ((self.settings.categories().get("categories") or {}).get(self.NOVEL) or {})
        bridge = TTNovelBridge(self.settings, self.root)
        all_series = bridge._series()
        posted = (bridge._registry().get("posts") or {})
        dashboard_generation = self._read_json(self.novel_generation_state, {})
        scheduler_generation = self._read_json(self.novel_generation_lock, {})
        active_generation = scheduler_generation or (
            dashboard_generation if str(dashboard_generation.get("status") or "") == "running" else {}
        )
        today = now.date().isoformat()
        rows: list[dict[str, Any]] = []
        for route_key, route in (category.get("routes") or {}).items():
            if not isinstance(route, dict):
                continue
            genre = str(route.get("novel_genre") or "")
            owned = [
                series for series in all_series
                if (
                    str(series.get("route_key") or "") == str(route_key)
                    or (
                        not str(series.get("route_key") or "")
                        and genre
                        and str(series.get("genre") or "") == genre
                    )
                )
            ]
            items = [item for series in owned for item in (series.get("parts") or [])]
            unposted = [item for item in items if item.get("content_id") not in posted]
            ready = [
                item for item in unposted
                if item.get("files_ready") and item.get("style_ok") and str(item.get("publish_date") or "") <= today
            ]
            scheduled = [
                item for item in unposted
                if item.get("files_ready") and item.get("style_ok") and str(item.get("publish_date") or "") > today
            ]
            style_blocked = [item for item in unposted if not item.get("style_ok")]
            files_missing = [item for item in unposted if not item.get("files_ready")]
            photo_mode = bool(route.get("novel_screenshot_pages_enabled", False))
            page_ready_parts = sum(1 for item in unposted if item.get("screenshot_pages_ready"))
            page_missing_parts = max(0, len(unposted) - page_ready_parts) if photo_mode else 0
            screenshot_count = sum(
                int(item.get("story_page_count") or 0)
                for item in unposted if item.get("screenshot_pages_ready")
            )
            next_item = unposted[0] if unposted else None
            generation_here = bool(
                active_generation
                and str(
                    active_generation.get("route_key")
                    or (active_generation.get("request") or {}).get("route_key")
                    or ""
                ) == str(route_key)
            )
            enabled = bool(category.get("enabled", True) and route.get("enabled", True))
            has_page = bool(str(route.get("facebook_page") or "").strip())
            if not enabled:
                status = "DISABLED"
            elif not has_page:
                status = "PAGE REQUIRED"
            elif generation_here:
                status = "GENERATING"
            elif style_blocked:
                status = "STYLE BLOCKED"
            elif files_missing:
                status = "FILES MISSING"
            elif photo_mode and page_missing_parts:
                status = "PAGES ON-DEMAND"
            elif ready:
                status = "READY"
            elif scheduled:
                status = "SCHEDULED"
            else:
                status = "ON-DEMAND"
            rows.append({
                "route_key": str(route_key),
                "route_label": str(route.get("label") or route_key),
                "genre": genre,
                "enabled": enabled,
                "daily_target": max(0, int(route.get("daily_limit") or 0)),
                "long_text_enabled": bool(route.get("novel_long_text_enabled", True)),
                "screenshot_pages_enabled": photo_mode,
                "series_count": len(owned),
                "parts_total": len(items),
                "parts_posted": len(items) - len(unposted),
                "parts_remaining": len(unposted),
                "ready_parts": len(ready),
                "scheduled_parts": len(scheduled),
                "style_blocked_parts": len(style_blocked),
                "files_missing_parts": len(files_missing),
                "page_ready_parts": page_ready_parts,
                "page_missing_parts": page_missing_parts,
                "screenshot_count": screenshot_count,
                "next_part_no": int((next_item or {}).get("part_no") or 0),
                "next_publish_date": str((next_item or {}).get("publish_date") or ""),
                "next_title": str((next_item or {}).get("title") or ""),
                "status": status,
            })
        overall = "NO ROUTES" if not rows else (
            "DISABLED" if all(row["status"] == "DISABLED" for row in rows)
            else "GENERATING" if any(row["status"] == "GENERATING" for row in rows)
            else "ATTENTION" if any(row["status"] in {"STYLE BLOCKED", "FILES MISSING", "PAGE REQUIRED"} for row in rows)
            else "READY"
        )
        return {
            "category": self.NOVEL,
            "label": "Novel On-Demand Inventory",
            "status": overall,
            "read_only": True,
            "generation_mode": "on_demand_at_scheduler_turn",
            "routes": rows,
            "generation": active_generation,
        }

    # ---------------- Scheduler helpers ----------------
    def route_ready_count(self, category_key: str, route_key: str, now: datetime | None = None) -> int | None:
        now = now or datetime.now().astimezone()
        if category_key == self.LTS:
            return self.lts_route_ready_count(now.date().isoformat(), route_key)
        if category_key == self.ES:
            return self.episode_route_ready_count(route_key)
        return None

    def ready_route_keys(self, category_key: str, now: datetime | None = None) -> set[str] | None:
        now = now or datetime.now().astimezone()
        if category_key not in {self.LTS, self.ES}:
            return None
        return {rk for rk in self._enabled_routable(category_key) if int(self.route_ready_count(category_key, rk, now) or 0) > 0}

    def snapshot(self, now: datetime | None = None) -> dict[str, Any]:
        now = now or datetime.now().astimezone()
        return {
            "long_to_short": self.lts_snapshot(now),
            "episode_splitter": self.episode_snapshot(now),
            "novel": self.novel_snapshot(now),
        }
