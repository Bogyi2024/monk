from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _project_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _resolve_project_path(value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else (_project_root() / path)


def _load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_json_atomic(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".cleanup.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _destination_keys(page_config: dict[str, Any]) -> list[str]:
    """Mirror the scheduler's destination-key normalization without importing it."""
    stream_key = str(page_config.get("page_key") or "").strip()
    if not stream_key:
        return []

    raw = page_config.get("destinations")
    if isinstance(raw, list) and raw:
        destinations = [dict(item) for item in raw if isinstance(item, dict)]
    else:
        legacy = dict(page_config)
        legacy["platform"] = str(page_config.get("platform", "fb")).lower()
        destinations = [legacy]

    keys: list[str] = []
    for index, destination in enumerate(destinations, 1):
        if not destination.get("enabled", True):
            continue
        platform = str(destination.get("platform", "fb")).lower()
        if platform in {"facebook", "meta"}:
            platform = "fb"
        key = str(destination.get("destination_key") or f"{stream_key}_{platform}_{index}").strip()
        if key and key not in keys:
            keys.append(key)
    return keys


def _parse_iso(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _folder_size(path: Path) -> int:
    total = 0
    try:
        for item in path.rglob("*"):
            try:
                if item.is_file():
                    total += item.stat().st_size
            except OSError:
                pass
    except OSError:
        pass
    return total


def _fmt_bytes(value: int) -> str:
    size = float(max(0, int(value or 0)))
    units = ["B", "KB", "MB", "GB", "TB"]
    for unit in units:
        if size < 1024.0 or unit == units[-1]:
            return f"{size:.1f}{unit}" if unit != "B" else f"{int(size)}B"
        size /= 1024.0
    return f"{size:.1f}TB"


def _terminal_time_for_video(
    record: dict[str, Any],
    destination_keys: list[str],
    max_failures: int,
) -> datetime | None:
    """Return when ALL destinations became terminal.

    Terminal means either:
    - successfully posted, or
    - intentionally abandoned after reaching max_failures_per_video.

    The returned time is the latest post/failure time among all destinations, so
    retention starts only after the final destination is done.
    """
    posted = record.get("posted_pages") or {}
    failures = record.get("failures") or {}
    terminal_times: list[datetime] = []

    for key in destination_keys:
        post_info = posted.get(key)
        if isinstance(post_info, dict):
            at = _parse_iso(post_info.get("posted_at"))
            if at is None:
                return None
            terminal_times.append(at)
            continue

        fail_info = failures.get(key)
        if isinstance(fail_info, dict) and int(fail_info.get("count", 0) or 0) >= max_failures:
            at = _parse_iso(fail_info.get("last_failed_at"))
            if at is None:
                return None
            terminal_times.append(at)
            continue

        # Still retryable / not attempted => never clean its media yet.
        return None

    return max(terminal_times) if terminal_times else None


def _record_destination_contract(
    record: dict[str, Any],
    stream_key: str,
    current_destination_keys: list[str],
) -> list[str]:
    """Use the immutable per-job contract, not today's route configuration."""
    contracts = record.get("required_destinations_by_stream") or {}
    stored = contracts.get(stream_key) if isinstance(contracts, dict) else None
    if isinstance(stored, list):
        normalized = list(dict.fromkeys(
            str(key).strip() for key in stored if str(key).strip()
        ))
        if normalized:
            return normalized

    # Read-only compatibility for registries that have not yet passed through
    # RecapSourceService's one-time contract migration.
    observed: list[str] = []
    for field in ("posted_pages", "failures"):
        for key, meta in (record.get(field) or {}).items():
            if not isinstance(meta, dict):
                continue
            if str(meta.get("stream_key") or "").strip() != stream_key:
                continue
            normalized_key = str(key or "").strip()
            if normalized_key and normalized_key not in observed:
                observed.append(normalized_key)
    has_success = any(
        isinstance(meta, dict)
        and str(meta.get("stream_key") or "").strip() == stream_key
        for meta in (record.get("posted_pages") or {}).values()
    )
    return observed if has_success and observed else current_destination_keys


def cleanup_completed_jobs(config: dict[str, Any]) -> dict[str, Any]:
    """Delete old completed recap job folders while preserving all registries/history.

    Safe defaults require no config changes:
      enabled=True, retention_hours=24, max_delete_per_cycle=25, dry_run=False

    Only ``downloads/recap_jobs/<stream>/<video_id>`` folders are deleted.
    ``recap_source_registry.json``, group-share registry and health logs are NEVER
    deleted by this function.
    """
    cfg = config.get("storage_cleanup") or {}
    enabled = bool(cfg.get("enabled", True))
    retention_hours = max(0.0, float(cfg.get("retention_hours", 24)))
    max_delete = max(1, int(cfg.get("max_delete_per_cycle", 25)))
    dry_run = bool(cfg.get("dry_run", False))

    result: dict[str, Any] = {
        "enabled": enabled,
        "retention_hours": retention_hours,
        "dry_run": dry_run,
        "deleted_jobs": 0,
        "freed_bytes": 0,
        "freed_human": "0B",
        "eligible_jobs": 0,
        "scheduled_jobs": 0,
        "would_delete_jobs": 0,
        "would_free_bytes": 0,
        "would_free_human": "0B",
        "skipped_active": 0,
        "skipped_incomplete": 0,
        "errors": [],
        "deleted": [],
    }
    if not enabled:
        return result

    registry_path = _resolve_project_path(
        str(config.get("registry_path", "downloads/recap_source_registry.json"))
    )
    job_root = _resolve_project_path(
        str(config.get("job_root", "downloads/recap_jobs"))
    )
    if not registry_path.exists() or not job_root.exists():
        return result

    registry = _load_json(registry_path)
    videos = registry.get("videos") or {}
    reservations = registry.get("reservations") or {}
    max_failures = max(1, int(config.get("max_failures_per_video", 3)))
    now_utc = datetime.now(timezone.utc)

    streams: dict[str, list[str]] = {}
    for page in config.get("pages", []) or []:
        if not isinstance(page, dict) or not page.get("enabled", True):
            continue
        stream_key = str(page.get("page_key") or "").strip()
        keys = _destination_keys(page)
        if stream_key and keys:
            streams[stream_key] = keys

    # TT Master builds a one-route runtime config, so retired/renamed streams
    # are no longer present in config even though their completed media remains
    # under recap_jobs. Discover those folders too. An empty current key list is
    # fail-closed: only a persisted/inferable per-record contract can make one
    # of these archived jobs terminal and eligible for deletion.
    try:
        for stream_dir in job_root.iterdir():
            if stream_dir.is_dir():
                streams.setdefault(stream_dir.name, [])
    except OSError as exc:
        result["errors"].append(f"job_root discovery: {exc}")

    registry_changed = False
    candidates: list[tuple[datetime, str, str, Path, dict[str, Any]]] = []

    for stream_key, destination_keys in streams.items():
        stream_dir = job_root / stream_key
        if not stream_dir.exists():
            continue

        try:
            child_dirs = [p for p in stream_dir.iterdir() if p.is_dir()]
        except OSError as exc:
            result["errors"].append(f"{stream_key}: {exc}")
            continue

        for job_dir in child_dirs:
            video_id = job_dir.name
            reservation_key = f"{stream_key}:{video_id}"
            if reservation_key in reservations:
                result["skipped_active"] += 1
                continue

            record = videos.get(video_id)
            if not isinstance(record, dict):
                result["skipped_incomplete"] += 1
                continue

            contract_keys = _record_destination_contract(
                record, stream_key, destination_keys
            )
            terminal_at = _terminal_time_for_video(record, contract_keys, max_failures)
            if terminal_at is None:
                result["skipped_incomplete"] += 1
                continue

            age_hours = max(0.0, (now_utc - terminal_at).total_seconds() / 3600.0)
            if age_hours < retention_hours:
                continue

            candidates.append((terminal_at, stream_key, video_id, job_dir, record))

    # Oldest completed media first.
    candidates.sort(key=lambda row: row[0])
    result["eligible_jobs"] = len(candidates)
    result["scheduled_jobs"] = min(len(candidates), max_delete)

    for terminal_at, stream_key, video_id, job_dir, record in candidates[:max_delete]:
        size = _folder_size(job_dir)
        rel = str(job_dir.relative_to(_project_root())) if job_dir.is_relative_to(_project_root()) else str(job_dir)

        if dry_run:
            result["would_delete_jobs"] += 1
            result["would_free_bytes"] += size
            print(f"🧹 [DRY RUN] would delete {rel} ({_fmt_bytes(size)})")
            continue

        try:
            shutil.rmtree(job_dir)
            result["deleted_jobs"] += 1
            result["freed_bytes"] += size
            result["deleted"].append({
                "stream_key": stream_key,
                "video_id": video_id,
                "job_dir": rel,
                "bytes": size,
                "terminal_at": terminal_at.isoformat(),
            })

            record["media_cleanup"] = {
                "cleaned_at": now_utc.isoformat(),
                "terminal_at": terminal_at.isoformat(),
                "job_dir": rel,
                "bytes_deleted": size,
                "retention_hours": retention_hours,
            }
            registry_changed = True
            print(f"🗑️ Storage cleanup: {rel} deleted ({_fmt_bytes(size)})")
        except Exception as exc:
            result["errors"].append(f"{rel}: {exc}")
            print(f"⚠️ Storage cleanup delete failed: {rel} ({exc})")

    result["freed_human"] = _fmt_bytes(result["freed_bytes"])
    result["would_free_human"] = _fmt_bytes(result["would_free_bytes"])

    # Save only metadata; all source/post histories remain intact.
    if registry_changed:
        _save_json_atomic(registry_path, registry)

    if result["deleted_jobs"]:
        print(
            f"🧹 Storage cleanup complete: deleted={result['deleted_jobs']} job(s), "
            f"freed={result['freed_human']}, retention={retention_hours:g}h"
        )
    elif not dry_run:
        print(f"🧹 Storage cleanup: nothing eligible yet (retention={retention_hours:g}h).")

    return result
