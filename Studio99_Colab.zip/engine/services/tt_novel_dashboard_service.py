from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import threading
from datetime import date, datetime
from pathlib import Path
from typing import Any

from services.tt_novel_bridge import TTNovelBridge


class TTNovelDashboardService:
    """Dashboard control and read-only inventory view for the standalone Novel app."""

    _LOCK = threading.RLock()

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings = settings_service
        self.root = Path(project_root).resolve()
        self.standalone_root = (self.root.parent / "novel_standalone").resolve()
        self.state_path = self.root / "state" / "tt_novel_generation.json"
        self.log_path = self.standalone_root / "logs" / "dashboard_generation.log"
        self.bridge = TTNovelBridge(settings_service, self.root)

    @staticmethod
    def _atomic(path: Path, data: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        os.close(fd)
        tmp = Path(name)
        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            os.replace(tmp, path)
        finally:
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass

    def _state(self) -> dict[str, Any]:
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}

    def _write_state(self, **values: Any) -> dict[str, Any]:
        with self._LOCK:
            state = self._state()
            state.update(values)
            self._atomic(self.state_path, state)
            return state

    def _tail(self, limit: int = 30) -> list[str]:
        try:
            return self.log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:]
        except OSError:
            return []

    @staticmethod
    def _pid_alive(pid: Any) -> bool:
        try:
            value = int(pid)
            if value <= 0:
                return False
            os.kill(value, 0)
            return True
        except (TypeError, ValueError, OSError):
            return False

    def snapshot(self) -> dict[str, Any]:
        state = self._state()
        if state.get("status") == "running" and state.get("pid") and not self._pid_alive(state.get("pid")):
            state = self._write_state(
                status="interrupted",
                finished_at=datetime.now().astimezone().isoformat(timespec="seconds"),
                error="Novel worker process ended before a completion receipt was written; safe to retry.",
            )
        inventory = self.bridge.inventory_snapshot()
        return {
            **inventory,
            "generation": state,
            "log_tail": self._tail(),
        }

    def _launch(self, args: list[str], *, operation: str, request: dict[str, Any]) -> dict[str, Any]:
        with self._LOCK:
            current = self._state()
            if current.get("status") == "running":
                raise RuntimeError(
                    f"Novel {current.get('operation') or 'job'} is already running since "
                    f"{current.get('started_at') or 'unknown time'}"
                )
            if not (self.standalone_root / "run_novel.py").exists():
                raise FileNotFoundError(f"Novel standalone runner missing: {self.standalone_root}")
            route_key = str(request.get("route_key") or "manual")
            self.bridge._acquire_generation_lock(route_key, operation)
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            started = datetime.now().astimezone().isoformat(timespec="seconds")
            state = {
                "status": "running",
                "operation": operation,
                "started_at": started,
                "finished_at": "",
                "request": request,
                "error": "",
                "returncode": None,
                "pid": None,
                "log_path": str(self.log_path),
            }
            self._atomic(self.state_path, state)

            def worker() -> None:
                try:
                    with self.log_path.open("a", encoding="utf-8") as log:
                        log.write(f"\n===== {started} {operation} =====\n")
                        log.flush()
                        process = subprocess.Popen(
                            [sys.executable, "-X", "utf8", "run_novel.py", *args],
                            cwd=str(self.standalone_root),
                            stdout=log,
                            stderr=subprocess.STDOUT,
                            text=True,
                            creationflags=(subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0),
                        )
                        self._write_state(pid=process.pid)
                        self.bridge._atomic_json(self.bridge.generation_lock_path, {
                            "route_key": route_key,
                            "operation": operation,
                            "owner_pid": os.getpid(),
                            "worker_pid": process.pid,
                            "started_at": started,
                        })
                        try:
                            returncode = process.wait(timeout=3 * 60 * 60)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=30)
                            raise TimeoutError("Novel generation exceeded the 3-hour hard timeout")
                    self._write_state(
                        status="complete" if returncode == 0 else "failed",
                        finished_at=datetime.now().astimezone().isoformat(timespec="seconds"),
                        returncode=returncode,
                        error="" if returncode == 0 else f"Novel process exited {returncode}",
                    )
                except Exception as exc:
                    self._write_state(
                        status="failed",
                        finished_at=datetime.now().astimezone().isoformat(timespec="seconds"),
                        returncode=-1,
                        error=str(exc),
                    )
                finally:
                    self.bridge.generation_lock_path.unlink(missing_ok=True)

            threading.Thread(target=worker, name=f"TTNovel-{operation}", daemon=True).start()
            return state

    def generate(
        self,
        *,
        genre: str,
        story_seed: str,
        publish_start_date: str,
        route_key: str = "",
        screenshot_pages: bool = False,
    ) -> dict[str, Any]:
        config = self.bridge._config()
        genres = [str(x).strip() for x in config.get("genres") or [] if str(x).strip()]
        selected = str(genre or "").strip()
        if selected not in genres:
            raise ValueError("Choose a Novel genre from the configured list")
        seed = str(story_seed or "").strip()
        if len(seed) > 5000:
            raise ValueError("Novel synopsis is too long (maximum 5000 characters)")
        raw_date = str(publish_start_date or date.today().isoformat()).strip()
        start = date.fromisoformat(raw_date).isoformat()
        args = ["--genre", selected, "--synopsis", seed, "--start-date", start, "--route-key", str(route_key or "")]
        if screenshot_pages:
            args.append("--screenshot-pages")
        return self._launch(
            args,
            operation="generate",
            request={"genre": selected, "story_seed": seed, "publish_start_date": start, "route_key": str(route_key or ""), "screenshot_pages": bool(screenshot_pages)},
        )

    def generate_route(self, route_key: str) -> dict[str, Any]:
        resolved = self.settings.resolve_route("novel", str(route_key or "default"))
        route = resolved.get("route") or {}
        if not route.get("enabled", True):
            raise RuntimeError(f"Novel route is disabled: {route_key}")
        safe_route_key = str(route_key or "default")
        genre = str(route.get("novel_genre") or "")
        remaining = self.bridge._unposted_items(safe_route_key, genre)
        if remaining:
            raise RuntimeError(
                f"Novel route {safe_route_key} still has {len(remaining)} unposted part(s); "
                "existing stock must be consumed before a new series is generated"
            )
        incomplete = self.bridge._latest_incomplete_dir(safe_route_key)
        if incomplete:
            args = ["--resume", str(incomplete)]
            if bool(route.get("novel_screenshot_pages_enabled", False)):
                args.append("--screenshot-pages")
            return self._launch(
                args,
                operation="resume_generation",
                request={"route_key": safe_route_key, "series_dir": str(incomplete)},
            )
        return self.generate(
            genre=genre,
            story_seed=str(route.get("novel_story_seed") or ""),
            publish_start_date=date.today().isoformat(),
            route_key=safe_route_key,
            screenshot_pages=bool(route.get("novel_screenshot_pages_enabled", False)),
        )

    def repair_latest_style(self) -> dict[str, Any]:
        latest = self.bridge.inventory_snapshot().get("latest_series") or {}
        series_dir = str(latest.get("series_dir") or "")
        if not series_dir:
            raise RuntimeError("No completed Novel series exists to repair")
        return self._launch(
            ["--resume", series_dir, "--repair-style"],
            operation="repair_style",
            request={"series_dir": series_dir},
        )
