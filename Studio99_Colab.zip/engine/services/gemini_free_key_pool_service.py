from __future__ import annotations

import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, TypeVar

from dotenv import dotenv_values
from google import genai
from google.genai import types


T = TypeVar("T")


@dataclass(frozen=True)
class GeminiFreeKeyEntry:
    alias: str
    env_name: str
    value: str


class GeminiFreeKeyPoolService:
    """Gemini pool sourced only from this project's numbered ``.env`` keys.

    Process-level ``GEMINI_API_KEY`` and ``GEMINI_IMAGE_PAID_KEY`` are never
    candidates, so production cannot silently fall back to either paid key.
    """

    _PROJECT_RE = re.compile(r"^GEMINI_IMAGE_PROJECT_(\d+)_KEY$", re.I)

    def __init__(
        self,
        env_path: str | Path | None = None,
        *,
        request_timeout_ms: int | None = None,
    ):
        root = Path(__file__).resolve().parents[1]
        self.env_path = Path(env_path).resolve() if env_path else root / ".env"
        self.request_timeout_ms = (
            max(1_000, int(request_timeout_ms))
            if request_timeout_ms is not None
            else None
        )
        self.entries = self.discover_entries(self.env_path)
        if not self.entries:
            raise RuntimeError(
                f"No free Gemini project key found in {self.env_path}. Add "
                "GEMINI_IMAGE_PROJECT_<N>_KEY; paid/process keys are disabled."
            )
        self._clients: dict[str, Any] = {}
        self._disabled_for_run: set[str] = set()
        self._active_alias: str | None = None
        print(
            "🔑 Gemini FREE .env pool: "
            + " → ".join(entry.alias for entry in self.entries)
            + " | process/paid fallback=OFF"
        )

    @classmethod
    def discover_entries(cls, env_path: str | Path) -> list[GeminiFreeKeyEntry]:
        values = dotenv_values(Path(env_path))
        ranked: list[tuple[int, GeminiFreeKeyEntry]] = []
        seen_values: set[str] = set()

        dedicated = str(values.get("GEMINI_TEXT_FREE_KEY") or "").strip()
        if dedicated:
            ranked.append((0, GeminiFreeKeyEntry("text_free", "GEMINI_TEXT_FREE_KEY", dedicated)))
            seen_values.add(dedicated)

        for raw_name, raw_value in values.items():
            env_name = str(raw_name or "").strip()
            value = str(raw_value or "").strip()
            match = cls._PROJECT_RE.match(env_name)
            if not match or not value or value in seen_values:
                continue
            number = int(match.group(1))
            ranked.append(
                (number + 1000, GeminiFreeKeyEntry(f"project_{number}", env_name, value))
            )
            seen_values.add(value)

        ranked.sort(key=lambda row: row[0])
        return [entry for _, entry in ranked]

    def _ordered_entries(self) -> list[GeminiFreeKeyEntry]:
        entries = [e for e in self.entries if e.alias not in self._disabled_for_run]
        if self._active_alias:
            active = next((e for e in entries if e.alias == self._active_alias), None)
            if active is not None:
                entries.remove(active)
                entries.insert(0, active)
        return entries

    def _client_for(self, entry: GeminiFreeKeyEntry):
        client = self._clients.get(entry.alias)
        if client is None:
            kwargs: dict[str, Any] = {"api_key": entry.value}
            if self.request_timeout_ms is not None:
                kwargs["http_options"] = types.HttpOptions(timeout=self.request_timeout_ms)
            client = genai.Client(**kwargs)
            self._clients[entry.alias] = client
        return client

    @property
    def active_alias(self) -> str:
        return str(self._active_alias or "")

    def active_client(self):
        entries = self._ordered_entries()
        if not entries:
            raise RuntimeError("All free Gemini .env project keys are unavailable; paid fallback is OFF.")
        entry = entries[0]
        self._active_alias = entry.alias
        return self._client_for(entry)

    @staticmethod
    def _safe_error(exc: Exception) -> str:
        text = str(exc)
        text = re.sub(r"([?&]key=)[^&\s]+", r"\1***", text, flags=re.I)
        return text[-1200:]

    @staticmethod
    def _is_transient_error(exc: Exception) -> bool:
        """High demand/transport failures must not poison a key for the whole run."""
        text = str(exc).casefold()
        return any(
            marker in text
            for marker in (
                "503",
                "unavailable",
                "high demand",
                "temporarily unavailable",
                "server disconnected",
                "connection reset",
                "connection aborted",
                "connection timed out",
                "read timed out",
                "timeout",
                "ssl",
                "unexpected_eof",
                "unexpected eof",
                "502",
                "504",
            )
        )

    @staticmethod
    def _is_key_fatal_error(exc: Exception) -> bool:
        """Only credentials/quota failures should poison a project key."""
        text = str(exc).casefold()
        return any(
            marker in text
            for marker in (
                "401",
                "unauthenticated",
                "api key not valid",
                "invalid api key",
                "403",
                "permission_denied",
                "permission denied",
                "429",
                "resource_exhausted",
                "resource exhausted",
                "quota",
            )
        )

    def call(
        self,
        operation: str,
        callback: Callable[[Any], T],
        *,
        max_transient_attempts: int | None = None,
        deadline_monotonic: float | None = None,
    ) -> T:
        failures: list[str] = []
        transient_attempts = 0
        for entry in self._ordered_entries():
            if deadline_monotonic is not None and time.monotonic() >= deadline_monotonic:
                failures.append("overall Gemini generation deadline reached")
                break
            try:
                result = callback(self._client_for(entry))
                if self._active_alias != entry.alias:
                    print(f"✅ Gemini FREE key active → {entry.alias} | operation={operation}")
                self._active_alias = entry.alias
                return result
            except Exception as exc:
                # Quota/auth/project errors stay disabled for this AIService run.
                # Capacity, transport, and model-specific request errors must not
                # poison a healthy project key before a fallback model can use it.
                transient = self._is_transient_error(exc)
                key_fatal = self._is_key_fatal_error(exc)
                if key_fatal:
                    self._disabled_for_run.add(entry.alias)
                safe = self._safe_error(exc)
                failures.append(f"{entry.alias}: {safe}")
                if key_fatal:
                    disposition = "credential/quota failure; disabled for this run"
                elif transient:
                    disposition = "transient; key kept for fallback"
                    transient_attempts += 1
                else:
                    disposition = "request/model failure; key kept for fallback"
                print(f"⚠️ Gemini FREE key unavailable → {entry.alias} | {disposition} | {safe}")
                if (
                    transient
                    and max_transient_attempts is not None
                    and transient_attempts >= max(1, int(max_transient_attempts))
                ):
                    print(
                        f"⏩ Gemini transient limit reached ({transient_attempts}); "
                        "stop key sweep so caller can switch model"
                    )
                    break

        raise RuntimeError(
            f"All free Gemini .env keys failed for {operation}; paid fallback is OFF. "
            + " | ".join(failures[-3:])
        )
