"""One profile identity for Page login, health checks, recovery and actual uploads."""
from pathlib import Path
import json

PROFILE_STORES = {"browser_sessions", "browser_profiles"}


def profile_store(value="browser_sessions"):
    value = str(value or "browser_sessions").strip()
    if value not in PROFILE_STORES:
        raise ValueError("Invalid Facebook profile store")
    return value


def profile_path(root, profile, store="browser_sessions"):
    store = profile_store(store)
    profile = str(profile or "").strip()
    if not profile or any(x in profile for x in ("/", "\\", "..", ":")):
        raise ValueError("Invalid Facebook profile name")
    base = (Path(root) / store).resolve()
    path = (base / profile).resolve()
    if path.parent != base:
        raise ValueError("Invalid Facebook profile path")
    return path


def page_store(root, profile, page_id):
    """Old Page entries keep browser_sessions; a selected Share login is explicit."""
    path = Path(root) / "config/tt_accounts.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return "browser_sessions"
    rows = (data.get("facebook_pages") or {}).values()
    matches = [row for row in rows if isinstance(row, dict)
               and str(row.get("profile") or "").strip() == str(profile).strip()
               and str(row.get("page_id") or "").strip() == str(page_id).strip()]
    stores = {profile_store(row.get("profile_store")) for row in matches}
    if len(stores) > 1:
        raise ValueError("Facebook Page has conflicting login profiles; edit its account selection")
    return next(iter(stores), "browser_sessions")
