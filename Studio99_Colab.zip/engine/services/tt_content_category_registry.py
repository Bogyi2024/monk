from __future__ import annotations

import copy
from typing import Any


# One registry for reusable editorial categories. Adding a future category does
# not require scattering source/output/processor defaults across the scheduler,
# API and UI. Existing legacy TT categories remain supported outside this list.
CONTENT_CATEGORY_REGISTRY: dict[str, dict[str, Any]] = {
    "movie_review": {
        "display_name": "Movie Review",
        "processor": "movie_review",
        "processor_kind": "builtin",
        "default_output": "video",
        "supported_outputs": ["video", "image_post"],
        # The current Movie Review generator writes and narrates in Burmese.
        # Do not expose a language switch that the worker cannot honour yet.
        "supported_languages": ["mm"],
        "supports_sources": True,
        "supports_automatic_discovery": True,
        "minimum_configured_sources": 0,
        "ensure_category": False,
    },
    "kpop_news": {
        "display_name": "K-pop News",
        "processor": "kpop_news",
        "processor_kind": "external_python",
        "default_output": "image_post",
        # The connected grounded-news worker currently emits image posts only.
        # Add video/carousel here only when those result contracts are real.
        "supported_outputs": ["image_post"],
        # External workers receive this value in the JSON payload and must
        # generate the selected editorial language.
        "supported_languages": ["mm", "en"],
        "supports_sources": True,
        "supports_automatic_discovery": True,
        "minimum_configured_sources": 2,
        "ensure_category": True,
        "runner_env": "TT_KPOP_NEWS_WORKER",
        "runner_candidates": ["../grounded_news/tt_bridge_runner.py"],
        "category_defaults": {
            "label": "K-pop News",
            "enabled": False,
            "daily_limit": 5,
            "production_mode": "fixed_daily",
            "facebook_page": "",
            "tiktok_account": "",
            "fb_share_account": "",
            "fb_share_accounts": [],
            "share_enabled": False,
            "schedule_policy": {
                "earliest_start": "09:00",
                "latest_finish": "22:30",
                "preferred_gap_minutes": 180,
                "minimum_gap_minutes": 120,
                "estimated_runtime_minutes": 20,
                "priority": 40,
                "prefer_preferred_windows": False,
                "preferred_windows_only": False,
                "preferred_windows": [],
            },
            "routes": {
                "default": {
                    "label": "K-pop News Main",
                    "enabled": False,
                    "content_type": "kpop_news",
                    "output_type": "image_post",
                    "language": "mm",
                    "genre_mode": "",
                    "fixed_genre": "",
                    "content_group": "kpop_main",
                    "daily_limit": 5,
                    "facebook_page": "",
                    "tiktok_account": "",
                    "fb_share_accounts": [],
                    "share_enabled": False,
                    "sources": [],
                    "source_urls": [],
                    "schedule_policy": {
                        "earliest_start": "09:00",
                        "latest_finish": "22:30",
                        "page_gap_minutes": 180,
                        "route_spacing_minutes": 120,
                        "estimated_runtime_minutes": 20,
                        "priority": 40,
                    },
                }
            },
        },
    },
    "football_news": {
        "display_name": "Football News",
        "processor": "football_news",
        "processor_kind": "external_python",
        "default_output": "image_post",
        "supported_outputs": ["image_post"],
        "supported_languages": ["mm", "en"],
        "supports_sources": True,
        "supports_automatic_discovery": True,
        "minimum_configured_sources": 2,
        "ensure_category": True,
        "runner_env": "TT_FOOTBALL_NEWS_WORKER",
        "runner_candidates": ["../grounded_news/tt_bridge_runner.py"],
        "category_defaults": {
            "label": "Football News",
            "enabled": False,
            "daily_limit": 5,
            "production_mode": "fixed_daily",
            "facebook_page": "",
            "tiktok_account": "",
            "fb_share_account": "",
            "fb_share_accounts": [],
            "share_enabled": False,
            "schedule_policy": {
                "earliest_start": "09:00",
                "latest_finish": "22:30",
                "preferred_gap_minutes": 180,
                "minimum_gap_minutes": 120,
                "estimated_runtime_minutes": 20,
                "priority": 40,
                "prefer_preferred_windows": False,
                "preferred_windows_only": False,
                "preferred_windows": [],
            },
            "routes": {
                "default": {
                    "label": "Football News Main",
                    "enabled": False,
                    "content_type": "football_news",
                    "output_type": "image_post",
                    "language": "mm",
                    "genre_mode": "",
                    "fixed_genre": "",
                    "content_group": "football_main",
                    "daily_limit": 5,
                    "facebook_page": "",
                    "tiktok_account": "",
                    "fb_share_accounts": [],
                    "share_enabled": False,
                    "sources": [],
                    "source_urls": [],
                    "schedule_policy": {
                        "earliest_start": "09:00",
                        "latest_finish": "22:30",
                        "page_gap_minutes": 180,
                        "route_spacing_minutes": 120,
                        "estimated_runtime_minutes": 20,
                        "priority": 40,
                    },
                }
            },
        },
    },
}


def content_category(key: str) -> dict[str, Any] | None:
    row = CONTENT_CATEGORY_REGISTRY.get(str(key or "").strip())
    return copy.deepcopy(row) if row else None


def registry_snapshot() -> dict[str, dict[str, Any]]:
    return copy.deepcopy(CONTENT_CATEGORY_REGISTRY)


def managed_category_defaults() -> dict[str, dict[str, Any]]:
    return {
        key: copy.deepcopy(row.get("category_defaults") or {})
        for key, row in CONTENT_CATEGORY_REGISTRY.items()
        if row.get("ensure_category") and row.get("category_defaults")
    }


def scheduler_category_keys() -> set[str]:
    return set(CONTENT_CATEGORY_REGISTRY)


# Studio99 Desktop (tools/sync_engine.py): the Posting list categories.
from studio99.posting_list import register as _studio99_register  # noqa: E402
_studio99_register(CONTENT_CATEGORY_REGISTRY)
