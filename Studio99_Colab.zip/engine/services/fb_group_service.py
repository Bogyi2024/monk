from __future__ import annotations

import asyncio
import json
import os
import re
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse, parse_qs, urlencode
from typing import Iterable

from playwright.async_api import async_playwright

try:
    from services.page_recovery import page_looks_blank, recover_blank_page
except ImportError:
    from page_recovery import page_looks_blank, recover_blank_page

try:
    from services.playwright_runtime import (
        install_playwright_target_closed_filter,
        settle_playwright_close_callbacks,
    )
except ImportError:
    from playwright_runtime import (
        install_playwright_target_closed_filter,
        settle_playwright_close_callbacks,
    )

try:
    from services.health_monitor import note_group_failure, note_login_lost
except ImportError:
    try:
        from health_monitor import note_group_failure, note_login_lost
    except ImportError:
        def note_group_failure(*args, **kwargs):
            return None
        def note_login_lost(*args, **kwargs):
            return None


def _project_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _accounts_config_path() -> Path:
    return _project_root() / os.getenv("FB_SHARE_ACCOUNTS_CONFIG", "config/fb_share_accounts.json")


def _proxy() -> dict:
    return None  # OS network / external VPN


def _registry_path() -> Path:
    path = _project_root() / os.getenv("FB_GROUP_SHARE_REGISTRY", "downloads/fb_group_share_registry.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _load_accounts_config() -> dict:
    path = _accounts_config_path()
    if not path.exists():
        return {"version": 1, "accounts": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("root must be object")
        data.setdefault("accounts", [])
        return data
    except Exception as exc:
        raise RuntimeError(f"FB share accounts config ဖတ်မရပါ: {path} ({exc})") from exc


def get_share_accounts(*, enabled_only: bool = True) -> dict[str, dict]:
    data = _load_accounts_config()
    result: dict[str, dict] = {}
    for raw in data.get("accounts", []):
        if not isinstance(raw, dict):
            continue
        name = str(raw.get("name", "")).strip()
        if not name:
            continue
        enabled = bool(raw.get("enabled", True))
        if enabled_only and not enabled:
            continue
        groups = []
        for value in raw.get("groups", []) or []:
            url = str(value).strip()
            if not url or "group_link_" in url:
                continue
            if url not in groups:
                groups.append(url)
        result[name] = {
            "name": name,
            "profile_folder": str(raw.get("profile_folder") or name).strip(),
            "enabled": enabled,
            "groups": groups,
            "note": str(raw.get("note", "")).strip(),
        }
    return result


SHARE_GROUPS_MAP = {name: cfg["groups"] for name, cfg in get_share_accounts(enabled_only=False).items()}


def _account_cfg(name: str, *, enabled_only: bool = False) -> dict | None:
    return get_share_accounts(enabled_only=enabled_only).get(name)


def _load_registry() -> dict:
    path = _registry_path()
    if not path.exists():
        return {"posts": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError
        data.setdefault("posts", {})
        return data
    except Exception:
        return {"posts": {}}


def _save_registry(data: dict) -> None:
    path = _registry_path()
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _share_key(profile_name: str, group_url: str) -> str:
    return f"{profile_name}|{group_url.rstrip('/')}"


def _already_shared(post_link: str, profile_name: str, group_url: str) -> bool:
    data = _load_registry()
    post = data.get("posts", {}).get(post_link, {})
    return _share_key(profile_name, group_url) in post.get("shared", {})


def _mark_shared(post_link: str, profile_name: str, group_url: str) -> None:
    data = _load_registry()
    post = data.setdefault("posts", {}).setdefault(
        post_link, {"shared": {}, "created_at": datetime.now().isoformat()}
    )
    post.setdefault("shared", {})[_share_key(profile_name, group_url)] = {
        "profile": profile_name,
        "group_url": group_url,
        "shared_at": datetime.now().isoformat(),
    }
    post["updated_at"] = datetime.now().isoformat()
    _save_registry(data)


def _register_share_plan(post_link: str, selected_accounts: list[str], share_text: str = "") -> None:
    active = get_share_accounts(enabled_only=True)
    data = _load_registry()
    post = data.setdefault("posts", {}).setdefault(
        post_link, {"shared": {}, "created_at": datetime.now().isoformat()}
    )
    intended = post.setdefault("intended", {})
    for name in selected_accounts:
        cfg = active.get(name)
        if not cfg:
            continue
        intended[name] = list(cfg["groups"])
    if str(share_text or "").strip():
        post["share_text"] = str(share_text).strip()
    post["updated_at"] = datetime.now().isoformat()
    _save_registry(data)


def _current_required_targets(post_link: str) -> list[str]:
    data = _load_registry()
    post = data.get("posts", {}).get(post_link, {})
    intended = post.get("intended", {}) or {}
    active = get_share_accounts(enabled_only=True)
    targets: list[str] = []
    for name, old_urls in intended.items():
        cfg = active.get(name)
        if not cfg:
            continue
        current_urls = set(cfg["groups"])
        for url in old_urls or []:
            if url in current_urls:
                targets.append(_share_key(name, url))
    return targets


def _post_is_complete(post_link: str) -> bool:
    data = _load_registry()
    post = data.get("posts", {}).get(post_link, {})
    shared = post.get("shared", {}) or {}
    targets = _current_required_targets(post_link)
    return all(key in shared for key in targets)


async def init_fb_profile(profile_folder_name: str) -> None:
    cfg = _account_cfg(profile_folder_name, enabled_only=False)
    folder = cfg["profile_folder"] if cfg else profile_folder_name
    profile_path = _project_root() / "browser_profiles" / folder
    profile_path.mkdir(parents=True, exist_ok=True)
    print(f"👉 Group-share profile: {profile_path}")

    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_path),
            headless=False,
            args=["--disable-notifications", "--disable-blink-features=AutomationControlled"],
            proxy=_proxy(),
        )
        page = context.pages[0] if context.pages else await context.new_page()
        home_url = "https://www.facebook.com/"
        await page.goto(home_url, timeout=90_000, wait_until="domcontentloaded")
        await recover_blank_page(page, target_url=home_url, label=f"{profile_folder_name} Facebook login", settle_ms=6000, max_reloads=2)
        print(f"✨ {profile_folder_name} Facebook login ကို browser ထဲဝင်ထားပါ။")
        print("Browser ကိုပိတ်ချင်တဲ့အချိန် Ctrl+C နှိပ်နိုင်ပါတယ်။ Auto close = 5 minutes")
        await page.wait_for_timeout(300_000)
        await context.close()


async def _find_post_box(page):
    selectors = [
        'div[role="button"]:has-text("Write something")',
        'div[role="button"]:has-text("Create a public post")',
        "div[role=\"button\"]:has-text(\"What's on your mind\")",
        '[aria-label*="Write something"]',
        '[aria-label*="Create a public post"]',
    ]
    for selector in selectors:
        loc = page.locator(selector).first
        try:
            if await loc.count() and await loc.is_visible():
                return loc
        except Exception:
            pass
    return None


async def _visible_dialog(page):
    """Return the visible Create-post dialog only; never fall back to the page body."""
    dialogs = page.locator('div[role="dialog"]')
    try:
        count = await dialogs.count()
    except Exception:
        return None

    # Prefer a dialog that actually contains the Create post heading/text.
    for idx in range(count - 1, -1, -1):
        loc = dialogs.nth(idx)
        try:
            if not await loc.is_visible():
                continue
            txt = (await loc.inner_text()).strip().lower()
            if 'create post' in txt or 'create a public post' in txt:
                return loc
        except Exception:
            pass

    # Last visible dialog is still safer than touching the page background.
    for idx in range(count - 1, -1, -1):
        loc = dialogs.nth(idx)
        try:
            if await loc.is_visible():
                return loc
        except Exception:
            pass
    return None


async def _wait_for_create_post_dialog(page, timeout_ms: int = 40_000):
    """Slow-network friendly wait for Facebook's Create Post modal."""
    elapsed = 0
    while elapsed < timeout_ms:
        dialog = await _visible_dialog(page)
        if dialog is not None:
            try:
                if await dialog.is_visible():
                    return dialog
            except Exception:
                pass

        if elapsed and elapsed % 5_000 < 350:
            print(f"⏳ Create post modal စောင့်နေပါတယ်... {elapsed // 1000}s")

        await page.wait_for_timeout(350)
        elapsed += 350
    return None


async def _find_composer(dialog):
    """Find composer strictly INSIDE the modal dialog."""
    if dialog is None:
        return None
    selectors = [
        'div[role="textbox"][contenteditable="true"]',
        'div[contenteditable="true"][data-lexical-editor="true"]',
        'div[contenteditable="true"][spellcheck="true"]',
        'div[contenteditable="true"]',
    ]
    for selector in selectors:
        try:
            candidates = dialog.locator(selector)
            count = await candidates.count()
        except Exception:
            continue
        for idx in range(count):
            loc = candidates.nth(idx)
            try:
                if not await loc.is_visible():
                    continue
                box = await loc.bounding_box()
                if box and box.get('width', 0) > 180 and box.get('height', 0) > 20:
                    return loc
            except Exception:
                pass
    return None


async def _wait_for_post_box(page, timeout_ms: int = 40_000):
    """Wait for the group page composer entry point instead of checking only once."""
    elapsed = 0
    while elapsed < timeout_ms:
        post_box = await _find_post_box(page)
        if post_box is not None:
            return post_box

        if elapsed and elapsed % 5_000 == 0:
            print(f"⏳ Group post box စောင့်နေပါတယ်... {elapsed // 1000}s")

        await page.wait_for_timeout(500)
        elapsed += 500
    return None


async def _wait_for_composer(page, dialog, timeout_ms: int = 45_000):
    """Wait until the visible modal's Lexical/contenteditable textbox is hydrated."""
    elapsed = 0
    while elapsed < timeout_ms:
        try:
            if not await dialog.is_visible():
                return None
        except Exception:
            return None

        composer = await _find_composer(dialog)
        if composer is not None:
            return composer

        if elapsed and elapsed % 5_000 == 0:
            print(f"⏳ Modal textbox ပွင့်လာဖို့ စောင့်နေပါတယ်... {elapsed // 1000}s")

        await page.wait_for_timeout(500)
        elapsed += 500

    return None


async def _composer_text(composer) -> str:
    try:
        return (await composer.inner_text()).strip()
    except Exception:
        try:
            return (await composer.text_content() or '').strip()
        except Exception:
            return ''


async def _set_composer_text(page, composer, text: str, *, verify_fragment: str | None = None) -> bool:
    text = str(text or '')
    fragment = str(verify_fragment or text).strip()

    # Strictly focus the modal composer before every insertion attempt.
    try:
        await composer.scroll_into_view_if_needed(timeout=5_000)
    except Exception:
        pass

    # 1) Playwright fill on the actual dialog contenteditable.
    try:
        await composer.click(timeout=10_000, force=True)
        await composer.focus()
        await composer.fill(text, timeout=15_000)
        await page.wait_for_timeout(650)
        current = await _composer_text(composer)
        if (not fragment) or fragment in current:
            return True
    except Exception:
        pass

    # 2) Focus + Ctrl+A + insert_text (Myanmar-safe, no key-by-key typing).
    try:
        await composer.click(timeout=10_000, force=True)
        await composer.focus()
        await page.keyboard.press('Control+A')
        await page.keyboard.insert_text(text)
        await page.wait_for_timeout(800)
        current = await _composer_text(composer)
        if (not fragment) or fragment in current:
            return True
    except Exception:
        pass

    # 3) Lexical/React fallback, still on the exact modal node.
    try:
        await composer.evaluate(
            """(el, value) => {
                el.focus();
                const sel = window.getSelection();
                const range = document.createRange();
                range.selectNodeContents(el);
                sel.removeAllRanges();
                sel.addRange(range);
                document.execCommand('insertText', false, value);
                el.dispatchEvent(new InputEvent('input', {
                    bubbles: true,
                    inputType: 'insertText',
                    data: value
                }));
            }""",
            text,
        )
        await page.wait_for_timeout(900)
        current = await _composer_text(composer)
        if (not fragment) or fragment in current:
            return True
    except Exception:
        pass

    return False



async def _dismiss_hashtag_suggestions(page, dialog, composer=None) -> bool:
    """Dismiss a visible hashtag/autocomplete popup without changing the locked dialog.

    Keep the old stable composer ownership model: this helper only blurs/dismisses
    floating UI and NEVER re-selects/re-scores another modal or editor.
    """
    if dialog is None:
        return False
    try:
        if composer is not None:
            await composer.evaluate("el => el.blur()")
    except Exception:
        pass
    try:
        await page.evaluate("() => document.activeElement && document.activeElement.blur && document.activeElement.blur()")
    except Exception:
        pass
    await page.wait_for_timeout(180)

    popup_visible = False
    for sel in (
        '[role="listbox"]:visible',
        '[role="option"]:visible',
        '[aria-label*="suggest" i]:visible',
        '[data-visualcompletion="ignore-dynamic"] [role="option"]:visible',
    ):
        try:
            if await page.locator(sel).count() > 0:
                popup_visible = True
                break
        except Exception:
            pass
    if popup_visible:
        try:
            await page.keyboard.press('Escape')
            await page.wait_for_timeout(280)
        except Exception:
            pass
    return popup_visible


async def _click_post_safely(page, dialog, post_button, composer=None) -> None:
    dismissed = await _dismiss_hashtag_suggestions(page, dialog, composer)
    if dismissed:
        print("🧹 Facebook hashtag suggestion popup dismissed before Post")
    try:
        await post_button.click(timeout=12_000)
        return
    except Exception as exc:
        msg = str(exc).lower()
        if 'intercepts pointer events' not in msg and 'subtree intercepts pointer events' not in msg:
            raise
    await _dismiss_hashtag_suggestions(page, dialog, composer)
    try:
        await post_button.click(timeout=8_000)
        return
    except Exception as exc:
        msg = str(exc).lower()
        if 'intercepts pointer events' not in msg and 'subtree intercepts pointer events' not in msg:
            raise
    await post_button.evaluate("el => el.click()")
    print("✅ Facebook Post DOM-click fallback used after suggestion overlay")


def _normalize_share_permalink(value: str) -> str:
    """Normalize Reel/video and normal Page-post permalinks for group sharing."""
    raw = str(value or '').strip()
    if not raw:
        return ''
    if raw.startswith('/'):
        raw = 'https://www.facebook.com' + raw
    try:
        u = urlparse(raw)
    except Exception:
        return ''
    host = (u.netloc or '').lower()
    if host.endswith('fb.watch'):
        return f"https://fb.watch{u.path.rstrip('/')}" if u.path else ''
    if not host.endswith('facebook.com'):
        return ''
    path = (u.path or '').rstrip('/')
    if re.search(r'/reel/[^/]+$', path, re.I):
        return 'https://www.facebook.com' + path
    if re.search(r'/videos/[^/]+$', path, re.I):
        return 'https://www.facebook.com' + path
    if re.search(r'/posts/[^/]+$', path, re.I):
        return 'https://www.facebook.com' + path
    q = parse_qs(u.query or '')
    if path.endswith('/story.php') or path == '/story.php':
        story_fbid = (q.get('story_fbid') or [''])[0]
        owner_id = (q.get('id') or [''])[0]
        if story_fbid:
            query = {'story_fbid': story_fbid}
            if owner_id:
                query['id'] = owner_id
            return 'https://www.facebook.com/story.php?' + urlencode(query)
    if path.endswith('/photo.php') or path == '/photo.php':
        fbid = (q.get('fbid') or [''])[0]
        if fbid:
            return 'https://www.facebook.com/photo.php?' + urlencode({'fbid': fbid})
    return ''


def _share_verify_fragment(post_link: str) -> str:
    link = str(post_link or '')
    for frag in ('/reel/', '/videos/', '/posts/', 'story_fbid=', 'photo.php', 'fb.watch'):
        if frag in link:
            return frag
    return 'facebook.com'


async def _preview_signature(dialog) -> tuple[int, int, int, int]:
    """Preview signature scoped to the active Create-post modal only."""
    if dialog is None:
        return (0, 0, 0, 0)
    try:
        reel_anchors = await dialog.locator('a[href*="/reel/"], a[href*="/videos/"]').count()
    except Exception:
        reel_anchors = 0
    try:
        media = await dialog.locator('video').count()
    except Exception:
        media = 0
    try:
        preview_images = await dialog.locator(
            'img[src*="scontent"], img[data-imgperflogname], [data-visualcompletion="media-vc-image"]'
        ).count()
    except Exception:
        preview_images = 0
    try:
        links = await dialog.locator('a[role="link"], div[role="link"]').count()
    except Exception:
        links = 0
    return reel_anchors, media, preview_images, links


async def _wait_for_link_preview(page, dialog, baseline: tuple[int, int, int, int], timeout_ms: int = 45_000) -> bool:
    elapsed = 0
    stable = 0
    while elapsed < timeout_ms:
        try:
            if not await dialog.is_visible():
                return False
        except Exception:
            return False
        now = await _preview_signature(dialog)
        grew = any(now[i] > baseline[i] for i in range(len(baseline)))
        if grew:
            stable += 1
            if stable >= 2:
                return True
        else:
            stable = 0
        await page.wait_for_timeout(1_000)
        elapsed += 1_000
    return False


async def _find_post_button(dialog):
    """Find Post strictly inside the active modal."""
    if dialog is None:
        return None
    candidates = [
        dialog.get_by_role('button', name='Post', exact=True).last,
        dialog.locator('div[aria-label="Post"]').last,
        dialog.locator('div[role="button"][aria-label="Post"]').last,
    ]
    for loc in candidates:
        try:
            if await loc.count() and await loc.is_visible():
                return loc
        except Exception:
            pass
    return None


async def _wait_for_post_button(page, dialog, timeout_ms: int = 35_000):
    """Wait for Post button because Facebook can render it after the dialog/textbox."""
    elapsed = 0
    while elapsed < timeout_ms:
        button = await _find_post_button(dialog)
        if button is not None:
            return button

        if elapsed and elapsed % 5_000 == 0:
            print(f"⏳ Modal Post button စောင့်နေပါတယ်... {elapsed // 1000}s")

        await page.wait_for_timeout(500)
        elapsed += 500
    return None


async def _wait_dialog_close_or_posted(page, dialog, timeout_ms: int = 40_000) -> bool:
    """Do not mark shared until the modal closes or a post-success state appears."""
    elapsed = 0
    while elapsed < timeout_ms:
        try:
            if not await dialog.is_visible():
                return True
        except Exception:
            return True
        # Some groups keep a short 'Posting' state before closing.
        try:
            body = (await dialog.inner_text()).lower()
            if 'posting' in body:
                pass
        except Exception:
            pass
        await page.wait_for_timeout(1_000)
        elapsed += 1_000
    return False


async def share_to_groups(
    profile_folder_name: str,
    group_urls: Iterable[str] | None,
    post_link: str,
    *,
    share_text: str = "",
    headless: bool = False,
    delay_between_groups_seconds: float = 20.0,
) -> dict:
    install_playwright_target_closed_filter()
    post_link = _normalize_share_permalink(post_link) or str(post_link or '').strip()
    verify_fragment = _share_verify_fragment(post_link)
    cfg = _account_cfg(profile_folder_name, enabled_only=True)
    if not cfg:
        print(f"⏭️ {profile_folder_name} disabled/removed — skip")
        return {"profile": profile_folder_name, "shared": 0, "failed": 0, "skipped": 0}

    profile_path = _project_root() / "browser_profiles" / cfg["profile_folder"]
    if not profile_path.exists():
        print(f"⚠️ {profile_folder_name} profile folder မရှိပါ — skip ({profile_path})")
        return {"profile": profile_folder_name, "shared": 0, "failed": 0, "skipped": 0}

    urls = list(group_urls) if group_urls is not None else list(cfg["groups"])
    urls = [str(u).strip() for u in urls if str(u).strip() and "group_link_" not in str(u)]
    current = set(cfg["groups"])
    urls = [u for u in urls if u in current]
    urls = list(dict.fromkeys(urls))
    if not urls:
        print(f"⚠️ {profile_folder_name} မှာ active group URL မရှိပါ — skip")
        return {"profile": profile_folder_name, "shared": 0, "failed": 0, "skipped": 0}

    share_text = str(share_text or "").strip()
    print(f"🚀 {profile_folder_name} → group auto-share start ({len(urls)} groups)")
    result = {"profile": profile_folder_name, "shared": 0, "failed": 0, "skipped": 0, "failures": []}

    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_path),
            headless=headless,
            args=["--disable-notifications", "--disable-blink-features=AutomationControlled"],
            proxy=_proxy(),
        )
        page = context.pages[0] if context.pages else await context.new_page()

        try:
            await page.goto("https://www.facebook.com/", timeout=90_000, wait_until="domcontentloaded")
        except Exception:
            pass
        await page.wait_for_timeout(5_000)

        try:
            if "login" in page.url.lower() or await page.locator("input[name='email']").count() > 0:
                print(f"❌ {profile_folder_name} login ပြုတ်နေပါတယ် — manager နဲ့ re-login လုပ်ပါ")
                note_login_lost(profile_folder_name)
                await context.close()
                return result
        except Exception:
            pass

        for idx, group_url in enumerate(urls, 1):
            if _already_shared(post_link, profile_folder_name, group_url):
                print(f"⏭️ [{profile_folder_name}] Group {idx} already shared — skip duplicate")
                result["skipped"] += 1
                continue

            try:
                print(f"🌐 [{profile_folder_name}] Group {idx}: {group_url}")
                loaded = False
                for attempt in range(3):
                    try:
                        await page.goto(group_url, timeout=120_000, wait_until="domcontentloaded")
                        loaded = True
                        break
                    except Exception:
                        if attempt < 2:
                            print(f"⏳ Group page load retry {attempt + 1}/3...")
                            await page.wait_for_timeout(5_000)

                if not loaded:
                    raise RuntimeError("group page load failed after 3 tries")

                # Myanmar/VPN network can occasionally land on a pure white/black blank page.
                # Recover only BEFORE opening the composer so no typed/post state can be lost.
                healthy = await recover_blank_page(
                    page, target_url=group_url, label=f"[{profile_folder_name}] Group {idx}",
                    settle_ms=6000, max_reloads=2, navigation_timeout_ms=120000,
                )
                if not healthy:
                    raise RuntimeError("group page stayed white/black blank after auto reload")

                post_box = await _wait_for_post_box(page, timeout_ms=40_000)
                if post_box is None:
                    # One last blank check. If the page became blank after initial hydration, reload
                    # and retry the post-box wait once. Do NOT do this after modal/text entry begins.
                    if await page_looks_blank(page):
                        recovered = await recover_blank_page(
                            page, target_url=group_url, label=f"[{profile_folder_name}] Group {idx} late blank",
                            settle_ms=4000, max_reloads=1, navigation_timeout_ms=120000,
                        )
                        if recovered:
                            post_box = await _wait_for_post_box(page, timeout_ms=40_000)
                if post_box is None:
                    raise RuntimeError(
                        "group post box not found after wait/reload / posting may be disabled"
                    )

                await post_box.click(timeout=30_000)

                # IMPORTANT: lock onto the modal. From here on, never search the page background.
                dialog = await _wait_for_create_post_dialog(page, timeout_ms=40_000)
                if dialog is None:
                    raise RuntimeError("Create post dialog did not open within 40s")

                # The modal can already be visible while the textbox is still hydrating.
                composer = await _wait_for_composer(page, dialog, timeout_ms=45_000)
                if composer is None:
                    raise RuntimeError("modal composer textbox not found after 45s")

                baseline = await _preview_signature(dialog)
                if not await _set_composer_text(page, composer, post_link, verify_fragment=verify_fragment):
                    raise RuntimeError("modal composer opened but permalink insertion verification failed")
                print("🔗 Facebook permalink MODAL textbox ထဲတကယ်ဝင်ပါပြီ — preview စောင့်နေပါတယ်...")

                preview_ready = await _wait_for_link_preview(page, dialog, baseline, timeout_ms=45_000)

                if preview_ready and share_text:
                    print("✅ Link preview ကို modal အတွင်းတွေ့ပါပြီ။ Share text ပြောင်းနေပါတယ်...")
                    before_replace = await _preview_signature(dialog)

                    # Facebook may replace the Lexical DOM node after preview attachment.
                    fresh_composer = await _wait_for_composer(page, dialog, timeout_ms=15_000)
                    if fresh_composer is not None:
                        composer = fresh_composer

                    if await _set_composer_text(page, composer, share_text, verify_fragment=share_text[:24]):
                        await page.wait_for_timeout(1_200)
                        after_replace = await _preview_signature(dialog)
                        # Preview must still exist after removing visible URL text.
                        preview_still_there = any(after_replace[i] >= before_replace[i] and after_replace[i] > baseline[i] for i in range(len(baseline)))
                        if preview_still_there:
                            print("📝 Facebook preview မပျက်ဘဲ URL စာသားကို ဇာတ်လမ်း share text နဲ့အစားထိုးပြီးပါပြီ။")
                        else:
                            print("⚠️ Caption အစားထိုးပြီး preview ပျောက်သွားလို့ share text + permalink ကို modal ထဲပြန်ထားပါမယ်။")
                            if not await _set_composer_text(page, composer, f"{share_text}\n\n{post_link}", verify_fragment=verify_fragment):
                                raise RuntimeError("preview disappeared and modal fallback insertion failed")
                    else:
                        print("⚠️ Share text replacement verify မအောင်လို့ modal ထဲ share text + permalink ပြန်ထားပါမယ်။")
                        if not await _set_composer_text(page, composer, f"{share_text}\n\n{post_link}", verify_fragment=verify_fragment):
                            raise RuntimeError("modal caption + permalink fallback insertion failed")
                elif not preview_ready and share_text:
                    print("⚠️ Modal ထဲ Link preview 45s အတွင်းမတွေ့သေးပါ — share text + permalink fallback သုံးပါမယ်။")
                    if not await _set_composer_text(page, composer, f"{share_text}\n\n{post_link}", verify_fragment=verify_fragment):
                        raise RuntimeError("modal caption + permalink fallback insertion failed")

                await page.wait_for_timeout(1_500)

                post_button = await _wait_for_post_button(page, dialog, timeout_ms=35_000)
                if post_button is None:
                    raise RuntimeError("modal Post button not found after 35s")

                enabled = False
                for _ in range(40):
                    try:
                        if await post_button.is_enabled():
                            enabled = True
                            break
                    except Exception:
                        # React may have replaced the button; reacquire it.
                        post_button = await _wait_for_post_button(page, dialog, timeout_ms=5_000)
                        if post_button is None:
                            break
                    await page.wait_for_timeout(1_000)

                if not enabled:
                    raise RuntimeError("Post button stayed disabled after 40s")

                await _click_post_safely(page, dialog, post_button, composer)

                if not await _wait_dialog_close_or_posted(page, dialog, timeout_ms=40_000):
                    raise RuntimeError("Post clicked but Create-post dialog did not close/confirm")
                await page.wait_for_timeout(2_000)
                _mark_shared(post_link, profile_folder_name, group_url)
                result["shared"] += 1
                print(f"🎉 [{profile_folder_name}] Group {idx} shared")

            except Exception as exc:
                result["failed"] += 1
                failure={"profile":profile_folder_name,"group_index":idx,"group_url":group_url,"error":str(exc)}
                result["failures"].append(failure)
                note_group_failure(profile_folder_name, idx, group_url, str(exc))
                print(f"❌ [{profile_folder_name}] Group {idx} share failed: {exc}")

            if idx < len(urls):
                await page.wait_for_timeout(int(max(0.0, delay_between_groups_seconds) * 1000))

        try:
            await context.close()
        except Exception:
            # A manually closed Chromium window is already clean. Awaited action
            # failures inside the group loop remain visible and counted above.
            pass
        await settle_playwright_close_callbacks()
    return result


async def auto_share_all_accounts(
    post_link: str,
    *,
    account_names: list[str] | None = None,
    share_text: str = "",
    headless: bool = False,
    delay_between_groups_seconds: float = 20.0,
    delay_between_accounts_seconds: float = 120.0,
) -> dict:
    original_link = str(post_link or '')
    post_link = _normalize_share_permalink(original_link)
    if not post_link:
        raise ValueError(f"Facebook reel/post permalink မဟုတ်ပါ: {original_link}")

    active = get_share_accounts(enabled_only=True)
    selected = list(active.keys()) if account_names is None else [n for n in account_names if n in active]
    _register_share_plan(post_link, selected, share_text=share_text)
    summary = {"post_link": post_link, "accounts": {}, "shared": 0, "failed": 0, "skipped": 0, "failures": []}

    for index, name in enumerate(selected):
        cfg = active[name]
        res = await share_to_groups(
            name,
            cfg["groups"],
            post_link,
            share_text=share_text,
            headless=headless,
            delay_between_groups_seconds=delay_between_groups_seconds,
        )
        summary["accounts"][name] = res
        summary["shared"] += res["shared"]
        summary["failed"] += res["failed"]
        summary["skipped"] += res["skipped"]
        summary["failures"].extend(res.get("failures", []))
        if index < len(selected) - 1:
            await asyncio.sleep(max(0.0, delay_between_accounts_seconds))

    print(f"🎊 Group share finished: shared={summary['shared']} skipped={summary['skipped']} failed={summary['failed']}")
    return summary


async def retry_incomplete_group_shares(
    *,
    account_names: list[str] | None = None,
    headless: bool = False,
    delay_between_groups_seconds: float = 20.0,
    delay_between_accounts_seconds: float = 120.0,
    limit_posts: int = 3,
) -> list[dict]:
    data = _load_registry()
    active = get_share_accounts(enabled_only=True)
    posts = list(data.get("posts", {}).items())
    pending: list[tuple[str, list[str], str]] = []

    for post_link, info in reversed(posts):
        intended = info.get("intended", {}) or {}
        if not intended or _post_is_complete(post_link):
            continue
        accounts = [name for name in intended.keys() if name in active]
        if account_names is not None:
            allowed = set(account_names)
            accounts = [name for name in accounts if name in allowed]
        if not accounts:
            continue
        share_text = str(info.get("share_text") or "").strip()
        pending.append((post_link, accounts, share_text))
        if len(pending) >= max(1, int(limit_posts)):
            break

    results = []
    for post_link, accounts, share_text in pending:
        print(f"♻️ Pending group-share retry: {post_link}")
        results.append(await auto_share_all_accounts(
            post_link,
            account_names=accounts,
            share_text=share_text,
            headless=headless,
            delay_between_groups_seconds=delay_between_groups_seconds,
            delay_between_accounts_seconds=delay_between_accounts_seconds,
        ))
    return results
