from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class TTHealthLogService:
    """Read-only health/log view for the localhost dashboard.

    The Master log is the canonical live terminal mirror. Existing Recap health
    artifacts are discovered read-only so older health writers keep working.
    """

    HEALTH_GLOBS = (
        "logs/*health*.json",
        "logs/*health*.jsonl",
        "logs/*cycle*.json",
        "logs/*cycle*.jsonl",
        "state/*health*.json",
        "state/*health*.jsonl",
        "downloads/*health*.json",
        "downloads/*health*.jsonl",
        "downloads/health/**/*.json",
        "downloads/health/**/*.jsonl",
    )

    def __init__(self, project_root: str | Path = "."):
        self.root = Path(project_root).resolve()
        self.log_path = self.root / "logs" / "tt_master.log"

    @staticmethod
    def _tail_text(path: Path, max_bytes: int = 140_000) -> str:
        if not path.exists() or not path.is_file():
            return ""
        try:
            size = path.stat().st_size
            with path.open("rb") as f:
                if size > max_bytes:
                    f.seek(size - max_bytes)
                    f.readline()  # discard partial first line
                raw = f.read()
            return raw.decode("utf-8", errors="replace")
        except Exception:
            return ""

    def master_tail(self, lines: int = 320) -> list[str]:
        lines = max(30, min(int(lines or 320), 1200))
        text = self._tail_text(self.log_path)
        return text.splitlines()[-lines:]

    def discovered_health(self) -> list[dict[str, Any]]:
        seen: set[Path] = set()
        found: list[Path] = []
        for pat in self.HEALTH_GLOBS:
            for p in self.root.glob(pat):
                try:
                    rp = p.resolve()
                except Exception:
                    continue
                if rp in seen or not p.is_file():
                    continue
                seen.add(rp); found.append(p)
        found.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
        out: list[dict[str, Any]] = []
        for p in found[:8]:
            rel = str(p.relative_to(self.root)).replace('\\','/')
            raw = self._tail_text(p, max_bytes=24_000)
            preview: Any = raw[-7000:]
            if p.suffix.lower() == '.json':
                try:
                    preview = json.loads(raw)
                except Exception:
                    pass
            out.append({
                "path": rel,
                "modified": p.stat().st_mtime,
                "preview": preview,
            })
        return out

    def latest_recap_cycle(self) -> dict[str, Any] | None:
        root = self.root / "downloads" / "health"
        if not root.exists():
            return None
        files = [p for p in root.glob("**/cycle_*.json") if p.is_file()]
        if not files:
            return None
        files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        p = files[0]
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                return None
            stages = data.get("stages") or []
            stage_seconds: dict[str, float] = {}
            for item in stages:
                if not isinstance(item, dict):
                    continue
                name = str(item.get("stage") or item.get("name") or "").upper()
                dur = item.get("duration_s")
                if name and isinstance(dur, (int, float)):
                    stage_seconds[name] = stage_seconds.get(name, 0.0) + float(dur)
            return {
                "path": str(p.relative_to(self.root)).replace('\\','/'),
                "cycle_no": data.get("cycle_no"),
                "started_at": data.get("started_at", ""),
                "finished_at": data.get("finished_at", ""),
                "duration_s": data.get("duration_s", 0),
                "summary": data.get("summary", ""),
                "cycle_error": data.get("cycle_error", ""),
                "group_fail_count": len(data.get("group_failures") or []),
                "blank_reload_count": len(data.get("blank_reloads") or []),
                "login_lost_count": len(data.get("login_lost") or []),
                "stage_seconds": stage_seconds,
            }
        except Exception:
            return None

    def snapshot(self, daily_state: dict[str, Any], capabilities: dict[str, Any]) -> dict[str, Any]:
        cats=[]
        current=(daily_state.get('current_job') or {}).get('category','')
        for key,row in (daily_state.get('categories') or {}).items():
            normal=int(row.get('normal_target') or 0)
            raw=row.get('target_override')
            target=normal if raw in (None,'','null') else int(raw)
            done=int(row.get('already_posted') or 0)
            left=max(0,target-done)
            cap=capabilities.get(key) or {}
            if key==current:
                status='RUNNING'
            elif not row.get('run_today'):
                status='PAUSED'
            elif row.get('last_error'):
                status='ERROR'
            elif left<=0:
                status='DONE'
            elif row.get('last_finished_at'):
                status='WAITING'
            else:
                status='READY'
            samples=[float(x) for x in (row.get('runtime_samples_seconds') or []) if isinstance(x,(int,float))]
            avg=(sum(samples)/len(samples)/60.0) if samples else None
            cats.append({
                'category':key,
                'status':status,
                'live':bool(cap.get('live')),
                'done':done,
                'target':target,
                'left':left,
                'last_started_at':row.get('last_started_at',''),
                'last_finished_at':row.get('last_finished_at',''),
                'last_error':row.get('last_error',''),
                'avg_runtime_minutes':round(avg,1) if avg is not None else None,
            })
        return {
            'ok':True,
            'armed':bool(daily_state.get('armed')),
            'current_job':daily_state.get('current_job'),
            'categories':cats,
            'events':list(daily_state.get('events') or [])[-40:],
            'master_log_path':str(self.log_path.relative_to(self.root)).replace('\\','/'),
            'master_log':self.master_tail(),
            'health_sources':self.discovered_health(),
            'recap_health_latest':self.latest_recap_cycle(),
        }
