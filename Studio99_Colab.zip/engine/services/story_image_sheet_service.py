from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Iterable, Sequence

from PIL import Image, ImageOps


class StoryImageSheetService:
    """Build and split deterministic 2x2 story-image sheets.

    The generator receives four ordered scene descriptions.  The saved sheet is
    always split in reading order: top-left, top-right, bottom-left, bottom-right.
    Keeping the sheet plus a manifest makes interrupted paid generations resumable;
    missing scene crops can be recreated locally without another API request.
    """

    PANEL_NAMES = ("top-left", "top-right", "bottom-left", "bottom-right")
    PANEL_COUNT = 4

    @staticmethod
    def groups(values: Sequence, size: int = PANEL_COUNT) -> list[list]:
        if size <= 0:
            raise ValueError("sheet group size must be positive")
        return [list(values[i:i + size]) for i in range(0, len(values), size)]

    @classmethod
    def _concise_scene_prompt(cls, value: str) -> str:
        text = re.sub(r"\s+", " ", str(value or "")).strip()
        text = re.sub(r"\b(?:No text|no baked-in text)\.?\s*$", "", text, flags=re.I).strip()
        # Story Motion repeats a long style lock at the beginning of every scene.
        # The sheet already has one global style lock; repeating it four times made
        # FLUX interpret nested layout instructions as extra comic panels.
        first, sep, remainder = text.partition('.')
        if sep and remainder.strip() and re.search(
            r"\b(?:9:16|cinematic|stylized|comic|cel-shaded|lighting)\b",
            first,
            flags=re.I,
        ):
            text = remainder.strip()
        return text

    @classmethod
    def build_prompt(
        cls,
        *,
        scene_prompts: Sequence[str],
        character_bible: str = "",
        global_style: str = "",
    ) -> str:
        if not 1 <= len(scene_prompts) <= cls.PANEL_COUNT:
            raise ValueError("a 2x2 sheet requires between one and four scene prompts")

        prompts = [cls._concise_scene_prompt(x) for x in scene_prompts]
        if any(not x for x in prompts):
            raise ValueError("sheet scene prompts cannot be empty")

        # A final unused cell is intentional for a 7-scene Drama batch.  It is never
        # exported; asking for a quiet continuation keeps the model from merging the
        # third panel across the entire bottom row.
        while len(prompts) < cls.PANEL_COUNT:
            prompts.append(
                "A quiet atmospheric continuation of the same location and visual style, "
                "with no new story action and no important character; filler panel only."
            )

        assignments = "\n".join(
            f"PANEL {i + 1} ({name}): {prompt}"
            for i, (name, prompt) in enumerate(zip(cls.PANEL_NAMES, prompts))
        )
        return (
            "Create ONE four-panel storyboard page. The page contains EXACTLY FOUR panels total.\n"
            "Draw exactly ONE straight vertical divider at the center and exactly ONE straight "
            "horizontal divider at the center. These two lines form a strict 2-by-2 grid: "
            "top-left panel 1, top-right panel 2, bottom-left panel 3, bottom-right panel 4.\n"
            "ABSOLUTELY NO OTHER DIVIDERS OR FRAMES: no nested panels, no split-screen inside a panel, "
            "no inset pictures, no duplicate upper/lower views, no collage fragments, no spanning, "
            "no overlap, and no content crossing the two center dividers.\n"
            "Each of the four cells is one clean tall portrait composition. Keep every important "
            "face, hand, object, and action well inside its assigned cell.\n"
            "Do not draw panel numbers, labels, captions, letters, subtitles, watermarks, logos, "
            "speech bubbles, or any other visible text.\n"
            f"GLOBAL VISUAL STYLE:\n{str(global_style or '').strip()}\n"
            f"CHARACTER CONSISTENCY FOR ALL PANELS:\n{str(character_bible or '').strip()}\n"
            f"ORDERED PANEL CONTENT:\n{assignments}\n"
            "FINAL CHECK: count exactly four panels—never five, six, or eight—with one scene per panel."
        ).strip()

    @classmethod
    def crop_sheet(
        cls,
        *,
        sheet_path: Path,
        output_paths: Sequence[Path],
        output_size: tuple[int, int] = (720, 1280),
        inset_fraction: float = 0.008,
        overwrite: bool = False,
        manifest_path: Path | None = None,
    ) -> list[Path]:
        if not 1 <= len(output_paths) <= cls.PANEL_COUNT:
            raise ValueError("output_paths must contain between one and four scene paths")
        if not sheet_path.exists() or sheet_path.stat().st_size < 1000:
            raise FileNotFoundError(f"story sheet missing or invalid: {sheet_path}")

        with Image.open(sheet_path) as opened:
            sheet = ImageOps.exif_transpose(opened).convert("RGB")

        width, height = sheet.size
        if width < 512 or height < 512:
            raise ValueError(f"story sheet is too small: {width}x{height}")
        sheet_ratio = width / float(height)
        if abs(sheet_ratio - (9.0 / 16.0)) > 0.035:
            raise ValueError(
                f"story sheet must be a 9:16 canvas, got {width}x{height} ({sheet_ratio:.4f})"
            )

        half_w = width // 2
        half_h = height // 2
        boxes = (
            (0, 0, half_w, half_h),
            (half_w, 0, width, half_h),
            (0, half_h, half_w, height),
            (half_w, half_h, width, height),
        )
        inset_fraction = min(0.03, max(0.0, float(inset_fraction)))
        written: list[Path] = []
        manifest_rows = []

        for index, (out_path, box) in enumerate(zip(output_paths, boxes), 1):
            left, top, right, bottom = box
            inset_x = int(round((right - left) * inset_fraction))
            inset_y = int(round((bottom - top) * inset_fraction))
            crop_box = (
                left + inset_x,
                top + inset_y,
                right - inset_x,
                bottom - inset_y,
            )
            out_path = Path(out_path)
            if overwrite or not out_path.exists() or out_path.stat().st_size < 1000:
                panel = sheet.crop(crop_box).resize(output_size, Image.Resampling.LANCZOS)
                out_path.parent.mkdir(parents=True, exist_ok=True)
                panel.save(out_path, format="JPEG", quality=95, subsampling=0)
            written.append(out_path)
            manifest_rows.append({
                "panel": index,
                "panel_name": cls.PANEL_NAMES[index - 1],
                "crop_box": list(crop_box),
                "output": str(out_path),
            })

        if manifest_path is not None:
            manifest_path.parent.mkdir(parents=True, exist_ok=True)
            manifest_path.write_text(json.dumps({
                "sheet": str(sheet_path),
                "sheet_size": [width, height],
                "output_size": list(output_size),
                "inset_fraction": inset_fraction,
                "panels": manifest_rows,
            }, ensure_ascii=False, indent=2), encoding="utf-8")
        return written

    @staticmethod
    def all_valid(paths: Iterable[Path], minimum_bytes: int = 5000) -> bool:
        for path in paths:
            try:
                if not path.exists() or path.stat().st_size < minimum_bytes:
                    return False
            except OSError:
                return False
        return True
