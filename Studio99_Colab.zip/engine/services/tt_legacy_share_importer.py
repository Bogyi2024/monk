from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from services.tt_settings_service import TTSettingsService


def _normalize_group_url(raw: str) -> str:
    value = str(raw or "").strip()
    if not value:
        return ""
    # Ignore old placeholder rows.
    if "group_link_" in value:
        return ""
    if value.isdigit():
        return f"https://www.facebook.com/groups/{value}/"
    if "facebook.com/groups/" not in value:
        return ""
    return value.split("?", 1)[0].rstrip("/") + "/"


def _guess_group_name(url: str) -> str:
    """Best-effort label only. Numeric Facebook IDs stay unnamed."""
    m = re.search(r"facebook\.com/groups/([^/?#]+)/?", str(url), flags=re.I)
    if not m:
        return ""
    slug = m.group(1).strip()
    if not slug or slug.isdigit():
        return ""
    # Vanity group URLs are often already human-readable enough to identify the group.
    return re.sub(r"[_-]+", " ", slug).strip()


def _clean_group_items(values: Any) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    seen: set[str] = set()
    for raw in values or []:
        name = ""
        url_raw: Any = raw
        if isinstance(raw, dict):
            name = str(raw.get("name") or raw.get("label") or "").strip()
            url_raw = raw.get("url") or raw.get("link") or raw.get("group_url") or ""
        url = _normalize_group_url(str(url_raw))
        if not url or url in seen:
            continue
        seen.add(url)
        out.append({"url": url, "name": name or _guess_group_name(url)})
    return out


def import_existing_fb_share_accounts(
    service: TTSettingsService,
    *,
    assign_to_recap: bool = False,
) -> dict[str, Any]:
    """
    Import the EXISTING Recap share-account config:
        config/fb_share_accounts.json

    Legacy schema:
      {
        "accounts": [
          {
            "name": "FB_Share_Acc_1",
            "profile_folder": "FB_Share_Acc_1",
            "enabled": true,
            "groups": ["https://www.facebook.com/groups/.../"],
            "note": "..."
          }
        ]
      }

    Merge rules:
    - Match a TT share account by Playwright profile first.
    - If not found, match by legacy account name/key.
    - Existing central labels are preserved.
    - Group URLs are UNIONED; never delete a current TT group.
    - Placeholder group_link_* entries are ignored.
    - New legacy accounts are added to TT.
    - Category routes are NOT changed unless assign_to_recap=True is explicitly requested.
    - The legacy source file itself is NOT changed.
    """
    legacy_path = service.root / "config" / "fb_share_accounts.json"
    report: dict[str, Any] = {
        "source": str(legacy_path),
        "found": legacy_path.exists(),
        "accounts_seen": 0,
        "accounts_added": 0,
        "accounts_matched": 0,
        "groups_seen": 0,
        "groups_added": 0,
        "assigned_to_recap": [],
        "warnings": [],
    }

    if not legacy_path.exists():
        return report

    try:
        legacy = json.loads(legacy_path.read_text(encoding="utf-8"))
        if not isinstance(legacy, dict):
            raise ValueError("legacy root must be an object")
        raw_accounts = legacy.get("accounts") or []
        if not isinstance(raw_accounts, list):
            raise ValueError("legacy accounts must be a list")
    except Exception as exc:
        report["warnings"].append(f"Could not read legacy config: {exc}")
        return report

    imported_enabled_keys: list[str] = []

    for raw in raw_accounts:
        if not isinstance(raw, dict):
            continue

        name = str(raw.get("name") or "").strip()
        profile = str(raw.get("profile_folder") or name).strip()
        if not name and not profile:
            continue

        enabled = bool(raw.get("enabled", True))
        note = str(raw.get("note") or "").strip()
        group_items = _clean_group_items(raw.get("groups") or [])
        groups = [x["url"] for x in group_items]
        imported_names = {x["url"]: x["name"] for x in group_items if x.get("name")}
        report["accounts_seen"] += 1
        report["groups_seen"] += len(groups)

        central = service.accounts()["fb_share_accounts"]

        # 1) Strongest match: same Playwright profile folder.
        target_key = ""
        for key, item in central.items():
            if str(item.get("profile") or "").strip().lower() == profile.lower():
                target_key = key
                break

        # 2) Then try normalized legacy name if it exists.
        if not target_key and name:
            try:
                normalized = service.normalize_key(name)
                if normalized in central:
                    target_key = normalized
            except Exception:
                normalized = ""

        if target_key:
            current = central[target_key]
            old_groups = [
                str(x).strip()
                for x in (current.get("groups") or [])
                if str(x).strip()
            ]
            merged = list(old_groups)
            for url in groups:
                if url not in merged:
                    merged.append(url)
                    report["groups_added"] += 1

            current_names = dict(current.get("group_names") or {})
            for url, group_name in imported_names.items():
                if group_name and not str(current_names.get(url) or "").strip():
                    current_names[url] = group_name

            changes: dict[str, Any] = {
                "groups": merged,
                "group_names": current_names,
                # Keep enabled if either side is enabled; don't unexpectedly disable.
                "enabled": bool(current.get("enabled", True) or enabled),
            }
            if not str(current.get("profile") or "").strip():
                changes["profile"] = profile
            # Existing human-friendly label wins. Only fill blank labels.
            if not str(current.get("label") or "").strip():
                changes["label"] = note or name or profile

            service.update_share_account(target_key, **changes)
            report["accounts_matched"] += 1
        else:
            label = note or name or profile
            base_key = name or profile or "share"
            target_key = service.add_share_account(
                key=base_key,
                label=label,
                profile=profile,
                enabled=enabled,
                auto_suffix=True,
            )
            service.update_share_account(target_key, groups=groups, group_names=imported_names)
            report["accounts_added"] += 1
            report["groups_added"] += len(groups)

        if enabled and target_key and target_key not in imported_enabled_keys:
            imported_enabled_keys.append(target_key)

    # Optional legacy behavior only. Web Manager V1.4 never enables this automatically.
    if assign_to_recap:
        cats = service.categories().get("categories", {})
        if "recap" in cats:
            current = list(cats["recap"].get("fb_share_accounts") or [])
            # Handle the old singular field too.
            legacy_single = str(cats["recap"].get("fb_share_account") or "").strip()
            if legacy_single and legacy_single not in current:
                current.append(legacy_single)

            merged_route = list(current)
            for key in imported_enabled_keys:
                if key not in merged_route:
                    merged_route.append(key)

            service.assign_route(
                "recap",
                fb_share_accounts=merged_route,
                share_enabled=True,
            )
            report["assigned_to_recap"] = imported_enabled_keys
        else:
            report["warnings"].append(
                "Recap category not found, so imported accounts were not auto-assigned."
            )

    return report
