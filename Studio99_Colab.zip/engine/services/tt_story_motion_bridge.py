from __future__ import annotations
from datetime import datetime

import asyncio
import json
from pathlib import Path
from typing import Any

from services.tt_share_export_service import TTShareExportService
from services.tt_route_branding_service import TTRouteBrandingService


class TTStoryMotionBridge:
    """Independent Story Motion route bridge.

    Routes in the same `content_group` reuse ONE story/FAL visual set.  MM/EN only
    generate their own continuous Gemini narration + render; images are never paid
    for twice just because the destination language/page differs.
    """

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings=settings_service;self.root=Path(project_root).resolve()
        self.pending_path=self.root/'state'/'tt_story_motion_pending.json'
        self.batch_path=self.root/'state'/'tt_story_motion_batch.json'
        self.genre_state_path=self.root/'state'/'tt_story_motion_genre_state.json'
        self.pipeline_config_path=self.root/'config'/'story_motion_pipeline.json'
        self.receipts_path=self.root/'state'/'tt_story_motion_primary_receipts.json'
        self.pending_path.parent.mkdir(parents=True,exist_ok=True)
        self.share_export=TTShareExportService(settings_service,self.root)
        self.branding=TTRouteBrandingService(self.root)

    def _load_json(self,path:Path,default):
        try:
            if path.exists(): return json.loads(path.read_text(encoding='utf-8'))
        except Exception: pass
        return default
    def _save_json(self,path:Path,data)->None:
        path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    def _pipeline_cfg(self)->dict[str,Any]:
        x=self._load_json(self.pipeline_config_path,{});return x if isinstance(x,dict) else {}

    def _pending_all(self)->dict[str,Any]:
        x=self._load_json(self.pending_path,{"routes":{}});return x if isinstance(x,dict) else {"routes":{}}
    def _pending_get(self,route_key:str)->dict[str,Any]|None:
        x=(self._pending_all().get('routes') or {}).get(route_key);return x if isinstance(x,dict) else None
    def _pending_set(self,route_key:str,value:dict[str,Any]|None)->None:
        allp=self._pending_all();routes=allp.setdefault('routes',{})
        if value is None: routes.pop(route_key,None)
        else: routes[route_key]=value
        if routes:self._save_json(self.pending_path,allp)
        elif self.pending_path.exists():self.pending_path.unlink()

    def _batches(self)->dict[str,Any]:
        x=self._load_json(self.batch_path,{"groups":{}});return x if isinstance(x,dict) else {"groups":{}}
    def _save_batches(self,x:dict[str,Any])->None:self._save_json(self.batch_path,x)

    def _receipt_state(self)->dict[str,Any]:
        from datetime import datetime
        today=datetime.now().astimezone().date().isoformat()
        data=self._load_json(self.receipts_path,{"date":today,"routes":{}})
        if not isinstance(data,dict) or data.get('date')!=today:
            data={"date":today,"routes":{}}
        data.setdefault('routes',{})
        return data

    def _lock_primary(self,route_key:str,content_id:str,pending:dict[str,Any],want_fb:bool,want_tt:bool)->bool:
        from datetime import datetime
        data=self._receipt_state(); routes=data.setdefault('routes',{}); row=routes.setdefault(route_key,{"items":[]})
        items=row.setdefault('items',[])
        existing=next((x for x in items if str((x or {}).get('content_id') or '')==content_id),None)
        if existing is not None:
            return False
        items.append({
            "content_id":content_id,
            "completed_at":datetime.now().astimezone().isoformat(timespec='seconds'),
            "fb_required":bool(want_fb),"tt_required":bool(want_tt),
            "fb_done":bool(pending.get('fb_done')),"tt_done":bool(pending.get('tt_done')),
            "fb_post_link":str(pending.get('fb_post_link') or ''),
        })
        row['items']=items[-100:]; self._save_json(self.receipts_path,data)
        print(f"🔒 Story Motion primary complete lock → {content_id} | route={route_key} | same-day repost disabled")
        return True

    def _finalize_batch(self,route_key:str,pending:dict[str,Any],build:dict[str,Any])->None:
        group=str(pending.get('group') or 'main');batches=self._batches();batch=(batches.get('groups') or {}).get(group)
        if isinstance(batch,dict):
            served=batch.setdefault('served_routes',[])
            if route_key not in served:served.append(route_key)
            active=self._group_routes(group)
            if active and all(x in served for x in active):
                self._mark_genre(group,str(batch.get('genre') or build.get('genre') or 'horror'))
                try:
                    from services.story_motion_production_service import StoryMotionProductionService
                    root_path=str((batch.get('assets') or {}).get('root') or '')
                    if root_path:
                        StoryMotionProductionService(self.root).engine._cleanup_success_work(Path(root_path))
                        receipt=Path(root_path)/'tt_master_completed.json'
                        self._save_json(receipt,{
                            'completed':True,'route_key':route_key,
                            'completed_at':datetime.now().astimezone().isoformat(timespec='seconds'),
                            'content_id':str(build.get('story_id') or Path(root_path).name),
                            'primary_complete':True,'group_summary':pending.get('group_summary'),
                            'secondary_skipped_reason':str(pending.get('secondary_skipped_reason') or ''),
                        })
                except Exception as cleanup_exc:
                    print(f'⚠️ Story Motion batch cleanup/receipt warning: {cleanup_exc}')
                batches.get('groups',{}).pop(group,None)
            self._save_batches(batches)
        self._pending_set(route_key,None)

    def _group_routes(self,group:str)->list[str]:
        out=[]
        for k,r in self.settings.category_routes('story_motion').items():
            if not isinstance(r,dict) or not r.get('enabled',True):continue
            if str(r.get('content_group') or 'main')!=group:continue
            if int(r.get('daily_limit') or 0)<=0:continue
            out.append(k)
        return out

    def _choose_genre(self,route_cfg:dict[str,Any],group:str)->str:
        mode=str(route_cfg.get('genre_mode') or 'alternate').lower().strip()
        fixed=str(route_cfg.get('fixed_genre') or 'horror').lower().strip()
        if mode in {'horror','thriller'}:return mode
        if mode=='fixed':return fixed if fixed in {'horror','thriller'} else 'horror'
        state=self._load_json(self.genre_state_path,{})
        last=str((state.get('groups') or {}).get(group) or '')
        return 'thriller' if last=='horror' else 'horror'
    def _mark_genre(self,group:str,genre:str)->None:
        state=self._load_json(self.genre_state_path,{"groups":{}});state.setdefault('groups',{})[group]=genre;self._save_json(self.genre_state_path,state)

    @staticmethod
    def _caption(build:dict[str,Any],cfg:dict[str,Any])->str:
        lang=str(build.get('language') or 'mm');cap_key='caption_mm' if lang=='mm' else 'caption_en';base=str(build.get(cap_key) or build.get('title') or '').strip();tags=[]
        for raw in ((cfg.get('hashtags') or {}).get(lang) or []):
            x=str(raw).strip()
            if x:tags.append(x if x.startswith('#') else '#'+x)
        return (base+('\n\n'+' '.join(tags) if tags else '')).strip()

    @staticmethod
    def _is_transient_fal_transport_error(message: str) -> bool:
        """Return True only for retryable FAL network/transport failures.

        Do not classify HTTP auth, validation, safety or quota responses as a
        network wait.  In particular, an SSL EOF can happen after the request
        left this process, so the caller must pause before resubmitting instead
        of issuing an immediate duplicate paid generation.
        """
        msg = str(message or '').lower()
        if 'fal' not in msg:
            return False
        terminal_markers = (
            'http 400', 'http 401', 'http 402', 'http 403', 'http 404',
            'http 409', 'http 422', 'quota', 'insufficient balance',
            'content policy', 'safety checker',
        )
        if any(marker in msg for marker in terminal_markers):
            return False
        transient_markers = (
            'ssleoferror', 'unexpected_eof_while_reading',
            'unexpected eof while reading', 'sslerror',
            'connectionpool', 'max retries exceeded',
            'connection reset', 'connection aborted',
            'remote disconnected', 'name resolution',
            'getaddrinfo failed', 'temporary failure in name resolution',
            'chunkedencodingerror', 'protocolerror',
            'connecttimeout', 'readtimeout', 'read timed out',
            'connect timed out', 'connection timed out',
            'http 500', 'http 502', 'http 503', 'http 504',
        )
        return any(marker in msg for marker in transient_markers)

    async def _prepare_build(self,route_key:str,route_cfg:dict[str,Any])->dict[str,Any]:
        from services.story_motion_production_service import StoryMotionProductionService
        group=str(route_cfg.get('content_group') or 'main').strip() or 'main';lang=str(route_cfg.get('language') or 'mm').lower().strip()
        if lang not in {'mm','en'}:lang='mm'
        batches=self._batches();groups=batches.setdefault('groups',{});batch=groups.get(group)
        active=self._group_routes(group)
        if batch and route_key in list(batch.get('served_routes') or []):
            unserved=[x for x in active if x not in list(batch.get('served_routes') or [])]
            if unserved:
                return {'wait_for_pair':True,'group':group,'unserved_routes':unserved}
            batch=None;groups.pop(group,None)
        service=StoryMotionProductionService(self.root)
        if not batch:
            genre=self._choose_genre(route_cfg,group);seed=str(route_cfg.get('topic_seed') or self._pipeline_cfg().get('topic_seed') or '')
            try:
                assets=await service.build_story_assets(genre=genre,seed=seed)
            except RuntimeError as exc:
                msg=str(exc)
                if 'request preserved for resume' in msg or 'fal image generation timeout' in msg or 'fal status poll failed after transient retries' in msg:
                    print(f"♻️ Story Motion FAL queue still pending — same request will resume on next turn; NOT treated as a failed content job: {msg}")
                    return {'fal_resume_pending':True,'group':group,'genre':genre,'error':msg}
                if self._is_transient_fal_transport_error(msg):
                    print(
                        "🌐 Story Motion FAL transport interrupted — pausing 5 minutes, then "
                        "resuming completed scenes instead of counting a content failure: "
                        f"{msg}"
                    )
                    return {'fal_transient_wait':True,'group':group,'genre':genre,'error':msg}
                raise
            batch={'group':group,'genre':genre,'assets':assets,'renders':{},'served_routes':[]}
            groups[group]=batch;self._save_batches(batches)
            print(f"🧩 Story Motion batch created → group={group} | genre={genre} | ONE FAL set")
        renders=batch.setdefault('renders',{})
        if lang not in renders:
            renders[lang]=await service.render_existing_assets(root=(batch.get('assets') or {}).get('root'),language=lang)
            groups[group]=batch;self._save_batches(batches)
        return {'batch':batch,'build':renders[lang],'group':group,'language':lang}

    async def run_once(self,route_key:str='default')->dict[str,Any]:
        existing=self._pending_get(route_key)
        resolved=self.settings.resolve_route('story_motion',route_key);cat=resolved['category'];route_cfg=resolved.get('route') or {}
        if not cat.get('enabled',True) or not route_cfg.get('enabled',True):raise RuntimeError(f"Story Motion route disabled: {route_key}")
        fb=resolved.get('facebook');tt=resolved.get('tiktok');want_fb=bool(fb and fb.get('enabled',True));want_tt=bool(tt and tt.get('enabled',True))
        if not want_fb and not want_tt:raise RuntimeError(f"Story Motion route {route_key} has no enabled Facebook/TikTok destination")
        selected=self.share_export.sync_route('story_motion',route_key)
        want_group=bool(want_fb and route_cfg.get('share_enabled',True) and selected)
        cfg=self._pipeline_cfg();pending=existing
        if not pending:
            prep=await self._prepare_build(route_key,route_cfg)
            if prep.get('wait_for_pair'):
                print(f"⏳ Story Motion content-group {prep['group']} waiting for sibling route(s): {prep['unserved_routes']}")
                return {'success':False,'new_content_count':0,'no_work':True,'route_key':route_key,'failure_kind':'waiting_for_content_pair'}
            if prep.get('fal_resume_pending'):
                return {
                    'success':False,'new_content_count':0,'transient_wait':True,
                    'category_wait':True,'retry_cooldown_minutes':5,
                    'route_key':route_key,'failure_kind':'fal_queue_resume_pending',
                    'error':str(prep.get('error') or ''),
                }
            if prep.get('fal_transient_wait'):
                return {
                    'success':False,'new_content_count':0,'transient_wait':True,
                    'category_wait':True,'retry_cooldown_minutes':5,
                    'route_key':route_key,'failure_kind':'fal_transport_retry',
                    'error':str(prep.get('error') or ''),
                }
            pending={'route_key':route_key,'group':prep['group'],'build':prep['build'],'fb_done':False,'tt_done':False,'group_done':False,'fb_post_link':'','group_summary':None,'permalink_recovery_attempts':0,'group_share_attempts':0}
            self._pending_set(route_key,pending)
        build=pending.get('build') or {};video=str(((build.get('render') or {}).get('full_video')) or '')
        if not video or not Path(video).exists():raise FileNotFoundError(f"Story Motion final video missing: {video}")
        caption=self._caption(build,cfg);content_id=str(build.get('story_id') or Path(str(build.get('root') or video)).stem or 'story_motion')

        primary_this_run=[]
        if want_fb and not pending.get('fb_done'):
            from services.browser_service import BrowserService
            branded_video=await asyncio.to_thread(self.branding.brand_video,video,'story_motion',route_key,route_cfg.get('branding') or {},'facebook_reel')
            r=await BrowserService().upload_reel_stealth(profile_name=str(fb.get('profile') or ''),page_id=str(fb.get('page_id') or ''),caption=caption,video_path=branded_video,capture_permalink=want_group)
            pending['fb_done']=bool((r or {}).get('success'));pending['fb_post_link']=str((r or {}).get('post_link') or '');self._pending_set(route_key,pending)
            if pending['fb_done']:primary_this_run.append('facebook')
            else:return {'success':False,'new_content_count':0,'pending':True,'route_key':route_key,'failure_kind':'facebook_upload_pending'}
        if want_tt and not pending.get('tt_done'):
            from services.tt_service import upload_to_tiktok
            branded_video=await asyncio.to_thread(self.branding.brand_video,video,'story_motion',route_key,route_cfg.get('branding') or {},'tiktok_reel')
            ok=await upload_to_tiktok(profile_folder_name=str(tt.get('profile') or ''),video_path=branded_video,caption_text=caption,headless=False)
            pending['tt_done']=bool(ok);self._pending_set(route_key,pending)
            if pending['tt_done']:primary_this_run.append('tiktok')
            else:return {'success':False,'new_content_count':0,'pending':True,'route_key':route_key,'failure_kind':'tiktok_upload_pending'}

        # PRIMARY completion is based ONLY on enabled FB/TikTok destinations.
        # If the route has Facebook only, Facebook success completes the content job.
        # If it has TikTok only, TikTok success completes it. Group share is secondary.
        primary_complete=((not want_fb) or bool(pending.get('fb_done'))) and ((not want_tt) or bool(pending.get('tt_done')))
        primary_new=False
        if primary_complete:
            primary_new=self._lock_primary(route_key,content_id,pending,want_fb,want_tt)
            pending['primary_complete']=True;self._pending_set(route_key,pending)

        if not want_group:
            pending['group_done']=True;pending['secondary_skipped_reason']='not_configured';self._pending_set(route_key,pending)
        elif primary_complete and not pending.get('group_done'):
            from services.browser_service import BrowserService
            from services.fb_group_service import auto_share_all_accounts
            link=str(pending.get('fb_post_link') or '')
            if not link:
                n=int(pending.get('permalink_recovery_attempts') or 0)+1;pending['permalink_recovery_attempts']=n;self._pending_set(route_key,pending)
                print(f"🔎 Story Motion Reel permalink recovery attempt {n}/3")
                link=await BrowserService().recover_latest_reel_permalink(str(fb.get('profile') or ''),str(fb.get('page_id') or ''),timeout_ms=120000)
                pending['fb_post_link']=str(link or '');self._pending_set(route_key,pending)
            if not link:
                n=int(pending.get('permalink_recovery_attempts') or 0)
                if n>=3:
                    pending['group_done']=True;pending['secondary_skipped_reason']='permalink_not_found_after_3';pending['group_summary']={'skipped':True,'reason':'permalink_not_found_after_3','attempts':n};self._pending_set(route_key,pending)
                    print("⏭️ Story Motion group-share permalink not found after 3 attempts — logged and SKIPPED; queue continues")
                else:
                    return {'success':True,'new_content_count':1 if primary_new else 0,'content_id':content_id,'story_id':content_id,'pending':True,'pending_secondary':True,'maintenance_only':not primary_new,'route_key':route_key,'failure_kind':'group_permalink_pending','primary_completed_this_run':primary_this_run}
            if link and not pending.get('group_done'):
                n=int(pending.get('group_share_attempts') or 0)+1;pending['group_share_attempts']=n;self._pending_set(route_key,pending)
                print(f"👥 Story Motion group-share whole-run attempt {n}/3")
                try:
                    gcfg=cfg.get('group_share') or {};summary=await auto_share_all_accounts(link,account_names=selected,share_text=caption,headless=bool(gcfg.get('headless',False)),delay_between_groups_seconds=float(gcfg.get('delay_between_groups_seconds',20)),delay_between_accounts_seconds=float(gcfg.get('delay_between_accounts_seconds',120)))
                    pending['group_summary']=summary;pending['group_done']=True;self._pending_set(route_key,pending)
                    if int((summary or {}).get('failed') or 0)>0:print(f"⚠️ Story Motion group share best-effort: {(summary or {}).get('failed')} group(s) failed; queue continues")
                except Exception as exc:
                    if n>=3:
                        pending['group_done']=True;pending['secondary_skipped_reason']='group_share_failed_after_3';pending['group_summary']={'skipped':True,'reason':'group_share_failed_after_3','attempts':n,'error':str(exc)};self._pending_set(route_key,pending)
                        print(f"⏭️ Story Motion group share failed after 3 attempts — logged and SKIPPED; queue continues: {exc}")
                    else:
                        return {'success':True,'new_content_count':1 if primary_new else 0,'content_id':content_id,'story_id':content_id,'pending':True,'pending_secondary':True,'maintenance_only':not primary_new,'route_key':route_key,'failure_kind':'group_share_pending','primary_completed_this_run':primary_this_run}

        if primary_complete and pending.get('group_done'):
            summary=pending.get('group_summary');skip_reason=str(pending.get('secondary_skipped_reason') or '')
            self._finalize_batch(route_key,pending,build)
            return {'success':True,'new_content_count':1 if primary_new else 0,'maintenance_only':not primary_new,'route_key':route_key,'content_id':content_id,'story_id':content_id,'genre':build.get('genre'),'language':build.get('language'),'group_share':summary if want_group else 'not_configured','secondary_skipped_reason':skip_reason,'primary_completed_this_run':primary_this_run}
        return {'success':False,'new_content_count':0,'pending':True,'route_key':route_key,'failure_kind':'pending_destination_retry'}
