from __future__ import annotations

import asyncio
import json
import os
import tempfile
import time
import uuid
from contextlib import suppress
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from bridges.episode_splitter_bridge import TTEpisodeSplitterBridge
from services.tt_preparation_status_service import TTPreparationStatusService
from services.tt_worker_lease_service import running_lease_status


class TTEpisodeSplitterNightService:
    """Night-only replenishment for standalone Episode Splitter pools.

    Posting jobs consume READY parts only. Heavy split/render work is moved out of
    the daytime rolling queue and runs after normal posting work has no safe slot.
    """

    CATEGORY = "episode_splitter"

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings = settings_service
        self.root = Path(project_root).resolve()
        self.bridge = TTEpisodeSplitterBridge(settings_service, self.root)
        self.prep = TTPreparationStatusService(settings_service, self.root)
        self.state_path = self.root / "state" / "tt_episode_splitter_night.json"
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self._wait_notice = ""
        self.owner_pid = os.getpid()
        self.owner_token = uuid.uuid4().hex

    @staticmethod
    def _atomic(path: Path, data: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        os.close(fd)
        tmp = Path(name)
        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            for attempt in range(7):
                try:
                    os.replace(tmp, path)
                    break
                except OSError as exc:
                    retryable = isinstance(exc, PermissionError) or getattr(exc, "winerror", None) in {5, 32}
                    if not retryable or attempt == 6:
                        raise
                    time.sleep(0.05 * (2 ** attempt))
        finally:
            try: tmp.unlink(missing_ok=True)
            except OSError: pass

    @staticmethod
    def _clock(now: datetime, value: str, fallback: str = "21:00") -> datetime:
        try:
            h, m = [int(x) for x in str(value or fallback).split(":", 1)]
        except Exception:
            h, m = [int(x) for x in fallback.split(":", 1)]
        return now.replace(hour=h, minute=m, second=0, microsecond=0)

    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8")) if self.state_path.exists() else {}
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _save(self, data: dict[str, Any]) -> None:
        data["updated_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
        self._atomic(self.state_path, data)

    def _save_failure_state(self, data: dict[str, Any], context: str) -> None:
        """Best-effort error receipt; a locked state file must never stop TT Master."""
        try:
            self._save(data)
        except OSError as exc:
            print(f"⚠️ Episode Splitter {context} state receipt skipped after retries: {type(exc).__name__}: {exc}")

    @staticmethod
    def _clear_lease(data: dict[str, Any]) -> None:
        data.pop("owner_pid", None)
        data.pop("owner_token", None)
        data.pop("heartbeat_at", None)

    def recover_stale_run(self, now: datetime | None = None) -> bool:
        """Release a RUNNING receipt after its process/heartbeat disappeared."""
        record = self._load()
        if str(record.get("status") or "").lower() != "running":
            return False
        local_now = now or datetime.now().astimezone()
        live, reason = running_lease_status(record, local_now)
        if live:
            return False
        self._clear_lease(record)
        record.update({
            "status": "interrupted",
            "complete": False,
            "last_error": f"stale Episode preparation recovered ({reason}); retry released",
            "finished_at": local_now.isoformat(timespec="seconds"),
        })
        self._save(record)
        print(f"[RECOVERY] Recovered stale Episode Splitter preparation ({reason}); retry released.")
        return True

    async def _heartbeat_lease(self, token: str) -> None:
        while True:
            await asyncio.sleep(15)
            current = self._load()
            if (
                str(current.get("status") or "").lower() != "running"
                or str(current.get("owner_token") or "") != token
            ):
                return
            current["heartbeat_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
            self._save(current)

    def _notice_once(self, token: str, message: str) -> None:
        if token != self._wait_notice:
            self._wait_notice = token
            print(message)

    async def run_if_due(
        self,
        state: dict[str, Any],
        decision: dict[str, Any],
        now: datetime,
        *,
        upstream_gate: dict[str, Any] | None = None,
    ) -> bool:
        cat = ((self.settings.categories().get("categories") or {}).get(self.CATEGORY) or {})
        rules = cat.get("production_rules") or {}
        prep_enabled = bool(rules.get("night_prep_enabled", rules.get("auto_prepare_inventory", True)))
        if not cat or not cat.get("enabled", True) or not prep_enabled:
            return False
        if decision.get("status") not in {"complete", "no_safe_slot"} or state.get("current_job"):
            return False
        gate = dict(upstream_gate or {})
        if not bool(gate.get("ready")):
            return False

        snap = self.prep.episode_snapshot(now)
        action_rows = [x for x in (snap.get("pools") or []) if x.get("status") == "ACTION REQUIRED"]
        if action_rows:
            self._notice_once(
                "source_auth_required",
                "🛑 Episode preparation paused: YouTube Source Download Auth needs Login / Refresh.",
            )
            return False
        need = [x for x in (snap.get("pools") or []) if x.get("status") in {"NEEDS PREP", "POOL MISSING"}]
        if not need:
            return False

        retry_minutes = max(5, int(rules.get("night_retry_minutes") or 60))
        prev = self._load()
        if str(prev.get("status") or "").lower() == "running":
            live, _reason = running_lease_status(prev, now)
            if live:
                return False
            self.recover_stale_run(now)
            prev = self._load()
        auth_recovered = any(bool(x.get("source_auth_refreshed_after_failure")) for x in need)
        retry_base = prev.get("finished_at") or prev.get("last_attempt_at")
        retry_immediately = str(prev.get("status") or "").lower() == "interrupted"
        if retry_base and not auth_recovered and not retry_immediately:
            try:
                last = datetime.fromisoformat(str(retry_base).replace("Z", "+00:00"))
                if last.tzinfo is None: last = last.astimezone()
                retry_at = last.astimezone(now.tzinfo) + timedelta(minutes=retry_minutes)
                if now < retry_at:
                    self._notice_once(
                        f"cooldown:{retry_at.isoformat(timespec='minutes')}",
                        f"⏳ Episode preparation retry scheduled → {retry_at:%H:%M} ({retry_minutes}m cooldown after last finish).",
                    )
                    return False
            except Exception:
                pass

        attempt_now = datetime.now().astimezone()
        self._wait_notice = ""
        record = {
            "version": 2,
            "status": "running",
            "last_attempt_at": attempt_now.isoformat(timespec="seconds"),
            "pools": [x.get("pool") for x in need],
            "upstream_handoff_id": str(gate.get("handoff_id") or ""),
            "upstream_status": str(gate.get("status") or ""),
            "upstream_finished_at": str(gate.get("finished_at") or ""),
            "last_error": "",
            "owner_pid": self.owner_pid,
            "owner_token": self.owner_token,
            "heartbeat_at": attempt_now.isoformat(timespec="seconds"),
        }
        self._save(record)
        heartbeat_task = asyncio.create_task(
            self._heartbeat_lease(self.owner_token), name="tt:episode-prep-heartbeat"
        )
        try:
            errors: list[str] = []
            for row in need:
                pool = str(row.get("pool") or "").strip()
                if not pool:
                    continue
                try:
                    print(f"🌙 TT NIGHT PREP → Episode Splitter pool={pool} | READY={row.get('ready_parts')} MIN={row.get('min_ready_parts')} TARGET={row.get('target_ready_parts')}")
                    result = await self.bridge._prepare(
                        pool,
                        list(row.get("source_urls") or []),
                        scan_limit=max(1, int(rules.get("youtube_scan_limit") or 12)),
                        prep_buffer_days=max(1, int(row.get("prep_buffer_days") or rules.get("prep_buffer_days") or 3)),
                        daily_upload_parts=max(1, int(row.get("posting_target") or 1)),
                    )
                    inv = result.get("inventory") or {}
                    print(f"✅ Episode Splitter prep → {pool} READY={inv.get('ready_parts','?')} MIN={inv.get('min_ready_parts','?')} TARGET={inv.get('target_ready_parts','?')}")
                except Exception as exc:
                    errors.append(f"{pool}: {type(exc).__name__}: {exc}")
                    print(f"⚠️ Episode Splitter night prep failed for {pool}: {exc}")

            after = self.prep.episode_snapshot(datetime.now().astimezone())
            complete = bool(after.get("pools")) and all(x.get("status") == "READY" for x in after.get("pools") or [])
            source_kind = next((str(x.get("source_failure_kind") or "") for x in after.get("pools") or [] if x.get("source_failure_kind")), "")
            source_error = next((str(x.get("source_error") or "") for x in after.get("pools") or [] if x.get("source_error")), "")
            finished_now = datetime.now().astimezone()
            self._clear_lease(record)
            record.update({
                "status": "ready" if complete else ("error" if errors else "shortfall"),
                "complete": complete,
                "failure_kind": "" if complete else (source_kind or ("worker_error" if errors else "inventory_shortfall")),
                "last_error": " | ".join(errors) or ("" if complete else source_error),
                "finished_at": finished_now.isoformat(timespec="seconds"),
                "retry_at": "" if source_kind == "source_auth_required" else (finished_now + timedelta(minutes=retry_minutes)).isoformat(timespec="seconds"),
                "result": after,
            })
            self._save(record)
            return True
        except asyncio.CancelledError:
            self._clear_lease(record)
            record.update({
                "status": "interrupted",
                "complete": False,
                "last_error": "TT Master stopped during Episode preparation; retry released",
                "finished_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            })
            self._save_failure_state(record, "interrupted")
            print("[INTERRUPTED] Episode Splitter preparation stopped; retry released.")
            raise
        finally:
            heartbeat_task.cancel()
            with suppress(asyncio.CancelledError):
                await heartbeat_task
