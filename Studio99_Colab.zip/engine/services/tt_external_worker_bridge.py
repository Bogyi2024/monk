from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from services.tt_content_category_registry import content_category
from services.tt_route_branding_service import TTRouteBrandingService


class TTExternalWorkerBridge:
    """Generic JSON contract for content tools that live outside TT Master."""

    def __init__(self, category_key: str, settings_service, project_root: str | Path = "."):
        self.category_key = str(category_key)
        self.settings = settings_service
        self.root = Path(project_root).resolve()
        self.definition = content_category(self.category_key) or {}
        self.work_dir = self.root / "state" / "tt_external_workers" / self.category_key
        self.work_dir.mkdir(parents=True, exist_ok=True)
        self.publish_ledger_path = self.work_dir / "publish_receipts.json"
        self.branding = TTRouteBrandingService(self.root)

    @staticmethod
    def _utf8_env() -> dict[str, str]:
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"] = "1"
        return env

    def _load_publish_ledger(self) -> dict[str, Any]:
        if not self.publish_ledger_path.exists():
            return {"version": 1, "items": {}}
        try:
            data = json.loads(self.publish_ledger_path.read_text(encoding="utf-8-sig"))
        except Exception as exc:
            # Fail closed: replacing a corrupt receipt file could repost an
            # already-published Facebook/TikTok image post.
            raise RuntimeError(f"External publish receipt ledger unreadable: {self.publish_ledger_path}: {exc}") from exc
        if not isinstance(data, dict) or not isinstance(data.get("items"), dict):
            raise RuntimeError(f"External publish receipt ledger invalid: {self.publish_ledger_path}")
        data.setdefault("version", 1)
        return data

    def _save_publish_ledger(self, data: dict[str, Any]) -> None:
        self.publish_ledger_path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.publish_ledger_path.with_suffix(self.publish_ledger_path.suffix + ".tmp")
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temp, self.publish_ledger_path)

    def _counted_on_date(self, content_id: str, date_value: str) -> bool:
        """Check TT Master's immutable Today receipt before generating again."""
        if not date_value:
            return False
        path = self.root / "state" / "tt_completion_receipts" / f"{date_value}.json"
        if not path.exists():
            return False
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig"))
            rows = (((data.get("categories") or {}).get(self.category_key) or {}).get("receipts") or {})
            return content_id in rows
        except Exception as exc:
            # A corrupt central receipt must not authorize generation of a new
            # story while we cannot prove the acknowledged one was counted.
            raise RuntimeError(f"TT completion receipt unreadable while reconciling {content_id}: {path}: {exc}") from exc

    @staticmethod
    def _completed_destinations(row: dict[str, Any]) -> list[str]:
        required = [str(x) for x in (row.get("required_destinations") or [])]
        done = row.get("destinations") or {}
        return required if set(required).issubset(done) else []

    @staticmethod
    def _friendly_destinations(required: list[str]) -> list[str]:
        return ["facebook" if name == "facebook_post" else "tiktok" for name in required]

    def _completion_result(self, row: dict[str, Any], *, completed_this_run: list[str] | None = None) -> dict[str, Any]:
        required = [str(x) for x in (row.get("required_destinations") or [])]
        done = row.get("destinations") or {}
        friendly = self._friendly_destinations(required)
        return {
            "success": True,
            "new_content_count": 1,
            "content_id": str(row.get("content_id") or ""),
            "route_key": str(row.get("route_key") or "default"),
            "pending": False,
            "pending_publish": False,
            "primary_destinations_completed": friendly,
            "destinations_completed": friendly,
            "primary_completed_this_run": list(completed_this_run or []),
            "facebook_post_link": str((done.get("facebook_post") or {}).get("post_link") or ""),
            "source_url": str(row.get("source_url") or ""),
            "canonical_url": str(row.get("canonical_url") or ""),
            "story_fingerprint": str(row.get("story_fingerprint") or ""),
            "manifest": str(row.get("manifest") or ""),
            "evidence_file": str(row.get("evidence_file") or ""),
        }

    async def _reconcile_completed_publish(self, route_key: str) -> dict[str, Any] | None:
        """Finish ack/count recovery before asking the worker for another story."""
        ledger = self._load_publish_ledger()
        candidates = [
            row for row in (ledger.get("items") or {}).values()
            if isinstance(row, dict)
            and str(row.get("route_key") or "default") == str(route_key or "default")
            and self._completed_destinations(row)
        ]
        candidates.sort(key=lambda row: str(row.get("created_at") or ""))
        for row in candidates:
            content_id = str(row.get("content_id") or "").strip()
            if not content_id:
                continue
            acknowledged_at = str(row.get("acknowledged_at") or "")
            if not acknowledged_at:
                await asyncio.to_thread(self._ack_publish, content_id, {"destinations": row.get("destinations") or {}})
                acknowledged_at = datetime.now(timezone.utc).isoformat()
                row["acknowledged_at"] = acknowledged_at
                row["acknowledged_local_date"] = datetime.now().astimezone().date().isoformat()
                self._save_publish_ledger(ledger)
                return self._completion_result(row)

            receipt_date = str(row.get("acknowledged_local_date") or "")
            if not receipt_date:
                try:
                    receipt_date = datetime.fromisoformat(acknowledged_at.replace("Z", "+00:00")).astimezone().date().isoformat()
                except Exception:
                    receipt_date = datetime.now().astimezone().date().isoformat()
                row["acknowledged_local_date"] = receipt_date
                self._save_publish_ledger(ledger)
            if receipt_date == datetime.now().astimezone().date().isoformat() and not self._counted_on_date(content_id, receipt_date):
                print(f"[Grounded News] restoring uncounted acknowledged post before new generation: {content_id}")
                return self._completion_result(row)
        return None

    @staticmethod
    def _read_artifact(path_value: Any, label: str) -> str:
        path = Path(str(path_value or ""))
        if not path.is_file():
            raise FileNotFoundError(f"Grounded-news {label} artifact missing: {path}")
        value = path.read_text(encoding="utf-8-sig").strip()
        if not value:
            raise RuntimeError(f"Grounded-news {label} artifact is empty: {path}")
        return value

    @staticmethod
    def _artifact_paths(values: Any, label: str) -> list[str]:
        rows = values if isinstance(values, list) else [values]
        paths: list[str] = []
        for raw in rows:
            path = Path(str(raw or ""))
            if not path.is_file():
                raise FileNotFoundError(f"Grounded-news {label} artifact missing: {path}")
            paths.append(str(path.resolve()))
        if not paths:
            raise RuntimeError(f"Grounded-news {label} artifact list is empty")
        return paths

    @classmethod
    def runner_for(cls, category_key: str, project_root: str | Path = ".") -> Path | None:
        root = Path(project_root).resolve()
        definition = content_category(category_key) or {}
        env_name = str(definition.get("runner_env") or "").strip()
        if env_name:
            configured = str(os.getenv(env_name) or "").strip()
            if configured:
                path = Path(configured).expanduser()
                if not path.is_absolute():
                    path = root / path
                if path.is_file():
                    return path.resolve()
        for raw in definition.get("runner_candidates") or []:
            path = Path(str(raw))
            if not path.is_absolute():
                path = root / path
            if path.is_file():
                return path.resolve()
        return None

    @classmethod
    def capability(cls, category_key: str, project_root: str | Path = ".") -> dict[str, Any]:
        runner = cls.runner_for(category_key, project_root)
        if runner:
            return {"live": True, "label": f"LIVE — external worker: {runner.name}", "runner": str(runner)}
        definition = content_category(category_key) or {}
        env_name = str(definition.get("runner_env") or "").strip()
        return {
            "live": False,
            "label": f"External {category_key} worker not connected"
            + (f"; set {env_name} or install the registered runner" if env_name else ""),
        }

    def _invoke(self, route_key: str) -> dict[str, Any]:
        runner = self.runner_for(self.category_key, self.root)
        if not runner:
            raise RuntimeError(self.capability(self.category_key, self.root)["label"])
        payload = self.settings.worker_payload(self.category_key, route_key)
        fd_in, input_name = tempfile.mkstemp(prefix="payload_", suffix=".json", dir=str(self.work_dir))
        fd_out, output_name = tempfile.mkstemp(prefix="result_", suffix=".json", dir=str(self.work_dir))
        os.close(fd_in)
        os.close(fd_out)
        input_path = Path(input_name)
        output_path = Path(output_name)
        output_path.unlink(missing_ok=True)
        try:
            input_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            proc = subprocess.Popen(
                [sys.executable, "-u", str(runner), "--payload", str(input_path), "--result", str(output_path)],
                cwd=str(runner.parent),
                env=self._utf8_env(),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            try:
                worker_timeout = max(
                    120,
                    min(3600, int(os.getenv("GROUNDED_NEWS_WORKER_TIMEOUT_SECONDS", "900"))),
                )
            except (TypeError, ValueError):
                worker_timeout = 900
            timed_out = threading.Event()

            def stop_hung_worker() -> None:
                if proc.poll() is None:
                    timed_out.set()
                    try:
                        proc.kill()
                    except OSError:
                        pass

            watchdog = threading.Timer(worker_timeout, stop_hung_worker)
            watchdog.daemon = True
            watchdog.start()
            assert proc.stdout is not None
            try:
                for line in proc.stdout:
                    print(line.rstrip())
                code = proc.wait()
            finally:
                watchdog.cancel()
            if timed_out.is_set():
                raise RuntimeError(
                    f"{self.category_key} external worker exceeded {worker_timeout}s hard timeout"
                )
            if code != 0:
                raise RuntimeError(f"{self.category_key} external worker exited with code {code}")
            if not output_path.exists():
                raise RuntimeError(f"{self.category_key} external worker did not write --result JSON")
            result = json.loads(output_path.read_text(encoding="utf-8"))
            if not isinstance(result, dict) or "success" not in result:
                raise RuntimeError(f"{self.category_key} external worker result must be an object containing success")
            return result
        finally:
            input_path.unlink(missing_ok=True)
            output_path.unlink(missing_ok=True)

    def _ack_publish(self, content_id: str, receipts: dict[str, Any]) -> None:
        runner = self.runner_for(self.category_key, self.root)
        if not runner:
            raise RuntimeError(self.capability(self.category_key, self.root)["label"])
        fd, name = tempfile.mkstemp(prefix="publish_ack_", suffix=".json", dir=str(self.work_dir))
        os.close(fd)
        receipts_path = Path(name)
        try:
            receipts_path.write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            proc = subprocess.Popen(
                [
                    sys.executable, "-u", str(runner),
                    "--ack-content-id", content_id,
                    "--receipts", str(receipts_path),
                ],
                cwd=str(runner.parent),
                env=self._utf8_env(),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            assert proc.stdout is not None
            for line in proc.stdout:
                print(line.rstrip())
            code = proc.wait()
            if code != 0:
                raise RuntimeError(f"{self.category_key} publish acknowledgement exited with code {code}")
        finally:
            receipts_path.unlink(missing_ok=True)

    async def _publish_pending(self, route_key: str, result: dict[str, Any]) -> dict[str, Any]:
        content_id = str(result.get("content_id") or "").strip()
        if not content_id:
            raise RuntimeError(f"{self.category_key} pending publish result has no content_id")
        resolved = self.settings.resolve_route(self.category_key, route_key)
        category = resolved.get("category") or {}
        route = resolved.get("route") or {}
        if not category.get("enabled", True) or not route.get("enabled", True):
            raise RuntimeError(f"{self.category_key} route disabled: {route_key}")

        facebook = resolved.get("facebook")
        tiktok = resolved.get("tiktok")
        current_required: list[str] = []
        if facebook and facebook.get("enabled", True):
            current_required.append("facebook_post")
        if tiktok and tiktok.get("enabled", True):
            current_required.append("tiktok_image_post")
        if not current_required:
            raise RuntimeError(
                f"{self.category_key}/{route_key} requires at least one connected and enabled Facebook or TikTok destination"
            )

        ledger = self._load_publish_ledger()
        items = ledger.setdefault("items", {})
        row = items.get(content_id)
        if not isinstance(row, dict):
            # Freeze the destination contract for this generated story. Adding a
            # TikTok account tomorrow must never reopen yesterday's pending post.
            row = {
                "content_id": content_id,
                "category": self.category_key,
                "route_key": route_key,
                "required_destinations": list(current_required),
                "targets": {
                    "facebook_post": dict(facebook or {}),
                    "tiktok_image_post": dict(tiktok or {}),
                },
                "destinations": {},
                "created_at": datetime.now(timezone.utc).isoformat(),
                "acknowledged_at": "",
                "acknowledged_local_date": "",
                "source_url": str(result.get("source_url") or ""),
                "canonical_url": str(result.get("canonical_url") or ""),
                "story_fingerprint": str(result.get("story_fingerprint") or ""),
                "manifest": str(result.get("manifest") or ""),
                "evidence_file": str(result.get("evidence_file") or ""),
            }
            items[content_id] = row
            self._save_publish_ledger(ledger)

        required = [str(x) for x in (row.get("required_destinations") or [])]
        done = row.setdefault("destinations", {})
        targets = row.get("targets") or {}
        specs = result.get("destinations") or {}
        completed_this_run: list[str] = []

        if "facebook_post" in required and "facebook_post" not in done:
            spec = specs.get("facebook_post") or {}
            images = self._artifact_paths(spec.get("image") or spec.get("images"), "Facebook image")
            images = await asyncio.to_thread(
                self.branding.brand_images, images, self.category_key, route_key,
                route.get("branding") or {}, "facebook_post",
            )
            caption = self._read_artifact(spec.get("text") or spec.get("caption"), "Facebook text")
            target = targets.get("facebook_post") or {}
            from services.story_carousel_upload_service import upload_facebook_story_carousel
            detail = await upload_facebook_story_carousel(
                images,
                caption,
                profile_name=str(target.get("profile") or "Main_FB_Account"),
                page_id=str(target.get("page_id") or ""),
                headless=False,
                return_detail=True,
                capture_permalink=True,
            )
            if not (detail or {}).get("success"):
                return {
                    "success": False, "new_content_count": 0, "pending": True,
                    "pending_publish": True, "content_id": content_id,
                    "route_key": route_key, "failure_kind": "facebook_upload_pending",
                    "retry_cooldown_minutes": 10,
                }
            done["facebook_post"] = {
                "completed_at": datetime.now(timezone.utc).isoformat(),
                "post_link": str((detail or {}).get("post_link") or ""),
            }
            completed_this_run.append("facebook")
            self._save_publish_ledger(ledger)

        if "tiktok_image_post" in required and "tiktok_image_post" not in done:
            spec = specs.get("tiktok_image_post") or {}
            images = self._artifact_paths(spec.get("images") or spec.get("image"), "TikTok image")
            images = await asyncio.to_thread(
                self.branding.brand_images, images, self.category_key, route_key,
                route.get("branding") or {}, "tiktok_image",
            )
            caption = self._read_artifact(spec.get("caption") or spec.get("text"), "TikTok caption")
            target = targets.get("tiktok_image_post") or {}
            from services.story_carousel_upload_service import upload_tiktok_story_photos
            ok = await upload_tiktok_story_photos(
                images,
                caption,
                profile_name=str(target.get("profile") or ""),
                headless=False,
            )
            if not ok:
                return {
                    "success": False, "new_content_count": 0, "pending": True,
                    "pending_publish": True, "content_id": content_id,
                    "route_key": route_key, "failure_kind": "tiktok_upload_pending",
                    "retry_cooldown_minutes": 10,
                }
            done["tiktok_image_post"] = {
                "completed_at": datetime.now(timezone.utc).isoformat(),
            }
            completed_this_run.append("tiktok")
            self._save_publish_ledger(ledger)

        if not set(required).issubset(done):
            return {
                "success": False, "new_content_count": 0, "pending": True,
                "pending_publish": True, "content_id": content_id,
                "route_key": route_key, "failure_kind": "pending_destination_retry",
                "retry_cooldown_minutes": 10,
            }

        if not row.get("acknowledged_at"):
            try:
                await asyncio.to_thread(self._ack_publish, content_id, {"destinations": done})
            except Exception as exc:
                print(f"[Grounded News] publish acknowledgement pending: {exc}")
                return {
                    "success": False, "new_content_count": 0, "pending": True,
                    "pending_publish": True, "content_id": content_id,
                    "route_key": route_key, "failure_kind": "publish_ack_pending",
                    "retry_cooldown_minutes": 5,
                }
            row["acknowledged_at"] = datetime.now(timezone.utc).isoformat()
            row["acknowledged_local_date"] = datetime.now().astimezone().date().isoformat()
            self._save_publish_ledger(ledger)
        return self._completion_result(row, completed_this_run=completed_this_run)

    async def run_once(self, route_key: str = "default") -> dict[str, Any]:
        recovered = await self._reconcile_completed_publish(route_key)
        if recovered is not None:
            return recovered
        result = await asyncio.to_thread(self._invoke, route_key)
        if bool(result.get("success")) and bool(result.get("pending_publish")):
            return await self._publish_pending(route_key, result)
        return result
