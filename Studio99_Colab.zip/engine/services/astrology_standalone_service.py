from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any

WEEKDAY_MM = {
    0: "တနင်္လာသားသမီးများအတွက်",
    1: "အင်္ဂါသားသမီးများအတွက်",
    2: "ဗုဒ္ဓဟူးသားသမီးများအတွက်",
    3: "ကြာသပတေးသားသမီးများအတွက်",
    4: "သောကြာသားသမီးများအတွက်",
    5: "စနေနေ့သားသမီးများအတွက်",
    6: "တနင်္ဂနွေသားသမီးများအတွက်",
}


def read_json(path: Path, default: Any) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


@dataclass
class AstroJob:
    key: str
    label: str
    fb_output: str
    tt_output: str
    language: str
    content_group: str
    visuals: dict[str, Any]
    payload: dict[str, Any]


class AstrologyStandaloneService:
    """Standalone Astrology planner/test harness.

    This patch intentionally focuses on deterministic business logic + render contracts,
    so the user can validate the exact posting rules before plugging the category into
    TT Master. It reuses existing Carousel/Motion engines later, but this test runner
    only writes the concrete job plan + render instructions to disk.
    """

    def __init__(self, config_path: str = "config/astrology_standalone.json") -> None:
        self.config_path = Path(config_path)
        self.cfg = read_json(self.config_path, {
            "language": "mm",
            "facebook_outputs": {
                "daily": "carousel",
                "image_pick": "motion",
                "weekly": "carousel",
                "monthly": "carousel",
            },
            "tiktok_outputs": {
                "daily": "motion",
                "image_pick": "motion",
                "weekly": "motion",
                "monthly": "motion",
            },
            "image_pick": {
                "selection_images": 4,
                "scene_count": 6,
                "first_scene_layout": "single_grid_2x2",
                "followup_crop_mode": "single_image_9x16_crop",
                "motion_caption_font_scale": 0.88,
                "theme_prompt": (
                    "cute dreamy mystical illustration, astrology friendly, random cute vibe, "
                    "clean composition, soft pastel glow"
                ),
            },
            "timing": {
                "short_seconds": 4.0,
                "medium_seconds": 5.5,
                "long_seconds": 7.0,
            },
        })

    @staticmethod
    def _is_last_day_of_month(d: datetime) -> bool:
        from calendar import monthrange
        return d.day == monthrange(d.year, d.month)[1]

    def build_jobs_for_date(self, when: datetime | None = None) -> list[AstroJob]:
        when = when or datetime.now()
        jobs: list[AstroJob] = []
        day_idx = when.weekday()  # Monday=0
        is_sunday = day_idx == 6
        is_month_end = self._is_last_day_of_month(when)
        born_label = WEEKDAY_MM[day_idx]
        date_label = when.strftime("%Y-%m-%d")

        # Priority rule confirmed by user:
        # normal: daily + image_pick
        # sunday: weekly + daily + image_pick
        # month-end: monthly + daily + image_pick
        # month-end sunday: monthly + daily + image_pick (weekly skipped)
        if is_month_end:
            jobs.append(self._monthly_job(date_label))
        elif is_sunday:
            jobs.append(self._weekly_job(date_label))

        jobs.append(self._daily_job(date_label, born_label, day_idx))
        jobs.append(self._image_pick_job(date_label, born_label))
        return jobs

    def _daily_job(self, date_label: str, born_label: str, day_idx: int) -> AstroJob:
        key = f"daily_{day_idx+1}"
        return AstroJob(
            key=key,
            label="တစ်နေ့တာဗေဒင်",
            fb_output=self.cfg["facebook_outputs"]["daily"],
            tt_output=self.cfg["tiktok_outputs"]["daily"],
            language="mm",
            content_group=f"astro_daily_{date_label}",
            visuals={
                "renderer": "carousel_for_fb_and_motion_for_tt",
                "motion_audio": "soft_lofi",
                "caption_mode": "full_slide_text",
            },
            payload={
                "date": date_label,
                "born_label": born_label,
                "cover_title": f"{born_label}\nတစ်နေ့တာဗေဒင်",
                "slides": [
                    {"role": "cover", "text": f"{born_label}\nဒီနေ့ ဘာတွေဖြစ်မလဲ?"},
                    {"role": "general", "text": "ယနေ့ စိတ်အခြေအနေ၊ အခွင့်အလမ်း၊ သတိထားစရာ"},
                    {"role": "love", "text": "အချစ်ရေး / ဆက်ဆံရေး"},
                    {"role": "work", "text": "အလုပ် / ငွေကြေး"},
                    {"role": "luck", "text": "ကံကောင်းအရောင် / ကံကောင်းနံပါတ် / သတိစကား"},
                ],
                "prompt_contract": {
                    "writer": "Gemini",
                    "instruction": (
                        f"Myanmar only. Write one concise daily horoscope for {born_label}. "
                        "Use friendly, shareable Burmese. Keep each slide readable."
                    ),
                },
            },
        )

    def _weekly_job(self, date_label: str) -> AstroJob:
        return AstroJob(
            key="weekly_all_weekdays",
            label="တစ်ပတ်တာဗေဒင်",
            fb_output=self.cfg["facebook_outputs"]["weekly"],
            tt_output=self.cfg["tiktok_outputs"]["weekly"],
            language="mm",
            content_group=f"astro_weekly_{date_label}",
            visuals={
                "renderer": "8_slide_fb_carousel_and_tt_motion",
                "motion_audio": "soft_lofi",
                "caption_mode": "full_slide_text",
            },
            payload={
                "date": date_label,
                "slides": [
                    {"role": "cover", "text": "၇ ရက်သားသမီးအတွက် တစ်ပတ်တာဗေဒင်"},
                    *[{"role": "weekday", "born_label": WEEKDAY_MM[i], "text": WEEKDAY_MM[i]} for i in range(7)],
                ],
                "prompt_contract": {
                    "writer": "Gemini",
                    "instruction": (
                        "Myanmar only. Write one weekly horoscope deck for all seven weekday-born groups. "
                        "8 slides total: 1 cover + 7 weekday groups."
                    ),
                },
            },
        )

    def _monthly_job(self, date_label: str) -> AstroJob:
        return AstroJob(
            key="monthly_all_weekdays",
            label="တစ်လတာဗေဒင်",
            fb_output=self.cfg["facebook_outputs"]["monthly"],
            tt_output=self.cfg["tiktok_outputs"]["monthly"],
            language="mm",
            content_group=f"astro_monthly_{date_label}",
            visuals={
                "renderer": "8_slide_fb_carousel_and_tt_motion",
                "motion_audio": "soft_lofi",
                "caption_mode": "full_slide_text",
            },
            payload={
                "date": date_label,
                "slides": [
                    {"role": "cover", "text": "၇ ရက်သားသမီးအတွက် တစ်လတာဗေဒင်"},
                    *[{"role": "weekday", "born_label": WEEKDAY_MM[i], "text": WEEKDAY_MM[i]} for i in range(7)],
                ],
                "prompt_contract": {
                    "writer": "Gemini",
                    "instruction": (
                        "Myanmar only. Write one monthly horoscope deck for all seven weekday-born groups. "
                        "8 slides total: 1 cover + 7 weekday groups."
                    ),
                },
            },
        )

    def _image_pick_job(self, date_label: str, born_label: str) -> AstroJob:
        pick_cfg = self.cfg.get("image_pick", {})
        return AstroJob(
            key="image_pick_4",
            label="ပုံ ၄ ပုံရွေး",
            fb_output=self.cfg["facebook_outputs"]["image_pick"],
            tt_output=self.cfg["tiktok_outputs"]["image_pick"],
            language="mm",
            content_group=f"astro_pick_{date_label}",
            visuals={
                "renderer": "motion_only",
                "motion_audio": "soft_lofi",
                "caption_mode": "grid_then_crops",
                "first_scene_layout": pick_cfg.get("first_scene_layout", "single_grid_2x2"),
                "followup_crop_mode": pick_cfg.get("followup_crop_mode", "single_image_9x16_crop"),
                "caption_font_scale": pick_cfg.get("motion_caption_font_scale", 0.88),
                "selection_images": pick_cfg.get("selection_images", 4),
            },
            payload={
                "date": date_label,
                "theme_prompt": pick_cfg.get("theme_prompt"),
                "selection_instruction": "စိတ်ထဲမှာ အကြိုက်ဆုံးတစ်ပုံကိုရွေးပါ",
                "scene_contract": [
                    {
                        "scene_no": 1,
                        "visual": "one image containing a 2x2 grid of 4 cute random mystical images",
                        "text": "ပုံ ၄ ပုံထဲက စိတ်ထဲမှာ အကြိုက်ဆုံးတစ်ပုံကိုရွေးပါ",
                        "notes": "Render a single composite scene with 4 images together. This is the token-saving first scene.",
                    },
                    *[
                        {
                            "scene_no": i + 2,
                            "visual": f"crop image {i+1} from the original 4-image grid and expand it to 9:16",
                            "text": f"ပုံ {i+1} ကိုရွေးတဲ့သူများအတွက်",
                            "notes": "Use the same selected image from scene 1, cropped and enlarged for readable Burmese text.",
                        }
                        for i in range(4)
                    ],
                    {
                        "scene_no": 6,
                        "visual": "final CTA over any one of the cute mystical images",
                        "text": "သင်ရွေးတာ ဘယ်ပုံလဲ comment မှာပြောပါ",
                        "notes": "Closing CTA",
                    },
                ],
                "prompt_contract": {
                    "writer": "Gemini",
                    "instruction": (
                        f"Myanmar only. Create one pick-an-image astrology post for {born_label}. "
                        "First scene asks users to choose 1 of 4 images. Then write 4 separate interpretations, one per chosen image. "
                        "Keep each interpretation concise, warm, and shareable."
                    ),
                },
            },
        )

    def export_test_bundle(self, when: datetime | None = None, output_root: str = "outputs/astrology_standalone_test") -> Path:
        when = when or datetime.now()
        ts = when.strftime("%Y%m%d_%H%M%S")
        out = Path(output_root) / ts
        out.mkdir(parents=True, exist_ok=True)
        jobs = self.build_jobs_for_date(when)
        plan = {
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "date": when.strftime("%Y-%m-%d"),
            "weekday": when.strftime("%A"),
            "rules_summary": {
                "normal_day": ["daily", "image_pick"],
                "sunday": ["weekly", "daily", "image_pick"],
                "month_end": ["monthly", "daily", "image_pick"],
                "month_end_sunday": ["monthly", "daily", "image_pick"],
            },
            "jobs": [asdict(j) for j in jobs],
        }
        write_json(out / "astrology_plan.json", plan)
        lines = [
            "ASTROLOGY STANDALONE TEST",
            f"Date: {plan['date']} ({plan['weekday']})",
            "",
            "Jobs:",
        ]
        for idx, j in enumerate(jobs, 1):
            lines.extend([
                f"{idx}. {j.label}",
                f"   FB: {j.fb_output}",
                f"   TT: {j.tt_output}",
                f"   Group: {j.content_group}",
                f"   Key: {j.key}",
                "",
            ])
        (out / "README_ASTROLOGY_TEST.txt").write_text("\n".join(lines), encoding="utf-8")
        return out
