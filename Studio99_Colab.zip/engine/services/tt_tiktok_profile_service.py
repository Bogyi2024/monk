from __future__ import annotations

import asyncio
import os
import threading
import time
from pathlib import Path
from typing import Any

from playwright.async_api import async_playwright


class TTTikTokProfileService:
    """
    Open/test persistent TikTok Playwright profiles from TT Web Manager.

    V3 important change:
    - Do NOT spawn a hidden child Python process and immediately report success.
    - Launch Playwright in a background thread inside TT Web Manager.
    - open_login() waits until the visible Chromium context really starts.
    - If Chromium fails to start, return the actual error to the UI.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root).resolve()
        self.profiles_root = self.root / "browser_profiles"
        self._jobs_lock = threading.Lock()
        self._jobs: dict[str, dict[str, Any]] = {}

    def _profile_path(self, profile_name: str) -> Path:
        name = str(profile_name or "").strip()
        if not name:
            raise ValueError("TikTok profile name is empty")
        if name in {".", ".."} or "/" in name or "\\" in name:
            raise ValueError("Invalid TikTok profile name")
        return self.profiles_root / name

    def _proxy(self) -> dict[str, str] | None:
        value = str(os.getenv("TIKTOK_PROXY") or "").strip()
        if not value or value.lower() in {"none", "off", "false", "0"}:
            return None
        return {"server": value}

    def status(self, profile_name: str) -> dict[str, Any]:
        try:
            p = self._profile_path(profile_name)
        except Exception as exc:
            return {"exists": False, "has_data": False, "reason": str(exc)}
        exists = p.exists() and p.is_dir()
        has_data = False
        if exists:
            indicators = [
                p / "Default" / "Cookies",
                p / "Default" / "Network" / "Cookies",
                p / "Local State",
            ]
            has_data = any(x.exists() for x in indicators)
            if not has_data:
                try:
                    has_data = any(p.iterdir())
                except Exception:
                    has_data = False

        running = False
        with self._jobs_lock:
            job = self._jobs.get(str(profile_name))
            if job:
                th = job.get("thread")
                running = bool(th and th.is_alive())

        return {
            "exists": exists,
            "has_data": has_data,
            "path": str(p),
            "login_browser_running": running,
        }

    async def _login_session(
        self,
        profile_name: str,
        ready: threading.Event,
        failed: threading.Event,
        box: dict[str, Any],
    ) -> None:
        profile_path = self._profile_path(profile_name)
        profile_path.mkdir(parents=True, exist_ok=True)
        context = None
        try:
            async with async_playwright() as pw:
                context = await pw.chromium.launch_persistent_context(
                    user_data_dir=str(profile_path),
                    headless=False,
                    args=[
                        "--disable-notifications",
                        "--disable-blink-features=AutomationControlled",
                    ],
                    proxy=self._proxy(),
                )

                # If this point is reached, a real visible Chromium window/context exists.
                box["started_at"] = time.time()
                box["profile_path"] = str(profile_path)
                ready.set()

                try:
                    await context.grant_permissions(
                        ["local-network-access"],
                        origin="https://www.tiktok.com",
                    )
                except Exception:
                    pass

                page = context.pages[0] if context.pages else await context.new_page()
                await page.goto(
                    "https://www.tiktok.com/tiktokstudio/upload",
                    timeout=120_000,
                    wait_until="domcontentloaded",
                )

                # Keep the login window alive for up to 15 minutes.
                # The user may close it manually after login; persistent profile data
                # is already being written to browser_profiles\<profile>.
                await page.wait_for_timeout(900_000)

        except Exception as exc:
            # Closing the browser manually after login can raise TargetClosedError.
            msg = str(exc)
            low = msg.lower()
            if ready.is_set() and any(x in low for x in ("target page", "targetclosed", "browser has been closed")):
                box["closed_by_user"] = True
            else:
                box["error"] = msg
                failed.set()
        finally:
            if context is not None:
                try:
                    await context.close()
                except Exception:
                    pass
            with self._jobs_lock:
                job = self._jobs.get(str(profile_name))
                if job is not None:
                    job["finished_at"] = time.time()

    def _thread_main(
        self,
        profile_name: str,
        ready: threading.Event,
        failed: threading.Event,
        box: dict[str, Any],
    ) -> None:
        try:
            asyncio.run(self._login_session(profile_name, ready, failed, box))
        except Exception as exc:
            box["error"] = str(exc)
            failed.set()

    def open_login(self, profile_name: str) -> dict[str, Any]:
        profile_name = str(profile_name or "").strip()
        profile_path = self._profile_path(profile_name)
        profile_path.mkdir(parents=True, exist_ok=True)

        with self._jobs_lock:
            existing = self._jobs.get(profile_name)
            if existing:
                th = existing.get("thread")
                if th and th.is_alive():
                    return {
                        "started": True,
                        "already_running": True,
                        "browser_confirmed": True,
                        "profile": profile_name,
                        "path": str(profile_path),
                    }

            ready = threading.Event()
            failed = threading.Event()
            box: dict[str, Any] = {}
            th = threading.Thread(
                target=self._thread_main,
                args=(profile_name, ready, failed, box),
                name=f"tt-tiktok-login-{profile_name}",
                daemon=True,
            )
            self._jobs[profile_name] = {
                "thread": th,
                "ready": ready,
                "failed": failed,
                "box": box,
                "created_at": time.time(),
            }
            th.start()

        # Wait briefly for actual Chromium context launch.
        deadline = time.time() + 20.0
        while time.time() < deadline:
            if ready.wait(timeout=0.20):
                return {
                    "started": True,
                    "already_running": False,
                    "browser_confirmed": True,
                    "profile": profile_name,
                    "path": str(profile_path),
                }
            if failed.is_set():
                break
            if not th.is_alive():
                break

        if failed.is_set() or not th.is_alive():
            reason = str(box.get("error") or "TikTok login browser process ended before Chromium opened.")
            raise RuntimeError(reason)

        raise RuntimeError(
            "TikTok login browser 20 seconds အတွင်း start confirm မရပါ။ "
            "Health / Logs ကိုစစ်ပါ သို့မဟုတ် Open / Login ပြန်နှိပ်ပါ။"
        )

    async def _test_async(self, profile_name: str) -> dict[str, Any]:
        p = self._profile_path(profile_name)
        if not p.exists() or not any(p.iterdir()):
            return {
                "logged_in": False,
                "profile": str(profile_name),
                "reason": "TikTok browser profile data မရှိသေးပါ။ Open / Login ကိုအရင်နှိပ်ပါ။",
            }

        with self._jobs_lock:
            job = self._jobs.get(str(profile_name))
            if job:
                th = job.get("thread")
                if th and th.is_alive():
                    return {
                        "logged_in": False,
                        "profile": str(profile_name),
                        "reason": "Login browser ဖွင့်ထားဆဲပါ။ Login ပြီး browser ကိုပိတ်ပြီးမှ Test Login နှိပ်ပါ။",
                    }

        context = None
        try:
            async with async_playwright() as pw:
                context = await pw.chromium.launch_persistent_context(
                    user_data_dir=str(p),
                    headless=True,
                    args=[
                        "--disable-notifications",
                        "--disable-blink-features=AutomationControlled",
                    ],
                    proxy=self._proxy(),
                )
                page = context.pages[0] if context.pages else await context.new_page()
                await page.goto(
                    "https://www.tiktok.com/tiktokstudio/upload",
                    timeout=90_000,
                    wait_until="domcontentloaded",
                )
                await page.wait_for_timeout(3500)
                url = str(page.url or "")
                lower_url = url.lower()

                login_marker = (
                    "login" in lower_url
                    or "signup" in lower_url
                    or await page.locator('input[name="username"]').count() > 0
                    or await page.locator('input[type="password"]').count() > 0
                )
                if login_marker:
                    return {
                        "logged_in": False,
                        "profile": str(profile_name),
                        "url": url,
                        "reason": "TikTok login required",
                    }

                if "tiktokstudio" in lower_url:
                    return {
                        "logged_in": True,
                        "profile": str(profile_name),
                        "url": url,
                        "reason": "TikTok Studio session active",
                    }

                return {
                    "logged_in": False,
                    "profile": str(profile_name),
                    "url": url,
                    "reason": "TikTok Studio session could not be confirmed",
                }
        except Exception as exc:
            msg = str(exc)
            low = msg.lower()
            if any(x in low for x in ("user data directory is already in use", "processsingleton", "profile in use")):
                msg = "TikTok profile browser ကဖွင့်ထားဆဲဖြစ်နိုင်ပါတယ်။ Browser ကိုပိတ်ပြီး Test Login ပြန်နှိပ်ပါ။"
            return {"logged_in": False, "profile": str(profile_name), "reason": msg}
        finally:
            if context is not None:
                try:
                    await context.close()
                except Exception:
                    pass

    def test_login(self, profile_name: str) -> dict[str, Any]:
        return asyncio.run(self._test_async(profile_name))
