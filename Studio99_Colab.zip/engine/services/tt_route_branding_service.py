from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Iterable

from PIL import Image


class TTRouteBrandingService:
    """Route-owned logo storage and deterministic upload-asset branding.

    Originals are never overwritten.  Every derivative name includes the category,
    route and branding hash, so two routes can never share a branded output by
    accident even when they reuse the same source media.
    """

    POSITIONS = {
        "top_left", "top_center", "top_right",
        "center_left", "center", "center_right",
        "bottom_left", "bottom_center", "bottom_right",
    }
    APPLY_TARGETS = {
        "facebook_post", "facebook_reel", "tiktok_reel",
        "facebook_image", "tiktok_image", "facebook_carousel",
        "tiktok_carousel", "video",
    }

    def __init__(self, project_root: str | Path = "."):
        self.root = Path(project_root).resolve()
        self.assets_root = self.root / "assets" / "route_logos"
        self.cache_root = self.root / "outputs" / "route_branding"
        self.assets_root.mkdir(parents=True, exist_ok=True)
        self.cache_root.mkdir(parents=True, exist_ok=True)
        self._last_cache_cleanup = 0.0

    def _cleanup_cache_if_due(self, retention_hours: float = 24.0) -> None:
        """Keep generated logo derivatives from becoming permanent storage."""
        now = time.time()
        if now - self._last_cache_cleanup < 3600:
            return
        self._last_cache_cleanup = now
        cutoff = now - max(1.0, float(retention_hours)) * 3600
        for path in self.cache_root.rglob("*"):
            if not path.is_file():
                continue
            try:
                if path.stat().st_mtime < cutoff:
                    path.unlink(missing_ok=True)
            except OSError:
                # An uploader/render may still have the derivative open.
                continue

    @staticmethod
    def _safe_key(value: str) -> str:
        value = str(value or "").strip().lower()
        clean = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in value)
        clean = clean.strip("_")
        if not clean:
            raise ValueError("Category and route keys are required for route branding")
        return clean

    def route_dir(self, category_key: str, route_key: str) -> Path:
        return self.assets_root / self._safe_key(category_key) / self._safe_key(route_key)

    def logo_path(self, category_key: str, route_key: str) -> Path:
        return self.route_dir(category_key, route_key) / "logo.png"

    @classmethod
    def normalize_config(cls, value: Any, *, logo_path: str = "") -> dict[str, Any]:
        raw = dict(value or {}) if isinstance(value, dict) else {}
        position = str(raw.get("position") or "top_right").strip().lower()
        if position not in cls.POSITIONS:
            position = "top_right"
        try:
            size = max(3.0, min(30.0, float(raw.get("size_percent", 10) or 10)))
        except (TypeError, ValueError):
            size = 10.0
        try:
            opacity = max(0.10, min(1.0, float(raw.get("opacity", 0.90) or 0.90)))
        except (TypeError, ValueError):
            opacity = 0.90
        apply_to = []
        for item in raw.get("apply_to") or ["facebook_post", "facebook_reel", "tiktok_reel", "facebook_image", "tiktok_image", "facebook_carousel", "tiktok_carousel", "video"]:
            key = str(item or "").strip().lower()
            if key in cls.APPLY_TARGETS and key not in apply_to:
                apply_to.append(key)
        return {
            "enabled": bool(raw.get("enabled", False)),
            "logo_path": str(logo_path or raw.get("logo_path") or "").replace("\\", "/"),
            "position": position,
            "size_percent": round(size, 2),
            "opacity": round(opacity, 2),
            "required": bool(raw.get("required", True)),
            "apply_to": apply_to,
        }

    def save_logo(self, category_key: str, route_key: str, data_url: str) -> str:
        if not isinstance(data_url, str) or "," not in data_url:
            raise ValueError("Logo upload payload is invalid")
        header, encoded = data_url.split(",", 1)
        allowed = {"data:image/png;base64", "data:image/jpeg;base64", "data:image/webp;base64"}
        if header.lower() not in allowed:
            raise ValueError("Logo must be a PNG, JPEG or WebP image")
        try:
            raw = base64.b64decode(encoded, validate=True)
        except Exception as exc:
            raise ValueError("Logo upload is not valid base64") from exc
        if not raw or len(raw) > 8 * 1024 * 1024:
            raise ValueError("Logo file must be between 1 byte and 8 MiB")
        try:
            with Image.open(io.BytesIO(raw)) as opened:
                if opened.width < 16 or opened.height < 16:
                    raise ValueError("Logo image is too small")
                if opened.width * opened.height > 24_000_000:
                    raise ValueError("Logo image dimensions are too large")
                image = opened.convert("RGBA")
                image.thumbnail((2048, 2048), Image.Resampling.LANCZOS)
        except ValueError:
            raise
        except Exception as exc:
            raise ValueError(f"Logo image could not be decoded: {exc}") from exc
        target = self.logo_path(category_key, route_key)
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_suffix(".tmp.png")
        image.save(temp, format="PNG", optimize=True)
        os.replace(temp, target)
        return target.relative_to(self.root).as_posix()

    def remove_logo(self, category_key: str, route_key: str) -> None:
        path = self.logo_path(category_key, route_key)
        path.unlink(missing_ok=True)

    def resolve_logo(self, category_key: str, route_key: str, branding: Any) -> tuple[Path | None, dict[str, Any]]:
        cfg = self.normalize_config(branding)
        expected = self.logo_path(category_key, route_key).resolve()
        configured = str(cfg.get("logo_path") or "").strip()
        path = (self.root / configured).resolve() if configured else expected
        # A route may only consume its own exact logo slot. This is the hard
        # cross-route isolation boundary.
        if path != expected:
            raise ValueError(f"Route logo path does not belong to {category_key}/{route_key}")
        if not path.is_file():
            if cfg.get("enabled") and cfg.get("required"):
                raise FileNotFoundError(f"Required route logo missing: {category_key}/{route_key}")
            return None, cfg
        return path, cfg

    @staticmethod
    def _target_enabled(cfg: dict[str, Any], destination: str) -> bool:
        if not cfg.get("enabled"):
            return False
        targets = set(cfg.get("apply_to") or [])
        destination = str(destination or "").strip().lower()
        if destination in targets:
            return True
        if destination.endswith("_image") and "facebook_post" in targets and destination.startswith("facebook"):
            return True
        if destination.endswith("_reel") and "video" in targets:
            return True
        return False

    @staticmethod
    def _xy(canvas_w: int, canvas_h: int, logo_w: int, logo_h: int, position: str) -> tuple[int, int]:
        margin = max(16, int(min(canvas_w, canvas_h) * 0.035))
        horizontal, vertical = "right", "top"
        parts = position.split("_")
        if position == "center":
            horizontal = vertical = "center"
        elif len(parts) == 2:
            vertical, horizontal = parts
        if horizontal == "left": x = margin
        elif horizontal == "center": x = (canvas_w - logo_w) // 2
        else: x = canvas_w - logo_w - margin
        if vertical == "top": y = margin
        elif vertical == "center": y = (canvas_h - logo_h) // 2
        else: y = canvas_h - logo_h - margin
        return max(0, x), max(0, y)

    @staticmethod
    def _brand_hash(source: Path, logo: Path, cfg: dict[str, Any], destination: str) -> str:
        payload = {
            "source": str(source.resolve()), "source_mtime": source.stat().st_mtime_ns,
            "logo": str(logo.resolve()), "logo_mtime": logo.stat().st_mtime_ns,
            # Destination selection decides whether branding applies, but the
            # pixels are identical. Excluding it lets FB + TikTok reuse one render.
            "config": cfg,
        }
        return hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()[:16]

    def brand_image(self, source: str | Path, category_key: str, route_key: str, branding: Any, destination: str) -> str:
        self._cleanup_cache_if_due()
        src = Path(source).resolve()
        logo, cfg = self.resolve_logo(category_key, route_key, branding)
        if logo is None or not self._target_enabled(cfg, destination):
            return str(src)
        digest = self._brand_hash(src, logo, cfg, destination)
        out_dir = self.cache_root / self._safe_key(category_key) / self._safe_key(route_key)
        out_dir.mkdir(parents=True, exist_ok=True)
        output = out_dir / f"{src.stem}.{digest}.png"
        if output.is_file() and output.stat().st_size > 1000:
            return str(output)
        with Image.open(src) as opened:
            canvas = opened.convert("RGBA")
        with Image.open(logo) as opened:
            mark = opened.convert("RGBA")
        target_w = max(24, int(canvas.width * float(cfg["size_percent"]) / 100.0))
        target_h = max(1, int(mark.height * target_w / max(1, mark.width)))
        max_h = max(24, int(canvas.height * 0.25))
        if target_h > max_h:
            target_h = max_h
            target_w = max(1, int(mark.width * target_h / max(1, mark.height)))
        mark = mark.resize((target_w, target_h), Image.Resampling.LANCZOS)
        if float(cfg["opacity"]) < 1.0:
            alpha = mark.getchannel("A").point(lambda value: int(value * float(cfg["opacity"])))
            mark.putalpha(alpha)
        canvas.alpha_composite(mark, self._xy(canvas.width, canvas.height, mark.width, mark.height, str(cfg["position"])))
        temp = output.with_suffix(".tmp.png")
        canvas.save(temp, format="PNG", optimize=True)
        os.replace(temp, output)
        return str(output)

    def brand_images(self, sources: Iterable[str | Path], category_key: str, route_key: str, branding: Any, destination: str) -> list[str]:
        return [self.brand_image(item, category_key, route_key, branding, destination) for item in sources]

    @staticmethod
    def _binary(name: str) -> str:
        configured = str(os.getenv(f"{name.upper()}_PATH") or "").strip()
        candidates = [configured, rf"C:\ffmpeg\bin\{name}.exe", shutil.which(name) or ""]
        for candidate in candidates:
            if candidate and Path(candidate).is_file():
                return str(Path(candidate).resolve())
        raise FileNotFoundError(f"{name} was not found for route-logo video rendering")

    def brand_video(self, source: str | Path, category_key: str, route_key: str, branding: Any, destination: str) -> str:
        self._cleanup_cache_if_due()
        src = Path(source).resolve()
        logo, cfg = self.resolve_logo(category_key, route_key, branding)
        if logo is None or not self._target_enabled(cfg, destination):
            return str(src)
        digest = self._brand_hash(src, logo, cfg, destination)
        out_dir = self.cache_root / self._safe_key(category_key) / self._safe_key(route_key)
        out_dir.mkdir(parents=True, exist_ok=True)
        output = out_dir / f"{src.stem}.{digest}.mp4"
        if output.is_file() and output.stat().st_size > 10_000:
            return str(output)
        ffmpeg = self._binary("ffmpeg")
        ffprobe = self._binary("ffprobe")
        probe = subprocess.run(
            [ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "json", str(src)],
            capture_output=True, text=True, encoding="utf-8", errors="replace", check=True,
        )
        streams = (json.loads(probe.stdout or "{}").get("streams") or [])
        if not streams:
            raise RuntimeError(f"Video dimensions unavailable for route branding: {src}")
        width, height = int(streams[0]["width"]), int(streams[0]["height"])
        with Image.open(logo) as opened:
            mark = opened.convert("RGBA")
        target_w = max(24, int(width * float(cfg["size_percent"]) / 100.0))
        target_h = max(1, int(mark.height * target_w / max(1, mark.width)))
        mark = mark.resize((target_w, target_h), Image.Resampling.LANCZOS)
        if float(cfg["opacity"]) < 1.0:
            alpha = mark.getchannel("A").point(lambda value: int(value * float(cfg["opacity"])))
            mark.putalpha(alpha)
        x, y = self._xy(width, height, mark.width, mark.height, str(cfg["position"]))
        overlay = out_dir / f"logo.{digest}.png"
        mark.save(overlay, format="PNG", optimize=True)
        temp = output.with_suffix(".tmp.mp4")
        cmd = [
            ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(src), "-i", str(overlay),
            "-filter_complex", f"[0:v][1:v]overlay={x}:{y}:format=auto[v]",
            "-map", "[v]", "-map", "0:a?", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
            "-c:a", "copy", "-movflags", "+faststart", str(temp),
        ]
        try:
            subprocess.run(cmd, check=True)
            os.replace(temp, output)
        finally:
            temp.unlink(missing_ok=True)
        return str(output)
