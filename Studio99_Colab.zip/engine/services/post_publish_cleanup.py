"""24-hour, receipt-backed cleanup of generated media; histories stay on disk."""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import tempfile
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

MEDIA = {'.mp4', '.mkv', '.mov', '.webm', '.avi', '.m4v', '.wav', '.mp3', '.m4a',
         '.flac', '.ogg', '.aac', '.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp', '.npy', '.npz'}

# Master posting and receipt retry must never open the same persistent profile
# concurrently. Each live job holds this lock; idle maintenance skips busy jobs.
PROFILE_MAINTENANCE_LOCK = asyncio.Lock()

def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8-sig'))

def timestamp(value: Any) -> datetime:
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, timezone.utc)
    parsed = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    return (parsed if parsed.tzinfo else parsed.astimezone()).astimezone(timezone.utc)

def posting_allows_profile_cleanup(
    state: dict[str, Any], decision: dict[str, Any], now: datetime, *, buffer_minutes: int = 10
) -> bool:
    """Return true only when browser maintenance cannot delay a scheduled post."""
    if state.get('current_job') or decision.get('status') == 'running':
        return False
    if not state.get('armed'):
        return True
    due = decision.get('next_at')
    if due is None:
        return True
    return timestamp(due) > timestamp(now) + timedelta(minutes=buffer_minutes)

def atomic(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=path.parent, suffix='.tmp')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)

class PostPublishCleanup:
    def __init__(self, root: str | Path, *, profile_cleanup_allowed: Callable[[], bool] | None = None):
        self.root = Path(root).resolve()
        self.workspace = self.root.parent
        self.profile_cleanup_allowed = profile_cleanup_allowed
        self.ledger = self.root / 'state/tt_media_cleanup'
        self.allowed = [self.root / 'outputs', self.root / 'downloads/recap_jobs']
        self.allowed += [self.workspace / p for p in
                         ('episode_splitter/pools', 'long_to_short/outputs',
                          'movie_review/output', 'grounded_news/output', 'novel_standalone/outputs')]

    def safe(self, path: Path) -> bool:
        resolved = (path if path.is_absolute() else self.root / path).resolve()
        denied = {'browser_profiles', 'browser_sessions', 'voxcpm_local_recap-v2'}
        return not denied.intersection(p.lower() for p in (*path.parts,*resolved.parts)) and any(
            resolved != base.resolve() and resolved.is_relative_to(base.resolve()) for base in self.allowed)

    def register(self, category: str, token: str, paths: list[str], completed_at: Any = None) -> None:
        paths = sorted({str((Path(p) if Path(p).is_absolute() else self.root / p).resolve()) for p in paths if p and self.safe(Path(p))})
        if not paths:
            return
        identity = hashlib.sha256(json.dumps([category, token, paths]).encode()).hexdigest()
        target = self.ledger / f'{identity}.json'
        if target.exists():
            return
        at = timestamp(completed_at) if completed_at else datetime.now(timezone.utc)
        atomic(target, {'category': category, 'content_id': token, 'paths': paths,
                        'completed_at': at.isoformat(), 'retention_hours': 24})

    def record_result(self, category: str, result: dict) -> None:
        if not result.get('success') or any(result.get(k) for k in
                ('pending', 'pending_secondary', 'pending_publish', 'no_work')):
            return
        if category == 'long_to_short':
            self.discover()
            return
        if category == 'novel':
            posts=read(self.root/'state/tt_novel_posts.json').get('posts') or {}
            completed={int(row.get('part_no') or 0) for row in posts.values()
                       if row.get('series_id')==result.get('series_id') and row.get('primary_complete')}
            if not {1,2,3,4}.issubset(completed): return
        assets = list(result.get('cleanup_assets') or result.get('posted_files') or [])
        if result.get('video_path'):
            assets.append(result['video_path'])
        if result.get('manifest'):
            assets.append(str(Path(result['manifest']).parent))
        if category == 'episode_splitter' and int(result.get('part_count') or 0)>0 and int(result.get('part_index') or 0)>=int(result['part_count']):
            assets.append(str(self.workspace/'episode_splitter/pools'/str(result['pool'])/'source_done'/str(result['source_folder'])))
        # Branded copies are generated upload assets too; keep the logo store.
        for raw in list(assets):
            source=Path(raw)
            if source.is_file():
                assets.extend(str(p) for p in (self.root/'outputs/route_branding'/category/str(result.get('route_key') or 'default')).glob(f'{source.stem}.*{source.suffix}'))
        self.register(category, str(result.get('content_id') or result.get('story_id') or ''), assets)

    def protected(self) -> list[Path]:
        protected = []
        def collect(value):
            if isinstance(value, dict):
                for child in value.values(): collect(child)
            elif isinstance(value, list):
                for child in value: collect(child)
            elif isinstance(value, str):
                path=Path(value)
                if path.is_absolute(): protected.append(path.resolve())
                elif value.replace('\\','/').startswith(('outputs/', 'downloads/')):
                    protected.append((self.root/path).resolve())
        for path in (self.root / 'state').glob('**/*.json'):
            parts=path.relative_to(self.root / 'state').parts
            if not ((len(parts)==1 and 'pending' in path.name.lower()) or
                    parts[0] in {'tt_long_to_short_pending','tt_episode_splitter_pending'}): continue
            if path.name.startswith('night_prepare_'): continue
            if path.name.startswith('tt_es_'): continue  # ephemeral subprocess JSON result, not an upload claim
            if path.name == 'tt_astrology_pending.json':
                continue  # Astrology receipts schedule only the completed logical item's media.
            collect(read(path))
        batch = self.root / 'state/tt_story_motion_batch.json'
        if batch.exists(): collect(read(batch))
        return protected

    def discover(self) -> None:
        registry=self.root/'downloads/recap_source_registry.json'
        if registry.exists():
            from services.storage_cleanup import _record_destination_contract, _terminal_time_for_video
            data=read(registry)
            for stream in (self.root/'downloads/recap_jobs').glob('*'):
                if not stream.is_dir(): continue
                for folder in stream.iterdir():
                    row=(data.get('videos') or {}).get(folder.name) or {}
                    if f'{stream.name}:{folder.name}' in (data.get('reservations') or {}): continue
                    required=_record_destination_contract(row,stream.name,[])
                    if required and set(required).issubset(row.get('posted_pages') or {}):
                        at=_terminal_time_for_video(row,required,3)
                        if at: self.register('recap',str(folder),[str(folder)],at.isoformat())
        # Existing completed stories have explicit final-destination markers.
        for marker in (self.root / 'outputs').glob('**/tt_master_completed.json'):
            row = read(marker)
            if row.get('completed') and row.get('primary_complete'):
                self.register('story', str(marker.parent), [str(marker.parent)],
                              row.get('completed_at') or marker.stat().st_mtime)
        movies = self.workspace / 'movie_review/state/processed_movies.json'
        if movies.exists():
            for token, row in (read(movies).get('movies') or {}).items():
                required = set(row.get('required_destinations') or [])
                done = row.get('destinations') or {}
                if row.get('status') == 'posted' and required and required.issubset(done) and row.get('manifest'):
                    times = [timestamp(done[k]['completed_at']) for k in required]
                    self.register('movie_review', token, [str(Path(row['manifest']).parent)], max(times).isoformat())
        for ledger in (self.root / 'state/tt_external_workers').glob('*/publish_receipts.json'):
            for token, row in (read(ledger).get('items') or {}).items():
                required = set(row.get('required_destinations') or [])
                done = row.get('destinations') or {}
                if row.get('acknowledged_at') and required and required.issubset(done) and row.get('manifest'):
                    self.register(ledger.parent.name, token, [str(Path(row['manifest']).parent)], row['acknowledged_at'])
        # Backfill old episode completions conservatively: secondary completion
        # was not timestamped in the old central receipt, so start 24h now.
        for ledger in (self.root / 'state/tt_completion_receipts').glob('*.json'):
            categories = read(ledger).get('categories') or {}
            astro=(categories.get('astrology') or {}).get('receipts') or {}
            for manifest in (self.root/'outputs/astrology_real_output_test').glob('*/real_output_result.json'):
                pack=read(manifest); outputs=pack.get('outputs') or {}
                jobs={'daily':('daily_tt_motion','daily_fb_carousel'), 'image_pick':('image_pick_motion',None),
                      'weekly':('weekly_motion','weekly_fb_carousel'),'monthly':('monthly_motion','monthly_fb_carousel')}
                needed={job for job,keys in jobs.items() if outputs.get(keys[0])}
                completed={job for job in needed if f"astrology:{pack.get('date')}:{job}" in astro}
                for job in completed:
                    paths=[outputs[key] for key in jobs[job] if key and outputs.get(key)]
                    self.register('astrology',f"astrology:{pack['date']}:{job}",paths,astro[f"astrology:{pack['date']}:{job}"]['completed_at'])
                if needed and needed==completed:
                    at=max(timestamp(astro[f"astrology:{pack['date']}:{job}"]['completed_at']) for job in needed)
                    self.register('astrology',str(manifest.parent),[str(manifest.parent)],at.isoformat())
            for token, row in ((categories.get('episode_splitter') or {}).get('receipts') or {}).items():
                parts = token.split(':')
                if len(parts) == 4 and parts[0] == 'episode' and parts[3].startswith('part'):
                    folder = self.workspace / 'episode_splitter/pools' / parts[1] / 'posted' / parts[2]
                    index = int(parts[3][4:])
                    paths = [str(p) for p in folder.glob(f'*part_{index:02d}*') if p.is_file()]
                    self.register('episode_splitter', token, paths)
        # Shared LTS render folders cannot be removed while another clip/mode
        # in that folder is still unposted. Individual completed modes can.
        protected=self.protected()
        configs=self.root/'config/tt_categories.json'
        routes=(((read(configs).get('categories') or {}).get('long_to_short') or {}).get('routes') or {}) if configs.exists() else {}
        aliases={'video':'transformative_envo_mm','voiceover_mm_sub':'transformative_envo_mm',
                 'original_sound_mm_sub':'original_audio_mm','voiceover_en_sub':'transformative_envo_en',
                 'original_sound_en_sub':'original_audio_en'}
        folders={}
        for inventory in (self.workspace/'long_to_short/state/tt_bridge/inventory').glob('*.json'):
            for bucket, group in (read(inventory).get('groups') or {}).items():
                for item in group.get('items') or []:
                    outputs={m:p for m,p in (item.get('outputs') or {}).items() if p}
                    done=item.get('primary_by_route') or {}
                    all_done=bool(outputs)
                    for mode, raw in outputs.items():
                        required={key for key,route in routes.items() if route.get('enabled',True)
                                  and f"{route.get('lts_category') or route.get('content_type') or 'motivation'}::{route.get('content_group') or 'main'}"==bucket
                                  and aliases.get(route.get('output_type'),route.get('output_type'))==mode}
                        completed=bool(required) and required.issubset(done) and all(done[key].get('output_mode')==mode for key in required)
                        path=Path(raw).resolve()
                        completed=completed and not any(path==p or path.is_relative_to(p) for p in protected)
                        all_done=all_done and completed
                        if completed:
                            self.register('long_to_short', f"lts:{item['content_id']}:{mode}", [raw])
                    if item.get('run_folder'):
                        folders.setdefault(item['run_folder'],[]).append(all_done)
        for folder, completed in folders.items():
            if completed and all(completed): self.register('long_to_short',folder,[folder])
        novel_posts=self.root/'state/tt_novel_posts.json'
        if novel_posts.exists():
            posts=read(novel_posts).get('posts') or {}
            for base in (self.workspace/'novel_standalone/outputs',self.root/'outputs/novel_standalone'):
                for manifest in base.glob('*/series.json'):
                    series=read(manifest)
                    series_id=series.get('series_id') or manifest.parent.name
                    completed={int(row.get('part_no') or 0) for row in posts.values() if row.get('series_id')==series_id and row.get('primary_complete')}
                    if series.get('complete') and {1,2,3,4}.issubset(completed):
                        self.register('novel',series_id,[str(manifest.parent)])

    def run(self, *, dry_run: bool = False, now: datetime | None = None) -> dict:
        now = now or datetime.now(timezone.utc)
        result = {'dry_run': dry_run, 'deleted_files': 0, 'freed_bytes': 0,
                  'eligible_bytes': 0, 'skipped_pending': 0, 'errors': []}
        try:
            if not dry_run: self.discover()
            protected = self.protected()
            seen=set()
            for ledger in sorted(self.ledger.glob('*.json')):
                ticket = read(ledger)
                if now - timestamp(ticket['completed_at']) < timedelta(hours=24): continue
                files = set()
                for raw in ticket['paths']:
                    path = Path(raw)
                    if not self.safe(path): raise ValueError(f'Cleanup path outside allowed media roots: {path}')
                    files.update(path.rglob('*') if path.is_dir() else [path])
                for path in sorted(files):
                    if path.suffix.lower() not in MEDIA or not path.is_file() or path.is_symlink(): continue
                    if path.resolve() in seen: continue
                    if not self.safe(path): raise ValueError(f'Unsafe media path: {path}')
                    if any(path.resolve() == p or path.resolve().is_relative_to(p) or p.is_relative_to(path.resolve()) for p in protected):
                        result['skipped_pending'] += 1; continue
                    size = path.stat().st_size
                    seen.add(path.resolve())
                    result['eligible_bytes'] += size
                    if not dry_run:
                        path.unlink()
                        result['deleted_files'] += 1; result['freed_bytes'] += size
                # Receipt/checkpoint/transcript files deliberately remain for dedupe/history.
        except Exception as exc:
            result['errors'].append(f'{type(exc).__name__}: {exc}')
        if not dry_run:
            atomic(self.root / 'state/tt_media_cleanup_last_run.json', {**result, 'ran_at': now.isoformat()})
        return result

    async def monitor(self) -> None:
        while True:
            try:
                result = await asyncio.to_thread(self.run)
                print(f"🧹 24h generated-media cleanup: files={result['deleted_files']} freed={result['freed_bytes']/1024**3:.2f}GB pending={result['skipped_pending']} errors={result['errors']}", flush=True)
                # Retry only persisted successful-post receipts. Browser close
                # or a failed upload never creates authorization for this task.
                profile_cleanup_allowed = (
                    self.profile_cleanup_allowed is None or self.profile_cleanup_allowed()
                )
                if ((self.root / 'state/tiktok_confirmed_posts').exists()
                        and profile_cleanup_allowed
                        and not PROFILE_MAINTENANCE_LOCK.locked()):
                    async with PROFILE_MAINTENANCE_LOCK:
                        child = await asyncio.create_subprocess_exec(
                            sys.executable, '-X', 'utf8', str(self.root/'cleanup_tiktok_drafts.py'), '--pending', '--delete', cwd=str(self.root))
                        try:
                            await asyncio.wait_for(child.wait(), timeout=300)
                        except (asyncio.TimeoutError, asyncio.CancelledError):
                            if child.returncode is None:
                                child.terminate()
                                await child.wait()
                            raise
                elif (self.root / 'state/tiktok_confirmed_posts').exists() and not profile_cleanup_allowed:
                    print('⏭️ TikTok confirmed-draft cleanup deferred: posting is running or due soon.', flush=True)
                dub = self.workspace / 'DUB_MASTER_VOXCPM_EXACT_STABLE_READABLE_TELEGRAM'
                if (dub / 'dubber/storage_cleanup.py').exists():
                    child = await asyncio.create_subprocess_exec(
                        sys.executable, '-X', 'utf8', '-m', 'dubber.storage_cleanup', cwd=str(dub))
                    await asyncio.wait_for(child.wait(), timeout=300)
            except Exception as exc:
                print(f'⚠️ Media cleanup warning: {exc}', flush=True)
            await asyncio.sleep(3600)
