from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Optional, Sequence

import edge_tts


class VoiceService:
    """Edge-TTS voice engine with segment-level timing support."""

    def __init__(
        self,
        voice: Optional[str] = None,
        rate: Optional[str] = None,
        ffmpeg_path: Optional[str] = None,
        ffprobe_path: Optional[str] = None,
    ) -> None:
        self.voice = voice or os.getenv("TTS_VOICE", "my-MM-ThihaNeural")
        self.rate = rate or os.getenv("TTS_RATE", "+35%")
        self.ffmpeg_path = self._resolve_binary(
            ffmpeg_path,
            os.getenv("FFMPEG_PATH"),
            r"C:\ffmpeg\bin\ffmpeg.exe",
            "ffmpeg",
        )
        self.ffprobe_path = self._resolve_binary(
            ffprobe_path,
            os.getenv("FFPROBE_PATH"),
            r"C:\ffmpeg\bin\ffprobe.exe",
            "ffprobe",
        )

    @staticmethod
    def _resolve_binary(*candidates: Optional[str]) -> str:
        executable_name = str(candidates[-1])
        for candidate in candidates[:-1]:
            if candidate and os.path.isfile(candidate):
                return os.path.abspath(candidate)
        found = shutil.which(executable_name)
        if found:
            return found
        raise FileNotFoundError(
            f"{executable_name} မတွေ့ပါ။ C:\\ffmpeg\\bin သို့ PATH/ENV ကိုစစ်ပါ။"
        )

    async def create_voice(self, text: str, output_path: str) -> str:
        """မြန်မာစာသားကို အသံဖိုင်အဖြစ် ပြောင်းသည်။"""
        text = (text or "").strip()
        if not text:
            raise ValueError("TTS text အလွတ်ဖြစ်နေပါသည်။")
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        if output.is_file() and output.stat().st_size < 500:
            output.unlink()
        timeout = max(30.0, min(300.0, float(os.getenv("RECAP_EDGE_TTS_TIMEOUT_SECONDS", "90"))))
        attempts = max(1, min(4, int(os.getenv("RECAP_EDGE_TTS_ATTEMPTS", "2"))))
        partial = output.with_name(output.stem + ".partial" + output.suffix)
        failures = []
        for attempt in range(1, attempts + 1):
            partial.unlink(missing_ok=True)
            try:
                communicate = edge_tts.Communicate(text, self.voice, rate=self.rate)
                await asyncio.wait_for(communicate.save(str(partial)), timeout=timeout)
                if not partial.is_file() or partial.stat().st_size < 500:
                    raise RuntimeError("TTS returned empty or incomplete audio")
                partial.replace(output)
                return str(output)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                failures.append(f"attempt {attempt}: {type(exc).__name__}: {str(exc)[:180]}")
                print(f"Edge TTS attempt {attempt}/{attempts} failed within {timeout:g}s: {type(exc).__name__}")
                if attempt < attempts:
                    await asyncio.sleep(min(5, attempt * 2))
            finally:
                partial.unlink(missing_ok=True)
        raise RuntimeError("Edge TTS failed: " + " | ".join(failures))

    def _probe_duration(self, audio_path: str) -> float:
        result = subprocess.run(
            [
                self.ffprobe_path,
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                os.path.abspath(audio_path),
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
        )
        if result.returncode != 0:
            raise RuntimeError(f"FFprobe audio error: {result.stderr.strip()}")
        return float(result.stdout.strip())

    def _concat_audio(self, parts: Sequence[str], output_path: str) -> str:
        if not parts:
            raise ValueError("Audio parts မရှိပါ။")
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)

        cmd = [self.ffmpeg_path, "-y", "-hide_banner", "-loglevel", "error"]
        for part in parts:
            cmd.extend(["-i", os.path.abspath(part)])

        input_labels = "".join(f"[{index}:a]" for index in range(len(parts)))
        filter_complex = f"{input_labels}concat=n={len(parts)}:v=0:a=1[aout]"
        suffix = output.suffix.lower()
        if suffix == ".mp3":
            codec_args = ["-c:a", "libmp3lame", "-b:a", "192k"]
        elif suffix == ".wav":
            codec_args = ["-c:a", "pcm_s16le"]
        else:
            codec_args = ["-c:a", "aac", "-b:a", "192k"]

        cmd.extend([
            "-filter_complex",
            filter_complex,
            "-map",
            "[aout]",
            "-ar",
            "48000",
            "-ac",
            "2",
            *codec_args,
            str(output),
        ])
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=180,
        )
        if result.returncode != 0:
            raise RuntimeError(f"Audio concat error: {result.stderr[-3000:]}")
        return str(output)

    async def create_segmented_voice(
        self,
        segments: Sequence[dict[str, Any]],
        output_path: str,
        work_dir: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Gemini narration segment တစ်ခုစီကို TTS သီးသန့်ထုတ်ပြီး concat လုပ်သည်။
        Actual audio duration ကိုတိုင်းတာထားသဖြင့် VideoService Smart Sync အတွက်
        audio_start/audio_end တိတိကျကျရသည်။
        """
        valid_segments = []
        for index, segment in enumerate(segments):
            text = str(segment.get("narration", segment.get("text", ""))).strip()
            if text:
                valid_segments.append((index, segment, text))
        if not valid_segments:
            raise ValueError("TTS ထုတ်ရန် narration segments မရှိပါ။")

        owns_temp = work_dir is None
        temp_dir = Path(work_dir or tempfile.mkdtemp(prefix="tts_segments_"))
        temp_dir.mkdir(parents=True, exist_ok=True)
        part_paths = []
        timing_segments = []
        cursor = 0.0

        try:
            for output_index, (source_index, source_segment, text) in enumerate(valid_segments):
                part_path = temp_dir / f"voice_{output_index:03d}.mp3"
                print(f"🗣️ TTS segment {output_index + 1}/{len(valid_segments)}: {text}")
                await self.create_voice(text, str(part_path))
                duration = self._probe_duration(str(part_path))
                if duration <= 0.05:
                    raise RuntimeError(f"TTS segment duration မမှန်ပါ: {text}")
                start = cursor
                end = cursor + duration
                timing_segments.append({
                    "source_index": source_index,
                    "audio_start": round(start, 3),
                    "audio_end": round(end, 3),
                    "audio_duration": round(duration, 3),
                    "text": text,
                    "video_start": source_segment.get("video_start", source_segment.get("start", 0.0)),
                    "video_end": source_segment.get("video_end", source_segment.get("end", 0.0)),
                })
                cursor = end
                part_paths.append(str(part_path))

            await asyncio.to_thread(self._concat_audio, part_paths, output_path)
            final_duration = self._probe_duration(output_path)
            script_text = " ".join(item["text"] for item in timing_segments)
            subtitle_segments = [
                {
                    "start": item["audio_start"],
                    "end": item["audio_end"],
                    "text": item["text"],
                }
                for item in timing_segments
            ]
            sync_segments = [
                {
                    "video_start": item["video_start"],
                    "video_end": item["video_end"],
                    "audio_start": item["audio_start"],
                    "audio_end": item["audio_end"],
                }
                for item in timing_segments
            ]
            return {
                "audio_path": os.path.abspath(output_path),
                "audio_duration": final_duration,
                "script_text": script_text,
                "segments": timing_segments,
                "subtitle_segments": subtitle_segments,
                "sync_segments": sync_segments,
            }
        finally:
            if owns_temp:
                shutil.rmtree(temp_dir, ignore_errors=True)
