from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any


class TTRouteRuntimeService:
    """Route/page-level runtime helpers shared by Today + rolling scheduler.

    V2.2 timing rule: only the SAME destination repeats are spaced. Repeating the
    same content category uses its configured gap, while a different category on
    that Page/account needs only a short cross-category safety gap.
    """

    CROSS_CATEGORY_DESTINATION_GAP_MINUTES = 15

    DEFAULT_ROUTE_POLICY = {
        "earliest_start": "09:00",
        "latest_finish": "20:50",
        "page_gap_minutes": 120,
        "estimated_runtime_minutes": 20,
        "priority": 50,
    }

    def __init__(self, settings_service):
        self.settings = settings_service

    @staticmethod
    def _iso(value: str | None) -> datetime | None:
        if not value:
            return None
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.astimezone()
            return dt
        except Exception:
            return None

    @staticmethod
    def _clock(day: datetime, hhmm: str, fallback: str) -> datetime:
        try:
            h, m = [int(x) for x in str(hhmm or fallback).split(":", 1)]
        except Exception:
            h, m = [int(x) for x in fallback.split(":", 1)]
        return day.replace(hour=h, minute=m, second=0, microsecond=0)

    def routes(self, category_key: str) -> dict[str, dict[str, Any]]:
        category = (self.settings.categories().get("categories") or {}).get(category_key) or {}
        routes = category.get("routes") or {}
        return routes if isinstance(routes, dict) else {}

    def enabled_routes(self, category_key: str) -> dict[str, dict[str, Any]]:
        return {k: v for k, v in self.routes(category_key).items() if isinstance(v, dict) and v.get("enabled", True)}

    def category_target(self, category_key: str, fallback: int = 0) -> int:
        routes = self.enabled_routes(category_key)
        if not routes:
            return max(0, int(fallback or 0))
        return sum(max(0, int(r.get("daily_limit") or 0)) for r in routes.values())

    def ensure_state(self, state: dict[str, Any]) -> bool:
        changed = False
        rr = state.setdefault("route_runtime", {})
        route_rows = rr.setdefault("routes", {})
        rr.setdefault("destinations", {})
        for category_key in (self.settings.categories().get("categories") or {}):
            cat_rows = route_rows.setdefault(category_key, {})
            for route_key, route in self.routes(category_key).items():
                if route_key not in cat_rows:
                    cat_rows[route_key] = {
                        "already_posted": 0,
                        "last_started_at": "",
                        "last_completed_at": "",
                        "last_finished_at": "",
                        "no_work_until": "",
                        "consecutive_failures": 0,
                        "last_failure_at": "",
                        "failure_cooldown_until": "",
                        "last_error": "",
                    }
                    changed = True
                row = cat_rows[route_key]
                for k, v in {
                    "already_posted": 0,
                    "last_started_at": "",
                    "last_completed_at": "",
                    "last_finished_at": "",
                    "no_work_until": "",
                    "consecutive_failures": 0,
                    "last_failure_at": "",
                    "failure_cooldown_until": "",
                    "last_error": "",
                }.items():
                    if k not in row:
                        row[k] = v
                        changed = True
            # Never delete route runtime history mid-day; a disabled/deleted route may
            # still be referenced by the current/pending job.
        return changed

    def route_policy(self, category_key: str, route_key: str) -> dict[str, Any]:
        cats = self.settings.categories().get("categories") or {}
        category = cats.get(category_key) or {}
        route = (category.get("routes") or {}).get(route_key) or {}
        cat_policy = category.get("schedule_policy") or {}
        raw = dict(self.DEFAULT_ROUTE_POLICY)
        raw.update({
            "earliest_start": cat_policy.get("earliest_start", raw["earliest_start"]),
            "latest_finish": cat_policy.get("latest_finish", raw["latest_finish"]),
            "page_gap_minutes": cat_policy.get("preferred_gap_minutes", raw["page_gap_minutes"]),
            "estimated_runtime_minutes": cat_policy.get("estimated_runtime_minutes", raw["estimated_runtime_minutes"]),
            "priority": cat_policy.get("priority", raw["priority"]),
        })
        raw.update(route.get("schedule_policy") or {})
        raw["page_gap_minutes"] = max(0, int(raw.get("page_gap_minutes") or 0))
        raw["estimated_runtime_minutes"] = max(1, int(raw.get("estimated_runtime_minutes") or 20))
        raw["priority"] = int(raw.get("priority") or 50)
        return raw

    def destination_keys(self, category_key: str, route_key: str) -> list[str]:
        """Only enabled primary destinations participate in repeat-gap timing."""
        try:
            resolved = self.settings.resolve_route(category_key, route_key)
        except Exception:
            return []
        out: list[str] = []
        fb_key = str(resolved.get("facebook_key") or "").strip()
        tt_key = str(resolved.get("tiktok_key") or "").strip()
        fb=resolved.get('facebook');tt=resolved.get('tiktok')
        if fb_key and fb and fb.get('enabled',True):
            out.append("fb:" + fb_key)
        if tt_key and tt and tt.get('enabled',True):
            out.append("tt:" + tt_key)
        return out

    def destination_gap_minutes(
        self,
        state: dict[str, Any],
        destination_key: str,
        fallback: int,
        category_key: str = "",
    ) -> int:
        """Return the applicable repeat gap for one shared destination.

        Routes in the same category use the largest configured gap in that
        category, preventing one sibling route from starving another. A different
        category may follow after 15 minutes, so Recap and Movie Review can share
        a Page without blocking one another for two hours. Legacy history without
        ``last_category`` keeps the old conservative all-category maximum.
        """
        destination_row = (
            ((state.get("route_runtime") or {}).get("destinations") or {}).get(destination_key)
            or {}
        )
        last_category = str(destination_row.get("last_category") or "").strip()
        current_category = str(category_key or "").strip()
        if last_category and current_category and last_category != current_category:
            return self.CROSS_CATEGORY_DESTINATION_GAP_MINUTES

        category_scope = current_category if last_category and current_category else ""
        gaps = [max(0, int(fallback or 0))]
        categories = self.settings.categories().get("categories") or {}
        category_rows = state.get("categories") or {}
        for category_key, category in categories.items():
            if category_scope and category_key != category_scope:
                continue
            if not isinstance(category, dict) or not category.get("enabled", True):
                continue
            category_row = category_rows.get(category_key) or {}
            if category_row and not category_row.get("run_today", False):
                continue
            target = category_row.get("target_override")
            if target is None:
                target = category_row.get("normal_target")
            if target is not None and int(category_row.get("already_posted") or 0) >= int(target or 0):
                continue
            for route_key in self.enabled_routes(category_key):
                if self.route_remaining(state, category_key, route_key) <= 0:
                    continue
                if destination_key not in self.destination_keys(category_key, route_key):
                    continue
                gaps.append(int(self.route_policy(category_key, route_key).get("page_gap_minutes") or 0))
        return max(gaps)

    def route_remaining(self, state: dict[str, Any], category_key: str, route_key: str) -> int:
        route = self.routes(category_key).get(route_key) or {}
        target = max(0, int(route.get("daily_limit") or 0))
        row = (((state.get("route_runtime") or {}).get("routes") or {}).get(category_key) or {}).get(route_key) or {}
        return max(0, target - max(0, int(row.get("already_posted") or 0)))

    def route_candidate(self, state: dict[str, Any], category_key: str, route_key: str, now: datetime, base: datetime, global_finish: datetime) -> dict[str, Any]:
        routes = self.routes(category_key)
        route = routes.get(route_key) or {}
        policy = self.route_policy(category_key, route_key)
        runtime = float(policy["estimated_runtime_minutes"])
        start = max(base, self._clock(now, str(policy.get("earliest_start") or "09:00"), "09:00"))
        finish = min(global_finish, self._clock(now, str(policy.get("latest_finish") or "20:50"), "20:50"))
        latest_start = finish - timedelta(minutes=runtime)
        category=(self.settings.categories().get("categories") or {}).get(category_key) or {}
        # Dynamic Astrology has a date-derived category target (2 normal / 3 special),
        # so a route's static daily_limit must not block the second/third item.
        # The category Today counter is the source of truth; this route only supplies
        # destinations + same-page spacing.
        remaining = 1 if category.get("production_mode")=="astrology_dynamic" else self.route_remaining(state, category_key, route_key)
        result = {
            "route_key": route_key,
            "route_label": str(route.get("label") or route_key),
            "remaining": remaining,
            "candidate": None,
            "latest_start": latest_start,
            "runtime_minutes": runtime,
            "priority": int(policy["priority"]),
            "policy": policy,
            "reason": "",
        }
        if not route.get("enabled", True):
            result["reason"] = "route_disabled"
            return result
        if remaining <= 0:
            result["reason"] = "route_target_complete"
            return result

        candidate = start
        route_state = (((state.get("route_runtime") or {}).get("routes") or {}).get(category_key) or {}).get(route_key) or {}
        no_work_until = self._iso(route_state.get("no_work_until"))
        if no_work_until and no_work_until > candidate:
            candidate = no_work_until
        failure_cooldown_until = self._iso(route_state.get("failure_cooldown_until"))
        if failure_cooldown_until and failure_cooldown_until > candidate:
            candidate = failure_cooldown_until
        page_gap = int(policy.get("page_gap_minutes") or 0)
        rr_state = (state.get("route_runtime") or {})
        dest_state = (rr_state.get("destinations") or {})
        blockers = []

        # V2.1: NO category/route-to-route spacing. Different pages may post close
        # together even inside the same category. Only reusing the SAME Facebook
        # Page or SAME TikTok account is blocked by page_gap_minutes below.
        for dest in self.destination_keys(category_key, route_key):
            effective_gap = self.destination_gap_minutes(
                state,
                dest,
                page_gap,
                category_key=category_key,
            )
            last = self._iso((dest_state.get(dest) or {}).get("last_completed_at"))
            if last and effective_gap > 0:
                due = last + timedelta(minutes=effective_gap)
                if due > candidate:
                    candidate = due
                    blockers.append(dest)
        if candidate > latest_start:
            if no_work_until and no_work_until > latest_start:
                result["reason"] = "route_no_work_hold"
            elif failure_cooldown_until and failure_cooldown_until > latest_start:
                result["reason"] = "route_failure_cooldown_too_late"
            else:
                result["reason"] = "page_gap_or_window_too_late"
            result["blocked_until"] = candidate
            result["blockers"] = blockers
            return result
        result["candidate"] = candidate
        result["blockers"] = blockers
        result["destination_keys"] = self.destination_keys(category_key, route_key)
        result["last_route_completed_at"] = route_state.get("last_completed_at") or ""
        result["reason"] = "page_gap:" + (",".join(blockers) if blockers else "ready")
        return result

    def unavailable_reason(self, state: dict[str, Any], category_key: str, now: datetime, base: datetime, global_finish: datetime, allowed_route_keys: set[str] | None = None) -> str:
        """Explain why routes exist but none can be queued instead of a vague label."""
        routes=self.enabled_routes(category_key)
        if allowed_route_keys is not None:
            routes={k:v for k,v in routes.items() if k in allowed_route_keys}
            if not routes:return 'waiting_for_preparation'
        if not routes:return 'no_enabled_routes'
        rows=[self.route_candidate(state,category_key,rk,now,base,global_finish) for rk in routes]
        if rows and all(r.get('reason')=='route_target_complete' for r in rows):
            catrow=(state.get('categories') or {}).get(category_key) or {}
            left=max(0,int(catrow.get('normal_target') or 0)-int(catrow.get('already_posted') or 0))
            return f'route_targets_complete_category_left_{left}' if left>0 else 'route_targets_complete'
        gap=[r for r in rows if r.get('reason')=='page_gap_or_window_too_late']
        if gap:
            r=min(gap,key=lambda x:x.get('blocked_until') or global_finish)
            due=r.get('blocked_until'); latest=r.get('latest_start'); blockers=','.join(r.get('blockers') or []) or 'same_destination'
            due_s=due.astimezone().strftime('%I:%M%p') if due else '?'
            latest_s=latest.astimezone().strftime('%I:%M%p') if latest else '?'
            return f'same_destination_gap_until_{due_s}_after_latest_start_{latest_s}:{blockers}'
        reasons=','.join(sorted({str(r.get('reason') or 'unknown') for r in rows}))
        return 'routes_not_ready:'+reasons

    def choose_route(self, state: dict[str, Any], category_key: str, now: datetime, base: datetime, global_finish: datetime, pending_route_key: str = "", allowed_route_keys: set[str] | None = None) -> dict[str, Any] | None:
        routes = self.enabled_routes(category_key)
        if allowed_route_keys is not None:
            routes = {k:v for k,v in routes.items() if k in allowed_route_keys}
        if not routes:
            return None
        candidates = []
        for route_key in routes:
            row = self.route_candidate(state, category_key, route_key, now, base, global_finish)
            if row.get("candidate") is not None:
                candidates.append(row)
        if not candidates:
            return None
        if pending_route_key:
            for row in candidates:
                if row["route_key"] == pending_route_key:
                    # Pending destination retries reuse already-generated content and
                    # should not be blocked by a normal posting gap for generation.
                    row = dict(row)
                    row["candidate"] = base
                    row["reason"] = "pending_route_retry"
                    return row
        candidates.sort(key=lambda x: (x["candidate"], -int(x.get("priority", 50)), x["route_key"]))
        chosen = candidates[0]
        # When several cards/routes are runnable, rotate all of them by progress
        # and last attempt.  This also prevents a failing alphabetically-first
        # route (usually "default") from monopolising a multi-route category.
        if chosen["candidate"] <= now + timedelta(seconds=1):
            contenders = [row for row in candidates if row["candidate"] <= now + timedelta(seconds=1)]
        else:
            cutoff = chosen["candidate"] + timedelta(seconds=1)
            contenders = [row for row in candidates if row["candidate"] <= cutoff]
        if len(contenders) > 1:
            route_rows = (((state.get("route_runtime") or {}).get("routes") or {}).get(category_key) or {})

            def fair_route_key(candidate_row: dict[str, Any]):
                route_key = str(candidate_row["route_key"])
                route = self.routes(category_key).get(route_key) or {}
                runtime_row = route_rows.get(route_key) or {}
                target = max(1, int(route.get("daily_limit") or 0))
                progress = int(runtime_row.get("already_posted") or 0) / target
                completed = self._iso(runtime_row.get("last_completed_at"))
                finished = self._iso(runtime_row.get("last_finished_at"))
                return (
                    progress,
                    completed.timestamp() if completed else float("-inf"),
                    finished.timestamp() if finished else float("-inf"),
                    -int(candidate_row.get("priority", 50)),
                    route_key,
                )

            chosen = min(contenders, key=fair_route_key)
        return chosen

    def mark_started(self, state: dict[str, Any], category_key: str, route_key: str, now: datetime) -> None:
        self.ensure_state(state)
        row = state["route_runtime"]["routes"].setdefault(category_key, {}).setdefault(route_key, {})
        row["last_started_at"] = now.isoformat(timespec="seconds")

    def mark_finished(self, state: dict[str, Any], category_key: str, route_key: str, now: datetime, success: bool) -> None:
        self.ensure_state(state)
        row = state["route_runtime"]["routes"].setdefault(category_key, {}).setdefault(route_key, {})
        row["last_finished_at"] = now.isoformat(timespec="seconds")
        if not success:
            return
        row["no_work_until"] = ""
        row["consecutive_failures"] = 0
        row["last_failure_at"] = ""
        row["failure_cooldown_until"] = ""
        row["last_error"] = ""
        row["already_posted"] = int(row.get("already_posted") or 0) + 1
        row["last_completed_at"] = now.isoformat(timespec="seconds")
        for dest in self.destination_keys(category_key, route_key):
            destination = state["route_runtime"]["destinations"].setdefault(dest, {})
            destination["last_completed_at"] = now.isoformat(timespec="seconds")
            destination["last_category"] = category_key
            destination["last_route"] = route_key
