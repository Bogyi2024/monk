from __future__ import annotations

import asyncio
from typing import Any


_HANDLER_MARKER = "_tt_playwright_target_closed_filter"


def is_unhandled_target_closed(context: dict[str, Any]) -> bool:
    """Match only event-loop noise from an already-unwound Playwright Future.

    Awaited Playwright calls still raise TargetClosedError normally. This predicate
    is used only by asyncio's last-resort exception handler after nobody owns the
    internal Future anymore.
    """
    message = str(context.get("message") or "").casefold()
    exception = context.get("exception")
    exception_name = type(exception).__name__.casefold() if exception is not None else ""
    exception_text = str(exception or "").casefold()
    unhandled_future = "future exception was never retrieved" in message
    target_closed = (
        exception_name == "targetclosederror"
        or "target page, context or browser has been closed" in exception_text
    )
    return bool(unhandled_future and target_closed)


def install_playwright_target_closed_filter() -> bool:
    """Install one loop-local filter while preserving every existing handler."""
    loop = asyncio.get_running_loop()
    if bool(getattr(loop, _HANDLER_MARKER, False)):
        return False

    previous = loop.get_exception_handler()

    def handler(active_loop: asyncio.AbstractEventLoop, context: dict[str, Any]) -> None:
        if is_unhandled_target_closed(context):
            return
        if previous is not None:
            previous(active_loop, context)
        else:
            active_loop.default_exception_handler(context)

    loop.set_exception_handler(handler)
    setattr(loop, _HANDLER_MARKER, True)
    return True


async def settle_playwright_close_callbacks() -> None:
    """Give close-related protocol callbacks two loop turns to finish quietly."""
    await asyncio.sleep(0)
    await asyncio.sleep(0)
