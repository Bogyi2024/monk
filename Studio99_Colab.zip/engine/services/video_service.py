from __future__ import annotations

import json
import math
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Iterable, Optional, Sequence

try:
    import cv2  # type: ignore
except Exception:  # OpenCV မရှိလည်း video render ဆက်လုပ်နိုင်ရန်
    cv2 = None

try:
    import easyocr  # type: ignore
except Exception:  # EasyOCR မရှိလည်း default subtitle area သုံးမည်
    easyocr = None

try:
    import yt_dlp  # type: ignore
except Exception:
    yt_dlp = None

from services.source_download_auth_service import cookiefile_ydl_option, resolve_source_cookie_file


class SourceDownloadError(RuntimeError):
    """Transient source fetch failure; posting destinations must not be penalized."""


class VideoService:
    """
    Personal Auto-Post Video Engine V2

    လက်ရှိ auto_scheduler_main.py က ခေါ်နေသော API ကို မဖျက်ထားပါ။

        edit_video_with_audio(
            video_input,
            audio_input,
            output_path,
            caption_text="",
            logo_path="logo.png",
            top_text="",
            bottom_text="",
        )

    အသစ်ထည့်ထားသော အဓိကစနစ်များ
    ---------------------------
    1. Smart Sync
       - သင့်တော်သောအတိုင်းအတာအတွင်း video speed ကို audio duration နဲ့ညှိမည်။
       - audio အလွန်တိုပါက max speed အထိမြန်ပြီး ကျန် video ကို trim မည်။
       - audio အလွန်ရှည်ပါက max slow အထိနှေးပြီး နောက်ဆုံး frame ကို freeze မည်။
       - sync_segments ပေးထားပါက အပိုင်းတစ်ပိုင်းချင်း duration sync လုပ်နိုင်သည်။

    2. Timed Myanmar subtitles
       - caption တစ်ခုလုံး အမြဲတမ်းပေါ်နေခြင်းမဟုတ်တော့ဘဲ အပိုင်းလိုက် ASS subtitle ထိုးမည်။

    3. Robust rendering
       - NVIDIA NVENC မရပါက libx264 CPU encoder သို့ အလိုအလျောက် fallback လုပ်မည်။
       - EasyOCR ကို startup မှာမတင်ဘဲ လိုမှသာ lazy-load လုပ်မည်။
       - တစ်ပြိုင်နက် job များ run လျှင် temp file မတိုက်စေရန် unique temp directory သုံးမည်။
    """

    def __init__(
        self,
        ffmpeg_path: Optional[str] = None,
        ffprobe_path: Optional[str] = None,
        temp_dir: Optional[str] = None,
        subtitle_font_size: int = 36,
        subtitle_y_fraction: float = 0.85,
    ) -> None:
        self.ffmpeg_path = self._resolve_binary(
            explicit=ffmpeg_path,
            env_name="FFMPEG_PATH",
            common_paths=[r"C:\ffmpeg\bin\ffmpeg.exe"],
            executable_name="ffmpeg",
        )
        self.ffprobe_path = self._resolve_binary(
            explicit=ffprobe_path,
            env_name="FFPROBE_PATH",
            common_paths=[r"C:\ffmpeg\bin\ffprobe.exe"],
            executable_name="ffprobe",
        )

        default_temp = os.getenv("RECAP_TEMP_DIR") or r"C:\recap_temp"
        self.temp_dir = Path(temp_dir or default_temp)
        self.temp_dir.mkdir(parents=True, exist_ok=True)

        self.subtitle_font_size = int(subtitle_font_size)
        self.subtitle_y_fraction = min(max(float(subtitle_y_fraction), 0.55), 0.95)

        self.font_path = self._find_myanmar_font()
        self.font_name = self._font_family_name(self.font_path)

        self._ocr_reader: Any = None
        self._encoder_cache: Optional[set[str]] = None

        print(f"✅ FFmpeg: {self.ffmpeg_path}")
        print(f"✅ FFprobe: {self.ffprobe_path}")
        print(f"✅ Subtitle font: {self.font_name} ({self.font_path or 'system font'})")

    # ------------------------------------------------------------------
    # Setup helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _resolve_binary(
        explicit: Optional[str],
        env_name: str,
        common_paths: Sequence[str],
        executable_name: str,
    ) -> str:
        candidates: list[str] = []
        if explicit:
            candidates.append(explicit)
        env_value = os.getenv(env_name)
        if env_value:
            candidates.append(env_value)
        candidates.extend(common_paths)

        which_value = shutil.which(executable_name)
        if which_value:
            candidates.append(which_value)
        if os.name == "nt":
            which_exe = shutil.which(f"{executable_name}.exe")
            if which_exe:
                candidates.append(which_exe)

        for candidate in candidates:
            if candidate and os.path.isfile(candidate):
                return os.path.abspath(candidate)

        raise FileNotFoundError(
            f"{executable_name} မတွေ့ပါ။ {env_name} သတ်မှတ်ပါ သို့မဟုတ် "
            f"C:\\ffmpeg\\bin ထဲတွင် ထည့်ပါ။"
        )

    def _find_myanmar_font(self) -> Optional[str]:
        env_font = os.getenv("SUBTITLE_FONT_PATH")
        if env_font and os.path.isfile(env_font):
            return os.path.abspath(env_font)

        user_profile = os.getenv("USERPROFILE", "")
        local_app_data = os.getenv("LOCALAPPDATA", "")
        possible_dirs = [
            os.path.join(local_app_data, "Microsoft", "Windows", "Fonts") if local_app_data else "",
            os.path.join(user_profile, "AppData", "Local", "Microsoft", "Windows", "Fonts")
            if user_profile
            else "",
            r"C:\Windows\Fonts",
        ]

        # ပထမရွေးချယ်မှုမှ နောက်ဆုံး fallback အထိ
        preferred_keywords = [
            "notosansmyanmar",
            "noto sans myanmar",
            "pyidaungsu",
            "myanmartext",
            "myanmar text",
            "burma020",
            "burma",
        ]

        discovered: list[tuple[int, str]] = []
        for directory in possible_dirs:
            if not directory or not os.path.isdir(directory):
                continue
            try:
                for filename in os.listdir(directory):
                    lower = filename.lower()
                    if not lower.endswith((".ttf", ".otf", ".ttc")):
                        continue
                    compact = lower.replace("-", "").replace("_", "")
                    for priority, keyword in enumerate(preferred_keywords):
                        keyword_compact = keyword.replace(" ", "").replace("-", "")
                        if keyword_compact in compact:
                            discovered.append((priority, os.path.join(directory, filename)))
                            break
            except OSError:
                continue

        if discovered:
            discovered.sort(key=lambda item: item[0])
            return os.path.abspath(discovered[0][1])

        # ASS renderer က system font ရှာသုံးနိုင်သဖြင့် None ခွင့်ပြုထားသည်။
        return None

    @staticmethod
    def _font_family_name(font_path: Optional[str]) -> str:
        if not font_path:
            return "Noto Sans Myanmar"
        name = Path(font_path).stem.lower().replace("_", " ").replace("-", " ")
        if "noto" in name and "myanmar" in name:
            return "Noto Sans Myanmar"
        if "pyidaungsu" in name:
            return "Pyidaungsu"
        if "myanmartext" in name.replace(" ", ""):
            return "Myanmar Text"
        if "burma" in name:
            return "Burma 020"
        return Path(font_path).stem

    # ------------------------------------------------------------------
    # Download
    # ------------------------------------------------------------------
    @staticmethod
    def _platform_for_url(url: str) -> str:
        low = str(url or "").lower()
        if "tiktok.com" in low or "vt.tiktok.com" in low:
            return "tiktok"
        if "youtube.com" in low or "youtu.be" in low:
            return "youtube"
        return "other"

    @staticmethod
    def _is_youtube_antibot_error(error: Exception | str) -> bool:
        """True for YouTube login / anti-bot / media 403 failures worth auth retry."""
        message = str(error or "").casefold()
        markers = (
            "sign in to confirm you’re not a bot",
            "sign in to confirm you're not a bot",
            "confirm you’re not a bot",
            "confirm you're not a bot",
            "use --cookies-from-browser or --cookies for the authentication",
            "use --cookies-from-browser",
            "http error 403",
            "403: forbidden",
        )
        return any(marker in message for marker in markers)

    @staticmethod
    def _is_retryable_download_error(error: Exception | str) -> bool:
        message = str(error or "").casefold()
        markers = (
            "http error 403",
            "403: forbidden",
            "http error 429",
            "too many requests",
            "unable to download video data",
            "requested format is not available",
            "fragment",
            "timed out",
            "connection reset",
        )
        return any(marker in message for marker in markers)

    def download_video(
        self,
        url: str,
        output_path: str,
        source_context: Optional[dict[str, Any]] = None,
    ) -> str:
        """Download YouTube/TikTok source with cookie.txt + resilient fallbacks.

        The source cookie is shared by source scan and media download only. Posting
        browser profiles are intentionally separate. A terminal fetch failure is
        raised as SourceDownloadError so Recap can soft-skip the source without
        incrementing FB/TikTok destination failure counters.
        """
        if yt_dlp is None:
            raise RuntimeError("yt-dlp package မတင်ရသေးပါ။ pip install yt-dlp လုပ်ပါ။")

        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        platform = self._platform_for_url(url)
        if platform == "tiktok" and source_context:
            # Profile scans keep secUid for durable API identity, but downloads
            # must use the public @username URL. This also keeps the command
            # equivalent to: yt-dlp --cookies cookie.txt <public-video-url>.
            profile_url = str(source_context.get("channel_url") or "").strip()
            video_id = str(source_context.get("video_id") or "").strip()
            username_match = re.search(r"tiktok\.com/@([^/?#]+)", profile_url, re.IGNORECASE)
            if username_match and video_id:
                url = f"https://www.tiktok.com/@{username_match.group(1)}/video/{video_id}"
        cookie_path = resolve_source_cookie_file()
        cookie_opts = cookiefile_ydl_option()

        print(f"📥 ဗီဒီယိုကို ဒေါင်းလုဒ်ဆွဲနေပါသည်: {url}")
        if cookie_opts:
            print(f"🍪 Source cookie: {cookie_path}")
        elif platform in {"youtube", "tiktok"}:
            print(f"⚠️ Source cookie မတွေ့ပါ: {cookie_path}")

        referer = "https://www.tiktok.com/" if platform == "tiktok" else "https://www.youtube.com/"
        base_opts: dict[str, Any] = {
            # TikTok currently exposes its separate audio track as format `audio`
            # (usually MP3), so an M4A-only selector can silently yield video-only.
            # Keep this exactly equivalent to the user's proven yt-dlp command.
            "format": (
                "bestvideo+bestaudio/best"
                if platform == "tiktok"
                else "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best"
            ),
            "merge_output_format": "mp4",
            "outtmpl": str(output),
            "quiet": True,
            "no_warnings": True,
            "retries": 10,
            "fragment_retries": 10,
            "continuedl": True,
            "noplaylist": True,
            **cookie_opts,
        }
        if platform != "tiktok":
            base_opts["http_headers"] = {
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/131.0.0.0 Safari/537.36"
                ),
                "Referer": referer,
                "Accept-Language": "en-US,en;q=0.9",
            }

        proxy = os.getenv("DOWNLOAD_PROXY") or os.getenv("HTTPS_PROXY")
        if proxy:
            base_opts["proxy"] = proxy

        def _cleanup_partial(*, force_output: bool = False) -> None:
            for candidate in (output, Path(str(output) + ".part"), Path(str(output) + ".ytdl")):
                try:
                    if candidate.exists() and (force_output or candidate.stat().st_size < 5_000):
                        candidate.unlink()
                except Exception:
                    pass
            if force_output:
                # yt-dlp separate-stream intermediates use source.f<format>.ext.
                for candidate in output.parent.glob(output.stem + ".f*"):
                    try:
                        if candidate.is_file():
                            candidate.unlink()
                    except Exception:
                        pass

        def _download_has_audio() -> bool:
            try:
                info = self._probe(str(output))
            except Exception:
                return False
            return any(str(stream.get("codec_type") or "").lower() == "audio" for stream in info.get("streams") or [])

        def _run_download(extra_opts: Optional[dict[str, Any]] = None) -> None:
            opts = dict(base_opts)
            if extra_opts:
                extra_opts = dict(extra_opts)
                if extra_opts.pop("_drop_cookiefile", False):
                    opts.pop("cookiefile", None)
                # Merge nested headers/extractor_args rather than replacing base data.
                for key, value in extra_opts.items():
                    if key in {"http_headers", "extractor_args"} and isinstance(value, dict):
                        merged = dict(opts.get(key) or {})
                        merged.update(value)
                        opts[key] = merged
                    else:
                        opts[key] = value
            with yt_dlp.YoutubeDL(opts) as ydl:
                ydl.download([url])

        attempts: list[tuple[str, dict[str, Any]]] = [("standard", {})]
        if platform == "youtube":
            # Progressive MP4 fallback avoids some DASH/googlevideo 403 cases.
            attempts.extend(
                [
                    ("youtube-progressive", {"format": "best[ext=mp4]/best"}),
                    (
                        "youtube-alt-client",
                        {
                            "format": "bestvideo+bestaudio/best",
                            "extractor_args": {"youtube": {"player_client": ["web_safari", "web"]}},
                        },
                    ),
                ]
            )
        elif platform == "tiktok":
            attempts.extend(
                [
                    ("tiktok-no-cookie-av", {"format": "bestvideo+bestaudio/best", "_drop_cookiefile": True}),
                    ("tiktok-watermarked-audio", {"format": "download"}),
                    (
                        "tiktok-h264-plus-audio",
                        {"format": "bestvideo[vcodec^=avc]+bestaudio/bestvideo+bestaudio/best"},
                    ),
                    ("tiktok-mobile-header", {"format": "bestvideo+bestaudio/best", "http_headers": {"Referer": "https://www.tiktok.com/"}}),
                ]
            )

        errors: list[str] = []
        for index, (label, extra) in enumerate(attempts, start=1):
            try:
                if index > 1:
                    print(f"🔁 Source download retry {index}/{len(attempts)}: {label}")
                _cleanup_partial(force_output=index > 1)
                _run_download(extra)
                if output.exists() and output.stat().st_size >= 5_000:
                    if platform == "tiktok" and not _download_has_audio():
                        raise RuntimeError("downloaded TikTok media has no audio stream")
                    print(f"✅ Download ပြီးပါပြီ: {output}")
                    return str(output)
                raise RuntimeError(f"download output missing or too small: {output}")
            except Exception as exc:
                errors.append(f"{label}: {exc}")
                low_error = str(exc).lower()
                if platform == "tiktok" and (
                    "unable to download webpage: http error 403" in low_error
                    or "unable to extract universal data" in low_error
                ):
                    # A stale exported cookie can itself trigger TikTok's
                    # rehydration rejection. Always allow the exact no-cookie A/V
                    # fallback once; format-only retries after that cannot help.
                    if label != "standard" or not cookie_opts:
                        break
                # Non-network/non-format failures are unlikely to improve with another profile.
                if index == 1 and "has no audio stream" not in low_error and not self._is_retryable_download_error(exc):
                    break

        # Preserve the old Firefox fallback for YouTube when cookie.txt is absent
        # or stale. It is last-resort only and never mutates the canonical cookie.
        if platform == "youtube":
            last_message = errors[-1] if errors else ""
            if self._is_youtube_antibot_error(last_message):
                try:
                    print("🦊 YouTube fallback: Firefox browser cookies နဲ့ နောက်ဆုံးတစ်ကြိမ် retry...")
                    _cleanup_partial()
                    fallback = dict(base_opts)
                    fallback.pop("cookiefile", None)
                    fallback["cookiesfrombrowser"] = ("firefox",)
                    fallback["format"] = "best[ext=mp4]/best"
                    with yt_dlp.YoutubeDL(fallback) as ydl:
                        ydl.download([url])
                    if output.exists() and output.stat().st_size >= 5_000:
                        print(f"✅ Firefox fallback download အောင်မြင်ပါပြီ: {output}")
                        return str(output)
                except Exception as exc:
                    errors.append(f"firefox-cookie-fallback: {exc}")

        _cleanup_partial(force_output=platform == "tiktok")
        cookie_hint = (
            f" cookie={cookie_path}" if cookie_opts else f" cookie missing ({cookie_path})"
        )
        detail = " | ".join(errors[-4:])
        raise SourceDownloadError(
            f"{platform or 'source'} download failed after retries;{cookie_hint}. {detail}"
        )


    # ------------------------------------------------------------------
    # Probe / validation
    # ------------------------------------------------------------------
    def _probe(self, media_path: str) -> dict[str, Any]:
        cmd = [
            self.ffprobe_path,
            "-v",
            "error",
            "-show_streams",
            "-show_format",
            "-of",
            "json",
            os.path.abspath(media_path),
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if result.returncode != 0:
            raise RuntimeError(f"FFprobe error: {result.stderr.strip()}")
        return json.loads(result.stdout)

    @staticmethod
    def _duration_from_probe(info: dict[str, Any]) -> float:
        try:
            return float(info.get("format", {}).get("duration", 0.0))
        except (TypeError, ValueError):
            return 0.0

    def get_media_duration(self, media_path: str) -> float:
        """Return media duration in seconds using the configured ffprobe binary.

        This is the public duration helper used by the Whisper test and recap
        scheduler. It validates the input and raises a clear error when ffprobe
        cannot report a usable duration.
        """
        path = Path(media_path).resolve()
        if not path.exists() or not path.is_file():
            raise FileNotFoundError(f"Media file မတွေ့ပါ: {path}")

        duration = self._duration_from_probe(self._probe(str(path)))
        if duration <= 0:
            raise RuntimeError(f"Media duration ကို မဖတ်နိုင်ပါ: {path}")
        return duration

    @staticmethod
    def _video_dimensions(info: dict[str, Any]) -> tuple[int, int]:
        for stream in info.get("streams", []):
            if stream.get("codec_type") == "video":
                return int(stream.get("width", 0)), int(stream.get("height", 0))
        return 0, 0

    def _validate_output(self, output_path: str, expected_duration: float) -> None:
        output = Path(output_path)
        if not output.exists() or output.stat().st_size < 10_000:
            raise RuntimeError("Final video ဖိုင်မထွက်ပါ သို့မဟုတ် ဖိုင်အရွယ်အစားအလွန်သေးနေပါသည်။")

        info = self._probe(str(output))
        duration = self._duration_from_probe(info)
        if duration <= 0:
            raise RuntimeError("Final video duration ကို မဖတ်နိုင်ပါ။")
        if abs(duration - expected_duration) > max(1.5, expected_duration * 0.08):
            print(
                f"⚠️ Output duration မျှော်မှန်းချက်နှင့် အနည်းငယ်ကွာသည်: "
                f"expected={expected_duration:.2f}s, actual={duration:.2f}s"
            )

    # ------------------------------------------------------------------
    # Text / subtitle helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _clean_caption(text: str) -> str:
        fluff_phrases = [
            "ဒီ video မှာပါတဲ့ စကားလုံးတွေကို သဘာ၀ကျကျဘာသာပြန်ပေးလိုက်ပါတယ်",
            "ဒီ video မှာပါတဲ့ စကားလုံးတွေကို သဘာဝကျကျဘာသာပြန်ပေးလိုက်ပါတယ်",
            "ဒီဗီဒီယိုအတွက် မြန်မာဘာသာစကားနဲ့ ပြန်ဆိုပေးလိုက်ပါတယ်",
            "ဒီဗီဒီယိုအတွက် မြန်မာဘာသာစကားနဲ့ ပြန်ဆိုပေးထားပါတယ်",
            "မြန်မာဘာသာစကားနဲ့ ပြန်ဆိုပေးလိုက်ပါတယ်",
            "ဘာသာပြန်ပေးလိုက်ပါတယ်",
            "ရေးပေးလိုက်ပါတယ်",
            "ဟုတ်ကဲ့ပါ",
        ]
        cleaned = text or ""
        for phrase in fluff_phrases:
            cleaned = cleaned.replace(phrase, "")
        cleaned = re.sub(r"\s+", " ", cleaned).strip()
        return cleaned

    @staticmethod
    def _split_long_piece(piece: str, max_chars: int) -> list[str]:
        piece = piece.strip()
        if not piece:
            return []
        if len(piece) <= max_chars:
            return [piece]

        words = piece.split()
        if len(words) > 1:
            chunks: list[str] = []
            current = ""
            for word in words:
                candidate = f"{current} {word}".strip()
                if current and len(candidate) > max_chars:
                    chunks.append(current)
                    current = word
                else:
                    current = candidate
            if current:
                chunks.append(current)
            return chunks

        # မြန်မာစာမှာ space နည်းနိုင်သဖြင့် character count ဖြင့် ဖြတ်မည်။
        return [piece[i : i + max_chars] for i in range(0, len(piece), max_chars)]

    def _subtitle_chunks(self, text: str, max_chars: int = 30) -> list[str]:
        text = self._clean_caption(text)
        if not text:
            return []

        # ပုဒ်ဖြတ်သင်္ကေတကို စာသားထဲမှာ ထားပြီး ခွဲသည်။
        pieces = re.findall(r"[^။!?၊,]+[။!?၊,]?", text)
        chunks: list[str] = []
        for piece in pieces:
            chunks.extend(self._split_long_piece(piece.strip(), max_chars))
        return [chunk.strip() for chunk in chunks if chunk.strip()]

    @staticmethod
    def _allocate_durations(chunks: Sequence[str], total_duration: float) -> list[float]:
        if not chunks:
            return []
        if len(chunks) == 1:
            return [total_duration]

        weights = [max(1, len(re.sub(r"\s+", "", chunk))) for chunk in chunks]
        weight_sum = float(sum(weights))
        durations = [total_duration * (weight / weight_sum) for weight in weights]

        # အလွန်မြန်/အလွန်နှေး မဖတ်ရအောင် soft clamp ပြုလုပ်ပြီး နောက်ဆုံး normalize ပြန်လုပ်သည်။
        min_duration = min(1.0, total_duration / len(chunks))
        max_duration = max(2.2, min(4.8, total_duration))
        durations = [min(max(value, min_duration), max_duration) for value in durations]

        scale = total_duration / sum(durations)
        return [value * scale for value in durations]

    @staticmethod
    def _ass_time(seconds: float) -> str:
        seconds = max(0.0, seconds)
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = seconds % 60
        return f"{hours}:{minutes:02d}:{secs:05.2f}"

    @staticmethod
    def _ass_escape(text: str) -> str:
        return (
            text.replace("\\", r"\\")
            .replace("{", r"\{")
            .replace("}", r"\}")
            .replace("\n", r"\N")
        )

    def _create_ass_file(
        self,
        ass_path: str,
        caption_text: str,
        audio_duration: float,
        target_w: int,
        target_h: int,
        top_text: str,
        bottom_text: str,
        font_size: int,
        subtitle_y_fraction: float,
        subtitle_segments: Optional[Sequence[dict[str, Any]]] = None,
    ) -> bool:
        events: list[str] = []

        if subtitle_segments:
            for segment in subtitle_segments:
                text = self._clean_caption(str(segment.get("text", "")))
                if not text:
                    continue
                start = self._to_seconds(segment.get("start", 0.0))
                end = self._to_seconds(segment.get("end", start + 1.0))
                if end <= start:
                    continue
                events.append(
                    f"Dialogue: 0,{self._ass_time(start)},{self._ass_time(min(end, audio_duration))},"
                    f"Subtitle,,0,0,0,,{self._ass_escape(text)}"
                )
        else:
            chunks = self._subtitle_chunks(caption_text)
            durations = self._allocate_durations(chunks, audio_duration)
            cursor = 0.0
            for index, (chunk, duration) in enumerate(zip(chunks, durations)):
                start = cursor
                end = audio_duration if index == len(chunks) - 1 else min(audio_duration, cursor + duration)
                events.append(
                    f"Dialogue: 0,{self._ass_time(start)},{self._ass_time(end)},"
                    f"Subtitle,,0,0,0,,{self._ass_escape(chunk)}"
                )
                cursor = end

        if top_text:
            events.append(
                f"Dialogue: 1,0:00:00.00,{self._ass_time(audio_duration)},TopText,,0,0,0,,"
                f"{self._ass_escape(top_text)}"
            )
        if bottom_text:
            events.append(
                f"Dialogue: 1,0:00:00.00,{self._ass_time(audio_duration)},BottomText,,0,0,0,,"
                f"{self._ass_escape(bottom_text)}"
            )

        if not events:
            return False

        # Alignment=2 က bottom-center ဖြစ်သောကြောင့် desired Y နေရာကို MarginV ဖြင့်ပြောင်းသည်။
        subtitle_margin_v = max(25, int(target_h * (1.0 - subtitle_y_fraction)))
        top_margin_v = max(60, int(target_h * 0.075))
        bottom_margin_v = max(40, int(target_h * 0.06))

        ass_content = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {target_w}
PlayResY: {target_h}
ScaledBorderAndShadow: yes
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Subtitle,{self.font_name},{font_size},&H00FFFFFF,&H0000FFFF,&H00101010,&H64000000,-1,0,0,0,100,100,0,0,1,3,1,2,70,70,{subtitle_margin_v},1
Style: TopText,{self.font_name},{max(font_size, 42)},&H00FFFFFF,&H0000FFFF,&H00101010,&H64000000,-1,0,0,0,100,100,0,0,1,3,1,8,60,60,{top_margin_v},1
Style: BottomText,{self.font_name},{max(font_size, 42)},&H0000FFFF,&H0000FFFF,&H00101010,&H64000000,-1,0,0,0,100,100,0,0,1,3,1,2,60,60,{bottom_margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
{os.linesep.join(events)}
"""
        Path(ass_path).write_text(ass_content, encoding="utf-8-sig")
        return True

    # ------------------------------------------------------------------
    # OCR subtitle box detection
    # ------------------------------------------------------------------
    def _get_ocr_reader(self) -> Any:
        if self._ocr_reader is not None:
            return self._ocr_reader
        if easyocr is None:
            return None

        print("🧠 EasyOCR ကို လိုအပ်သည့်အချိန်မှ စတင်အသက်သွင်းနေပါသည်...")
        try:
            self._ocr_reader = easyocr.Reader(["en"], gpu=True, verbose=False)
        except Exception as gpu_error:
            print(f"⚠️ EasyOCR GPU mode မရပါ ({gpu_error})။ CPU mode ပြောင်းသုံးပါမည်။")
            try:
                self._ocr_reader = easyocr.Reader(["en"], gpu=False, verbose=False)
            except Exception as cpu_error:
                print(f"⚠️ EasyOCR စတင်မရပါ: {cpu_error}")
                self._ocr_reader = None
        return self._ocr_reader

    def _detect_subtitle_box(self, video_path: str) -> tuple[int, int, int, int, int, int]:
        """Detect original subtitle band anywhere from mid-screen to lower screen.

        Old behavior was bottom-biased (roughly y >= 58%-60%), so subtitles placed
        around the middle of a vertical video were ignored. This version samples
        several frames, groups OCR/CV detections into recurring horizontal bands,
        and picks one stable subtitle-like band without merging unrelated text from
        different vertical positions.
        """
        info = self._probe(video_path)
        width, height = self._video_dimensions(info)
        duration = self._duration_from_probe(info)

        if width <= 0 or height <= 0:
            raise RuntimeError("Video resolution ကို မဖတ်နိုင်ပါ။")

        # Safe fallback stays near the traditional lower subtitle position.
        default_box = (
            int(width * 0.04),
            int(height * 0.775),
            int(width * 0.92),
            int(height * 0.11),
            width,
            height,
        )

        if cv2 is None:
            print("⚠️ OpenCV မရှိသဖြင့် default subtitle blur area သုံးပါမည်။")
            return default_box

        reader = self._get_ocr_reader()
        if reader is None:
            print("⚠️ EasyOCR မရသဖြင့် default subtitle blur area သုံးပါမည်။")
            return default_box

        print("🔍 မူရင်းစာတန်းနေရာကို mid+lower sample frames များဖြင့်ရှာနေပါသည်...")

        # Scan enough of the video to avoid landing on a subtitle-free frame.
        sample_times = sorted({
            max(0.35, min(duration * 0.12, max(0.35, duration - 0.2))),
            max(0.35, min(duration * 0.30, max(0.35, duration - 0.2))),
            max(0.35, min(duration * 0.48, max(0.35, duration - 0.2))),
            max(0.35, min(duration * 0.66, max(0.35, duration - 0.2))),
            max(0.35, min(duration * 0.84, max(0.35, duration - 0.2))),
        })

        # Store: (frame_idx, x, y, w, h, confidence)
        ocr_boxes: list[tuple[int, float, float, float, float, float]] = []
        cap = cv2.VideoCapture(video_path)
        fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
        try:
            for frame_idx, sample_time in enumerate(sample_times):
                cap.set(cv2.CAP_PROP_POS_FRAMES, int(fps * sample_time))
                success, frame = cap.read()
                if not success:
                    continue
                try:
                    results = reader.readtext(frame)
                except Exception:
                    continue

                for bbox, text, probability in results:
                    if probability < 0.18:
                        continue
                    x1, y1 = bbox[0]
                    x3, y3 = bbox[2]
                    box_w = float(x3 - x1)
                    box_h = float(y3 - y1)
                    center_y = float(y1 + box_h / 2.0)

                    # Allow subtitles from about the upper-middle downwards, while
                    # excluding common top-title / watermark zones.
                    if center_y < height * 0.25 or center_y > height * 0.96:
                        continue
                    if box_w < width * 0.035:
                        continue
                    if box_h < max(5.0, height * 0.006) or box_h > height * 0.10:
                        continue

                    # Tiny OCR specks are rarely subtitles unless confidence is high.
                    cleaned_text = re.sub(r"\s+", "", str(text or ""))
                    if len(cleaned_text) <= 1 and probability < 0.55:
                        continue

                    ocr_boxes.append((frame_idx, x1, y1, box_w, box_h, float(probability)))
        finally:
            cap.release()

        def choose_band(items):
            """Cluster detections by vertical center and return the best recurring band."""
            if not items:
                return None

            tolerance = max(18.0, height * 0.055)
            clusters: list[list] = []

            for item in sorted(items, key=lambda b: b[2] + b[4] / 2.0):
                cy = item[2] + item[4] / 2.0
                placed = False
                for cluster in clusters:
                    cluster_cy = sum(b[2] + b[4] / 2.0 for b in cluster) / len(cluster)
                    if abs(cy - cluster_cy) <= tolerance:
                        cluster.append(item)
                        placed = True
                        break
                if not placed:
                    clusters.append([item])

            scored = []
            for cluster in clusters:
                frame_ids = {int(b[0]) for b in cluster}
                min_x = min(float(b[1]) for b in cluster)
                min_y = min(float(b[2]) for b in cluster)
                max_x = max(float(b[1] + b[3]) for b in cluster)
                max_y = max(float(b[2] + b[4]) for b in cluster)
                band_w = max_x - min_x
                band_h = max_y - min_y
                cy = (min_y + max_y) / 2.0

                # Subtitle bands usually recur, cover meaningful horizontal width,
                # and live from mid-screen to lower-screen. Recurrence dominates.
                recurrence = len(frame_ids)
                width_score = min(1.0, band_w / max(1.0, width * 0.55))
                lower_bonus = 0.20 if cy >= height * 0.52 else 0.0
                confidence = sum(float(b[5]) for b in cluster) / len(cluster)
                score = recurrence * 4.0 + width_score * 2.0 + confidence + lower_bonus

                # Reject implausibly tall merged clusters.
                if band_h > height * 0.20:
                    score -= 4.0

                scored.append((score, recurrence, band_w, cluster))

            scored.sort(key=lambda s: (s[0], s[1], s[2]), reverse=True)
            return scored[0][3] if scored else None

        chosen = choose_band(ocr_boxes)

        if chosen:
            min_x = min(b[1] for b in chosen)
            min_y = min(b[2] for b in chosen)
            max_x = max(b[1] + b[3] for b in chosen)
            max_y = max(b[2] + b[4] for b in chosen)
            pad_x = int(width * 0.045)
            pad_y = int(height * 0.018)

            x = max(0, int(min_x) - pad_x)
            y = max(0, int(min_y) - pad_y)
            box_w = min(width - x, int(max_x - min_x) + pad_x * 2)
            box_h = min(height - y, int(max_y - min_y) + pad_y * 2)

            print(
                f"🎯 Subtitle area: x={x}, y={y}, w={box_w}, h={box_h} "
                f"(OCR band, frames={len({int(b[0]) for b in chosen})})"
            )
            return x, y, box_w, box_h, width, height

        # ------------------------------------------------------------------
        # Language-agnostic OpenCV fallback, now scanning middle + lower screen.
        # ------------------------------------------------------------------
        print("ℹ️ OCR ဖြင့် subtitle မတွေ့ပါ။ OpenCV mid+lower text-band fallback စမ်းနေပါသည်...")
        visual_boxes: list[tuple[int, int, int, int, int, float]] = []
        cap = cv2.VideoCapture(video_path)
        fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
        visual_times = sorted({
            max(0.35, min(duration * 0.10, max(0.35, duration - 0.2))),
            max(0.35, min(duration * 0.28, max(0.35, duration - 0.2))),
            max(0.35, min(duration * 0.46, max(0.35, duration - 0.2))),
            max(0.35, min(duration * 0.64, max(0.35, duration - 0.2))),
            max(0.35, min(duration * 0.82, max(0.35, duration - 0.2))),
        })

        try:
            for frame_idx, sample_time in enumerate(visual_times):
                cap.set(cv2.CAP_PROP_POS_FRAMES, int(fps * sample_time))
                ok, frame = cap.read()
                if not ok:
                    continue

                y0 = int(height * 0.24)
                y1 = int(height * 0.97)
                roi = frame[y0:y1, :]
                gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
                gray = cv2.GaussianBlur(gray, (3, 3), 0)
                grad = cv2.morphologyEx(
                    gray,
                    cv2.MORPH_GRADIENT,
                    cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)),
                )
                _, bw_img = cv2.threshold(grad, 28, 255, cv2.THRESH_BINARY)
                kernel = cv2.getStructuringElement(
                    cv2.MORPH_RECT,
                    (max(15, width // 35), 3),
                )
                joined = cv2.morphologyEx(bw_img, cv2.MORPH_CLOSE, kernel, iterations=2)
                contours, _ = cv2.findContours(joined, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                for c in contours:
                    x, yy, ww, hh = cv2.boundingRect(c)
                    abs_y = yy + y0
                    cy = abs_y + hh / 2.0

                    if ww < width * 0.16:
                        continue
                    if hh < max(5, height * 0.008) or hh > height * 0.11:
                        continue
                    if cy < height * 0.25 or cy > height * 0.96:
                        continue

                    # pseudo-confidence is based on width coverage; choose_band only
                    # needs a stable final numeric score.
                    pseudo_conf = min(1.0, ww / max(1.0, width * 0.55))
                    visual_boxes.append((frame_idx, x, abs_y, ww, hh, pseudo_conf))
        finally:
            cap.release()

        chosen_visual = choose_band(visual_boxes)
        if chosen_visual:
            min_x = min(b[1] for b in chosen_visual)
            min_y = min(b[2] for b in chosen_visual)
            max_x = max(b[1] + b[3] for b in chosen_visual)
            max_y = max(b[2] + b[4] for b in chosen_visual)
            pad_x = int(width * 0.045)
            pad_y = int(height * 0.022)

            x = max(0, int(min_x) - pad_x)
            y = max(0, int(min_y) - pad_y)
            box_w = min(width - x, int(max_x - min_x) + pad_x * 2)
            box_h = min(height - y, int(max_y - min_y) + pad_y * 2)

            print(
                f"🎯 OpenCV fallback subtitle area: x={x}, y={y}, w={box_w}, h={box_h} "
                f"(frames={len({int(b[0]) for b in chosen_visual})})"
            )
            return x, y, box_w, box_h, width, height

        print("ℹ️ OCR/CV နှစ်ခုလုံး subtitle မတွေ့ပါ။ Safe bottom blur band ကိုသုံးပါမည်။")
        return default_box

    # ------------------------------------------------------------------
    # Smart sync helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _to_seconds(value: Any) -> float:
        if isinstance(value, (int, float)):
            return float(value)
        if value is None:
            return 0.0
        text = str(value).strip()
        if not text:
            return 0.0
        try:
            return float(text)
        except ValueError:
            pass
        parts = text.split(":")
        try:
            seconds = 0.0
            for part in parts:
                seconds = seconds * 60.0 + float(part)
            return seconds
        except ValueError as exc:
            raise ValueError(f"Time value မမှန်ပါ: {value}") from exc

    @staticmethod
    def _sync_chain(
        source_label: str,
        source_duration: float,
        target_duration: float,
        output_label: str,
        max_video_speed: float,
        max_video_slow: float,
    ) -> str:
        """
        setpts factor < 1 = မြန်၊ > 1 = နှေး။
        အကန့်အသတ်ကျော်ပါက trim သို့ freeze ဖြင့် target duration ကို တိတိကျကျညှိသည်။
        """
        if source_duration <= 0 or target_duration <= 0:
            raise ValueError("Smart Sync duration သည် 0 ထက်ကြီးရပါမည်။")

        minimum_factor = 1.0 / max(max_video_speed, 1.0)
        maximum_factor = max(max_video_slow, 1.0)
        desired_factor = target_duration / source_duration
        applied_factor = min(max(desired_factor, minimum_factor), maximum_factor)
        adjusted_duration = source_duration * applied_factor

        filters = [
            f"{source_label}setpts={applied_factor:.8f}*(PTS-STARTPTS)"
        ]

        if adjusted_duration > target_duration + 0.02:
            filters.append(f"trim=duration={target_duration:.6f}")
            filters.append("setpts=PTS-STARTPTS")
        elif adjusted_duration < target_duration - 0.02:
            freeze_duration = target_duration - adjusted_duration
            filters.append(f"tpad=stop_mode=clone:stop_duration={freeze_duration:.6f}")
            filters.append(f"trim=duration={target_duration:.6f}")

        return ",".join(filters) + output_label

    def _build_sync_graph(
        self,
        video_duration: float,
        audio_duration: float,
        sync_segments: Optional[Sequence[dict[str, Any]]],
        max_video_speed: float,
        max_video_slow: float,
    ) -> tuple[list[str], str]:
        filters: list[str] = []

        if not sync_segments:
            chain = self._sync_chain(
                source_label="[0:v]",
                source_duration=video_duration,
                target_duration=audio_duration,
                output_label="[v_synced]",
                max_video_speed=max_video_speed,
                max_video_slow=max_video_slow,
            )
            filters.append(chain)
            return filters, "[v_synced]"

        valid_segments: list[tuple[float, float, float]] = []
        for segment in sync_segments:
            video_start = self._to_seconds(segment.get("video_start", segment.get("start", 0.0)))
            video_end = self._to_seconds(segment.get("video_end", segment.get("end", 0.0)))

            if "audio_start" in segment or "audio_end" in segment:
                audio_start = self._to_seconds(segment.get("audio_start", 0.0))
                audio_end = self._to_seconds(segment.get("audio_end", 0.0))
                target_duration = audio_end - audio_start
            else:
                target_duration = self._to_seconds(segment.get("audio_duration", 0.0))

            video_start = max(0.0, min(video_start, video_duration))
            video_end = max(video_start, min(video_end, video_duration))
            if video_end - video_start <= 0.03 or target_duration <= 0.03:
                continue
            valid_segments.append((video_start, video_end, target_duration))

        if not valid_segments:
            print("⚠️ sync_segments မမှန်သဖြင့် global Smart Sync ကိုပြန်သုံးပါမည်။")
            return self._build_sync_graph(
                video_duration,
                audio_duration,
                None,
                max_video_speed,
                max_video_slow,
            )

        labels: list[str] = []
        total_target = 0.0
        for index, (video_start, video_end, target_duration) in enumerate(valid_segments):
            trimmed_label = f"[seg_trim_{index}]"
            synced_label = f"[seg_sync_{index}]"
            filters.append(
                f"[0:v]trim=start={video_start:.6f}:end={video_end:.6f},"
                f"setpts=PTS-STARTPTS{trimmed_label}"
            )
            filters.append(
                self._sync_chain(
                    source_label=trimmed_label,
                    source_duration=video_end - video_start,
                    target_duration=target_duration,
                    output_label=synced_label,
                    max_video_speed=max_video_speed,
                    max_video_slow=max_video_slow,
                )
            )
            labels.append(synced_label)
            total_target += target_duration

        filters.append(f"{''.join(labels)}concat=n={len(labels)}:v=1:a=0[v_segments_concat]")

        # Segment target total နှင့် audio total ကွာလျှင် final duration ကို တစ်ကြိမ်ပြန်ညှိသည်။
        if abs(total_target - audio_duration) > 0.03:
            filters.append(
                self._sync_chain(
                    source_label="[v_segments_concat]",
                    source_duration=total_target,
                    target_duration=audio_duration,
                    output_label="[v_synced]",
                    max_video_speed=max_video_speed,
                    max_video_slow=max_video_slow,
                )
            )
            return filters, "[v_synced]"

        return filters, "[v_segments_concat]"

    # ------------------------------------------------------------------
    # FFmpeg helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _escape_filter_path(path: str) -> str:
        normalized = os.path.abspath(path).replace("\\", "/")
        normalized = normalized.replace(":", r"\:")
        normalized = normalized.replace("'", r"\'")
        return normalized

    def _available_encoders(self) -> set[str]:
        if self._encoder_cache is not None:
            return self._encoder_cache
        result = subprocess.run(
            [self.ffmpeg_path, "-hide_banner", "-encoders"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        encoders: set[str] = set()
        for line in result.stdout.splitlines():
            match = re.search(r"\b(h264_[a-z0-9_]+|libx264)\b", line)
            if match:
                encoders.add(match.group(1))
        self._encoder_cache = encoders
        return encoders

    def _encoder_candidates(self) -> list[tuple[str, list[str]]]:
        available = self._available_encoders()
        candidates: list[tuple[str, list[str]]] = []
        if "h264_nvenc" in available:
            candidates.append(
                (
                    "h264_nvenc",
                    ["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", "21", "-b:v", "0"],
                )
            )
        candidates.append(
            (
                "libx264",
                ["-c:v", "libx264", "-preset", "medium", "-crf", "20"],
            )
        )
        return candidates

    def _run_render_with_fallback(
        self,
        base_cmd: list[str],
        output_path: str,
    ) -> None:
        last_error = ""
        for encoder_name, encoder_args in self._encoder_candidates():
            if os.path.exists(output_path):
                try:
                    os.remove(output_path)
                except OSError:
                    pass

            cmd = base_cmd + encoder_args + [
                "-c:a",
                "aac",
                "-b:a",
                "192k",
                "-pix_fmt",
                "yuv420p",
                "-movflags",
                "+faststart",
                output_path,
            ]
            print(f"🚀 Render encoder: {encoder_name}")
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            if result.returncode == 0:
                return

            last_error = result.stderr[-5000:]
            print(f"⚠️ {encoder_name} render မအောင်မြင်ပါ။ နောက် encoder ပြောင်းစမ်းပါမည်။")

        raise RuntimeError(f"FFmpeg render failed:\n{last_error}")

    # ------------------------------------------------------------------
    # Main public method - old caller compatible
    # ------------------------------------------------------------------
    def edit_video_with_audio(
        self,
        video_input: str,
        audio_input: str,
        output_path: str,
        caption_text: str = "",
        logo_path: str = "logo.png",
        top_text: str = "",
        bottom_text: str = "",
        *,
        output_ratio: str = "9:16",
        smart_sync: bool = True,
        sync_segments: Optional[Sequence[dict[str, Any]]] = None,
        subtitle_segments: Optional[Sequence[dict[str, Any]]] = None,
        subtitle_font_size: Optional[int] = None,
        subtitle_y_fraction: Optional[float] = None,
        mirror_video: bool = True,
        blur_original_subtitles: bool = True,
        freeze_when_audio_longer: bool = True,
        max_video_speed: float = 1.50,
        max_video_slow: float = 1.35,
        logo_width: int = 180,
        logo_x: int = 50,
        logo_y: int = 50,
        logo_opacity: float = 1.0,
    ) -> Optional[str]:
        """
        Original video + TTS audio ကို social-video အဖြစ် render လုပ်သည်။

        sync_segments optional format:
            [
              {
                "video_start": 0.0,
                "video_end": 5.2,
                "audio_start": 0.0,
                "audio_end": 4.4
              }
            ]

        subtitle_segments optional format:
            [
              {"start": 0.0, "end": 2.4, "text": "စာတန်းတစ်ပိုင်း"}
            ]
        """
        print("🎬 Personal Video Engine V2 စတင်လုပ်ဆောင်နေပါသည်...")

        video_abs = os.path.abspath(video_input)
        audio_abs = os.path.abspath(audio_input)
        output_abs = os.path.abspath(output_path)
        Path(output_abs).parent.mkdir(parents=True, exist_ok=True)

        if not os.path.isfile(video_abs):
            print(f"❌ Video input မတွေ့ပါ: {video_abs}")
            return None
        if not os.path.isfile(audio_abs):
            print(f"❌ Audio input မတွေ့ပါ: {audio_abs}")
            return None

        ratio_map = {
            "9:16": (1080, 1920),
            "16:9": (1920, 1080),
            "1:1": (1080, 1080),
            "4:3": (1440, 1080),
        }
        target_w, target_h = ratio_map.get(output_ratio, ratio_map["9:16"])

        font_size = int(subtitle_font_size or self.subtitle_font_size)
        y_fraction = subtitle_y_fraction if subtitle_y_fraction is not None else self.subtitle_y_fraction
        y_fraction = min(max(float(y_fraction), 0.55), 0.95)

        job_temp = tempfile.mkdtemp(prefix="video_job_", dir=str(self.temp_dir))
        ass_path = os.path.join(job_temp, "timed_subtitles.ass")

        try:
            video_info = self._probe(video_abs)
            audio_info = self._probe(audio_abs)
            video_duration = self._duration_from_probe(video_info)
            audio_duration = self._duration_from_probe(audio_info)
            orig_w, orig_h = self._video_dimensions(video_info)

            if video_duration <= 0 or audio_duration <= 0:
                raise RuntimeError(
                    f"Duration မမှန်ပါ: video={video_duration:.3f}s, audio={audio_duration:.3f}s"
                )
            if orig_w <= 0 or orig_h <= 0:
                raise RuntimeError("Video resolution ကို မဖတ်နိုင်ပါ။")

            caption_text = self._clean_caption(caption_text)
            print(f"📝 Caption: {caption_text}")
            print(
                f"⏱️ Duration — video={video_duration:.2f}s, audio={audio_duration:.2f}s, "
                f"ratio={audio_duration / video_duration:.3f}"
            )

            # freeze ပိတ်ထားပါက slow limit ကို audio နဲ့ညီနိုင်အောင် ခွင့်ပြုသည်။
            effective_max_slow = max_video_slow
            if not freeze_when_audio_longer and audio_duration > video_duration * max_video_slow:
                effective_max_slow = audio_duration / video_duration

            sync_filters, synced_label = self._build_sync_graph(
                video_duration=video_duration,
                audio_duration=audio_duration,
                sync_segments=sync_segments if smart_sync else None,
                max_video_speed=max_video_speed,
                max_video_slow=effective_max_slow,
            )

            # smart_sync=False ဖြစ်ပါက 1x playback + trim/freeze ကိုသာသုံးသည်။
            if not smart_sync:
                sync_filters = [
                    self._sync_chain(
                        source_label="[0:v]",
                        source_duration=video_duration,
                        target_duration=audio_duration,
                        output_label="[v_synced]",
                        max_video_speed=1.0,
                        max_video_slow=1.0 if freeze_when_audio_longer else max(1.0, audio_duration / video_duration),
                    )
                ]
                synced_label = "[v_synced]"

            # foreground contain dimensions
            foreground_scale = min(target_w / orig_w, target_h / orig_h)
            foreground_w = max(2, int(round(orig_w * foreground_scale / 2.0) * 2))
            foreground_h = max(2, int(round(orig_h * foreground_scale / 2.0) * 2))
            foreground_x = int((target_w - foreground_w) / 2)
            foreground_y = int((target_h - foreground_h) / 2)

            filters = list(sync_filters)
            transform_chain = []
            if mirror_video:
                transform_chain.append("hflip")
            transform_chain.extend(
                [
                    "eq=contrast=0.98:brightness=-0.02:saturation=1.08",
                    "fps=30",
                    "format=yuv420p",
                ]
            )
            filters.append(f"{synced_label}{','.join(transform_chain)}[v_prepared]")

            # OCR blur area
            blur_box: Optional[tuple[int, int, int, int]] = None
            if blur_original_subtitles:
                x, y, box_w, box_h, _det_w, _det_h = self._detect_subtitle_box(video_abs)
                if mirror_video:
                    x = max(0, orig_w - (x + box_w))

                mapped_x = int(x * foreground_scale)
                mapped_y = int(y * foreground_scale)
                mapped_w = max(2, int(box_w * foreground_scale))
                mapped_h = max(2, int(box_h * foreground_scale))

                mapped_x = min(max(0, mapped_x), max(0, foreground_w - 2))
                mapped_y = min(max(0, mapped_y), max(0, foreground_h - 2))
                mapped_w = min(mapped_w, foreground_w - mapped_x)
                mapped_h = min(mapped_h, foreground_h - mapped_y)
                if mapped_w >= 4 and mapped_h >= 4:
                    blur_box = (mapped_x, mapped_y, mapped_w, mapped_h)

            split_count = 3 if blur_box else 2
            if split_count == 3:
                filters.append("[v_prepared]split=3[v_bg_src][v_main_src][v_crop_src]")
            else:
                filters.append("[v_prepared]split=2[v_bg_src][v_main_src]")

            filters.append(
                f"[v_bg_src]scale={target_w}:{target_h}:force_original_aspect_ratio=increase,"
                f"crop={target_w}:{target_h},boxblur=25:2[bg_layer]"
            )
            filters.append(f"[v_main_src]scale={foreground_w}:{foreground_h}[main_layer]")

            if blur_box:
                mapped_x, mapped_y, mapped_w, mapped_h = blur_box
                filters.append(
                    f"[v_crop_src]scale={foreground_w}:{foreground_h},"
                    f"crop={mapped_w}:{mapped_h}:{mapped_x}:{mapped_y},boxblur=12:1[sub_blur_box]"
                )
                filters.append(
                    f"[main_layer][sub_blur_box]overlay=x={mapped_x}:y={mapped_y}[main_cleaned]"
                )
                main_label = "[main_cleaned]"
            else:
                main_label = "[main_layer]"

            filters.append(
                f"[bg_layer]{main_label}overlay=x={foreground_x}:y={foreground_y}:"
                f"shortest=1[composition]"
            )
            current_label = "[composition]"

            inputs_cmd = ["-i", video_abs, "-i", audio_abs]
            next_input_index = 2

            if logo_path and os.path.isfile(logo_path):
                logo_abs = os.path.abspath(logo_path)
                inputs_cmd.extend(["-i", logo_abs])
                filters.append(
                    f"[{next_input_index}:v]scale={int(logo_width)}:-1,format=rgba,colorchannelmixer=aa={max(0.1,min(1.0,float(logo_opacity))):.3f}[logo_scaled]"
                )
                filters.append(
                    f"{current_label}[logo_scaled]overlay=x={int(logo_x)}:y={int(logo_y)}[with_logo]"
                )
                current_label = "[with_logo]"
                next_input_index += 1

            has_ass = self._create_ass_file(
                ass_path=ass_path,
                caption_text=caption_text,
                audio_duration=audio_duration,
                target_w=target_w,
                target_h=target_h,
                top_text=top_text,
                bottom_text=bottom_text,
                font_size=font_size,
                subtitle_y_fraction=y_fraction,
                subtitle_segments=subtitle_segments,
            )

            if has_ass:
                ass_filter_path = self._escape_filter_path(ass_path)
                subtitles_filter = f"subtitles='{ass_filter_path}'"
                if self.font_path:
                    font_dir = self._escape_filter_path(str(Path(self.font_path).parent))
                    subtitles_filter += f":fontsdir='{font_dir}'"
                filters.append(f"{current_label}{subtitles_filter}[final_v]")
                current_label = "[final_v]"

            filters.append(
                f"[1:a]aresample=48000:async=1:first_pts=0,"
                f"loudnorm=I=-16:TP=-1.5:LRA=11,"
                f"atrim=duration={audio_duration:.6f},asetpts=PTS-STARTPTS[aout]"
            )

            filter_complex = ";".join(filters)
            base_cmd = [
                self.ffmpeg_path,
                "-y",
                "-hide_banner",
                "-loglevel",
                "error",
                *inputs_cmd,
                "-filter_complex",
                filter_complex,
                "-map",
                current_label,
                "-map",
                "[aout]",
                "-t",
                f"{audio_duration:.6f}",
            ]

            self._run_render_with_fallback(base_cmd, output_abs)
            self._validate_output(output_abs, audio_duration)

            print(f"✅ Video Engine V2 အောင်မြင်ပါပြီ → {output_abs}")
            return output_abs

        except Exception as error:
            print(f"❌ Video Engine V2 Error: {error}")
            return None
        finally:
            shutil.rmtree(job_temp, ignore_errors=True)

# ================= Production-style subtitle patch V3 =================
# Unicode-safe Myanmar rendering:
# - Never split Myanmar text by raw character count.
# - Subtitle: one natural sentence/phrase at a time, one visual line.
# - Browser auto-shrinks font when a complete line is too long.
# - Title: full Unicode text, browser wraps safely to max 2 lines.

import base64 as _vs_base64
import html as _vs_html
try:
    from playwright.sync_api import sync_playwright as _vs_sync_playwright  # type: ignore
except Exception:
    _vs_sync_playwright = None


def _vs_natural_units(text: str) -> list[str]:
    """Split only at real punctuation boundaries; never slice Myanmar grapheme clusters."""
    cleaned = re.sub(r"\s+", " ", (text or "").strip())
    if not cleaned:
        return []

    # Main sentence endings. Keep punctuation with the sentence.
    units = [part.strip() for part in re.findall(r"[^။!?]+[။!?]?", cleaned) if part.strip()]
    if not units:
        return [cleaned]

    # If a sentence is extremely long and contains Burmese commas, use commas as
    # semantic boundaries. We still never cut by character index.
    out = []
    for unit in units:
        if len(unit) > 58 and "၊" in unit:
            comma_parts = [p.strip() for p in re.findall(r"[^၊]+၊?", unit) if p.strip()]
            out.extend(comma_parts or [unit])
        else:
            out.append(unit)
    return out


def _vs_build_subtitle_events(self, caption_text: str, audio_duration: float, subtitle_segments=None):
    events = []

    def add_units(start_sec: float, end_sec: float, value: str):
        start_sec = float(start_sec)
        end_sec = float(end_sec)
        if end_sec <= start_sec:
            return
        cleaned = self._clean_caption(value)
        units = _vs_natural_units(cleaned)
        if not units:
            return
        if len(units) == 1:
            events.append({"start": start_sec, "end": end_sec, "text": units[0]})
            return

        # Allocate display time proportionally to sentence length, but do not split text.
        duration = end_sec - start_sec
        weights = [max(1, len(re.sub(r"\s+", "", u))) for u in units]
        total = float(sum(weights))
        cursor = start_sec
        for idx, (unit, weight) in enumerate(zip(units, weights)):
            part = duration * (weight / total)
            unit_end = end_sec if idx == len(units) - 1 else min(end_sec, cursor + part)
            events.append({"start": cursor, "end": unit_end, "text": unit})
            cursor = unit_end

    if subtitle_segments:
        for segment in subtitle_segments:
            start = self._to_seconds(segment.get("start", 0.0))
            end = self._to_seconds(segment.get("end", start + 1.0))
            end = min(end, audio_duration)
            add_units(start, end, str(segment.get("text", "")))
        return events

    add_units(0.0, audio_duration, caption_text)
    return events


def _vs_browser_render_available(self) -> bool:
    return _vs_sync_playwright is not None and bool(self.font_path)


def _vs_render_text_overlay_png(
    self,
    output_png_path: str,
    text: str,
    width: int,
    height: int,
    font_size: int,
    bg_alpha: float = 0.34,
    text_color: str = '#FFFFFF',
    outline_color: str = '#0D0D0D',
    padding_x: int = 28,
    padding_y: int = 14,
    radius: int = 22,
    font_weight: int = 700,
    single_line: bool = False,
    max_lines: int = 2,
    min_font_size: int = 28,
):
    text = self._clean_caption(text)
    if not text or _vs_sync_playwright is None:
        return False

    # IMPORTANT: never call _subtitle_chunks here. Browser handles Myanmar line breaking.
    display_text = _vs_html.escape(text)

    font_base64 = ''
    if self.font_path and os.path.isfile(self.font_path):
        try:
            font_base64 = _vs_base64.b64encode(Path(self.font_path).read_bytes()).decode('utf-8')
        except Exception:
            font_base64 = ''

    white_space = 'nowrap' if single_line else 'normal'
    overflow_wrap = 'normal' if single_line else 'break-word'

    html_doc = f"""<!DOCTYPE html>
<html>
<head>
<meta charset='UTF-8'>
<style>
@font-face {{
  font-family: 'MyanmarCaption';
  src: url(data:font/ttf;base64,{font_base64}) format('truetype');
}}
html, body {{
  margin:0; padding:0; width:{int(width)}px; height:{int(height)}px;
  background:transparent; overflow:hidden;
}}
body {{ display:flex; align-items:center; justify-content:center; }}
.wrap {{
  box-sizing:border-box;
  width:calc(100% - {padding_x * 2}px);
  height:calc(100% - 4px);
  padding:{padding_y}px {padding_x}px;
  border-radius:{radius}px;
  background:rgba(0,0,0,{bg_alpha:.3f});
  display:flex;
  align-items:center;
  justify-content:center;
  overflow:hidden;
}}
.txt {{
  font-family:'MyanmarCaption','Pyidaungsu','Noto Sans Myanmar',sans-serif;
  font-size:{int(font_size)}px;
  line-height:1.34;
  font-weight:{int(font_weight)};
  color:{text_color};
  text-align:center;
  white-space:{white_space};
  word-break:normal;
  overflow-wrap:{overflow_wrap};
  line-break:auto;
  text-shadow:
    -2px -2px 0 {outline_color},
     2px -2px 0 {outline_color},
    -2px  2px 0 {outline_color},
     2px  2px 0 {outline_color},
     0px  4px 10px rgba(0,0,0,0.66);
}}
</style>
</head>
<body>
  <div class='wrap' id='wrap'><div class='txt' id='txt'>{display_text}</div></div>
<script>
(function() {{
  const el = document.getElementById('txt');
  const wrap = document.getElementById('wrap');
  let size = {int(font_size)};
  const minSize = {int(min_font_size)};
  const oneLine = {'true' if single_line else 'false'};
  const maxLines = {int(max_lines)};

  function fits() {{
    if (oneLine) return el.scrollWidth <= wrap.clientWidth - 4 && el.scrollHeight <= wrap.clientHeight - 4;
    const lh = parseFloat(getComputedStyle(el).lineHeight) || size * 1.34;
    const lines = Math.ceil(el.scrollHeight / lh);
    return el.scrollHeight <= wrap.clientHeight - 4 && lines <= maxLines;
  }}

  while (size > minSize && !fits()) {{
    size -= 1;
    el.style.fontSize = size + 'px';
  }}
}})();
</script>
</body>
</html>"""

    try:
        with _vs_sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page(viewport={"width": int(width), "height": int(height)})
            page.set_content(html_doc, wait_until='load')
            page.wait_for_timeout(450)
            page.screenshot(path=output_png_path, omit_background=True)
            browser.close()
        return os.path.isfile(output_png_path)
    except Exception as error:
        print(f"⚠️ Browser text render fail: {error}")
        return False


def _vs_edit_video_with_audio(
    self,
    video_input,
    audio_input,
    output_path,
    caption_text="",
    logo_path=None,
    top_text="",
    bottom_text="",
    output_ratio="9:16",
    smart_sync=True,
    sync_segments=None,
    subtitle_segments=None,
    subtitle_font_size=None,
    subtitle_y_fraction=None,
    mirror_video=True,
    blur_original_subtitles=True,
    freeze_when_audio_longer=True,
    max_video_speed=1.50,
    max_video_slow=1.35,
    logo_width=180,
    logo_x=50,
    logo_y=50,
    logo_opacity=1.0,
):
    print("🎬 Personal Video Engine V2 (Unicode-safe wrapped subtitles V4) စတင်လုပ်ဆောင်နေပါသည်...")

    video_abs = os.path.abspath(video_input)
    audio_abs = os.path.abspath(audio_input)
    output_abs = os.path.abspath(output_path)
    Path(output_abs).parent.mkdir(parents=True, exist_ok=True)

    if not os.path.isfile(video_abs):
        print(f"❌ Video input မတွေ့ပါ: {video_abs}")
        return None
    if not os.path.isfile(audio_abs):
        print(f"❌ Audio input မတွေ့ပါ: {audio_abs}")
        return None

    ratio_map = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080), "4:3": (1440, 1080)}
    target_w, target_h = ratio_map.get(output_ratio, ratio_map["9:16"])

    font_size = int(subtitle_font_size or self.subtitle_font_size)
    y_fraction = subtitle_y_fraction if subtitle_y_fraction is not None else self.subtitle_y_fraction
    y_fraction = min(max(float(y_fraction), 0.55), 0.95)

    job_temp = tempfile.mkdtemp(prefix="video_job_", dir=str(self.temp_dir))
    ass_path = os.path.join(job_temp, "timed_subtitles.ass")

    try:
        video_info = self._probe(video_abs)
        audio_info = self._probe(audio_abs)
        video_duration = self._duration_from_probe(video_info)
        audio_duration = self._duration_from_probe(audio_info)
        orig_w, orig_h = self._video_dimensions(video_info)
        if video_duration <= 0 or audio_duration <= 0:
            raise RuntimeError(f"Duration မမှန်ပါ: video={video_duration:.3f}s, audio={audio_duration:.3f}s")
        if orig_w <= 0 or orig_h <= 0:
            raise RuntimeError("Video resolution ကို မဖတ်နိုင်ပါ။")

        caption_text = self._clean_caption(caption_text)
        print(f"📝 Caption: {caption_text}")
        print(f"⏱️ Duration — video={video_duration:.2f}s, audio={audio_duration:.2f}s, ratio={audio_duration / video_duration:.3f}")

        effective_max_slow = max_video_slow
        if not freeze_when_audio_longer and audio_duration > video_duration * max_video_slow:
            effective_max_slow = audio_duration / video_duration

        sync_filters, synced_label = self._build_sync_graph(
            video_duration=video_duration,
            audio_duration=audio_duration,
            sync_segments=sync_segments if smart_sync else None,
            max_video_speed=max_video_speed,
            max_video_slow=effective_max_slow,
        )
        if not smart_sync:
            sync_filters = [self._sync_chain(
                source_label="[0:v]", source_duration=video_duration, target_duration=audio_duration,
                output_label="[v_synced]", max_video_speed=1.0,
                max_video_slow=1.0 if freeze_when_audio_longer else max(1.0, audio_duration / video_duration),
            )]
            synced_label = "[v_synced]"

        foreground_scale = min(target_w / orig_w, target_h / orig_h)
        foreground_w = max(2, int(round(orig_w * foreground_scale / 2.0) * 2))
        foreground_h = max(2, int(round(orig_h * foreground_scale / 2.0) * 2))
        foreground_x = int((target_w - foreground_w) / 2)
        foreground_y = int((target_h - foreground_h) / 2)

        filters = list(sync_filters)
        transform_chain = []
        if mirror_video:
            transform_chain.append("hflip")
        transform_chain.extend(["eq=contrast=0.98:brightness=-0.02:saturation=1.08", "fps=30", "format=yuv420p"])
        filters.append(f"{synced_label}{','.join(transform_chain)}[v_prepared]")

        blur_box = None
        if blur_original_subtitles:
            x, y, box_w, box_h, _det_w, _det_h = self._detect_subtitle_box(video_abs)
            if mirror_video:
                x = max(0, orig_w - (x + box_w))
            mapped_x = int(x * foreground_scale)
            mapped_y = int(y * foreground_scale)
            mapped_w = max(2, int(box_w * foreground_scale))
            mapped_h = max(2, int(box_h * foreground_scale))
            mapped_x = min(max(0, mapped_x), max(0, foreground_w - 2))
            mapped_y = min(max(0, mapped_y), max(0, foreground_h - 2))
            mapped_w = min(mapped_w, foreground_w - mapped_x)
            mapped_h = min(mapped_h, foreground_h - mapped_y)
            if mapped_w >= 4 and mapped_h >= 4:
                blur_box = (mapped_x, mapped_y, mapped_w, mapped_h)

        if blur_box:
            filters.append("[v_prepared]split=3[v_bg_src][v_main_src][v_crop_src]")
        else:
            filters.append("[v_prepared]split=2[v_bg_src][v_main_src]")
        filters.append(f"[v_bg_src]scale={target_w}:{target_h}:force_original_aspect_ratio=increase,crop={target_w}:{target_h},boxblur=25:2[bg_layer]")
        filters.append(f"[v_main_src]scale={foreground_w}:{foreground_h}[main_layer]")

        if blur_box:
            bx, by, bw, bh = blur_box
            filters.append(f"[v_crop_src]scale={foreground_w}:{foreground_h},crop={bw}:{bh}:{bx}:{by},boxblur=12:1[sub_blur_box]")
            filters.append(f"[main_layer][sub_blur_box]overlay=x={bx}:y={by}[main_cleaned]")
            main_label = "[main_cleaned]"
        else:
            main_label = "[main_layer]"

        filters.append(f"[bg_layer]{main_label}overlay=x={foreground_x}:y={foreground_y}:shortest=1[composition]")
        current_label = "[composition]"
        inputs_cmd = ["-i", video_abs, "-i", audio_abs]
        next_input_index = 2

        if logo_path and os.path.isfile(logo_path):
            inputs_cmd.extend(["-i", os.path.abspath(logo_path)])
            filters.append(f"[{next_input_index}:v]scale={int(logo_width)}:-1,format=rgba,colorchannelmixer=aa={max(0.1,min(1.0,float(logo_opacity))):.3f}[logo_scaled]")
            filters.append(f"{current_label}[logo_scaled]overlay=x={int(logo_x)}:y={int(logo_y)}[with_logo]")
            current_label = "[with_logo]"
            next_input_index += 1

        subtitle_events = self._build_subtitle_events(
            caption_text=caption_text,
            audio_duration=audio_duration,
            subtitle_segments=subtitle_segments,
        )

        # Keep generated Burmese subtitles at the configured bottom position.
        # OCR blur may move to the middle/lower area to cover source subtitles,
        # but our subtitle overlay must NOT follow that blur box.
        # Width, height, font size and the existing y_fraction are unchanged.
        subtitle_w = int(target_w * 0.97)
        subtitle_h = max(250, int(target_h * 0.135))
        subtitle_x = int((target_w - subtitle_w) / 2)
        subtitle_y = int(target_h * y_fraction - subtitle_h / 2)
        subtitle_y = max(0, min(subtitle_y, target_h - subtitle_h - 4))

        if self._browser_render_available():
            # Title: full Unicode string, browser-safe wrap, maximum two visual lines.
            if top_text:
                top_png = os.path.join(job_temp, "top_title.png")
                top_w = int(target_w * 0.96)
                top_h = max(130, int(target_h * 0.115))
                top_font = 40
                if self._render_text_overlay_png(
                    top_png, top_text, top_w, top_h, top_font,
                    bg_alpha=0.30, padding_x=30, padding_y=14, radius=22,
                    single_line=False, max_lines=2, min_font_size=30,
                ):
                    inputs_cmd.extend(["-i", top_png])
                    top_x = int((target_w - top_w) / 2)
                    top_y = max(30, int(target_h * 0.04))
                    filters.append(f"{current_label}[{next_input_index}:v]overlay=x={top_x}:y={top_y}[with_top]")
                    current_label = "[with_top]"
                    next_input_index += 1

            # Subtitle: one complete natural sentence/phrase at a time, forced to one visual line.
            for idx, item in enumerate(subtitle_events):
                sub_png = os.path.join(job_temp, f"sub_{idx:03d}.png")
                if not self._render_text_overlay_png(
                    sub_png, str(item.get("text", "")), subtitle_w, subtitle_h, 44,
                    bg_alpha=0.18, padding_x=16, padding_y=12, radius=20,
                    single_line=False, max_lines=4, min_font_size=44,
                ):
                    continue
                start = max(0.0, float(item["start"]))
                end = max(start + 0.05, min(audio_duration, float(item["end"])))
                inputs_cmd.extend(["-i", sub_png])
                filters.append(
                    f"{current_label}[{next_input_index}:v]overlay=x={subtitle_x}:y={subtitle_y}:"
                    f"enable='between(t,{start:.3f},{end:.3f})'[subbed_{idx}]"
                )
                current_label = f"[subbed_{idx}]"
                next_input_index += 1

            if bottom_text:
                bottom_png = os.path.join(job_temp, "bottom_text.png")
                bottom_w = int(target_w * 0.92)
                bottom_h = max(96, int(target_h * 0.07))
                if self._render_text_overlay_png(
                    bottom_png, bottom_text, bottom_w, bottom_h, 36,
                    bg_alpha=0.20, text_color='#FFD500', padding_x=24, padding_y=10,
                    single_line=True, max_lines=1, min_font_size=26,
                ):
                    inputs_cmd.extend(["-i", bottom_png])
                    bottom_x = int((target_w - bottom_w) / 2)
                    bottom_y = target_h - bottom_h - max(34, int(target_h * 0.045))
                    filters.append(f"{current_label}[{next_input_index}:v]overlay=x={bottom_x}:y={bottom_y}[with_bottom]")
                    current_label = "[with_bottom]"
                    next_input_index += 1
        else:
            print("⚠️ Playwright text render မရပါ။ ASS fallback ကို သုံးပါမည်။")
            has_ass = self._create_ass_file(
                ass_path=ass_path, caption_text=caption_text, audio_duration=audio_duration,
                target_w=target_w, target_h=target_h, top_text=top_text, bottom_text=bottom_text,
                font_size=max(font_size, 40), subtitle_y_fraction=y_fraction,
                subtitle_segments=subtitle_segments,
            )
            if has_ass:
                ass_filter_path = self._escape_filter_path(ass_path)
                subtitles_filter = f"subtitles='{ass_filter_path}'"
                if self.font_path:
                    font_dir = self._escape_filter_path(str(Path(self.font_path).parent))
                    subtitles_filter += f":fontsdir='{font_dir}'"
                filters.append(f"{current_label}{subtitles_filter}[final_v]")
                current_label = "[final_v]"

        filters.append(
            f"[1:a]aresample=48000:async=1:first_pts=0,loudnorm=I=-16:TP=-1.5:LRA=11,"
            f"atrim=duration={audio_duration:.6f},asetpts=PTS-STARTPTS[aout]"
        )
        base_cmd = [
            self.ffmpeg_path, '-y', '-hide_banner', '-loglevel', 'error',
            *inputs_cmd, '-filter_complex', ';'.join(filters),
            '-map', current_label, '-map', '[aout]', '-t', f'{audio_duration:.6f}',
        ]
        self._run_render_with_fallback(base_cmd, output_abs)
        self._validate_output(output_abs, audio_duration)
        print(f"✅ Unicode-safe subtitle render အောင်မြင်ပါပြီ → {output_abs}")
        return output_abs
    except Exception as error:
        print(f"❌ Video Engine V2 Error: {error}")
        return None
    finally:
        shutil.rmtree(job_temp, ignore_errors=True)


VideoService._build_subtitle_events = _vs_build_subtitle_events
VideoService._browser_render_available = _vs_browser_render_available
VideoService._render_text_overlay_png = _vs_render_text_overlay_png
VideoService.edit_video_with_audio = _vs_edit_video_with_audio
# ================= end production-style subtitle patch V3 =================


# ================= V5.9 adaptive subtitle-blur clamp =================
_v59_original_detect_subtitle_box = VideoService._detect_subtitle_box

def _v59_detect_subtitle_box_adaptive(self, video_path: str):
    x, y, w, h, width, height = _v59_original_detect_subtitle_box(self, video_path)
    if width <= 0 or height <= 0:
        return x, y, w, h, width, height

    # Keep the detector's actual vertical center. Unlike V5.8, do NOT force y >= 60%.
    # This allows genuine middle-screen subtitles to be blurred correctly.
    max_h = max(28, int(height * 0.145))
    min_h = max(20, int(height * 0.045))
    new_h = min(max_h, max(min_h, int(h)))
    center_y = int(y + h / 2)
    new_y = int(center_y - new_h / 2)
    new_y = max(0, min(new_y, height - new_h - 2))

    # Keep a little horizontal safety margin but never exceed frame bounds.
    x = max(0, min(int(x), width - 2))
    w = max(4, min(int(w), width - x))

    if int(h) != new_h or int(y) != new_y:
        print(
            f"✂️ Subtitle blur adaptive clamp: detected y={int(y)},h={int(h)} -> "
            f"y={new_y},h={new_h} (location preserved, max 14.5% of frame)"
        )
    return x, new_y, w, new_h, width, height

VideoService._detect_subtitle_box = _v59_detect_subtitle_box_adaptive
# ================= end V5.9 adaptive subtitle-blur clamp =================
