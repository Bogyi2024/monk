from __future__ import annotations

import asyncio
import ctypes
import os
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from playwright.async_api import BrowserContext, Page, TimeoutError as PlaywrightTimeoutError, async_playwright

try:
    from services.playwright_runtime import install_playwright_target_closed_filter
except ImportError:
    from playwright_runtime import install_playwright_target_closed_filter

try:
    from services.platform_caption_service import normalize_platform_caption_hashtags
except ImportError:
    from platform_caption_service import normalize_platform_caption_hashtags


def _profile_path(profile_folder_name: str) -> Path:
    current_dir = Path(__file__).resolve().parent
    project_root = current_dir.parent
    path = project_root / "browser_profiles" / profile_folder_name
    path.mkdir(parents=True, exist_ok=True)
    return path


def _proxy_config(proxy: Optional[str]) -> Optional[dict[str, str]]:
    return None  # use the OS network / external VPN


async def _grant_tiktok_local_network_permission(context: BrowserContext) -> None:
    """Pre-grant Chrome Local Network Access so TikTok Studio cannot interrupt automation with a prompt."""
    origins = [
        "https://www.tiktok.com",
        "https://www.tiktok.com",
    ]
    granted = False
    for origin in origins:
        try:
            await context.grant_permissions(["local-network-access"], origin=origin)
            granted = True
        except Exception as exc:
            print(f"⚠️ TikTok local-network permission pre-grant skipped for {origin}: {exc}")
    if granted:
        print("🔐 TikTok Local Network Access permission pre-granted.")


async def init_tiktok_profile(
    profile_folder_name: str = "TikTok_Recapentertainment",
    login_wait_seconds: int = 300,
    proxy: Optional[str] = None,
) -> None:
    """Open a persistent TikTok profile so the user can log in once."""
    profile_path = _profile_path(profile_folder_name)
    print(f"👉 TikTok profile path: {profile_path}")

    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_path),
            headless=False,
            args=["--disable-notifications", "--disable-blink-features=AutomationControlled"],
            proxy=_proxy_config(proxy),
        )
        await _grant_tiktok_local_network_permission(context)
        page = context.pages[0] if context.pages else await context.new_page()
        await page.goto(
            "https://www.tiktok.com/tiktokstudio/upload",
            timeout=120_000,
            wait_until="domcontentloaded",
        )
        print(
            f"✨ {profile_folder_name} အတွက် TikTok login ဝင်ပြီး browser ကို "
            f"{login_wait_seconds} seconds မပိတ်ဘဲထားပါ။"
        )
        await page.wait_for_timeout(max(30, login_wait_seconds) * 1000)
        await context.close()
        print("✅ TikTok persistent profile သိမ်းပြီးပါပြီ။")


async def _set_video_file(
    page: Page,
    video_path: str,
    timeout_ms: int,
    *,
    selection_delay_ms: int = 0,
    prefer_drag_drop: bool = False,
    prefer_native_dialog: bool = False,
) -> str:
    """Select a TikTok video through the visible chooser whenever possible.

    Directly assigning TikTok's hidden input works for ordinary short uploads, but
    large Episode Splitter files can leave the red Select-video control spinning
    forever without hydrating the editor.  Clicking that same control and handling
    its real file chooser (the action that fixes it manually) reliably retriggers
    TikTok's frontend upload state machine.
    """
    if prefer_native_dialog:
        try:
            return await _set_video_file_native_dialog(
                page,
                video_path,
                selection_delay_ms=selection_delay_ms,
            )
        except Exception as exc:
            print(f"⚠️ TikTok native Windows chooser failed; drag-drop fallback → {exc}")

    if prefer_drag_drop:
        try:
            return await _drop_video_file(
                page,
                video_path,
                selection_delay_ms=selection_delay_ms,
            )
        except Exception as exc:
            # Keep the proven chooser path as a bounded compatibility fallback
            # if TikTok changes the geometry of its drop target.
            print(f"⚠️ TikTok native drag-drop dispatch failed; chooser fallback → {exc}")

    button_candidates = [
        page.locator('button[data-e2e="select_video_button"]'),
        page.get_by_role("button", name="Select video", exact=False),
        page.get_by_text("Select video", exact=False),
    ]
    last_error: Optional[Exception] = None
    for candidate in button_candidates:
        try:
            button = candidate.first
            await button.wait_for(state="visible", timeout=20_000)
            async with page.expect_file_chooser(timeout=timeout_ms) as chooser_info:
                # TikTok leaves aria-disabled=false while showing its loading
                # spinner. A real click is still accepted and opens the chooser.
                await button.click(timeout=20_000, force=True)
            chooser = await chooser_info.value
            if selection_delay_ms:
                print(
                    f"⏳ TikTok chooser pacing — selecting large file after "
                    f"{selection_delay_ms / 1000:.1f}s..."
                )
                await page.wait_for_timeout(max(0, int(selection_delay_ms)))
            await chooser.set_files(video_path)
            return "chooser"
        except Exception as exc:
            last_error = exc

    # Compatibility fallback for TikTok builds that expose no clickable chooser.
    file_input = page.locator('input[type="file"][accept*="video" i], input[type="file"]').first
    try:
        await file_input.wait_for(state="attached", timeout=20_000)
        if selection_delay_ms:
            await page.wait_for_timeout(max(0, int(selection_delay_ms)))
        await file_input.set_input_files(video_path)
        return "input"
    except Exception as exc:
        last_error = exc
    raise RuntimeError(f"TikTok video file selector မတွေ့ပါ: {last_error}")


def _visible_windows_file_dialogs() -> set[int]:
    if os.name != "nt":
        return set()
    user32 = ctypes.windll.user32
    handles: set[int] = set()
    callback_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    @callback_type
    def collect(hwnd, _lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        class_name = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, class_name, len(class_name))
        if class_name.value == "#32770":
            handles.add(int(hwnd))
        return True

    user32.EnumWindows(collect, 0)
    return handles


def _send_windows_key(vk: int, *, key_up: bool = False) -> None:
    ctypes.windll.user32.keybd_event(vk, 0, 0x0002 if key_up else 0, 0)


def _send_windows_shortcut(modifier: int, key: int) -> None:
    _send_windows_key(modifier)
    _send_windows_key(key)
    _send_windows_key(key, key_up=True)
    _send_windows_key(modifier, key_up=True)


def _send_windows_unicode_text(value: str) -> None:
    user32 = ctypes.windll.user32
    for char in value:
        codepoint = ord(char)
        # KEYEVENTF_UNICODE accepts one UTF-16 code unit at a time.
        units = (
            [codepoint]
            if codepoint <= 0xFFFF
            else [
                0xD800 + ((codepoint - 0x10000) >> 10),
                0xDC00 + ((codepoint - 0x10000) & 0x3FF),
            ]
        )
        for unit in units:
            user32.keybd_event(0, unit, 0x0004, 0)
            user32.keybd_event(0, unit, 0x0004 | 0x0002, 0)


def _find_windows_dialog_child(dialog: int, class_name: str, control_id: int) -> int:
    user32 = ctypes.windll.user32
    found = 0
    callback_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    @callback_type
    def collect(hwnd, _lparam):
        nonlocal found
        name = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, name, len(name))
        if name.value == class_name and int(user32.GetDlgCtrlID(hwnd)) == int(control_id):
            found = int(hwnd)
            return False
        return True

    user32.EnumChildWindows(dialog, collect, 0)
    return found


def _complete_windows_file_dialog(
    video_path: str,
    existing_handles: set[int],
    timeout_seconds: float = 20.0,
) -> None:
    """Fill only the newly opened Windows common-file dialog."""
    if os.name != "nt":
        raise RuntimeError("native file dialog selection is Windows-only")
    user32 = ctypes.windll.user32
    deadline = time.monotonic() + max(5.0, float(timeout_seconds))
    dialog = 0
    while time.monotonic() < deadline:
        new_handles = _visible_windows_file_dialogs() - set(existing_handles)
        if new_handles:
            dialog = max(new_handles)
            break
        time.sleep(0.1)
    if not dialog:
        raise TimeoutError("new Windows Open dialog did not appear")

    filename_edit = _find_windows_dialog_child(dialog, "Edit", 1148)
    open_button = _find_windows_dialog_child(dialog, "Button", 1)
    if not filename_edit or not open_button:
        raise RuntimeError(
            f"Windows Open controls missing: filename={filename_edit}, open={open_button}"
        )

    # Address the exact File name edit (ID 1148) and Open button (ID 1).
    # This avoids locale/access-key dependence and never sends text to whatever
    # application the user happened to have focused.
    user32.SendMessageW.argtypes = [
        ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_void_p,
    ]
    user32.SendMessageW.restype = ctypes.c_ssize_t
    native_path = ctypes.c_wchar_p(str(Path(video_path).resolve()))
    user32.SendMessageW(
        ctypes.c_void_p(filename_edit),
        0x000C,  # WM_SETTEXT
        0,
        ctypes.cast(native_path, ctypes.c_void_p),
    )
    time.sleep(0.25)
    user32.SendMessageW(
        ctypes.c_void_p(open_button),
        0x00F5,  # BM_CLICK
        0,
        None,
    )

    close_deadline = time.monotonic() + 20.0
    while time.monotonic() < close_deadline:
        if not user32.IsWindow(dialog):
            return
        time.sleep(0.1)
    raise TimeoutError("Windows Open dialog stayed open after selecting the video")


async def _set_video_file_native_dialog(
    page: Page,
    video_path: str,
    *,
    selection_delay_ms: int = 0,
) -> str:
    """Use the real Windows Open dialog, matching the user's proven workflow."""
    if os.name != "nt":
        raise RuntimeError("native Windows chooser requested on a non-Windows host")
    button = page.locator('button[data-e2e="select_video_button"]').first
    try:
        await button.wait_for(state="visible", timeout=20_000)
    except Exception:
        button = page.get_by_text("Select video", exact=False).first
        await button.wait_for(state="visible", timeout=20_000)
    if selection_delay_ms:
        print(
            f"⏳ TikTok native chooser pacing — opening after "
            f"{selection_delay_ms / 1000:.1f}s..."
        )
        await page.wait_for_timeout(max(0, int(selection_delay_ms)))

    existing = await asyncio.to_thread(_visible_windows_file_dialogs)
    session = await page.context.new_cdp_session(page)
    await session.send("Page.setInterceptFileChooserDialog", {"enabled": False})
    dialog_task = asyncio.create_task(
        asyncio.to_thread(_complete_windows_file_dialog, video_path, existing)
    )
    try:
        try:
            await button.click(timeout=25_000, force=True, no_wait_after=True)
        finally:
            await dialog_task
    finally:
        await session.detach()
    print("✅ TikTok video selected through the real Windows Open dialog.")
    return "windows-native-dialog"


async def _drop_video_file(
    page: Page,
    video_path: str,
    *,
    selection_delay_ms: int = 0,
) -> str:
    """Drop a local file through Chromium's native drag payload.

    TikTok can display a loading spinner after Playwright's synthetic
    FileChooser.set_files() while never starting its upload worker. CDP's drag
    payload carries the real local path without copying a 0.6-1.0 GiB file into
    JavaScript memory and follows the same frontend path as a manual Explorer
    drag-and-drop.
    """
    target = page.locator('button[data-e2e="select_video_button"]').first
    try:
        await target.wait_for(state="visible", timeout=20_000)
    except Exception:
        target = page.get_by_text("Select video", exact=False).first
        await target.wait_for(state="visible", timeout=20_000)
    await target.scroll_into_view_if_needed(timeout=20_000)
    box = await target.bounding_box()
    if not box or box.get("width", 0) < 2 or box.get("height", 0) < 2:
        raise RuntimeError("TikTok visible drop target has no usable bounding box")
    if selection_delay_ms:
        print(
            f"⏳ TikTok drag-drop pacing — dropping large file after "
            f"{selection_delay_ms / 1000:.1f}s..."
        )
        await page.wait_for_timeout(max(0, int(selection_delay_ms)))

    x = float(box["x"]) + float(box["width"]) / 2.0
    y = float(box["y"]) + float(box["height"]) / 2.0
    data = {
        "items": [],
        "files": [str(Path(video_path).resolve())],
        "dragOperationsMask": 1,
    }
    session = await page.context.new_cdp_session(page)
    try:
        for event_type in ("dragEnter", "dragOver", "drop"):
            await session.send(
                "Input.dispatchDragEvent",
                {"type": event_type, "x": x, "y": y, "data": data},
            )
            await page.wait_for_timeout(250)
    finally:
        await session.detach()
    print("✅ TikTok video dispatched through native Chromium drag-drop.")
    return "native-drag-drop"


async def _select_tiktok_cover(
    page: Page,
    thumbnail_path: str,
    *,
    first_frame_is_thumbnail: bool = False,
    timeout_ms: int = 90_000,
) -> str:
    """Select an external cover image when offered, otherwise select frame zero.

    TikTok Studio UI varies by account/region. Some web builds expose an image
    file input inside Edit cover; others expose only a video-frame slider. The
    Episode Splitter renderer embeds the downloaded part thumbnail into frame
    zero, so both UI variants result in the same cover image.
    """
    thumbnail = Path(thumbnail_path).resolve()
    if not thumbnail.exists() or thumbnail.stat().st_size < 1_000:
        raise FileNotFoundError(f"TikTok cover thumbnail missing or invalid: {thumbnail}")

    edit_pattern = re.compile(r"^(edit|select|change)\s+cover$", re.I)
    opened = False
    candidates = [
        page.get_by_role("button", name=edit_pattern),
        page.get_by_text(edit_pattern),
        page.locator('[data-e2e*="cover" i]'),
    ]
    for candidate in candidates:
        try:
            count = min(await candidate.count(), 8)
            for index in range(count):
                control = candidate.nth(index)
                if await control.is_visible():
                    await control.click(timeout=20_000)
                    opened = True
                    break
            if opened:
                break
        except Exception:
            continue
    if not opened:
        await _debug_tiktok_page(page, "cover_edit_control_not_found")
        raise RuntimeError("TikTok Edit cover control not found")

    await page.wait_for_timeout(2_000)
    dialog = page.locator('[role="dialog"]').last
    try:
        root = dialog if await dialog.count() and await dialog.is_visible() else page
    except Exception:
        root = page

    mode = ""
    # Prefer the exact downloaded JPG/PNG when this TikTok web variant exposes
    # an image upload input in the cover editor.
    for search_root in (root, page):
        try:
            inputs = search_root.locator('input[type="file"]')
            for index in range(min(await inputs.count(), 12)):
                file_input = inputs.nth(index)
                accept = str(await file_input.get_attribute("accept") or "").casefold()
                if "image" not in accept and not any(x in accept for x in (".jpg", ".jpeg", ".png", ".webp")):
                    continue
                await file_input.set_input_files(str(thumbnail), timeout=timeout_ms)
                mode = "uploaded_image"
                break
            if mode:
                break
        except Exception:
            continue

    if not mode:
        upload_pattern = re.compile(r"^(upload|choose|select)(\s+(a\s+)?)?(cover|image|photo)$", re.I)
        for search_root in (root, page):
            try:
                buttons = search_root.get_by_role("button", name=upload_pattern)
                for index in range(min(await buttons.count(), 8)):
                    button = buttons.nth(index)
                    if not await button.is_visible():
                        continue
                    async with page.expect_file_chooser(timeout=20_000) as chooser_info:
                        await button.click(timeout=20_000)
                    chooser = await chooser_info.value
                    await chooser.set_files(str(thumbnail))
                    mode = "uploaded_image"
                    break
                if mode:
                    break
            except Exception:
                continue

    # Official TikTok cover flow can be frame-only. New Episode renders put the
    # exact part thumbnail at t=0, so moving the cover selector to its minimum is
    # an exact fallback rather than an arbitrary frame guess.
    if not mode and first_frame_is_thumbnail:
        slider = root.locator('[role="slider"], input[type="range"]').first
        try:
            await slider.wait_for(state="attached", timeout=20_000)
            tag = str(await slider.evaluate("el => el.tagName.toLowerCase()") or "")
            if tag == "input":
                await slider.evaluate("""el => {
                    const min = el.min || '0';
                    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
                    setter.call(el, min);
                    el.dispatchEvent(new Event('input', {bubbles:true}));
                    el.dispatchEvent(new Event('change', {bubbles:true}));
                }""")
            else:
                await slider.focus()
                await slider.press("Home")
            mode = "embedded_first_frame"
        except Exception:
            mode = ""

    if not mode:
        await _debug_tiktok_page(page, "custom_cover_selector_not_found")
        raise RuntimeError(
            "TikTok cover editor has no external image input, and this video does not "
            "contain the downloaded thumbnail in its first frame"
        )

    await page.wait_for_timeout(1_500)
    confirm_pattern = re.compile(r"^(save|done|confirm|apply)$", re.I)
    confirmed = False
    for _ in range(2):
        buttons = root.get_by_role("button", name=confirm_pattern)
        clicked = False
        try:
            for index in range(min(await buttons.count(), 10)):
                button = buttons.nth(index)
                if await button.is_visible() and await button.is_enabled():
                    await button.click(timeout=20_000)
                    clicked = True
                    confirmed = True
                    await page.wait_for_timeout(1_500)
                    break
        except Exception:
            pass
        if not clicked:
            break

    if not confirmed:
        await _debug_tiktok_page(page, "cover_confirm_not_found")
        raise RuntimeError("TikTok cover was selected but Save/Done control was not found")

    print(f"✅ TikTok custom cover selected ({mode}): {thumbnail.name}")
    return mode


async def _debug_tiktok_page(page: Page, label: str = "editor_not_found") -> None:
    """Save enough evidence to patch selectors again if TikTok changes its UI."""
    try:
        project_root = Path(__file__).resolve().parent.parent
        debug_dir = project_root / "downloads" / "tiktok_debug"
        debug_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        png = debug_dir / f"{label}_{stamp}.png"
        html = debug_dir / f"{label}_{stamp}.html"
        await page.screenshot(path=str(png), full_page=True)
        html.write_text(await page.content(), encoding="utf-8")
        print(f"🧪 TikTok debug screenshot: {png}")
        print(f"🧪 TikTok debug HTML: {html}")
    except Exception as exc:
        print(f"⚠️ TikTok debug capture fail: {exc}")


def _normalize_tiktok_caption_payload(value: str) -> str:
    """Conservatively remove exact duplicate blocks/hashtags."""
    text=(value or '').replace('\r\n','\n').replace('\r','\n').replace('\u00a0',' ').strip()
    if not text:
        return ''
    text=re.sub(r'\n[ \t]*\n(?:[ \t]*\n)+','\n\n',text)
    paragraphs=[p.strip() for p in re.split(r'\n\s*\n',text) if p.strip()]
    out=[]; seen=set(); tags=[]; seen_tags=set()
    for para in paragraphs:
        toks=para.split()
        if toks and all(t.startswith('#') for t in toks):
            for tag in toks:
                k=tag.casefold()
                if k not in seen_tags:
                    seen_tags.add(k); tags.append(tag)
            continue
        k=re.sub(r'\s+',' ',para).strip().casefold()
        if k in seen:
            continue
        seen.add(k); out.append(para)
    if tags:
        out.append(' '.join(tags))
    return normalize_platform_caption_hashtags('\n\n'.join(out).strip(), 'tiktok', limit=5)


async def _fill_one_editor(root, caption_text: str) -> bool:
    """Clear, fill and double-verify TikTok caption to catch delayed duplication."""
    selectors=[
        '[data-e2e="caption-editor"] [contenteditable="true"]',
        '[data-e2e="caption-container"] [contenteditable="true"]',
        '[data-e2e="video-caption"] [contenteditable="true"]',
        'div[contenteditable="true"][role="textbox"]',
        'div[contenteditable="true"][aria-label*="caption" i]',
        'div[contenteditable="true"][aria-label*="description" i]',
        'div[contenteditable="true"][data-placeholder*="caption" i]',
        'div[contenteditable="true"][data-placeholder*="description" i]',
        'div.ProseMirror[contenteditable="true"]',
        '.DraftEditor-editorContainer div[contenteditable="true"]',
        '.public-DraftEditor-content[contenteditable="true"]',
        'textarea[placeholder*="caption" i]',
        'textarea[placeholder*="description" i]',
        'textarea[aria-label*="caption" i]',
        'textarea[aria-label*="description" i]',
    ]
    def norm(v):
        return (v or '').replace('\r\n','\n').replace('\r','\n').replace('\u00a0',' ').strip()
    async def read(editor,tag):
        try:
            return norm(await editor.input_value()) if tag in ('textarea','input') else norm(await editor.inner_text())
        except Exception:
            try: return norm(await editor.evaluate("el => ('value' in el ? el.value : el.textContent) || ''"))
            except Exception: return ''
    expected=norm(caption_text)
    for sel in selectors:
        loc=root.locator(sel)
        try: count=await loc.count()
        except Exception: continue
        for i in range(min(count,5)):
            editor=loc.nth(i)
            try:
                if not await editor.is_visible(): continue
                box=await editor.bounding_box()
                if not box or box.get('width',0)<180 or box.get('height',0)<20: continue
                tag=(await editor.evaluate('el => el.tagName.toLowerCase()')) or ''
                await editor.click(force=True)
                try:
                    await editor.press('Control+A'); await editor.press('Backspace'); await asyncio.sleep(.15)
                except Exception: pass
                try:
                    await editor.fill(caption_text)
                except Exception:
                    await editor.evaluate("""(el,value)=>{el.focus();const s=window.getSelection(),r=document.createRange();r.selectNodeContents(el);s.removeAllRanges();s.addRange(r);if('value' in el&&(el.tagName==='TEXTAREA'||el.tagName==='INPUT')){const p=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(p,'value').set.call(el,value);el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:value}));}else{document.execCommand('insertText',false,value);}el.dispatchEvent(new Event('change',{bubbles:true}));}""",caption_text)
                await asyncio.sleep(.8)
                actual=await read(editor,tag)
                if actual!=expected:
                    await editor.click(force=True)
                    try:
                        await editor.press('Control+A'); await editor.press('Backspace'); await asyncio.sleep(.2); await editor.fill(caption_text)
                    except Exception: pass
                    await asyncio.sleep(1.0); actual=await read(editor,tag)
                if actual!=expected:
                    print(f'⚠️ TikTok caption immediate verify mismatch: expected={len(expected)}, actual={len(actual)}')
                    continue
                await asyncio.sleep(2.5)
                delayed=await read(editor,tag)
                if delayed==expected:
                    print(f'✅ TikTok caption Unicode exact+delayed verify OK ({len(expected)} chars).')
                    return True
                print(f'⚠️ TikTok caption changed after hydration (expected={len(expected)}, actual={len(delayed)}). Rewriting once...')
                await editor.click(force=True)
                try:
                    await editor.press('Control+A'); await editor.press('Backspace'); await asyncio.sleep(.2); await editor.fill(caption_text)
                except Exception: continue
                await asyncio.sleep(2.5)
                if await read(editor,tag)==expected:
                    print(f'✅ TikTok caption final rewrite exact-verify OK ({len(expected)} chars).')
                    return True
            except Exception:
                continue
    return False


async def _fill_caption(page: Page, caption_text: str) -> None:
    # TikTok Studio changes its editor DOM frequently and sometimes renders it a few
    # seconds after the file chooser succeeds. Wait and search all frames.
    deadline = asyncio.get_running_loop().time() + 75.0
    while asyncio.get_running_loop().time() < deadline:
        for frame in page.frames:
            if await _fill_one_editor(frame, caption_text):
                return

        # Last-resort generic visible editors. Score by caption-ish attributes and size.
        for frame in page.frames:
            generic = frame.locator('[contenteditable="true"], textarea')
            try:
                count = await generic.count()
            except Exception:
                continue
            candidates = []
            for i in range(min(count, 20)):
                el = generic.nth(i)
                try:
                    if not await el.is_visible():
                        continue
                    box = await el.bounding_box()
                    if not box or box.get("width", 0) < 250 or box.get("height", 0) < 24:
                        continue
                    meta = await el.evaluate("""el => [
                        el.getAttribute('aria-label')||'', el.getAttribute('placeholder')||'',
                        el.getAttribute('data-placeholder')||'', el.getAttribute('data-e2e')||'',
                        el.className||''
                    ].join(' ').toLowerCase()""")
                    score = 0
                    if any(k in meta for k in ('caption','description','describe','post')):
                        score += 100
                    score += min(50, int(box.get("width", 0) / 20))
                    candidates.append((score, el))
                except Exception:
                    continue
            candidates.sort(key=lambda x: x[0], reverse=True)
            for _score, el in candidates[:3]:
                try:
                    await el.click(force=True)
                    await el.fill(caption_text)
                    actual = await el.input_value() if (await el.evaluate("el => el.tagName.toLowerCase()")) == 'textarea' else await el.inner_text()
                    if actual.strip():
                        print(f"✅ TikTok caption generic Unicode fill OK ({len(caption_text)} chars).")
                        return
                except Exception:
                    continue

        await page.wait_for_timeout(2500)

    await _debug_tiktok_page(page, "caption_editor_not_found")
    raise RuntimeError("TikTok caption editor မတွေ့ပါ။ Debug screenshot/HTML ကို downloads/tiktok_debug ထဲ သိမ်းထားပါသည်။")


async def _caption_editor_visible(page: Page) -> bool:
    """Return whether TikTok's upload form/editor has hydrated in any frame."""
    selectors = (
        '[data-e2e="caption-editor"] [contenteditable="true"]',
        '[data-e2e="caption-container"] [contenteditable="true"]',
        '[data-e2e="video-caption"] [contenteditable="true"]',
        'div[contenteditable="true"][role="textbox"]',
        'div[contenteditable="true"][aria-label*="caption" i]',
        'div[contenteditable="true"][aria-label*="description" i]',
        'div.ProseMirror[contenteditable="true"]',
        '.public-DraftEditor-content[contenteditable="true"]',
        'textarea[placeholder*="caption" i]',
        'textarea[placeholder*="description" i]',
    )
    for frame in page.frames:
        for selector in selectors:
            loc = frame.locator(selector)
            try:
                for index in range(min(await loc.count(), 3)):
                    editor = loc.nth(index)
                    if not await editor.is_visible():
                        continue
                    box = await editor.bounding_box()
                    if box and box.get("width", 0) >= 180 and box.get("height", 0) >= 20:
                        return True
            except Exception:
                continue
    return False


async def _upload_entry_state(page: Page) -> dict:
    """Read upload-picker/editor transition state without depending on one CSS build."""
    try:
        return await page.evaluate(r"""() => {
            const visible = el => {
                if (!el) return false;
                const s=getComputedStyle(el), r=el.getBoundingClientRect();
                return s.display!=='none' && s.visibility!=='hidden' &&
                       Number(s.opacity||1)!==0 && r.width>0 && r.height>0;
            };
            const select=[...document.querySelectorAll('[data-e2e="select_video_button"],button')]
                .find(el => visible(el) && /select video/i.test((el.innerText||el.textContent||el.getAttribute('aria-label')||'').trim()));
            const loading=!!(select && (
                select.getAttribute('data-loading')==='true' ||
                select.className.toString().includes('loading-true') ||
                select.querySelector('[data-icon="Loading"],[data-testid="Loading"],[role="progressbar"]')
            ));
            const values=[];
            for(const el of document.querySelectorAll('progress,[role="progressbar"]')){
                if(!visible(el))continue;
                if(el.tagName.toLowerCase()==='progress'){
                    const max=Number(el.max||1), val=Number(el.value||0);
                    if(Number.isFinite(max)&&max>0&&Number.isFinite(val))values.push(val/max*100);
                } else {
                    const val=Number(el.getAttribute('aria-valuenow'));
                    if(Number.isFinite(val)&&val>=0&&val<=100)values.push(val);
                }
            }
            for(const el of document.querySelectorAll('div,span,p')){
                if(!visible(el))continue;
                const match=(el.innerText||el.textContent||'').trim().match(/^(\d{1,3}(?:\.\d+)?)%$/);
                if(match){const val=Number(match[1]);if(Number.isFinite(val)&&val>=0&&val<=100)values.push(val);}
            }
            return {
                pickerVisible: !!select,
                pickerLoading: loading,
                percent: values.length ? Math.max(...values) : null
            };
        }""")
    except Exception:
        return {"pickerVisible": False, "pickerLoading": False, "percent": None}


async def _wait_for_upload_form_ready(
    page: Page,
    video_path: str,
    *,
    timeout_ms: int = 900_000,
    spinner_reselect_seconds: float = 60.0,
    reload_after_seconds: float = 300.0,
    selection_delay_ms: int = 0,
    prefer_drag_drop: bool = False,
    prefer_native_dialog: bool = False,
) -> None:
    """Wait for large-file acceptance before touching the caption editor.

    TikTok sometimes keeps the initial Select-video card visible with
    data-loading=true while it ingests a large local file. If this entry stage
    makes no transition for one minute, click the same spinner/button and feed its
    real file chooser once (matching the proven manual recovery). If it still does
    not transition for five minutes, reload and select the same file one final time.
    """
    loop = asyncio.get_running_loop()
    deadline = loop.time() + max(600_000, int(timeout_ms)) / 1000.0
    attempt_started = loop.time()
    last_report = 0.0
    last_percent: float | None = None
    spinner_reselected = False
    page_reloaded = False

    while loop.time() < deadline:
        if await _caption_editor_visible(page):
            print("✅ TikTok upload form/caption editor ready.")
            return

        now = loop.time()
        state = await _upload_entry_state(page)
        raw_percent = state.get("percent")
        percent = float(raw_percent) if raw_percent is not None else None
        elapsed = now - attempt_started
        should_report = now - last_report >= 15.0
        if percent is not None and (last_percent is None or percent >= last_percent + 2.0):
            should_report = True
        if should_report:
            if percent is not None:
                print(f"⏳ TikTok upload form wait — {percent:.1f}% | elapsed≈{int(elapsed)}s")
            elif state.get("pickerLoading"):
                print(f"⏳ TikTok large file accepted; upload form loading... elapsed≈{int(elapsed)}s")
            else:
                print(f"⏳ TikTok upload form စောင့်နေပါတယ်... elapsed≈{int(elapsed)}s")
            last_report = now
        if percent is not None and (last_percent is None or percent > last_percent):
            last_percent = percent

        picker_visible = bool(state.get("pickerVisible"))
        picker_idle = picker_visible and not bool(state.get("pickerLoading"))
        spinner_stalled = picker_visible and elapsed >= max(30.0, float(spinner_reselect_seconds))
        if not spinner_reselected and (picker_idle or spinner_stalled):
            reason = "file selection returned idle" if picker_idle else "Select-video spinner did not transition"
            print(f"🔄 TikTok upload entry stalled ({reason}) — click spinner + chooser reselect 1/1...")
            method = await _set_video_file(
                page, video_path, 120_000,
                selection_delay_ms=selection_delay_ms,
                prefer_drag_drop=prefer_drag_drop,
                prefer_native_dialog=prefer_native_dialog,
            )
            print(f"✅ TikTok same-page file reselect dispatched via {method}.")
            spinner_reselected = True
            attempt_started = loop.time()
            last_report = 0.0
            last_percent = None
            continue

        entry_stalled = elapsed >= max(60.0, float(reload_after_seconds))
        if not page_reloaded and entry_stalled:
            print("🔄 TikTok upload form still did not transition — reload + chooser reselect 1/1...")
            await page.reload(timeout=120_000, wait_until="domcontentloaded")
            await page.wait_for_timeout(5_000)
            method = await _set_video_file(
                page, video_path, 120_000,
                selection_delay_ms=selection_delay_ms,
                prefer_drag_drop=prefer_drag_drop,
                prefer_native_dialog=prefer_native_dialog,
            )
            print(f"✅ TikTok post-reload file reselect dispatched via {method}.")
            page_reloaded = True
            attempt_started = loop.time()
            last_report = 0.0
            last_percent = None
            continue

        await page.wait_for_timeout(2_000)

    await _debug_tiktok_page(page, "upload_form_timeout")
    raise TimeoutError(
        "TikTok upload form/caption editor did not appear within the large-file wait, "
        "including one same-page chooser reselect and one reload + reselect attempt."
    )


async def _find_post_button(page: Page):
    candidates = [
        page.locator("button[data-e2e='post_video_button']"),
        page.get_by_role("button", name="Post", exact=True),
        page.get_by_role("button", name="Publish", exact=True),
    ]
    for candidate in candidates:
        try:
            if await candidate.count() > 0:
                return candidate.first
        except Exception:
            continue
    raise RuntimeError("TikTok Post button မတွေ့ပါ။")


_CONTENT_RESTRICTED_SIGNALS = (
    "content may be restricted",
    "unoriginal, low-quality, and qr code content",
    "violation reason",
)


async def _dismiss_content_restricted_warning(page: Page) -> bool:
    """Dismiss TikTok's advisory restriction dialog without clicking an unrelated X.

    The dialog explicitly says that the video can still be posted.  Scope the
    close click to the matching visible ``role=dialog`` element; TikTok Studio
    contains several other close icons that must not be touched.
    """
    dialogs = page.locator("[role='dialog']")
    for index in range(await dialogs.count()):
        dialog = dialogs.nth(index)
        try:
            if not await dialog.is_visible():
                continue
            text = (await dialog.inner_text()).lower()
            if "content may be restricted" not in text or "you can still post" not in text:
                continue

            close_button = dialog.locator(".common-modal-close").first
            if await close_button.count() == 0 or not await close_button.is_visible():
                continue

            await close_button.click(timeout=15_000)
            await dialog.wait_for(state="hidden", timeout=15_000)
            return True
        except Exception:
            continue
    return False


async def _content_check_bypass_reason(page: Page) -> str:
    """Return the validated safe-bypass reason, or an empty string.

    This is deliberately narrow: browser upload progress must be gone, the page
    must show TikTok's Content check lite wording, the music copyright section
    must explicitly say no issues were found, and no restriction/violation
    wording may be present. TikTok's isolated ``Something went wrong. Try again
    later. Retry`` message under Content check lite is a checker-service failure,
    not a content rejection, so an already-enabled Post control remains usable.
    """
    try:
        body=(await page.locator('body').inner_text(timeout=5_000)).lower()
        content_section=body.find('content check')
        content_text=body[content_section:content_section+700] if content_section>=0 else ''
        content_check_pending=(
            'checking in progress' in content_text
            and ('longer videos may take more time' in content_text or 'take about 10 minutes' in content_text)
        )
        content_check_service_error=(
            'something went wrong' in content_text
            and 'try again later' in content_text
            and 'retry' in content_text
        )
        content_check=content_section>=0 and (content_check_pending or content_check_service_error)
        music_section=body.find('music copyright check')
        music_clean=False
        if music_section>=0:
            music_clean='no issues found' in body[music_section:music_section+500]
        blocked=any(signal in body for signal in (
            'content may be restricted','violation reason','copyright violation',
            'copyright issue found','copyright issues found','upload failed',
            "couldn't upload",'could not upload',
        ))
        button=await _find_post_button(page)
        safe=bool(
            content_check and music_clean and not blocked
            and await button.is_visible() and await button.is_enabled()
            and await button.get_attribute('aria-disabled')!='true'
            and await button.get_attribute('disabled') is None
        )
        if not safe:
            return ''
        return 'service_error' if content_check_service_error else 'pending'
    except Exception:
        return ''


async def _can_post_while_content_check_pending(page: Page) -> bool:
    """Whether TikTok's enabled Post is safe despite its content-check state."""
    return bool(await _content_check_bypass_reason(page))


async def _wait_until_post_ready(
    page: Page,
    timeout_ms: int,
    *,
    allow_post_while_content_checking: bool = False,
) -> bool:
    """Wait for TikTok checking UI.

    Return True when all checks finished. Return False only for the tightly
    validated, route-opted-in Content check lite timeout path.
    """
    loop=asyncio.get_running_loop(); deadline=loop.time()+max(timeout_ms,600_000)/1000
    stable=0; last=None
    while loop.time()<deadline:
        try:
            state=await page.evaluate(r"""()=>{const vis=e=>{if(!e)return false;const s=getComputedStyle(e),r=e.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)!==0&&r.width>0&&r.height>0};const st=[];for(const e of document.querySelectorAll('div,span,p')){if(!vis(e))continue;const t=(e.innerText||e.textContent||'').replace(/\s+/g,' ').trim();if(!t||t.length>120)continue;if(/^(checking|processing|uploading|scanning)(\b|[.…:])/i.test(t)||/\b(checking|processing|uploading|scanning) (video|file|upload)\b/i.test(t)||/\b(seconds?|minutes?) left\b/i.test(t)||/\bpreparing video\b/i.test(t))st.push(t.toLowerCase())}const cancel=[...document.querySelectorAll('button')].some(b=>vis(b)&&(b.innerText||b.textContent||'').trim().toLowerCase()==='cancel');const pv=[];for(const e of document.querySelectorAll('progress,[role=progressbar]')){if(!vis(e))continue;if(e.tagName.toLowerCase()==='progress'){const m=Number(e.max||1),v=Number(e.value||0);if(Number.isFinite(v)&&Number.isFinite(m)&&m>0)pv.push(v/m*100)}else{const v=Number(e.getAttribute('aria-valuenow'));if(Number.isFinite(v))pv.push(v)}}for(const e of document.querySelectorAll('div,span,p')){if(!vis(e))continue;const m=(e.innerText||e.textContent||'').trim().match(/^(\d{1,3}(?:\.\d+)?)%$/);if(m){const v=Number(m[1]);if(Number.isFinite(v)&&v>=0&&v<=100)pv.push(v)}}return{processing:st.length>0,samples:st.slice(0,5),cancel,pct:pv.some(v=>v<99.5)}}""")
            b=await _find_post_button(page); visible=await b.is_visible(); enabled=await b.is_enabled(); aria=await b.get_attribute('aria-disabled'); disabled=await b.get_attribute('disabled')
            processing=bool(state.get('processing')); cancel=bool(state.get('cancel')); pct=bool(state.get('pct')); samples=state.get('samples') or []
            # V5.8: A stale/secondary Cancel button may remain visible after the
            # browser->TikTok transfer has already completed. Do not use Cancel as
            # a hard readiness blocker. Server-side checking is still protected by
            # `processing`, `pct`, and the actual Post enabled state.
            ok=visible and enabled and aria!='true' and disabled is None and not processing and not pct
            brief=(processing,cancel,pct,visible,enabled,aria,tuple(samples))
            if brief!=last:
                note=f', status={samples[:2]}' if samples else ''
                print(f'🧪 TikTok ready check — processing={processing}, cancel={cancel}, pct_pending={pct}, post_visible={visible}, post_enabled={enabled}{note}')
                last=brief
            if allow_post_while_content_checking and visible and enabled:
                bypass_reason=await _content_check_bypass_reason(page)
                if bypass_reason=='service_error':
                    print(
                        '⚠️ TikTok Content check lite service က “Something went wrong; try again later” '
                        'ပြထားသော်လည်း Music copyright = No issues found နှင့် Post button enabled ဖြစ်နေပါသည်။ '
                        'Violation မဟုတ်သဖြင့် ဒီ route setting အရ Post ဆက်လုပ်ပါမည်။'
                    )
                    return False
            if ok:
                stable+=1; print(f'✅ TikTok Post ready stability: {stable}/3')
                if stable>=3:
                    await page.wait_for_timeout(3000); b=await _find_post_button(page)
                    if await b.is_visible() and await b.is_enabled():
                        print('✅ TikTok checking/processing finished. Post button is stably ready.'); return True
                    stable=0
            else: stable=0
        except Exception:
            stable=0
        await page.wait_for_timeout(2000)
    if allow_post_while_content_checking and await _can_post_while_content_check_pending(page):
        print(
            '⚠️ TikTok Content check lite သတ်မှတ်စောင့်ချိန်ကျော်သွားသော်လည်း '
            'Music copyright = No issues found နှင့် Post button enabled ဖြစ်နေပါသည်။ '
            'ဒီ route setting အရ content check နောက်ကွယ်တွင်ဆက်လုပ်နေစဉ် Post ဆက်လုပ်ပါမည်။'
        )
        return False
    await _debug_tiktok_page(page,'post_not_ready_after_processing')
    waited=max(timeout_ms,600_000)/60_000
    raise TimeoutError(f'TikTok upload 100% ပြီးပြီးနောက် {waited:g} minutes အထိစောင့်ခဲ့ပေမယ့် visible Checking/Processing မပြီးသေးခြင်း သို့မဟုတ် Post button ready မဖြစ်သေးပါ။ Post ကို အတင်းမနှိပ်ပါ။')


async def _wait_for_upload_transfer_complete(
    page: Page,
    timeout_ms: int = 600_000,
    *,
    video_path: str | None = None,
    caption_text: str | None = None,
    selection_delay_ms: int = 0,
    prefer_drag_drop: bool = False,
    prefer_native_dialog: bool = False,
) -> None:
    """Wait for the browser->TikTok transfer, without false-timing-out at 100%.

    TikTok Studio has several UI variants. Some leave the word "Uploading" or a
    Cancel button visible after the actual transfer reaches 100%, while server-side
    Checking/Processing continues. The old detector scanned the whole page for the
    generic word "uploading", so it could remain `active=True` forever even though
    the progress bar visibly showed 100%.

    V5.8.2 completion rules:
      1) visible progress reaches >=99.5% stably for 3 polls -> transfer complete;
         Post does NOT need to be enabled yet because `_wait_until_post_ready()`
         handles TikTok's server-side checking next.
      2) progress UI disappears after we observed transfer activity -> complete.
      3) UI variant exposes no progress card, but Post control is visible and there
         are no strong ETA/bytes-left transfer signals for 3 polls -> complete.

    We deliberately do NOT use the generic word "uploading" as a hard blocker.
    """
    loop = asyncio.get_running_loop()
    # Large Episode parts can legitimately need much longer than ten minutes.
    # Keep a generous hard safety ceiling, but decide recovery from *stalled*
    # progress rather than total elapsed time.
    deadline = loop.time() + max(timeout_ms, 5_400_000) / 1000

    saw_transfer_signal = False
    stable_100 = 0
    stable_progress_cleared = 0
    stable_editor_ready = 0
    last_log = None
    last_progress_report_at = 0.0
    last_progress_report_pct: float | None = None
    last_progress_at = loop.time()
    highest_progress_pct: float | None = None
    transfer_reselected = False

    while loop.time() < deadline:
        try:
            state = await page.evaluate(r"""() => {
                const visible = (el) => {
                    if (!el) return false;
                    const s = getComputedStyle(el);
                    const r = el.getBoundingClientRect();
                    return s.display !== 'none' && s.visibility !== 'hidden' &&
                           Number(s.opacity || 1) !== 0 && r.width > 0 && r.height > 0;
                };

                // Prefer actual visible progress controls / standalone percentage labels.
                const vals = [];
                for (const el of document.querySelectorAll('progress')) {
                    if (!visible(el)) continue;
                    const max = Number(el.max || 1);
                    const value = Number(el.value || 0);
                    if (Number.isFinite(value) && Number.isFinite(max) && max > 0) {
                        vals.push((value / max) * 100);
                    }
                }
                for (const el of document.querySelectorAll('[role=progressbar]')) {
                    if (!visible(el)) continue;
                    const now = Number(el.getAttribute('aria-valuenow'));
                    if (Number.isFinite(now) && now >= 0 && now <= 100) vals.push(now);
                }
                for (const el of document.querySelectorAll('div,span,p')) {
                    if (!visible(el)) continue;
                    const t = (el.innerText || el.textContent || '').trim();
                    const m = t.match(/^(\d{1,3}(?:\.\d+)?)%$/);
                    if (!m) continue;
                    const v = Number(m[1]);
                    if (Number.isFinite(v) && v >= 0 && v <= 100) vals.push(v);
                }

                const maxPct = vals.length ? Math.max(...vals) : null;
                const minPct = vals.length ? Math.min(...vals) : null;

                // Strong transfer-only signals. Do not include generic "uploading";
                // TikTok may leave that label on-screen after 100%.
                const shortVisibleText = [];
                for (const el of document.querySelectorAll('div,span,p')) {
                    if (!visible(el)) continue;
                    const t = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
                    if (t && t.length <= 160) shortVisibleText.push(t);
                }
                const statusText = shortVisibleText.join(' | ');
                const etaActive = /\b\d+\s*(seconds?|minutes?)\s*left\b/i.test(statusText) ||
                                  /\b(seconds?|minutes?)\s*left\b/i.test(statusText);
                const bytesActive = /\b\d+(?:\.\d+)?\s*(kb|mb|gb)\s*\/\s*\d+(?:\.\d+)?\s*(kb|mb|gb)\b/i.test(statusText);
                const transferActive = etaActive || bytesActive;

                const cancelVisible = [...document.querySelectorAll('button')].some(b => {
                    if (!visible(b)) return false;
                    const s = (b.innerText || b.textContent || '').trim().toLowerCase();
                    return s === 'cancel';
                });

                return {
                    maxPct,
                    minPct,
                    transferActive,
                    etaActive,
                    bytesActive,
                    cancelVisible,
                    statusSample: shortVisibleText.slice(0, 30)
                };
            }""")

            max_pct = state.get("maxPct")
            transfer_active = bool(state.get("transferActive"))
            cancel_visible = bool(state.get("cancelVisible"))

            try:
                post_button = await _find_post_button(page)
                post_visible = await post_button.is_visible()
                post_enabled = await post_button.is_enabled()
            except Exception:
                post_visible = False
                post_enabled = False

            if max_pct is not None or transfer_active:
                saw_transfer_signal = True

            brief = (
                round(float(max_pct), 1) if max_pct is not None else None,
                transfer_active,
                cancel_visible,
                post_visible,
                post_enabled,
            )
            # Keep transfer polling quiet in production.  This loop can run for
            # several minutes and used to print every percentage change, flooding
            # TT Master logs.  State tracking is unchanged; only noisy progress
            # telemetry is suppressed.
            if brief != last_log:
                last_log = brief

            # Facebook-style compact progress: report percentage changes without
            # flooding the terminal. If TikTok exposes no numeric progress, emit
            # one heartbeat every 30 seconds so a large upload never looks stuck.
            now = loop.time()
            if max_pct is not None:
                numeric_pct = max(0.0, min(100.0, float(max_pct)))
                if highest_progress_pct is None or numeric_pct > highest_progress_pct + 0.05:
                    highest_progress_pct = numeric_pct
                    last_progress_at = now
                if (
                    last_progress_report_pct is None
                    or numeric_pct >= last_progress_report_pct + 2.0
                    or now - last_progress_report_at >= 15.0
                ):
                    print(f"⏳ TikTok upload transfer: {numeric_pct:.1f}%")
                    last_progress_report_pct = numeric_pct
                    last_progress_report_at = now
            elif now - last_progress_report_at >= 30.0:
                detail = "transfer active" if transfer_active or cancel_visible else "processing upload form"
                print(f"⏳ TikTok upload transfer — {detail}; numeric % not exposed yet")
                last_progress_report_at = now

            # Strongest signal: progress has reached 100%. TikTok can still be
            # Checking/Processing afterwards, which is handled by the next gate.
            if max_pct is not None and float(max_pct) >= 99.5:
                stable_100 += 1
                stable_editor_ready = 0
                if stable_100 >= 3:
                    print("✅ TikTok file transfer complete at stable 100% — waiting for server-side Post readiness next.")
                    await page.wait_for_timeout(1500)
                    return
            else:
                stable_100 = 0

            # Some UI versions remove the upload progress card as soon as transfer
            # finishes. Keep this stability counter separate from the editor-ready
            # fallback below; V5.8.1 accidentally reset the shared counter every poll.
            if saw_transfer_signal and max_pct is None and not transfer_active:
                stable_progress_cleared += 1
                if stable_progress_cleared >= 2:
                    print("✅ TikTok file transfer complete (progress UI cleared).")
                    await page.wait_for_timeout(1500)
                    return
            else:
                stable_progress_cleared = 0

            # UI variant seen on TikTok Studio: no progress element is exposed at all,
            # but the editor is already ready and the Post button is enabled.
            # V5.8.1 had a counter-reset bug here: the counter was reset to zero
            # immediately before it was incremented, so it could never reach 3.
            if not saw_transfer_signal and post_visible and post_enabled and not transfer_active:
                stable_editor_ready += 1
                if stable_editor_ready >= 3:
                    print("✅ TikTok file transfer inferred complete (editor ready + Post enabled, no active transfer signal).")
                    await page.wait_for_timeout(1000)
                    return
            else:
                stable_editor_ready = 0

            # A moving numeric percentage can run for up to the hard safety
            # ceiling. Only recover when it has not moved for five minutes. UI
            # variants without numeric progress get a ten-minute grace period.
            stall_limit = 300.0 if highest_progress_pct is not None else 600.0
            if now - last_progress_at >= stall_limit:
                if video_path and caption_text is not None and not transfer_reselected:
                    print(
                        "🔄 TikTok upload transfer stalled — reload + file reselect + caption refill once..."
                    )
                    await page.reload(timeout=120_000, wait_until="domcontentloaded")
                    await page.wait_for_timeout(5_000)
                    await _set_video_file(
                        page, video_path, 120_000,
                        selection_delay_ms=selection_delay_ms,
                        prefer_drag_drop=prefer_drag_drop,
                        prefer_native_dialog=prefer_native_dialog,
                    )
                    await _wait_for_upload_form_ready(
                        page, video_path, timeout_ms=900_000,
                        selection_delay_ms=selection_delay_ms,
                        prefer_drag_drop=prefer_drag_drop,
                        prefer_native_dialog=prefer_native_dialog,
                    )
                    await _fill_caption(page, caption_text)
                    print("✅ TikTok upload retry form restored; transfer monitoring resumed.")
                    transfer_reselected = True
                    saw_transfer_signal = False
                    stable_100 = 0
                    stable_progress_cleared = 0
                    stable_editor_ready = 0
                    last_log = None
                    last_progress_report_at = 0.0
                    last_progress_report_pct = None
                    highest_progress_pct = None
                    last_progress_at = loop.time()
                    continue
                await _debug_tiktok_page(page, "upload_transfer_stalled")
                raise TimeoutError(
                    "TikTok upload transfer progress stalled after one automatic reload/reselect retry."
                )

        except Exception:
            stable_100 = 0

        await page.wait_for_timeout(1500)

    await _debug_tiktok_page(page, "upload_transfer_timeout")
    raise TimeoutError(
        "TikTok file transfer readiness detector timeout. "
        "Debug screenshot/HTML ကို downloads/tiktok_debug ထဲ သိမ်းထားပါသည်။"
    )


async def _wait_for_real_post_confirmation(page: Page, before_url: str, timeout_ms: int = 180_000) -> bool:
    """Require a post-specific success state; do not accept generic 'uploaded' text."""
    loop = asyncio.get_running_loop()
    deadline = loop.time() + max(timeout_ms, 60_000) / 1000
    success_phrases = (
        'manage your posts',
        'upload another',
        'posted successfully',
        'post successfully',
        'your post is being processed',
        'your video is being processed',
    )
    restricted_warning_retry_used = False

    while loop.time() < deadline:
        try:
            current_url = page.url
            if current_url and before_url and current_url != before_url and '/upload' not in current_url.lower():
                print(f"✅ TikTok confirmation URL: {current_url}")
                await page.wait_for_timeout(5000)
                # TikTok sends a completed upload to its authenticated content
                # manager. This exact post-click destination is success evidence;
                # arbitrary redirects (login, home, errors) are not.
                normalized_url = current_url.lower().split('?', 1)[0].rstrip('/')
                if normalized_url == 'https://www.tiktok.com/tiktokstudio/content':
                    return True
                body = (await page.locator('body').inner_text()).lower()
                return any(phrase in body for phrase in success_phrases)

            body = (await page.locator('body').inner_text()).lower()

            # This is an advisory modal: TikTok explicitly says "You can still
            # post". Close only that dialog and repeat the Post click once. The
            # bounded retry prevents an endless click loop if TikTok shows it again.
            if any(signal in body for signal in _CONTENT_RESTRICTED_SIGNALS):
                if restricted_warning_retry_used:
                    await _debug_tiktok_page(page, 'content_restricted_after_retry')
                    raise RuntimeError(
                        'TikTok Content may be restricted warning returned after the '
                        'single safe dismiss + Post retry.'
                    )

                await _debug_tiktok_page(page, 'content_restricted_before_retry')
                dismissed = await _dismiss_content_restricted_warning(page)
                if not dismissed:
                    raise RuntimeError(
                        'TikTok Content may be restricted warning was detected, but '
                        'its scoped advisory dialog could not be dismissed safely.'
                    )

                await page.wait_for_timeout(1_500)
                post_button = await _find_post_button(page)
                if not await post_button.is_visible() or not await post_button.is_enabled():
                    raise RuntimeError(
                        'TikTok advisory warning was dismissed, but Post is not ready '
                        'for the single confirmation retry.'
                    )

                restricted_warning_retry_used = True
                print(
                    '⚠️ TikTok advisory restriction warning dismissed — '
                    'Post ကို တစ်ကြိမ်ပြန်နှိပ်ပြီး real confirmation စောင့်နေပါပြီ။'
                )
                await post_button.click(timeout=30_000)
                await page.wait_for_timeout(2_000)
                continue

            if any(p in body for p in success_phrases):
                print("✅ TikTok post confirmation UI detected.")
                await page.wait_for_timeout(5000)
                return True
        except RuntimeError as exc:
            # A bounded advisory retry failure is intentional, not a transient
            # DOM-read error. Let upload_to_tiktok() report it immediately.
            if (
                'TikTok Content may be restricted warning' in str(exc)
                or 'TikTok advisory warning' in str(exc)
            ):
                raise
        except Exception:
            pass
        await page.wait_for_timeout(2000)

    await _debug_tiktok_page(page, 'post_confirmation_timeout')
    raise TimeoutError("TikTok Post နှိပ်ပြီးနောက် တကယ့် success confirmation မရသေးပါ။ Browser ကို စောပိတ်မည်မဟုတ်ပါ။")

async def upload_to_tiktok(
    profile_folder_name: str,
    video_path: str,
    caption_text: str,
    *,
    headless: bool = False,
    proxy: Optional[str] = None,
    timeout_ms: int = 240_000,
    thumbnail_path: Optional[str] = None,
    first_frame_is_thumbnail: bool = False,
    require_thumbnail: bool = False,
    file_selection_delay_ms: int = 0,
    upload_entry_reselect_seconds: float = 60.0,
    upload_entry_reload_seconds: float = 300.0,
    prefer_drag_drop: bool = False,
    prefer_native_dialog: bool = False,
    content_check_wait_ms: int = 600_000,
    allow_post_while_content_checking: bool = False,
) -> bool:
    """Upload one rendered video to TikTok Studio using a persistent login profile."""
    install_playwright_target_closed_filter()
    video = Path(video_path).resolve()
    if not video.exists() or video.stat().st_size < 5_000:
        raise FileNotFoundError(f"TikTok upload video မတွေ့ပါ သို့မဟုတ် file ပျက်နေပါသည်: {video}")

    profile_path = _profile_path(profile_folder_name)
    print(f"🎵 TikTok upload start: {profile_folder_name} → {video.name}")

    cleanup_fingerprint = None
    try:
        from services.tiktok_draft_cleanup import fingerprint
        cleanup_fingerprint = await asyncio.to_thread(fingerprint, video)
    except Exception as exc:
        print(f"⚠️ TikTok draft fingerprint unavailable; media will be retained: {exc}")

    context: Optional[BrowserContext] = None
    async with async_playwright() as p:
        try:
            context = await p.chromium.launch_persistent_context(
                user_data_dir=str(profile_path),
                headless=headless,
                args=[
                    "--disable-notifications",
                    "--disable-blink-features=AutomationControlled",
                ],
                proxy=_proxy_config(proxy),
            )
            await _grant_tiktok_local_network_permission(context)
            page = context.pages[0] if context.pages else await context.new_page()
            await page.goto(
                "https://www.tiktok.com/tiktokstudio/upload",
                timeout=120_000,
                wait_until="domcontentloaded",
            )
            await page.wait_for_timeout(5_000)

            if "login" in page.url.lower() or await page.locator('input[name="username"]').count() > 0:
                raise RuntimeError(
                    f"TikTok profile '{profile_folder_name}' login ပြုတ်နေပါသည်။ "
                    "init_tiktok_profile() ကိုတစ်ကြိမ် run ပါ။"
                )

            await _set_video_file(
                page, str(video), timeout_ms,
                selection_delay_ms=max(0, int(file_selection_delay_ms or 0)),
                prefer_drag_drop=prefer_drag_drop,
                prefer_native_dialog=prefer_native_dialog,
            )
            print("✅ TikTok video file ရွေးပြီးပါပြီ။")
            print(f"📦 TikTok upload file size: {video.stat().st_size / (1024 * 1024):.1f} MiB")

            # Large files can leave TikTok's initial picker in data-loading=true
            # for minutes. Wait for the actual upload form before caption fill.
            await _wait_for_upload_form_ready(
                page,
                str(video),
                timeout_ms=max(timeout_ms, 900_000),
                spinner_reselect_seconds=upload_entry_reselect_seconds,
                reload_after_seconds=upload_entry_reload_seconds,
                selection_delay_ms=max(0, int(file_selection_delay_ms or 0)),
                prefer_drag_drop=prefer_drag_drop,
                prefer_native_dialog=prefer_native_dialog,
            )

            cleaned_caption = _normalize_tiktok_caption_payload(caption_text)
            normalized_original = (caption_text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
            if cleaned_caption != normalized_original:
                print(f"🧹 TikTok caption duplicate cleanup applied: {len(caption_text or '')} → {len(cleaned_caption)} chars")

            await _fill_caption(page, cleaned_caption)
            print("✅ TikTok caption ဖြည့်ပြီးပါပြီ။")

            await _wait_for_upload_transfer_complete(
                page,
                timeout_ms=max(timeout_ms, 600_000),
                video_path=str(video),
                caption_text=cleaned_caption,
                selection_delay_ms=max(0, int(file_selection_delay_ms or 0)),
                prefer_drag_drop=prefer_drag_drop,
                prefer_native_dialog=prefer_native_dialog,
            )

            if thumbnail_path:
                print("🖼️ TikTok custom cover selection...")
                await _select_tiktok_cover(
                    page,
                    thumbnail_path,
                    first_frame_is_thumbnail=first_frame_is_thumbnail,
                )
            elif require_thumbnail:
                raise RuntimeError("TikTok thumbnail is required for this upload but no thumbnail path was provided")

            checks_finished=await _wait_until_post_ready(
                page,
                timeout_ms=max(timeout_ms,int(content_check_wait_ms or 600_000)),
                allow_post_while_content_checking=allow_post_while_content_checking,
            )

            print("🔎 TikTok caption final pre-Post verify...")
            await _fill_caption(page, cleaned_caption)
            if checks_finished:
                await _wait_until_post_ready(page, timeout_ms=120_000)
            elif not await _can_post_while_content_check_pending(page):
                raise RuntimeError('TikTok Content check bypass pre-Post safety recheck failed; Post not clicked.')

            post_button = await _find_post_button(page)
            before_post_url = page.url
            print("🚀 TikTok Post ခလုတ်နှိပ်နေပါပြီ။")
            await post_button.click(timeout=30_000)

            # Never treat generic upload-progress text as success.
            explicit_post_success = await _wait_for_real_post_confirmation(
                page,
                before_url=before_post_url,
                timeout_ms=max(180_000, timeout_ms),
            )

            print("⏳ TikTok post confirmed. 10 seconds settle wait before closing browser...")
            await page.wait_for_timeout(10_000)
            print(f"🎉 TikTok upload + post confirmation completed: {profile_folder_name}")
            if cleanup_fingerprint and explicit_post_success is True:
                try:
                    from services.tiktok_draft_cleanup import record_success, cleanup_page
                    record_success(profile_folder_name, video, cleanup_fingerprint)
                    cleanup_result = await cleanup_page(page, profile_folder_name)
                    print(f"🧹 TikTok confirmed-post draft cleanup: records={cleanup_result['deleted_records']} media={cleanup_result['eligible_bytes']/1024**3:.2f}GB")
                except Exception as exc:
                    # Publishing has succeeded; retaining its draft must not turn
                    # that confirmed post into a failed/repeated upload.
                    print(f"⚠️ TikTok confirmed-post draft cleanup deferred: {exc}")
            elif cleanup_fingerprint:
                print("🛡️ TikTok draft retained: explicit successful-post UI was not observed.")
            return True
        except Exception as exc:
            print(f"❌ TikTok upload error [{profile_folder_name}]: {exc}")
            return False
        finally:
            if context is not None:
                await context.close()


if __name__ == "__main__":
    asyncio.run(init_tiktok_profile("TikTok_Recapentertainment"))
