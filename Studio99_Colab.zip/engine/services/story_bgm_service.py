from __future__ import annotations

import json
import random
from pathlib import Path
from typing import Any


class StoryBGMService:
    """Select local royalty-free music without repeats until the pool is exhausted."""

    AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}

    def __init__(self, config: dict[str, Any] | None = None):
        self.config = config or {}
        self.root = Path(self.config.get("music_root", "assets/music/drama"))
        self.registry_path = Path(
            self.config.get("music_registry", "downloads/story_music_registry.json")
        )
        self.registry_path.parent.mkdir(parents=True, exist_ok=True)

    def _load(self) -> dict[str, Any]:
        if not self.registry_path.exists():
            return {"used_tracks": [], "story_assignments": {}, "history": []}
        try:
            data = json.loads(self.registry_path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                data.setdefault("used_tracks", [])
                data.setdefault("story_assignments", {})
                data.setdefault("history", [])
                return data
        except Exception:
            pass
        return {"used_tracks": [], "story_assignments": {}, "history": []}

    def _save(self, data: dict[str, Any]) -> None:
        self.registry_path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def _all_tracks(self) -> list[Path]:
        if not self.root.exists():
            return []
        return sorted(
            p for p in self.root.rglob("*")
            if p.is_file() and p.suffix.lower() in self.AUDIO_EXTS
        )

    def _relative(self, p: Path) -> str:
        try:
            return p.resolve().relative_to(self.root.resolve()).as_posix()
        except Exception:
            return p.resolve().as_posix()

    def choose(self, *, story_id: str, mood: str) -> Path:
        data = self._load()
        assignments = data["story_assignments"]

        # Retry/re-render of the same story keeps the same BGM.
        existing = str(assignments.get(story_id) or "").strip()
        if existing:
            p = self.root / existing
            if p.exists():
                print(f"🎵 Reuse assigned BGM for this story → {existing}")
                return p

        all_tracks = self._all_tracks()
        if not all_tracks:
            raise RuntimeError(
                f"No music files found under {self.root}. "
                "Put royalty-free tracks into emotional/sad/warm/tense/hopeful folders."
            )

        mood = (mood or "emotional").strip().lower()
        mood_dir = self.root / mood
        mood_tracks = [
            p for p in all_tracks
            if mood_dir.exists() and mood_dir.resolve() in p.resolve().parents
        ]
        candidates = mood_tracks or all_tracks

        used = set(str(x) for x in data.get("used_tracks") or [])
        available = [p for p in candidates if self._relative(p) not in used]

        # If this mood is exhausted, try any still-unused track globally.
        if not available:
            available = [p for p in all_tracks if self._relative(p) not in used]

        # Whole library exhausted -> start a new no-repeat cycle.
        if not available:
            print("🔄 All drama BGM tracks were used once. Starting a new music cycle.")
            data["used_tracks"] = []
            used = set()
            available = candidates or all_tracks

        chosen = random.SystemRandom().choice(available)
        rel = self._relative(chosen)
        data["used_tracks"].append(rel)
        data["story_assignments"][story_id] = rel
        data["history"].append({"story_id": story_id, "mood": mood, "track": rel})
        data["history"] = data["history"][-1000:]
        self._save(data)

        print(f"🎵 BGM selected ({mood}) → {rel}")
        return chosen
