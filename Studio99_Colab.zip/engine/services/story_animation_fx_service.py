from __future__ import annotations

import json
import math
import os
import random
import shutil
import subprocess
import time
from pathlib import Path
from typing import Iterable


class StoryAnimationFXService:
    """Standalone visual-effect lab for TT Story Animation.

    Purpose:
    - Test the long scene-wide push/pull camera feel before wiring it into Master.
    - No Gemini/HF/fal calls are made here.
    - Uses existing Story Carousel RAW images when available.
    - One FFmpeg render runs at a time and never touches scheduler state/config.
    """

    QUICK_DURATIONS = [2.2, 2.0, 2.0, 2.2, 2.0, 2.2, 2.8]  # 15.4 sec total
    LONG_DURATIONS = [8.2, 8.5, 8.7, 9.0, 9.1, 9.4, 10.1]  # 63 sec total

    CAMERA_PATHS = (
        "push_center",
        "push_left",
        "push_right",
        "pull_center",
        "push_low",
        "push_left",
        "push_center",
    )

    def __init__(self, *, width: int = 1080, height: int = 1920, fps: int = 30):
        self.width = int(width)
        self.height = int(height)
        self.fps = int(fps)
        self.ffmpeg = self._resolve_binary(
            os.getenv("FFMPEG_PATH"), r"C:\ffmpeg\bin\ffmpeg.exe", "ffmpeg"
        )
        self.ffprobe = self._resolve_binary(
            os.getenv("FFPROBE_PATH"), r"C:\ffmpeg\bin\ffprobe.exe", "ffprobe"
        )
        self.encoder = self._pick_encoder()

    @staticmethod
    def _resolve_binary(*candidates: str | None) -> str:
        executable = str(candidates[-1])
        for item in candidates[:-1]:
            if item and os.path.isfile(item):
                return os.path.abspath(item)
        found = shutil.which(executable)
        if found:
            return found
        raise FileNotFoundError(f"{executable} not found")

    def _pick_encoder(self) -> list[str]:
        p = subprocess.run(
            [self.ffmpeg, "-hide_banner", "-encoders"],
            capture_output=True, text=True, encoding="utf-8", errors="replace"
        )
        if "h264_nvenc" in (p.stdout or ""):
            return ["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", "21", "-b:v", "0"]
        return ["-c:v", "libx264", "-preset", "veryfast", "-crf", "19"]

    @staticmethod
    def newest_story_raw_dir(root: Path = Path("outputs/story_carousel")) -> Path:
        candidates: list[Path] = []
        if root.exists():
            for story in root.iterdir():
                raw = story / "raw"
                if story.is_dir() and raw.is_dir() and list(raw.glob("slide_*.jpg")):
                    candidates.append(raw)
        if not candidates:
            raise FileNotFoundError(
                "Story Carousel RAW images မတွေ့ပါ။ outputs/story_carousel/<story>/raw/slide_*.jpg လိုပါတယ်။"
            )
        return max(candidates, key=lambda p: p.parent.stat().st_mtime)

    @staticmethod
    def collect_images(input_dir: Path, limit: int = 7) -> list[Path]:
        patterns = ("slide_*.jpg", "slide_*.jpeg", "slide_*.png", "*.jpg", "*.jpeg", "*.png")
        images: list[Path] = []
        seen: set[Path] = set()
        for pat in patterns:
            for p in sorted(input_dir.glob(pat)):
                if p.is_file() and p not in seen:
                    seen.add(p)
                    images.append(p)
                    if len(images) >= limit:
                        return images
        if len(images) < 2:
            raise FileNotFoundError(f"Not enough images in {input_dir}")
        return images

    @staticmethod
    def _duration_list(count: int, mode: str) -> list[float]:
        base = StoryAnimationFXService.LONG_DURATIONS if mode == "long" else StoryAnimationFXService.QUICK_DURATIONS
        if count <= len(base):
            return base[:count]
        # If later Story Animation grows to 12-15 scenes, use a stable narration-like duration.
        default = 7.0 if mode == "long" else 2.2
        return base + [default] * (count - len(base))

    def _camera_expr(self, camera: str, frames: int) -> tuple[str, str, str]:
        n = max(2, frames - 1)
        if camera == "pull_center":
            z = f"max(1.015,1.105-0.090*on/{n})"
            x = "(iw-iw/zoom)*0.50"
            y = "(ih-ih/zoom)*0.50"
        elif camera == "push_left":
            z = f"min(1.105,1.005+0.100*on/{n})"
            x = f"(iw-iw/zoom)*(0.58-0.12*on/{n})"
            y = f"(ih-ih/zoom)*(0.48+0.03*on/{n})"
        elif camera == "push_right":
            z = f"min(1.105,1.005+0.100*on/{n})"
            x = f"(iw-iw/zoom)*(0.42+0.12*on/{n})"
            y = f"(ih-ih/zoom)*(0.50-0.03*on/{n})"
        elif camera == "push_low":
            z = f"min(1.115,1.005+0.110*on/{n})"
            x = f"(iw-iw/zoom)*(0.49+0.02*on/{n})"
            y = f"(ih-ih/zoom)*(0.40+0.12*on/{n})"
        else:
            z = f"min(1.110,1.005+0.105*on/{n})"
            x = f"(iw-iw/zoom)*(0.49+0.02*on/{n})"
            y = f"(ih-ih/zoom)*(0.50-0.02*on/{n})"
        return z, x, y

    @staticmethod
    def _grade_filter(preset: str) -> str:
        preset = preset.lower().strip()
        if preset == "thriller":
            return (
                "eq=contrast=1.18:brightness=-0.045:saturation=0.83:gamma=0.96,"
                "colorbalance=rm=-0.025:gm=-0.005:bm=0.040,"
                "vignette=PI/5.5,noise=alls=2.2:allf=t+u,unsharp=5:5:0.32"
            )
        return (
            "eq=contrast=1.22:brightness=-0.070:saturation=0.76:gamma=0.94,"
            "colorbalance=rm=-0.025:gm=0.045:bm=-0.035,"
            "vignette=PI/5.2,noise=alls=2.8:allf=t+u,unsharp=5:5:0.30"
        )

    def _render_scene(self, image: Path, out: Path, *, duration: float, index: int, preset: str) -> None:
        frames = max(2, round(duration * self.fps))
        camera = self.CAMERA_PATHS[(index - 1) % len(self.CAMERA_PATHS)]
        z, x, y = self._camera_expr(camera, frames)
        # Cover-crop first, then move slowly through the *whole* scene.
        vf = (
            f"scale={self.width}:{self.height}:force_original_aspect_ratio=increase,"
            f"crop={self.width}:{self.height},"
            f"zoompan=z='{z}':x='{x}':y='{y}':d=1:s={self.width}x{self.height}:fps={self.fps},"
            f"{self._grade_filter(preset)},"
            "format=yuv420p"
        )
        cmd = [
            self.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
            "-loop", "1", "-framerate", str(self.fps), "-i", str(image.resolve()),
            "-vf", vf, "-t", f"{duration:.3f}", "-r", str(self.fps),
            *self.encoder, "-an", str(out.resolve())
        ]
        p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if p.returncode != 0 and "h264_nvenc" in self.encoder:
            # FFmpeg can list NVENC even when the current machine/session has no usable CUDA runtime.
            # Fall back automatically instead of failing the visual test.
            print("⚠️ NVENC unavailable at runtime — auto-fallback to libx264.")
            self.encoder = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "19"]
            cmd = [
                self.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
                "-loop", "1", "-framerate", str(self.fps), "-i", str(image.resolve()),
                "-vf", vf, "-t", f"{duration:.3f}", "-r", str(self.fps),
                *self.encoder, "-an", str(out.resolve())
            ]
            p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if p.returncode != 0:
            raise RuntimeError(f"Scene {index} render failed:\n{p.stderr[-4000:]}")
        print(f"🎥 Scene {index}: {camera} | {duration:.1f}s")

    def _concat(self, scene_files: Iterable[Path], output: Path) -> None:
        scene_files = list(scene_files)
        manifest = output.parent / "concat.txt"
        manifest.write_text("\n".join(f"file '{p.resolve().as_posix()}'" for p in scene_files), encoding="utf-8")
        cmd = [
            self.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
            "-f", "concat", "-safe", "0", "-i", str(manifest.resolve()),
            "-c", "copy", str(output.resolve())
        ]
        p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if p.returncode != 0:
            raise RuntimeError(f"Concat failed:\n{p.stderr[-4000:]}")

    @staticmethod
    def _find_music(preset: str) -> Path | None:
        roots: list[Path]
        if preset == "thriller":
            roots = [Path("assets/music/drama/tense"), Path("assets/music/drama/emotional"), Path("assets/music/drama")]
        else:
            roots = [Path("assets/music/drama/tense"), Path("assets/music/drama/sad"), Path("assets/music/drama")]
        audio_exts = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}
        for root in roots:
            if not root.exists():
                continue
            files = [p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in audio_exts]
            if files:
                return random.choice(files)
        return None

    def _add_music(self, video: Path, output: Path, music: Path, *, preset: str) -> None:
        duration = self.duration(video)
        # No narration in FX Lab, so let the music hit harder than production BGM.
        vol = 0.62 if preset == "thriller" else 0.58
        fade_out = max(0.0, duration - 1.2)
        cmd = [
            self.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
            "-i", str(video.resolve()), "-stream_loop", "-1", "-i", str(music.resolve()),
            "-filter_complex",
            f"[1:a]volume={vol},highpass=f=45,afade=t=in:st=0:d=0.12,afade=t=out:st={fade_out:.3f}:d=1.0[a]",
            "-map", "0:v:0", "-map", "[a]", "-t", f"{duration:.3f}",
            "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", str(output.resolve())
        ]
        p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if p.returncode != 0:
            raise RuntimeError(f"BGM mix failed:\n{p.stderr[-4000:]}")

    def duration(self, media: Path) -> float:
        p = subprocess.run([
            self.ffprobe, "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", str(media.resolve())
        ], capture_output=True, text=True, encoding="utf-8", errors="replace")
        if p.returncode != 0:
            raise RuntimeError(p.stderr[-2000:])
        return float(p.stdout.strip())

    def build(self, *, input_dir: Path, preset: str = "horror", mode: str = "quick", music: bool = True) -> dict:
        preset = preset.lower().strip()
        if preset not in {"horror", "thriller"}:
            raise ValueError("preset must be horror or thriller")
        mode = mode.lower().strip()
        if mode not in {"quick", "long"}:
            raise ValueError("mode must be quick or long")

        images = self.collect_images(input_dir, limit=7)
        durations = self._duration_list(len(images), mode)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        out_dir = Path("outputs/story_animation_fx_test") / f"{stamp}_{preset}_{mode}"
        scene_dir = out_dir / "scenes"
        scene_dir.mkdir(parents=True, exist_ok=True)

        scenes: list[Path] = []
        for idx, (image, dur) in enumerate(zip(images, durations), 1):
            out = scene_dir / f"scene_{idx:02d}.mp4"
            self._render_scene(image, out, duration=dur, index=idx, preset=preset)
            scenes.append(out)

        silent = out_dir / f"story_animation_{preset}_{mode}_silent.mp4"
        self._concat(scenes, silent)

        final = out_dir / f"story_animation_{preset}_{mode}.mp4"
        picked_music = self._find_music(preset) if music else None
        if picked_music:
            self._add_music(silent, final, picked_music, preset=preset)
            print(f"🎵 Test BGM → {picked_music}")
        else:
            shutil.copy2(silent, final)
            print("ℹ️ BGM pool not found — silent FX preview created.")

        report = {
            "success": True,
            "preset": preset,
            "mode": mode,
            "input_dir": str(input_dir),
            "images": [str(p) for p in images],
            "duration_seconds": round(self.duration(final), 3),
            "music": str(picked_music) if picked_music else "",
            "output": str(final),
            "notes": "Effect-only lab: no API calls, no upload, no Master scheduler state changes.",
        }
        (out_dir / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"\n✅ STORY ANIMATION FX TEST READY → {final}")
        return report
