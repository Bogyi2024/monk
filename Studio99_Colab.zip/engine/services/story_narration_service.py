from __future__ import annotations

import asyncio
import json
import re
from typing import Any

from services.ai_service import AIService


class StoryNarrationService:
    """Turn the existing 7-slide Story Board plan into a richer 7-scene Burmese narration."""

    def __init__(self, config: dict[str, Any] | None = None):
        self.config = config or {}
        self.ai = AIService()

    @staticmethod
    def _parse_json(raw: str) -> dict[str, Any]:
        text = (raw or "").strip()
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
        text = re.sub(r"\s*```$", "", text)
        try:
            return json.loads(text)
        except Exception:
            start = text.find("{")
            end = text.rfind("}")
            if start >= 0 and end > start:
                return json.loads(text[start:end + 1])
            raise

    def _validate(self, plan: dict[str, Any], expected_count: int) -> dict[str, Any]:
        scenes = plan.get("scenes") or []
        if not isinstance(scenes, list) or len(scenes) != expected_count:
            raise ValueError(f"narration scenes must be exactly {expected_count}")

        cleaned = []
        for idx, item in enumerate(scenes, 1):
            if not isinstance(item, dict):
                raise ValueError(f"scene {idx} invalid")
            narration = re.sub(r"\s+", " ", str(item.get("narration") or "")).strip()
            emotion = re.sub(r"\s+", " ", str(item.get("emotion") or "serious")).strip()
            if not narration:
                raise ValueError(f"scene {idx} narration empty")
            cleaned.append({
                "scene_no": idx,
                "narration": narration,
                "emotion": emotion,
                "motion": str(item.get("motion") or "").strip() or ("slow_push_in" if idx % 2 else "slow_pull_out"),
            })

        total_chars = sum(len(item["narration"]) for item in cleaned)
        min_chars = int(self.config.get("narration_min_chars", 650))
        if total_chars < min_chars:
            raise ValueError(f"narration too short: {total_chars} < {min_chars}")
        # V2.0.4: no hard maximum. A longer narration simply makes the matching
        # scene(s) longer; completeness is preferred over character-count trimming.

        mood = str(plan.get("music_mood") or "emotional").strip().lower()
        if mood not in {"emotional", "sad", "warm", "tense", "hopeful"}:
            mood = "emotional"

        return {
            "music_mood": mood,
            "voice_direction": str(plan.get("voice_direction") or "").strip(),
            "scenes": cleaned,
        }

    async def create_plan(self, story: dict[str, Any]) -> dict[str, Any]:
        slides = story.get("slides") or []
        if not slides:
            raise ValueError("story.json has no slides")

        slide_payload = []
        for idx, slide in enumerate(slides, 1):
            slide_payload.append({
                "scene_no": idx,
                "headline": str(slide.get("headline") or ""),
                "body": str(slide.get("body") or ""),
                "role": str(slide.get("role") or ""),
                "emotion": str(slide.get("emotion") or ""),
            })

        target_min = float(self.config.get("target_min_seconds", 66))
        retries = int(self.config.get("narration_retries", 3))

        base_prompt = f"""
မင်းက Burmese cinematic drama narrator/script writer ဖြစ်တယ်။

အောက်က Story Board 7 scenes ကို TikTok 1-minute-plus motion video အတွက်
အသံဖတ်စာသားအဖြစ် ပြန်ရေးပါ။

အဓိကစည်းကမ်း:
- ဇာတ်လမ်းအသစ် မဖန်တီးရ။ ပေးထားတဲ့ story ကိုပဲ richer narration အဖြစ်ချဲ့ပါ။
- Scene 1 မှ Scene 7 အစဉ် မပြောင်းရ။
- Scene တစ်ခုချင်းရဲ့ narration က အဲဒီပုံ/အဲဒီ scene ပြနေချိန်မှာပဲ ဖတ်ရမယ်။
- Burmese သဘာဝစကားပြောဟန်၊ အလေးအနက်ရှိတဲ့ drama narrator style ဖြစ်ရမယ်။
- ပေါ့ပေါ့ပါးပါး၊ ကြော်ငြာသံ၊ YouTuber greeting သံ မဖြစ်ရ။
- On-image headline/body ကို တိုက်ရိုက်ဖတ်ကူးရုံ မလုပ်ရ။ အဓိပ္ပာယ်တူပေမယ့် cinematic narration ဖြစ်အောင်ရေး။
- စိတ်ခံစားမှု arc: hook → setup → pressure → reveal → consequence → realization → emotional ending.
- စကားပိုမထွက်၊ မလိုတဲ့ရှင်းပြချက်မထည့်။
- ဒီ video က monetization အတွက် one-minute-plus ဖြစ်ရမယ်။ Spoken narration ကို အနည်းဆုံး {target_min:.0f} seconds ဝန်းကျင်ရအောင် လုံလောက်စွာရေး။
- ဇာတ်လမ်းအတွက်လိုရင် 75 sec, 90 sec, 120 sec သို့မဟုတ် ပိုရှည်နိုင်တယ်။ ရှည်တာကို error မယူရ။
- Scene တစ်ခုချင်းကို fixed 8-10 seconds အတင်းမချုပ်ရ။ အဲဒီ scene ရဲ့အကြောင်းအရာပြည့်စုံသလောက် 1-3 natural sentences ရေးနိုင်တယ်။
- Character-count maximum မရှိ။ Ending/facts ကို အတိုချုံ့ပြီးဖြတ်မပစ်ရ၊ repeated filler ပဲရှောင်ရ။
- TTS က ဖတ်ရလွယ်အောင် punctuation သဘာဝကျကျသုံး။
- "ဒီပုံမှာ", "Scene 1" စတဲ့ meta စကား မဖတ်ရ။

music_mood ကို emotional / sad / warm / tense / hopeful ထဲက တစ်ခုရွေး။
voice_direction မှာ ONE mature female Burmese narrator အတွက် overall delivery ကို English နဲ့တိုတိုရေး။ Character voice switching မရေးရ။

STORY TITLE:
{story.get("title", "")}

STORY SLIDES:
{json.dumps(slide_payload, ensure_ascii=False, indent=2)}

JSON ONLY:
{{
  "music_mood": "emotional",
  "voice_direction": "mature female, slightly deep, warm, restrained, cinematic...",
  "scenes": [
    {{
      "scene_no": 1,
      "narration": "မြန်မာအသံဖတ်စာ...",
      "emotion": "serious / warm / sad / tense / hopeful / reflective",
      "motion": "slow_push_in"
    }}
  ]
}}
""".strip()

        last_exc = None
        retry_note = ""
        self.ai._enable_proxy()
        try:
            for attempt in range(1, retries + 1):
                try:
                    prompt = base_prompt
                    if retry_note:
                        prompt += "\n\nIMPORTANT RETRY CORRECTION:\n" + retry_note

                    response = await asyncio.to_thread(
                        self.ai.generate_content,
                        model=self.ai.text_model,
                        contents=prompt,
                    )
                    plan = self._parse_json(response.text)
                    return self._validate(plan, len(slides))

                except Exception as exc:
                    last_exc = exc
                    msg = str(exc)
                    too_short = re.search(r"narration too short:\s*(\d+)\s*<\s*(\d+)", msg)

                    if too_short:
                        actual = int(too_short.group(1))
                        limit = int(too_short.group(2))
                        retry_note = (
                            f"Your previous narration totaled only {actual} Burmese characters. "
                            f"Expand it while preserving all 7 scenes, all facts, and the full ending. "
                            f"It must be rich enough for a one-minute-plus video and at least {limit} characters. "
                            f"There is NO maximum character limit."
                        )
                    else:
                        retry_note = (
                            "The previous response failed validation. Return strict JSON only, "
                            "keep exactly 7 narration scenes, preserve the full ending, and do not shorten for a character ceiling."
                        )

                    print(f"⚠️ Drama narration plan retry {attempt}/{retries}: {exc}")
                    await asyncio.sleep(min(2 * attempt, 5))
        finally:
            self.ai._disable_proxy()
        raise RuntimeError(f"Drama narration plan failed: {last_exc}")
