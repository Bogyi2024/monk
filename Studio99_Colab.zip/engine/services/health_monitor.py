from __future__ import annotations

import json
import time
from contextvars import ContextVar
from datetime import datetime
from pathlib import Path
from typing import Any

_ACTIVE_MONITOR: ContextVar["CycleHealthMonitor | None"] = ContextVar("recap_health_monitor", default=None)
_PAGE_KEY: ContextVar[str] = ContextVar("recap_health_page_key", default="")
_DESTINATION_KEY: ContextVar[str] = ContextVar("recap_health_destination_key", default="")


def _fmt_seconds(value: float) -> str:
    seconds = max(0, int(round(float(value or 0.0))))
    if seconds < 60:
        return f"{seconds}s"
    minutes, sec = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes}m{sec:02d}s"
    hours, minute = divmod(minutes, 60)
    return f"{hours}h{minute:02d}m{sec:02d}s"


def _safe_text(value: Any, limit: int = 500) -> str:
    text = str(value or "").strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


class CycleHealthMonitor:
    def __init__(self, *, cycle_started: datetime, output_root: str | Path = "downloads/health") -> None:
        self.started_at = cycle_started
        self.started_perf = time.perf_counter()
        self.finished_at: datetime | None = None
        self.output_root = Path(output_root)
        self.stage_records: list[dict[str, Any]] = []
        self.group_results: list[dict[str, Any]] = []
        self.group_recovery_results: list[dict[str, Any]] = []
        self.group_failures: list[dict[str, Any]] = []
        self.login_lost: list[dict[str, Any]] = []
        self.blank_reloads: list[dict[str, Any]] = []
        self.processing_records: list[dict[str, Any]] = []
        self.events: list[dict[str, Any]] = []
        self.cycle_error: str = ""
        self.cycle_no = self._next_cycle_no()
        self.cycle_id = f"{cycle_started:%Y%m%d_%H%M%S}"

    def _next_cycle_no(self) -> int:
        day_dir = self.output_root / self.started_at.strftime("%Y-%m-%d")
        try:
            return len(list(day_dir.glob("cycle_*.json"))) + 1
        except Exception:
            return 1

    def record_stage(
        self,
        stage: str,
        status: str,
        duration_s: float = 0.0,
        *,
        detail: str = "",
        page_key: str = "",
        destination_key: str = "",
        meta: dict[str, Any] | None = None,
    ) -> None:
        self.stage_records.append({
            "stage": str(stage).upper(),
            "status": str(status).lower(),
            "duration_s": round(max(0.0, float(duration_s or 0.0)), 3),
            "detail": _safe_text(detail, 1000),
            "page_key": page_key or _PAGE_KEY.get(),
            "destination_key": destination_key or _DESTINATION_KEY.get(),
            "meta": dict(meta or {}),
            "at": datetime.now().isoformat(timespec="seconds"),
        })

    def record_group_result(self, result: dict[str, Any], *, current: bool = True, post_link: str = "") -> None:
        if not isinstance(result, dict):
            return
        shared = int(result.get("shared", 0) or 0)
        failed = int(result.get("failed", 0) or 0)
        skipped = int(result.get("skipped", 0) or 0)
        total = int(result.get("total", shared + failed + skipped) or 0)
        if total <= 0:
            total = shared + failed + skipped
        item = {
            "shared": shared,
            "failed": failed,
            "skipped": skipped,
            "completed": min(total, shared + skipped),
            "total": total,
            "post_link": _safe_text(post_link, 500),
            "accounts": result.get("accounts", {}),
            "login_lost_accounts": list(result.get("login_lost_accounts", []) or []),
            "failures": list(result.get("failures", []) or []),
            "page_key": _PAGE_KEY.get(),
            "destination_key": _DESTINATION_KEY.get(),
            "at": datetime.now().isoformat(timespec="seconds"),
        }
        (self.group_results if current else self.group_recovery_results).append(item)

    def note_group_failure(self, profile: str, group_index: int | None, group_url: str, error: str) -> None:
        item = {
            "profile": _safe_text(profile, 100),
            "group_index": group_index,
            "group_url": _safe_text(group_url, 500),
            "error": _safe_text(error, 1000),
            "page_key": _PAGE_KEY.get(),
            "destination_key": _DESTINATION_KEY.get(),
            "at": datetime.now().isoformat(timespec="seconds"),
        }
        # Avoid duplicate detail entries for the same failure.
        key = (item["profile"], item["group_index"], item["group_url"], item["error"])
        if not any((x["profile"], x["group_index"], x["group_url"], x["error"]) == key for x in self.group_failures):
            self.group_failures.append(item)

    def note_login_lost(self, profile: str, platform: str = "facebook") -> None:
        profile = _safe_text(profile, 120)
        platform = _safe_text(platform, 80)
        if any(x["profile"] == profile and x["platform"] == platform for x in self.login_lost):
            return
        self.login_lost.append({
            "profile": profile,
            "platform": platform,
            "page_key": _PAGE_KEY.get(),
            "destination_key": _DESTINATION_KEY.get(),
            "at": datetime.now().isoformat(timespec="seconds"),
        })

    def note_blank_reload(self, label: str, attempt: int, max_reloads: int) -> None:
        self.blank_reloads.append({
            "label": _safe_text(label, 300),
            "attempt": int(attempt),
            "max_reloads": int(max_reloads),
            "page_key": _PAGE_KEY.get(),
            "destination_key": _DESTINATION_KEY.get(),
            "at": datetime.now().isoformat(timespec="seconds"),
        })

    def note_processing(
        self,
        platform: str,
        phase: str,
        duration_s: float,
        *,
        status: str = "ok",
        account: str = "",
        detail: str = "",
    ) -> None:
        self.processing_records.append({
            "platform": str(platform).upper(),
            "phase": _safe_text(phase, 120),
            "duration_s": round(max(0.0, float(duration_s or 0.0)), 3),
            "status": str(status).lower(),
            "account": _safe_text(account, 120),
            "detail": _safe_text(detail, 500),
            "page_key": _PAGE_KEY.get(),
            "destination_key": _DESTINATION_KEY.get(),
            "at": datetime.now().isoformat(timespec="seconds"),
        })

    def note_event(self, kind: str, detail: str = "", **meta: Any) -> None:
        self.events.append({
            "kind": _safe_text(kind, 120),
            "detail": _safe_text(detail, 1000),
            "meta": meta,
            "page_key": _PAGE_KEY.get(),
            "destination_key": _DESTINATION_KEY.get(),
            "at": datetime.now().isoformat(timespec="seconds"),
        })

    def _stage_summary(self, stage: str) -> tuple[str, float]:
        rows = [x for x in self.stage_records if x.get("stage") == stage]
        if not rows:
            return "➖", 0.0
        statuses = {str(x.get("status", "")) for x in rows}
        duration = sum(float(x.get("duration_s", 0.0) or 0.0) for x in rows)
        if "failed" in statuses or "error" in statuses:
            return "❌", duration
        if statuses <= {"ok", "success", "reused", "skipped"}:
            return "✅", duration
        return "⚠️", duration

    def _group_summary(self) -> tuple[str, int, int]:
        total = sum(int(x.get("total", 0) or 0) for x in self.group_results)
        completed = sum(int(x.get("completed", 0) or 0) for x in self.group_results)
        if total <= 0:
            return "➖", 0, 0
        completed = min(completed, total)
        if completed == total:
            return "✅", completed, total
        if completed > 0:
            return "⚠️", completed, total
        return "❌", completed, total

    def finish(self, *, cycle_error: str = "") -> Path:
        self.finished_at = datetime.now()
        self.cycle_error = _safe_text(cycle_error, 2000)
        total_s = max(0.0, time.perf_counter() - self.started_perf)

        dl_icon, dl_s = self._stage_summary("DOWNLOAD")
        gem_icon, gem_s = self._stage_summary("GEMINI")
        render_icon, render_s = self._stage_summary("RENDER")
        fb_icon, fb_s = self._stage_summary("FB")
        tt_icon, tt_s = self._stage_summary("TT")
        group_icon, group_done, group_total = self._group_summary()
        group_text = "➖" if group_total <= 0 else f"{group_done}/{group_total} {group_icon}"

        summary_line = (
            f"DOWNLOAD {dl_icon} | GEMINI {gem_icon} | RENDER {render_icon} | "
            f"FB {fb_icon} | GROUP {group_text} | TT {tt_icon}"
        )
        if self.blank_reloads:
            summary_line += f" | RELOAD {len(self.blank_reloads)}"

        cleanup_rows = [x for x in self.stage_records if x.get("stage") == "CLEANUP"]
        if cleanup_rows:
            cleanup_failed = any(str(x.get("status", "")) in {"failed", "error"} for x in cleanup_rows)
            cleanup_bytes = 0
            cleanup_jobs = 0
            for row in cleanup_rows:
                meta = row.get("meta") or {}
                cleanup_bytes += int(meta.get("freed_bytes", 0) or 0)
                cleanup_jobs += int(meta.get("deleted_jobs", 0) or 0)
            if cleanup_failed:
                summary_line += " | CLEANUP ❌"
            elif cleanup_jobs > 0:
                size = float(cleanup_bytes)
                units = ["B", "KB", "MB", "GB", "TB"]
                unit = "B"
                for unit in units:
                    if size < 1024.0 or unit == units[-1]:
                        break
                    size /= 1024.0
                size_text = f"{int(size)}{unit}" if unit == "B" else f"{size:.1f}{unit}"
                summary_line += f" | CLEANUP {cleanup_jobs} ({size_text}) ✅"

        print("\n" + "═" * 82)
        print(f"📊 CYCLE #{self.cycle_no} HEALTH — {summary_line}")
        print(
            f"⏱️ DOWNLOAD {_fmt_seconds(dl_s)} | GEMINI {_fmt_seconds(gem_s)} | "
            f"RENDER {_fmt_seconds(render_s)} | FB {_fmt_seconds(fb_s)} | "
            f"TT {_fmt_seconds(tt_s)} | TOTAL {_fmt_seconds(total_s)}"
        )

        if self.processing_records:
            parts = []
            for item in self.processing_records:
                parts.append(
                    f"{item['platform']}:{item['phase']}={_fmt_seconds(float(item['duration_s']))}"
                )
            print("⚙️ Processing: " + " | ".join(parts[:12]))

        if self.login_lost:
            profiles = ", ".join(f"{x['profile']}({x['platform']})" for x in self.login_lost)
            print(f"🔐 Login lost: {profiles}")

        if self.group_failures:
            print(f"⚠️ Group failures: {len(self.group_failures)}")
            for item in self.group_failures[:10]:
                idx = f" Group {item['group_index']}" if item.get("group_index") else ""
                print(f"   • {item['profile']}{idx}: {item['error']}")

        if self.blank_reloads:
            labels = ", ".join(x["label"] for x in self.blank_reloads[:8])
            print(f"🔄 Blank reloads: {len(self.blank_reloads)} — {labels}")

        if self.cycle_error:
            print(f"❌ Cycle error: {self.cycle_error}")

        day_dir = self.output_root / self.started_at.strftime("%Y-%m-%d")
        day_dir.mkdir(parents=True, exist_ok=True)
        path = day_dir / f"cycle_{self.cycle_id}.json"

        payload = {
            "version": 1,
            "cycle_id": self.cycle_id,
            "cycle_no": self.cycle_no,
            "started_at": self.started_at.isoformat(timespec="seconds"),
            "finished_at": self.finished_at.isoformat(timespec="seconds"),
            "duration_s": round(total_s, 3),
            "summary": summary_line,
            "cycle_error": self.cycle_error,
            "stages": self.stage_records,
            "group_results": self.group_results,
            "group_recovery_results": self.group_recovery_results,
            "group_failures": self.group_failures,
            "login_lost": self.login_lost,
            "blank_reloads": self.blank_reloads,
            "processing": self.processing_records,
            "events": self.events,
        }
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

        history = self.output_root / "health_history.jsonl"
        history.parent.mkdir(parents=True, exist_ok=True)
        with history.open("a", encoding="utf-8") as f:
            f.write(json.dumps({
                "cycle_id": self.cycle_id,
                "cycle_no": self.cycle_no,
                "started_at": payload["started_at"],
                "finished_at": payload["finished_at"],
                "duration_s": payload["duration_s"],
                "summary": summary_line,
                "login_lost": [x["profile"] for x in self.login_lost],
                "blank_reload_count": len(self.blank_reloads),
                "group_fail_count": len(self.group_failures),
                "cycle_error": self.cycle_error,
            }, ensure_ascii=False) + "\n")

        print(f"🧾 Health report saved: {path}")
        print("═" * 82 + "\n")
        return path


def start_cycle_health(*, cycle_started: datetime, output_root: str | Path = "downloads/health") -> CycleHealthMonitor:
    monitor = CycleHealthMonitor(cycle_started=cycle_started, output_root=output_root)
    _ACTIVE_MONITOR.set(monitor)
    _PAGE_KEY.set("")
    _DESTINATION_KEY.set("")
    return monitor


def finish_cycle_health(*, cycle_error: str = "") -> Path | None:
    monitor = _ACTIVE_MONITOR.get()
    if monitor is None:
        return None
    try:
        return monitor.finish(cycle_error=cycle_error)
    finally:
        _ACTIVE_MONITOR.set(None)
        _PAGE_KEY.set("")
        _DESTINATION_KEY.set("")


def set_health_context(*, page_key: str | None = None, destination_key: str | None = None) -> None:
    if page_key is not None:
        _PAGE_KEY.set(str(page_key))
    if destination_key is not None:
        _DESTINATION_KEY.set(str(destination_key))


def record_stage(stage: str, status: str, duration_s: float = 0.0, *, detail: str = "", meta: dict[str, Any] | None = None) -> None:
    monitor = _ACTIVE_MONITOR.get()
    if monitor is not None:
        monitor.record_stage(stage, status, duration_s, detail=detail, meta=meta)


def record_group_summary(result: dict[str, Any], *, current: bool = True, post_link: str = "") -> None:
    monitor = _ACTIVE_MONITOR.get()
    if monitor is not None:
        monitor.record_group_result(result, current=current, post_link=post_link)


def note_group_failure(profile: str, group_index: int | None, group_url: str, error: str) -> None:
    monitor = _ACTIVE_MONITOR.get()
    if monitor is not None:
        monitor.note_group_failure(profile, group_index, group_url, error)


def note_login_lost(profile: str, platform: str = "facebook") -> None:
    monitor = _ACTIVE_MONITOR.get()
    if monitor is not None:
        monitor.note_login_lost(profile, platform)


def note_blank_reload(label: str, attempt: int, max_reloads: int) -> None:
    monitor = _ACTIVE_MONITOR.get()
    if monitor is not None:
        monitor.note_blank_reload(label, attempt, max_reloads)


def note_processing(platform: str, phase: str, duration_s: float, *, status: str = "ok", account: str = "", detail: str = "") -> None:
    monitor = _ACTIVE_MONITOR.get()
    if monitor is not None:
        monitor.note_processing(platform, phase, duration_s, status=status, account=account, detail=detail)


def note_event(kind: str, detail: str = "", **meta: Any) -> None:
    monitor = _ACTIVE_MONITOR.get()
    if monitor is not None:
        monitor.note_event(kind, detail, **meta)
