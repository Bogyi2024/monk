from __future__ import annotations

import asyncio
import copy
import importlib.util
import inspect
import json
import os
from pathlib import Path
from typing import Any
from datetime import datetime

from services.tt_share_export_service import TTShareExportService
from services.tt_recap_guard_service import TTRecapGuardService
from services.storage_cleanup import cleanup_completed_jobs
from services.recap_source_service import RecapSourceService
from services.tt_route_branding_service import TTRouteBrandingService


class TTRecapBridge:
    """Run exactly ONE cycle of the user's current recap scheduler with TT central routes."""

    CANDIDATES = [
        "recap_auto_scheduler.py",
        "recap_auto_scheduler_v6_6_group_caption.py",
        "recap_auto_scheduler_v6_4_strict_permalink.py",
        "recap_auto_scheduler_v6_2_runtime_account_picker.py",
        "recap_auto_scheduler_v5_9_group_share.py",
    ]

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings = settings_service
        self.root = Path(project_root).resolve()
        self.module = self._load_module()
        self._services: dict[str, Any] | None = None
        self.share_export = TTShareExportService(settings_service, self.root)
        self.guard = TTRecapGuardService(self.root)
        self.branding = TTRouteBrandingService(self.root)

    def _load_module(self):
        env = os.getenv("TT_RECAP_RUNNER", "").strip()
        candidates = [env] if env else []
        candidates += self.CANDIDATES
        target = None
        for raw in candidates:
            if not raw:
                continue
            p = Path(raw)
            if not p.is_absolute():
                p = self.root / p
            if p.exists():
                target = p.resolve(); break
        if not target:
            raise FileNotFoundError("No recap scheduler file found. Expected recap_auto_scheduler.py")
        spec = importlib.util.spec_from_file_location("tt_recap_live_runner", target)
        if not spec or not spec.loader:
            raise RuntimeError(f"Cannot import recap runner: {target}")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        if not hasattr(mod, "run_cycle"):
            raise RuntimeError(f"Recap runner has no run_cycle(): {target}")
        self.runner_path = target
        return mod

    def _registry_route_snapshot(
        self,
        stream_key: str,
        required_destinations: dict[str, str],
    ) -> dict[str, Any]:
        """Return exact primary-delivery state for one Recap route.

        Recap writes one registry row per destination.  A route is complete only
        when every currently-enabled destination key is present for the same
        source video.  Failure counters are included so ``run_once`` can tell a
        real failed upload from a genuine no-content cycle and ask TT Master for
        a short, destination-only retry.
        """
        cfg_path = self.root / "config" / "recap_pages.json"
        registry = self.root / "downloads" / "recap_source_registry.json"
        try:
            if cfg_path.exists():
                cfg = json.loads(cfg_path.read_text(encoding="utf-8")); registry = self.root / str(cfg.get("registry_path") or "downloads/recap_source_registry.json")
            data = json.loads(registry.read_text(encoding="utf-8"))
        except Exception:
            return {"videos": {}, "complete": set()}

        required = set(required_destinations)
        videos: dict[str, dict[str, Any]] = {}

        # The per-video view contains both successful destinations and retry
        # counters.  It is the authoritative source for deciding what to resume.
        for vid, record in (data.get("videos") or {}).items():
            if not isinstance(record, dict):
                continue
            video_id = str(vid or "").strip()
            if not video_id:
                continue
            contracts = record.get("required_destinations_by_stream") or {}
            stored_contract = contracts.get(stream_key) if isinstance(contracts, dict) else None
            contract = {
                str(key).strip() for key in (stored_contract or required)
                if str(key).strip()
            }
            item = videos.setdefault(video_id, {
                "posted": set(), "failures": {}, "last_errors": {}, "required": contract,
            })
            item["required"] = contract
            accepted = required | contract
            for dest, meta in (record.get("posted_pages") or {}).items():
                if dest not in accepted or not isinstance(meta, dict):
                    continue
                if str(meta.get("stream_key") or "").strip() == stream_key:
                    item["posted"].add(dest)
            for dest, meta in (record.get("failures") or {}).items():
                if dest not in accepted or not isinstance(meta, dict):
                    continue
                if str(meta.get("stream_key") or "").strip() != stream_key:
                    continue
                item["failures"][dest] = max(0, int(meta.get("count") or 0))
                item["last_errors"][dest] = str(meta.get("last_error") or "")[-1500:]

        # Repair-tolerant fallback: posted_by_page can survive even when the
        # denormalized videos[].posted_pages view has drifted.
        for dest, rows in (data.get("posted_by_page") or {}).items():
            if dest not in required:
                continue
            for row in rows or []:
                try:
                    if str(row.get("stream_key") or "").strip() != stream_key:
                        continue
                    vid = str(row.get("video_id") or "").strip()
                    if vid:
                        videos.setdefault(vid, {
                            "posted": set(), "failures": {}, "last_errors": {}, "required": set(required),
                        })["posted"].add(dest)
                except Exception:
                    pass

        complete = {
            vid for vid, item in videos.items()
            if set(item.get("required") or required)
            and set(item.get("required") or required).issubset(item["posted"])
        }
        return {"videos": videos, "complete": complete}

    @staticmethod
    def _result_from_snapshots(
        *,
        route_key: str,
        required_destinations: dict[str, str],
        before: dict[str, Any],
        after: dict[str, Any],
        max_failures: int,
    ) -> dict[str, Any]:
        """Translate registry deltas into TT Master's completion/retry contract."""
        before_complete = set(before.get("complete") or set())
        after_complete = set(after.get("complete") or set())
        completed = sorted(after_complete - before_complete)
        platforms = {
            key: ("facebook" if str(platform).lower() == "fb" else str(platform).lower())
            for key, platform in required_destinations.items()
        }

        if completed:
            content_id = completed[0]
            posted = set(((after.get("videos") or {}).get(content_id) or {}).get("posted") or set())
            return {
                "success": True,
                "route_key": route_key,
                "new_content_count": len(completed),
                "new_video_ids": completed,
                "content_id": content_id,
                "primary_destinations_completed": sorted({platforms[key] for key in posted if key in platforms}),
                "failure_kind": "",
                "no_work": False,
            }

        changed_pending: list[str] = []
        before_videos = before.get("videos") or {}
        after_videos = after.get("videos") or {}
        for vid, current in after_videos.items():
            if vid in after_complete:
                continue
            previous = before_videos.get(vid) or {}
            posted_changed = set(current.get("posted") or set()) != set(previous.get("posted") or set())
            failures_changed = dict(current.get("failures") or {}) != dict(previous.get("failures") or {})
            if posted_changed or failures_changed:
                changed_pending.append(str(vid))

        if changed_pending:
            # run_cycle processes one source per route. Sorting only makes the
            # fallback deterministic if a repaired registry exposes >1 delta.
            content_id = sorted(changed_pending)[0]
            item = after_videos.get(content_id) or {}
            posted = set(item.get("posted") or set())
            item_required = list(item.get("required") or required_destinations)
            missing = [key for key in item_required if key not in posted]
            failure_counts = dict(item.get("failures") or {})
            attempt = max([int(failure_counts.get(key) or 0) for key in missing] or [1])
            retryable = any(int(failure_counts.get(key) or 0) < max_failures for key in missing)
            errors = item.get("last_errors") or {}
            last_error = next((str(errors.get(key) or "") for key in missing if errors.get(key)), "")
            return {
                "success": False,
                "route_key": route_key,
                "new_content_count": 0,
                "new_video_ids": [],
                "content_id": content_id,
                "pending": retryable,
                "pending_primary": retryable,
                "pending_destinations": [platforms[key] for key in missing],
                "primary_destinations_completed": sorted({platforms[key] for key in posted if key in platforms}),
                "retry_attempt": attempt,
                "retry_cooldown_minutes": min(20, 5 * (2 ** max(0, attempt - 1))),
                "failure_kind": "pending_destination_retry" if retryable else "destination_retries_exhausted",
                "error": last_error,
                "no_work": False,
            }

        return {
            "success": False,
            "route_key": route_key,
            "new_content_count": 0,
            "new_video_ids": [],
            "failure_kind": "no_new_content",
            "no_work": True,
        }

    def _build_runtime_config(self, route_key: str = "default") -> tuple[dict[str, Any], list[str], str]:
        m=self.module
        base=m.load_config(m.CONFIG_PATH); cfg=copy.deepcopy(base)
        pages=cfg.get("pages") or []
        if not pages: raise RuntimeError("recap_pages.json has no pages")
        page=copy.deepcopy(pages[0])
        for candidate in pages:
            if "recap" in str(candidate.get("page_key") or "").lower():
                page=copy.deepcopy(candidate); break

        resolved=self.settings.resolve_route("recap", route_key)
        category=resolved["category"]; route_cfg=resolved.get("route") or {}
        if not category.get("enabled",True) or not route_cfg.get("enabled",True):
            raise RuntimeError(f"Recap route disabled: {route_key}")

        stream_key=f"recap_{route_key}"
        page["page_key"]=stream_key
        page["route_key"]=route_key
        page["content_type"]=str(route_cfg.get("content_type") or "movie")
        branding=route_cfg.get("branding") or {}
        logo,brand_cfg=self.branding.resolve_logo("recap",route_key,branding)
        applies=bool(
            brand_cfg.get("enabled") and logo and
            ({"facebook_reel","tiktok_reel","video"} & set(brand_cfg.get("apply_to") or []))
        )
        if applies:
            from PIL import Image
            with Image.open(logo) as mark:
                logo_w=max(24,int(1080*float(brand_cfg.get("size_percent") or 10)/100.0))
                logo_h=max(1,int(mark.height*logo_w/max(1,mark.width)))
            logo_x,logo_y=self.branding._xy(1080,1920,logo_w,logo_h,str(brand_cfg.get("position") or "top_right"))
            page.update({
                "logo_path":str(logo),"logo_width":logo_w,"logo_x":logo_x,"logo_y":logo_y,
                "logo_opacity":float(brand_cfg.get("opacity") or 0.9),
            })
        else:
            page["logo_path"]=""

        source_urls=[str(x).strip() for x in (route_cfg.get("source_urls") or []) if str(x).strip()]
        if source_urls:
            source_dir=self.root/'state'/'tt_route_sources'; source_dir.mkdir(parents=True,exist_ok=True)
            source_path=source_dir/f"recap_{route_key}.txt"
            source_path.write_text("\n".join(source_urls)+"\n",encoding='utf-8')
            page["source_file"]=str(source_path)

        old_destinations=m.normalize_destinations(page) if hasattr(m,"normalize_destinations") else list(page.get("destinations") or [])
        old_by_platform={str(x.get("platform") or "").lower():x for x in old_destinations}
        new_destinations=[]
        fb=resolved.get("facebook")
        if fb and fb.get("enabled",True):
            d=copy.deepcopy(old_by_platform.get("fb") or {})
            d.update({"enabled":True,"platform":"fb","page_id":str(fb.get("page_id") or ""),"browser_profile":str(fb.get("profile") or "Main_FB_Account"),"destination_key":f"{stream_key}_FB"})
            new_destinations.append(d)
        tt=resolved.get("tiktok")
        if tt and tt.get("enabled",True):
            d=copy.deepcopy(old_by_platform.get("tiktok") or {})
            d.update({"enabled":True,"platform":"tiktok","profile_name":str(tt.get("profile") or ""),"browser_profile":str(tt.get("profile") or ""),"destination_key":f"{stream_key}_TikTok","content_check_wait_ms":int(route_cfg.get("tiktok_content_check_wait_ms",600_000) or 600_000),"allow_post_while_content_checking":bool(route_cfg.get("tiktok_allow_post_while_content_checking",False))})
            new_destinations.append(d)

        selected_share_profiles=self.share_export.sync_route("recap",route_key)
        for d in new_destinations:
            if d.get("platform")=="fb":
                g=dict(d.get("group_share") or {})
                g["enabled"]=bool(route_cfg.get("share_enabled",True) and selected_share_profiles)
                g["accounts"]=selected_share_profiles; d["group_share"]=g
        if not new_destinations:
            raise RuntimeError(f"Recap route {route_key} has no enabled Facebook/TikTok destination")
        page["enabled"]=True; page["destinations"]=new_destinations; cfg["pages"]=[page]
        runtime_sel=dict(cfg.get("facebook_group_share_runtime_selection") or {});runtime_sel.update({"prompt_on_start":False,"default":"all"});cfg["facebook_group_share_runtime_selection"]=runtime_sel
        return cfg,selected_share_profiles,stream_key

    def _ensure_services(self, config: dict[str, Any]) -> dict[str, Any]:
        if self._services is not None:
            return self._services
        m = self.module
        svc: dict[str, Any] = {}
        if hasattr(m, "AIService"): svc["ai"] = m.AIService()
        if hasattr(m, "VideoService"):
            video = m.VideoService(
                subtitle_font_size=int(config.get("default_subtitle_font_size", 36)),
                subtitle_y_fraction=float(config.get("default_subtitle_y_fraction", 0.85)),
            )
            svc["video_svc"] = video
        if hasattr(m, "VoiceService"):
            video = svc.get("video_svc")
            svc["voice_svc"] = m.VoiceService(
                ffmpeg_path=video.ffmpeg_path if video else None,
                ffprobe_path=video.ffprobe_path if video else None,
            )
        if hasattr(m, "WhisperTimestampService"):
            svc["whisper_svc"] = m.WhisperTimestampService(
                model_size=str(config.get("whisper_model", os.getenv("WHISPER_MODEL", "medium"))),
                backend=str(config.get("whisper_backend", os.getenv("WHISPER_BACKEND", "auto"))),
                device=str(config.get("whisper_device", os.getenv("WHISPER_DEVICE", "cuda"))),
                compute_type=str(config.get("whisper_compute_type", os.getenv("WHISPER_COMPUTE_TYPE", "float16"))),
                language=config.get("whisper_language") or None,
            )
        if hasattr(m, "BrowserService"): svc["browser_svc"] = m.BrowserService()
        self._services = svc
        return svc

    async def run_once(self, route_key: str = "default") -> dict[str, Any]:
        config, shares, stream_key = self._build_runtime_config(route_key)
        page = (config.get("pages") or [{}])[0]
        required_destinations = {
            str(item.get("destination_key") or ""): str(item.get("platform") or "").lower()
            for item in (page.get("destinations") or [])
            if item.get("enabled", True) and str(item.get("destination_key") or "").strip()
        }

        # V1.7.3 safety preflight:
        # - repairs posted_pages from posted_by_page history when registry views drift;
        # - blocks strong duplicate evidence from the legacy old_unposted selector;
        # - temporarily holds recently failed sources.
        guard_result = self.guard.preflight(config)

        # Both registry repair and the one-time legacy contract migration must
        # happen BEFORE the delta baseline. Otherwise merely adding the contract
        # can make dozens of old FB-only rows appear newly completed to TT Master.
        registry_value = Path(str(
            config.get("registry_path") or "downloads/recap_source_registry.json"
        ))
        registry_path = registry_value if registry_value.is_absolute() else self.root / registry_value
        contract_service = RecapSourceService(
            registry_path=str(registry_path),
            playlist_limit=int(config.get("playlist_limit") or 30),
        )
        migrated_contracts = await asyncio.to_thread(
            contract_service.migrate_legacy_destination_contracts,
            stream_key,
            list(required_destinations),
        )
        before = self._registry_route_snapshot(stream_key, required_destinations)

        services = self._ensure_services(config)
        sig = inspect.signature(self.module.run_cycle)
        kwargs = {k: v for k, v in services.items() if k in sig.parameters}
        if "runtime_group_accounts" in sig.parameters:
            kwargs["runtime_group_accounts"] = shares
        print(f"🎬 TT Recap Bridge → {self.runner_path.name} | route={route_key} | stream={stream_key} | shares={shares}")

        # The old standalone recap scheduler started CycleHealthMonitor in its
        # outer 2-hour loop. TT Master calls run_cycle() directly, so preserve
        # the proven health system here as well. This keeps DOWNLOAD/GEMINI/
        # RENDER/FB/GROUP/TT reports alive under the new Master architecture.
        health_mod = None
        health_started_here = False
        cycle_error = ""
        cleanup_result: dict[str, Any] = {}
        try:
            import services.health_monitor as health_mod
            active_ctx = getattr(health_mod, "_ACTIVE_MONITOR", None)
            already_active = bool(active_ctx and active_ctx.get() is not None)
            if not already_active and hasattr(health_mod, "start_cycle_health"):
                health_cfg = config.get("health_monitor") or {}
                health_mod.start_cycle_health(
                    cycle_started=datetime.now(),
                    output_root=str(health_cfg.get("output_dir", "downloads/health")),
                )
                health_started_here = True
                print("📊 TT Master → existing Recap CycleHealthMonitor started")
        except Exception as health_exc:
            print(f"⚠️ Recap health monitor unavailable; cycle continues: {health_exc}")
            health_mod = None

        try:
            try:
                cycle_timeout_minutes = max(
                    15.0,
                    min(120.0, float(config.get("cycle_hard_timeout_minutes") or 60)),
                )
            except (TypeError, ValueError):
                cycle_timeout_minutes = 60.0
            try:
                await asyncio.wait_for(
                    self.module.run_cycle(config, **kwargs),
                    timeout=cycle_timeout_minutes * 60.0,
                )
            except asyncio.TimeoutError as exc:
                raise TimeoutError(
                    f"Recap cycle exceeded {cycle_timeout_minutes:g} minutes hard timeout"
                ) from exc
        except Exception as exc:
            cycle_error = str(exc)
            raise
        finally:
            try:
                self.guard.postflight(config)
            except Exception as guard_exc:
                print(f"⚠️ Recap guard postflight unavailable; cycle continues: {guard_exc}")
            if health_started_here and health_mod is not None:
                try:
                    health_mod.finish_cycle_health(cycle_error=cycle_error)
                except Exception as health_exc:
                    print(f"⚠️ Could not finish Recap health report: {health_exc}")
            try:
                # TT Master intentionally calls one run_cycle(), not the standalone
                # scheduler's infinite main() loop.  Keep that architecture while
                # preserving the same 24-hour completed-media cleanup contract.
                cleanup_result = await asyncio.to_thread(cleanup_completed_jobs, config)
            except Exception as cleanup_exc:
                print(f"⚠️ Recap storage cleanup unavailable; cycle continues: {cleanup_exc}")
                cleanup_result = {"error": str(cleanup_exc)}

        after = self._registry_route_snapshot(stream_key, required_destinations)
        result = self._result_from_snapshots(
            route_key=route_key,
            required_destinations=required_destinations,
            before=before,
            after=after,
            max_failures=max(1, int(config.get("max_failures_per_video") or 3)),
        )
        if result.get("no_work"):
            # A genuinely exhausted Recap source pool should leave the front of
            # the rolling queue for a full day, not rescan every 45 minutes and
            # repeatedly delay categories that still have work.
            result["no_work_retry_minutes"] = max(
                60,
                int(config.get("source_exhausted_retry_minutes") or 1440),
            )
        result["guard"] = guard_result
        result["migrated_destination_contracts"] = migrated_contracts
        result["storage_cleanup"] = cleanup_result
        if result.get("pending_primary"):
            print(
                f"♻️ Recap primary retry queued → {result.get('content_id')} | "
                f"pending={result.get('pending_destinations')} | cooldown={result.get('retry_cooldown_minutes')}m"
            )
        return result
