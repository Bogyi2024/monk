from __future__ import annotations

import json
import os
import tempfile
import threading
import time
import copy
from functools import wraps
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from services.tt_adaptive_schedule_service import TTAdaptiveScheduleService
from services.tt_route_runtime_service import TTRouteRuntimeService
from services.tt_content_category_registry import scheduler_category_keys


def _state_transaction(method):
    """Serialize a complete daily-state read/modify/write transaction.

    ``_atomic`` already protects the final replace, but that alone does not stop
    another thread from reading an old snapshot and writing it back after a newer
    update.  The Master and Web Manager share this service class in one process,
    so the class RLock must cover the whole operation.
    """
    @wraps(method)
    def locked(self, *args, **kwargs):
        with TTDailyRunService._STATE_WRITE_LOCK:
            return method(self, *args, **kwargs)
    return locked


class TTDailyRunService:
    """Date-scoped Today Control + real-time execution history."""

    LIVE_RUNNERS={"recap","drama","story_motion","astrology","long_to_short","episode_splitter","novel","movie_review"} | scheduler_category_keys()
    ENGINE_VERSION="rolling_realtime_v2_route_page_gap"

    # Scheduler + Web Manager share the same date JSON from different threads.
    _STATE_WRITE_LOCK = threading.RLock()
    # Keep the last parsed snapshot in-process.  A dashboard read must never turn a
    # transient Windows file-share/replace error into a brand-new, disarmed day.
    _LAST_GOOD_STATE:dict[str,dict[str,Any]]={}

    def __init__(self,settings_service,project_root:str|Path="."):
        self.settings=settings_service;self.root=Path(project_root).resolve()
        self.state_dir=self.root/'state'/'tt_daily_run';self.state_dir.mkdir(parents=True,exist_ok=True)
        self.schedule=TTAdaptiveScheduleService(settings_service);self.route_runtime=TTRouteRuntimeService(settings_service)
        # Console noise control: announce a Story Motion FAL checkpoint only when
        # it first appears (or after it clears and later appears again).
        self._story_motion_fal_checkpoint_logged=False

    @staticmethod
    def _today(now:datetime|None=None)->str:
        return (now or datetime.now().astimezone()).date().isoformat()
    def _path(self,now:datetime|None=None)->Path:return self.state_dir/f"{self._today(now)}.json"

    @staticmethod
    def _atomic(path:Path,data:dict[str,Any])->None:
        # Windows-safe atomic JSON replace. WinError 5/32 is usually a short-lived
        # file-handle collision between scheduler heartbeat and TT Web Manager.
        path.parent.mkdir(parents=True,exist_ok=True)
        payload=json.dumps(data,ensure_ascii=False,indent=2)+'\n'
        last_exc=None
        with TTDailyRunService._STATE_WRITE_LOCK:
            for attempt in range(12):
                fd,name=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=str(path.parent));os.close(fd);tmp=Path(name)
                try:
                    tmp.write_text(payload,encoding='utf-8')
                    try:
                        os.replace(tmp,path)
                        TTDailyRunService._LAST_GOOD_STATE[str(path.resolve())]=copy.deepcopy(data)
                        return
                    except PermissionError as exc:
                        last_exc=exc
                        if getattr(exc,'winerror',None) not in (None,5,32) and getattr(exc,'errno',None) not in (13,):raise
                    except OSError as exc:
                        last_exc=exc
                        if getattr(exc,'winerror',None) not in (5,32):raise
                finally:
                    if tmp.exists():
                        try:tmp.unlink()
                        except Exception:pass
                if attempt in (0,3,7):print(f"⚠️ TT state write transient lock — retry {attempt+1}/12 → {path.name}")
                time.sleep(min(0.75,0.05*(attempt+1)))
        if last_exc is not None:raise last_exc
        raise RuntimeError(f"TT state atomic write failed: {path}")

    @classmethod
    def _read_existing_state(cls,path:Path)->dict[str,Any]|None:
        """Read an existing daily state without ever fabricating a replacement.

        The scheduler heartbeat and the Dashboard run in different threads and both
        touch this file frequently.  On Windows, a reader can briefly see a sharing
        violation while ``os.replace`` is committing a heartbeat.  The old fail-open
        behavior treated every read/JSON error as a missing day and then persisted a
        fresh ``armed=False, current_job=None`` state, cancelling the live upload.
        """
        key=str(path.resolve())
        last_exc:Exception|None=None
        for attempt in range(12):
            try:
                with cls._STATE_WRITE_LOCK:
                    if not path.exists():
                        cached=cls._LAST_GOOD_STATE.get(key)
                        return copy.deepcopy(cached) if cached is not None else None
                    state=json.loads(path.read_text(encoding='utf-8'))
                if not isinstance(state,dict):
                    raise ValueError(f"TT daily state root must be an object: {path}")
                with cls._STATE_WRITE_LOCK:
                    cls._LAST_GOOD_STATE[key]=copy.deepcopy(state)
                return state
            except (OSError,UnicodeError,json.JSONDecodeError,ValueError) as exc:
                last_exc=exc
                if attempt<11:
                    time.sleep(min(0.25,0.02*(attempt+1)))
        with cls._STATE_WRITE_LOCK:
            cached=cls._LAST_GOOD_STATE.get(key)
        if cached is not None:
            print(f"[WARN] TT daily state read stayed busy; last-good live state retained: {path.name}")
            return copy.deepcopy(cached)
        raise RuntimeError(f"TT daily state unreadable; refusing destructive reset: {path}") from last_exc

    def _recap_registry_summary(self,now:datetime|None=None)->dict[str,Any]:
        """Count only route-complete Recap posts from the source registry.

        ``posted_by_page`` contains one row per destination.  Counting a video as
        soon as *any* destination appears overstates a Facebook+TikTok route while
        its second upload is still pending.  Group by route/video and require every
        enabled primary platform before exposing the count to Today/scheduling.
        """
        now=now or datetime.now().astimezone();cfg_path=self.root/'config'/'recap_pages.json';registry=self.root/'downloads'/'recap_source_registry.json'
        try:
            if cfg_path.exists():
                cfg=json.loads(cfg_path.read_text(encoding='utf-8'));registry=self.root/str(cfg.get('registry_path') or 'downloads/recap_source_registry.json')
            if not registry.exists():return {'count':0,'last':'','routes':{}}
            data=json.loads(registry.read_text(encoding='utf-8'))
        except Exception:return {'count':0,'last':'','routes':{}}

        route_requirements:dict[str,set[str]]={}
        stream_to_route:dict[str,str]={}
        for route_key in self.route_runtime.enabled_routes('recap'):
            try:
                resolved=self.settings.resolve_route('recap',route_key)
                required:set[str]=set()
                if resolved.get('facebook') and (resolved.get('facebook') or {}).get('enabled',True):required.add('fb')
                if resolved.get('tiktok') and (resolved.get('tiktok') or {}).get('enabled',True):required.add('tiktok')
                if required:
                    route_requirements[str(route_key)]=required
                    stream_to_route[f"recap_{route_key}".lower()]=str(route_key)
            except Exception:
                continue

        grouped:dict[tuple[str,str],dict[str,Any]]={}
        for dest,rows in (data.get('posted_by_page') or {}).items():
            for row in rows or []:
                try:
                    stamp=str(row.get('posted_at') or '');dt=datetime.fromisoformat(stamp.replace('Z','+00:00'))
                    if dt.tzinfo is None:dt=dt.astimezone()
                    local=dt.astimezone(now.tzinfo)
                    if local.date()!=now.date():continue
                    stream=str(row.get('stream_key') or '').strip().lower()
                    route_key=stream_to_route.get(stream)
                    if not route_key:continue
                    vid=str(row.get('video_id') or '').strip()
                    if not vid:continue
                    platform=str(row.get('platform') or '').strip().lower()
                    if platform not in {'fb','tiktok'}:
                        dest_low=str(dest).lower()
                        platform='tiktok' if 'tiktok' in dest_low else ('fb' if dest_low.endswith('_fb') else '')
                    if not platform:continue
                    item=grouped.setdefault((route_key,vid),{'platforms':set(),'latest':None})
                    item['platforms'].add(platform)
                    if item['latest'] is None or local>item['latest']:item['latest']=local
                except Exception:pass

        route_ids:dict[str,set[str]]={};latest=None
        for (route_key,vid),item in grouped.items():
            if not route_requirements.get(route_key,set()).issubset(item.get('platforms') or set()):continue
            route_ids.setdefault(route_key,set()).add(vid)
            completed_at=item.get('latest')
            if completed_at is not None and (latest is None or completed_at>latest):latest=completed_at
        return {
            'count':sum(len(ids) for ids in route_ids.values()),
            'last':latest.isoformat(timespec='seconds') if latest else '',
            'routes':{rk:len(ids) for rk,ids in route_ids.items()},
            'route_ids':route_ids,
        }

    def _recap_registry_stats(self,now:datetime|None=None)->tuple[int,str]:
        summary=self._recap_registry_summary(now)
        return max(0,int(summary.get('count') or 0)),str(summary.get('last') or '')

    def _recap_pending_primary(self,now:datetime|None=None)->dict[str,Any]|None:
        """Recover a recent incomplete Recap primary job across Master restarts."""
        now=now or datetime.now().astimezone();cfg_path=self.root/'config'/'recap_pages.json';registry=self.root/'downloads'/'recap_source_registry.json'
        try:
            cfg=json.loads(cfg_path.read_text(encoding='utf-8')) if cfg_path.exists() else {}
            registry=self.root/str(cfg.get('registry_path') or 'downloads/recap_source_registry.json')
            data=json.loads(registry.read_text(encoding='utf-8'))
            max_failures=max(1,int(cfg.get('max_failures_per_video') or 3))
            max_age_hours=max(1.0,float(cfg.get('destination_retry_max_age_hours') or 24))
        except Exception:return None
        candidates=[]
        for route_key in self.route_runtime.enabled_routes('recap'):
            try:
                resolved=self.settings.resolve_route('recap',route_key);stream=f'recap_{route_key}'
                required=[]
                if resolved.get('facebook') and (resolved.get('facebook') or {}).get('enabled',True):required.append(f'{stream}_FB')
                if resolved.get('tiktok') and (resolved.get('tiktok') or {}).get('enabled',True):required.append(f'{stream}_TikTok')
                if not required:continue
            except Exception:continue
            for vid,record in (data.get('videos') or {}).items():
                if not isinstance(record,dict):continue
                posted={
                    str(key) for key,meta in (record.get('posted_pages') or {}).items()
                    if isinstance(meta,dict) and str(meta.get('stream_key') or '')==stream
                }
                missing=[key for key in required if key not in posted]
                if not missing:continue
                retry_rows=[]
                for key in missing:
                    failure=(record.get('failures') or {}).get(key) or {}
                    if str(failure.get('stream_key') or '')!=stream:continue
                    count=max(0,int(failure.get('count') or 0))
                    if count<=0 or count>=max_failures:continue
                    try:
                        failed_at=datetime.fromisoformat(str(failure.get('last_failed_at') or '').replace('Z','+00:00'))
                        if failed_at.tzinfo is None:failed_at=failed_at.astimezone()
                        failed_at=failed_at.astimezone(now.tzinfo)
                    except Exception:continue
                    if now-failed_at>timedelta(hours=max_age_hours):continue
                    retry_rows.append((failed_at,count,key,str(failure.get('last_error') or '')[-1200:]))
                if not retry_rows:continue
                failed_at,attempt,_key,error=max(retry_rows,key=lambda item:item[0])
                cooldown=min(20,5*(2**max(0,attempt-1)))
                candidates.append({
                    'route_key':str(route_key),'content_id':str(vid),'attempt':attempt,
                    'failed_at':failed_at.isoformat(timespec='seconds'),
                    'retry_at':(failed_at+timedelta(minutes=cooldown)).isoformat(timespec='seconds'),
                    'error':error,'missing_destinations':missing,
                })
        return max(candidates,key=lambda item:item['failed_at']) if candidates else None


    @staticmethod
    def _drama_result_content_id(result:dict[str,Any]|None)->str:
        result=result or {}
        sid=str(result.get('story_id') or '').strip()
        if sid:return sid
        try:
            story_json=Path(str(result.get('story_json') or ''))
            if story_json.name:return story_json.resolve().parent.name
        except Exception:pass
        return ''

    def _drama_same_day_primary_evidence(self,now:datetime)->dict[str,set[str]]:
        """Legacy/current local receipts used only to heal missing Today counts.

        Future jobs are counted live by content_id. This reconciliation is deliberately
        conservative: completed folders must carry today's YYYYMMDD prefix; a pending
        story must have both configured primary destinations done and an FB upload
        start timestamp from today. Group-share completion is NOT required.
        """
        evidence:dict[str,set[str]]={}
        prefix=now.strftime('%Y%m%d_')
        root=self.root/'outputs'/'story_carousel'
        if root.exists():
            for folder in root.iterdir():
                if not folder.is_dir() or not folder.name.startswith(prefix) or not folder.name.endswith('_drama'):
                    continue
                receipt=folder/'tt_master_completed.json'
                if not receipt.exists():continue
                try:
                    data=json.loads(receipt.read_text(encoding='utf-8'))
                    if not bool(data.get('completed')):continue
                    route=str(data.get('route_key') or 'default')
                    cid=str(data.get('content_id') or folder.name).strip() or folder.name
                    evidence.setdefault(route,set()).add(cid)
                except Exception:continue

        pending_path=self.root/'state'/'tt_drama_pending.json'
        try:
            if pending_path.exists():
                pending=json.loads(pending_path.read_text(encoding='utf-8'))
                if isinstance(pending,dict):
                    route=str(pending.get('route_key') or 'default')
                    _wf,_wt,_wg,primary_complete,_secondary_complete=self._route_requirement_state('drama',route,pending)
                    if primary_complete:
                        ts=float(pending.get('fb_upload_started_at') or 0)
                        local=datetime.fromtimestamp(ts,tz=now.tzinfo) if ts>0 else now
                        if local.date()==now.date():
                            cid=self._drama_result_content_id(pending.get('result') if isinstance(pending.get('result'),dict) else {})
                            if cid:evidence.setdefault(route,set()).add(cid)
        except Exception:pass
        return evidence

    def _route_requirement_state(self,category_key:str,route_key:str,pending:dict[str,Any])->tuple[bool,bool,bool,bool,bool]:
        """Return (want_fb,want_tt,want_group,primary_complete,secondary_complete).

        IMPORTANT: completion follows configured ENABLED primary destinations, not
        hard-coded fb_done+tt_done. A Facebook-only route completes when Facebook is
        done; a TikTok-only route completes when TikTok is done. No share accounts =
        no secondary work at all.
        """
        try:
            resolved=self.settings.resolve_route(category_key,route_key)
            fb=resolved.get('facebook');tt=resolved.get('tiktok');route=resolved.get('route') or {}
            want_fb=bool(fb and fb.get('enabled',True));want_tt=bool(tt and tt.get('enabled',True))
            shares=[x for x in (resolved.get('share_accounts') or []) if isinstance(x,dict) and x.get('enabled',True)]
            want_group=bool(want_fb and route.get('share_enabled',True) and shares)
        except Exception:
            want_fb=want_tt=True;want_group=bool(pending.get('group_done') is False)
        primary_complete=((not want_fb) or bool(pending.get('fb_done'))) and ((not want_tt) or bool(pending.get('tt_done')))
        secondary_complete=(not want_group) or bool(pending.get('group_done'))
        return want_fb,want_tt,want_group,bool(primary_complete),bool(secondary_complete)

    def _story_motion_fal_resume_pending(self,now:datetime)->bool:
        root=self.root/'outputs'/'story_motion'
        if not root.exists():return False
        cutoff=now.timestamp()-24*3600
        try:
            for q in root.glob('*/raw/*.fal_queue.json'):
                try:
                    if q.stat().st_mtime < cutoff:continue
                    # queue checkpoint is meaningful only while its target image is absent/invalid
                    img=Path(str(q)[:-len('.fal_queue.json')])
                    if (not img.exists()) or img.stat().st_size < 5000:return True
                except Exception:continue
        except Exception:pass
        return False

    @staticmethod
    def _is_transient_story_motion_fal_error(message:str)->bool:
        """Recognize old daily-state failures that should have been a network wait."""
        msg=str(message or '').lower()
        if 'fal' not in msg:
            return False
        if any(x in msg for x in ('http 400','http 401','http 402','http 403','http 404','http 409','http 422','quota','insufficient balance','content policy','safety checker')):
            return False
        return any(x in msg for x in (
            'ssleoferror','unexpected_eof_while_reading','unexpected eof while reading','sslerror',
            'connectionpool','max retries exceeded','connection reset','connection aborted',
            'remote disconnected','name resolution','getaddrinfo failed','temporary failure in name resolution',
            'chunkedencodingerror','protocolerror','connecttimeout','readtimeout','read timed out',
            'connect timed out','connection timed out','http 500','http 502','http 503','http 504',
        ))

    # ------------------------------------------------------------------
    # V2.0.16 DURABLE COMPLETION LEDGER
    # ------------------------------------------------------------------
    def _completion_receipt_path(self, now: datetime) -> Path:
        folder = self.root / 'state' / 'tt_completion_receipts'
        folder.mkdir(parents=True, exist_ok=True)
        return folder / f"{now.date().isoformat()}.json"

    def _load_completion_receipts(self, now: datetime) -> dict[str, Any]:
        path = self._completion_receipt_path(now)
        if not path.exists():
            return {'date': now.date().isoformat(), 'version': 1, 'categories': {}}
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            if not isinstance(data, dict) or str(data.get('date') or '') != now.date().isoformat():
                raise ValueError('invalid receipt ledger')
            data.setdefault('categories', {})
            return data
        except Exception as exc:
            # Never silently replace a corrupt durable ledger: preserve it and start
            # an empty in-memory view so the operator can inspect the bad file.
            print(f"⚠️ Completion receipt ledger read warning: {exc} ({path})")
            return {'date': now.date().isoformat(), 'version': 1, 'categories': {}}

    def _save_completion_receipts(self, now: datetime, data: dict[str, Any]) -> None:
        path = self._completion_receipt_path(now)
        data['date'] = now.date().isoformat()
        data['version'] = 1
        self._atomic(path, data)

    def _record_completion_receipt(
        self, category: str, route_key: str, content_id: str, count_increment: int,
        now: datetime, *, job_id: str = '', result: dict[str, Any] | None = None,
    ) -> str:
        """Persist primary completion BEFORE relying on mutable daily-run state.

        The content token is idempotent. A crash/reset after this write is safe:
        get() will reconstruct category/route Done counts from this ledger.
        """
        increment = max(1, int(count_increment or 1))
        token = str(content_id or '').strip()
        if not token:
            token = f"{category}:{now.date().isoformat()}:job:{str(job_id or now.strftime('%H%M%S'))}"
        data = self._load_completion_receipts(now)
        cats = data.setdefault('categories', {})
        crow = cats.setdefault(str(category), {'receipts': {}})
        receipts = crow.setdefault('receipts', {})
        if token not in receipts:
            receipts[token] = {
                'content_id': token,
                'route_key': str(route_key or 'default'),
                'count_increment': increment,
                'completed_at': now.isoformat(timespec='seconds'),
                'job_id': str(job_id or ''),
                'primary_destinations': list((result or {}).get('primary_destinations_completed') or (result or {}).get('destinations_completed') or []),
            }
            self._save_completion_receipts(now, data)
            print(f"🔐 Durable completion receipt saved → {category}/{route_key} | {token}")
        return token

    def _receipt_summary(self, now: datetime) -> dict[str, dict[str, Any]]:
        data = self._load_completion_receipts(now)
        recap_registry = self._recap_registry_summary(now)
        recap_route_ids = recap_registry.get('route_ids') or {}
        out: dict[str, dict[str, Any]] = {}
        for category, crow in (data.get('categories') or {}).items():
            receipts = (crow or {}).get('receipts') or {}
            total = 0
            route_totals: dict[str, int] = {}
            ids: set[str] = set()
            for token, raw in receipts.items():
                if not isinstance(raw, dict):
                    continue
                inc = max(1, int(raw.get('count_increment') or 1))
                rk = str(raw.get('route_key') or 'default')
                content_id = str(raw.get('content_id') or token)
                if str(category) == 'recap':
                    # Legacy Recap bridge wrote a receipt after only one primary
                    # destination. Do not let that bad receipt remain an immutable
                    # Today-count floor. Exact registry completion or an explicit
                    # all-primary proof is required.
                    completed_ids = {str(x) for x in (recap_route_ids.get(rk) or set())}
                    proof = {str(x).strip().lower() for x in (raw.get('primary_destinations') or [])}
                    proof.discard('')
                    try:
                        resolved = self.settings.resolve_route('recap', rk)
                        required = set()
                        if resolved.get('facebook') and (resolved.get('facebook') or {}).get('enabled', True): required.add('facebook')
                        if resolved.get('tiktok') and (resolved.get('tiktok') or {}).get('enabled', True): required.add('tiktok')
                    except Exception:
                        required = {'facebook', 'tiktok'}
                    if content_id not in completed_ids and not (required and required.issubset(proof)):
                        continue
                total += inc
                route_totals[rk] = route_totals.get(rk, 0) + inc
                ids.add(content_id)
            out[str(category)] = {'count': total, 'routes': route_totals, 'content_ids': ids}
        return out

    def _reconcile_durable_completion_receipts(self, state: dict[str, Any], now: datetime) -> bool:
        """Receipts are a floor: mutable daily JSON may go up, never below proven posts."""
        changed = False
        summary = self._receipt_summary(now)
        for category, evidence in summary.items():
            row = (state.get('categories') or {}).get(category)
            if not isinstance(row, dict):
                continue
            proven = max(0, int(evidence.get('count') or 0))
            current = max(0, int(row.get('already_posted') or 0))
            if current < proven:
                row['already_posted'] = proven
                row['count_source'] = 'durable_receipts'
                ids = set(str(x) for x in (row.get('counted_content_ids') or []) if str(x))
                ids |= set(str(x) for x in (evidence.get('content_ids') or set()) if str(x))
                row['counted_content_ids'] = sorted(ids)[-500:]
                row['last_error'] = ''
                state.setdefault('events', []).append({
                    'type': 'durable_completion_reconciled', 'category': category,
                    'at': now.isoformat(timespec='seconds'), 'from': current, 'to': proven,
                    'message': 'Daily state was below immutable primary-post receipts; Done count restored to prevent duplicate reposting.'
                })
                print(f"🛡️ Durable Done restore → {category}: {current} → {proven}")
                changed = True
            rr = ((state.get('route_runtime') or {}).get('routes') or {}).setdefault(category, {})
            for rk, rcount in (evidence.get('routes') or {}).items():
                rrow = rr.setdefault(str(rk), {})
                existing = max(0, int(rrow.get('already_posted') or 0))
                rcount = max(0, int(rcount or 0))
                if existing < rcount:
                    rrow['already_posted'] = rcount
                    changed = True
        return changed

    def _reconcile_recap_route_counts(self,state:dict[str,Any],now:datetime)->bool:
        """Make Recap parent/route counters agree with completed-primary evidence.

        Recap is multi-route, so an unassigned manual parent count cannot safely
        choose the next route.  Registry completions and durable receipts both carry
        route identity; use the larger proven count per route, then derive the parent.
        Never reconcile while a live job is between destination writes and receipt.
        """
        if state.get('current_job'):return False
        enabled=self.route_runtime.enabled_routes('recap')
        if not enabled:return False
        registry=self._recap_registry_summary(now)
        receipt=((self._receipt_summary(now).get('recap') or {}).get('routes') or {})
        registry_routes=registry.get('routes') or {}
        desired_routes={
            str(rk):max(0,int(registry_routes.get(rk) or 0),int(receipt.get(rk) or 0))
            for rk in enabled
        }
        # Do not erase a manually seeded pre-ledger day when no exact route evidence exists.
        if not any(desired_routes.values()):return False
        desired_total=sum(desired_routes.values());changed=False
        rr=((state.get('route_runtime') or {}).get('routes') or {}).setdefault('recap',{})
        for rk,desired in desired_routes.items():
            rrow=rr.setdefault(rk,{})
            current=max(0,int(rrow.get('already_posted') or 0))
            if current!=desired:
                rrow['already_posted']=desired;changed=True
        row=(state.get('categories') or {}).get('recap') or {}
        current=max(0,int(row.get('already_posted') or 0))
        if current!=desired_total:
            row['already_posted']=desired_total
            row['count_source']='route_completion_evidence'
            row['last_completed_at']=str(registry.get('last') or row.get('last_completed_at') or '')
            state.setdefault('events',[]).append({
                'type':'recap_multi_route_count_reconciled','category':'recap',
                'at':now.isoformat(timespec='seconds'),'from':current,'to':desired_total,
                'routes':desired_routes,
                'message':'Recap parent Done was derived from route-complete primary evidence; partial destination uploads were excluded.'
            })
            print(f"🧮 Recap route counts reconciled → parent {current} → {desired_total} | routes={desired_routes}")
            changed=True
        return changed

    def _story_motion_same_day_primary_evidence(self,now:datetime)->dict[str,set[str]]:
        evidence:dict[str,set[str]]={}
        path=self.root/'state'/'tt_story_motion_primary_receipts.json'
        try:
            data=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
            if str(data.get('date') or '')!=now.date().isoformat(): return evidence
            for rk,row in (data.get('routes') or {}).items():
                for item in (row or {}).get('items') or []:
                    cid=str((item or {}).get('content_id') or '').strip()
                    if cid:evidence.setdefault(str(rk),set()).add(cid)
        except Exception:pass
        return evidence

    def _reconcile_single_route_counter(self,state:dict[str,Any],category_key:str)->bool:
        """Single enabled route count must equal category Done count.

        Older builds sometimes incremented route_runtime during a retry/secondary
        maintenance even when the category content count did not increment. That made
        the UI show Left>0 while route selection said target complete. With one route
        there is no ambiguity: route Done == category Done.
        """
        routes=self.route_runtime.enabled_routes(category_key)
        if len(routes)!=1:return False
        rk=next(iter(routes)); catrow=(state.get('categories') or {}).get(category_key) or {}
        desired=max(0,int(catrow.get('already_posted') or 0))
        rr=((state.get('route_runtime') or {}).get('routes') or {}).setdefault(category_key,{})
        rrow=rr.setdefault(rk,{})
        current=max(0,int(rrow.get('already_posted') or 0))
        if current==desired:return False
        rrow['already_posted']=desired
        if desired<=0 and not catrow.get('last_completed_at'):
            rrow['last_completed_at']=''
        elif catrow.get('last_completed_at'):
            rrow['last_completed_at']=str(catrow.get('last_completed_at') or '')
        state.setdefault('events',[]).append({
            'type':'single_route_count_reconciled','category':category_key,'route_key':rk,
            'at':datetime.now().astimezone().isoformat(timespec='seconds'),
            'from':current,'to':desired,
            'message':'Single-route runtime count reconciled to category Done count so a stale route counter cannot hide remaining work.'
        })
        print(f"🧮 Route count reconciled → {category_key}/{rk}: {current} → {desired}")
        return True

    def _new_row(self,key:str,cat:dict[str,Any],now:datetime,recap_count:int=0,recap_last:str='')->dict[str,Any]:
        try:
            base_target=self.schedule.category_target(key,now)
        except Exception:
            base_target=max(0,int(cat.get('daily_limit') or 0))
        target=self.route_runtime.category_target(key,base_target) if cat.get('production_mode')!='astrology_dynamic' else base_target
        return {'run_today':bool(cat.get('enabled',True)) and key in self.LIVE_RUNNERS,'normal_target':target,'target_override':None,'already_posted':recap_count if key=='recap' else 0,'count_source':'registry' if key=='recap' and recap_count else 'manual','planned_slots':[],'done_slots':[],'last_started_at':'','last_completed_at':recap_last if key=='recap' else '','last_finished_at':'','last_error':'','runtime_samples_seconds':[],'attempts':0,'consecutive_failures':0,'last_failure_at':'','failure_cooldown_until':'','no_work_until':'','manual_skip_until':'','pending_retry':False,'counted_content_ids':[]}

    def _new_state(self,now:datetime|None=None)->dict[str,Any]:
        now=now or datetime.now().astimezone();cats=self.settings.categories().get('categories',{});count,last=self._recap_registry_stats(now)
        state={'date':now.date().isoformat(),'created_at':now.isoformat(timespec='seconds'),'engine_version':self.ENGINE_VERSION,'armed':False,'stop_after_current':False,'current_job':None,'last_job_category':'','events':[],'categories':{k:self._new_row(k,c,now,count,last) for k,c in cats.items()},'route_runtime':{'routes':{},'destinations':{}}}
        self.route_runtime.ensure_state(state)
        # Existing recap registry count belongs to the migrated default route on first V2 day.
        recap_routes=((state.get('route_runtime') or {}).get('routes') or {}).get('recap') or {}
        if count and len(recap_routes)==1:
            next(iter(recap_routes.values()))['already_posted']=count
            if last: next(iter(recap_routes.values()))['last_completed_at']=last
        return state

    @_state_transaction
    def get(self,now:datetime|None=None)->dict[str,Any]:
        now=now or datetime.now().astimezone();path=self._path(now)
        state=self._read_existing_state(path)
        changed=state is None
        if state is None:state=self._new_state(now)
        state.setdefault('categories',{});state.setdefault('events',[]);state.setdefault('last_job_category','')
        # V1.6 static-slot state is intentionally disarmed once on upgrade. Controls/counts survive.
        if state.get('engine_version')!=self.ENGINE_VERSION:
            state['engine_version']=self.ENGINE_VERSION;state['armed']=False;state['current_job']=None;state['stop_after_current']=False;changed=True
            for row in state['categories'].values():row['planned_slots']=[];row['done_slots']=[]
            state['events'].append({'type':'engine_upgrade','at':now.isoformat(timespec='seconds'),'message':'Static slots replaced by rolling real-time scheduler; press START TODAY again.'})
        cats=self.settings.categories().get('categories',{})
        # V2.0.9 Astrology just became a real LIVE bridge. Existing same-day state
        # files were created while Astrology was forcibly non-live, so their
        # run_today=false is not a meaningful user pause. Enable it once only when
        # it has never attempted a job; subsequent user Today toggles are preserved.
        if not state.get('astrology_live_migrated_v209'):
            arow=(state.get('categories') or {}).get('astrology') or {}
            acat=cats.get('astrology') or {}
            if acat and acat.get('enabled',True) and int(arow.get('attempts') or 0)==0 and not arow.get('last_started_at'):
                arow['run_today']=True
                state.setdefault('events',[]).append({'type':'astrology_live_migration','at':now.isoformat(timespec='seconds'),'message':'Astrology became LIVE in V2.0.9; enabled for Today once.'})
            state['astrology_live_migrated_v209']=True;changed=True
        for key,cat in cats.items():
            if key not in state['categories']:
                state['categories'][key]=self._new_row(key,cat,now);changed=True
            row=state['categories'][key]
            try:base_target=self.schedule.category_target(key,now)
            except Exception:base_target=max(0,int(cat.get('daily_limit') or 0))
            row['normal_target']=self.route_runtime.category_target(key,base_target) if cat.get('production_mode')!='astrology_dynamic' else base_target
            for k,v in {'runtime_samples_seconds':[],'attempts':0,'last_finished_at':'','last_error':'','planned_slots':[],'done_slots':[],'consecutive_failures':0,'last_failure_at':'','failure_cooldown_until':'','no_work_until':'','manual_skip_until':'','pending_retry':False,'pending_route_key':'','counted_content_ids':[]}.items():
                if k not in row:row[k]=v;changed=True
        if self.route_runtime.ensure_state(state): changed=True
        # Immutable primary-post receipts are authoritative lower bounds.
        # Never reconcile while a job is live. mark_finished() owns that result and
        # its transaction will clear current_job. A dashboard read seeing the newly
        # written receipt must not race ahead with a stale live-job snapshot.
        if not state.get('current_job') and self._reconcile_durable_completion_receipts(state,now): changed=True
        # A partial FB/TikTok destination must never complete a multi-route Recap item.
        if self._reconcile_recap_route_counts(state,now): changed=True
        # Primary retry state is registry-backed so a Master restart cannot lose
        # the 5/10/20-minute retry turn. Only recent (< configured age) failures
        # below the three-attempt cap are resumed.
        recap_row=state.get('categories',{}).get('recap')
        if isinstance(recap_row,dict) and not state.get('current_job'):
            recap_pending=self._recap_pending_primary(now)
            desired=bool(recap_pending)
            desired_route=str((recap_pending or {}).get('route_key') or '')
            if bool(recap_row.get('pending_retry'))!=desired:
                recap_row['pending_retry']=desired;changed=True
            if str(recap_row.get('pending_route_key') or '')!=desired_route:
                recap_row['pending_route_key']=desired_route;changed=True
            if recap_pending:
                if recap_row.get('no_work_until'):
                    # A legacy/older bridge may have mislabeled a failed primary
                    # upload as no-content. Registry failure evidence wins and the
                    # short primary retry must not wait behind the 45-minute rescan.
                    recap_row['no_work_until']='';changed=True
                pending_route=str((recap_pending or {}).get('route_key') or '')
                pending_route_row=((((state.get('route_runtime') or {}).get('routes') or {}).get('recap') or {}).get(pending_route) or {})
                if pending_route_row.get('no_work_until'):
                    pending_route_row['no_work_until']='';changed=True
                retry_at=str(recap_pending.get('retry_at') or '')
                try:retry_dt=datetime.fromisoformat(retry_at.replace('Z','+00:00'));retry_at=retry_at if retry_dt>now else ''
                except Exception:retry_at=''
                if str(recap_row.get('failure_cooldown_until') or '')!=retry_at:
                    recap_row['failure_cooldown_until']=retry_at;changed=True
                pending_attempt=max(1,int(recap_pending.get('attempt') or 1))
                recap_row['consecutive_failures']=pending_attempt
                recap_row['last_failure_at']=str(recap_pending.get('failed_at') or '')
                if recap_pending.get('error'):recap_row['last_error']=str(recap_pending.get('error'))
                # The registry-backed retry is authoritative. Clear/shorten an
                # older route-level exhaustion cooldown too; otherwise the parent
                # says pending while choose_route() still hides the exact card.
                if str(pending_route_row.get('failure_cooldown_until') or '')!=retry_at:
                    pending_route_row['failure_cooldown_until']=retry_at;changed=True
                pending_route_row['consecutive_failures']=pending_attempt
                pending_route_row['last_failure_at']=str(recap_pending.get('failed_at') or '')
                if recap_pending.get('error'):pending_route_row['last_error']=str(recap_pending.get('error'))
        # Seed destination spacing from existing category completion timestamps on
        # first V2 migration so a Page is not posted again immediately after restart.
        dest_state=(state.get('route_runtime') or {}).setdefault('destinations',{})
        for _cat_key,_cat_row in (state.get('categories') or {}).items():
            _last=str(_cat_row.get('last_completed_at') or '')
            if not _last: continue
            _routes=self.route_runtime.routes(_cat_key)
            if len(_routes)==1:
                _rk=next(iter(_routes))
                for _dest in self.route_runtime.destination_keys(_cat_key,_rk):
                    if not (dest_state.get(_dest) or {}).get('last_completed_at'):
                        dest_state.setdefault(_dest,{})['last_completed_at']=_last;changed=True

        # Drama pending state includes secondary Page-permalink/group-share work too.
        # Primary FB+TT may already be complete (and should count Today) while the same
        # story remains pending only for group-share maintenance.
        drama_row=state.get('categories',{}).get('drama')
        if isinstance(drama_row,dict):
            pending_path=self.root/'state'/'tt_drama_pending.json'
            pending_retry=False
            pending_route=''
            try:
                if pending_path.exists():
                    pending=json.loads(pending_path.read_text(encoding='utf-8'))
                    if isinstance(pending,dict):
                        pending_route_key=str(pending.get('route_key') or 'default')
                        _wf,_wt,_wg,primary_complete,secondary_complete=self._route_requirement_state('drama',pending_route_key,pending)
                        pending_retry=not (primary_complete and secondary_complete)
                        pending_route=pending_route_key if pending_retry else ''
            except Exception:
                pending_retry=False;pending_route=''
            if bool(drama_row.get('pending_retry'))!=pending_retry:
                drama_row['pending_retry']=pending_retry;changed=True
            if str(drama_row.get('pending_route_key') or '')!=pending_route:
                drama_row['pending_route_key']=pending_route;changed=True

            # V2.0.7 count-heal: earlier builds waited for group sharing before
            # incrementing Done.  Recover same-day primary-complete Drama stories from
            # local receipts/pending state, then future content_id accounting prevents
            # any duplicate increment.
            # Reconcile only while idle. During mark_finished current_job is still
            # present; the live result must be the authoritative counter update.
            # This avoids the reconciliation racing ahead of the current job result.
            evidence=self._drama_same_day_primary_evidence(now) if not state.get('current_job') else {}
            all_ids=set().union(*evidence.values()) if evidence else set()
            counted=set(str(x) for x in (drama_row.get('counted_content_ids') or []) if str(x))
            missing=sorted(all_ids-counted)
            if missing:
                drama_row['already_posted']=int(drama_row.get('already_posted') or 0)+len(missing)
                drama_row['counted_content_ids']=sorted(counted|all_ids)[-200:]
                drama_row['count_source']='master_reconciled'
                drama_row['last_completed_at']=now.isoformat(timespec='seconds')
                state.setdefault('events',[]).append({
                    'type':'drama_primary_count_reconciled','at':now.isoformat(timespec='seconds'),
                    'content_ids':missing,'count_increment':len(missing),
                    'message':'Recovered same-day Drama primary posts that older builds left at Done=0 while group share was pending.'
                })
                # Keep route targets consistent with category Done.
                rr=((state.get('route_runtime') or {}).get('routes') or {}).setdefault('drama',{})
                for rk,ids in evidence.items():
                    route_row=rr.setdefault(rk,{})
                    route_row['already_posted']=max(int(route_row.get('already_posted') or 0),len(ids))
                    route_row['last_completed_at']=route_row.get('last_completed_at') or now.isoformat(timespec='seconds')
                print(f"🧮 Drama Today count reconciled +{len(missing)} from same-day primary-post evidence")
                changed=True

        # Story Motion primary receipts are the same-day duplicate lock. Primary
        # completion counts independently from optional group-share maintenance.
        motion_row=state.get('categories',{}).get('story_motion')
        if isinstance(motion_row,dict):
            # One-time live-state heal for failures written by the older scheduler.
            # A FAL transport interruption used to become a 30/60/90-minute content
            # failure. On restart, convert that stale backoff to a five-minute wait.
            if not state.get('current_job'):
                motion_routes=(((state.get('route_runtime') or {}).get('routes') or {}).get('story_motion') or {})
                affected=[]
                for rk,route_row in motion_routes.items():
                    if not isinstance(route_row,dict):continue
                    had_backoff=bool(int(route_row.get('consecutive_failures') or 0) or route_row.get('failure_cooldown_until'))
                    route_error=str(route_row.get('last_error') or motion_row.get('last_error') or '')
                    if had_backoff and self._is_transient_story_motion_fal_error(route_error):
                        affected.append((str(rk),route_row))
                category_had_backoff=bool(int(motion_row.get('consecutive_failures') or 0) or motion_row.get('failure_cooldown_until'))
                category_transient=category_had_backoff and self._is_transient_story_motion_fal_error(str(motion_row.get('last_error') or ''))
                if affected or category_transient:
                    retry_at=''
                    try:
                        failed_at=datetime.fromisoformat(str(motion_row.get('last_failure_at') or '').replace('Z','+00:00'))
                        if failed_at.tzinfo is None:failed_at=failed_at.astimezone()
                        candidate=failed_at+timedelta(minutes=5)
                        if candidate>now:retry_at=candidate.isoformat(timespec='seconds')
                    except Exception:pass
                    old_failures=int(motion_row.get('consecutive_failures') or 0)
                    for _rk,route_row in affected:
                        route_row['consecutive_failures']=0;route_row['last_failure_at']='';route_row['failure_cooldown_until']='';route_row['no_work_until']=retry_at
                    motion_row['consecutive_failures']=0;motion_row['last_failure_at']='';motion_row['failure_cooldown_until']='';motion_row['no_work_until']=retry_at
                    state.setdefault('events',[]).append({'type':'story_motion_fal_transport_backoff_healed','at':now.isoformat(timespec='seconds'),'routes':[rk for rk,_row in affected],'old_consecutive_failures':old_failures,'network_wait_until':retry_at})
                    print(f"🩹 Story Motion stale FAL network backoff healed → failures {old_failures} → 0")
                    changed=True
            evidence=self._story_motion_same_day_primary_evidence(now) if not state.get('current_job') else {}
            all_ids=set().union(*evidence.values()) if evidence else set()
            counted=set(str(x) for x in (motion_row.get('counted_content_ids') or []) if str(x))
            missing=sorted(all_ids-counted)
            if missing:
                motion_row['already_posted']=int(motion_row.get('already_posted') or 0)+len(missing)
                motion_row['counted_content_ids']=sorted(counted|all_ids)[-200:]
                motion_row['count_source']='master_reconciled'
                motion_row['last_completed_at']=now.isoformat(timespec='seconds')
                state.setdefault('events',[]).append({'type':'story_motion_primary_count_reconciled','at':now.isoformat(timespec='seconds'),'content_ids':missing,'count_increment':len(missing)})
                print(f"🧮 Story Motion Today count reconciled +{len(missing)} from same-day primary receipts")
                changed=True
            pending_path=self.root/'state'/'tt_story_motion_pending.json'
            pending_retry=False;pending_route=''
            try:
                if pending_path.exists():
                    pdata=json.loads(pending_path.read_text(encoding='utf-8'))
                    for rk,pending in ((pdata.get('routes') or {}) if isinstance(pdata,dict) else {}).items():
                        if not isinstance(pending,dict):continue
                        _wf,_wt,_wg,primary_complete,secondary_complete=self._route_requirement_state('story_motion',str(rk),pending)
                        if not (primary_complete and secondary_complete):
                            pending_retry=True;pending_route=str(rk);break
            except Exception:pass
            fal_resume_pending=self._story_motion_fal_resume_pending(now)
            if fal_resume_pending:
                if not self._story_motion_fal_checkpoint_logged:
                    print('♻️ Story Motion FAL queue checkpoint detected — pending retry kept without creating a new story')
                    self._story_motion_fal_checkpoint_logged=True
                if not pending_retry:
                    pending_retry=True
                    pending_route=str(motion_row.get('pending_route_key') or 'default')
            else:
                self._story_motion_fal_checkpoint_logged=False
            if bool(motion_row.get('pending_retry'))!=pending_retry:
                motion_row['pending_retry']=pending_retry;changed=True
            if str(motion_row.get('pending_route_key') or '')!=pending_route:
                motion_row['pending_route_key']=pending_route;changed=True

        # Repair legacy route-runtime counters after all category count reconciliation.
        # This is exact and safe for categories that currently have ONE enabled route.
        for _key in (state.get('categories') or {}):
            if self._reconcile_single_route_counter(state,_key):changed=True

        if changed:
            state['events']=state.get('events',[])[-200:]
            self._atomic(path,state)
        return state

    @_state_transaction
    def save_controls(self,controls:dict[str,Any],now:datetime|None=None)->dict[str,Any]:
        now=now or datetime.now().astimezone();state=self.get(now);cats=self.settings.categories().get('categories',{})
        for key,incoming in controls.items():
            if key not in cats or not isinstance(incoming,dict):continue
            row=state['categories'].setdefault(key,{})
            row['run_today']=bool(incoming.get('run_today',row.get('run_today',False)))
            row['already_posted']=max(0,int(incoming.get('already_posted',row.get('already_posted',0)) or 0))
            raw=incoming.get('target_override',row.get('target_override'));row['target_override']=None if raw in (None,'','null') else max(0,int(raw))
            row['count_source']='manual';row['last_error']='';row['planned_slots']=[];row['done_slots']=[];row['consecutive_failures']=0;row['last_failure_at']='';row['failure_cooldown_until']='';row['no_work_until']=''
        # Multi-route Recap Done is route-derived. This prevents a stale Today form
        # from re-introducing a parent-only count that no route can consume.
        self._reconcile_recap_route_counts(state,now)
        state['armed']=False;state['stop_after_current']=False
        self._atomic(self._path(now),state);return state

    @_state_transaction
    def preset(self,mode:str,now:datetime|None=None)->dict[str,Any]:
        state=self.get(now);mode=str(mode or '').lower()
        for key,row in state.get('categories',{}).items():
            if mode=='pause_all':row['run_today']=False
            elif mode=='run_all':row['run_today']=key in self.LIVE_RUNNERS
            elif mode=='recap_only':row['run_today']=key=='recap'
        state['armed']=False;state['stop_after_current']=False;self._atomic(self._path(now),state);return state

    @_state_transaction
    def autodetect_recap(self,now:datetime|None=None)->dict[str,Any]:
        now=now or datetime.now().astimezone();state=self.get(now);count,last=self._recap_registry_stats(now)
        if 'recap' in state['categories']:
            r=state['categories']['recap'];r['already_posted']=count;r['count_source']='registry_complete_routes';r['last_completed_at']=last or r.get('last_completed_at','')
            self._reconcile_recap_route_counts(state,now);state['armed']=False;self._atomic(self._path(now),state)
        return state

    @_state_transaction
    def arm(self,now:datetime|None=None)->dict[str,Any]:
        now=now or datetime.now().astimezone();state=self.get(now);state['armed']=True;state['stop_after_current']=False;state['armed_at']=now.isoformat(timespec='seconds');state['engine_version']=self.ENGINE_VERSION
        state.setdefault('events',[]).append({'type':'day_armed','at':now.isoformat(timespec='seconds'),'message':'Rolling real-time scheduler armed.'})
        self._atomic(self._path(now),state);return state

    @_state_transaction
    def request_stop(self,now:datetime|None=None)->dict[str,Any]:
        state=self.get(now)
        if state.get('current_job'):state['stop_after_current']=True
        else:state['armed']=False;state['stop_after_current']=False
        self._atomic(self._path(now),state);return state

    @_state_transaction
    def disarm(self,now:datetime|None=None)->dict[str,Any]:
        state=self.get(now);state['armed']=False;state['stop_after_current']=False;self._atomic(self._path(now),state);return state

    def _heartbeat_age_seconds(self,current:dict[str,Any],now:datetime)->float|None:
        raw=str((current or {}).get('heartbeat_at') or '').strip()
        if not raw:
            return None
        try:
            dt=datetime.fromisoformat(raw.replace('Z','+00:00'))
            if dt.tzinfo is None:dt=dt.astimezone()
            return max(0.0,(now-dt.astimezone(now.tzinfo)).total_seconds())
        except Exception:
            return None

    @_state_transaction
    def recover_stale_current_job(self,now:datetime|None=None,max_age_seconds:int=90)->dict[str,Any]:
        """Clear a dead current_job left behind by a killed terminal/process.

        Active Master jobs refresh heartbeat_at about once per second. Legacy locks have
        no heartbeat and are safe to clear on startup. A fresh heartbeat is preserved so
        accidentally starting a second Master does not steal the live job.
        """
        now=now or datetime.now().astimezone();state=self.get(now);current=state.get('current_job') or {}
        if not current:return {'cleared':False,'reason':'no_current_job','state':state}
        age=self._heartbeat_age_seconds(current,now)
        if age is not None and age<=max(5,int(max_age_seconds)):
            return {'cleared':False,'reason':'heartbeat_fresh','heartbeat_age_seconds':round(age,1),'state':state}
        cat=str(current.get('category') or '')
        jid=str(current.get('job_id') or '')
        state['current_job']=None;state['stop_after_current']=False
        state.setdefault('events',[]).append({'type':'stale_job_auto_cleared','category':cat,'job_id':jid,'at':now.isoformat(timespec='seconds'),'heartbeat_age_seconds':None if age is None else round(age,1)})
        state['events']=state['events'][-200:]
        self._atomic(self._path(now),state)
        print(f"🧹 STALE CURRENT JOB auto-cleared → {cat or 'unknown'} {jid} (heartbeat age={('legacy/no-heartbeat' if age is None else f'{age:.0f}s')})")
        return {'cleared':True,'reason':'stale','heartbeat_age_seconds':age,'state':state}

    @_state_transaction
    def touch_current_job(self,job_id:str,now:datetime|None=None)->bool:
        now=now or datetime.now().astimezone();state=self.get(now);current=state.get('current_job') or {}
        if not current or str(current.get('job_id') or '')!=str(job_id or ''):
            return False
        current['heartbeat_at']=now.isoformat(timespec='seconds');current['owner_pid']=os.getpid();state['current_job']=current
        self._atomic(self._path(now),state);return True

    @_state_transaction
    def clear_current_job(self,now:datetime|None=None,reason:str='dashboard_clear')->dict[str,Any]:
        """Force-clear only the scheduler state lock.

        The scheduler notices the missing job_id and cancels the matching live coroutine.
        This makes the dashboard control useful for both stale locks and a wedged live job.
        """
        now=now or datetime.now().astimezone();state=self.get(now);current=state.get('current_job') or {}
        if not current:return {'cleared':False,'reason':'no_current_job','state':state}
        cat=str(current.get('category') or '');jid=str(current.get('job_id') or '')
        state['current_job']=None;state['stop_after_current']=False
        state.setdefault('events',[]).append({'type':'job_state_cleared','category':cat,'job_id':jid,'at':now.isoformat(timespec='seconds'),'reason':reason})
        state['events']=state['events'][-200:];self._atomic(self._path(now),state)
        return {'cleared':True,'category':cat,'job_id':jid,'state':state}

    @_state_transaction
    def skip_current_to_next(self,now:datetime|None=None,hold_minutes:int=10)->dict[str,Any]:
        """Skip the current queue turn without counting a failure, then let another job run."""
        now=now or datetime.now().astimezone();state=self.get(now);current=state.get('current_job') or {}
        if not current:return {'skipped':False,'reason':'no_current_job','state':state}
        cat=str(current.get('category') or '');route=str(current.get('route_key') or 'default');jid=str(current.get('job_id') or '')
        row=(state.get('categories') or {}).get(cat) or {}
        hold=max(1,int(hold_minutes or 10));until=now+timedelta(minutes=hold)
        row['manual_skip_until']=until.isoformat(timespec='seconds');row['last_finished_at']=now.isoformat(timespec='seconds');row['last_error']='manual_skip_to_next'
        row['consecutive_failures']=0;row['last_failure_at']='';row['failure_cooldown_until']=''
        state['current_job']=None;state['stop_after_current']=False;state['last_job_category']=cat;state['last_job_route']=route
        state.setdefault('events',[]).append({'type':'job_skipped_to_next','category':cat,'route_key':route,'job_id':jid,'at':now.isoformat(timespec='seconds'),'hold_until':until.isoformat(timespec='seconds')})
        state['events']=state['events'][-200:];self._atomic(self._path(now),state)
        return {'skipped':True,'category':cat,'route_key':route,'job_id':jid,'hold_until':until.isoformat(timespec='seconds'),'state':state}

    @_state_transaction
    def mark_started(self,category:str,now:datetime|None=None,route_key:str='default')->str:
        now=now or datetime.now().astimezone();state=self.get(now)
        active=state.get('current_job')
        if active:
            raise RuntimeError(f"Sequential queue locked by {active.get('category','unknown')} ({active.get('job_id','')})")
        row=state['categories'][category]; route_key=str(route_key or 'default')
        job_id=f"{now.strftime('%H%M%S')}_{category}_{route_key}_{int(row.get('attempts') or 0)+1}"
        state['current_job']={'category':category,'route_key':route_key,'job_id':job_id,'started_at':now.isoformat(timespec='seconds'),'heartbeat_at':now.isoformat(timespec='seconds'),'owner_pid':os.getpid()}
        row['last_started_at']=now.isoformat(timespec='seconds');row['last_error']='';row['attempts']=int(row.get('attempts') or 0)+1
        self.route_runtime.mark_started(state,category,route_key,now)
        state.setdefault('events',[]).append({'type':'job_start','category':category,'route_key':route_key,'job_id':job_id,'at':now.isoformat(timespec='seconds')})
        self._atomic(self._path(now),state);return job_id

    @_state_transaction
    def mark_finished(self,category:str,*,success:bool,count_increment:int=0,error:str='',result:dict[str,Any]|None=None,now:datetime|None=None)->None:
        now=now or datetime.now().astimezone();state=self.get(now);row=state['categories'][category];current=state.get('current_job') or {};route_key=str(current.get('route_key') or row.get('pending_route_key') or 'default');started=None
        try:
            if current.get('started_at'):
                started=datetime.fromisoformat(str(current['started_at']).replace('Z','+00:00'))
                if started.tzinfo is None:started=started.astimezone()
        except Exception:started=None
        runtime=max(0.0,(now-started).total_seconds()) if started else 0.0;row['last_finished_at']=now.isoformat(timespec='seconds')

        # Count content by a stable content token, not by which retry invocation
        # happened to finish group sharing. This prevents both missing Done counts and
        # duplicate increments when the same pending Drama is retried many times.
        result=result or {}
        content_id=str(result.get('content_id') or result.get('story_id') or '').strip()
        counted=list(row.get('counted_content_ids') or [])
        counted_set={str(x) for x in counted if str(x)}
        effective_increment=max(0,int(count_increment or 0))
        duplicate_content=False
        if success and effective_increment>0 and content_id:
            if content_id in counted_set:
                effective_increment=0;duplicate_content=True
            else:
                counted_set.add(content_id)
                row['counted_content_ids']=list(counted_set)[-200:]
        pending_secondary=bool(result.get('pending_secondary'))
        real_success=bool(success and effective_increment>0)
        maintenance_only=bool(result.get('maintenance_only') or (success and effective_increment==0 and (pending_secondary or duplicate_content)))
        no_work=bool(result.get('no_work') or str(result.get('failure_kind') or '')=='no_new_content')
        transient_wait=bool(result.get('transient_wait'))
        pending_retry=bool(result.get('pending') or pending_secondary or str(result.get('failure_kind') or '') in {'pending_destination_retry','group_permalink_pending','group_share_pending'})
        cooldown_until=''

        if real_success:
            # V2.0.16: write durable proof FIRST. If the mutable daily JSON is later
            # regenerated/overwritten, get() restores Done from this immutable floor.
            content_id=self._record_completion_receipt(
                category,route_key,content_id,effective_increment,now,
                job_id=str(current.get('job_id') or ''),result=result,
            )
            row['already_posted']=int(row.get('already_posted') or 0)+effective_increment;row['count_source']='master+durable_receipt';row['last_completed_at']=now.isoformat(timespec='seconds')
            row['consecutive_failures']=0;row['last_failure_at']='';row['failure_cooldown_until']='';row['no_work_until']='';row['last_error']=''
            row['pending_retry']=pending_retry;row['pending_route_key']=route_key if pending_retry else ''
            route_row=((((state.get('route_runtime') or {}).get('routes') or {}).get(category) or {}).get(route_key) or {})
            route_row['no_work_until']=''
            self.route_runtime.mark_finished(state,category,route_key,now,True)
            if runtime>0:
                samples=list(row.get('runtime_samples_seconds') or []);samples.append(round(runtime,1));row['runtime_samples_seconds']=samples[-20:]
        elif maintenance_only:
            # Secondary retry after the primary story has already been counted.
            # Keep pending=true while permalink/group work remains; clear it only on
            # the final maintenance completion. Never rewrite primary destination gap.
            row['last_error']='';row['pending_retry']=pending_retry;row['pending_route_key']=route_key if pending_retry else ''
            row['consecutive_failures']=0;row['last_failure_at']='';row['failure_cooldown_until']='';row['no_work_until']=''
            route_row=((((state.get('route_runtime') or {}).get('routes') or {}).get(category) or {}).get(route_key) or {})
            route_row['no_work_until']=''
            self.route_runtime.mark_finished(state,category,route_key,now,False)
        elif transient_wait:
            # External transport outages (for example a FAL SSL EOF) are not a
            # broken content job.  Give the service a short, route-aware pause
            # and do not grow the normal 30/60/90-minute failure backoff.
            requested_wait=result.get('retry_cooldown_minutes')
            try:wait_minutes=max(1,int(requested_wait)) if requested_wait is not None else 5
            except Exception:wait_minutes=5
            transient_wait_until=(now+timedelta(minutes=wait_minutes)).isoformat(timespec='seconds')
            route_row=((((state.get('route_runtime') or {}).get('routes') or {}).get(category) or {}).get(route_key) or {})
            route_row['no_work_until']=transient_wait_until
            route_row['consecutive_failures']=0;route_row['last_failure_at']='';route_row['failure_cooldown_until']='';route_row['last_error']=str(error or result.get('error') or '')[-1200:]
            # Story Motion routes in one content group share the same unfinished
            # image set, so briefly hold the category as well as the selected card.
            row['no_work_until']=transient_wait_until if bool(result.get('category_wait')) or len(self.route_runtime.enabled_routes(category))<=1 else ''
            row['last_error']=str(error or result.get('error') or result.get('failure_kind') or 'transient_external_wait')[-1200:]
            row['pending_retry']=False;row['pending_route_key']=''
            row['consecutive_failures']=0;row['last_failure_at']='';row['failure_cooldown_until']=''
            self.route_runtime.mark_finished(state,category,route_key,now,False)
        elif no_work:
            # No selectable source is not a broken pipeline. Do not increment
            # failure count or trigger FAIL COOLDOWN. Wait, then rescan later.
            requested_wait=result.get('no_work_retry_minutes')
            if requested_wait is not None:
                try:wait_minutes=max(5,int(requested_wait))
                except Exception:wait_minutes=45
            else:
                try:
                    rr=self.settings.scheduler().get('rolling_realtime') or {}
                    wait_minutes=max(5,int(rr.get('no_work_retry_minutes',45) or 45))
                except Exception:
                    wait_minutes=45
            no_work_until=(now+timedelta(minutes=wait_minutes)).isoformat(timespec='seconds')
            route_row=((((state.get('route_runtime') or {}).get('routes') or {}).get(category) or {}).get(route_key) or {})
            route_row['no_work_until']=no_work_until
            route_row['consecutive_failures']=0;route_row['last_failure_at']='';route_row['failure_cooldown_until']='';route_row['last_error']=''
            # A multi-route category must not let one exhausted source list block
            # its sibling routes. Single-route categories retain the legacy
            # category-level field used by the rolling projection.
            row['no_work_until']=no_work_until if len(self.route_runtime.enabled_routes(category)) <= 1 else ''
            row['last_error']='no_new_content'
            row['pending_retry']=False
            row['consecutive_failures']=0;row['last_failure_at']='';row['failure_cooldown_until']=''
            self.route_runtime.mark_finished(state,category,route_key,now,False)
        else:
            if error:row['last_error']=str(error)[-1200:]
            route_row=((((state.get('route_runtime') or {}).get('routes') or {}).get(category) or {}).get(route_key) or {})
            failures=max(1,int(route_row.get('consecutive_failures') or 0)+1)
            row['consecutive_failures']=failures;row['last_failure_at']=now.isoformat(timespec='seconds')
            row['no_work_until']=''
            route_row['no_work_until']=''
            route_row['consecutive_failures']=failures;route_row['last_failure_at']=now.isoformat(timespec='seconds');route_row['last_error']=str(error)[-1200:] if error else ''
            row['pending_retry']=pending_retry
            row['pending_route_key']=route_key if pending_retry else ''
            self.route_runtime.mark_finished(state,category,route_key,now,False)

            # Fresh pipeline failures use the normal backoff. A partial/pending
            # destination retry (e.g. Drama FB done, TikTok pending) uses a shorter
            # cooldown because generation will NOT repeat.
            try:
                rr=self.settings.scheduler().get('rolling_realtime') or {}
                normal_base=max(1,int(rr.get('failure_cooldown_minutes',30) or 30))
                pending_base=max(1,int(rr.get('pending_retry_cooldown_minutes',10) or 10))
                cap=max(normal_base,int(rr.get('max_failure_cooldown_minutes',120) or 120))
            except Exception:
                normal_base,pending_base,cap=30,10,120
            base=pending_base if pending_retry else normal_base
            if pending_retry:
                requested=result.get('retry_cooldown_minutes')
                try: requested=max(1,int(requested)) if requested is not None else None
                except Exception: requested=None
                cooldown_minutes=min(cap,requested if requested is not None else base*(2**max(0,failures-1)))
            else:
                cooldown_minutes=min(cap,base*failures)
            until=now+timedelta(minutes=cooldown_minutes)
            cooldown_until=until.isoformat(timespec='seconds')
            route_row['failure_cooldown_until']=cooldown_until
            # Do not freeze sibling cards after an ordinary generator failure.
            # Pending destination retries deliberately stay locked to their route.
            row['failure_cooldown_until']=cooldown_until if pending_retry or len(self.route_runtime.enabled_routes(category))<=1 else ''

        event_type=('job_counted_pending' if real_success and pending_retry else ('job_complete' if real_success else ('job_maintenance' if maintenance_only else ('job_transient_wait' if transient_wait else ('job_no_work' if no_work else 'job_failed')))))
        event={'type':event_type,'category':category,'route_key':route_key,'job_id':current.get('job_id',''),'at':now.isoformat(timespec='seconds'),'runtime_seconds':round(runtime,1),'success':bool(real_success or maintenance_only),'count_increment':int(effective_increment),'content_id':content_id}
        if maintenance_only:event['maintenance_kind']=str(result.get('maintenance_kind') or 'maintenance')
        if error:event['error']=str(error)[-500:]
        if cooldown_until:event['failure_cooldown_until']=cooldown_until
        if transient_wait:event['transient_wait_until']=transient_wait_until
        if no_work:event['no_work_until']=no_work_until
        if pending_retry:event['pending_retry']=True
        state.setdefault('events',[]).append(event);state['events']=state['events'][-200:];state['last_job_category']=category;state['last_job_route']=route_key;state['current_job']=None
        if state.get('stop_after_current'):state['armed']=False;state['stop_after_current']=False
        self._atomic(self._path(now),state)

        if transient_wait:
            print(f"🌐 NETWORK WAIT — {category}/{route_key} will resume after {datetime.fromisoformat(transient_wait_until).astimezone():%H:%M:%S}; failure count unchanged.")
        elif no_work:
            print(f"🌙 NO CONTENT WAIT — {category}/{route_key} will rescan after {datetime.fromisoformat(no_work_until).astimezone():%Y-%m-%d %H:%M:%S}; sibling routes/categories remain eligible.")
        elif cooldown_until:
            label='PENDING RETRY' if pending_retry else 'FAIL COOLDOWN'
            scope=category if pending_retry or len(self.route_runtime.enabled_routes(category))<=1 else f'{category}/{route_key} (sibling routes remain eligible)'
            print(f"⏳ {label} — {scope} paused until {datetime.fromisoformat(cooldown_until).astimezone():%H:%M:%S} after {row.get('consecutive_failures',1)} consecutive failure(s)")
        return int(effective_increment)
