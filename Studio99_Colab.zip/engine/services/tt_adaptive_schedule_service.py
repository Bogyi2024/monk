from __future__ import annotations

import calendar
import hashlib
import math
import random
from datetime import datetime, timedelta
from typing import Any


class TTAdaptiveScheduleService:
    """Create late-start-safe posting slots without bunching posts together."""

    DEFAULT = {
        "enabled": True,
        "nominal_gap_minutes": 120,
        "minimum_gap_minutes": 90,
        "first_post_delay_minutes": 5,
        "end_buffer_minutes": 10,
        "jitter_minutes": 6,
        "late_policy": "respect_min_gap",
    }

    def __init__(self, settings_service):
        self.settings = settings_service

    @staticmethod
    def _clock(day: datetime, hhmm: str) -> datetime:
        h, m = [int(x) for x in str(hhmm).split(":", 1)]
        return day.replace(hour=h, minute=m, second=0, microsecond=0)

    def category_target(self, category_key: str, now: datetime) -> int:
        cats = self.settings.categories().get("categories", {})
        if category_key not in cats:
            raise KeyError(category_key)
        c = cats[category_key]
        if not c.get("enabled", True):
            return 0

        if c.get("production_mode") == "astrology_dynamic":
            r = c.get("production_rules") or {}
            d = r.get("daily") or {}
            w = r.get("weekly") or {}
            m = r.get("monthly") or {}
            total = int(d.get("weekday_forecast", 0)) + int(d.get("pick_one_of_four", 0))
            # Locked Astrology cadence: the MONTHLY special belongs to calendar day 30,
            # not generic month-end.  When the 30th is Sunday, Monthly replaces Weekly
            # so the day still contains exactly: Monthly + Daily + Image Pick.
            is_day_30 = now.day == 30
            is_weekly_day = now.strftime("%A").lower() == str(w.get("weekday", "sunday")).lower()
            if is_day_30 and bool(m.get("enabled", True)):
                total += int(m.get("monthly_special", 0))
            elif bool(w.get("enabled", True)) and is_weekly_day:
                total += int(w.get("weekly_special", 0))
            return max(0, total)
        return max(0, int(c.get("daily_limit", 0)))

    def preview(self, category_key: str, *, already_posted: int = 0, target_override: int | None = None, now: datetime | None = None) -> dict[str, Any]:
        now = now or datetime.now().astimezone()
        scheduler = self.settings.scheduler()
        window = scheduler.get("posting_window") or {"start": "09:00", "end": "21:00"}
        cfg = dict(self.DEFAULT)
        cfg.update(scheduler.get("adaptive_catchup") or {})

        normal_target = self.category_target(category_key, now)
        target = max(0, int(target_override)) if target_override is not None else normal_target
        already = max(0, int(already_posted))
        remaining = max(0, target - already)
        start = self._clock(now, window.get("start", "09:00"))
        end = self._clock(now, window.get("end", "21:00"))
        safe_end = end - timedelta(minutes=max(0, int(cfg["end_buffer_minutes"])))

        result: dict[str, Any] = {
            "category": category_key,
            "date": now.date().isoformat(),
            "now": now.isoformat(timespec="minutes"),
            "target": target,
            "normal_target": normal_target,
            "target_override": target_override,
            "already_posted": already,
            "remaining_requested": remaining,
            "window": {"start": start.strftime("%H:%M"), "end": end.strftime("%H:%M")},
            "safe_end": safe_end.strftime("%H:%M"),
            "settings": cfg,
            "slots": [],
            "scheduled_count": 0,
            "deferred_count": 0,
            "mode": "none",
        }
        if remaining <= 0:
            result["mode"] = "done"
            return result
        if now >= end:
            result["mode"] = "window_closed"
            result["deferred_count"] = remaining
            return result

        if now <= start:
            first = start
        else:
            first = now + timedelta(minutes=max(0, int(cfg["first_post_delay_minutes"])))
        if first > safe_end:
            result["mode"] = "too_late"
            result["deferred_count"] = remaining
            return result

        nominal = max(1, int(cfg["nominal_gap_minutes"]))
        min_gap = max(1, int(cfg["minimum_gap_minutes"]))
        available = max(0.0, (safe_end - first).total_seconds() / 60.0)

        if remaining == 1:
            count, gap, mode = 1, 0.0, "single"
        else:
            nominal_need = nominal * (remaining - 1)
            compressed_gap = available / (remaining - 1)
            if nominal_need <= available:
                count, gap, mode = remaining, float(nominal), "normal_2h"
            elif compressed_gap >= min_gap:
                count, gap, mode = remaining, compressed_gap, "adaptive_compressed"
            else:
                # Never bunch below minimum gap. Fit what is reasonable today.
                count = min(remaining, int(math.floor(available / min_gap)) + 1)
                if count <= 1:
                    gap = 0.0
                else:
                    # Spread the fit count across the remaining safe window.
                    gap = available / (count - 1)
                mode = "late_reduced_count"

        base_slots = [first + timedelta(minutes=gap * i) for i in range(count)]

        # Small deterministic jitter keeps times from looking mechanically exact,
        # while preserving the configured minimum gap and safe end.
        jitter = max(0, int(cfg.get("jitter_minutes", 0)))
        if jitter and count > 1 and gap > min_gap + 2:
            seed_raw = f"{now.date().isoformat()}|{category_key}|{first.strftime('%H:%M')}|{count}"
            seed = int(hashlib.sha256(seed_raw.encode()).hexdigest()[:16], 16)
            rng = random.Random(seed)
            slots = []
            for i, base in enumerate(base_slots):
                if i == 0:
                    candidate = base
                else:
                    candidate = base + timedelta(minutes=rng.uniform(-jitter, jitter))
                lower = slots[-1] + timedelta(minutes=min_gap) if slots else first
                remaining_after = count - 1 - i
                upper = safe_end - timedelta(minutes=min_gap * remaining_after)
                candidate = max(lower, min(candidate, upper))
                slots.append(candidate)
        else:
            slots = base_slots

        result["mode"] = mode
        result["scheduled_count"] = len(slots)
        result["deferred_count"] = max(0, remaining - len(slots))
        result["effective_gap_minutes"] = round(gap, 1)
        result["slots"] = [x.strftime("%H:%M") for x in slots]
        return result
