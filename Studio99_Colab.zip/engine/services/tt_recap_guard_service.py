from __future__ import annotations

import json
import os
import re
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


class TTRecapGuardService:
    """Extra safety layer for the legacy Recap registry.

    Goals:
    - repair posted_pages from posted_by_page when those two registry views drift;
    - keep a second persistent ledger of video ids that clearly have processing/post evidence;
    - temporarily reserve suspicious duplicate ids so the old source selector cannot pick them;
    - apply source-level retry cooldowns after failures without changing the proven recap selector.

    The guard does NOT delete existing registry history and does NOT rewrite user configs.
    """

    VERSION = 3

    def __init__(self, project_root: str | Path = "."):
        self.root = Path(project_root).resolve()
        self.state_path = self.root / "state" / "tt_recap_guard.json"
        self.state_path.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _now() -> datetime:
        return datetime.now(timezone.utc)

    @staticmethod
    def _iso(value: Any) -> datetime | None:
        if not value:
            return None
        try:
            d = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if d.tzinfo is None:
                d = d.replace(tzinfo=timezone.utc)
            return d.astimezone(timezone.utc)
        except Exception:
            return None

    @staticmethod
    def _atomic_json(path: Path, data: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        os.close(fd)
        tmp = Path(name)
        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            os.replace(tmp, path)
        finally:
            if tmp.exists():
                try:
                    tmp.unlink()
                except Exception:
                    pass

    @staticmethod
    def _load_json(path: Path, default: dict[str, Any]) -> dict[str, Any]:
        try:
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    return data
        except Exception:
            pass
        return dict(default)

    def _state(self) -> dict[str, Any]:
        now = self._now()
        state = self._load_json(
            self.state_path,
            {
                "version": self.VERSION,
                "created_at": now.isoformat(),
                "seen_video_ids": {},
                "legacy_quarantine_ids": {},
                "legacy_baseline_seeded": False,
                "events": [],
            },
        )
        state["version"] = self.VERSION
        state.setdefault("created_at", now.isoformat())
        state.setdefault("seen_video_ids", {})
        state.setdefault("legacy_quarantine_ids", {})
        state.setdefault("legacy_baseline_seeded", False)
        state.setdefault("events", [])
        return state

    def _registry_path(self, config: dict[str, Any]) -> Path:
        raw = str(config.get("registry_path") or "downloads/recap_source_registry.json")
        p = Path(raw)
        return p if p.is_absolute() else self.root / p

    @staticmethod
    def _runtime_page(config: dict[str, Any]) -> dict[str, Any]:
        pages = list(config.get("pages") or [])
        if not pages:
            return {}
        for p in pages:
            if "recap" in str(p.get("page_key") or "").lower():
                return p
        return pages[0]

    @classmethod
    def _destination_keys(cls, config: dict[str, Any]) -> list[str]:
        page = cls._runtime_page(config)
        page_key = str(page.get("page_key") or "Recap_Entertainment")
        raw = page.get("destinations")
        if isinstance(raw, list) and raw:
            out = []
            for i, d in enumerate(raw, 1):
                if not isinstance(d, dict) or not d.get("enabled", True):
                    continue
                platform = str(d.get("platform") or "fb").lower()
                if platform in {"facebook", "meta"}:
                    platform = "fb"
                key = str(d.get("destination_key") or f"{page_key}_{platform}_{i}")
                if key:
                    out.append(key)
            if out:
                return out
        return [page_key]

    @classmethod
    def _page_key(cls, config: dict[str, Any]) -> str:
        page = cls._runtime_page(config)
        return str(page.get("page_key") or "Recap_Entertainment")

    @staticmethod
    def _history_index(registry: dict[str, Any]) -> dict[str, dict[str, dict[str, Any]]]:
        index: dict[str, dict[str, dict[str, Any]]] = {}
        for dest, rows in (registry.get("posted_by_page") or {}).items():
            for row in rows or []:
                if not isinstance(row, dict):
                    continue
                vid = str(row.get("video_id") or "").strip()
                if not vid:
                    continue
                index.setdefault(vid, {})[str(dest)] = row
        return index

    def _seed_job_evidence(
        self,
        state: dict[str, Any],
        *,
        config: dict[str, Any],
        registry: dict[str, Any],
        now: datetime,
    ) -> int:
        """Seed the second ledger from final/render evidence left by prior runs.

        source.mp4 alone is NOT enough because a failed Whisper job also leaves it.
        final.mp4 / smart_sync_plan.json / voice files are much stronger evidence that
        this source has already gone through the expensive pipeline.
        """
        page_key = self._page_key(config)
        job_root_raw = str(config.get("job_root") or "downloads/recap_jobs")
        job_root = Path(job_root_raw)
        if not job_root.is_absolute():
            job_root = self.root / job_root
        page_dir = job_root / page_key
        if not page_dir.exists():
            return 0

        seen = state.setdefault("seen_video_ids", {})
        videos = registry.get("videos") or {}
        destinations = set(self._destination_keys(config))
        added = 0
        for child in page_dir.iterdir():
            if not child.is_dir():
                continue
            vid = child.name.strip()
            if not vid:
                continue
            record = videos.get(vid)
            if isinstance(record, dict) and not (record.get("posted_pages") or {}):
                contracts = record.get("required_destinations_by_stream") or {}
                contract = set(contracts.get(page_key) or []) if isinstance(contracts, dict) else set()
                # A destination contract is created when the current pipeline reserves
                # a source.  If that source has no upload receipt yet, artifacts in the
                # job directory are checkpoints from an interrupted run and must remain
                # selectable so prepare_rendered_video() can resume or reuse them.
                if contract and contract.intersection(destinations):
                    continue
            evidence = None
            for name in ("final.mp4", "smart_sync_plan.json", "voice.m4a", "voice.wav"):
                p = child / name
                try:
                    if p.exists() and p.stat().st_size > 0:
                        evidence = name
                        break
                except Exception:
                    pass
            if not evidence:
                continue
            if vid not in seen:
                seen[vid] = {
                    "first_guard_seen_at": now.isoformat(),
                    "last_guard_seen_at": now.isoformat(),
                    "reason": f"job_evidence:{evidence}",
                }
                added += 1
            else:
                seen[vid]["last_guard_seen_at"] = now.isoformat()
        return added

    def _release_known_incomplete_job_evidence(
        self,
        state: dict[str, Any],
        *,
        config: dict[str, Any],
        registry: dict[str, Any],
    ) -> int:
        """Release old job-evidence guards for contracted runs with no upload receipt."""
        page_key = self._page_key(config)
        destinations = set(self._destination_keys(config))
        seen = state.setdefault("seen_video_ids", {})
        released = 0
        for vid, record in (registry.get("videos") or {}).items():
            if not isinstance(record, dict) or (record.get("posted_pages") or {}):
                continue
            contracts = record.get("required_destinations_by_stream") or {}
            contract = set(contracts.get(page_key) or []) if isinstance(contracts, dict) else set()
            if not contract or not contract.intersection(destinations):
                continue
            entry = seen.get(vid)
            reason = str((entry or {}).get("reason") or "") if isinstance(entry, dict) else ""
            if reason.startswith("job_evidence:"):
                seen.pop(vid, None)
                released += 1
        return released

    @staticmethod
    def _repair_from_history(registry: dict[str, Any], history: dict[str, dict[str, dict[str, Any]]]) -> int:
        repaired = 0
        videos = registry.setdefault("videos", {})
        for vid, by_dest in history.items():
            record = videos.get(vid)
            if not isinstance(record, dict):
                continue
            posted = record.setdefault("posted_pages", {})
            for dest, row in by_dest.items():
                if dest in posted:
                    continue
                posted[dest] = {
                    "stream_key": str(row.get("stream_key") or ""),
                    "platform": str(row.get("platform") or ""),
                    "posted_at": str(row.get("posted_at") or ""),
                    "post_link": str(row.get("post_link") or ""),
                    "output_path": str(row.get("output_path") or ""),
                    "guard_repaired_from_history": True,
                }
                repaired += 1
        return repaired

    def _release_overbroad_legacy_quarantine(
        self,
        state: dict[str, Any],
        *,
        now: datetime,
    ) -> int:
        """V1.7.4 migration: release V1.7.3's blanket legacy backlog hold.

        V1.7.3 quarantined every pre-existing `posted_pages={}` row. That was too
        conservative because the Recap registry intentionally contains a large
        backlog of genuinely-unposted videos from earlier channel scans.

        V1.7.4 keeps only evidence-based duplicate protection:
          - posted_pages / posted_by_page history
          - strong prior job/render evidence
          - explicit destination failure cooldowns

        The old blanket quarantine entries are removed exactly once. No registry
        post history is deleted or fabricated.
        """
        if state.get("v174_broad_quarantine_released"):
            return 0
        quarantine = state.setdefault("legacy_quarantine_ids", {})
        released = 0
        for vid, item in list(quarantine.items()):
            reason = str((item or {}).get("reason") or "") if isinstance(item, dict) else ""
            if reason == "legacy_pre_v1_7_3_unknown_post_state":
                quarantine.pop(vid, None)
                released += 1
        state["legacy_baseline_seeded"] = True
        state["v174_broad_quarantine_released"] = True
        state["v174_broad_quarantine_released_at"] = now.isoformat()
        return released

    @staticmethod
    def _failure_hold_minutes(error: str, attempt: int = 1) -> int:
        e = str(error or "").lower()
        # Source/content failures are unlikely to heal immediately.
        if (
            "whisper transcript segment" in e
            or "transcript segment" in e
            or "valid segment" in e
            or "no segment" in e
        ):
            return 360
        # Anti-bot / network download failures deserve a longer quiet period.
        if "403" in e or "not a bot" in e or "download" in e:
            return 60
        # Browser upload / transient platform failures use the same bounded
        # primary retry contract as TT Master: 5m, 10m, then 20m. Keeping the
        # old 30-minute guard here silently defeated Master's short retry turn.
        return min(20, 5 * (2 ** max(0, int(attempt or 1) - 1)))

    def _recent_failure_hold(
        self,
        record: dict[str, Any],
        pending: list[str],
        now: datetime,
    ) -> tuple[datetime | None, str]:
        latest_until: datetime | None = None
        latest_reason = ""
        failures_all = record.get("failures") or {}
        for dest in pending:
            f = failures_all.get(dest) or {}
            failed_at = self._iso(f.get("last_failed_at"))
            if not failed_at:
                continue
            minutes = self._failure_hold_minutes(
                str(f.get("last_error") or ""),
                int(f.get("count") or 1),
            )
            until = failed_at + timedelta(minutes=minutes)
            if until > now and (latest_until is None or until > latest_until):
                latest_until = until
                latest_reason = f"{dest}:{minutes}m"
        return latest_until, latest_reason

    @staticmethod
    def _record_event(state: dict[str, Any], event: dict[str, Any]) -> None:
        events = state.setdefault("events", [])
        events.append(event)
        state["events"] = events[-300:]

    def preflight(self, config: dict[str, Any]) -> dict[str, Any]:
        now = self._now()
        registry_path = self._registry_path(config)
        registry = self._load_json(
            registry_path,
            {"version": 2, "channels": {}, "videos": {}, "posted_by_page": {}, "reservations": {}},
        )
        registry.setdefault("videos", {})
        registry.setdefault("posted_by_page", {})
        registry.setdefault("reservations", {})

        state = self._state()
        history = self._history_index(registry)
        repaired = self._repair_from_history(registry, history)

        # Remove only OUR old reservations and recompute them from current facts.
        # This prevents a 30-minute source cooldown from accidentally lasting the
        # legacy selector's full six-hour stale-reservation period.
        reservations = registry.setdefault("reservations", {})
        cleared_guard_reservations = 0
        for rkey, rvalue in list(reservations.items()):
            if isinstance(rvalue, dict) and str(rvalue.get("guard_type") or "") in {
                "duplicate_guard", "legacy_quarantine", "failure_cooldown"
            }:
                reservations.pop(rkey, None)
                cleared_guard_reservations += 1

        # V1.7.4: release the blanket V1.7.3 quarantine. The normal source
        # backlog must remain selectable; only evidence-based guards stay active.
        legacy_released = self._release_overbroad_legacy_quarantine(state, now=now)
        legacy_quarantine = state.setdefault("legacy_quarantine_ids", {})

        seen = state.setdefault("seen_video_ids", {})
        seeded_posted = 0
        for vid, record in (registry.get("videos") or {}).items():
            if not isinstance(record, dict):
                continue
            if record.get("posted_pages") or vid in history:
                if vid not in seen:
                    seeded_posted += 1
                seen[vid] = {
                    **(seen.get(vid) or {}),
                    "first_guard_seen_at": (seen.get(vid) or {}).get("first_guard_seen_at") or now.isoformat(),
                    "last_guard_seen_at": now.isoformat(),
                    "reason": (seen.get(vid) or {}).get("reason") or "registry_posted",
                }

        resumed_job_evidence = self._release_known_incomplete_job_evidence(
            state,
            config=config,
            registry=registry,
        )
        job_seeded = self._seed_job_evidence(state, config=config, registry=registry, now=now)

        destinations = self._destination_keys(config)
        page_key = self._page_key(config)
        guarded_duplicate = 0
        guarded_legacy = 0
        failure_holds = 0
        duplicate_ids: list[str] = []
        legacy_ids: list[str] = []
        failure_ids: list[str] = []

        for vid, record in (registry.get("videos") or {}).items():
            if not isinstance(record, dict):
                continue
            posted = record.get("posted_pages") or {}
            pending = [d for d in destinations if d not in posted]
            if not pending:
                continue

            failures = record.get("failures") or {}
            explicit_retry_destinations = [d for d in pending if int((failures.get(d) or {}).get("count", 0) or 0) > 0]

            # Any recent explicit failure gets a temporary source reservation.
            failure_until, failure_reason = self._recent_failure_hold(record, pending, now)
            if failure_until:
                reservations[f"{page_key}:{vid}"] = {
                    "page_key": page_key,
                    "video_id": vid,
                    "pending_destinations": pending,
                    "reserved_at": now.isoformat(),
                    "guard_type": "failure_cooldown",
                    "guard_until": failure_until.isoformat(),
                    "guard_reason": failure_reason,
                }
                failure_holds += 1
                failure_ids.append(vid)
                continue

            # Partial destination state is legitimate: e.g. FB succeeded and TT
            # still needs to resume. Never duplicate-block a record that already has
            # at least one destination posted.
            if posted:
                continue

            # Strong duplicate evidence + no explicit failed destination to resume:
            # block it from the legacy old_unposted selector. This never fakes a
            # posted destination; it only uses the selector's existing reservation gate.
            if vid in seen and not explicit_retry_destinations:
                reservations[f"{page_key}:{vid}"] = {
                    "page_key": page_key,
                    "video_id": vid,
                    "pending_destinations": pending,
                    "reserved_at": now.isoformat(),
                    "guard_type": "duplicate_guard",
                    "guard_reason": str((seen.get(vid) or {}).get("reason") or "seen_video_id"),
                }
                guarded_duplicate += 1
                duplicate_ids.append(vid)

        if repaired or seeded_posted or job_seeded or resumed_job_evidence or legacy_released or guarded_duplicate or failure_holds or cleared_guard_reservations:
            self._record_event(
                state,
                {
                    "type": "preflight",
                    "at": now.isoformat(),
                    "repaired_history": repaired,
                    "seeded_posted": seeded_posted,
                    "seeded_job_evidence": job_seeded,
                    "released_incomplete_job_evidence": resumed_job_evidence,
                    "legacy_quarantine_released": legacy_released,
                    "legacy_guarded": 0,
            "legacy_quarantine_released": legacy_released,
                    "duplicate_guarded": guarded_duplicate,
                    "failure_holds": failure_holds,
                    "cleared_old_guard_reservations": cleared_guard_reservations,
                },
            )

        self._atomic_json(registry_path, registry)
        self._atomic_json(self.state_path, state)

        if repaired:
            print(f"🧩 RECAP GUARD repaired registry history → posted_pages: {repaired}")
        if legacy_released:
            print(f"🔓 V1.7.4 released {legacy_released} over-broad legacy quarantine source(s); normal unposted backlog is selectable again.")
        if guarded_duplicate:
            sample = ", ".join(duplicate_ids[:4])
            print(f"🛑 DUPLICATE GUARD blocked {guarded_duplicate} processed/posted source(s): {sample}{' ...' if len(duplicate_ids)>4 else ''}")
        if failure_holds:
            sample = ", ".join(failure_ids[:4])
            print(f"⏳ SOURCE FAIL COOLDOWN holding {failure_holds} source(s): {sample}{' ...' if len(failure_ids)>4 else ''}")

        return {
            "registry_path": str(registry_path),
            "repaired_history": repaired,
            "seeded_posted": seeded_posted,
            "seeded_job_evidence": job_seeded,
            "released_incomplete_job_evidence": resumed_job_evidence,
            "legacy_quarantine_released": legacy_released,
            "legacy_guarded": guarded_legacy,
            "duplicate_guarded": guarded_duplicate,
            "failure_holds": failure_holds,
            "legacy_ids": legacy_ids,
            "duplicate_ids": duplicate_ids,
            "failure_ids": failure_ids,
        }

    def postflight(self, config: dict[str, Any]) -> dict[str, Any]:
        """Refresh the second ledger after a Recap attempt."""
        now = self._now()
        registry_path = self._registry_path(config)
        registry = self._load_json(registry_path, {"videos": {}, "posted_by_page": {}})
        state = self._state()
        seen = state.setdefault("seen_video_ids", {})
        added = 0
        for vid, record in (registry.get("videos") or {}).items():
            if not isinstance(record, dict) or not record.get("posted_pages"):
                continue
            if vid not in seen:
                added += 1
            seen[vid] = {
                **(seen.get(vid) or {}),
                "first_guard_seen_at": (seen.get(vid) or {}).get("first_guard_seen_at") or now.isoformat(),
                "last_guard_seen_at": now.isoformat(),
                "reason": "registry_posted",
            }
        job_added = self._seed_job_evidence(state, config=config, registry=registry, now=now)
        if added or job_added:
            self._record_event(
                state,
                {
                    "type": "postflight",
                    "at": now.isoformat(),
                    "posted_added": added,
                    "job_evidence_added": job_added,
                },
            )
        self._atomic_json(self.state_path, state)
        return {"posted_added": added, "job_evidence_added": job_added}
