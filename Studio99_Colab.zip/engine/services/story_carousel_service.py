from __future__ import annotations

import asyncio
import base64
import html
import hashlib
import threading
import json
import os
import re
import subprocess
import requests
import tempfile
import time
import unicodedata
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageEnhance
from playwright.sync_api import sync_playwright

from services.ai_service import AIService
from services.gemini_web_story_image_service import GeminiWebStoryImageService
from services.story_image_sheet_service import StoryImageSheetService


class StoryCarouselService:
    """Phase-1.1 Story Carousel engine.

    - Gemini writes the original Burmese story plan
    - Imagen generates the scene images
    - FFmpeg/libass renders Burmese text correctly on cards
    """

    def __init__(self, config_path: str = "config/story_carousel.json"):
        self.config_path = Path(config_path)
        if not self.config_path.exists():
            raise FileNotFoundError(f"Story carousel config မတွေ့ပါ: {self.config_path}")
        self.config = json.loads(self.config_path.read_text(encoding="utf-8"))
        self.ai = AIService()
        self._story_font_path_cache: Path | None = None
        self._story_font_base64_cache: str | None = None

    @staticmethod
    def _safe_slug(value: str, fallback: str = "story") -> str:
        value = re.sub(r"[^0-9A-Za-z_-]+", "_", str(value or "")).strip("_")
        return value[:60] or fallback

    @staticmethod
    def _strip_code_fence(raw: str) -> str:
        text = (raw or "").strip()
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
        text = re.sub(r"\s*```$", "", text)
        return text.strip()

    @classmethod
    def _parse_json(cls, raw: str) -> dict[str, Any]:
        text = cls._strip_code_fence(raw)
        try:
            return json.loads(text)
        except Exception:
            start = text.find("{")
            end = text.rfind("}")
            if start >= 0 and end > start:
                return json.loads(text[start:end + 1])
            raise

    @staticmethod
    def _clean_display_text(value: str) -> str:
        text = str(value or '')
        text = text.replace('\r', ' ').replace('\n', ' ')
        # Remove slash / pipe-like artifacts that sometimes sneak into generated copy
        # or appear ugly in large Burmese overlay text.
        text = text.replace('/', ' ').replace('\\', ' ').replace('|', ' ')
        text = text.replace('／', ' ').replace('｜', ' ').replace('¦', ' ')
        text = text.replace('\\N', ' ').replace('\\n', ' ')
        # Normalize punctuation spacing and whitespace.
        text = re.sub(r'\s+([၊။!?])', r'\1', text)
        text = re.sub(r'\s+', ' ', text).strip()
        # Trim leftover trailing separators/punctuation noise.
        text = re.sub(r'[\s\-–—_/\\|]+$', '', text).strip()
        return text

    def _validate_plan(self, plan: dict[str, Any]) -> dict[str, Any]:
        slide_count = int(self.config.get("slides_count", 7))
        slides = plan.get("slides") or []
        if not isinstance(slides, list) or len(slides) != slide_count:
            raise ValueError(f"slides count must be exactly {slide_count}, got {len(slides) if isinstance(slides, list) else 0}")

        cleaned: list[dict[str, Any]] = []
        seen: set[str] = set()
        max_body_chars = int(self.config.get("max_body_chars", 180))
        max_headline_chars = int(self.config.get("max_headline_chars", 72))

        for idx, raw in enumerate(slides, 1):
            if not isinstance(raw, dict):
                raise ValueError(f"slide {idx} is not an object")
            headline = self._clean_display_text(raw.get("headline") or "")
            body = self._clean_display_text(raw.get("body") or "")
            visual = re.sub(r"\s+", " ", str(raw.get("visual_prompt") or raw.get("visual_hint") or "")).strip()
            role = re.sub(r"\s+", " ", str(raw.get("role") or "")).strip()
            if not headline or not body or not visual:
                raise ValueError(f"slide {idx} missing headline/body/visual_prompt")
            if len(body) > max_body_chars:
                raise ValueError(f"slide {idx} body too long: {len(body)} > {max_body_chars}")
            if len(headline) > max_headline_chars:
                raise ValueError(f"slide {idx} headline too long: {len(headline)} > {max_headline_chars}")

            key = (headline + "|" + body).casefold()
            if key in seen:
                raise ValueError(f"duplicate slide text at {idx}")
            seen.add(key)

            cleaned.append(
                {
                    "slide_no": idx,
                    "role": role or ("hook" if idx == 1 else "story"),
                    "headline": headline,
                    "body": body,
                    "visual_prompt": visual,
                    "emotion": str(raw.get("emotion") or "").strip(),
                }
            )

        plan["slides"] = cleaned
        plan["title"] = self._clean_display_text(plan.get("title") or cleaned[0]["headline"])
        plan["hook"] = self._clean_display_text(plan.get("hook") or cleaned[0]["headline"])
        plan["character_bible"] = str(plan.get("character_bible") or "").strip()
        plan["fb_caption"] = self._clean_display_text(plan.get("fb_caption") or "")
        plan["tt_caption"] = self._clean_display_text(plan.get("tt_caption") or "")

        tags: list[str] = []
        for tag in plan.get("hashtags") or []:
            tag = str(tag).strip()
            if not tag:
                continue
            if not tag.startswith("#"):
                tag = "#" + tag
            if tag.casefold() not in {x.casefold() for x in tags}:
                tags.append(tag)
        plan["hashtags"] = tags[: int(self.config.get("hashtag_limit", 8))]
        return plan

    async def generate_story_plan(self, *, genre: str, topic: str = "") -> dict[str, Any]:
        slide_count = int(self.config.get("slides_count", 7))
        genre = str(genre or "drama").strip().lower()
        topic = str(topic or "").strip()
        genre_label = {
            "ghost": "သရဲ/လျှို့ဝှက်သည်းထိတ်ရင်ဖို",
            "horror": "သရဲ/လျှို့ဝှက်သည်းထိတ်ရင်ဖို",
            "drama": "ဒရာမာ/စိတ်ခံစားမှု",
            "thriller": "သည်းထိတ်ရင်ဖိုဒရာမာ",
        }.get(genre, genre)

        seed_line = (
            f"ဇာတ်လမ်းအခြေခံအကြောင်းအရာ: {topic}"
            if topic
            else "ဇာတ်လမ်းအကြောင်းအရာကို မင်းကိုယ်တိုင် လုံးဝအသစ် ဖန်တီးပါ။"
        )

        prompt = f"""
မင်းက Facebook/TikTok အတွက် ORIGINAL Burmese swipe-story writer တစ်ယောက်ပါ။
Genre = {genre_label}
{seed_line}

ရည်ရွယ်ချက်:
- စာပိုဒ်ကြီးမဟုတ်ဘဲ ဖုန်းပေါ်မှာ ပုံတစ်ပုံချင်း swipe လုပ်ဖတ်ရမယ့် story carousel ဖန်တီးရန်
- မူပိုင်ခွင့်ရှိတဲ့ ဝတ္ထု၊ ရုပ်ရှင်၊ creepypasta စာသားကို မကူးပါနှင့်
- ဇာတ်လမ်း၊ ဇာတ်ကောင်၊ dialogue/incident များကို လုံးဝ original ဖန်တီးပါ
- Slide 1 က scroll-stopping dramatic hook ဖြစ်ရမည်
- Slide တစ်ခုမှာ idea တစ်ခုပဲ
- ဇာတ်လမ်းတိုးတက်မှုရှိရမည်၊ ထပ်ခါထပ်ခါမရေးရ
- Burmese စကားပြောသဘာဝကျစေ
- Graphic gore မလုပ်ရ; horror ဖြစ်ရင် atmosphere/suspense ကိုဦးစားပေး

အတိအကျ {slide_count} slides ထုတ်ပါ:
1 Hook
2 Setup
3 Escalation
4 Twist
5 Peak drama
6 Outcome / reveal
7 Final sting / CTA-like tease (spammy follow request မဖြစ်ရ)

စာအရွယ် (IMPORTANT for fixed-layout image cards):
- headline: အတိုဆုံးထားပါ၊ ideally 1 line / maximum 2 lines only
- headline length: အများဆုံး 40 မြန်မာ characters ဝန်းကျင်
- body: slide တစ်ခု 1–2 စာကြောင်းသာ
- body length: အများဆုံး 90 မြန်မာ characters ဝန်းကျင်
- စကားပိုတွေ၊ ထပ်ခါထပ်ခါရေးတာ၊ ရှည်လျားတဲ့ sentence မလုပ်ရ
- slash(/), backslash(\), pipe(|) မသုံးရ

Character consistency:
- character_bible ထဲမှာ main character အသက်ခန့်မှန်း၊ မျက်နှာ/ဆံပင်/အဝတ်အစား/အထူးလက္ခဏာကို တစ်ကြောင်းတည်း တိတိကျကျရေး
- visual_prompt တိုင်းမှာ character_bible ကို မမှီခိုဘဲ မြင်ရမည့် character တစ်ယောက်ချင်း၏ အသက်၊ မျက်နှာပုံစံ၊ အသားအရောင်၊ ဆံပင်ပုံစံ/အရောင်၊ အဝတ်အစား/အရောင်နှင့် အထူးလက္ခဏာအားလုံးကို အပြည့်အစုံ ထပ်ရေး
- ဇာတ်ကောင်အမည်သည် identifier သာဖြစ်ပြီး ပုံထဲမှာ အမည်စာသား၊ poster သို့ caption အဖြစ် မပေါ်ရ
- visual_prompt က သက်ဆိုင်ရာ headline/body မှာ ဖြစ်နေတဲ့ အချိန်တိတိကျကျကိုပဲ ပုံဖော်ရမည်။ မဖြစ်သေးတဲ့ action ကို စောထည့်တာ၊ ဖြစ်ပြီးသား action ကို နောက်ကျပြတာ မလုပ်ရ
- body မှာ အရောင်၊ ပစ္စည်းအမျိုးအစား၊ အဝတ်အစား၊ နေရာ သတ်မှတ်ထားရင် visual_prompt မှာ အတိအကျတူရမည်။ ဥပမာ body မှာ အိတ်အနက်ဆို visual_prompt မှာ blue bag မရေးရ
- Slide တစ်ခု၏ visual_prompt ကို အရင် slide သို့ နောက် slide action နှင့် မရောရ
- visual_prompt ထဲမှာ NO text, NO letters, NO subtitles, NO watermark, NO logo ပါရမည်
- image ကို text overlay မပါဘဲ cinematic background အဖြစ်ဖန်တီးမည်

JSON ONLY:
{{
  "title": "...",
  "hook": "...",
  "character_bible": "...",
  "slides": [
    {{
      "slide_no": 1,
      "role": "hook",
      "headline": "...",
      "body": "...",
      "visual_prompt": "English cinematic scene prompt, no text",
      "emotion": "..."
    }}
  ],
  "fb_caption": "အလွန်တိုသော Facebook caption 1-2 lines",
  "tt_caption": "အလွန်တိုသော TikTok photo-post caption",
  "hashtags": ["#...", "#..."]
}}
"""
        retries = int(self.config.get("gemini_retries", 3))
        last_exc = None
        self.ai._enable_proxy()
        try:
            for attempt in range(1, retries + 1):
                try:
                    response = self.ai.generate_content(
                        model=self.ai.text_model,
                        contents=prompt,
                    )
                    plan = self._parse_json(response.text)
                    plan = self._validate_plan(plan)
                    plan["genre"] = genre
                    plan["topic_seed"] = topic
                    print(f"✅ Story Carousel Gemini plan ready: {len(plan['slides'])} slides")
                    return plan
                except Exception as exc:
                    last_exc = exc
                    print(f"⚠️ Story Carousel Gemini validation retry {attempt}/{retries}: {exc}")
                    await asyncio.sleep(min(2 * attempt, 5))
        finally:
            self.ai._disable_proxy()
        raise RuntimeError(f"Story Carousel Gemini plan failed: {last_exc}")

    @staticmethod
    def _cover_crop(image: Image.Image, size: tuple[int, int]) -> Image.Image:
        target_w, target_h = size
        src_w, src_h = image.size
        scale = max(target_w / src_w, target_h / src_h)
        resized = image.resize((int(src_w * scale), int(src_h * scale)), Image.Resampling.LANCZOS)
        left = max(0, (resized.width - target_w) // 2)
        top = max(0, (resized.height - target_h) // 2)
        return resized.crop((left, top, left + target_w, top + target_h))

    @staticmethod
    def _ass_escape_text(value: str) -> str:
        text = str(value or "")
        text = text.replace("\\", r"\\")
        text = text.replace("{", r"\{")
        text = text.replace("}", r"\}")
        return text

    @staticmethod
    def _ass_wrap_words(value: str, max_chars: int) -> str:
        text = re.sub(r"\s+", " ", str(value or "")).strip()
        if not text:
            return ""
        words = text.split(" ")
        if len(words) <= 1:
            return r"\N".join([text[i:i + max_chars] for i in range(0, len(text), max_chars)])
        lines: list[str] = []
        line = ""
        for word in words:
            test = word if not line else line + " " + word
            if len(test) <= max_chars:
                line = test
            else:
                if line:
                    lines.append(line)
                line = word
        if line:
            lines.append(line)
        return r"\N".join(lines)

    @staticmethod
    def _char_units(ch: str) -> float:
        if not ch:
            return 0.0
        if ch.isspace():
            return 0.45
        cat = unicodedata.category(ch)
        if cat.startswith('M'):
            return 0.0
        cp = ord(ch)
        # Myanmar base glyphs are visually wide; punctuation is narrower.
        if 0x1000 <= cp <= 0x109F or 0xAA60 <= cp <= 0xAA7F or 0xA9E0 <= cp <= 0xA9FF:
            if ch in '၊။':
                return 0.45
            return 1.0
        if ch.isdigit():
            return 0.60
        if ord(ch) < 128:
            return 0.58
        return 0.90

    @classmethod
    def _text_units(cls, text: str) -> float:
        return sum(cls._char_units(ch) for ch in str(text or ''))

    @classmethod
    def _split_long_token(cls, token: str, max_units: float) -> list[str]:
        parts: list[str] = []
        cur = ''
        cur_u = 0.0
        for ch in token:
            u = cls._char_units(ch)
            if cur and cur_u + u > max_units:
                parts.append(cur)
                cur = ch
                cur_u = u
            else:
                cur += ch
                cur_u += u
        if cur:
            parts.append(cur)
        return parts

    @classmethod
    def _wrap_for_units(cls, text: str, max_units: float) -> list[str]:
        text = re.sub(r'\s+', ' ', str(text or '')).strip()
        if not text:
            return []
        words = text.split(' ')
        lines: list[str] = []
        current = ''
        current_u = 0.0

        def flush() -> None:
            nonlocal current, current_u
            if current:
                lines.append(current)
                current = ''
                current_u = 0.0

        for word in words:
            wu = cls._text_units(word)
            if wu > max_units:
                flush()
                pieces = cls._split_long_token(word, max_units)
                if pieces:
                    lines.extend(pieces[:-1])
                    current = pieces[-1]
                    current_u = cls._text_units(current)
                continue

            sep_u = cls._char_units(' ') if current else 0.0
            if current and current_u + sep_u + wu > max_units:
                flush()
            if current:
                current += ' ' + word
                current_u += sep_u + wu
            else:
                current = word
                current_u = wu
        flush()
        return lines

    def _fit_text_block(
        self,
        text: str,
        *,
        usable_width: int,
        start_size: int,
        min_size: int,
        max_lines: int,
        max_height: int,
        width_factor: float,
        line_height_factor: float = 1.22,
    ) -> tuple[int, list[str]]:
        cleaned = self._clean_display_text(text)
        if not cleaned:
            return min_size, []

        best_lines: list[str] = [cleaned]
        for size in range(start_size, min_size - 1, -2):
            max_units = max(4.0, usable_width / max(1.0, size * width_factor))
            lines = self._wrap_for_units(cleaned, max_units)
            block_h = int(len(lines) * size * line_height_factor)
            if len(lines) <= max_lines and block_h <= max_height:
                return size, lines
            best_lines = lines

        # Last-resort safety: keep shrinking below configured minimum rather than
        # letting body text disappear under the footer.
        size = min_size
        while size > 30:
            max_units = max(4.0, usable_width / max(1.0, size * width_factor))
            lines = self._wrap_for_units(cleaned, max_units)
            block_h = int(len(lines) * size * line_height_factor)
            if block_h <= max_height:
                return size, lines
            size -= 2
            best_lines = lines
        return max(30, size), best_lines


    @staticmethod
    def _trim_chars_soft(text: str, max_chars: int) -> str:
        text = re.sub(r'\s+', ' ', str(text or '')).strip()
        if not text or len(text) <= max_chars:
            return text
        candidate = text[:max_chars].rstrip(' ၊။,.;:!?-–—')
        if ' ' in candidate:
            candidate = candidate.rsplit(' ', 1)[0].strip()
        return (candidate or text[:max_chars].strip()) + '…'

    @classmethod
    def _truncate_units_with_ellipsis(cls, text: str, max_units: float) -> str:
        text = re.sub(r'\s+', ' ', str(text or '')).strip()
        if not text:
            return ''
        ell = '…'
        ell_u = cls._text_units(ell)
        if cls._text_units(text) <= max_units:
            return text
        out = ''
        used = 0.0
        for ch in text:
            u = cls._char_units(ch)
            if out and used + u + ell_u > max_units:
                break
            out += ch
            used += u
        out = out.rstrip(' ၊။,.;:!?-–—')
        return (out or text[:1]) + ell

    def _wrap_fixed_block(
        self,
        text: str,
        *,
        usable_width: int,
        font_size: int,
        width_factor: float,
        max_lines: int,
        max_chars: int,
    ) -> list[str]:
        cleaned = self._clean_display_text(text)
        cleaned = self._trim_chars_soft(cleaned, max_chars)
        if not cleaned:
            return []
        max_units = max(4.0, usable_width / max(1.0, font_size * width_factor))
        lines = self._wrap_for_units(cleaned, max_units)
        if len(lines) <= max_lines:
            return lines
        clipped = list(lines[: max_lines - 1])
        remainder = ' '.join(lines[max_lines - 1:]).strip()
        clipped.append(self._truncate_units_with_ellipsis(remainder, max_units))
        return clipped

    def _ass_lines(self, lines: list[str]) -> str:
        # Escape every visible line first, then insert real ASS hard line breaks.
        # This avoids the old visible slash/backslash artifact.
        return r'\N'.join(self._ass_escape_text(line) for line in lines)

    @staticmethod
    def _ffmpeg_filter_path(path: Path) -> str:
        value = str(path.resolve()).replace("\\", "/")
        value = value.replace(":", r"\:")
        value = value.replace("'", r"\'")
        return value


    def _find_story_font_file(self) -> Path | None:
        """Find a Myanmar font for Chromium, preferring project fonts first."""
        if self._story_font_path_cache is not None:
            return self._story_font_path_cache

        project_candidates = [
            Path("assets/fonts/Pyidaungsu-Regular.ttf"),
            Path("assets/fonts/Pyidaungsu.ttf"),
            Path("assets/fonts/myanmar.ttf"),
            Path("assets/fonts/NotoSansMyanmar-Regular.ttf"),
            Path("fonts/Pyidaungsu-Regular.ttf"),
            Path("fonts/Pyidaungsu.ttf"),
            Path("fonts/myanmar.ttf"),
            Path("fonts/NotoSansMyanmar-Regular.ttf"),
        ]
        for candidate in project_candidates:
            if candidate.exists():
                self._story_font_path_cache = candidate.resolve()
                print(f"🔤 Story browser font: {self._story_font_path_cache}")
                return self._story_font_path_cache

        windows_dirs: list[Path] = []
        local_appdata = os.getenv("LOCALAPPDATA")
        if local_appdata:
            windows_dirs.append(Path(local_appdata) / "Microsoft" / "Windows" / "Fonts")
        windows_dirs.append(Path(r"C:\Windows\Fonts"))

        preferred = [
            "pyidaungsu",
            "burma020",
            "burma",
            "notosansmyanmar",
            "myanmartext",
            "myanmar",
        ]
        for keyword in preferred:
            for folder in windows_dirs:
                if not folder.exists():
                    continue
                try:
                    files = list(folder.iterdir())
                except Exception:
                    continue
                for item in files:
                    name = item.name.lower().replace("-", "").replace("_", "")
                    key = keyword.lower().replace("-", "").replace("_", "")
                    if key in name and item.suffix.lower() in {".ttf", ".otf"}:
                        self._story_font_path_cache = item.resolve()
                        print(f"🔤 Story browser font: {self._story_font_path_cache}")
                        return self._story_font_path_cache

        print("⚠️ Story browser font file not found; Chromium system Myanmar fallback will be used.")
        return None

    def _story_font_base64(self) -> str:
        if self._story_font_base64_cache is not None:
            return self._story_font_base64_cache
        font_path = self._find_story_font_file()
        if not font_path:
            self._story_font_base64_cache = ""
            return ""
        try:
            self._story_font_base64_cache = base64.b64encode(font_path.read_bytes()).decode("ascii")
        except Exception as exc:
            print(f"⚠️ Story font embed failed: {exc}")
            self._story_font_base64_cache = ""
        return self._story_font_base64_cache

    def _render_story_text_layer_playwright(
        self,
        *,
        headline: str,
        body: str,
        index: int,
        total: int,
        output_png_path: Path,
        canvas_size: tuple[int, int],
    ) -> None:
        """Render Burmese with Chromium like Recap Personal instead of libass/manual width estimates."""
        w, h = canvas_size
        headline = self._clean_display_text(headline)
        body = self._clean_display_text(body)
        headline_html = html.escape(headline, quote=True)
        body_html = html.escape(body, quote=True)
        watermark_html = html.escape(str(self.config.get("watermark_text") or "CHANNEL 99"), quote=True)
        font_b64 = self._story_font_base64()

        title_size = int(self.config.get("browser_headline_size", 66))
        title_min = int(self.config.get("browser_headline_min_size", 58))
        body_size = int(self.config.get("browser_body_size", 42))
        body_min = int(self.config.get("browser_body_min_size", 36))
        text_left = int(self.config.get("browser_margin_x", 58))
        text_top = int(self.config.get("browser_text_top", 600))
        text_bottom = int(self.config.get("browser_text_bottom", 70))
        title_max_lines = int(self.config.get("title_max_lines", 2))
        body_max_lines = int(self.config.get("body_max_lines", 4))
        watermark_size = int(self.config.get("watermark_size", 42))
        watermark_opacity = float(self.config.get("watermark_opacity", 0.15))

        font_face = ""
        if font_b64:
            font_face = f"""
            @font-face {{
                font-family: 'StoryMyanmar';
                src: url(data:font/ttf;base64,{font_b64}) format('truetype');
                font-style: normal;
                font-weight: 100 900;
            }}
            """

        page_html = f"""<!doctype html>
<html lang="my">
<head>
<meta charset="UTF-8">
<style>
{font_face}
* {{ box-sizing: border-box; }}
html, body {{
    margin: 0;
    padding: 0;
    width: {w}px;
    height: {h}px;
    overflow: hidden;
    background: transparent;
}}
body {{
    position: relative;
    font-family: 'StoryMyanmar', 'Pyidaungsu', 'Myanmar Text', 'Noto Sans Myanmar', sans-serif;
    -webkit-font-smoothing: antialiased;
    text-rendering: optimizeLegibility;
}}
.watermark {{
    position: absolute;
    left: 0;
    top: 49.0%;
    width: 100%;
    text-align: center;
    transform: translateY(-50%);
    color: rgba(255,255,255,{watermark_opacity});
    -webkit-text-stroke: 1px rgba(0,0,0,0.28);
    font-family: Arial, sans-serif;
    font-size: {watermark_size}px;
    font-weight: 700;
    letter-spacing: 6px;
    white-space: nowrap;
}}
.text-area {{
    position: absolute;
    left: {text_left}px;
    right: {text_left}px;
    top: {text_top}px;
    bottom: {text_bottom}px;
    overflow: visible;
}}
.headline {{
    width: 100%;
    margin: 0;
    padding: 0;
    color: white;
    text-align: left;
    font-size: {title_size}px;
    line-height: 1.24;
    font-weight: 700;
    white-space: normal;
    word-break: normal;
    overflow-wrap: break-word;
    line-break: auto;
    text-shadow:
        -2px -2px 0 rgba(0,0,0,.95),
         2px -2px 0 rgba(0,0,0,.95),
        -2px  2px 0 rgba(0,0,0,.95),
         2px  2px 0 rgba(0,0,0,.95),
         0px  4px 8px rgba(0,0,0,.85);
}}
.body-copy {{
    width: 100%;
    margin-top: 24px;
    padding: 0;
    color: rgba(255,255,255,.97);
    text-align: left;
    font-size: {body_size}px;
    line-height: 1.52;
    font-weight: 400;
    white-space: normal;
    word-break: normal;
    overflow-wrap: break-word;
    line-break: auto;
    text-shadow:
        -1px -1px 0 rgba(0,0,0,.92),
         1px -1px 0 rgba(0,0,0,.92),
        -1px  1px 0 rgba(0,0,0,.92),
         1px  1px 0 rgba(0,0,0,.92),
         0px  3px 7px rgba(0,0,0,.90);
}}
.index {{
    position: absolute;
    right: {text_left}px;
    bottom: 18px;
    color: rgba(255,255,255,.90);
    font-family: Arial, sans-serif;
    font-size: 20px;
    text-shadow: 0 2px 4px rgba(0,0,0,.9);
}}
</style>
</head>
<body>
<div class="watermark">{watermark_html}</div>
<div class="text-area" id="textArea">
  <div class="headline" id="headline">{headline_html}</div>
  <div class="body-copy" id="bodyCopy">{body_html}</div>
</div>
<div class="index">{index}/{total}</div>
<script>
function lineCount(el) {{
  const cs = getComputedStyle(el);
  const fs = parseFloat(cs.fontSize) || 1;
  const lhRaw = cs.lineHeight;
  const lh = lhRaw.endsWith('px') ? parseFloat(lhRaw) : fs * 1.2;
  return Math.max(1, Math.round(el.getBoundingClientRect().height / lh));
}}
function setSize(el, px) {{ el.style.fontSize = px + 'px'; }}
function fitsOverall() {{
  const a = document.getElementById('textArea').getBoundingClientRect();
  const b = document.getElementById('bodyCopy').getBoundingClientRect();
  return b.bottom <= a.bottom + 1;
}}
const title = document.getElementById('headline');
const bodyEl = document.getElementById('bodyCopy');
let ts = {title_size};
while (ts > {title_min} && lineCount(title) > {title_max_lines}) {{ ts -= 1; setSize(title, ts); }}
let bs = {body_size};
while (bs > {body_min} && (lineCount(bodyEl) > {body_max_lines} || !fitsOverall())) {{ bs -= 1; setSize(bodyEl, bs); }}
// If a two-line title plus body still exceeds the box, reduce body first, then title slightly.
while (!fitsOverall() && bs > {body_min}) {{ bs -= 1; setSize(bodyEl, bs); }}
while (!fitsOverall() && ts > {title_min}) {{ ts -= 1; setSize(title, ts); }}
</script>
</body>
</html>"""

        output_png_path.parent.mkdir(parents=True, exist_ok=True)
        error_box: list[Exception] = []

        def worker() -> None:
            try:
                with sync_playwright() as p:
                    browser = p.chromium.launch(headless=True)
                    page = browser.new_page(viewport={"width": w, "height": h}, device_scale_factor=1)
                    page.set_content(page_html, wait_until="networkidle")
                    # Same practical stability trick as Recap Personal: allow shaping/font load to settle.
                    page.wait_for_timeout(700)
                    page.screenshot(path=str(output_png_path), omit_background=True)
                    browser.close()
            except Exception as exc:
                error_box.append(exc)

        render_thread = threading.Thread(target=worker, daemon=True)
        render_thread.start()
        render_thread.join()
        if error_box:
            raise RuntimeError(f"Playwright Burmese text render failed: {error_box[0]}")
        if not output_png_path.exists():
            raise RuntimeError("Playwright Burmese text render did not create output PNG")

    def _render_card(
        self,
        background_path: Path,
        out_path: Path,
        slide: dict[str, Any],
        *,
        canvas_size: tuple[int, int],
        index: int,
        total: int,
        platform: str,
    ) -> None:
        """Story card renderer using the Recap Personal Chromium/PNG text path."""
        w, h = canvas_size
        base = Image.open(background_path).convert("RGB")
        base = self._cover_crop(base, canvas_size)
        base = ImageEnhance.Contrast(base).enhance(0.95)
        base = ImageEnhance.Brightness(base).enhance(0.88)
        rgba = base.convert("RGBA")

        # Keep a consistent lower readability zone; text itself is rendered by Chromium.
        overlay = Image.new("RGBA", canvas_size, (0, 0, 0, 0))
        od = ImageDraw.Draw(overlay)
        lower_y = int(h * float(self.config.get("lower_overlay_start", 0.51)))
        lower_alpha = int(self.config.get("lower_overlay_alpha", 182))
        od.rectangle((0, lower_y, w, h), fill=(0, 0, 0, max(0, min(255, lower_alpha))))
        rgba = Image.alpha_composite(rgba, overlay)

        out_path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="story_browser_text_") as td:
            text_layer_path = Path(td) / "story_text.png"
            self._render_story_text_layer_playwright(
                headline=slide.get("headline") or "",
                body=slide.get("body") or "",
                index=index,
                total=total,
                output_png_path=text_layer_path,
                canvas_size=canvas_size,
            )
            text_layer = Image.open(text_layer_path).convert("RGBA")
            if text_layer.size != canvas_size:
                text_layer = text_layer.resize(canvas_size, Image.Resampling.LANCZOS)
            final_rgba = Image.alpha_composite(rgba, text_layer)
            final_rgba.convert("RGB").save(out_path, format="JPEG", quality=95, subsampling=0)

        print(f"📝 Slide {index}/{total}: Recap-Personal-style Chromium Burmese renderer ✅")

    def _build_image_prompt(self, prompt: str, character_bible: str) -> str:
        model=str(self.config.get('fal_model') or '').rstrip('/')
        if model in {'fal-ai/flux/schnell','fal-ai/flux-1/schnell'}:
            # Schnell follows concise, concrete prompts better than a long global
            # instruction block. The planner repeats full appearance in every scene;
            # the bible remains a stable identity reminder, not a required cast list.
            return (
                "Vertical 9:16 cinematic Burmese emotional drama, realistic people, natural anatomy, "
                "believable lighting and location. "
                "ONE CONTINUOUS FULL-FRAME SHOT: exactly one camera viewpoint and one instant in time, "
                "with one coherent environment filling the entire 9:16 canvas. Never make a collage, "
                "comic page, storyboard, contact sheet, split screen, before-and-after, picture-in-picture, "
                "stacked rows, tiled copies, repeated scene, repeated subject, panel border, or frame divider. "
                f"SCENE: {str(prompt or '').strip()} "
                f"FIXED CHARACTER DESIGN REFERENCE: {str(character_bible or '').strip()} "
                "Keep the same face shape, skin tone, age, hairstyle, hair color, clothing colors and accessories "
                "for every recurring person. Show only people explicitly visible in SCENE; do not add absent or "
                "mentioned people, portraits, reflections, silhouettes or duplicates. Character names are identifiers "
                "only and must never appear as writing. Preserve the exact action, prop type/color, location and shot. "
                "No text, name, letters, numbers, subtitle, sign, poster, watermark or logo. Leave safe negative space "
                "for later overlay."
            ).strip()
        return (
            f"{prompt}\n"
            f"CHARACTER CONSISTENCY: {character_bible}\n"
            "Vertical cinematic story illustration, realistic dramatic lighting, "
            "strong composition with safe negative space for later text overlay. "
            "ONE CONTINUOUS FULL-FRAME SHOT with exactly one camera viewpoint and one instant; fill the "
            "entire 9:16 canvas with one coherent scene. Never use a collage, comic page, storyboard, "
            "contact sheet, split screen, stacked rows, tiled copies, repeated scene or subject, panel border, "
            "frame divider, before-and-after, or picture-in-picture. "
            "No text, no letters, no subtitles, no watermark, no logo."
        ).strip()

    def _resolve_slide_reference_path(self, *, raw_dir: Path, slide_index: int) -> Path | None:
        explicit = str(self.config.get('story_reference_image') or '').strip()
        if explicit:
            p = Path(explicit)
            if p.exists():
                return p
        reuse_first = bool(self.config.get('gemini_web_reuse_first_slide_as_reference', True))
        if not reuse_first or slide_index <= 1:
            return None
        anchor = raw_dir / 'slide_01.jpg'
        return anchor if anchor.exists() else None

    def _generate_scene_image_fal(
        self,
        prompt: str,
        save_path: Path,
        *,
        width: int | None = None,
        height: int | None = None,
    ) -> Path:
        """Generate one image with fal queue API.

        V0.3.2 fixes FLUX.2 Flash validation/result 422 errors:
        - FLUX.2 Flash only receives fields documented by its current schema.
        - `num_inference_steps` and `safety_tolerance` are NOT sent to
          fal-ai/flux-2/flash because that endpoint does not expose them.
        - a COMPLETED queue status may still contain `error` / `error_type`;
          surface that before fetching the response URL.
        - HTTP error bodies are included in logs instead of hiding the reason.
        """
        api_key = (
            os.getenv('FAL_KEY')
            or os.getenv('FAL_API_KEY')
            or str(self.config.get('fal_api_key') or '').strip()
        )
        if not api_key:
            raise RuntimeError('FAL_KEY environment variable မတွေ့ပါ။ fal/FLUX သုံးမယ်ဆို FAL_KEY ထည့်ပေးပါ။')

        model = str(self.config.get('fal_model') or 'fal-ai/flux-2/flash').strip()
        width = int(width if width is not None else self.config.get('fal_width', 720))
        height = int(height if height is not None else self.config.get('fal_height', 1280))
        guidance_scale = float(self.config.get('fal_guidance_scale', 3.5))
        output_format = str(self.config.get('fal_output_format', 'jpeg')).strip().lower()
        timeout_seconds = int(self.config.get('fal_timeout_seconds', 180))
        poll_interval = float(self.config.get('fal_poll_interval_seconds', 2.0))

        # Current FAL image endpoints accept these custom dimensions.
        if not (512 <= width <= 2048 and 512 <= height <= 2048):
            raise RuntimeError(f'fal image_size invalid: {width}x{height}; each side must be 512..2048')
        if output_format not in {'jpeg', 'png', 'webp'}:
            output_format = 'jpeg'

        submit_url = f'https://queue.fal.run/{model}'
        headers = {
            'Authorization': f'Key {api_key}',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        }

        # IMPORTANT: model-aware schema.  The old implementation sent
        # num_inference_steps + safety_tolerance to FLUX.2 Flash.  Those are not
        # part of the current Flash text-to-image input schema and can lead to a
        # queued request completing with a validation error / 422 on result fetch.
        payload = {
            'prompt': prompt,
            'image_size': {'width': width, 'height': height},
            'num_images': 1,
            'output_format': output_format,
            'guidance_scale': guidance_scale,
            'enable_safety_checker': True,
        }
        normalized_model=model.rstrip('/')
        if normalized_model == 'fal-ai/flux-2/flash':
            payload['enable_prompt_expansion'] = bool(
                self.config.get('fal_enable_prompt_expansion', False)
            )
            print(
                f'🟣 FAL FLUX.2 Flash → {width}x{height} | '
                f'guidance={guidance_scale:g} | prompt_expansion={payload["enable_prompt_expansion"]}'
            )
        elif normalized_model in {'fal-ai/flux/schnell','fal-ai/flux-1/schnell'}:
            payload['num_inference_steps'] = max(1,min(12,int(self.config.get('fal_num_inference_steps',4))))
            print(
                f'🟣 FAL FLUX.1 Schnell single image → {width}x{height} | '
                f'steps={payload["num_inference_steps"]} | guidance={guidance_scale:g}'
            )
        else:
            # Preserve legacy knobs only for older/non-Flash routes that may use them.
            if 'fal_num_inference_steps' in self.config:
                payload['num_inference_steps'] = int(self.config.get('fal_num_inference_steps', 20))
            if 'fal_safety_tolerance' in self.config:
                payload['safety_tolerance'] = str(self.config.get('fal_safety_tolerance', '2')).strip()

        # V2.0.13: queue request checkpoint. If a status/result HTTP poll times out,
        # keep the SAME fal request_id and resume it instead of submitting another paid
        # generation. The checkpoint contains no API key.
        queue_ckpt = save_path.with_suffix(save_path.suffix + '.fal_queue.json')
        prompt_sha = hashlib.sha256(
            f'{model}\n{width}x{height}\n{prompt}'.encode('utf-8')
        ).hexdigest()
        legacy_prompt_sha = hashlib.sha256(prompt.encode('utf-8')).hexdigest()
        submit_data = None
        status_url = None
        response_url = None
        request_id = ''
        checkpoint_image_url = ''
        try:
            if queue_ckpt.exists() and not save_path.exists():
                q = json.loads(queue_ckpt.read_text(encoding='utf-8'))
                if (
                    str(q.get('prompt_sha') or '') in {prompt_sha, legacy_prompt_sha}
                    and str(q.get('model') or '') == model
                ):
                    request_id = str(q.get('request_id') or '').strip()
                    status_url = str(q.get('status_url') or '').strip()
                    response_url = str(q.get('response_url') or '').strip()
                    checkpoint_image_url = str(q.get('image_url') or '').strip()
                    if status_url and response_url:
                        if checkpoint_image_url:
                            print(
                                f'♻️ FAL completed asset resume → '
                                f'{request_id or "existing request"} (status/result poll skipped)'
                            )
                        else:
                            print(f'♻️ FAL queue resume → {request_id or "existing request"} (no new image submission)')
                    else:
                        status_url = response_url = None
        except Exception as exc:
            print(f'⚠️ FAL queue checkpoint read warning: {exc}')

        if not status_url or not response_url:
            try:
                submit = requests.post(submit_url, headers=headers, json=payload, timeout=60)
                if not submit.ok:
                    body = (submit.text or '')[-2500:]
                    raise RuntimeError(f'HTTP {submit.status_code}: {body}')
                submit_data = submit.json()
            except Exception as exc:
                raise RuntimeError(f'fal submit failed: {exc}') from exc

            request_id = str(submit_data.get('request_id') or '').strip()
            status_url = submit_data.get('status_url')
            response_url = submit_data.get('response_url')
            if not status_url or not response_url:
                raise RuntimeError(f'fal response missing status_url/response_url: {submit_data}')
            try:
                queue_ckpt.parent.mkdir(parents=True, exist_ok=True)
                queue_ckpt.write_text(json.dumps({
                    'request_id': request_id,
                    'status_url': status_url,
                    'response_url': response_url,
                    'prompt_sha': prompt_sha,
                    'model': model,
                    'saved_at': time.time(),
                }, ensure_ascii=False, indent=2), encoding='utf-8')
            except Exception as exc:
                print(f'⚠️ FAL queue checkpoint save warning: {exc}')
            if request_id:
                print(f'🟣 FAL queued → {request_id}')

        # If an earlier attempt reached the completed result but its media
        # download was interrupted, use the saved immutable asset URL directly.
        # This avoids depending on queue.fal.run again and never resubmits a paid
        # generation request.
        if checkpoint_image_url:
            image_bytes = self._download_fal_image_bytes(
                checkpoint_image_url,
                attempts=int(self.config.get('fal_image_download_attempts', 8)),
                timeout_seconds=int(self.config.get('fal_image_download_timeout_seconds', 120)),
            )
            save_path.parent.mkdir(parents=True, exist_ok=True)
            tmp_path = save_path.with_suffix(save_path.suffix + '.part')
            tmp_path.write_bytes(image_bytes)
            tmp_path.replace(save_path)
            try:
                queue_ckpt.unlink(missing_ok=True)
            except Exception:
                pass
            print(f'✅ FAL image saved → {save_path}')
            return save_path

        import time as _time
        start_ts = _time.time()
        final_status = {}
        transient_poll_errors = 0
        while True:
            if _time.time() - start_ts > timeout_seconds:
                # Keep queue_ckpt so an outer retry/restart resumes this SAME request.
                raise RuntimeError(f'fal image generation timeout; request preserved for resume: {request_id}')
            try:
                sres = requests.get(
                    status_url,
                    headers={'Authorization': f'Key {api_key}', 'Accept': 'application/json'},
                    params={'logs': 1},
                    timeout=30,
                )
                if not sres.ok:
                    body = (sres.text or '')[-2500:]
                    # 4xx status responses are normally terminal; network/5xx are retried.
                    if 400 <= sres.status_code < 500:
                        terminal_exc = RuntimeError(f'HTTP {sres.status_code}: {body}')
                        if self._is_fal_content_policy_violation(terminal_exc):
                            try: queue_ckpt.unlink(missing_ok=True)
                            except Exception: pass
                        raise terminal_exc
                    raise requests.RequestException(f'HTTP {sres.status_code}: {body}')
                sdata = sres.json()
                transient_poll_errors = 0
            except RuntimeError:
                raise
            except Exception as exc:
                transient_poll_errors += 1
                remaining = max(0, int(timeout_seconds - (_time.time() - start_ts)))
                if transient_poll_errors <= 8 and remaining > 5:
                    wait_s = min(10.0, max(2.0, transient_poll_errors * 2.0))
                    print(
                        f'🌐 FAL status poll transient error {transient_poll_errors}/8: {exc} '
                        f'— keeping SAME request {request_id or ""}; retry in {wait_s:g}s'
                    )
                    _time.sleep(wait_s)
                    continue
                raise RuntimeError(
                    f'fal status poll failed after transient retries; request preserved for resume: '
                    f'{request_id}; last_error={exc}'
                ) from exc

            final_status = sdata
            state = str(sdata.get('status') or sdata.get('state') or '').upper()
            if state in {'COMPLETED', 'SUCCESS'}:
                err = sdata.get('error')
                err_type = sdata.get('error_type')
                if err or err_type:
                    # Terminal generation failure: do not keep a stale queue checkpoint.
                    try: queue_ckpt.unlink(missing_ok=True)
                    except Exception: pass
                    raise RuntimeError(
                        f'fal generation completed with error: '
                        f'type={err_type or "unknown"}; error={err or "unknown"}'
                    )
                break
            if state in {'FAILED', 'ERROR', 'CANCELLED'}:
                try: queue_ckpt.unlink(missing_ok=True)
                except Exception: pass
                raise RuntimeError(f'fal generation failed: {sdata}')
            _time.sleep(poll_interval)

        response_url = final_status.get('response_url') or response_url
        rdata = None
        last_result_exc = None
        for result_try in range(1, 6):
            try:
                rres = requests.get(
                    response_url,
                    headers={'Authorization': f'Key {api_key}', 'Accept': 'application/json'},
                    timeout=60,
                )
                if not rres.ok:
                    body = (rres.text or '')[-3500:]
                    if 400 <= rres.status_code < 500:
                        terminal_exc = RuntimeError(f'HTTP {rres.status_code}: {body}')
                        if self._is_fal_content_policy_violation(terminal_exc):
                            try: queue_ckpt.unlink(missing_ok=True)
                            except Exception: pass
                        raise terminal_exc
                    raise requests.RequestException(f'HTTP {rres.status_code}: {body}')
                rdata = rres.json()
                break
            except RuntimeError:
                raise
            except Exception as exc:
                last_result_exc = exc
                if result_try < 5:
                    print(f'🌐 FAL result fetch transient error {result_try}/5: {exc} — SAME request, retrying')
                    _time.sleep(min(10.0, result_try * 2.0))
                    continue
        if rdata is None:
            raise RuntimeError(
                f'fal result fetch failed after retries; request preserved for resume: '
                f'{request_id}; last_error={last_result_exc}'
            )

        images = rdata.get('images') or []
        if not images:
            raise RuntimeError(f'fal result missing images: {rdata}')
        image_url = images[0].get('url')
        if not image_url:
            raise RuntimeError(f'fal image url missing: {images[0]}')

        # Persist the completed media URL before downloading. If fal.media has a
        # transient TLS failure, the next process can resume at the download
        # stage without another status/result request.
        try:
            q = json.loads(queue_ckpt.read_text(encoding='utf-8')) if queue_ckpt.exists() else {}
            q['image_url'] = str(image_url)
            q['result_ready_at'] = time.time()
            queue_ckpt.write_text(json.dumps(q, ensure_ascii=False, indent=2), encoding='utf-8')
        except Exception as exc:
            print(f'⚠️ FAL completed asset checkpoint warning: {exc}')

        image_bytes = self._download_fal_image_bytes(
            image_url,
            attempts=int(self.config.get('fal_image_download_attempts', 8)),
            timeout_seconds=int(self.config.get('fal_image_download_timeout_seconds', 120)),
        )

        save_path.parent.mkdir(parents=True, exist_ok=True)
        # Write only after the response body is complete.  A TLS EOF therefore
        # cannot leave a corrupt image that a later resume mistakes for success.
        tmp_path = save_path.with_suffix(save_path.suffix + '.part')
        tmp_path.write_bytes(image_bytes)
        tmp_path.replace(save_path)
        try:
            queue_ckpt.unlink(missing_ok=True)
        except Exception:
            pass
        print(f'✅ FAL image saved → {save_path}')
        return save_path

    @staticmethod
    def _download_fal_image_bytes(
        image_url: str,
        *,
        attempts: int = 8,
        timeout_seconds: int = 120,
    ) -> bytes:
        """Download one completed FAL asset without resubmitting generation.

        fal.media downloads occasionally end with an SSL EOF behind the local
        proxy even though the paid queue request completed successfully. Retry
        only the immutable result URL and ask the server to close each HTTP
        connection, which avoids reusing a broken pooled TLS connection.
        """
        attempts = max(1, min(12, int(attempts)))
        timeout_seconds = max(30, int(timeout_seconds))
        last_exc: Exception | None = None
        for attempt in range(1, attempts + 1):
            try:
                response = requests.get(
                    image_url,
                    headers={'Accept': 'image/*', 'Connection': 'close'},
                    timeout=(20, timeout_seconds),
                )
                response.raise_for_status()
                content = bytes(response.content or b'')
                if not content:
                    raise RuntimeError('empty image response body')
                return content
            except Exception as exc:
                last_exc = exc
                if attempt >= attempts:
                    break
                wait_s = min(12.0, float(attempt * 2))
                print(
                    f'🌐 FAL image download transient error {attempt}/{attempts}: {exc} '
                    f'— SAME completed asset URL, retry in {wait_s:g}s'
                )
                time.sleep(wait_s)
        raise RuntimeError(
            f'fal image download failed after {attempts} attempts; '
            f'completed request preserved for resume: {last_exc}'
        ) from last_exc

    @staticmethod
    def _is_fal_content_policy_violation(exc: Exception) -> bool:
        text = str(exc or '').lower()
        return (
            'content_policy_violation' in text
            or ('http 422' in text and 'content checker' in text)
            or ('http 422' in text and 'flagged' in text)
        )

    @staticmethod
    def _local_policy_safe_visual_rewrite(prompt: str) -> str:
        """Fail-safe neutralizer used only if Gemini rewrite is unavailable.

        This does not disable or evade FAL safety.  It removes graphic/medical wording
        while preserving character, setting, emotion and composition.
        """
        text = str(prompt or '')
        replacements = [
            # Phrase-level rewrites first so horror mood survives without graphic wording.
            (r'(?i)\bcasting\s+a\s+bloody\s+light\b', 'casting an ominous deep-red glow'),
            (r'(?i)\bbloody\s+light\b', 'ominous deep-red glow'),
            (r'(?i)\bclutching\s+his\s+head\s+in\s+pain\b', 'holding his head, visibly distressed'),
            (r'(?i)\bclutching\s+her\s+head\s+in\s+pain\b', 'holding her head, visibly distressed'),
            (r'(?i)\bclutching\s+their\s+head\s+in\s+pain\b', 'holding their head, visibly distressed'),
            (r'(?i)\bsurgical\s+bandage\b', 'a simple folded cloth near her side'),
            (r'(?i)\bbandage(?:s)?\b', 'soft cloth wrap'),
            (r'(?i)\bsurgical\s+scar\b', 'a subtle sign of past hardship'),
            (r'(?i)\bscar(?:s|red)?\b', 'subtle sign of past hardship'),
            (r'(?i)\bbleeding\b', 'visibly distressed'),
            (r'(?i)\bblood(?:y|ied)?\b', 'ominous deep-red detail'),
            (r'(?i)\bgore|gory\b', 'intense dramatic atmosphere'),
            (r'(?i)\bwound(?:s|ed)?\b', 'sign of exhaustion'),
            (r'(?i)\binjur(?:y|ies|ed)\b', 'difficult experience'),
            (r'(?i)\bincision(?:s)?\b', 'subtle recovery detail'),
            (r'(?i)\bsurger(?:y|ies|ical)\b', 'recovery'),
            (r'(?i)\bstitch(?:es|ed)?\b', 'recovery detail'),
            (r'(?i)\bin\s+pain\b', 'in visible distress'),
        ]
        for pat, repl in replacements:
            text = re.sub(pat, repl, text)
        text = re.sub(r'\s+', ' ', text).strip()
        if 'general-audience presentation' not in text.casefold():
            text += ' Keep all physical details non-graphic and suitable for a general-audience presentation.'
        return text

    async def _rewrite_fal_policy_prompt(self, prompt: str, rewrite_no: int) -> str:
        """Ask Gemini for a genuinely safer visual prompt after FAL policy 422.

        The request explicitly preserves the scene/story but removes policy-sensitive
        graphic/medical detail.  FAL safety_checker remains enabled.
        """
        instruction = f"""
Rewrite this image-generation prompt into a policy-safe cinematic prompt.
The previous version was rejected by an image safety checker.

Rules:
- Preserve the SAME adult characters, clothing, location, pose intent, emotion, camera composition and story meaning.
- Preserve the ONE CONTINUOUS FULL-FRAME SHOT constraint: one camera viewpoint, one instant, one undivided 9:16 scene; never panels, collage, split screen, stacked rows, tiles or repeated subjects.
- Remove or soften explicit injury, wound, scar, surgery, medical-procedure, blood, gore, self-harm or graphic bodily detail.
- Express difficult events through emotion, posture, atmosphere, clothing and non-graphic context instead.
- Do NOT add sexual content or nudity.
- Do NOT describe how to bypass a safety checker. The goal is a genuinely safer image.
- Keep the existing no-text/no-watermark requirement.
- Return ONLY the rewritten English image prompt. No markdown, no explanation.

Original prompt:
{prompt}
"""
        rewritten = ''
        self.ai._enable_proxy()
        try:
            response = await asyncio.to_thread(
                self.ai.generate_content,
                model=self.ai.text_model,
                contents=instruction,
            )
            rewritten = str(getattr(response, 'text', '') or '').strip()
        except Exception as exc:
            print(f"⚠️ Gemini safe visual rewrite {rewrite_no} failed; local neutralizer fallback: {exc}")
        finally:
            self.ai._disable_proxy()

        rewritten = self._strip_code_fence(rewritten).strip() if rewritten else ''
        if not rewritten or rewritten.casefold() == str(prompt or '').strip().casefold():
            rewritten = self._local_policy_safe_visual_rewrite(prompt)
        return rewritten

    async def _generate_scene_image(self, prompt: str, character_bible: str, save_path: Path) -> Path:
        full_prompt = self._build_image_prompt(prompt, character_bible)
        provider = str(self.config.get('image_provider') or 'fal').strip().lower()

        save_path.parent.mkdir(parents=True, exist_ok=True)
        retries = max(1, int(self.config.get('image_retries', 3)))
        policy_rewrites_max = max(0, int(self.config.get('fal_policy_rewrite_retries', 2)))
        last_exc = None

        if provider == 'fal':
            active_prompt = full_prompt
            network_failures = 0
            policy_rewrites = 0
            while True:
                try:
                    return self._generate_scene_image_fal(active_prompt, save_path)
                except Exception as exc:
                    last_exc = exc
                    if self._is_fal_content_policy_violation(exc):
                        if policy_rewrites >= policy_rewrites_max:
                            print(
                                f"🛡️ FAL content-policy flag remains after {policy_rewrites} safe rewrite(s); "
                                "stopping instead of blindly resubmitting the same prompt."
                            )
                            break
                        policy_rewrites += 1
                        print(
                            f"🛡️ FAL content-policy 422 detected — blind retry skipped. "
                            f"Rewriting visual safely with Gemini {policy_rewrites}/{policy_rewrites_max}..."
                        )
                        active_prompt = await self._rewrite_fal_policy_prompt(active_prompt, policy_rewrites)
                        print("✍️ Policy-safe visual prompt ready → retrying FAL with rewritten prompt")
                        await asyncio.sleep(1.0)
                        continue

                    network_failures += 1
                    print(f"⚠️ Story FAL/FLUX transport/image retry {network_failures}/{retries}: {exc}")
                    if network_failures >= retries:
                        break
                    await asyncio.sleep(min(3 * network_failures, 8))
            raise RuntimeError(f'FAL image generation failed: {last_exc}')

        # fallback: google / gemini image generation
        self.ai._enable_proxy()
        try:
            for attempt in range(1, retries + 1):
                try:
                    try:
                        result = self.ai.generate_images(
                            model=self.ai.image_model,
                            prompt=full_prompt,
                            config=dict(number_of_images=1, output_mime_type='image/jpeg', aspect_ratio='9:16'),
                        )
                    except Exception:
                        result = self.ai.generate_images(
                            model=self.ai.image_model,
                            prompt=full_prompt,
                            config=dict(number_of_images=1, output_mime_type='image/jpeg'),
                        )
                    result.generated_images[0].image.save(save_path)
                    return save_path
                except Exception as exc:
                    last_exc = exc
                    print(f"⚠️ Story Gemini image retry {attempt}/{retries}: {exc}")
                    await asyncio.sleep(min(3 * attempt, 8))
            raise RuntimeError(f'Gemini/Imagen generation failed: {last_exc}')
        finally:
            self.ai._disable_proxy()

    async def _generate_fal_sheet_image(
        self,
        *,
        prompt: str,
        save_path: Path,
        width: int,
        height: int,
    ) -> Path:
        """Generate one paid 2x2 sheet with the normal resume/policy protections."""
        retries = max(1, int(self.config.get('image_retries', 3)))
        policy_rewrites_max = max(0, int(self.config.get('fal_policy_rewrite_retries', 2)))
        active_prompt = str(prompt or '').strip()
        network_failures = 0
        policy_rewrites = 0
        last_exc: Exception | None = None
        while True:
            try:
                return self._generate_scene_image_fal(
                    active_prompt,
                    save_path,
                    width=width,
                    height=height,
                )
            except Exception as exc:
                last_exc = exc
                if self._is_fal_content_policy_violation(exc):
                    if policy_rewrites >= policy_rewrites_max:
                        break
                    policy_rewrites += 1
                    print(
                        f"🛡️ FAL 2x2 sheet policy rewrite "
                        f"{policy_rewrites}/{policy_rewrites_max}"
                    )
                    try:
                        save_path.with_suffix(save_path.suffix + '.fal_queue.json').unlink(missing_ok=True)
                    except OSError:
                        pass
                    active_prompt = await self._rewrite_fal_policy_prompt(
                        active_prompt,
                        policy_rewrites,
                    )
                    continue
                network_failures += 1
                if network_failures >= retries:
                    break
                print(
                    f"⚠️ FAL 2x2 sheet transport retry "
                    f"{network_failures}/{retries}: {exc}"
                )
                await asyncio.sleep(min(3 * network_failures, 8))
        raise RuntimeError(f'FAL 2x2 sheet generation failed: {last_exc}')

    async def _build_story_images(
        self,
        *,
        plan: dict[str, Any],
        raw_dir: Path,
    ) -> list[Path]:
        slides = list(plan.get('slides') or [])
        targets = [raw_dir / f'slide_{i:02d}.jpg' for i in range(1, len(slides) + 1)]
        provider = str(self.config.get('image_provider') or 'fal').strip().lower()
        sheet_enabled = bool(self.config.get('image_sheet_enabled', False))

        if provider == 'fal' and sheet_enabled:
            sheet_width = int(self.config.get('image_sheet_width', 1152))
            sheet_height = int(self.config.get('image_sheet_height', 2048))
            crop_width = int(self.config.get('image_sheet_crop_width', 720))
            crop_height = int(self.config.get('image_sheet_crop_height', 1280))
            inset = float(self.config.get('image_sheet_crop_inset_fraction', 0.008))
            sheet_dir = raw_dir / '_sheets'
            sheet_dir.mkdir(parents=True, exist_ok=True)
            slide_groups = StoryImageSheetService.groups(slides)
            target_groups = StoryImageSheetService.groups(targets)
            print(
                f"🧩 Drama 2x2 image sheets: {len(slide_groups)} FAL call(s) "
                f"→ {len(slides)} scene crop(s)"
            )
            global_style = (
                "Consistent cinematic Burmese emotional drama, realistic people and locations, "
                "natural anatomy, coherent wardrobe and identity, dramatic but believable lighting. "
                "Every panel must depict the exact assigned action and preserve every explicitly "
                "stated object type, object color, location, and character relationship."
            )
            for group_index, (slide_group, target_group) in enumerate(
                zip(slide_groups, target_groups),
                1,
            ):
                if StoryImageSheetService.all_valid(target_group):
                    print(f"♻️ Drama sheet group {group_index}: all crops already ready")
                    continue
                sheet_path = sheet_dir / f'sheet_{group_index:02d}.jpg'
                if not StoryImageSheetService.all_valid([sheet_path]):
                    prompt = StoryImageSheetService.build_prompt(
                        scene_prompts=[str(x.get('visual_prompt') or '') for x in slide_group],
                        character_bible=str(plan.get('character_bible') or ''),
                        global_style=global_style,
                    )
                    await self._generate_fal_sheet_image(
                        prompt=prompt,
                        save_path=sheet_path,
                        width=sheet_width,
                        height=sheet_height,
                    )
                StoryImageSheetService.crop_sheet(
                    sheet_path=sheet_path,
                    output_paths=target_group,
                    output_size=(crop_width, crop_height),
                    inset_fraction=inset,
                    overwrite=False,
                    manifest_path=sheet_dir / f'sheet_{group_index:02d}_manifest.json',
                )
                if not StoryImageSheetService.all_valid(target_group):
                    raise RuntimeError(f'Drama 2x2 crop validation failed for group {group_index}')
            return targets

        gemini_web_worker = GeminiWebStoryImageService(self.config) if provider == 'gemini_web' else None
        try:
            for idx, (slide, raw_path) in enumerate(zip(slides, targets), 1):
                if StoryImageSheetService.all_valid([raw_path]):
                    print(f"♻️ Slide image {idx:02d}/{len(slides)} reuse")
                    continue
                if gemini_web_worker:
                    ref_path = self._resolve_slide_reference_path(raw_dir=raw_dir, slide_index=idx)
                    full_prompt = self._build_image_prompt(
                        slide.get('visual_prompt') or '',
                        plan.get('character_bible') or '',
                    )
                    await gemini_web_worker.generate_image(
                        prompt=full_prompt,
                        save_path=raw_path,
                        reference_image_path=ref_path,
                    )
                else:
                    await self._generate_scene_image(
                        slide.get('visual_prompt') or '',
                        plan.get('character_bible') or '',
                        raw_path,
                    )
        finally:
            if gemini_web_worker:
                await gemini_web_worker.close()
        return targets


    async def build_story(self, *, genre: str = "drama", topic: str = "", story_id: str = "") -> dict[str, Any]:
        plan = await self.generate_story_plan(genre=genre, topic=topic)
        if not story_id:
            story_id = time.strftime("%Y%m%d_%H%M%S") + "_" + self._safe_slug(genre)

        output_root = Path(self.config.get("output_root", "outputs/story_carousel")) / story_id
        raw_dir = output_root / "raw"
        square_dir = output_root / "square"
        output_root.mkdir(parents=True, exist_ok=True)

        plan["story_id"] = story_id
        plan["output_root"] = str(output_root)
        (output_root / "story.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")

        total = len(plan["slides"])
        print(f"🎨 Story Carousel image build start: {total} slides")

        raw_images = await self._build_story_images(plan=plan, raw_dir=raw_dir)
        for idx, (slide, raw_path) in enumerate(zip(plan['slides'], raw_images), 1):
            square_path = square_dir / f"slide_{idx:02d}.jpg"
            self._render_card(
                raw_path,
                square_path,
                slide,
                canvas_size=(1080, 1080),
                index=idx,
                total=total,
                platform="square",
            )
            print(f"✅ Slide {idx}/{total}: unified square rendered")

        result = {
            "success": True,
            "story_id": story_id,
            "genre": genre,
            "title": plan.get("title", ""),
            "square_images": [str(square_dir / f"slide_{i:02d}.jpg") for i in range(1, total + 1)],
            "fb_caption": plan.get("fb_caption", ""),
            "tt_caption": plan.get("tt_caption", ""),
            "hashtags": plan.get("hashtags", []),
            "story_json": str(output_root / "story.json"),
        }
        (output_root / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"🎉 Story Carousel Phase-1.1 complete → {output_root}")
        return result
