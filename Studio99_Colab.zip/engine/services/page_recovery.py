from __future__ import annotations

import asyncio

from typing import Optional, Sequence

try:
    from services.health_monitor import note_blank_reload, note_event
except ImportError:
    from health_monitor import note_blank_reload, note_event


async def page_looks_blank(page) -> bool:
    """Detect a genuinely blank/stuck browser page.

    This legacy signal is kept for generic pages/probes. Upload pages use the
    stronger expected-UI signal in recover_blank_page(), because Meta/TikTok can
    render sidebars while the actual composer area stays white/black and stuck.
    """
    try:
        url = str(page.url or "").lower()
        if url.startswith("about:blank") or url.startswith("chrome-error://"):
            return True

        state = await page.evaluate(r"""() => {
            const body = document.body;
            if (!body) return {blank: true, textLen: 0, useful: 0, ready: document.readyState};

            const visible = (el) => {
                const s = getComputedStyle(el);
                const r = el.getBoundingClientRect();
                return s.display !== 'none' && s.visibility !== 'hidden'
                    && Number(s.opacity || 1) !== 0 && r.width > 3 && r.height > 3;
            };

            const text = (body.innerText || '').replace(/\s+/g, ' ').trim();
            let useful = 0;
            const nodes = body.querySelectorAll(
                'button,a,input,textarea,select,[role="button"],[role="textbox"],img,video,canvas,svg,h1,h2,h3,p'
            );
            for (const el of nodes) {
                if (!visible(el)) continue;
                const t = (el.innerText || el.textContent || el.getAttribute('aria-label') || '').trim();
                if (t || ['IMG','VIDEO','CANVAS','SVG','INPUT','TEXTAREA','SELECT'].includes(el.tagName)) {
                    useful += 1;
                    if (useful >= 4) break;
                }
            }

            const blank = document.readyState !== 'loading' && text.length < 20 && useful < 2;
            return {blank, textLen: text.length, useful, ready: document.readyState};
        }""")
        return bool(state.get('blank'))
    except Exception:
        return False


async def _visible_selector_exists(page, selector: str) -> bool:
    try:
        loc = page.locator(selector)
        count = min(await loc.count(), 8)
        for i in range(count):
            try:
                if await loc.nth(i).is_visible():
                    return True
            except Exception:
                pass
    except Exception:
        pass
    return False


async def _attached_selector_exists(page, selector: str) -> bool:
    try:
        return await page.locator(selector).count() > 0
    except Exception:
        return False


async def _visible_text_exists(page, text: str) -> bool:
    try:
        loc = page.get_by_text(text, exact=False)
        count = min(await loc.count(), 8)
        for i in range(count):
            try:
                if await loc.nth(i).is_visible():
                    return True
            except Exception:
                pass
    except Exception:
        pass
    return False


async def expected_ui_ready(
    page,
    *,
    expected_selectors: Sequence[str] = (),
    expected_attached_selectors: Sequence[str] = (),
    expected_texts: Sequence[str] = (),
) -> bool:
    """Return True when ANY expected composer/upload control is actually present.

    This deliberately ignores generic shell UI such as Meta's sidebar. A page can
    therefore have lots of text/icons and still be classified as stalled when the
    real Reels composer, group post box, or TikTok upload control never hydrated.
    """
    for selector in expected_selectors or ():
        if await _visible_selector_exists(page, selector):
            return True
    for selector in expected_attached_selectors or ():
        if await _attached_selector_exists(page, selector):
            return True
    for text in expected_texts or ():
        if await _visible_text_exists(page, text):
            return True
    return False


async def _wait_expected_ui(
    page,
    *,
    expected_selectors: Sequence[str],
    expected_attached_selectors: Sequence[str],
    expected_texts: Sequence[str],
    timeout_ms: int,
) -> bool:
    if not (expected_selectors or expected_attached_selectors or expected_texts):
        return False

    elapsed = 0
    poll_ms = 500
    timeout_ms = max(1000, int(timeout_ms))
    while elapsed < timeout_ms:
        try:
            ready = await asyncio.wait_for(
                expected_ui_ready(
                    page,
                    expected_selectors=expected_selectors,
                    expected_attached_selectors=expected_attached_selectors,
                    expected_texts=expected_texts,
                ),
                timeout=3.0,
            )
        except Exception:
            # A renderer-hung tab can stop responding even to DOM probes.
            ready = False

        if ready:
            return True

        try:
            await asyncio.wait_for(page.wait_for_timeout(poll_ms), timeout=2.0)
        except Exception:
            # Keep the recovery loop moving even if this tab's renderer is wedged.
            await asyncio.sleep(poll_ms / 1000.0)
        elapsed += poll_ms
    return False


async def recover_blank_page(
    page,
    *,
    target_url: Optional[str] = None,
    label: str = "page",
    settle_ms: int = 7000,
    max_reloads: int = 2,
    navigation_timeout_ms: int = 120000,
    expected_selectors: Sequence[str] = (),
    expected_attached_selectors: Sequence[str] = (),
    expected_texts: Sequence[str] = (),
    expected_wait_ms: int = 20000,
) -> bool:
    """Recover both fully blank pages and *partial* blank/stalled app shells.

    Safe-use rule: callers must invoke this only BEFORE selecting/uploading a file,
    typing into a composer, or clicking final Post/Share. At those later stages a
    reload could lose state or create duplicate submissions.

    If expected_* values are supplied, the page is considered healthy only when at
    least one real workflow control appears. This fixes the case where Meta's left
    sidebar loads but the main Reels composer stays white forever.
    """
    has_expected = bool(expected_selectors or expected_attached_selectors or expected_texts)

    # Small initial settle. The expected-UI poll below supplies the main 20s grace
    # period, so slow Myanmar/VPN connections are not reloaded too aggressively.
    await page.wait_for_timeout(max(500, int(settle_ms)))

    for attempt in range(max(0, int(max_reloads)) + 1):
        if has_expected:
            ready = await _wait_expected_ui(
                page,
                expected_selectors=expected_selectors,
                expected_attached_selectors=expected_attached_selectors,
                expected_texts=expected_texts,
                timeout_ms=expected_wait_ms,
            )
            if ready:
                return True
            unhealthy = True
            reason = "expected workflow UI missing (partial blank/stalled shell)"
        else:
            unhealthy = await page_looks_blank(page)
            if not unhealthy:
                return True
            reason = "white/black blank page"

        if attempt >= max_reloads:
            print(f"❌ {label}: {reason} — reload limit reached")
            note_event(
                "blank_recovery_failed",
                label,
                max_reloads=max_reloads,
                partial_blank=has_expected,
            )
            return False

        print(
            f"🔄 {label}: {reason} — "
            f"auto reload {attempt + 1}/{max_reloads}"
        )
        note_blank_reload(label, attempt + 1, max_reloads)

        try:
            current = str(page.url or '')
            bad_current = current.startswith('about:blank') or current.startswith('chrome-error://')
            if target_url and bad_current:
                await asyncio.wait_for(
                    page.goto(target_url, timeout=navigation_timeout_ms, wait_until='domcontentloaded'),
                    timeout=(navigation_timeout_ms / 1000.0) + 5.0,
                )
            else:
                await asyncio.wait_for(
                    page.reload(timeout=navigation_timeout_ms, wait_until='domcontentloaded'),
                    timeout=(navigation_timeout_ms / 1000.0) + 5.0,
                )
        except Exception:
            if target_url:
                try:
                    await page.goto(target_url, timeout=navigation_timeout_ms, wait_until='domcontentloaded')
                except Exception:
                    pass

        # Do not sleep another full 20s here; the next loop's expected poll does it.
        await page.wait_for_timeout(2500)

    return False


# V5.5.2: recovery returns the healthy replacement tab; upload callers prune stale tabs immediately after success.
async def recover_page_ladder(
    context,
    page,
    *,
    target_url: str,
    label: str = "page",
    settle_ms: int = 2000,
    max_reloads: int = 2,
    max_tab_reopens: int = 1,
    new_tab_max_reloads: int | None = None,
    navigation_timeout_ms: int = 60000,
    expected_selectors: Sequence[str] = (),
    expected_attached_selectors: Sequence[str] = (),
    expected_texts: Sequence[str] = (),
    expected_wait_ms: int = 20000,
):
    """Safe pre-interaction recovery ladder.

    Ladder:
      current tab reload(s)
      -> new tab in SAME persistent browser context
      -> new tab reload(s)

    Context restart is intentionally owned by the caller because only the caller
    knows the persistent profile path/proxy/headless launch options.

    IMPORTANT: call this only before selecting/uploading files, typing content,
    or clicking final Post/Share. It is deliberately unsafe after stateful work.
    Returns: (usable_page, healthy_bool)
    """
    common = dict(
        target_url=target_url,
        label=label,
        settle_ms=settle_ms,
        max_reloads=max_reloads,
        navigation_timeout_ms=navigation_timeout_ms,
        expected_selectors=expected_selectors,
        expected_attached_selectors=expected_attached_selectors,
        expected_texts=expected_texts,
        expected_wait_ms=expected_wait_ms,
    )

    if await recover_blank_page(page, **common):
        return page, True

    current_page = page
    for reopen_no in range(1, max(0, int(max_tab_reopens)) + 1):
        print(
            f"🧯 {label}: reload မကယ်နိုင်ပါ — hung tab ကိုဖယ်ပြီး "
            f"NEW TAB recovery {reopen_no}/{max_tab_reopens}"
        )
        note_event(
            "tab_reopen",
            label,
            attempt=reopen_no,
            max_tab_reopens=max_tab_reopens,
        )

        old_page = current_page
        try:
            current_page = await asyncio.wait_for(context.new_page(), timeout=15.0)
            await asyncio.wait_for(
                current_page.goto(
                    target_url,
                    timeout=navigation_timeout_ms,
                    wait_until="domcontentloaded",
                ),
                timeout=(navigation_timeout_ms / 1000.0) + 5.0,
            )
        except Exception as exc:
            print(f"⚠️ {label}: new tab open/navigation failed: {exc}")
            try:
                if current_page is not old_page:
                    await asyncio.wait_for(current_page.close(), timeout=5.0)
            except Exception:
                pass
            current_page = old_page
            continue

        new_common = dict(common)
        new_common["label"] = f"{label} NEW TAB"
        # Allow callers to skip reloads on the already-stalled first tab but still
        # keep one small reload fallback inside the freshly-opened tab.
        if new_tab_max_reloads is not None:
            new_common["max_reloads"] = max(0, int(new_tab_max_reloads))
        if await recover_blank_page(current_page, **new_common):
            # Return the healthy replacement immediately. The upload caller now closes
            # stale tabs *after* this function has unwound, avoiding both the old
            # TargetClosedError race and the later two-tab permalink-search deadlock.
            print(f"✅ {label}: NEW TAB recovery success")
            note_event(
                "tab_reopen_success",
                label,
                attempt=reopen_no,
                old_tab_cleanup="caller_immediate",
            )
            return current_page, True

        # New tab also failed. Do not explicitly close the old hung renderer here.
        # The caller owns the whole-context restart and will close all pages together.
        # This avoids orphaned Playwright protocol futures from a mid-recovery close.

    print(f"❌ {label}: reload + new-tab recovery exhausted; context restart required")
    note_event("context_restart_required", label)
    return current_page, False
