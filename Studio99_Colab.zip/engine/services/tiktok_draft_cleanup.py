"""Delete only TikTok creation resources backed by a confirmed post.

Cookies, secure-store, localforage and all other origin storage are untouched.
IndexedDB deletes its own blob files; never unlink files from a browser profile.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SAMPLE = 65536


def fingerprint(path: Path) -> dict:
    path = Path(path)
    size = path.stat().st_size
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for offset in (0, max(0, size // 2 - SAMPLE // 2), max(0, size - SAMPLE)):
            stream.seek(offset)
            digest.update(stream.read(SAMPLE))
    return {'size': size, 'sample_sha256': digest.hexdigest()}


def receipt_path(profile: str, root: Path = ROOT) -> Path:
    if not profile or Path(profile).name != profile or '/' in profile or '\\' in profile:
        raise ValueError('Invalid TikTok profile name')
    return Path(root) / 'state/tiktok_confirmed_posts' / f'{profile}.json'


def load_receipts(profile: str, root: Path = ROOT) -> dict:
    path = receipt_path(profile, root)
    return json.loads(path.read_text(encoding='utf-8-sig')) if path.exists() else {'profile': profile, 'posts': []}


def save_receipts(profile: str, rows: list[dict], root: Path = ROOT) -> None:
    from services.post_publish_cleanup import atomic
    data = load_receipts(profile, root)
    known = {json.dumps(row, sort_keys=True) for row in data['posts']}
    data['posts'].extend(row for row in rows if json.dumps(row, sort_keys=True) not in known)
    atomic(receipt_path(profile, root), data)


def record_success(profile: str, source: Path, file_fingerprint: dict, root: Path = ROOT) -> None:
    # Called exclusively after _wait_for_real_post_confirmation returns.
    save_receipts(profile, [{
        'confirmed': True, 'method': 'post_confirmation',
        'confirmed_at': datetime.now(timezone.utc).isoformat(),
        'source': str(Path(source).resolve()), 'fingerprint': file_fingerprint,
    }], root)


def record_photo_success(profile: str, sources: list[Path], fingerprints: list[dict], root: Path = ROOT) -> None:
    save_receipts(profile, [{'confirmed': True, 'method': 'post_photo_confirmation',
        'confirmed_at': datetime.now(timezone.utc).isoformat(),
        'sources': [str(Path(p).resolve()) for p in sources], 'fingerprints': fingerprints}], root)


def import_published_report(report: dict, root: Path = ROOT) -> int:
    rows = []
    for row in report.get('posts') or []:
        # 102 is the published state observed on TikTok Studio's content list.
        # Under-review, failed, scheduled and unknown states do not authorize deletion.
        if row.get('status') != 102 or row.get('in_review') is not False or not row.get('post_time'):
            continue
        for vid in row.get('video_ids') or []:
            rows.append({'confirmed': True, 'method': 'studio_published_list',
                         'item_id': row['item_id'], 'video_id': vid})
    save_receipts(report['profile'], rows, root)
    return len(rows)


SCRIPT = r"""async ({proofs, dryRun}) => {
    if (location.origin !== 'https://www.tiktok.com') throw Error('Wrong TikTok origin');
    const accepted = proofs.filter(p => p.confirmed === true);
    const vids = new Set(accepted.filter(p => p.method === 'studio_published_list').map(p => p.video_id));
    const fps = accepted.filter(p => p.method === 'post_confirmation' && p.fingerprint).map(p => p.fingerprint);
    const photos = accepted.filter(p => p.method === 'post_photo_confirmation' && p.fingerprints?.length).map(p => p.fingerprints);
    const result = {dry_run:dryRun, groups:[], deleted_records:0, eligible_bytes:0, skipped_groups:0};
    if (!(await indexedDB.databases()).some(d => d.name === 'web_creation_draft')) return result;
    const db = await new Promise((ok,no) => {const r=indexedDB.open('web_creation_draft');r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)});
    const readRows = name => new Promise((ok,no) => {
        const a=[]; const r=db.transaction(name,'readonly').objectStore(name).openCursor();
        r.onsuccess=()=>{const c=r.result;if(!c)return ok(a);a.push({key:c.key,value:c.value});c.continue()};r.onerror=()=>no(r.error);
    });
    const hashBlob = async b => {
        const n=65536, offsets=[0,Math.max(0,Math.floor(b.size/2)-n/2),Math.max(0,b.size-n)];
        const pieces=await Promise.all(offsets.map(o=>b.slice(o,o+n).arrayBuffer()));
        const data=new Uint8Array(pieces.reduce((n,p)=>n+p.byteLength,0));let pos=0;
        for(const piece of pieces){data.set(new Uint8Array(piece),pos);pos+=piece.byteLength}
        return [...new Uint8Array(await crypto.subtle.digest('SHA-256',data))].map(x=>x.toString(16).padStart(2,'0')).join('');
    };
    try {
        for (const store of db.objectStoreNames) {
            if (!/^resource_\d+$/.test(store)) continue;
            const owner=store.slice('resource_'.length), draftStore='local_draft_'+owner;
            if (!db.objectStoreNames.contains(draftStore)) continue;
            const rows=await readRows(store), drafts=await readRows(draftStore), groups=new Map();
            for(const row of rows){const match=typeof row.key==='string'&&row.key.match(/^\/([^/]+)\//);if(!match)continue;const g=match[1];if(!groups.has(g))groups.set(g,[]);groups.get(g).push(row)}
            for(const [id,items] of groups){
                const videos=items.filter(r=>r.value?.data instanceof Blob && r.value.data.type.startsWith('video/'));
                if(items.some(r=>r.value?.isLocked === true || !(r.value?.data instanceof Blob) || !/^(video|image)\//.test(r.value.data.type))){result.skipped_groups++;continue}
                let verified=true;const matched=[];
                if(!videos.length){
                    verified=false;
                    for(const collection of photos){
                        const found=[];
                        for(const row of items){const b=row.value.data;if(collection.some(f=>f.size===b.size))found.push({size:b.size,sample_sha256:await hashBlob(b)})}
                        if(collection.every(f=>found.some(x=>x.size===f.size&&x.sample_sha256===f.sample_sha256))){verified=true;matched.push({method:'post_photo_confirmation'});break}
                    }
                }
                for(const video of videos){
                    const vid=video.value.originalKey, b=video.value.data;
                    if(vids.has(vid)){matched.push({video_id:vid,method:'studio_published_list'});continue}
                    const candidates=fps.filter(f=>f.size===b.size);
                    if(candidates.length && candidates.some(f=>f.sample_sha256===null)){verified=false;break}
                    if(candidates.length){const hash=await hashBlob(b);if(candidates.some(f=>f.sample_sha256===hash)){matched.push({method:'post_confirmation',sample_sha256:hash});continue}}
                    verified=false;break;
                }
                if(!verified){result.skipped_groups++;continue}
                const draft=drafts.find(d=>d.key===id);
                if(draft?.value?.isLocked===true){result.skipped_groups++;continue}
                const bytes=items.reduce((n,r)=>n+r.value.data.size,0);
                if(!dryRun){
                    await new Promise((ok,no)=>{
                        const tx=db.transaction([store,draftStore],'readwrite');
                        tx.oncomplete=ok;tx.onabort=()=>no(tx.error||Error('Creation resource changed during cleanup'));tx.onerror=()=>{};
                        const resources=tx.objectStore(store),local=tx.objectStore(draftStore);
                        for(const row of items){const request=resources.get(row.key);request.onsuccess=()=>{
                            const v=request.result,old=row.value;
                            if(!v || v.isLocked===true || v.updateTime!==old.updateTime || v.originalKey!==old.originalKey || !(v.data instanceof Blob) || v.data.size!==old.data.size){tx.abort();return}
                            resources.delete(row.key);
                        }}
                        const request=local.get(id);request.onsuccess=()=>{
                            const v=request.result;
                            if((!!v)!=(!!draft) || (v && (v.isLocked===true || v.updateTime!==draft.value.updateTime))){tx.abort();return}
                            if(v)local.delete(id);
                        };
                    });
                    result.deleted_records+=items.length+(draft?1:0);
                }
                result.eligible_bytes+=bytes;
                result.groups.push({id,store,resources:items.length,draft_record:!!draft,bytes,proofs:matched});
            }
        }
        return result;
    } finally {db.close()}
}"""


async def cleanup_page(page, profile: str, *, dry_run=False, root: Path = ROOT) -> dict:
    from services.post_publish_cleanup import atomic
    proofs = load_receipts(profile, root)['posts']
    result = await page.evaluate(SCRIPT, {'proofs': proofs, 'dryRun': dry_run})
    if not dry_run:
        try:
            # Release our Blob handles and let Chromium finish its journal
            # cleanup. The browser owns this garbage collection and file unlink.
            session = await page.context.new_cdp_session(page)
            await session.send('HeapProfiler.collectGarbage')
            await page.wait_for_timeout(6000)
            await session.detach()
        except Exception as exc:
            result['gc_warning'] = str(exc)
    result.update(profile=profile, ran_at=datetime.now(timezone.utc).isoformat())
    atomic(Path(root)/'state/tiktok_draft_cleanup'/f'{profile}_last_run.json', result)
    return result
