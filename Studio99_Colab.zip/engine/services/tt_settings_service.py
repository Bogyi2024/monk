from __future__ import annotations

import copy
import json
import os
import re
import shutil
import tempfile
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Any
from services.fb_profile_paths import profile_path, profile_store as validate_profile_store

from services.tt_content_category_registry import (
    content_category,
    managed_category_defaults,
    registry_snapshot,
)
from services.tt_source_config import (
    active_source_records,
    active_source_urls,
    normalize_source_records,
)
from services.tt_route_branding_service import TTRouteBrandingService
from movie_review_profiles import normalize_profile


class TTSettingsService:
    """Central persistent TT account/category/route configuration.

    V1.2 changes:
    - group URLs keep backward-compatible string list + separate group_names map
    - existing group links can be labeled without changing the URL

    V1.1 changes:
    - a category may use MULTIPLE FB share accounts
    - old singular `fb_share_account` configs migrate automatically
    - Astrology supports DYNAMIC production rules instead of one fixed daily_limit
    - no existing config is deleted or reset
    """

    KEY_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{1,48}$")

    def __init__(self, project_root: str | Path = "."):
        self.root = Path(project_root).resolve()
        self.config_dir = self.root / "config"
        self.backup_dir = self.root / "state" / "tt_settings_backup"
        self.accounts_path = self.config_dir / "tt_accounts.json"
        self.categories_path = self.config_dir / "tt_categories.json"
        self.scheduler_path = self.config_dir / "tt_scheduler.json"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self._ensure_files()
        self._migrate_v1_to_v1_1()
        self._migrate_share_group_names()
        self._migrate_v13_scheduler_and_targets()
        self._migrate_v17_rolling_category_schedules()
        self._migrate_v20_page_routes()
        self._migrate_content_category_registry()

    def _ensure_files(self) -> None:
        if not self.accounts_path.exists():
            self._atomic_write(self.accounts_path, {
                "version": 2,
                "facebook_pages": {},
                "tiktok_accounts": {},
                "fb_share_accounts": {},
            }, make_backup=False)
        if not self.categories_path.exists():
            self._atomic_write(self.categories_path, {
                "version": 2,
                "categories": {},
            }, make_backup=False)
        if not self.scheduler_path.exists():
            self._atomic_write(self.scheduler_path, {
                "version": 1,
                "startup_mode": "ask",
                "sequential_queue": True,
                "posting_window": {"start": "09:00", "end": "21:00"},
            }, make_backup=False)

    @staticmethod
    def _read_json(path: Path) -> dict[str, Any]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError("root JSON must be an object")
            return data
        except Exception as exc:
            raise RuntimeError(f"Could not read {path}: {exc}") from exc

    def _backup_file(self, path: Path) -> None:
        if not path.exists(): return
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        shutil.copy2(path, self.backup_dir / f"{path.stem}_{stamp}{path.suffix}")

    def _atomic_write(self, path: Path, data: dict[str, Any], *, make_backup: bool = True) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        if make_backup: self._backup_file(path)
        fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        os.close(fd)
        tmp = Path(tmp_name)
        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            os.replace(tmp, path)
        finally:
            if tmp.exists():
                try: tmp.unlink()
                except Exception: pass

    def _migrate_v1_to_v1_1(self) -> None:
        """Safe in-place migration. Backups are created only if data changes."""
        cats = self._read_json(self.categories_path)
        changed = False
        cats.setdefault("categories", {})

        for key, item in cats["categories"].items():
            # singular -> list
            if "fb_share_accounts" not in item:
                old = str(item.get("fb_share_account") or "").strip()
                item["fb_share_accounts"] = [old] if old else []
                changed = True
            # keep legacy field temporarily for old code, but list is source of truth
            if "fb_share_account" not in item:
                item["fb_share_account"] = ""
                changed = True

            # Production mode defaults
            if key == "astrology":
                if item.get("production_mode") != "astrology_dynamic":
                    item["production_mode"] = "astrology_dynamic"
                    changed = True
                if "production_rules" not in item:
                    item["production_rules"] = {
                        "facebook_output_mode": "video_only",
                        "daily": {
                            "weekday_forecast": 1,
                            "pick_one_of_four": 1
                        },
                        "weekly": {
                            "enabled": True,
                            "weekday": "sunday",
                            "weekly_special": 1
                        },
                        "monthly": {
                            "enabled": True,
                            "trigger": "day_30",
                            "monthly_special": 1
                        }
                    }
                    changed = True
                else:
                    rules=item.get("production_rules") or {}
                    if rules.get("facebook_output_mode") not in {"video_only","mixed"}:
                        rules["facebook_output_mode"]="video_only"; changed=True
                    monthly=rules.setdefault("monthly",{})
                    if monthly.get("trigger") != "day_30":
                        monthly["trigger"]="day_30"; changed=True
                    item["production_rules"]=rules
                # 0 means do not use a fixed cap for dynamic astrology
                if item.get("daily_limit") != 0:
                    item["daily_limit"] = 0
                    changed = True
            else:
                if "production_mode" not in item:
                    item["production_mode"] = "fixed_daily"
                    changed = True

        if cats.get("version", 1) < 2:
            cats["version"] = 2
            changed = True
        if changed:
            self._atomic_write(self.categories_path, cats)
            print("🔄 TT settings auto-migrated to V1.1 (multi-share + dynamic astrology).")

    def _migrate_share_group_names(self) -> None:
        """Add a URL->display-name map without changing the legacy URL list."""
        data = self._read_json(self.accounts_path)
        data.setdefault("fb_share_accounts", {})
        changed = False
        for _, item in data["fb_share_accounts"].items():
            if "group_names" not in item or not isinstance(item.get("group_names"), dict):
                item["group_names"] = {}
                changed = True
            # Remove name entries for URLs no longer present. Keep only valid strings.
            groups = [str(x).strip() for x in (item.get("groups") or []) if str(x).strip()]
            names = item.get("group_names") or {}
            clean = {str(url): str(name).strip() for url, name in names.items() if str(url) in groups and str(name).strip()}
            if clean != names:
                item["group_names"] = clean
                changed = True
        if changed:
            self._atomic_write(self.accounts_path, data)
            print("🔄 TT share groups upgraded: group display names enabled.")

    def _migrate_v13_scheduler_and_targets(self) -> None:
        """Add adaptive catch-up defaults and lock the current Recap target at 6/day."""
        sch = self._read_json(self.scheduler_path)
        changed = False
        if "adaptive_catchup" not in sch or not isinstance(sch.get("adaptive_catchup"), dict):
            sch["adaptive_catchup"] = {
                "enabled": True,
                "nominal_gap_minutes": 120,
                "minimum_gap_minutes": 90,
                "first_post_delay_minutes": 5,
                "end_buffer_minutes": 10,
                "jitter_minutes": 6,
                "late_policy": "respect_min_gap"
            }
            changed = True
        if changed:
            self._atomic_write(self.scheduler_path, sch)
            print("🔄 TT scheduler upgraded: adaptive late-start spacing enabled.")

        cats = self._read_json(self.categories_path)
        recap = (cats.get("categories") or {}).get("recap")
        if isinstance(recap, dict) and recap.get("production_mode", "fixed_daily") == "fixed_daily":
            if int(recap.get("daily_limit") or 0) <= 0:
                recap["daily_limit"] = 6
                self._atomic_write(self.categories_path, cats)
                print("🔄 Recap production target set to 6/day.")

    def _migrate_v17_rolling_category_schedules(self) -> None:
        """Add category-specific timing windows without overwriting existing routes/counts."""
        defaults = {
            "recap": {"earliest_start":"09:00","latest_finish":"20:50","preferred_gap_minutes":120,"minimum_gap_minutes":90,"estimated_runtime_minutes":25,"priority":50,"prefer_preferred_windows":False,"preferred_windows_only":False,"preferred_windows":[]},
            "drama": {"earliest_start":"12:00","latest_finish":"20:50","preferred_gap_minutes":180,"minimum_gap_minutes":120,"estimated_runtime_minutes":22,"priority":55,"prefer_preferred_windows":False,"preferred_windows_only":False,"preferred_windows":[]},
            "astrology": {"earliest_start":"09:00","latest_finish":"20:50","preferred_gap_minutes":180,"minimum_gap_minutes":120,"estimated_runtime_minutes":15,"priority":50,"prefer_preferred_windows":False,"preferred_windows_only":False,"preferred_windows":[]},
            "story_animation": {"earliest_start":"12:00","latest_finish":"20:50","preferred_gap_minutes":180,"minimum_gap_minutes":120,"estimated_runtime_minutes":20,"priority":50,"prefer_preferred_windows":False,"preferred_windows_only":False,"preferred_windows":[]},
        }
        cats=self._read_json(self.categories_path);changed=False
        for key,item in (cats.get("categories") or {}).items():
            base=defaults.get(key,{"earliest_start":"09:00","latest_finish":"20:50","preferred_gap_minutes":120,"minimum_gap_minutes":90,"estimated_runtime_minutes":20,"priority":50,"prefer_preferred_windows":False,"preferred_windows_only":False,"preferred_windows":[]})
            current=item.get("schedule_policy") if isinstance(item.get("schedule_policy"),dict) else {}
            merged=dict(base);merged.update(current)
            if merged!=current:item["schedule_policy"]=merged;changed=True
        if changed:
            self._atomic_write(self.categories_path,cats)
            print("🔄 TT categories upgraded: per-category timing windows enabled.")
        sch=self._read_json(self.scheduler_path);r=sch.get("rolling_realtime") if isinstance(sch.get("rolling_realtime"),dict) else {}
        merged={"enabled":True,"decision_interval_seconds":5,"inter_job_buffer_minutes":2,"failure_cooldown_minutes":30,"pending_retry_cooldown_minutes":5,"no_work_retry_minutes":45,"max_failure_cooldown_minutes":120};merged.update(r)
        if merged!=r:
            sch["rolling_realtime"]=merged;self._atomic_write(self.scheduler_path,sch)
            print("🔄 TT scheduler upgraded: rolling real-time decisions enabled.")

    def _read_url_lines(self, path: Path) -> list[str]:
        try:
            if not path.exists():
                return []
            out=[]
            for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
                line=raw.strip()
                if not line or line.startswith("#"):
                    continue
                # Legacy source files sometimes append a human note after whitespace.
                url=line.split()[0].strip()
                if url.startswith(("http://","https://")) and url not in out:
                    out.append(url)
            return out
        except Exception:
            return []

    def _migrate_v20_page_routes(self) -> None:
        """Non-destructive migration from one route/category to many page routes.

        Old top-level fields stay in place for legacy bridges.  A `routes.default`
        copy is added once and becomes the V2 Web/Master source of truth.  Existing
        account/page/share settings are never cleared or reassigned.
        """
        cats=self._read_json(self.categories_path); changed=False
        recap_sources=[]
        try:
            recap_cfg=self._read_json(self.config_dir/'recap_pages.json')
            pages=recap_cfg.get('pages') or []
            if pages:
                source_file=str((pages[0] or {}).get('source_file') or '').strip()
                if source_file:
                    source_path=Path(source_file)
                    if not source_path.is_absolute(): source_path=self.root/source_path
                    recap_sources=self._read_url_lines(source_path)
        except Exception:
            pass
        motion_cfg={}
        try:
            motion_cfg=self._read_json(self.config_dir/'story_motion_pipeline.json')
        except Exception:
            motion_cfg={}
        for key,item in (cats.get('categories') or {}).items():
            routes=item.get('routes')
            if isinstance(routes,dict) and routes:
                continue
            policy=dict(item.get('schedule_policy') or {})
            content_type={
                'recap':'movie', 'drama':'story_board', 'story_motion':'horror_thriller',
                'astrology':'astrology', 'story_animation':'story_animation'
            }.get(key,key)
            route={
                'label':'Default',
                'enabled':True,
                'content_type':content_type,
                'output_type':'motion' if key=='story_motion' else ('carousel' if key in {'drama','astrology'} else 'video'),
                'language': str(motion_cfg.get('language') or 'mm') if key=='story_motion' else 'mm',
                'genre_mode': str(motion_cfg.get('genre_mode') or 'alternate') if key=='story_motion' else '',
                'fixed_genre': str(motion_cfg.get('fixed_genre') or 'horror') if key=='story_motion' else '',
                'content_group':'main',
                'daily_limit':max(0,int(item.get('daily_limit') or 0)),
                'facebook_page':str(item.get('facebook_page') or ''),
                'tiktok_account':str(item.get('tiktok_account') or ''),
                'fb_share_accounts':list(item.get('fb_share_accounts') or ([item.get('fb_share_account')] if item.get('fb_share_account') else [])),
                'share_enabled':bool(item.get('share_enabled',True)),
                'branding':TTRouteBrandingService.normalize_config({}),
                'source_urls':list(recap_sources) if key=='recap' else [],
                'schedule_policy':{
                    'earliest_start':str(policy.get('earliest_start') or '09:00'),
                    'latest_finish':str(policy.get('latest_finish') or '20:50'),
                    # Old same-category gap becomes the initial SAME-PAGE gap.
                    'page_gap_minutes':max(0,int(policy.get('preferred_gap_minutes') or 120)),
                    'route_spacing_minutes':max(0,int(policy.get('minimum_gap_minutes') or 30)),
                    'estimated_runtime_minutes':max(1,int(policy.get('estimated_runtime_minutes') or 20)),
                    'priority':int(policy.get('priority') or 50),
                },
            }
            item['routes']={'default':route}
            changed=True
        if cats.get('version',2)<3:
            cats['version']=3; changed=True
        if changed:
            self._atomic_write(self.categories_path,cats)
            print('🔄 TT settings V2: page-level routes enabled (legacy category routes preserved).')

    def _migrate_content_category_registry(self) -> None:
        """Register new reusable categories without touching existing route data."""
        data = self._read_json(self.categories_path)
        categories = data.setdefault("categories", {})
        changed = False
        for key, defaults in managed_category_defaults().items():
            if key not in categories:
                categories[key] = defaults
                changed = True
        if int(data.get("version") or 0) < 6:
            data["version"] = 6
            changed = True
        if int(data.get("content_category_registry_version") or 0) < 1:
            data["content_category_registry_version"] = 1
            changed = True
        if changed:
            self._atomic_write(self.categories_path, data)
            print("🔄 TT content-category registry enabled; new categories added OFF by default.")

    def backup_all(self) -> Path:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        folder = self.backup_dir / f"manual_{stamp}"
        folder.mkdir(parents=True, exist_ok=True)
        for p in [self.accounts_path, self.categories_path, self.scheduler_path]:
            if p.exists(): shutil.copy2(p, folder / p.name)
        return folder

    def accounts(self) -> dict[str, Any]:
        data = self._read_json(self.accounts_path)
        data.setdefault("facebook_pages", {})
        data.setdefault("tiktok_accounts", {})
        data.setdefault("fb_share_accounts", {})
        return data

    def categories(self) -> dict[str, Any]:
        data = self._read_json(self.categories_path)
        data.setdefault("categories", {})
        return data

    def scheduler(self) -> dict[str, Any]:
        return self._read_json(self.scheduler_path)

    def normalize_key(self, value: str) -> str:
        key = re.sub(r"[^a-z0-9_-]+", "_", value.strip().lower())
        key = re.sub(r"_+", "_", key).strip("_")
        if len(key) < 2: raise ValueError("Key must contain at least 2 letters/numbers.")
        if not self.KEY_RE.match(key):
            raise ValueError("Key must use lowercase letters, numbers, _ or - and be <= 49 chars.")
        return key

    def unique_key(self, registry_type: str, requested: str) -> str:
        """Return requested normalized key, or append _2/_3/... if it already exists."""
        base = self.normalize_key(requested)
        reg = self.accounts()[registry_type]
        if base not in reg: return base
        i = 2
        while f"{base}_{i}" in reg:
            i += 1
        return f"{base}_{i}"

    def _references(self, registry_type: str, key: str) -> list[str]:
        refs=[]
        for category_key,item in (self.categories().get('categories') or {}).items():
            # Legacy category-level route
            legacy_hit=False
            if registry_type=='facebook_pages': legacy_hit=str(item.get('facebook_page') or '')==key
            elif registry_type=='tiktok_accounts': legacy_hit=str(item.get('tiktok_account') or '')==key
            elif registry_type=='fb_share_accounts':
                vals=list(item.get('fb_share_accounts') or [])
                if item.get('fb_share_account') and item.get('fb_share_account') not in vals: vals.append(item.get('fb_share_account'))
                legacy_hit=key in vals
            if legacy_hit: refs.append(category_key+'/legacy')
            for route_key,route in (item.get('routes') or {}).items():
                hit=False
                if registry_type=='facebook_pages': hit=str(route.get('facebook_page') or '')==key
                elif registry_type=='tiktok_accounts': hit=str(route.get('tiktok_account') or '')==key
                elif registry_type=='fb_share_accounts': hit=key in list(route.get('fb_share_accounts') or [])
                if hit: refs.append(category_key+'/'+route_key)
        return refs

    # ---------- account CRUD ----------
    def add_facebook_page(self, *, key: str, label: str, page_id: str, profile: str, enabled: bool = True, auto_suffix: bool = False,
                          profile_store: str = "browser_sessions") -> str:
        profile_store = validate_profile_store(profile_store)
        profile_path(self.root, profile, profile_store)
        data = self.accounts()
        key = self.unique_key("facebook_pages", key) if auto_suffix else self.normalize_key(key)
        if key in data["facebook_pages"]: raise ValueError(f"Facebook Page key already exists: {key}")
        data["facebook_pages"][key] = {"label": label.strip() or key, "page_id": str(page_id).strip(), "profile": profile.strip(),
                                       "profile_store": profile_store, "enabled": bool(enabled)}
        self._atomic_write(self.accounts_path, data); return key

    def update_facebook_page(self, key: str, **changes: Any) -> None:
        data = self.accounts(); reg = data["facebook_pages"]
        if key not in reg: raise KeyError(key)
        if "profile" in changes or "profile_store" in changes:
            store = validate_profile_store(changes.get("profile_store", reg[key].get("profile_store")))
            profile_path(self.root, changes.get("profile", reg[key].get("profile")), store)
            changes["profile_store"] = store
        for k,v in changes.items():
            if k in {"label","page_id","profile","profile_store","enabled"}: reg[key][k]=v
        self._atomic_write(self.accounts_path, data)

    def add_tiktok_account(self, *, key: str, label: str, profile: str, enabled: bool = True, auto_suffix: bool = False) -> str:
        data = self.accounts()
        key = self.unique_key("tiktok_accounts", key) if auto_suffix else self.normalize_key(key)
        if key in data["tiktok_accounts"]: raise ValueError(f"TikTok account key already exists: {key}")
        data["tiktok_accounts"][key] = {"label": label.strip() or key, "profile": profile.strip(), "enabled": bool(enabled)}
        self._atomic_write(self.accounts_path, data); return key

    def update_tiktok_account(self, key: str, **changes: Any) -> None:
        data = self.accounts(); reg=data["tiktok_accounts"]
        if key not in reg: raise KeyError(key)
        for k,v in changes.items():
            if k in {"label","profile","enabled"}: reg[key][k]=v
        self._atomic_write(self.accounts_path, data)

    def add_share_account(self, *, key: str, label: str, profile: str, enabled: bool = True, auto_suffix: bool = True) -> str:
        data = self.accounts()
        requested = key
        key = self.unique_key("fb_share_accounts", key) if auto_suffix else self.normalize_key(key)
        if key in data["fb_share_accounts"]: raise ValueError(f"FB Share account key already exists: {key}")
        data["fb_share_accounts"][key] = {"label": label.strip() or key, "profile": profile.strip(), "enabled": bool(enabled), "groups": [], "group_names": {}}
        self._atomic_write(self.accounts_path, data)
        if self.normalize_key(requested) != key:
            print(f"ℹ️ Share key already existed. Saved new account as: {key}")
        return key

    def update_share_account(self, key: str, **changes: Any) -> None:
        data=self.accounts(); reg=data["fb_share_accounts"]
        if key not in reg: raise KeyError(key)
        for k,v in changes.items():
            if k in {"label","profile","enabled","groups","group_names"}: reg[key][k]=v
        self._atomic_write(self.accounts_path, data)

    def remove_account(self, registry_type: str, key: str) -> None:
        refs=self._references(registry_type,key)
        if refs: raise RuntimeError(f"Cannot remove {key}; assigned to categories: {', '.join(refs)}")
        data=self.accounts(); reg=data[registry_type]
        if key not in reg: raise KeyError(key)
        del reg[key]; self._atomic_write(self.accounts_path,data)

    # ---------- categories ----------
    def add_category(self, *, key: str, label: str, daily_limit: int = 0, enabled: bool = True) -> str:
        key=self.normalize_key(key); data=self.categories()
        if key in data["categories"]: raise ValueError(f"Category already exists: {key}")
        data["categories"][key]={
            "label": label.strip() or key,
            "enabled": bool(enabled),
            "daily_limit": max(0,int(daily_limit)),
            "production_mode": "fixed_daily",
            "facebook_page":"",
            "tiktok_account":"",
            "fb_share_accounts":[],
            "fb_share_account":"",
            "share_enabled":True,
        }
        self._atomic_write(self.categories_path,data); return key

    def update_category(self,key:str,**changes:Any)->None:
        data=self.categories(); reg=data["categories"]
        if key not in reg: raise KeyError(key)
        if changes.get('enabled') is True:
            definition = content_category(key) or {}
            minimum_sources = max(0, int(definition.get('minimum_configured_sources') or 0))
            if minimum_sources:
                enabled_routes = [
                    route for route in (reg[key].get('routes') or {}).values()
                    if isinstance(route, dict) and route.get('enabled', True)
                ]
                valid_routes = [
                    route for route in enabled_routes
                    if len(active_source_records(route.get('sources') or route.get('source_urls') or [])) >= minimum_sources
                ]
                if not valid_routes:
                    raise ValueError(
                        f"{definition.get('display_name') or key} requires an enabled route with at least "
                        f"{minimum_sources} enabled source links before the category can be enabled"
                    )
        allowed={"label","enabled","daily_limit","production_mode","production_rules","facebook_page","tiktok_account","fb_share_accounts","share_enabled","schedule_policy","content_categories"}
        for k,v in changes.items():
            if k in allowed: reg[key][k]=v
        self._atomic_write(self.categories_path,data)

    def remove_category(self,key:str)->None:
        data=self.categories(); reg=data["categories"]
        if key not in reg: raise KeyError(key)
        del reg[key]; self._atomic_write(self.categories_path,data)

    def assign_route(self, category_key:str, *, facebook_page:str|None=None, tiktok_account:str|None=None, fb_share_accounts:list[str]|None=None, share_enabled:bool|None=None)->None:
        acc=self.accounts(); cats=self.categories(); reg=cats["categories"]
        if category_key not in reg: raise KeyError(f"Unknown category: {category_key}")
        item=reg[category_key]
        if facebook_page is not None:
            if facebook_page and facebook_page not in acc["facebook_pages"]: raise KeyError(f"Unknown Facebook Page: {facebook_page}")
            item["facebook_page"]=facebook_page
        if tiktok_account is not None:
            if tiktok_account and tiktok_account not in acc["tiktok_accounts"]: raise KeyError(f"Unknown TikTok account: {tiktok_account}")
            item["tiktok_account"]=tiktok_account
        if fb_share_accounts is not None:
            clean=[]
            for key in fb_share_accounts:
                if key not in acc["fb_share_accounts"]: raise KeyError(f"Unknown FB Share account: {key}")
                if key not in clean: clean.append(key)
            item["fb_share_accounts"]=clean
            item["fb_share_account"] = clean[0] if clean else ""  # legacy compatibility
        if share_enabled is not None: item["share_enabled"]=bool(share_enabled)
        self._atomic_write(self.categories_path,cats)

    def set_astrology_rules(self, *, weekday_forecast:int=1, pick_one_of_four:int=1, weekly_enabled:bool=True, weekly_weekday:str="sunday", weekly_special:int=1, monthly_enabled:bool=True, monthly_special:int=1, facebook_output_mode:str="video_only")->None:
        data=self.categories(); cats=data["categories"]
        if "astrology" not in cats: raise KeyError("astrology")
        a=cats["astrology"]
        a["production_mode"]="astrology_dynamic"
        a["daily_limit"]=0
        mode=str(facebook_output_mode or "video_only").strip().lower()
        if mode not in {"video_only","mixed"}: mode="video_only"
        a["production_rules"]={
            "facebook_output_mode":mode,
            "daily":{"weekday_forecast":max(0,int(weekday_forecast)),"pick_one_of_four":max(0,int(pick_one_of_four))},
            "weekly":{"enabled":bool(weekly_enabled),"weekday":weekly_weekday.lower(),"weekly_special":max(0,int(weekly_special))},
            "monthly":{"enabled":bool(monthly_enabled),"trigger":"day_30","monthly_special":max(0,int(monthly_special))}
        }
        self._atomic_write(self.categories_path,data)

    def update_category_schedule(self,key:str,policy:dict[str,Any])->None:
        data=self.categories();cats=data.get("categories",{})
        if key not in cats:raise KeyError(key)
        current=dict(cats[key].get("schedule_policy") or {})
        allowed={"earliest_start","latest_finish","preferred_gap_minutes","minimum_gap_minutes","estimated_runtime_minutes","priority","prefer_preferred_windows","preferred_windows_only","preferred_windows"}
        for k,v in (policy or {}).items():
            if k in allowed:current[k]=v
        cats[key]["schedule_policy"]=current
        self._atomic_write(self.categories_path,data)

    def update_scheduler(self,**changes:Any)->None:
        data=self.scheduler(); data.update(changes); self._atomic_write(self.scheduler_path,data)

    # ---------- V2 page/content routes ----------
    def category_routes(self, category_key: str) -> dict[str, Any]:
        cats=self.categories().get('categories') or {}
        if category_key not in cats: raise KeyError(f"Unknown category: {category_key}")
        routes=cats[category_key].get('routes') or {}
        return copy.deepcopy(routes if isinstance(routes,dict) else {})

    def add_route(self, category_key: str, *, key: str, label: str = "", **values: Any) -> str:
        data=self.categories(); cats=data.get('categories') or {}
        if category_key not in cats: raise KeyError(f"Unknown category: {category_key}")
        route_key=self.normalize_key(key)
        routes=cats[category_key].setdefault('routes',{})
        if route_key in routes: raise ValueError(f"Route already exists: {category_key}/{route_key}")
        requested_type = str(values.get('content_type') or category_key or 'default').strip()
        definition = content_category(requested_type) or content_category(category_key) or {}
        route={
            'label':str(label or route_key).strip(), 'enabled':bool(values.get('enabled',True)),
            'content_type':requested_type,
            'output_type':str(values.get('output_type') or definition.get('default_output') or 'video').strip(),
            'language':str(values.get('language') or 'mm').strip().lower(),
            'genre_mode':str(values.get('genre_mode') or '').strip().lower(),
            'fixed_genre':str(values.get('fixed_genre') or '').strip().lower(),
            'content_group':str(values.get('content_group') or 'main').strip() or 'main',
            'novel_genre':str(values.get('novel_genre') or '').strip(),
            'novel_story_seed':str(values.get('novel_story_seed') or '').strip(),
            'novel_publish_start_date':str(values.get('novel_publish_start_date') or '').strip(),
            'novel_long_text_enabled':bool(values.get('novel_long_text_enabled',True)),
            'novel_screenshot_pages_enabled':bool(values.get('novel_screenshot_pages_enabled',False)),
            'lts_category':str(values.get('lts_category') or values.get('content_type') or 'motivation').strip().lower(),
            'daily_limit':max(0,int(values.get('daily_limit') or 0)),
            'facebook_page':'', 'tiktok_account':'', 'fb_share_accounts':[],
            'share_enabled':bool(values.get('share_enabled',True)),
            'branding':TTRouteBrandingService.normalize_config(values.get('branding')),
            'sources':[], 'source_urls':[], 'episode_hashtags':[], 'schedule_policy':{},
        }
        routes[route_key]=route
        self._atomic_write(self.categories_path,data)
        self.update_route(category_key,route_key,**values)
        return route_key

    def _share_account_page_owners(self, *, exclude_category: str = "", exclude_route: str = "") -> dict[str, set[str]]:
        """Return share-account -> FB Page keys used by active routes.

        One share account may serve multiple routes for the SAME Facebook Page, but
        must not be shared across different Facebook Pages. This keeps group-share
        load isolated per Page and reduces accidental spam bursts.
        """
        owners: dict[str, set[str]] = {}
        cats = self.categories().get('categories') or {}
        for ck, cat in cats.items():
            for rk, route in (cat.get('routes') or {}).items():
                if ck == exclude_category and rk == exclude_route:
                    continue
                if not isinstance(route, dict) or not route.get('enabled', True):
                    continue
                fb = str(route.get('facebook_page') or '').strip()
                if not fb:
                    continue
                for raw in route.get('fb_share_accounts') or []:
                    sh = str(raw).strip()
                    if sh:
                        owners.setdefault(sh, set()).add(fb)
        return owners

    def _validate_share_page_assignment(self, *, category_key: str, route_key: str, facebook_page: str, share_keys: list[str]) -> None:
        """Route-level share mapping validation.

        V2.3 deliberately does NOT lock a login to one Facebook Page.  Every enabled
        share account remains selectable from every route; the Web Manager shows all
        current route/Page assignments so the operator can distribute load manually.
        The only hard rule is that a route cannot request group sharing without an FB Page.
        """
        if share_keys and not facebook_page:
            raise ValueError('FB Share accounts require a Facebook Page on this route.')

    def update_route(self, category_key: str, route_key: str, **changes: Any) -> None:
        data=self.categories(); cats=data.get('categories') or {}
        if category_key not in cats: raise KeyError(f"Unknown category: {category_key}")
        routes=cats[category_key].setdefault('routes',{})
        if route_key not in routes: raise KeyError(f"Unknown route: {category_key}/{route_key}")
        acc=self.accounts(); route=routes[route_key]
        if category_key == "movie_review" and "movie_review_profile" in changes:
            route["movie_review_profile"] = normalize_profile(changes["movie_review_profile"])
        if 'facebook_page' in changes:
            v=str(changes.get('facebook_page') or '').strip()
            if v and v not in acc['facebook_pages']: raise KeyError(f"Unknown Facebook Page: {v}")
            route['facebook_page']=v
        if 'tiktok_account' in changes:
            v=str(changes.get('tiktok_account') or '').strip()
            if v and v not in acc['tiktok_accounts']: raise KeyError(f"Unknown TikTok account: {v}")
            route['tiktok_account']=v
        if 'fb_share_accounts' in changes:
            clean=[]
            for raw in changes.get('fb_share_accounts') or []:
                v=str(raw).strip()
                if not v: continue
                if v not in acc['fb_share_accounts']: raise KeyError(f"Unknown FB Share account: {v}")
                if v not in clean: clean.append(v)
            route['fb_share_accounts']=clean
        for k in {'label','content_type','output_type','language','genre_mode','fixed_genre','content_group','lts_category','novel_genre','novel_story_seed','novel_publish_start_date'}:
            if k in changes: route[k]=str(changes.get(k) or '').strip()
        if 'enabled' in changes: route['enabled']=bool(changes.get('enabled'))
        if 'share_enabled' in changes: route['share_enabled']=bool(changes.get('share_enabled'))
        if 'branding' in changes:
            current_branding=dict(route.get('branding') or {})
            incoming=dict(changes.get('branding') or {}) if isinstance(changes.get('branding'),dict) else {}
            current_branding.update(incoming)
            expected=(Path('assets')/'route_logos'/str(category_key)/str(route_key)/'logo.png').as_posix()
            requested=str(current_branding.get('logo_path') or '').replace('\\','/').strip()
            if requested and requested!=expected:
                raise ValueError(f'Route logo path must stay isolated under {expected}')
            logo_exists=(self.root/expected).is_file()
            route['branding']=TTRouteBrandingService.normalize_config(
                current_branding,logo_path=expected if logo_exists else ''
            )
        if 'novel_long_text_enabled' in changes: route['novel_long_text_enabled']=bool(changes.get('novel_long_text_enabled'))
        if 'novel_screenshot_pages_enabled' in changes: route['novel_screenshot_pages_enabled']=bool(changes.get('novel_screenshot_pages_enabled'))
        if 'daily_limit' in changes: route['daily_limit']=max(0,int(changes.get('daily_limit') or 0))
        if 'sources' in changes or 'source_urls' in changes:
            incoming = changes.get('sources') if 'sources' in changes else changes.get('source_urls')
            existing_sources = route.get('sources') if 'sources' in route else route.get('source_urls') or []
            records = normalize_source_records(incoming, existing=existing_sources)
            route['sources'] = records
            # Legacy consumers keep receiving a simple URL list, but disabled
            # structured records are deliberately excluded from active work.
            route['source_urls'] = active_source_urls(records)
        if 'episode_hashtags' in changes:
            raw_values=changes.get('episode_hashtags') or []
            if isinstance(raw_values,str): raw_values=re.split(r'[\s,]+',raw_values)
            tags=[]; seen=set()
            for raw in raw_values:
                tag=str(raw or '').strip().lstrip('#')
                tag=''.join(
                    ch for ch in tag
                    if ch.isalnum() or ch=='_' or unicodedata.category(ch).startswith('M')
                )
                if not tag: continue
                normalized=f'#{tag}'; key=normalized.casefold()
                if key not in seen: seen.add(key); tags.append(normalized)
            route['episode_hashtags']=tags
        if 'schedule_policy' in changes:
            current=dict(route.get('schedule_policy') or {})
            # route_spacing_minutes is retained if already present for backwards
            # compatibility, but V2.1 scheduler intentionally ignores it.
            allowed={'earliest_start','latest_finish','page_gap_minutes','route_spacing_minutes','estimated_runtime_minutes','priority'}
            for k,v in dict(changes.get('schedule_policy') or {}).items():
                if k in allowed: current[k]=v
            route['schedule_policy']=current

        # Page-owned group sharing: a share account can be used by many routes only
        # when those routes publish to the SAME Facebook Page.
        self._validate_share_page_assignment(
            category_key=category_key, route_key=route_key,
            facebook_page=str(route.get('facebook_page') or '').strip(),
            share_keys=[str(x).strip() for x in (route.get('fb_share_accounts') or []) if str(x).strip()],
        )
        definition = content_category(str(route.get('content_type') or category_key)) or content_category(category_key) or {}
        minimum_sources = max(0, int(definition.get('minimum_configured_sources') or 0))
        active_sources = active_source_records(route.get('sources') or route.get('source_urls') or [])
        if route.get('enabled', True) and minimum_sources and len(active_sources) < minimum_sources:
            raise ValueError(
                f"{definition.get('display_name') or category_key} requires at least "
                f"{minimum_sources} enabled source links before the route can be enabled"
            )
        # Registered managed categories are operational units. Enabling one of
        # their routes should not leave the invisible parent kill-switch OFF.
        if route.get('enabled', True) and content_category(category_key):
            cats[category_key]['enabled'] = True
        # Legacy compatibility: keep top-level fields synchronized only for the
        # original default route. New routes never overwrite another route.
        if route_key=='default':
            cat=cats[category_key]
            for k in ('facebook_page','tiktok_account','fb_share_accounts','share_enabled'):
                if k in route: cat[k]=copy.deepcopy(route[k])
            cat['fb_share_account']=(route.get('fb_share_accounts') or [''])[0] if route.get('fb_share_accounts') else ''
            if cat.get('production_mode','fixed_daily')!='astrology_dynamic': cat['daily_limit']=max(0,int(route.get('daily_limit') or 0))
        self._atomic_write(self.categories_path,data)

    def upsert_lts_content_category(self, key: str, **changes: Any) -> str:
        data=self.categories(); cats=data.get('categories') or {}
        if 'long_to_short' not in cats: raise KeyError('long_to_short')
        cat=cats['long_to_short']; reg=cat.setdefault('content_categories',{})
        clean=self.normalize_key(key or changes.get('label') or 'category')
        row=reg.setdefault(clean,{})
        row['label']=str(changes.get('label') or row.get('label') or clean).strip()
        row['enabled']=bool(changes.get('enabled',row.get('enabled',True)))
        profile=str(changes.get('selector_profile') or row.get('selector_profile') or clean).strip().lower().replace('-','_')
        row['selector_profile']=profile or 'generic'
        urls=[]
        for raw in changes.get('source_urls',row.get('source_urls') or []) or []:
            v=str(raw).strip()
            if v.startswith(('http://','https://')) and v not in urls: urls.append(v)
        row['source_urls']=urls
        row['min_editorial_score']=max(0.0,min(10.0,float(changes.get('min_editorial_score',row.get('min_editorial_score',8.8)) or 8.8)))
        row['max_candidates_per_source']=max(1,int(changes.get('max_candidates_per_source',row.get('max_candidates_per_source',5)) or 5))
        row['scan_limit']=max(1,int(changes.get('scan_limit',row.get('scan_limit',12)) or 12))
        row['min_source_minutes']=max(0.0,float(changes.get('min_source_minutes',row.get('min_source_minutes',10)) or 10))
        row['prep_buffer_days']=max(1,min(7,int(changes.get('prep_buffer_days',row.get('prep_buffer_days',3)) or 3)))
        self._atomic_write(self.categories_path,data)
        return clean

    def remove_lts_content_category(self, key: str) -> None:
        data=self.categories(); cats=data.get('categories') or {}
        cat=cats.get('long_to_short') or {}; reg=cat.get('content_categories') or {}
        if key not in reg: raise KeyError(f'Unknown Long-to-Short content category: {key}')
        users=[rk for rk,r in (cat.get('routes') or {}).items() if str((r or {}).get('lts_category') or (r or {}).get('content_type') or '')==key]
        if users: raise RuntimeError('Move/remove routes from this Long-to-Short content category first: '+', '.join(users))
        if len(reg)<=1: raise RuntimeError('Long-to-Short must keep at least one content category.')
        del reg[key]; self._atomic_write(self.categories_path,data)

    def remove_route(self, category_key: str, route_key: str) -> None:
        data=self.categories(); cats=data.get('categories') or {}
        routes=(cats.get(category_key) or {}).get('routes') or {}
        if route_key not in routes: raise KeyError(f"Unknown route: {category_key}/{route_key}")
        if len(routes)<=1: raise RuntimeError('A category must keep at least one route. Disable it instead.')
        del routes[route_key]
        self._atomic_write(self.categories_path,data)

    def resolve_route(self, category_key: str, route_key: str='default') -> dict[str,Any]:
        acc=self.accounts(); cats=self.categories().get('categories') or {}
        if category_key not in cats: raise KeyError(f"Unknown category: {category_key}")
        cat=copy.deepcopy(cats[category_key]); routes=cat.get('routes') or {}
        if route_key not in routes:
            if route_key=='default' and not routes:
                return self.resolve_category(category_key)
            raise KeyError(f"Unknown route: {category_key}/{route_key}")
        route=copy.deepcopy(routes[route_key])
        source_value = route.get('sources') if 'sources' in route else route.get('source_urls') or []
        all_sources = normalize_source_records(source_value)
        enabled_sources = active_source_records(all_sources)
        route['sources'] = all_sources
        route['active_sources'] = enabled_sources
        route['source_urls'] = [row['url'] for row in enabled_sources]
        fb_key=str(route.get('facebook_page') or '')
        tt_key=str(route.get('tiktok_account') or '')
        share_keys=list(route.get('fb_share_accounts') or [])
        shares=[]
        for k in share_keys:
            item=copy.deepcopy(acc['fb_share_accounts'].get(k))
            if item is not None: shares.append({'key':k,**item})
        return {
            'category_key':category_key,'route_key':route_key,'category':cat,'route':route,
            'facebook':copy.deepcopy(acc['facebook_pages'].get(fb_key)) if fb_key else None,
            'facebook_key':fb_key,
            'tiktok':copy.deepcopy(acc['tiktok_accounts'].get(tt_key)) if tt_key else None,
            'tiktok_key':tt_key,
            'share_accounts':shares,'share_keys':share_keys,
        }

    def worker_payload(self, category_key: str, route_key: str = 'default') -> dict[str, Any]:
        """Stable JSON contract passed to external category processors."""
        resolved = self.resolve_route(category_key, route_key)
        route = resolved.get('route') or {}
        category_id = str(route.get('content_type') or category_key).strip() or category_key
        definition = content_category(category_id) or content_category(category_key) or {}
        facebook = copy.deepcopy(resolved.get('facebook')) if resolved.get('facebook') else None
        tiktok = copy.deepcopy(resolved.get('tiktok')) if resolved.get('tiktok') else None
        return {
            'schema_version': 1,
            'route_id': f'{category_key}/{route_key}',
            'route_key': route_key,
            'category': category_id,
            'processor': str(definition.get('processor') or category_id),
            'language': str(route.get('language') or 'mm'),
            'daily_target': max(0, int(route.get('daily_limit') or 0)),
            'sources': copy.deepcopy(route.get('active_sources') or []),
            'destinations': {
                'facebook': ({'key': resolved.get('facebook_key'), **facebook} if facebook else None),
                'tiktok': ({'key': resolved.get('tiktok_key'), **tiktok} if tiktok else None),
                'share_accounts': copy.deepcopy(resolved.get('share_accounts') or []),
            },
            'timing': copy.deepcopy(route.get('schedule_policy') or {}),
            'output': {
                'type': str(route.get('output_type') or definition.get('default_output') or 'video'),
                'content_group': str(route.get('content_group') or 'main'),
            },
            'content_identity_contract': {
                'required_result_field': 'content_id',
                'optional_fields': ['source_url', 'canonical_url', 'story_fingerprint', 'published_at'],
                'note': 'TT Master durable completion receipts use content_id; workers may include source identity metadata without a second duplicate database.',
            },
        }

    def resolve_category(self,category_key:str)->dict[str,Any]:
        acc=self.accounts(); cats=self.categories()["categories"]
        if category_key not in cats: raise KeyError(f"Unknown category: {category_key}")
        cat=copy.deepcopy(cats[category_key])
        fb_key=str(cat.get("facebook_page") or "")
        tt_key=str(cat.get("tiktok_account") or "")
        share_keys=list(cat.get("fb_share_accounts") or [])
        if not share_keys:
            legacy=str(cat.get("fb_share_account") or "")
            if legacy: share_keys=[legacy]
        shares=[]
        for k in share_keys:
            item=copy.deepcopy(acc["fb_share_accounts"].get(k))
            if item is not None: shares.append({"key":k, **item})
        return {
            "category_key":category_key,
            "category":cat,
            "facebook":copy.deepcopy(acc["facebook_pages"].get(fb_key)) if fb_key else None,
            "facebook_key":fb_key,
            "tiktok":copy.deepcopy(acc["tiktok_accounts"].get(tt_key)) if tt_key else None,
            "tiktok_key":tt_key,
            "share_accounts":shares,
            "share_keys":share_keys,
        }

    def validate(self)->list[str]:
        issues=[]; acc=self.accounts(); cats=self.categories().get('categories') or {}
        for category_key,item in cats.items():
            for route_key, route in (item.get('routes') or {}).items():
                try:
                    raw_sources = route.get('sources') if 'sources' in route else route.get('source_urls') or []
                    normalize_source_records(raw_sources)
                except Exception as exc:
                    issues.append(f"{category_key}/{route_key}: invalid sources — {exc}")
            if not item.get('enabled',True): continue
            routes=item.get('routes') or {}
            if routes:
                for route_key,route in routes.items():
                    if not route.get('enabled',True): continue
                    fb=str(route.get('facebook_page') or ''); tt=str(route.get('tiktok_account') or '')
                    if fb and fb not in acc['facebook_pages']: issues.append(f"{category_key}/{route_key}: missing Facebook Page '{fb}'")
                    if tt and tt not in acc['tiktok_accounts']: issues.append(f"{category_key}/{route_key}: missing TikTok account '{tt}'")
                    for sh in route.get('fb_share_accounts') or []:
                        if sh not in acc['fb_share_accounts']: issues.append(f"{category_key}/{route_key}: missing FB Share account '{sh}'")
                    if route.get('fb_share_accounts') and not fb:
                        issues.append(f"{category_key}/{route_key}: share accounts selected but no Facebook Page assigned")
            else:
                fb=str(item.get('facebook_page') or ''); tt=str(item.get('tiktok_account') or '')
                if fb and fb not in acc['facebook_pages']: issues.append(f"{category_key}: missing Facebook Page '{fb}'")
                if tt and tt not in acc['tiktok_accounts']: issues.append(f"{category_key}: missing TikTok account '{tt}'")
        return issues

    def categories_snapshot(self) -> dict[str, Any]:
        """UI/read API view with legacy URL lists expanded into source records."""
        data = copy.deepcopy(self.categories())
        for _, category in (data.get('categories') or {}).items():
            for _, route in (category.get('routes') or {}).items():
                raw_sources = route.get('sources') if 'sources' in route else route.get('source_urls') or []
                try:
                    records = normalize_source_records(raw_sources)
                    route['sources'] = records
                    route['active_sources'] = active_source_records(records)
                    route['source_urls'] = [row['url'] for row in route['active_sources']]
                except Exception as exc:
                    route['sources'] = []
                    route['active_sources'] = []
                    route['source_error'] = str(exc)
        return data

    def full_snapshot(self)->dict[str,Any]:
        return {
            "accounts": self.accounts(),
            "categories": self.categories_snapshot(),
            "content_category_registry": registry_snapshot(),
            "scheduler": self.scheduler(),
            "issues": self.validate(),
        }
