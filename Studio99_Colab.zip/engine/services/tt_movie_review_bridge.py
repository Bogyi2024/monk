from __future__ import annotations

import asyncio
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from services.tt_route_branding_service import TTRouteBrandingService
from movie_review_profiles import normalize_profile, accepts_genres


class TTMovieReviewBridge:
    """Generate once, then independently receipt FB post, FB Reel and TikTok Reel."""

    ALL_DESTINATIONS = {"facebook_post", "facebook_reel", "tiktok_reel"}

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings = settings_service
        self.root = Path(project_root).resolve()
        self.branding = TTRouteBrandingService(self.root)
        self.movie_root = (self.root.parent / "movie_review").resolve()
        self.registry_path = self.movie_root / "state" / "processed_movies.json"

    @classmethod
    def capability(cls, project_root: str | Path) -> dict[str, Any]:
        movie_root = Path(project_root).resolve().parent / "movie_review"
        required = [movie_root / "main.py", movie_root / "app" / "pipeline.py"]
        live = all(path.exists() for path in required)
        return {"live": live, "label": "LIVE" if live else "Movie Review project missing"}

    def _load_registry(self) -> dict[str, Any]:
        try:
            data = json.loads(self.registry_path.read_text(encoding="utf-8-sig"))
            if isinstance(data, dict):
                data.setdefault("version", 1)
                data.setdefault("movies", {})
                return data
        except Exception:
            pass
        return {"version": 1, "movies": {}}

    def _save_registry(self, data: dict[str, Any]) -> None:
        self.registry_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.registry_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, self.registry_path)

    def _pending_item(self, required_destinations: set[str], *, profile: str = "movie_general", route_key: str = "") -> tuple[str, dict[str, Any]] | None:
        data = self._load_registry()
        rows = data.get("movies") or {}
        candidates: list[tuple[str, dict[str, Any]]] = []
        changed = False
        for key, row in rows.items():
            if not isinstance(row, dict) or row.get("status") not in {"generated", "posted"}:
                continue
            # A completed movie keeps the destination contract it completed with.
            # Adding a TikTok account later must not reopen and repost old movies.
            if row.get("status") == "posted":
                continue
            manifest_path = Path(str(row.get("manifest") or ""))
            if not manifest_path.exists():
                continue
            try:
                manifest_header = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
            except (OSError, json.JSONDecodeError):
                # A temporarily unreadable current manifest should surface through
                # _read_manifest rather than being silently discarded here.
                manifest_header = None
            if isinstance(manifest_header, dict) and int(manifest_header.get("schema_version") or 0) < 2:
                row["status"] = "invalidated"
                row["invalidated_at"] = datetime.now(timezone.utc).isoformat()
                row["invalidation_reason"] = "legacy manifest is not TT-ready (schema_version < 2)"
                changed = True
                print(f"[Movie Review] legacy non-TT manifest skipped: {manifest_path}")
                continue
            if isinstance(manifest_header, dict):
                owner = str(manifest_header.get("tt_route_key") or "")
                if owner and route_key and owner != route_key:
                    continue
                artifact_profile = normalize_profile(manifest_header.get("movie_review_profile"))
                if artifact_profile != normalize_profile(profile):
                    continue
                if not accepts_genres(profile, manifest_header.get("movie_genres") or []):
                    continue
            contract = set(required_destinations)
            desired_contract = sorted(contract)
            if row.get("required_destinations") != desired_contract:
                row["required_destinations"] = desired_contract
                changed = True
            done = set((row.get("destinations") or {}).keys())
            if not contract.issubset(done):
                candidates.append((str(key), row))
            else:
                row["status"] = "posted"
                row["posted_at"] = row.get("posted_at") or datetime.now(timezone.utc).isoformat()
                changed = True
        if changed:
            self._save_registry(data)
        candidates.sort(key=lambda item: str(item[1].get("generated_at") or ""))
        return candidates[0] if candidates else None

    def _receipt(
        self,
        key: str,
        destination: str,
        detail: dict[str, Any],
        required_destinations: set[str],
    ) -> bool:
        data = self._load_registry()
        row = (data.get("movies") or {}).get(key)
        if not isinstance(row, dict):
            return False
        row["required_destinations"] = sorted(required_destinations)
        destinations = row.setdefault("destinations", {})
        is_new = destination not in destinations
        destinations[destination] = {
            "completed_at": datetime.now(timezone.utc).isoformat(),
            **detail,
        }
        if required_destinations.issubset(destinations):
            row["status"] = "posted"
            row["posted_at"] = datetime.now(timezone.utc).isoformat()
        self._save_registry(data)
        print(f"[Movie Review receipt] {destination} | {row.get('content_id')}")
        return is_new

    @staticmethod
    def _route_source_domains(route: dict[str, Any]) -> list[str]:
        """Return enabled TT Master Movie Review source domains."""
        raw_rows = (
            route.get("active_sources")
            or route.get("sources")
            or route.get("source_urls")
            or []
        )
        urls: list[str] = []
        for row in raw_rows:
            if isinstance(row, dict):
                if row.get("enabled", True) is False:
                    continue
                value = str(row.get("url") or "").strip()
            else:
                value = str(row or "").strip()
            if value:
                urls.append(value)

        from urllib.parse import urlsplit
        domains: list[str] = []
        for value in urls:
            try:
                host = (urlsplit(value).hostname or "").lower().removeprefix("www.")
            except Exception:
                host = ""
            if not host and "://" not in value:
                host = value.lower().removeprefix("www.").strip(" /")
            if host and host not in domains:
                domains.append(host)
        return domains

    def _generator_args(self, route: dict[str, Any]) -> list[str]:
        args = [sys.executable, "-u", str(self.movie_root / "main.py"), "--auto", "--video", "--auto-trailer"]
        args.extend(["--profile", normalize_profile(route.get("movie_review_profile"))])
        if bool(route.get("movie_review_use_fal", True)):
            # FAL is an optional enhancement. A provider policy rejection for one
            # TMDB reference image must fall back to the normal TMDB + Chromium
            # composition instead of aborting the review, Reel, and uploads.
            args.append("--fal")
        return args

    async def _generate(self, route: dict[str, Any]) -> None:
        args = self._generator_args(route)

        # TT Master UI already stores Movie Review source URLs, but the legacy
        # bridge launched the child without passing them.  Export only the
        # normalized domains to this child process; do not mutate the parent env.
        child_env = os.environ.copy()
        # MOVIE_REVIEW_TT_SOURCES_BRIDGE_V1 remains the source transport.
        child_env["MOVIE_REVIEW_PROFILE"] = normalize_profile(route.get("movie_review_profile"))
        child_env["MOVIE_REVIEW_TT_ROUTE_KEY"] = str(route.get("_tt_route_key") or "")
        tt_source_domains = self._route_source_domains(route)
        if tt_source_domains:
            child_env["MOVIE_REVIEW_TT_SOURCE_DOMAINS"] = ";".join(tt_source_domains)
            print(
                "[Movie Review] TT source bridge: "
                f"{len(tt_source_domains)} enabled domain(s) -> "
                + ", ".join(tt_source_domains)
            )
        else:
            child_env.pop("MOVIE_REVIEW_TT_SOURCE_DOMAINS", None)
            print("[Movie Review] TT source bridge: no extra UI sources; using config defaults")

        idle_timeout_seconds = max(
            120.0,
            min(900.0, float(os.getenv("MOVIE_REVIEW_WORKER_IDLE_TIMEOUT_SECONDS", "720"))),
        )
        print("[Movie Review] auto-generation start")
        print(f"[Movie Review] worker idle watchdog: {idle_timeout_seconds:.0f}s")
        proc = await asyncio.create_subprocess_exec(
            *args,
            cwd=str(self.movie_root),
            env=child_env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        assert proc.stdout is not None
        while True:
            try:
                line = await asyncio.wait_for(proc.stdout.readline(), timeout=idle_timeout_seconds)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                raise RuntimeError(
                    f"Movie Review generator produced no output for {idle_timeout_seconds:.0f}s; "
                    "stuck child was terminated for a clean scheduler retry"
                )
            if not line:
                break
            print(line.decode("utf-8", errors="replace").rstrip())
        code = await proc.wait()
        if code:
            raise RuntimeError(f"Movie Review generator exited with code {code}")

    @staticmethod
    def _read_manifest(row: dict[str, Any]) -> dict[str, Any]:
        path = Path(str(row.get("manifest") or ""))
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if int(data.get("schema_version") or 0) < 2:
            raise RuntimeError(f"Movie Review manifest is not TT-ready: {path}")
        return data

    @staticmethod
    def _read_text(path: str) -> str:
        value = Path(path).read_text(encoding="utf-8-sig").strip()
        if not value:
            raise RuntimeError(f"Movie Review caption is empty: {path}")
        return value

    def _cleanup_old_intermediates(self) -> None:
        cutoff = datetime.now().timestamp() - timedelta(hours=24).total_seconds()
        removable_dirs = {"youtube", "scene_frames", "caption_overlays", "video_render", "voiceover_beats"}
        removable_files = {"video_silent.mp4"}
        output = self.movie_root / "output"
        if not output.exists():
            return
        import shutil
        for work in output.iterdir():
            if not work.is_dir() or work.stat().st_mtime > cutoff:
                continue
            manifest = work / "manifest.json"
            if not manifest.exists():
                continue
            for name in removable_dirs:
                path = work / name
                if path.exists() and path.is_dir():
                    shutil.rmtree(path)
            for name in removable_files:
                path = work / name
                if path.exists() and path.is_file():
                    path.unlink()

    async def run_once(self, route_key: str = "default") -> dict[str, Any]:
        resolved = self.settings.resolve_route("movie_review", route_key)
        category = resolved.get("category") or {}
        route = dict(resolved.get("route") or {})
        route["_tt_route_key"] = route_key
        profile = normalize_profile(route.get("movie_review_profile"))
        if not category.get("enabled", True) or not route.get("enabled", True):
            raise RuntimeError(f"Movie Review route disabled: {route_key}")
        fb = resolved.get("facebook")
        tt = resolved.get("tiktok")
        fb_ready = bool(fb and fb.get("enabled", True))
        tt_ready = bool(tt and tt.get("enabled", True))
        required_destinations: set[str] = set()
        if fb_ready and bool(route.get("facebook_post_enabled", True)):
            required_destinations.add("facebook_post")
        if fb_ready and bool(route.get("facebook_reel_enabled", True)):
            required_destinations.add("facebook_reel")
        if tt_ready and bool(route.get("tiktok_reel_enabled", True)):
            required_destinations.add("tiktok_reel")
        if not required_destinations:
            raise RuntimeError("Movie Review requires at least one connected and enabled Facebook or TikTok destination")
        print(f"[Movie Review] active destinations: {', '.join(sorted(required_destinations))}")

        self._cleanup_old_intermediates()
        pending = self._pending_item(required_destinations, profile=profile, route_key=route_key)
        if pending is None:
            await self._generate(route)
            pending = self._pending_item(required_destinations, profile=profile, route_key=route_key)
        if pending is None:
            return {"success": True, "new_content_count": 0, "no_work": True, "failure_kind": "no_new_content"}

        key, row = pending
        manifest = self._read_manifest(row)
        destinations = manifest.get("destinations") or {}
        state_done = set((row.get("destinations") or {}).keys())
        content_id = str(manifest.get("content_id") or row.get("content_id") or key)
        primary_this_run: list[str] = []

        fb_post = destinations.get("facebook_post") or {}
        if "facebook_post" in required_destinations and "facebook_post" not in state_done:
            from services.story_carousel_upload_service import upload_facebook_story_carousel
            branded_image = await asyncio.to_thread(
                self.branding.brand_image, str(fb_post.get("image") or ""),
                "movie_review", route_key, route.get("branding") or {}, "facebook_post",
            )
            detail = await upload_facebook_story_carousel(
                [branded_image],
                self._read_text(str(fb_post.get("text") or "")),
                profile_name=str(fb.get("profile") or "Main_FB_Account"),
                page_id=str(fb.get("page_id") or ""),
                headless=False,
                return_detail=True,
                capture_permalink=True,
            )
            if not (detail or {}).get("success"):
                return {"success": False, "new_content_count": 0, "pending": True, "content_id": content_id, "failure_kind": "facebook_post_pending"}
            self._receipt(key, "facebook_post", {"post_link": str((detail or {}).get("post_link") or "")}, required_destinations)
            primary_this_run.append("facebook_post")

        fb_reel = destinations.get("facebook_reel") or {}
        if "facebook_reel" in required_destinations and "facebook_reel" not in state_done:
            from services.browser_service import BrowserService
            branded_video = await asyncio.to_thread(
                self.branding.brand_video, str(fb_reel.get("video") or ""),
                "movie_review", route_key, route.get("branding") or {}, "facebook_reel",
            )
            outcome = await BrowserService().upload_reel_stealth(
                profile_name=str(fb.get("profile") or "Main_FB_Account"),
                page_id=str(fb.get("page_id") or ""),
                caption=self._read_text(str(fb_reel.get("caption") or "")),
                video_path=branded_video,
                page_name_hint=str(fb.get("label") or ""),
                capture_permalink=True,
            )
            if not (outcome or {}).get("success"):
                return {"success": False, "new_content_count": 0, "pending": True, "content_id": content_id, "failure_kind": "facebook_reel_pending"}
            self._receipt(key, "facebook_reel", {"post_link": str((outcome or {}).get("post_link") or "")}, required_destinations)
            primary_this_run.append("facebook_reel")

        tt_reel = destinations.get("tiktok_reel") or {}
        if "tiktok_reel" in required_destinations and "tiktok_reel" not in state_done:
            from services.tt_service import upload_to_tiktok
            branded_video = await asyncio.to_thread(
                self.branding.brand_video, str(tt_reel.get("video") or ""),
                "movie_review", route_key, route.get("branding") or {}, "tiktok_reel",
            )
            ok = await upload_to_tiktok(
                profile_folder_name=str(tt.get("profile") or ""),
                video_path=branded_video,
                caption_text=self._read_text(str(tt_reel.get("caption") or "")),
                headless=False,
            )
            if not ok:
                return {"success": False, "new_content_count": 0, "pending": True, "content_id": content_id, "failure_kind": "tiktok_reel_pending"}
            self._receipt(key, "tiktok_reel", {}, required_destinations)
            primary_this_run.append("tiktok_reel")

        final_row = (self._load_registry().get("movies") or {}).get(key) or {}
        complete = required_destinations.issubset((final_row.get("destinations") or {}).keys())
        return {
            "success": bool(complete),
            "new_content_count": 1 if complete and primary_this_run else 0,
            "content_id": content_id,
            "route_key": route_key,
            "primary_completed_this_run": primary_this_run,
            "cleanup_assets": [str(Path(row['manifest']).parent)],
            "pending": not complete,
            "failure_kind": "" if complete else "pending_destination_retry",
        }
