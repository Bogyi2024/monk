from __future__ import annotations

import os
import shutil
import subprocess
import wave
from pathlib import Path
from typing import Any, Sequence

from services.gemini_tts_pool_service import GeminiFreeTTSPoolService


class GeminiStoryTTSService:
    """
    Gemini TTS wrapper for Story Board Drama V2.

    KEY CHANGE:
    - The whole 7-scene story is generated in ONE TTS request.
    - One female voice identity is kept across the entire story.
    - Scene emotion changes are delivery changes only; no character/voice switching.
    """

    def __init__(self, config: dict[str, Any] | None = None):
        self.config = config or {}

        self.model = str(
            self.config.get("tts_model")
            or os.getenv("STORY_TTS_MODEL")
            or "gemini-3.1-flash-tts-preview"
        )

        # Sulafat is the default female voice for Drama V2.1.
        self.voice = str(
            self.config.get("tts_voice")
            or os.getenv("STORY_TTS_VOICE")
            or "Sulafat"
        )

        self.sample_rate = int(self.config.get("tts_sample_rate", 24000))
        self.tts_pool = GeminiFreeTTSPoolService(self.config)

        self.ffprobe = self._resolve_binary(
            os.getenv("FFPROBE_PATH"),
            r"C:\ffmpeg\bin\ffprobe.exe",
            "ffprobe",
        )

    @staticmethod
    def _resolve_binary(*candidates: str | None) -> str:
        executable = str(candidates[-1])
        for c in candidates[:-1]:
            if c and os.path.isfile(c):
                return os.path.abspath(c)
        found = shutil.which(executable)
        if found:
            return found
        raise FileNotFoundError(f"{executable} not found")

    def _write_wav(self, path: Path, pcm: bytes) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        if pcm[:4] == b"RIFF":
            path.write_bytes(pcm)
            return
        with wave.open(str(path), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(self.sample_rate)
            wf.writeframes(pcm)

    def duration(self, path: str | Path) -> float:
        result = subprocess.run(
            [
                self.ffprobe,
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                str(Path(path).resolve()),
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr[-2000:])
        return float(result.stdout.strip())

    @staticmethod
    def _clean_text(value: str) -> str:
        return " ".join(str(value or "").split()).strip()

    def synthesize_story(
        self,
        *,
        scenes: Sequence[dict[str, Any]],
        output_path: str | Path,
        voice_direction: str = "",
    ) -> dict[str, Any]:
        """
        Generate the ENTIRE story in one call to maximize narrator identity consistency.

        The transcript contains exactly one paragraph per scene. We instruct the model
        to make a clearly longer silent pause between paragraphs so scene boundaries
        can be detected later without changing the speaker.
        """
        cleaned_scenes: list[dict[str, str]] = []
        for idx, scene in enumerate(scenes, 1):
            text = self._clean_text(scene.get("narration", ""))
            if not text:
                raise ValueError(f"TTS scene {idx} narration is empty")
            cleaned_scenes.append(
                {
                    "text": text,
                    "emotion": self._clean_text(scene.get("emotion", "serious")),
                }
            )

        if not cleaned_scenes:
            raise ValueError("No narration scenes for TTS")

        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)

        emotion_map = "\n".join(
            f"- Paragraph {i}: {item['emotion'] or 'serious'}"
            for i, item in enumerate(cleaned_scenes, 1)
        )
        # Gemini 3.1 audio tags: keep them intentionally conservative.
        # We use [neutral] at the beginning to stabilize identity and [short pause]
        # only between scenes. Emotional acting remains mostly in the director prompt
        # so voice timbre does not jump scene-to-scene.
        transcript_parts = []
        for idx, item in enumerate(cleaned_scenes):
            prefix = "[neutral] " if idx == 0 else ""
            transcript_parts.append(prefix + item["text"])
        transcript = " [short pause] ".join(transcript_parts)

        extra = self._clean_text(voice_direction)
        pause_min = max(0.45, float(self.config.get('scene_pause_min_seconds', 0.55)))
        pause_max = max(pause_min, float(self.config.get('scene_pause_max_seconds', 0.75)))

        prompt = f"""
AUDIO PROFILE:
Use ONE single adult female Burmese narrator for the ENTIRE recording.
Use the Sulafat voice as a warm adult female Burmese narrator with a clear, centered, broadcast-like tone.
Keep the delivery natural, human and conversational-cinematic, NOT slow, sleepy, breathy, robotic, or over-acted.
Aim for a medium, steady pace. Prioritize very clear Burmese diction, crisp consonants, clean syllable boundaries, and effortless phrasing.
Keep the SAME speaker identity, vocal timbre, accent, perceived age, and register
from the first word to the final word.

CRITICAL VOICE-CONSISTENCY RULES:
- Never switch character voices.
- Never role-play male, child, elderly, or secondary voices.
- Never change narrator identity between paragraphs.
- Emotion may change only through subtle intensity and phrasing; keep pace and timbre stable.
- Do NOT make large pitch/timbre changes between scenes.
- Do NOT sound cheerful, commercial, cartoonish, theatrical, breathy, whispered, sleepy, or like an advertisement.
- Natural, intelligible Burmese pronunciation is the highest priority; emotional color must never reduce clarity.
- {extra if extra else "Use clear, restrained emotional storytelling at a medium natural pace."}

SCENE DELIVERY MAP:
{emotion_map}

SCENE BOUNDARY RULE:
There are exactly {len(cleaned_scenes)} Burmese story sections below.
Read ONLY the Burmese paragraph text.
At every [short pause] tag, make a clean silent gap around {pause_min:.2f} to {pause_max:.2f} seconds.
Inside a paragraph, keep normal pauses short and natural; avoid drawn-out pauses.
Do not speak tags, numbers, labels, instructions, or scene names.

TRANSCRIPT:
{transcript}
""".strip()

        result = self.tts_pool.synthesize(
            prompt=prompt,
            model=self.model,
            voice=self.voice,
        )
        pcm = result.data

        self._write_wav(output, pcm)
        dur = self.duration(output)
        if dur <= 0.1:
            raise RuntimeError("Gemini TTS output duration invalid")

        print(
            f"🎙️ CONTINUOUS Gemini TTS → {output.name} | {dur:.2f}s | "
            f"ONE voice={self.voice} | scenes={len(cleaned_scenes)} | "
            f"model={self.model} | free_key={result.key_alias}"
        )
        return {
            "path": str(output.resolve()),
            "duration": dur,
            "voice": self.voice,
            "model": self.model,
            "scene_count": len(cleaned_scenes),
            "single_call": True,
        }

    # Kept only for optional voice A/B tests.
    def synthesize(
        self,
        *,
        text: str,
        emotion: str,
        output_path: str | Path,
        voice_direction: str = "",
    ) -> dict[str, Any]:
        return self.synthesize_story(
            scenes=[{"narration": text, "emotion": emotion}],
            output_path=output_path,
            voice_direction=voice_direction,
        )
