from __future__ import annotations

import base64
import os
import re
import time
from dataclasses import dataclass
from typing import Any

from dotenv import load_dotenv
from google import genai
from google.genai import types


@dataclass(frozen=True)
class GeminiTTSResult:
    data: bytes
    mime_type: str
    key_alias: str


@dataclass(frozen=True)
class _TTSKeyEntry:
    alias: str
    env_name: str


class GeminiFreeTTSPoolService:
    """Gemini TTS client pool that can never select a paid/reserve key.

    The pool intentionally accepts only ``GEMINI_TTS_FREE_KEY`` and the existing
    numbered ``GEMINI_IMAGE_PROJECT_<N>_KEY`` variables.  Despite the historical
    ``IMAGE`` part of those names, they are ordinary Gemini Developer API keys;
    actual TTS availability is decided by the model/quota attached to each Google
    project.  ``GEMINI_IMAGE_PAID_KEY``, ``GEMINI_API_KEY`` and ``GOOGLE_API_KEY``
    are never candidates, so a free-tier failure cannot silently become a bill.
    """

    _PROJECT_RE = re.compile(r"^GEMINI_IMAGE_PROJECT_(\d+)_KEY$", re.I)
    _FORBIDDEN = {
        "GEMINI_IMAGE_PAID_KEY",
        "GEMINI_API_KEY",
        "GOOGLE_API_KEY",
    }

    def __init__(self, config: dict[str, Any] | None = None):
        load_dotenv()
        self.config = dict(config or {})
        try:
            timeout_seconds = float(
                self.config.get("tts_request_timeout_seconds", 180) or 180
            )
        except (TypeError, ValueError):
            timeout_seconds = 180.0
        # The Google SDK is synchronous here. Without a transport timeout a dead
        # socket can block TT Master's main worker indefinitely and even prevent
        # Ctrl+C from being handled on Windows.
        self.request_timeout_ms = int(max(30.0, min(600.0, timeout_seconds)) * 1000)
        self.entries = self.discover_env_entries()
        if not self.entries:
            raise RuntimeError(
                "No free Gemini TTS key found. Add GEMINI_TTS_FREE_KEY or "
                "GEMINI_IMAGE_PROJECT_<N>_KEY to .env; paid keys are intentionally disabled."
            )
        self._clients: dict[str, Any] = {}
        self._disabled_for_run: set[str] = set()
        self._active_alias: str | None = None
        print(
            "🔊 Gemini TTS FREE pool: "
            + " → ".join(entry.alias for entry in self.entries)
            + f" | paid fallback=OFF | hard timeout={self.request_timeout_ms // 1000}s/key"
        )

    @classmethod
    def discover_env_entries(cls) -> list[_TTSKeyEntry]:
        ranked: list[tuple[int, _TTSKeyEntry]] = []
        seen_values: set[str] = set()

        dedicated = str(os.getenv("GEMINI_TTS_FREE_KEY") or "").strip()
        if dedicated:
            ranked.append((0, _TTSKeyEntry("tts_free", "GEMINI_TTS_FREE_KEY")))
            seen_values.add(dedicated)

        for env_name, raw_value in os.environ.items():
            match = cls._PROJECT_RE.match(str(env_name))
            value = str(raw_value or "").strip()
            if not match or not value or value in seen_values:
                continue
            number = int(match.group(1))
            ranked.append(
                (1000 + number, _TTSKeyEntry(f"project_{number}", str(env_name)))
            )
            seen_values.add(value)

        ranked.sort(key=lambda item: item[0])
        return [entry for _, entry in ranked]

    def _ordered_entries(self) -> list[_TTSKeyEntry]:
        entries = [e for e in self.entries if e.alias not in self._disabled_for_run]
        if self._active_alias:
            active = next((e for e in entries if e.alias == self._active_alias), None)
            if active is not None:
                entries.remove(active)
                entries.insert(0, active)
        return entries

    def _client_for(self, entry: _TTSKeyEntry):
        client = self._clients.get(entry.alias)
        if client is None:
            key = str(os.getenv(entry.env_name) or "").strip()
            if not key:
                raise RuntimeError(f"{entry.env_name} is empty")
            client = genai.Client(
                api_key=key,
                http_options=types.HttpOptions(timeout=self.request_timeout_ms),
            )
            self._clients[entry.alias] = client
        return client

    @staticmethod
    def _audio_from_response(response: Any) -> tuple[bytes, str]:
        for candidate in (getattr(response, "candidates", None) or []):
            content = getattr(candidate, "content", None)
            for part in (getattr(content, "parts", None) or []):
                inline = getattr(part, "inline_data", None)
                data = getattr(inline, "data", None) if inline is not None else None
                if not data:
                    continue
                if isinstance(data, str):
                    data = base64.b64decode(data)
                raw = bytes(data)
                if len(raw) >= 1000:
                    return raw, str(getattr(inline, "mime_type", None) or "audio/pcm")
        raise RuntimeError("Gemini TTS returned no usable audio payload")

    @staticmethod
    def _safe_error(exc: Exception) -> str:
        # API errors should not contain a key, but strip common URL-key forms as a
        # second line of defence before the message reaches production logs.
        text = str(exc)
        text = re.sub(r"([?&]key=)[^&\s]+", r"\1***", text, flags=re.I)
        return text[-1800:]

    @staticmethod
    def _is_timeout_error(message: str) -> bool:
        text = str(message or "").lower()
        return any(token in text for token in (
            "timeout", "timed out", "readtimeout", "connecttimeout",
            "deadline exceeded", "operation timed out",
        ))

    def synthesize(
        self,
        *,
        prompt: str,
        model: str,
        voice: str,
    ) -> GeminiTTSResult:
        candidates = self._ordered_entries()
        if not candidates:
            raise RuntimeError(
                "All free Gemini TTS project keys are unavailable for this run; "
                "paid fallback is OFF."
            )

        transient_retries = max(
            0, int(self.config.get("tts_free_key_transient_retries", 1) or 0)
        )
        failures: list[str] = []

        for entry in candidates:
            for attempt in range(1, transient_retries + 2):
                try:
                    print(
                        f"🎙️ Gemini TTS → {entry.alias} | model={model} "
                        f"| attempt={attempt}/{transient_retries + 1}"
                    )
                    response = self._client_for(entry).models.generate_content(
                        model=model,
                        contents=prompt,
                        config=types.GenerateContentConfig(
                            response_modalities=["AUDIO"],
                            speech_config=types.SpeechConfig(
                                voice_config=types.VoiceConfig(
                                    prebuilt_voice_config=types.PrebuiltVoiceConfig(
                                        voice_name=voice
                                    )
                                )
                            ),
                        ),
                    )
                    data, mime_type = self._audio_from_response(response)
                    self._active_alias = entry.alias
                    print(f"✅ Gemini TTS FREE ready → {entry.alias}")
                    return GeminiTTSResult(data, mime_type, entry.alias)
                except Exception as exc:
                    safe = self._safe_error(exc)
                    failures.append(f"{entry.alias}: {safe}")
                    if self._is_timeout_error(safe):
                        print(
                            f"⏭️ Gemini TTS {entry.alias} hard timeout — "
                            "skip same-key retry and rotate to next FREE key"
                        )
                        break
                    if attempt <= transient_retries:
                        print(
                            f"⚠️ Gemini TTS {entry.alias} transient retry: {safe}"
                        )
                        time.sleep(min(2 * attempt, 4))

            self._disabled_for_run.add(entry.alias)
            print(f"⏭️ Gemini TTS {entry.alias} unavailable — rotate to next FREE key")

        detail = " | ".join(failures[-len(candidates):])
        raise RuntimeError(
            "Free Gemini TTS pool exhausted; paid fallback is OFF. " + detail
        )
