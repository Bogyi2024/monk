from __future__ import annotations

from typing import Any
from urllib.parse import urlsplit


SOURCE_TYPES = {"website", "facebook", "youtube", "tiktok", "reddit", "unknown"}


def detect_source_type(url: str) -> str:
    try:
        host = (urlsplit(str(url)).hostname or "").lower()
    except Exception:
        return "unknown"
    if host == "facebook.com" or host.endswith(".facebook.com") or host == "fb.watch":
        return "facebook"
    if host == "youtube.com" or host.endswith(".youtube.com") or host == "youtu.be":
        return "youtube"
    if host == "tiktok.com" or host.endswith(".tiktok.com"):
        return "tiktok"
    if host == "reddit.com" or host.endswith(".reddit.com") or host == "redd.it":
        return "reddit"
    return "website" if host else "unknown"


def _rows(raw: Any) -> list[Any]:
    if raw is None:
        return []
    if isinstance(raw, str):
        return [line.strip() for line in raw.splitlines() if line.strip()]
    if isinstance(raw, (list, tuple)):
        return list(raw)
    raise ValueError("Sources must be a list of source records or URLs, or one URL per line.")


def _valid_url(value: Any, index: int) -> str:
    url = str(value or "").strip()
    if not url:
        raise ValueError(f"Source #{index} URL cannot be blank.")
    try:
        parsed = urlsplit(url)
    except Exception as exc:
        raise ValueError(f"Source #{index} URL is invalid: {url}") from exc
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
        raise ValueError(f"Source #{index} must be a complete http:// or https:// URL: {url}")
    return url


def normalize_source_records(raw: Any, *, existing: Any = None) -> list[dict[str, Any]]:
    """Normalize legacy strings/multiline URLs and structured source records.

    URLs are only outer-whitespace-trimmed. Paths, query strings, fragments and
    trailing slashes remain untouched so Facebook Page and non-HTML targets are
    stored without destructive canonicalization.
    """
    old_by_url: dict[str, dict[str, Any]] = {}
    if existing is not None:
        try:
            for row in normalize_source_records(existing):
                old_by_url[row["url"]] = row
        except Exception:
            old_by_url = {}

    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, raw_row in enumerate(_rows(raw), start=1):
        if isinstance(raw_row, str):
            url = _valid_url(raw_row, index)
            row = dict(old_by_url.get(url) or {})
            row["url"] = url
        elif isinstance(raw_row, dict):
            url = _valid_url(raw_row.get("url"), index)
            row = dict(old_by_url.get(url) or {})
            row.update(raw_row)
            row["url"] = url
        else:
            raise ValueError(f"Source #{index} must be a URL string or an object.")

        # Exact duplicates are collapsed without rewriting the surviving URL.
        if url in seen:
            continue
        seen.add(url)

        try:
            priority = int(row.get("priority", 0) or 0)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Source #{index} priority must be a whole number.") from exc
        priority = max(-100000, min(100000, priority))
        requested_type = str(row.get("source_type") or row.get("type") or "").strip().lower()
        source_type = requested_type if requested_type in SOURCE_TYPES else detect_source_type(url)
        normalized.append({
            "name": str(row.get("name") or row.get("label") or "").strip(),
            "url": url,
            "priority": priority,
            "enabled": bool(row.get("enabled", True)),
            "source_type": source_type,
        })
    return normalized


def active_source_records(records: Any) -> list[dict[str, Any]]:
    rows = normalize_source_records(records)
    active = [row for row in rows if row.get("enabled", True)]
    return sorted(active, key=lambda row: -int(row.get("priority") or 0))


def active_source_urls(records: Any) -> list[str]:
    return [row["url"] for row in active_source_records(records)]
