from __future__ import annotations

import json
import os
import re
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

import requests

try:
    from dotenv import load_dotenv
except Exception:  # pragma: no cover
    load_dotenv = None


class TTTelegramNotifyService:
    """Fail-open Telegram notifier + read-only command surface for TT Master."""

    def __init__(self, project_root: str | Path = ".", settings_service=None):
        self.root = Path(project_root).resolve()
        self.settings = settings_service
        if load_dotenv is not None:
            try:
                load_dotenv(self.root / ".env", override=False)
            except Exception:
                pass
        self.token = str(os.getenv("TELEGRAM_BOT_TOKEN") or "").strip()
        self.chat_id = str(os.getenv("TELEGRAM_CHAT_ID") or "").strip()
        raw_enabled = str(os.getenv("TT_TELEGRAM_ENABLED") or "auto").strip().lower()
        self.enabled = bool(self.token and self.chat_id) and raw_enabled not in {"0", "false", "no", "off", "disabled"}
        self.timeout = max(3, int(os.getenv("TT_TELEGRAM_TIMEOUT_SECONDS") or 8))
        self._status_provider: Callable[[], dict[str, Any]] | None = None
        self._state_provider: Callable[[], dict[str, Any]] | None = None
        self._listener_thread: threading.Thread | None = None
        self._listener_stop = threading.Event()
        self._offset = 0
        self._warning_lock = threading.Lock()
        self._warning_state: dict[str, dict[str, Any]] = {}
        # AI generation temporarily changes process-wide proxy environment values.
        # Telegram runs on a separate thread, so it must not inherit that moving
        # target or a Google/FAL proxy window can break getUpdates with ProxyError.
        self._poll_session = requests.Session()
        self._poll_session.trust_env = False
        self._notify_session = requests.Session()
        self._notify_session.trust_env = False
        self._notify_lock = threading.Lock()
        self._outbox_lock = threading.Lock()
        self._outbox_path = self.root / "state" / "tt_telegram_outbox.json"

    def _warn_rate_limited(self,key:str,message:str,*,interval_seconds:float=600.0)->None:
        """Print the first transport warning, then one compact reminder per interval."""
        now=time.monotonic()
        with self._warning_lock:
            state=self._warning_state.setdefault(str(key),{'last':0.0,'suppressed':0})
            elapsed=now-float(state.get('last') or 0.0)
            if state.get('last') and elapsed<float(interval_seconds):
                state['suppressed']=int(state.get('suppressed') or 0)+1
                return
            suppressed=int(state.get('suppressed') or 0)
            state['last']=now;state['suppressed']=0
        suffix=f" (suppressed {suppressed} repeat(s))" if suppressed else ''
        print(message+suffix)

    def _clear_warning(self,key:str)->None:
        with self._warning_lock:
            self._warning_state.pop(str(key),None)

    def _safe_error(self, value: Any, *, limit: int = 900) -> str:
        """Return a compact error message with every Telegram token form removed."""
        text = " ".join(str(value or "unknown error").split())
        if self.token:
            text = text.replace(self.token, "<redacted>")
        text = re.sub(r"/bot[^/\s?]+/", "/bot<redacted>/", text, flags=re.I)
        text = re.sub(
            r"\bbot\d{5,}:[A-Za-z0-9_-]{10,}\b",
            "bot<redacted>",
            text,
            flags=re.I,
        )
        return text[-max(80, int(limit)) :]

    @staticmethod
    def _poll_backoff_seconds(consecutive_failures: int) -> float:
        # Telegram retains incoming updates, so reconnect promptly while still
        # avoiding a hot loop during a real outage: 3, 5, 10, 20, 30, then 60s.
        steps = (3.0, 5.0, 10.0, 20.0, 30.0, 60.0)
        index = min(max(0, int(consecutive_failures) - 1), len(steps) - 1)
        return steps[index]

    @staticmethod
    def _fresh_session() -> requests.Session:
        session = requests.Session()
        session.trust_env = False
        return session

    def _reset_poll_session(self) -> None:
        old = self._poll_session
        self._poll_session = self._fresh_session()
        try:
            old.close()
        except Exception:
            pass

    def _reset_notify_session_locked(self) -> None:
        old = self._notify_session
        self._notify_session = self._fresh_session()
        try:
            old.close()
        except Exception:
            pass

    def _read_outbox_unlocked(self) -> list[dict[str, Any]]:
        try:
            data = json.loads(self._outbox_path.read_text(encoding="utf-8")) if self._outbox_path.exists() else {}
            rows = data.get("messages") if isinstance(data, dict) else []
            return [dict(row) for row in (rows or []) if isinstance(row, dict)]
        except Exception:
            return []

    def _write_outbox_unlocked(self, rows: list[dict[str, Any]]) -> None:
        self._outbox_path.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix="tt_telegram_outbox_", suffix=".tmp", dir=str(self._outbox_path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
                json.dump({"version": 1, "messages": rows[-100:]}, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
            os.replace(name, self._outbox_path)
        finally:
            try:
                if os.path.exists(name):
                    os.remove(name)
            except OSError:
                pass

    def _queue_outbox(self, text: str, show_keyboard: bool, error: str) -> None:
        with self._outbox_lock:
            rows = self._read_outbox_unlocked()
            rows.append({
                "id": f"{time.time_ns()}-{threading.get_ident()}",
                "text": str(text or "")[:4000],
                "show_keyboard": bool(show_keyboard),
                "queued_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                "attempts": 0,
                "last_error": self._safe_error(error, limit=500),
            })
            self._write_outbox_unlocked(rows)

    def _flush_outbox(self, *, limit: int = 5) -> int:
        """Retry durable notifications after polling connectivity recovers."""
        delivered = 0
        with self._outbox_lock:
            rows = self._read_outbox_unlocked()
            remaining: list[dict[str, Any]] = []
            for index, row in enumerate(rows):
                if index >= max(1, int(limit)):
                    remaining.extend(rows[index:])
                    break
                ok = self.send_text(
                    str(row.get("text") or ""),
                    show_keyboard=bool(row.get("show_keyboard", True)),
                    _queue_on_failure=False,
                )
                if ok:
                    delivered += 1
                    continue
                row["attempts"] = int(row.get("attempts") or 0) + 1
                row["last_attempt_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
                remaining.append(row)
                remaining.extend(rows[index + 1 :])
                break
            if delivered or remaining != rows:
                self._write_outbox_unlocked(remaining)
        if delivered:
            print(f"✅ Telegram connection recovered; delivered {delivered} queued message(s).")
        return delivered

    def configure_read_only_commands(
        self,
        *,
        status_provider: Callable[[], dict[str, Any]],
        state_provider: Callable[[], dict[str, Any]],
    ) -> None:
        self._status_provider = status_provider
        self._state_provider = state_provider

    @staticmethod
    def _content_id(result: dict[str, Any]) -> str:
        return str(result.get("content_id") or result.get("story_id") or result.get("video_id") or "").strip()

    @staticmethod
    def _primary_destinations(result: dict[str, Any]) -> str:
        rows = result.get("primary_destinations_completed") or result.get("destinations_completed") or []
        if isinstance(rows, str):
            rows = [rows]
        vals = [str(x).strip() for x in rows if str(x).strip()]
        return ", ".join(vals) if vals else "confirmed primary"

    @staticmethod
    def _fmt_time(value: Any) -> str:
        if not value:
            return "—"
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.astimezone()
            return dt.astimezone().strftime("%I:%M %p")
        except Exception:
            return str(value)

    def _route_context(self, category: str, route_key: str) -> dict[str, str]:
        route_label = str(route_key or "default")
        fb_label = "—"
        tt_label = "—"
        if self.settings is None:
            return {"route_label": route_label, "fb_label": fb_label, "tt_label": tt_label}
        try:
            resolved = self.settings.resolve_route(category, route_key or "default")
            route = resolved.get("route") or {}
            route_label = str(route.get("label") or route_key or "default")
            fb = resolved.get("facebook") or {}
            tt = resolved.get("tiktok") or {}
            fb_label = str(fb.get("label") or resolved.get("facebook_key") or "—")
            tt_label = str(tt.get("label") or resolved.get("tiktok_key") or "—")
        except Exception:
            pass
        return {"route_label": route_label, "fb_label": fb_label, "tt_label": tt_label}

    def _describe_next(self, next_info: dict[str, Any] | None) -> list[str]:
        if not next_info:
            return ["Next: none currently"]
        cat = str(next_info.get("category") or "")
        rk = str(next_info.get("route_key") or "default")
        ctx = self._route_context(cat, rk)
        start = self._fmt_time(next_info.get("start"))
        finish = self._fmt_time(next_info.get("finish"))
        return [
            "",
            "NEXT",
            f"{cat} → {ctx['route_label']}",
            f"Start: {start} | Est. finish: {finish}",
        ]

    @staticmethod
    def _keyboard_markup() -> dict[str, Any]:
        return {
            "keyboard": [
                [{"text": "📅 Next"}, {"text": "📊 Today"}],
                [{"text": "🟢 Status"}, {"text": "❌ Fails"}],
                [{"text": "🧭 Routes"}, {"text": "❓ Help"}],
            ],
            "resize_keyboard": True,
            "one_time_keyboard": False,
            "is_persistent": True,
            "input_field_placeholder": "TT Master controls",
        }

    @staticmethod
    def _normalize_command(raw_text: str) -> str:
        text = str(raw_text or "").strip()
        if not text:
            return ""
        low = text.lower()
        button_aliases = {
            "📅 next": "/next",
            "📊 today": "/today",
            "🟢 status": "/status",
            "❌ fails": "/fails",
            "🧭 routes": "/routes",
            "❓ help": "/help",
            "next": "/next",
            "today": "/today",
            "status": "/status",
            "fails": "/fails",
            "routes": "/routes",
            "help": "/help",
        }
        if low in button_aliases:
            return button_aliases[low]
        cmd = low.split()[0]
        if "@" in cmd:
            cmd = cmd.split("@", 1)[0]
        return cmd

    def send_text(self, text: str, *, show_keyboard: bool = True, _queue_on_failure: bool = True) -> bool:
        if not self.enabled:
            return False
        retryable = False
        failure = ""
        try:
            url = f"https://api.telegram.org/bot{self.token}/sendMessage"
            with self._notify_lock:
                try:
                    res = self._notify_session.post(
                        url,
                        json={
                            "chat_id": self.chat_id,
                            "text": str(text or "")[:4000],
                            "disable_web_page_preview": True,
                            **({"reply_markup": self._keyboard_markup()} if show_keyboard else {}),
                        },
                        timeout=(10, max(20, self.timeout)),
                    )
                except Exception:
                    self._reset_notify_session_locked()
                    raise
            if not res.ok:
                retryable = res.status_code == 429 or res.status_code >= 500
                failure = f"HTTP {res.status_code}"
                self._warn_rate_limited('notify_http',f"⚠️ Telegram notify failed: HTTP {res.status_code}")
                if retryable and _queue_on_failure:
                    self._queue_outbox(text, show_keyboard, failure)
                return False
            self._clear_warning('notify_http')
            self._clear_warning('notify_transport')
            return True
        except Exception as exc:
            retryable = True
            failure = f"{type(exc).__name__}: {self._safe_error(exc)}"
            self._warn_rate_limited(
                'notify_transport',
                f"⚠️ Telegram notify transport warning: {failure}",
            )
            if _queue_on_failure:
                self._queue_outbox(text, show_keyboard, failure)
            return False

    def notify_primary_success(
        self,
        *,
        category: str,
        route_key: str,
        done: int,
        target: int,
        result: dict[str, Any] | None,
        job_id: str,
        finished_at: datetime,
        next_info: dict[str, Any] | None = None,
    ) -> bool:
        if not self.enabled:
            return False
        result = result or {}
        cid = self._content_id(result)
        primary = self._primary_destinations(result)
        secondary = "pending" if result.get("pending_secondary") else "done / not required"
        ctx = self._route_context(category, route_key)
        lines = [
            "✅ TT Job Completed",
            "",
            f"Category: {category}",
            f"Route: {ctx['route_label']}",
            f"FB: {ctx['fb_label']}",
            f"TikTok: {ctx['tt_label']}",
            f"Progress: {int(done)}/{int(target)}" if int(target or 0) > 0 else f"Done: {int(done)}",
            f"Primary: {primary}",
            f"Group/Secondary: {secondary}",
            f"Time: {finished_at:%Y-%m-%d %H:%M:%S}",
            f"Job: {job_id}",
        ]
        if cid:
            lines.append(f"Content: {cid}")
        lines.extend(self._describe_next(next_info))
        return self.send_text("\n".join(lines))

    def notify_failure(
        self,
        *,
        category: str,
        route_key: str,
        error: str,
        job_id: str,
        finished_at: datetime,
        cooldown_until: str = "",
        next_info: dict[str, Any] | None = None,
    ) -> bool:
        if not self.enabled:
            return False
        ctx = self._route_context(category, route_key)
        clean_error = self._safe_error(error, limit=900)
        lines = [
            "❌ TT Job Failed",
            "",
            f"Category: {category}",
            f"Route: {ctx['route_label']}",
            f"FB: {ctx['fb_label']}",
            f"TikTok: {ctx['tt_label']}",
            f"Time: {finished_at:%Y-%m-%d %H:%M:%S}",
            f"Job: {job_id}",
            f"Error: {clean_error}",
        ]
        if cooldown_until:
            lines.append(f"Cooldown until: {self._fmt_time(cooldown_until)}")
        lines.extend(self._describe_next(next_info))
        return self.send_text("\n".join(lines))

    # ---------- read-only Telegram commands ----------
    def _safe_status(self) -> dict[str, Any]:
        try:
            return dict(self._status_provider() or {}) if self._status_provider else {}
        except Exception as exc:
            return {"_error": f"status unavailable: {exc}"}

    def _safe_state(self) -> dict[str, Any]:
        try:
            return dict(self._state_provider() or {}) if self._state_provider else {}
        except Exception as exc:
            return {"_error": f"state unavailable: {exc}"}

    def _cmd_next(self) -> str:
        status = self._safe_status()
        if status.get("_error"):
            return status["_error"]
        rows = list(status.get("upcoming") or [])[:8]
        lines = ["📅 NEXT JOBS"]
        if status.get("current"):
            cur = status["current"]
            ctx = self._route_context(str(cur.get("category") or ""), str(cur.get("route_key") or "default"))
            lines += ["", f"RUNNING: {cur.get('category')} → {ctx['route_label']}", f"Est. finish: {self._fmt_time(cur.get('estimated_finish'))}"]
        if not rows:
            nxt = status.get("next")
            if nxt:
                rows = [nxt]
        if not rows:
            lines += ["", "No safe next job currently."]
            return "\n".join(lines)
        lines += ["", "Time | Category | Route"]
        for item in rows:
            cat = str(item.get("category") or "")
            rk = str(item.get("route_key") or "default")
            label = str(item.get("route_label") or self._route_context(cat, rk)["route_label"])
            lines.append(f"{self._fmt_time(item.get('start'))} | {cat} | {label}")
        return "\n".join(lines)

    def _cmd_today(self) -> str:
        status = self._safe_status()
        if status.get("_error"):
            return status["_error"]
        lines = ["📊 TODAY", "", "Category | Done/Target | Left"]
        for row in status.get("categories") or []:
            if not row.get("run_today"):
                continue
            done = int(row.get("already_posted") or 0)
            target = int(row.get("target") or 0)
            left = int(row.get("remaining") or 0)
            lines.append(f"{row.get('category')} | {done}/{target} | {left}")
        lines += ["", f"Safe end: {self._fmt_time(status.get('safe_end'))}", f"Remaining total: {int(status.get('remaining_total') or 0)}"]
        return "\n".join(lines)

    def _cmd_status(self) -> str:
        status = self._safe_status()
        if status.get("_error"):
            return status["_error"]
        lines = ["🧭 TT STATUS"]
        cur = status.get("current")
        if cur:
            ctx = self._route_context(str(cur.get("category") or ""), str(cur.get("route_key") or "default"))
            lines += ["", f"Current: {cur.get('category')} → {ctx['route_label']}", f"Est. finish: {self._fmt_time(cur.get('estimated_finish'))}"]
        else:
            lines += ["", "Current: idle"]
        nxt = status.get("next")
        if nxt:
            ctx = self._route_context(str(nxt.get("category") or ""), str(nxt.get("route_key") or "default"))
            lines += [f"Next: {nxt.get('category')} → {ctx['route_label']}", f"Start: {self._fmt_time(nxt.get('start'))} | Finish: {self._fmt_time(nxt.get('finish'))}"]
        else:
            lines.append("Next: none currently")
        lines += [f"Safe end: {self._fmt_time(status.get('safe_end'))}", f"Can finish today: {'YES' if status.get('can_finish_today') else 'NO'}"]
        return "\n".join(lines)

    def _cmd_fails(self) -> str:
        state = self._safe_state()
        if state.get("_error"):
            return state["_error"]
        events = [x for x in (state.get("events") or []) if str((x or {}).get("type") or "") == "job_failed"][-8:]
        lines = ["⚠️ RECENT FAILS"]
        if not events:
            return "\n".join(lines + ["", "No job_failed events today."])
        for ev in reversed(events):
            cat = str(ev.get("category") or "")
            rk = str(ev.get("route_key") or "default")
            ctx = self._route_context(cat, rk)
            err = self._safe_error(ev.get("error") or "unknown", limit=260)
            lines += ["", f"{self._fmt_time(ev.get('at'))} | {cat} → {ctx['route_label']}", err]
            if ev.get("failure_cooldown_until"):
                lines.append(f"Cooldown: {self._fmt_time(ev.get('failure_cooldown_until'))}")
        return "\n".join(lines)

    def _cmd_routes(self) -> str:
        if self.settings is None:
            return "Routes unavailable."
        try:
            cats = self.settings.categories().get("categories") or {}
        except Exception as exc:
            return f"Routes unavailable: {exc}"
        lines = ["🗺️ ENABLED ROUTES"]
        for cat_key, cat in cats.items():
            for rk, route in (cat.get("routes") or {}).items():
                if not isinstance(route, dict) or not route.get("enabled", True):
                    continue
                ctx = self._route_context(str(cat_key), str(rk))
                lines += ["", f"{cat_key} → {ctx['route_label']}", f"FB: {ctx['fb_label']} | TT: {ctx['tt_label']}"]
        return "\n".join(lines)[:3900]

    def _command_reply(self, raw_text: str) -> str:
        cmd = self._normalize_command(raw_text)
        if cmd == "/next":
            return self._cmd_next()
        if cmd == "/today":
            return self._cmd_today()
        if cmd == "/status":
            return self._cmd_status()
        if cmd == "/fails":
            return self._cmd_fails()
        if cmd == "/routes":
            return self._cmd_routes()
        if cmd in {"/help", "/start"}:
            return "TT controls are ready. Tap a button below, or use:\n/next  /today  /status  /fails  /routes  /help"
        return "Unknown TT command. Tap ❓ Help or use /help"

    def _poll_loop(self) -> None:
        url = f"https://api.telegram.org/bot{self.token}/getUpdates"
        consecutive_failures=0
        consecutive_successes=0
        while not self._listener_stop.is_set():
            try:
                res = self._poll_session.get(
                    url,
                    params={"timeout": 25, "offset": self._offset, "allowed_updates": '["message"]'},
                    timeout=(10, 45),
                )
                if not res.ok:
                    consecutive_failures+=1
                    consecutive_successes=0
                    delay=self._poll_backoff_seconds(consecutive_failures)
                    self._warn_rate_limited(
                        'poll_http',
                        f"⚠️ Telegram command polling unavailable: HTTP {res.status_code} | retry≈{delay:.0f}s",
                    )
                    self._listener_stop.wait(delay)
                    continue
                # One successful long-poll between failures must NOT reset warning
                # throttling.  Clear only after three consecutive healthy polls.
                consecutive_successes+=1
                if consecutive_successes>=3:
                    consecutive_failures=0
                    self._clear_warning('poll_http')
                    self._clear_warning('poll_transport')
                self._flush_outbox(limit=5)
                payload = res.json() if res.content else {}
                for update in payload.get("result") or []:
                    try:
                        uid = int(update.get("update_id") or 0)
                        self._offset = max(self._offset, uid + 1)
                        msg = update.get("message") or {}
                        incoming_chat = str((msg.get("chat") or {}).get("id") or "")
                        text = str(msg.get("text") or "").strip()
                        if incoming_chat != self.chat_id or not text:
                            continue
                        normalized = self._normalize_command(text)
                        if normalized not in {"/next", "/today", "/status", "/fails", "/routes", "/help", "/start"}:
                            continue
                        self.send_text(self._command_reply(text), show_keyboard=True)
                    except Exception as exc:
                        self._warn_rate_limited(
                            'command_handling',
                            f"⚠️ Telegram command handling warning: {self._safe_error(exc)}",
                        )
            except Exception as exc:
                consecutive_failures+=1
                consecutive_successes=0
                delay=self._poll_backoff_seconds(consecutive_failures)
                self._reset_poll_session()
                self._warn_rate_limited(
                    'poll_transport',
                    f"⚠️ Telegram command polling unavailable: {type(exc).__name__}: "
                    f"{self._safe_error(exc)} | retry≈{delay:.0f}s",
                )
                self._listener_stop.wait(delay)

    def start_command_listener(self) -> bool:
        if not self.enabled:
            return False
        if self._listener_thread is not None and self._listener_thread.is_alive():
            return False
        self._listener_thread = None
        if self._status_provider is None or self._state_provider is None:
            print("⚠️ Telegram commands not started: read-only providers not configured")
            return False
        self._listener_stop.clear()
        self._listener_thread = threading.Thread(target=self._poll_loop, name="tt-telegram-commands", daemon=True)
        self._listener_thread.start()
        print("🤖 Telegram read-only controls live: buttons + /next /today /status /fails /routes")
        try:
            self.send_text("🤖 TT Telegram controls ready. Tap a button below.", show_keyboard=True)
        except Exception:
            pass
        return True

    def stop_command_listener(self) -> None:
        self._listener_stop.set()
        thread = self._listener_thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=2.0)
        if thread is None or not thread.is_alive():
            self._listener_thread = None
