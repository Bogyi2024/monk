from __future__ import annotations

import json
import math
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from PIL import Image, ImageEnhance, ImageFilter, ImageDraw

from services.gemini_story_tts_service import GeminiStoryTTSService
from services.story_bgm_service import StoryBGMService


class StoryMotionVideoService:
    """
    Drama V2:
    - 7 Story Board cards
    - ONE continuous female TTS generation for all scenes
    - Detect long inter-scene silences in that one narration
    - Cut only at silence centers, preserving one speaker identity
    - Scene duration follows the matching narration segment
    - Add distributed silent tail only when needed to keep final safely > 1 minute
    - Non-repeat local BGM
    """

    def __init__(self, config: dict[str, Any] | None = None):
        self.config = config or {}

        self.ffmpeg = self._resolve_binary(
            os.getenv("FFMPEG_PATH"),
            r"C:\ffmpeg\bin\ffmpeg.exe",
            "ffmpeg",
        )
        self.ffprobe = self._resolve_binary(
            os.getenv("FFPROBE_PATH"),
            r"C:\ffmpeg\bin\ffprobe.exe",
            "ffprobe",
        )

        self.width = int(self.config.get("video_width", 1080))
        self.height = int(self.config.get("video_height", 1920))
        self.fps = int(self.config.get("fps", 30))

        self.target_min = float(self.config.get("target_min_seconds", 66))
        self.minimum_scene_tail = float(self.config.get("minimum_scene_tail_seconds", 0.0))

        self.silence_noise = str(self.config.get("silence_noise", "-38dB"))
        self.silence_min = float(self.config.get("silence_min_seconds", 0.72))

        self.bgm_volume = float(self.config.get("bgm_volume", 1.0))

        self.tts = GeminiStoryTTSService(self.config)
        self.bgm = StoryBGMService(self.config)
        self._encoder = None

    @staticmethod
    def _resolve_binary(*candidates: str | None) -> str:
        executable = str(candidates[-1])
        for c in candidates[:-1]:
            if c and os.path.isfile(c):
                return os.path.abspath(c)
        found = shutil.which(executable)
        if found:
            return found
        raise FileNotFoundError(f"{executable} not found")

    def _run(self, cmd: list[str], label: str) -> subprocess.CompletedProcess:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if result.returncode != 0:
            raise RuntimeError(f"{label} failed:\n{result.stderr[-5000:]}")
        return result

    def _pick_encoder(self) -> list[str]:
        if self._encoder is not None:
            return self._encoder

        p = subprocess.run(
            [self.ffmpeg, "-hide_banner", "-encoders"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if "h264_nvenc" in p.stdout:
            self._encoder = [
                "-c:v", "h264_nvenc", "-preset", "p5",
                "-rc", "vbr", "-cq", "22", "-b:v", "0",
            ]
        else:
            self._encoder = [
                "-c:v", "libx264", "-preset", "medium", "-crf", "20",
            ]
        return self._encoder

    def _duration(self, media: Path) -> float:
        p = subprocess.run(
            [
                self.ffprobe,
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                str(media.resolve()),
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if p.returncode != 0:
            raise RuntimeError(p.stderr[-2000:])
        return float(p.stdout.strip())

    @staticmethod
    def _cover(img: Image.Image, size: tuple[int, int]) -> Image.Image:
        tw, th = size
        sw, sh = img.size
        scale = max(tw / sw, th / sh)
        r = img.resize(
            (math.ceil(sw * scale), math.ceil(sh * scale)),
            Image.Resampling.LANCZOS,
        )
        left = (r.width - tw) // 2
        top = (r.height - th) // 2
        return r.crop((left, top, left + tw, top + th))

    def _make_vertical_frame(
        self,
        square_path: Path,
        background_path: Path,
        output: Path,
    ) -> None:
        """Build the MOTION image layer only — never bake Story Board text into it.

        V2.3 uses the raw FAL image for both the vertical background and center square.
        Text/readability overlay is rendered separately and stays static while this
        image layer zooms/pans.  `square_path` remains only as a fallback for old jobs
        where the raw image no longer exists.
        """
        source_path = background_path if background_path.exists() else square_path
        src = Image.open(source_path).convert("RGB")

        bg = self._cover(src, (self.width, self.height))
        bg = bg.filter(ImageFilter.GaussianBlur(radius=32))
        bg = ImageEnhance.Brightness(bg).enhance(0.46)
        bg = ImageEnhance.Color(bg).enhance(0.82)

        fg = self._cover(src, (self.width, self.width))
        y = (self.height - self.width) // 2
        bg.paste(fg, (0, y))

        output.parent.mkdir(parents=True, exist_ok=True)
        bg.save(output, "JPEG", quality=95, subsampling=0)

    def _make_static_story_overlay(
        self,
        *,
        slide: dict[str, Any],
        index: int,
        total: int,
        output: Path,
    ) -> None:
        """Render Story Board Burmese text as a STATIC transparent overlay.

        This reuses the proven Chromium Myanmar renderer from Story Carousel, but
        keeps the resulting text/readability layer outside the zoom filter.
        """
        from services.story_carousel_service import StoryCarouselService

        cfg_path = Path("config/story_carousel.json")
        cfg = json.loads(cfg_path.read_text(encoding="utf-8")) if cfg_path.exists() else {}
        renderer = StoryCarouselService.__new__(StoryCarouselService)
        renderer.config_path = cfg_path
        renderer.config = cfg
        renderer._story_font_path_cache = None
        renderer._story_font_base64_cache = None

        square_size = (self.width, self.width)
        square_overlay = Image.new("RGBA", square_size, (0, 0, 0, 0))
        od = ImageDraw.Draw(square_overlay)
        lower_y = int(self.width * float(cfg.get("lower_overlay_start", 0.51)))
        lower_alpha = int(cfg.get("lower_overlay_alpha", 182))
        od.rectangle((0, lower_y, self.width, self.width), fill=(0, 0, 0, max(0, min(255, lower_alpha))))

        with tempfile.TemporaryDirectory(prefix="drama_motion_text_") as td:
            text_png = Path(td) / "story_text.png"
            renderer._render_story_text_layer_playwright(
                headline=slide.get("headline") or "",
                body=slide.get("body") or "",
                index=index,
                total=total,
                output_png_path=text_png,
                canvas_size=square_size,
            )
            text_layer = Image.open(text_png).convert("RGBA")
            square_overlay = Image.alpha_composite(square_overlay, text_layer)

        canvas = Image.new("RGBA", (self.width, self.height), (0, 0, 0, 0))
        y = (self.height - self.width) // 2
        canvas.alpha_composite(square_overlay, (0, y))
        output.parent.mkdir(parents=True, exist_ok=True)
        canvas.save(output, "PNG")

    def _render_scene_video(
        self,
        image_path: Path,
        output_path: Path,
        duration: float,
        scene_index: int,
        overlay_path: Path | None = None,
    ) -> None:
        frames = max(2, int(round(duration * self.fps)))
        fade = min(0.30, max(0.15, duration / 10))
        fade_out_start = max(0.0, duration - fade)

        if scene_index % 2:
            zoom = "min(zoom+0.00065,1.055)"
        else:
            zoom = "if(eq(on,1),1.055,max(zoom-0.00065,1.0))"

        zoom_filter = (
            f"zoompan=z='{zoom}':"
            f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
            f"d={frames}:s={self.width}x{self.height}:fps={self.fps}"
        )

        cmd = [
            self.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
            "-loop", "1", "-i", str(image_path.resolve()),
        ]
        if overlay_path is not None and overlay_path.exists():
            cmd += ["-loop", "1", "-i", str(overlay_path.resolve())]
            fc = (
                f"[0:v]{zoom_filter}[motion];"
                f"[motion][1:v]overlay=x=0:y=0:eof_action=pass:repeatlast=1,"
                f"fade=t=in:st=0:d={fade:.3f},"
                f"fade=t=out:st={fade_out_start:.3f}:d={fade:.3f},"
                "format=yuv420p[vout]"
            )
            cmd += ["-filter_complex", fc, "-map", "[vout]"]
        else:
            vf = (
                f"{zoom_filter},"
                f"fade=t=in:st=0:d={fade:.3f},"
                f"fade=t=out:st={fade_out_start:.3f}:d={fade:.3f},"
                "format=yuv420p"
            )
            cmd += ["-vf", vf]

        cmd += [
            "-t", f"{duration:.3f}", "-r", str(self.fps),
            *self._pick_encoder(), "-an", str(output_path.resolve()),
        ]
        self._run(cmd, f"scene video {scene_index}")

    def _detect_silences(self, audio_path: Path) -> list[tuple[float, float]]:
        cmd = [
            self.ffmpeg,
            "-hide_banner",
            "-i",
            str(audio_path.resolve()),
            "-af",
            f"silencedetect=noise={self.silence_noise}:d={self.silence_min:.3f}",
            "-f",
            "null",
            "-",
        ]
        p = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

        text = (p.stderr or "") + "\n" + (p.stdout or "")
        starts: list[float] = []
        intervals: list[tuple[float, float]] = []

        for line in text.splitlines():
            m = re.search(r"silence_start:\s*([0-9.]+)", line)
            if m:
                starts.append(float(m.group(1)))
                continue

            m = re.search(r"silence_end:\s*([0-9.]+)", line)
            if m and starts:
                start = starts.pop(0)
                end = float(m.group(1))
                if end > start:
                    intervals.append((start, end))

        return intervals

    @staticmethod
    def _expected_boundaries(
        scenes: list[dict[str, Any]],
        total_duration: float,
    ) -> list[float]:
        weights = [
            max(1, len(re.sub(r"\s+", "", str(s.get("narration") or ""))))
            for s in scenes
        ]
        total_weight = float(sum(weights))
        out = []
        cumulative = 0.0
        for weight in weights[:-1]:
            cumulative += weight
            out.append(total_duration * cumulative / total_weight)
        return out

    def _choose_boundaries(
        self,
        *,
        scenes: list[dict[str, Any]],
        audio_path: Path,
        total_duration: float,
    ) -> tuple[list[float], str, list[dict[str, float]]]:
        """
        Long pauses are the primary boundary source.
        If TTS does not create enough long pauses, use narration-text ratios as fallback.
        """
        intervals = self._detect_silences(audio_path)
        candidates = []
        for start, end in intervals:
            duration = end - start
            if duration < self.silence_min:
                continue
            center = (start + end) / 2.0
            if center <= 0.4 or center >= total_duration - 0.4:
                continue
            candidates.append({
                "start": start,
                "end": end,
                "duration": duration,
                "center": center,
            })

        needed = len(scenes) - 1
        expected = self._expected_boundaries(scenes, total_duration)

        if len(candidates) >= needed:
            # Pick silence centers nearest to the expected cumulative text position.
            chosen: list[float] = []
            used: set[int] = set()
            last = 0.0

            for exp in expected:
                valid = [
                    (idx, item)
                    for idx, item in enumerate(candidates)
                    if idx not in used and item["center"] > last + 0.8
                ]
                if not valid:
                    break

                idx, item = min(
                    valid,
                    key=lambda pair: (
                        abs(pair[1]["center"] - exp),
                        -pair[1]["duration"],
                    ),
                )
                chosen.append(float(item["center"]))
                used.add(idx)
                last = float(item["center"])

            if len(chosen) == needed and chosen == sorted(chosen):
                print(
                    f"🎯 Scene timing boundaries detected from ONE-voice silence gaps: "
                    f"{', '.join(f'{x:.2f}' for x in chosen)}"
                )
                return chosen, "silence_detect", candidates

        fallback = expected
        print(
            "⚠️ Could not confidently detect all inter-scene long pauses. "
            "Using narration-text proportional boundaries while keeping ONE continuous voice."
        )
        return fallback, "text_ratio_fallback", candidates

    def _extract_scene_audio(
        self,
        *,
        source_audio: Path,
        output_path: Path,
        start: float,
        end: float,
        final_duration: float,
    ) -> None:
        source_duration = max(0.05, end - start)
        pad = max(0.0, final_duration - source_duration)

        af = (
            f"atrim=start={start:.6f}:end={end:.6f},"
            "asetpts=PTS-STARTPTS,"
            "aresample=48000,"
            f"apad=pad_dur={pad:.6f},"
            f"atrim=duration={final_duration:.6f}"
        )

        cmd = [
            self.ffmpeg,
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(source_audio.resolve()),
            "-af",
            af,
            "-ar",
            "48000",
            "-ac",
            "2",
            "-c:a",
            "pcm_s16le",
            str(output_path.resolve()),
        ]
        self._run(cmd, "extract scene audio")

    @staticmethod
    def _concat_list(paths: list[Path], output_txt: Path) -> None:
        rows = []
        for p in paths:
            value = p.resolve().as_posix().replace("'", r"'\''")
            rows.append(f"file '{value}'")
        output_txt.write_text("\n".join(rows) + "\n", encoding="utf-8")

    def _concat_video(self, clips: list[Path], output: Path, work: Path) -> None:
        list_file = work / "video_concat.txt"
        self._concat_list(clips, list_file)
        self._run(
            [
                self.ffmpeg,
                "-y",
                "-hide_banner",
                "-loglevel",
                "error",
                "-f",
                "concat",
                "-safe",
                "0",
                "-i",
                str(list_file.resolve()),
                "-c",
                "copy",
                str(output.resolve()),
            ],
            "video concat",
        )

    def _concat_audio(self, clips: list[Path], output: Path, work: Path) -> None:
        list_file = work / "audio_concat.txt"
        self._concat_list(clips, list_file)
        self._run(
            [
                self.ffmpeg,
                "-y",
                "-hide_banner",
                "-loglevel",
                "error",
                "-f",
                "concat",
                "-safe",
                "0",
                "-i",
                str(list_file.resolve()),
                "-ar",
                "48000",
                "-ac",
                "2",
                "-c:a",
                "pcm_s16le",
                str(output.resolve()),
            ],
            "audio concat",
        )

    def _mix_final(
        self,
        video: Path,
        narration: Path,
        bgm: Path,
        output: Path,
        duration: float,
    ) -> None:
        fade_out = max(0.0, duration - 2.0)

        fc = (
            # Narration: noticeably louder and clearer than V2.2.
            "[1:a]"
            "highpass=f=65,"
            "equalizer=f=3200:t=q:w=1.0:g=2.2,"
            "acompressor=threshold=-20dB:ratio=2.0:attack=6:release=100:makeup=1.5,"
            "loudnorm=I=-12.0:TP=-1.0:LRA=7,"
            "aresample=48000[narr];"
            # BGM: normalize to a predictable audible level instead of relying only
            # on a tiny raw volume multiplier (tracks have very different source levels).
            "[2:a]"
            f"atrim=duration={duration:.3f},"
            "loudnorm=I=-24.0:TP=-3.0:LRA=12,"
            "afade=t=in:st=0:d=1.0,"
            f"afade=t=out:st={fade_out:.3f}:d=2.0,"
            "aresample=48000[bg];"
            # Mix and protect against clipping.
            "[narr][bg]amix=inputs=2:duration=first:dropout_transition=2,"
            "alimiter=limit=0.95,"
            "aresample=48000[aout]"
        )

        self._run(
            [
                self.ffmpeg,
                "-y",
                "-hide_banner",
                "-loglevel",
                "error",
                "-i",
                str(video.resolve()),
                "-i",
                str(narration.resolve()),
                "-stream_loop",
                "-1",
                "-i",
                str(bgm.resolve()),
                "-filter_complex",
                fc,
                "-map",
                "0:v:0",
                "-map",
                "[aout]",
                "-c:v",
                "copy",
                "-c:a",
                "aac",
                "-b:a",
                "192k",
                "-ar",
                "48000",
                "-t",
                f"{duration:.3f}",
                "-movflags",
                "+faststart",
                str(output.resolve()),
            ],
            "final BGM mix",
        )

    def build(
        self,
        *,
        story_dir: Path,
        story: dict[str, Any],
        narration_plan: dict[str, Any],
        force_tts: bool = False,
    ) -> dict[str, Any]:
        slides = story.get("slides") or []
        scenes = narration_plan.get("scenes") or []

        if len(slides) != len(scenes):
            raise ValueError("Story slide count and narration scene count do not match")

        story_id = str(story.get("story_id") or story_dir.name)

        square_dir = story_dir / "square"
        raw_dir = story_dir / "raw"
        work = story_dir / "video_build_v2"
        frames_dir = work / "frames"
        clips_dir = work / "clips"
        scene_audio_dir = work / "scene_audio"

        for d in [work, frames_dir, clips_dir, scene_audio_dir]:
            d.mkdir(parents=True, exist_ok=True)

        continuous_voice = work / "continuous_female_narration.wav"
        voice_direction = str(narration_plan.get("voice_direction") or "")

        if (
            force_tts
            or not continuous_voice.exists()
            or continuous_voice.stat().st_size < 2000
        ):
            voice_info = self.tts.synthesize_story(
                scenes=scenes,
                output_path=continuous_voice,
                voice_direction=voice_direction,
            )
        else:
            voice_info = {
                "path": str(continuous_voice.resolve()),
                "duration": self.tts.duration(continuous_voice),
                "voice": self.tts.voice,
                "model": self.tts.model,
                "scene_count": len(scenes),
                "single_call": True,
            }
            print(
                f"♻️ Reuse ONE continuous female narration → "
                f"{continuous_voice.name} | {voice_info['duration']:.2f}s"
            )

        total_voice_duration = float(voice_info["duration"])

        boundaries, boundary_mode, silence_candidates = self._choose_boundaries(
            scenes=scenes,
            audio_path=continuous_voice,
            total_duration=total_voice_duration,
        )

        points = [0.0] + boundaries + [total_voice_duration]
        raw_scene_durations = [
            max(0.05, points[i + 1] - points[i])
            for i in range(len(scenes))
        ]

        # Keep some clean visual breathing room. If the narration is under our
        # safe 66s target, distribute the missing time across all 7 scenes.
        tails = [self.minimum_scene_tail for _ in scenes]
        planned_total = sum(
            d + tail for d, tail in zip(raw_scene_durations, tails)
        )

        if planned_total < self.target_min:
            extra = (self.target_min - planned_total) / len(scenes)
            tails = [tail + extra for tail in tails]
            planned_total = sum(
                d + tail for d, tail in zip(raw_scene_durations, tails)
            )
        # V2.0.4: there is intentionally NO maximum runtime cap. Long narration is
        # valid; each scene simply follows its matching audio segment. Only the
        # one-minute minimum is guarded below.

        print(
            f"⏱️ ONE narrator audio={total_voice_duration:.2f}s | "
            f"planned final={planned_total:.2f}s | boundary_mode={boundary_mode}"
        )

        if planned_total < 60.5:
            raise RuntimeError("Final planned duration is not safely over one minute")

        video_clips: list[Path] = []
        audio_clips: list[Path] = []
        timing: list[dict[str, Any]] = []

        cursor = 0.0

        for i, scene in enumerate(scenes, 1):
            source_start = points[i - 1]
            source_end = points[i]
            source_duration = raw_scene_durations[i - 1]
            scene_duration = source_duration + tails[i - 1]

            square = square_dir / f"slide_{i:02d}.jpg"
            if not square.exists():
                raise FileNotFoundError(f"Missing square slide: {square}")

            raw = raw_dir / f"slide_{i:02d}.jpg"
            bg_source = raw if raw.exists() else square

            vertical = frames_dir / f"scene_{i:02d}_vertical.jpg"
            self._make_vertical_frame(square, bg_source, vertical)

            static_overlay = frames_dir / f"scene_{i:02d}_static_text.png"
            self._make_static_story_overlay(
                slide=slides[i - 1],
                index=i,
                total=len(slides),
                output=static_overlay,
            )

            clip = clips_dir / f"scene_{i:02d}.mp4"
            self._render_scene_video(vertical, clip, scene_duration, i, static_overlay)
            video_clips.append(clip)

            scene_audio = scene_audio_dir / f"scene_{i:02d}.wav"
            self._extract_scene_audio(
                source_audio=continuous_voice,
                output_path=scene_audio,
                start=source_start,
                end=source_end,
                final_duration=scene_duration,
            )
            audio_clips.append(scene_audio)

            timing.append(
                {
                    "scene_no": i,
                    "start": round(cursor, 3),
                    "end": round(cursor + scene_duration, 3),
                    "scene_duration": round(scene_duration, 3),
                    "source_voice_start": round(source_start, 3),
                    "source_voice_end": round(source_end, 3),
                    "source_voice_duration": round(source_duration, 3),
                    "visual_tail": round(tails[i - 1], 3),
                    "narration": str(scene.get("narration") or ""),
                    "emotion": str(scene.get("emotion") or ""),
                }
            )
            cursor += scene_duration

        silent_video = work / "story_video_noaudio.mp4"
        narration_audio = work / "continuous_voice_scene_synced.wav"

        self._concat_video(video_clips, silent_video, work)
        self._concat_audio(audio_clips, narration_audio, work)

        final_duration = min(
            self._duration(silent_video),
            self._duration(narration_audio),
        )

        music_mood = str(narration_plan.get("music_mood") or "emotional")
        bgm = self.bgm.choose(story_id=story_id, mood=music_mood)

        final_video = story_dir / "story_drama_motion_v2.mp4"

        self._mix_final(
            silent_video,
            narration_audio,
            bgm,
            final_video,
            final_duration,
        )

        actual_final = self._duration(final_video)

        report = {
            "story_id": story_id,
            "title": story.get("title", ""),
            "final_video": str(final_video.resolve()),
            "final_duration": round(actual_final, 3),
            "tts_model": self.tts.model,
            "tts_voice": self.tts.voice,
            "voice_generation_mode": "ONE_CONTINUOUS_TTS_CALL",
            "boundary_mode": boundary_mode,
            "detected_silence_candidates": silence_candidates,
            "music_mood": music_mood,
            "bgm": str(bgm.resolve()),
            "bgm_volume": self.bgm_volume,
            "scenes": timing,
        }

        (story_dir / "story_drama_motion_v2_report.json").write_text(
            json.dumps(report, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        print(f"🎬 Drama V2 motion video READY → {final_video}")
        print(
            f"🎙️ Voice consistency mode → ONE continuous female TTS call ({self.tts.voice})"
        )
        print(f"⏱️ Final duration → {actual_final:.2f}s")

        return report
