from __future__ import annotations

import hashlib
import json
import math
import os
import random
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence


AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp"}


@dataclass
class PartSpec:
    number: int
    total: int
    start_index: int
    end_index: int
    images: list[Path]
    durations: list[float]


class StoryMotionLabService:
    """Standalone Story Motion audio/FX + series continuity test lab.

    It intentionally does NOT call Gemini / Hugging Face / fal.ai and does NOT post
    to Facebook / TikTok / YouTube.  The goal is to approve:
      - Horror / Thriller visual motion preset
      - local BGM + SFX mix
      - no-repeat music pool
      - future Part 1 / Part 2 continuity state

    Once approved, this exact service can be wired into TT Master.
    """

    CAMERA_PATHS = (
        "push_center",
        "push_left",
        "push_right",
        "pull_center",
        "push_low",
        "push_right",
        "push_center",
        "pull_center",
    )

    def __init__(self, root: Path | str = ".", *, width: int = 1080, height: int = 1920, fps: int = 30, motion_config: dict | None = None):
        self.root = Path(root).resolve()
        self.width = int(width)
        self.height = int(height)
        self.fps = int(fps)
        self.motion_config = dict(motion_config or {})
        self.ffmpeg = self._resolve_binary(os.getenv("FFMPEG_PATH"), r"C:\ffmpeg\bin\ffmpeg.exe", "ffmpeg")
        self.ffprobe = self._resolve_binary(os.getenv("FFPROBE_PATH"), r"C:\ffmpeg\bin\ffprobe.exe", "ffprobe")
        self.encoder = self._pick_encoder()
        self.state_dir = self.root / "state"
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.music_registry_path = self.state_dir / "story_motion_music_registry.json"
        self.series_registry_path = self.state_dir / "story_motion_series_registry.json"

    @staticmethod
    def _resolve_binary(*candidates: str | None) -> str:
        for item in candidates[:-1]:
            if item and os.path.isfile(item):
                return os.path.abspath(item)
        found = shutil.which(str(candidates[-1]))
        if found:
            return found
        raise FileNotFoundError(str(candidates[-1]))

    def _pick_encoder(self) -> list[str]:
        p = subprocess.run([self.ffmpeg, "-hide_banner", "-encoders"], capture_output=True, text=True, encoding="utf-8", errors="replace")
        if "h264_nvenc" in (p.stdout or ""):
            return ["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", "22", "-b:v", "0"]
        return ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20"]

    @staticmethod
    def _read_json(path: Path, default):
        try:
            if path.exists():
                value = json.loads(path.read_text(encoding="utf-8"))
                return value
        except Exception:
            pass
        return default

    @staticmethod
    def _write_json(path: Path, value) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, path)

    @staticmethod
    def newest_story_raw_dir(root: Path = Path("outputs/story_carousel")) -> Path:
        candidates: list[Path] = []
        if root.exists():
            for story in root.iterdir():
                raw = story / "raw"
                if story.is_dir() and raw.is_dir() and any(p.suffix.lower() in IMAGE_EXTS for p in raw.iterdir() if p.is_file()):
                    candidates.append(raw)
        if not candidates:
            raise FileNotFoundError("outputs/story_carousel/<story>/raw ထဲက image set မတွေ့ပါ။ --input-dir နဲ့ folder တိုက်ရိုက်ပေးလို့ရပါတယ်။")
        return max(candidates, key=lambda p: p.parent.stat().st_mtime)

    @staticmethod
    def collect_images(input_dir: Path, limit: int = 18) -> list[Path]:
        preferred = []
        fallback = []
        for p in sorted(input_dir.iterdir() if input_dir.exists() else []):
            if not p.is_file() or p.suffix.lower() not in IMAGE_EXTS:
                continue
            n = p.name.lower()
            if n.startswith(("scene_", "slide_", "frame_")):
                preferred.append(p)
            else:
                fallback.append(p)
        images = (preferred or fallback)[:limit]
        if len(images) < 2:
            raise FileNotFoundError(f"Not enough images in {input_dir}")
        return images

    @staticmethod
    def _story_signature(images: Sequence[Path], preset: str) -> str:
        h = hashlib.sha1()
        h.update(preset.encode("utf-8"))
        for p in images:
            h.update(p.name.encode("utf-8", errors="ignore"))
            try:
                h.update(str(p.stat().st_size).encode())
                with p.open("rb") as f:
                    h.update(f.read(4096))
            except Exception:
                pass
        return h.hexdigest()[:14]

    def _load_optional_plan(self, input_dir: Path) -> dict:
        for name in ("story_motion_plan.json", "story_plan.json", "plan.json"):
            p = input_dir / name
            if p.exists():
                data = self._read_json(p, {})
                if isinstance(data, dict):
                    return data
        return {}

    @staticmethod
    def _scene_durations(count: int, preset: str, plan: dict) -> list[float]:
        supplied = plan.get("scene_durations")
        if isinstance(supplied, list) and len(supplied) >= count:
            out = []
            for x in supplied[:count]:
                try:
                    out.append(max(3.5, min(14.0, float(x))))
                except Exception:
                    out.append(7.0)
            return out
        base = 7.2 if preset == "horror" else 6.7
        # Scene-long motion, with slightly longer hook / climax shots.
        vals = [base] * count
        if count:
            vals[0] = base + 0.8
            vals[-1] = base + 1.1
        if count >= 5:
            vals[count // 2] = base + 0.6
        return vals

    def _part_specs(self, images: list[Path], durations: list[float], plan: dict, *, mode: str = "auto") -> list[PartSpec]:
        total_duration = sum(durations)
        forced = mode.lower().strip()
        cut = plan.get("part_break_after_scene")
        try:
            cut = int(cut) if cut not in (None, "") else None
        except Exception:
            cut = None

        # Auto rule for TEST architecture:
        # - <=105 sec: keep one self-contained episode.
        # - >105 sec: use explicit natural story cut when plan provides it.
        # - otherwise split near the middle, but never leave a tiny part.
        should_split = forced == "2" or (forced == "auto" and total_duration > 105.0)
        if forced == "1":
            should_split = False

        if not should_split or len(images) < 8:
            return [PartSpec(1, 1, 0, len(images), images, durations)]

        if cut is None or cut < 3 or cut > len(images) - 3:
            target = total_duration / 2.0
            running = 0.0
            cut = max(3, min(len(images) - 3, len(images) // 2))
            for i, d in enumerate(durations[:-2], 1):
                running += d
                if running >= target:
                    cut = max(3, min(len(images) - 3, i))
                    break

        return [
            PartSpec(1, 2, 0, cut, images[:cut], durations[:cut]),
            PartSpec(2, 2, cut, len(images), images[cut:], durations[cut:]),
        ]

    def _camera_expr(self, camera: str, frames: int) -> tuple[str, str, str]:
        n = max(2, frames - 1)
        # V0.3.6 deliberately PRESERVES a visible cinematic zoom language.
        # Liquid distortion is an additional surface deformation, never a replacement
        # for the push/pull camera move.
        if camera == "pull_center":
            return f"max(1.018,1.132-0.114*on/{n})", "(iw-iw/zoom)*0.50", "(ih-ih/zoom)*0.50"
        if camera == "push_left":
            return f"min(1.128,1.005+0.123*on/{n})", f"(iw-iw/zoom)*(0.61-0.15*on/{n})", f"(ih-ih/zoom)*(0.48+0.035*on/{n})"
        if camera == "push_right":
            return f"min(1.128,1.005+0.123*on/{n})", f"(iw-iw/zoom)*(0.39+0.15*on/{n})", f"(ih-ih/zoom)*(0.50-0.035*on/{n})"
        if camera == "push_low":
            return f"min(1.136,1.005+0.131*on/{n})", f"(iw-iw/zoom)*(0.49+0.025*on/{n})", f"(ih-ih/zoom)*(0.38+0.15*on/{n})"
        return f"min(1.130,1.005+0.125*on/{n})", f"(iw-iw/zoom)*(0.49+0.025*on/{n})", f"(ih-ih/zoom)*(0.51-0.025*on/{n})"

    @staticmethod
    def _grade_filter(preset: str) -> str:
        # Keep the horror/thriller grade, but avoid temporal grain shimmer.  The old
        # allf=t+u changes the noise pattern every frame and can read as micro-shake.
        if preset == "thriller":
            return "eq=contrast=1.18:brightness=-0.050:saturation=0.82:gamma=0.96,colorbalance=rm=-0.035:gm=-0.010:bm=0.050,vignette=PI/5.4,noise=alls=1.5:allf=u,unsharp=5:5:0.30"
        return "eq=contrast=1.23:brightness=-0.075:saturation=0.74:gamma=0.93,colorbalance=rm=-0.030:gm=0.050:bm=-0.040,vignette=PI/5.0,noise=alls=1.9:allf=u,unsharp=5:5:0.30"

    def _motion_setting(self, key: str, default):
        value = self.motion_config.get(key, default)
        try:
            if isinstance(default, bool):
                return bool(value)
            if isinstance(default, int):
                return int(value)
            if isinstance(default, float):
                return float(value)
        except Exception:
            return default
        return value

    def _render_scene(self, image: Path, out: Path, *, duration: float, index: int, preset: str) -> None:
        """Render one scene with stable cinematic drift + true fluid displacement.

        V0.3.6 changes:
        - zoom/pan is rendered on a supersampled canvas and downscaled, which removes
          the integer-pixel stepping that looked like camera shake;
        - two slow broad displacement maps create a liquid-surface ripple while
          keeping the original push/pull zoom clearly visible;
        - temporal film-noise shimmer is removed from the grade.
        """
        frames = max(2, round(duration * self.fps))
        camera = self.CAMERA_PATHS[(index - 1) % len(self.CAMERA_PATHS)]

        supersample = max(1.0, min(2.0, self._motion_setting("supersample", 1.5)))
        work_w = max(self.width, int(round(self.width * supersample / 2.0)) * 2)
        work_h = max(self.height, int(round(self.height * supersample / 2.0)) * 2)
        z, x, y = self._camera_expr(camera, frames)

        # A low-resolution procedural displacement map is dramatically faster than
        # running geq on every full-resolution RGB frame.  Bicubic upscaling keeps
        # the deformation smooth instead of blocky.
        wave_enabled = self._motion_setting("wave_enabled", True)
        base_x = self._motion_setting("wave_x_pixels", 13.8 if preset == "horror" else 11.8)
        base_y = self._motion_setting("wave_y_pixels", 8.8 if preset == "horror" else 7.2)
        speed_x = self._motion_setting("wave_speed_x", 0.58 if preset == "horror" else 0.50)
        speed_y = self._motion_setting("wave_speed_y", 0.44 if preset == "horror" else 0.38)
        # Vary the strength slightly by scene so the result feels organic, not like
        # the exact same effect pasted on every image.
        strength_cycle = (0.90, 1.00, 0.95, 1.08, 0.92, 1.04)
        strength = strength_cycle[(index - 1) % len(strength_cycle)]
        amp_x = max(0.0, min(18.0, base_x * strength))
        amp_y = max(0.0, min(14.0, base_y * strength))
        map_w = max(180, self.width // 4)
        map_h = max(320, self.height // 4)

        base_filter = (
            f"[0:v]scale={work_w}:{work_h}:force_original_aspect_ratio=increase,"
            f"crop={work_w}:{work_h},"
            f"zoompan=z='{z}':x='{x}':y='{y}':d=1:s={work_w}x{work_h}:fps={self.fps},"
            f"scale={self.width}:{self.height}:flags=lanczos,"
            f"{self._grade_filter(preset)}[base]"
        )

        def build_cmd(encoder: list[str]) -> list[str]:
            cmd = [
                self.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
                "-loop", "1", "-framerate", str(self.fps), "-i", str(image.resolve()),
            ]
            if wave_enabled and (amp_x > 0.01 or amp_y > 0.01):
                x_map = (
                    f"nullsrc=s={map_w}x{map_h}:r={self.fps},"
                    f"geq=lum='128+{amp_x:.3f}*(0.55*sin(Y/55+T*{speed_x:.3f})+0.30*sin(Y/120-X/180-T*{speed_x*0.63:.3f})+0.15*sin((X+Y)/190+T*{speed_x*0.37:.3f}))':cb=128:cr=128,"
                    f"format=gray,scale={self.width}:{self.height}:flags=bicubic"
                )
                y_map = (
                    f"nullsrc=s={map_w}x{map_h}:r={self.fps},"
                    f"geq=lum='128+{amp_y:.3f}*(0.58*sin(X/68+T*{speed_y:.3f})+0.27*sin(X/145+Y/210-T*{speed_y*0.59:.3f})+0.15*sin((X-Y)/220+T*{speed_y*0.31:.3f}))':cb=128:cr=128,"
                    f"format=gray,scale={self.width}:{self.height}:flags=bicubic"
                )
                cmd += ["-f", "lavfi", "-i", x_map, "-f", "lavfi", "-i", y_map]
                fc = base_filter + ";[base][1:v][2:v]displace=edge=smear,format=yuv420p[vout]"
            else:
                fc = base_filter + ";[base]format=yuv420p[vout]"
            cmd += [
                "-filter_complex", fc, "-map", "[vout]",
                "-t", f"{duration:.3f}", "-r", str(self.fps),
                *encoder, "-an", str(out.resolve()),
            ]
            return cmd

        cmd = build_cmd(self.encoder)
        p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if p.returncode != 0 and "h264_nvenc" in self.encoder:
            print("⚠️ NVENC unavailable — libx264 fallback")
            self.encoder = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20"]
            p = subprocess.run(build_cmd(self.encoder), capture_output=True, text=True, encoding="utf-8", errors="replace")
        if p.returncode != 0:
            raise RuntimeError(f"Scene {index} failed:\n{p.stderr[-4000:]}")
        wave_note = f"fluid {amp_x:.1f}/{amp_y:.1f}px" if wave_enabled else "wave off"
        print(f"🎥 Scene {index:02d}: {camera} + {wave_note} | {duration:.1f}s")

    def _concat(self, scene_files: Sequence[Path], output: Path) -> None:
        manifest = output.parent / f"concat_{output.stem}.txt"
        manifest.write_text("\n".join(f"file '{p.resolve().as_posix()}'" for p in scene_files), encoding="utf-8")
        cmd = [self.ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(manifest.resolve()), "-c", "copy", str(output.resolve())]
        p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if p.returncode != 0:
            raise RuntimeError(p.stderr[-3000:])

    def duration(self, media: Path) -> float:
        p = subprocess.run([self.ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(media.resolve())], capture_output=True, text=True, encoding="utf-8", errors="replace")
        if p.returncode != 0:
            raise RuntimeError(p.stderr[-2000:])
        return float(p.stdout.strip())

    def _pool_files(self, candidates: Sequence[Path]) -> list[Path]:
        out: list[Path] = []
        seen = set()
        for root in candidates:
            if not root.exists():
                continue
            for p in sorted(root.rglob("*")):
                if p.is_file() and p.suffix.lower() in AUDIO_EXTS:
                    rp = p.resolve()
                    if rp not in seen:
                        seen.add(rp)
                        out.append(p)
        return out

    def _music_roots(self, preset: str) -> list[Path]:
        # Search narrowly first, then fall back to the existing Drama/general music pool.
        # The user should not need to reorganize existing audio just for Story Motion.
        roots = [self.root / "assets" / "music" / "story_motion" / preset]
        if preset == "horror":
            roots += [
                self.root / "assets" / "music" / "story_motion" / "horror",
                self.root / "assets" / "music" / "drama" / "tense",
                self.root / "assets" / "music" / "drama" / "sad",
                self.root / "assets" / "music" / "drama",
            ]
        else:
            roots += [
                self.root / "assets" / "music" / "story_motion" / "thriller",
                self.root / "assets" / "music" / "drama" / "tense",
                self.root / "assets" / "music" / "drama" / "emotional",
                self.root / "assets" / "music" / "drama",
            ]
        roots += [self.root / "assets" / "music"]
        return roots

    def _pick_music_no_repeat(self, preset: str) -> Path | None:
        files = self._pool_files(self._music_roots(preset))
        if not files:
            return None
        registry = self._read_json(self.music_registry_path, {"version": 1, "used": {}})
        used = registry.setdefault("used", {}).setdefault(preset, [])
        used_set = set(str(x) for x in used)
        available = [p for p in files if str(p.resolve()) not in used_set]
        if not available:
            # Whole pool exhausted: start a fresh round, as requested for Drama too.
            used.clear()
            available = list(files)
        picked = random.choice(available)
        used.append(str(picked.resolve()))
        registry["last_picked"] = {"preset": preset, "path": str(picked.resolve()), "at": time.strftime("%Y-%m-%dT%H:%M:%S")}
        self._write_json(self.music_registry_path, registry)
        return picked

    @staticmethod
    def _sfx_name_matches(category: str, name: str) -> bool:
        n = name.lower().replace('_','-')
        groups = {
            'impacts': ('impact','hit','boom','slam','metal-hit','bass-hit','cinematic-bass'),
            'risers': ('riser','rise','reverse','whoosh','swoosh','cymbal-roll','braam'),
            'heartbeat': ('heartbeat','heart-beat','heart beat','pulse'),
            'ticking': ('ticking','clock-tick','clock ticking','tick-tock','ticktock'),
            'ambience': ('ambience','ambient','wind','hum','rumble','underwater','dark-sound','atmos'),
            'whoosh': ('whoosh','swoosh','reverse'),
        }
        return any(k in n for k in groups.get(category, (category,)))

    def _flat_sfx_files(self, category: str) -> list[Path]:
        root = self.root / 'assets' / 'sfx'
        if not root.exists():
            return []
        out=[]
        for p in root.iterdir():
            if not p.is_file() or p.suffix.lower() not in AUDIO_EXTS:
                continue
            if self._sfx_name_matches(category, p.stem):
                out.append(p)
        return out

    def _pick_sfx(self, category: str) -> Path | None:
        # User does NOT need to manually sort files. Prefer optional category folders,
        # then auto-classify loose assets/sfx/*.mp3 by filename keywords.
        files = self._pool_files([self.root / "assets" / "sfx" / "story_motion" / category])
        files += [p for p in self._flat_sfx_files(category) if p not in files]
        return random.choice(files) if files else None

    def scan_audio(self, preset: str) -> dict:
        def cat(name: str) -> list[str]:
            files=self._pool_files([self.root / "assets" / "sfx" / "story_motion" / name])
            files += [p for p in self._flat_sfx_files(name) if p not in files]
            return [str(p) for p in files]
        result = {
            "bgm": [str(p) for p in self._pool_files(self._music_roots(preset))],
            "impact": cat("impacts"),
            "riser": cat("risers"),
            "heartbeat": cat("heartbeat"),
            "ticking": cat("ticking"),
            "ambience": cat("ambience"),
            "whoosh": cat("whoosh"),
        }
        return result

    def _mix_audio(self, video: Path, output: Path, *, preset: str, scene_durations: Sequence[float]) -> dict:
        duration = self.duration(video)
        bgm = self._pick_music_no_repeat(preset)
        impact = self._pick_sfx("impacts")
        riser = self._pick_sfx("risers")
        ambience = self._pick_sfx("ambience")
        pulse = self._pick_sfx("heartbeat" if preset == "horror" else "ticking")
        whoosh = self._pick_sfx("whoosh")

        print("\n🔊 STORY MOTION AUDIO BED — LOUD MIX V0.4.3")
        print(f"🎵 BGM      : {bgm if bgm else 'NONE FOUND'}")
        print(f"🌫️ Ambience : {ambience if ambience else 'NONE'}")
        print(f"💓 Pulse    : {pulse if pulse else 'NONE'}")
        print(f"💥 Impact   : {impact if impact else 'NONE'}")
        print(f"📈 Riser    : {riser if riser else 'NONE'}")
        print(f"💨 Whoosh   : {whoosh if whoosh else 'NONE'}")

        if not any((bgm, impact, riser, ambience, pulse, whoosh)):
            shutil.copy2(video, output)
            return {"bgm": "", "impact": "", "riser": "", "ambience": "", "pulse": "", "whoosh": "", "note": "No local audio found"}

        inputs = ["-i", str(video.resolve())]
        filters = []
        mix_labels = []
        idx = 1

        if bgm:
            inputs += ["-stream_loop", "-1", "-i", str(bgm.resolve())]
            vol = 0.88 if preset == "horror" else 0.92
            filters.append(f"[{idx}:a]volume={vol},highpass=f=38,lowpass=f=15000,afade=t=in:st=0:d=0.15,afade=t=out:st={max(0,duration-1.2):.3f}:d=1.0[bgm]")
            mix_labels.append("[bgm]")
            idx += 1

        if ambience:
            inputs += ["-stream_loop", "-1", "-i", str(ambience.resolve())]
            filters.append(f"[{idx}:a]volume=0.34,highpass=f=30,lowpass=f=9000[amb]")
            mix_labels.append("[amb]")
            idx += 1

        if pulse:
            inputs += ["-stream_loop", "-1", "-i", str(pulse.resolve())]
            vol = 0.30 if preset == "horror" else 0.27
            filters.append(f"[{idx}:a]volume={vol},highpass=f=25,lowpass=f=8000[pulse]")
            mix_labels.append("[pulse]")
            idx += 1

        # Hook impact at 0 and a smaller impact at selected cuts.
        cut_times = []
        acc = 0.0
        for d in scene_durations[:-1]:
            acc += float(d)
            cut_times.append(acc)

        if impact:
            impact_times = [0.0]
            if cut_times:
                impact_times += [cut_times[len(cut_times)//2]]
                if len(cut_times) >= 3:
                    impact_times.append(cut_times[-1])
            for j, t in enumerate(impact_times):
                inputs += ["-i", str(impact.resolve())]
                delay = max(0, int(t * 1000))
                gain = 1.05 if j == 0 else 0.78
                label = f"imp{j}"
                filters.append(f"[{idx}:a]atrim=0:3,asetpts=PTS-STARTPTS,volume={gain},adelay={delay}|{delay}[{label}]")
                mix_labels.append(f"[{label}]")
                idx += 1

        if riser and cut_times:
            # Put a short riser before selected scene cuts; not every cut, to avoid template spam.
            selected = cut_times[::2][:5]
            for j, t in enumerate(selected):
                start_at = max(0.0, t - 1.5)
                inputs += ["-i", str(riser.resolve())]
                delay = int(start_at * 1000)
                label = f"ris{j}"
                filters.append(f"[{idx}:a]atrim=0:2.2,asetpts=PTS-STARTPTS,volume=0.68,adelay={delay}|{delay}[{label}]")
                mix_labels.append(f"[{label}]")
                idx += 1

        if whoosh and cut_times:
            # Short whoosh at selected scene transitions. Filename auto-classifier means
            # the user does not have to manually move loose SFX into subfolders.
            for j, t in enumerate(cut_times[1::2][:5]):
                inputs += ["-i", str(whoosh.resolve())]
                delay = max(0, int((t - 0.18) * 1000))
                label = f"wh{j}"
                filters.append(f"[{idx}:a]atrim=0:1.3,asetpts=PTS-STARTPTS,volume=0.88,adelay={delay}|{delay}[{label}]")
                mix_labels.append(f"[{label}]")
                idx += 1

        if not mix_labels:
            shutil.copy2(video, output)
        else:
            filters.append(f"{''.join(mix_labels)}amix=inputs={len(mix_labels)}:duration=longest:dropout_transition=0:normalize=0,acompressor=threshold=-16dB:ratio=2.2:attack=12:release=180:makeup=2.0,alimiter=limit=0.96[aout]")
            cmd = [self.ffmpeg, "-y", "-hide_banner", "-loglevel", "error", *inputs, "-filter_complex", ";".join(filters), "-map", "0:v:0", "-map", "[aout]", "-t", f"{duration:.3f}", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest", str(output.resolve())]
            p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
            if p.returncode != 0:
                raise RuntimeError(f"Audio mix failed:\n{p.stderr[-4000:]}")

        return {
            "bgm": str(bgm) if bgm else "",
            "impact": str(impact) if impact else "",
            "riser": str(riser) if riser else "",
            "ambience": str(ambience) if ambience else "",
            "pulse": str(pulse) if pulse else "",
            "whoosh": str(whoosh) if whoosh else "",
        }

    def _update_series_registry(self, *, series_id: str, preset: str, input_dir: Path, plan: dict, parts: list[dict]) -> None:
        reg = self._read_json(self.series_registry_path, {"version": 1, "series": {}})
        entry = reg.setdefault("series", {}).setdefault(series_id, {})
        entry.update({
            "series_id": series_id,
            "preset": preset,
            "title": str(plan.get("title") or input_dir.parent.name or input_dir.name),
            "story_signature": series_id.split("_")[-1],
            "source_dir": str(input_dir),
            "total_parts": len(parts),
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "continuity": {
                "same_story_required": True,
                "same_visual_set_required": True,
                "same_voice_required": True,
                "part_2_requires_part_1_posted": True,
                "micro_recap_seconds_for_next_part": 2.5,
            },
            "parts": parts,
        })
        self._write_json(self.series_registry_path, reg)

    def build(self, *, input_dir: Path, preset: str = "horror", part_mode: str = "auto", music: bool = True) -> dict:
        preset = preset.lower().strip()
        if preset not in {"horror", "thriller"}:
            raise ValueError("preset must be horror or thriller")

        images = self.collect_images(input_dir)
        plan = self._load_optional_plan(input_dir)
        durations = self._scene_durations(len(images), preset, plan)
        part_specs = self._part_specs(images, durations, plan, mode=part_mode)
        signature = self._story_signature(images, preset)
        series_id = str(plan.get("series_id") or f"{preset}_{time.strftime('%Y%m%d')}_{signature}")
        stamp = time.strftime("%Y%m%d_%H%M%S")
        out_dir = self.root / "outputs" / "story_motion_lab" / f"{stamp}_{series_id}"
        out_dir.mkdir(parents=True, exist_ok=True)

        print(f"\n🎬 STORY MOTION LAB V0.2 | {preset.upper()} | series={series_id}")
        print(f"🖼️ Scenes={len(images)} | estimated full duration={sum(durations):.1f}s | parts={len(part_specs)}")

        part_reports = []
        global_scene_index = 1
        for spec in part_specs:
            part_dir = out_dir / f"part_{spec.number:02d}_of_{spec.total:02d}"
            scene_dir = part_dir / "scenes"
            scene_dir.mkdir(parents=True, exist_ok=True)
            rendered = []
            for image, dur in zip(spec.images, spec.durations):
                scene_out = scene_dir / f"scene_{global_scene_index:02d}.mp4"
                self._render_scene(image, scene_out, duration=dur, index=global_scene_index, preset=preset)
                rendered.append(scene_out)
                global_scene_index += 1

            silent = part_dir / f"story_motion_{preset}_part_{spec.number:02d}_silent.mp4"
            self._concat(rendered, silent)
            final = part_dir / f"story_motion_{preset}_part_{spec.number:02d}.mp4"
            audio = self._mix_audio(silent, final, preset=preset, scene_durations=spec.durations) if music else {}
            if not music:
                shutil.copy2(silent, final)

            report = {
                "part": spec.number,
                "total_parts": spec.total,
                "scene_start": spec.start_index + 1,
                "scene_end": spec.end_index,
                "duration_seconds": round(self.duration(final), 3),
                "output": str(final),
                "audio": audio,
                "status": "rendered_not_posted",
                "platform_posts": {},
            }
            part_reports.append(report)
            print(f"✅ Part {spec.number}/{spec.total} → {final}")

        report = {
            "success": True,
            "series_id": series_id,
            "preset": preset,
            "input_dir": str(input_dir),
            "scene_count": len(images),
            "estimated_story_seconds": round(sum(durations), 2),
            "parts": part_reports,
            "series_registry": str(self.series_registry_path),
            "music_registry": str(self.music_registry_path),
            "notes": "Standalone test only; no API generation and no social upload.",
        }
        self._write_json(out_dir / "report.json", report)
        self._update_series_registry(series_id=series_id, preset=preset, input_dir=input_dir, plan=plan, parts=part_reports)
        print(f"🧬 Continuity registry → {self.series_registry_path}")
        print(f"🎵 No-repeat music registry → {self.music_registry_path}")
        return report
