from __future__ import annotations

import asyncio
import base64
import io
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PIL import Image
from google import genai


@dataclass
class _KeyEntry:
    alias: str
    env_name: str
    is_paid: bool = False


class GeminiApiPoolImageService:
    """Gemini native-image worker with a multi-project API-key pool.

    AUTO mode behavior:
      Auto-discovers GEMINI_IMAGE_PROJECT_<N>_KEY variables from .env, sorted
      numerically. GEMINI_IMAGE_PAID_KEY is opt-in only and is OFF by default.

      Example (normal production):
        PROJECT_1 -> PROJECT_2 -> PROJECT_4 -> PROJECT_10 -> stop

      PAID is considered only when ``gemini_api_paid_fallback`` is explicitly
      true, including when manual key mode is used.

    Adding a new numbered project key to .env requires no Python/config edit.
    A successful key remains active until it fails. Quota/auth/model-access
    failures disable that project for the rest of the current story run, then
    the next discovered project is tried. API key values are never printed.
    """

    def __init__(self, config: dict[str, Any]):
        self.config = config
        self.model = str(
            config.get("gemini_api_model") or "gemini-3.1-flash-image"
        ).strip()
        self.mode = str(config.get("gemini_api_key_mode") or "auto").strip().lower()
        self.aspect_ratio = str(
            config.get("gemini_api_aspect_ratio") or "1:1"
        ).strip()
        self.image_size = str(config.get("gemini_api_image_size") or "1K").strip()
        self.mime_type = str(
            config.get("gemini_api_output_mime_type") or "image/jpeg"
        ).strip()

        self.entries = self._load_entries()
        self._clients: dict[str, Any] = {}
        self._disabled_for_run: set[str] = set()
        self._active_alias: str | None = None
        self._missing_warned: set[str] = set()

    @staticmethod
    def discover_env_entries() -> list[_KeyEntry]:
        """Discover numbered project keys from the current environment.

        Canonical env names:
          GEMINI_IMAGE_PROJECT_1_KEY
          GEMINI_IMAGE_PROJECT_2_KEY
          ...
          GEMINI_IMAGE_PROJECT_999_KEY

        Gaps are fine; numeric order is preserved. A configured paid key is
        discovered for explicit opt-in use, but is not eligible by default.
        """
        discovered: list[tuple[int, _KeyEntry]] = []
        pattern = re.compile(r"^GEMINI_IMAGE_PROJECT_(\d+)_KEY$", re.I)

        for env_name, raw_value in os.environ.items():
            match = pattern.match(str(env_name))
            if not match:
                continue
            # Only expose configured keys in the runtime pool/menu.
            if not str(raw_value or "").strip():
                continue
            number = int(match.group(1))
            discovered.append(
                (
                    number,
                    _KeyEntry(
                        alias=f"project_{number}",
                        env_name=str(env_name),
                        is_paid=False,
                    ),
                )
            )

        discovered.sort(key=lambda item: item[0])
        entries = [entry for _, entry in discovered]

        paid_env = "GEMINI_IMAGE_PAID_KEY"
        if str(os.getenv(paid_env) or "").strip():
            entries.append(
                _KeyEntry(alias="paid", env_name=paid_env, is_paid=True)
            )

        return entries

    def _load_entries(self) -> list[_KeyEntry]:
        # Phase 2.0.1: .env is the source of truth for normal numbered projects.
        # This means adding PROJECT_4/5/6... requires no config/code edit.
        dynamic = self.discover_env_entries()
        if dynamic:
            print(
                "🔑 Gemini API pool auto-discovered: "
                + " → ".join(
                    e.alias + (" [PAID]" if e.is_paid else "") for e in dynamic
                )
            )
            return dynamic

        # Backward-compatible fallback for old Phase 2.0 configs when no matching
        # environment variables are currently populated.
        raw = self.config.get("gemini_api_pool") or [
            {
                "alias": "project_1",
                "env": "GEMINI_IMAGE_PROJECT_1_KEY",
                "paid": False,
            },
            {
                "alias": "project_2",
                "env": "GEMINI_IMAGE_PROJECT_2_KEY",
                "paid": False,
            },
            {
                "alias": "project_3",
                "env": "GEMINI_IMAGE_PROJECT_3_KEY",
                "paid": False,
            },
            {
                "alias": "paid",
                "env": "GEMINI_IMAGE_PAID_KEY",
                "paid": True,
            },
        ]

        entries: list[_KeyEntry] = []
        seen: set[str] = set()
        for item in raw:
            if not isinstance(item, dict):
                continue
            alias = str(item.get("alias") or "").strip().lower()
            env_name = str(item.get("env") or "").strip()
            if not alias or not env_name or alias in seen:
                continue
            entries.append(
                _KeyEntry(
                    alias=alias,
                    env_name=env_name,
                    is_paid=bool(item.get("paid", False)),
                )
            )
            seen.add(alias)
        return entries

    def _key_for(self, entry: _KeyEntry) -> str:
        return str(os.getenv(entry.env_name) or "").strip()

    def _entry_by_alias(self, alias: str) -> _KeyEntry | None:
        alias = str(alias or "").strip().lower()
        for entry in self.entries:
            if entry.alias == alias:
                return entry
        return None

    def _ordered_candidates(self) -> list[_KeyEntry]:
        # Manual mode means exactly the selected project/key.
        if self.mode != "auto":
            selected = self._entry_by_alias(self.mode)
            if selected is None:
                aliases = ", ".join(e.alias for e in self.entries)
                raise RuntimeError(
                    f"Unknown Gemini API key mode '{self.mode}'. Available: {aliases}"
                )
            if selected.is_paid and not bool(
                self.config.get("gemini_api_paid_fallback", False)
            ):
                raise RuntimeError(
                    "Paid Gemini image key mode is disabled. Set "
                    "gemini_api_paid_fallback=true explicitly to opt in."
                )
            return [selected]

        candidates = list(self.entries)

        # AUTO keeps using the last successful project until it becomes unavailable.
        if self._active_alias:
            active = self._entry_by_alias(self._active_alias)
            if active in candidates:
                candidates.remove(active)
                candidates.insert(0, active)

        # Paid use must be an explicit config decision; absence always means OFF.
        if bool(self.config.get("gemini_api_paid_fallback", False)):
            free = [e for e in candidates if not e.is_paid]
            paid = [e for e in candidates if e.is_paid]
            candidates = free + paid
        else:
            candidates = [e for e in candidates if not e.is_paid]

        return candidates

    def _client_for(self, entry: _KeyEntry, api_key: str):
        client = self._clients.get(entry.alias)
        if client is None:
            client = genai.Client(api_key=api_key)
            self._clients[entry.alias] = client
        return client

    @staticmethod
    def _reference_payload(reference_image_path: Path) -> dict[str, str]:
        suffix = reference_image_path.suffix.lower()
        mime = {
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".webp": "image/webp",
        }.get(suffix, "image/jpeg")

        data = base64.b64encode(reference_image_path.read_bytes()).decode("ascii")
        return {
            "type": "image",
            "mime_type": mime,
            "data": data,
        }

    def _generate_sync(
        self,
        *,
        entry: _KeyEntry,
        api_key: str,
        prompt: str,
        reference_image_path: Path | None,
    ) -> bytes:
        client = self._client_for(entry, api_key)

        payload: list[dict[str, str]] = [
            {
                "type": "text",
                "text": prompt,
            }
        ]

        if reference_image_path and reference_image_path.exists():
            payload.append(self._reference_payload(reference_image_path))

        try:
            interaction = client.interactions.create(
                model=self.model,
                input=payload,
                response_format={
                    "type": "image",
                    "mime_type": self.mime_type,
                    "aspect_ratio": self.aspect_ratio,
                    "image_size": self.image_size,
                },
            )
        except AttributeError as exc:
            raise RuntimeError(
                "Installed google-genai package is too old for Interactions API. "
                "Run: pip install -U google-genai"
            ) from exc

        output_image = getattr(interaction, "output_image", None)
        data = getattr(output_image, "data", None) if output_image is not None else None
        if not data:
            raise RuntimeError(
                "Gemini returned no output image. This can be a prompt/safety response, "
                "so the key pool will not rotate blindly."
            )

        if isinstance(data, bytes):
            return data
        return base64.b64decode(str(data))

    @staticmethod
    def _save_verified_jpeg(raw_bytes: bytes, save_path: Path) -> None:
        if len(raw_bytes) < 8_000:
            raise RuntimeError(
                f"Gemini image payload is suspiciously small ({len(raw_bytes)} bytes)"
            )

        save_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with Image.open(io.BytesIO(raw_bytes)) as img:
                img.load()
                img.convert("RGB").save(
                    save_path,
                    format="JPEG",
                    quality=95,
                    subsampling=0,
                )
        except Exception as exc:
            raise RuntimeError(f"Gemini image decode/save failed: {exc}") from exc

        if not save_path.exists() or save_path.stat().st_size < 8_000:
            raise RuntimeError(f"Gemini saved image is invalid: {save_path}")

    @staticmethod
    def _classify_error(exc: Exception) -> str:
        text = f"{type(exc).__name__}: {exc}".lower()

        if any(token in text for token in (
            "429",
            "resource_exhausted",
            "resource exhausted",
            "rate limit",
            "rate_limit",
            "quota",
            "too many requests",
        )):
            return "quota"

        if any(token in text for token in (
            "401",
            "unauthenticated",
            "invalid api key",
            "api_key_invalid",
            "api key not valid",
        )):
            return "auth"

        if any(token in text for token in (
            "403",
            "permission_denied",
            "permission denied",
            "not allowed",
            "access denied",
        )):
            return "access"

        if any(token in text for token in (
            "404",
            "model not found",
            "not found for api version",
            "model is not available",
        )):
            return "model_access"

        if any(token in text for token in (
            "timeout",
            "timed out",
            "connection",
            "temporarily unavailable",
            "service unavailable",
            "503",
            "502",
            "504",
        )):
            return "transient"

        return "fatal"

    async def generate_image(
        self,
        *,
        prompt: str,
        save_path: Path,
        reference_image_path: str | Path | None = None,
        slide_index: int | None = None,
    ) -> Path:
        reference: Path | None = None
        if reference_image_path:
            candidate = Path(reference_image_path)
            if candidate.exists():
                reference = candidate

        candidates = self._ordered_candidates()
        if not candidates:
            raise RuntimeError("Gemini API pool has no configured candidates")

        last_exc: Exception | None = None
        manual_mode = self.mode != "auto"
        transient_retries = max(
            0, int(self.config.get("gemini_api_transient_retries_per_key", 1))
        )

        for entry in candidates:
            if entry.alias in self._disabled_for_run:
                continue

            api_key = self._key_for(entry)
            if not api_key:
                if entry.env_name not in self._missing_warned:
                    print(
                        f"➖ Gemini API {entry.alias}: env {entry.env_name} not set — skip"
                    )
                    self._missing_warned.add(entry.env_name)
                if manual_mode:
                    raise RuntimeError(
                        f"Selected Gemini API key '{entry.alias}' is missing. "
                        f"Set {entry.env_name} in .env"
                    )
                continue

            attempts = 1 + transient_retries
            for attempt in range(1, attempts + 1):
                started = time.time()
                label = entry.alias + (" [PAID]" if entry.is_paid else "")
                slide_text = f"Slide {slide_index}" if slide_index else "Image"
                print(f"🖼️ {slide_text} → Gemini API {label} | model={self.model}")

                try:
                    raw = await asyncio.to_thread(
                        self._generate_sync,
                        entry=entry,
                        api_key=api_key,
                        prompt=prompt,
                        reference_image_path=reference,
                    )
                    await asyncio.to_thread(
                        self._save_verified_jpeg,
                        raw,
                        save_path,
                    )

                    elapsed = time.time() - started
                    self._active_alias = entry.alias
                    ref_note = " + reference" if reference else ""
                    print(
                        f"✅ Gemini API {entry.alias}{ref_note} → "
                        f"{save_path.name} ({elapsed:.1f}s)"
                    )
                    return save_path

                except Exception as exc:
                    last_exc = exc
                    kind = self._classify_error(exc)
                    elapsed = time.time() - started

                    if kind == "transient" and attempt < attempts:
                        wait_s = float(
                            self.config.get("gemini_api_transient_retry_delay_seconds", 3)
                        )
                        print(
                            f"⚠️ Gemini API {entry.alias} transient error "
                            f"({elapsed:.1f}s) → retry {attempt}/{attempts - 1}: {exc}"
                        )
                        await asyncio.sleep(wait_s)
                        continue

                    if kind in {"quota", "auth", "access", "model_access"}:
                        self._disabled_for_run.add(entry.alias)
                        reason = {
                            "quota": "quota/rate limit",
                            "auth": "invalid/auth key",
                            "access": "project/model permission",
                            "model_access": "model unavailable",
                        }[kind]
                        print(
                            f"⚠️ Gemini API {entry.alias} → {reason}; "
                            "disabled for this story run"
                        )

                        if manual_mode:
                            raise RuntimeError(
                                f"Selected Gemini API key '{entry.alias}' failed: {exc}"
                            ) from exc

                        print("🔄 AUTO POOL → trying next configured project")
                        break

                    # Don't rotate keys for prompt/safety/unknown fatal errors.
                    raise RuntimeError(
                        f"Gemini image generation failed on {entry.alias}: {exc}"
                    ) from exc

        configured = [
            e.alias
            for e in candidates
            if self._key_for(e)
        ]
        configured_text = ", ".join(configured) if configured else "none"
        raise RuntimeError(
            "Gemini API pool exhausted for this story run. "
            f"Configured candidates: {configured_text}. Last error: {last_exc}"
        )
