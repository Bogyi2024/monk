from __future__ import annotations

from pathlib import Path
from typing import Any

from services.tt_recap_bridge import TTRecapBridge
from services.tt_drama_bridge import TTDramaBridge
from services.tt_story_motion_bridge import TTStoryMotionBridge
from services.tt_astrology_bridge import TTAstrologyBridge
from bridges.long_to_short_bridge import TTLongToShortBridge
from bridges.episode_splitter_bridge import TTEpisodeSplitterBridge
from services.tt_novel_bridge import TTNovelBridge
from services.tt_movie_review_bridge import TTMovieReviewBridge
from services.tt_content_category_registry import CONTENT_CATEGORY_REGISTRY, content_category
from services.tt_external_worker_bridge import TTExternalWorkerBridge
from services.post_publish_cleanup import PostPublishCleanup


class TTPipelineService:
    BUILTIN_BRIDGES = {
        "recap": TTRecapBridge,
        "drama": TTDramaBridge,
        "story_motion": TTStoryMotionBridge,
        "astrology": TTAstrologyBridge,
        "long_to_short": TTLongToShortBridge,
        "episode_splitter": TTEpisodeSplitterBridge,
        "novel": TTNovelBridge,
        "movie_review": TTMovieReviewBridge,
    }

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings = settings_service
        self.root = Path(project_root).resolve()
        self._bridges: dict[str, Any] = {}

    def capabilities(self) -> dict[str, dict[str, Any]]:
        recap_file = any((self.root / x).exists() for x in TTRecapBridge.CANDIDATES)
        drama_files = [
            "services/story_carousel_service.py",
            "services/story_carousel_upload_service.py",
            "services/story_narration_service.py",
            "services/story_motion_video_service.py",
            "config/story_video.json",
        ]
        drama_ok = all((self.root / x).exists() for x in drama_files)
        story_motion_files = [
            "services/tt_story_motion_bridge.py",
            "services/story_motion_production_service.py",
            "services/story_motion_lab_service.py",
            "story_motion_production_test.py",
            "config/story_motion_production.json",
            "config/story_motion_pipeline.json",
        ]
        story_motion_ok = all((self.root / x).exists() for x in story_motion_files)
        result = {
            "recap": {"live": recap_file, "label": "LIVE" if recap_file else "Missing recap runner"},
            "drama": {"live": drama_ok, "label": "LIVE" if drama_ok else "Drama files missing"},
            "story_motion": {"live": story_motion_ok, "label": "LIVE" if story_motion_ok else "Story Motion files missing"},
            "astrology": {"live": all((self.root / x).exists() for x in ["services/tt_astrology_bridge.py","services/astrology_real_output_service.py","config/astrology_real_output_test.json"]), "label": "LIVE" if all((self.root / x).exists() for x in ["services/tt_astrology_bridge.py","services/astrology_real_output_service.py","config/astrology_real_output_test.json"]) else "Astrology files/config missing"},
            "long_to_short": TTLongToShortBridge.capability(self.root),
            "episode_splitter": TTEpisodeSplitterBridge.capability(self.root),
            "novel": TTNovelBridge.capability(self.root),
            "movie_review": TTMovieReviewBridge.capability(self.root),
            "story_animation": {"live": False, "label": "Not connected yet"},
        }
        for key, definition in CONTENT_CATEGORY_REGISTRY.items():
            if key in result or definition.get("processor_kind") != "external_python":
                continue
            result[key] = TTExternalWorkerBridge.capability(key, self.root)
        for key, definition in CONTENT_CATEGORY_REGISTRY.items():      # Studio99 Desktop: Posting list
            if definition.get("processor_kind") == "studio99_posting":
                result[key] = {"live": True, "label": "LIVE — POSTING LIST"}
        return result

    def _bridge(self, key: str):
        if key not in self._bridges:
            bridge_type = self.BUILTIN_BRIDGES.get(key)
            if bridge_type is not None:
                self._bridges[key] = bridge_type(self.settings, self.root)
            else:
                definition = content_category(key) or {}
                if definition.get("processor_kind") == "external_python":
                    self._bridges[key] = TTExternalWorkerBridge(key, self.settings, self.root)
                elif definition.get("processor_kind") == "studio99_posting":     # Studio99 Desktop
                    from studio99.posting_bridge import PostingListBridge
                    self._bridges[key] = PostingListBridge(key, self.settings, self.root)
                else:
                    raise RuntimeError(f"Pipeline not connected yet: {key}")
        return self._bridges[key]

    async def run_once(self, key: str, route_key: str = "default") -> dict[str, Any]:
        cap = self.capabilities().get(key) or {"live": False}
        if not cap.get("live"):
            raise RuntimeError(cap.get("label") or f"Pipeline not connected: {key}")
        result = await self._bridge(key).run_once(route_key=route_key)
        try:
            PostPublishCleanup(self.root).record_result(key, result)
        except Exception as exc:
            print(f'⚠️ Cleanup completion receipt warning: {exc}')
        return result
