from __future__ import annotations

import copy
from datetime import datetime, timedelta
from typing import Any

from services.tt_route_runtime_service import TTRouteRuntimeService
from services.tt_preparation_status_service import TTPreparationStatusService


class TTRollingScheduleService:
    """Real-time rolling scheduler.

    Nothing is permanently time-slotted at START TODAY.
    After each actual job completion the next job is recalculated from:
      - current local time
      - remaining count in Today Control
      - category earliest/latest times
      - category preferred/minimum cadence
      - optional preferred/peak windows
      - actual runtime history
      - one-process sequential queue availability
    """

    DEFAULT_POLICY = {
        "earliest_start": "09:00",
        "latest_finish": "20:50",
        "preferred_gap_minutes": 120,
        "minimum_gap_minutes": 90,
        "estimated_runtime_minutes": 20,
        "priority": 50,
        "prefer_preferred_windows": False,
        "preferred_windows_only": False,
        "preferred_windows": [],
    }

    def __init__(self, settings_service):
        self.settings = settings_service
        self.route_runtime = TTRouteRuntimeService(settings_service)
        self.preparation = TTPreparationStatusService(settings_service, getattr(settings_service, "root", "."))

    @staticmethod
    def _clock(day: datetime, hhmm: str, fallback: str) -> datetime:
        try:
            h,m=[int(x) for x in str(hhmm or fallback).split(':',1)]
        except Exception:
            h,m=[int(x) for x in fallback.split(':',1)]
        return day.replace(hour=h,minute=m,second=0,microsecond=0)

    @staticmethod
    def _iso(value: str | None) -> datetime | None:
        if not value:return None
        try:
            dt=datetime.fromisoformat(str(value).replace('Z','+00:00'))
            if dt.tzinfo is None:dt=dt.astimezone()
            return dt
        except Exception:return None

    @staticmethod
    def _target(row: dict[str,Any]) -> int:
        raw=row.get('target_override')
        return max(0,int(raw if raw is not None else row.get('normal_target') or 0))

    @classmethod
    def _remaining(cls,row:dict[str,Any])->int:
        return max(0,cls._target(row)-max(0,int(row.get('already_posted') or 0)))

    def policy(self,key:str)->dict[str,Any]:
        cats=self.settings.categories().get('categories',{})
        c=cats.get(key) or {}
        p=dict(self.DEFAULT_POLICY)
        p.update(c.get('schedule_policy') or {})
        p['preferred_gap_minutes']=max(1,int(p.get('preferred_gap_minutes') or 120))
        p['minimum_gap_minutes']=max(1,min(p['preferred_gap_minutes'],int(p.get('minimum_gap_minutes') or 90)))
        p['estimated_runtime_minutes']=max(1,int(p.get('estimated_runtime_minutes') or 20))
        p['priority']=int(p.get('priority') or 50)
        wins=[]
        for w in p.get('preferred_windows') or []:
            if isinstance(w,dict) and w.get('start') and w.get('end'):
                wins.append({'start':str(w['start']),'end':str(w['end'])})
        p['preferred_windows']=wins[:4]
        return p

    def runtime_minutes(self,key:str,row:dict[str,Any])->float:
        samples=[]
        for x in row.get('runtime_samples_seconds') or []:
            try:
                v=float(x)
                if 20 <= v <= 4*3600:samples.append(v)
            except Exception:pass
        if samples:
            recent=samples[-8:]
            return round(sum(recent)/len(recent)/60.0,1)
        return float(self.policy(key)['estimated_runtime_minutes'])

    def _global_bounds(self,now:datetime)->tuple[datetime,datetime]:
        sch=self.settings.scheduler()
        win=sch.get('posting_window') or {'start':'09:00','end':'21:00'}
        catch=sch.get('adaptive_catchup') or {}
        start=self._clock(now,win.get('start','09:00'),'09:00')
        end=self._clock(now,win.get('end','21:00'),'21:00')
        end-=timedelta(minutes=max(0,int(catch.get('end_buffer_minutes',10))))
        return start,end

    def _bounds(self,key:str,now:datetime)->tuple[datetime,datetime]:
        gs,ge=self._global_bounds(now)
        p=self.policy(key)
        cs=self._clock(now,p.get('earliest_start'),'09:00')
        ce=self._clock(now,p.get('latest_finish'),'20:50')
        return max(gs,cs),min(ge,ce)

    def _window_points(self,key:str,now:datetime)->list[tuple[datetime,datetime]]:
        p=self.policy(key); start,end=self._bounds(key,now)
        out=[]
        for w in p.get('preferred_windows') or []:
            a=max(start,self._clock(now,w.get('start'),'09:00'))
            b=min(end,self._clock(now,w.get('end'),'20:50'))
            if b>a:out.append((a,b))
        return sorted(out,key=lambda x:x[0])

    def _apply_preferred_window(self,key:str,candidate:datetime,latest_start:datetime,remaining:int,runtime:float,now:datetime)->tuple[datetime|None,bool,str]:
        p=self.policy(key); wins=self._window_points(key,now)
        if not wins or not (p.get('prefer_preferred_windows') or p.get('preferred_windows_only')):
            return candidate,False,'allowed_window'
        for a,b in wins:
            if a <= candidate <= b:
                return candidate,True,'preferred_window_active'
        future=[]
        for a,b in wins:
            if b < candidate:continue
            future.append(max(candidate,a))
        if not future:
            if p.get('preferred_windows_only'):return None,False,'no_peak_window_left'
            return candidate,False,'outside_preferred_window'
        nxt=future[0]
        if p.get('preferred_windows_only'):
            return (nxt if nxt<=latest_start else None),True,'peak_only_wait'
        # Prefer waiting only when the category can still fit its remaining work at min cadence.
        min_gap=float(p['minimum_gap_minutes'])
        rough_need=remaining*runtime + max(0,remaining-1)*min_gap
        finish_if_wait=nxt+timedelta(minutes=rough_need)
        _,latest_finish=self._bounds(key,now)
        if finish_if_wait <= latest_finish+timedelta(minutes=runtime):
            return (nxt if nxt<=latest_start else candidate),True,'wait_for_preferred_window'
        return candidate,False,'use_allowed_window_to_finish_target'

    def _prepared_allowed_routes(self,key:str,row:dict[str,Any],state:dict[str,Any],now:datetime)->set[str]|None:
        cat=((self.settings.categories().get("categories") or {}).get(key) or {})
        if str(cat.get("production_mode") or "") != "prepared_inventory":
            return None
        if row.get("pending_retry") and row.get("pending_route_key"):
            return {str(row.get("pending_route_key"))}
        budget=((state.get("_prepared_inventory_budget") or {}).get(key))
        if isinstance(budget,dict):
            return {str(rk) for rk,count in budget.items() if int(count or 0)>0}
        return self.preparation.ready_route_keys(key,now) or set()

    def category_candidate(self,key:str,row:dict[str,Any],state:dict[str,Any],now:datetime)->dict[str,Any]:
        remaining=self._remaining(row); p=self.policy(key); runtime=self.runtime_minutes(key,row)
        start,finish=self._bounds(key,now); latest_start=finish-timedelta(minutes=runtime)
        result={'category':key,'remaining':remaining,'runtime_minutes':runtime,'policy':p,'candidate':None,'eligible_now':False,'reason':'','preferred_active':False,'latest_start':latest_start}
        if not row.get('run_today',False):result['reason']='paused_today';return result
        if remaining<=0:result['reason']='target_complete';return result
        if now>latest_start:result['reason']='too_late_for_safe_finish';return result

        sch=self.settings.scheduler(); catch=sch.get('adaptive_catchup') or {}
        rolling=sch.get('rolling_realtime') or {}
        arm=self._iso(state.get('armed_at')) or now
        first_delay=max(0,int(catch.get('first_post_delay_minutes',5)))
        base=max(now,start)

        # V1.7.3 failure backoff: a failed category does not immediately
        # reclaim the queue. The candidate becomes eligible again only after
        # its real cooldown timestamp; other categories may run meanwhile.
        # Ordinary failures in a multi-route category cool only the route that
        # failed. Pending destination retries stay category-locked by design.
        category_cooldown_applies=len(self.route_runtime.enabled_routes(key))<=1 or bool(row.get('pending_retry'))
        cooldown_until=self._iso(row.get('failure_cooldown_until')) if category_cooldown_applies else None
        cooldown_active=bool(cooldown_until and cooldown_until>now)
        if cooldown_active:
            base=max(base,cooldown_until)

        no_work_until=self._iso(row.get('no_work_until'))
        no_work_active=bool(no_work_until and no_work_until>now)
        if no_work_active:
            base=max(base,no_work_until)

        manual_skip_until=self._iso(row.get('manual_skip_until'))
        manual_skip_active=bool(manual_skip_until and manual_skip_until>now)
        if manual_skip_active:
            base=max(base,manual_skip_until)

        # V1.7.1 hard sequential turn buffer. Even when two categories become
        # eligible at the same clock time, only one can execute. After the
        # previous real job finishes, every category waits until the global
        # inter-job buffer has elapsed before it can become runnable.
        last_global_finish=None
        for _row in (state.get('categories') or {}).values():
            _dt=self._iso(_row.get('last_finished_at'))
            if _dt and (last_global_finish is None or _dt>last_global_finish):
                last_global_finish=_dt
        if last_global_finish is not None:
            turn_buffer=max(0,int(rolling.get('inter_job_buffer_minutes',2)))
            base=max(base,last_global_finish+timedelta(minutes=turn_buffer))

        # V2 route/page scheduler: when a category has routes, spacing belongs
        # to the actual FB Page/TikTok destination. Different categories/routes may
        # therefore run close together when they target different pages.
        if self.route_runtime.routes(key):
            pending_route=str(row.get('pending_route_key') or '') if row.get('pending_retry') else ''
            allowed_routes=self._prepared_allowed_routes(key,row,state,now)
            chosen_route=self.route_runtime.choose_route(state,key,now,base,finish,pending_route_key=pending_route,allowed_route_keys=allowed_routes)
            if chosen_route is None:
                result['reason']=self.route_runtime.unavailable_reason(state,key,now,base,finish,allowed_route_keys=allowed_routes)
                return result
            candidate=max(base,chosen_route['candidate'])
            route_latest=chosen_route.get('latest_start') or latest_start
            latest_start=min(latest_start,route_latest)
            if candidate>latest_start:
                result['reason']='route_page_gap_too_late_for_safe_finish'
                return result
            result.update({
                'candidate':candidate,
                'eligible_now':candidate<=now+timedelta(seconds=1),
                'reason':('pending_retry:' if row.get('pending_retry') else '')+str(chosen_route.get('reason') or 'route_ready'),
                'preferred_active':False,
                'slack_minutes':round((finish-candidate).total_seconds()/60.0,1),
                'priority':int(chosen_route.get('priority',p['priority'])),
                'runtime_minutes':float(chosen_route.get('runtime_minutes',runtime)),
                'route_key':chosen_route.get('route_key'),
                'route_label':chosen_route.get('route_label'),
                'route_policy':chosen_route.get('policy') or {},
                'destination_keys':chosen_route.get('destination_keys') or [],
                'last_route_completed_at':chosen_route.get('last_route_completed_at') or '',
                'latest_start':latest_start,
            })
            return result

        last=self._iso(row.get('last_completed_at'))
        if last:
            pref=float(p['preferred_gap_minutes']); minimum=float(p['minimum_gap_minutes'])
            nominal_due=last+timedelta(minutes=pref)
            min_due=last+timedelta(minutes=minimum)
            # If nominal cadence can still finish all remaining category items, keep it.
            nominal_last_finish=nominal_due+timedelta(minutes=(remaining-1)*(pref+runtime)+runtime)
            if nominal_last_finish <= finish:
                due=nominal_due; cadence='preferred_gap'
            else:
                available=max(0.0,(latest_start-min_due).total_seconds()/60.0)
                if remaining<=1:
                    dynamic=minimum
                else:
                    dynamic=max(minimum,min(pref,available/max(1,remaining-1)))
                due=last+timedelta(minutes=dynamic); cadence='compressed_gap'
            candidate=max(base,due)
        else:
            # At first scheduler start give browser/services a small warm-up delay.
            no_master_success=not bool(row.get('last_completed_at'))
            warm=arm+timedelta(minutes=first_delay) if no_master_success else arm
            candidate=max(base,warm); cadence='first_job'

        candidate,preferred,window_reason=self._apply_preferred_window(key,candidate,latest_start,remaining,runtime,now)
        if candidate is None:
            result['reason']=window_reason;return result
        if candidate>latest_start:
            result['reason']='too_late_after_window_rules';return result

        need=remaining*runtime+max(0,remaining-1)*float(p['minimum_gap_minutes'])
        slack=(finish-now).total_seconds()/60.0-need
        active_pref=any(a<=now<=b for a,b in self._window_points(key,now))
        result.update({
            'candidate':candidate,
            'eligible_now':candidate<=now+timedelta(seconds=1),
            'reason':f"{'manual_skip:' if manual_skip_active else ''}{'failure_cooldown:' if cooldown_active else ''}{'no_content_wait:' if no_work_active else ''}{'pending_retry:' if row.get('pending_retry') else ''}{cadence}:{window_reason}",
            'preferred_active':active_pref,
            'slack_minutes':round(slack,1),
            'priority':int(p['priority']),
        })
        return result

    def _fair_shared_destination_choice(self,state:dict[str,Any],ordered:list[dict[str,Any]],chosen:dict[str,Any],now:datetime)->dict[str,Any]:
        """Rotate ready cards that publish to the same Page/account.

        Normal priority still chooses between unrelated destinations.  Fairness
        is applied only inside the chosen destination group, so a high-volume
        card cannot keep resetting the shared Page clock ahead of its sibling.
        """
        destinations=set(chosen.get('destination_keys') or [])
        if not destinations:return chosen
        if chosen['candidate']<=now+timedelta(seconds=1):
            contenders=[c for c in ordered if c['candidate']<=now+timedelta(seconds=1) and destinations.intersection(c.get('destination_keys') or [])]
        else:
            cutoff=chosen['candidate']+timedelta(seconds=1)
            contenders=[c for c in ordered if c['candidate']<=cutoff and destinations.intersection(c.get('destination_keys') or [])]
        if len(contenders)<=1:return chosen

        def fairness_key(c:dict[str,Any]):
            pending=bool((state.get('categories',{}).get(c['category'],{}).get('pending_retry')))
            completed=self._iso(c.get('last_route_completed_at'))
            # Never-posted/least-recently-posted card gets the next shared Page turn.
            completed_ts=completed.timestamp() if completed else float('-inf')
            return (0 if pending else 1,completed_ts,-int(c.get('priority',50)),c['category'],str(c.get('route_key') or ''))

        return min(contenders,key=fairness_key)

    def next_decision(self,state:dict[str,Any],now:datetime|None=None)->dict[str,Any]:
        now=now or datetime.now().astimezone()
        if not state.get('armed'):
            return {'status':'not_armed','next_category':None,'next_at':None,'candidates':[]}
        if state.get('current_job'):
            return {'status':'running','next_category':None,'next_at':None,'candidates':[]}
        candidates=[]
        for key,row in (state.get('categories') or {}).items():
            c=self.category_candidate(key,row,state,now)
            if c.get('candidate') is not None:candidates.append(c)
        if not candidates:
            remaining=sum(self._remaining(r) for r in (state.get('categories') or {}).values() if r.get('run_today'))
            return {'status':'complete' if remaining<=0 else 'no_safe_slot','next_category':None,'next_at':None,'candidates':[],'remaining':remaining}

        eligible=[c for c in candidates if c['eligible_now']]
        last_cat=str(state.get('last_job_category') or '')
        if eligible:
            # Active preferred window first, then urgency (small slack), configured priority,
            # and finally avoid immediately repeating the same category when another is ready.
            eligible.sort(key=lambda c:(0 if (state.get('categories',{}).get(c['category'],{}).get('pending_retry')) else 1,0 if c.get('preferred_active') else 1,float(c.get('slack_minutes',999999)),-int(c.get('priority',50)),1 if c['category']==last_cat else 0,c['category']))
            chosen=self._fair_shared_destination_choice(state,eligible,eligible[0],now);status='run_now'
        else:
            candidates.sort(key=lambda c:(c['candidate'],0 if (state.get('categories',{}).get(c['category'],{}).get('pending_retry')) else 1,0 if c.get('preferred_active') else 1,-int(c.get('priority',50))))
            chosen=self._fair_shared_destination_choice(state,candidates,candidates[0],now);status='wait'
        return {'status':status,'next_category':chosen['category'],'next_route':chosen.get('route_key') or 'default','next_at':chosen['candidate'],'reason':chosen.get('reason'),'candidate':chosen,'candidates':candidates}

    def _simulate_projection(self,state:dict[str,Any],now:datetime,max_jobs:int=30)->list[dict[str,Any]]:
        sim=copy.deepcopy(state); sim['current_job']=None
        if not isinstance(sim.get('_prepared_inventory_budget'),dict):
            budget={}
            for cat_key,cat_row in (sim.get('categories') or {}).items():
                cat_cfg=((self.settings.categories().get('categories') or {}).get(cat_key) or {})
                if str(cat_cfg.get('production_mode') or '')!='prepared_inventory':
                    continue
                budget[cat_key]={rk:int(self.preparation.route_ready_count(cat_key,rk,now) or 0) for rk in self.route_runtime.enabled_routes(cat_key)}
            sim['_prepared_inventory_budget']=budget
        sch=self.settings.scheduler(); rolling=sch.get('rolling_realtime') or {}
        buffer_min=max(0,int(rolling.get('inter_job_buffer_minutes',2)))
        out=[]; cursor=now
        for _ in range(max_jobs):
            d=self.next_decision(sim,cursor)
            if d.get('status') not in {'run_now','wait'} or not d.get('next_category'):break
            key=d['next_category']; route_key=str(d.get('next_route') or 'default'); start=max(cursor,d['next_at']); row=sim['categories'][key]
            runtime=float((d.get('candidate') or {}).get('runtime_minutes') or self.runtime_minutes(key,row)); finish=start+timedelta(minutes=runtime)
            out.append({'category':key,'route_key':route_key,'route_label':str((d.get('candidate') or {}).get('route_label') or route_key),'start':start,'finish':finish,'runtime_minutes':runtime,'reason':d.get('reason',''),'preferred':bool(d.get('candidate',{}).get('preferred_active'))})
            row['already_posted']=int(row.get('already_posted') or 0)+1
            row['last_completed_at']=finish.isoformat(timespec='seconds')
            self.route_runtime.mark_finished(sim,key,route_key,finish,True)
            _pb=((sim.get('_prepared_inventory_budget') or {}).get(key))
            if isinstance(_pb,dict) and route_key in _pb:
                _pb[route_key]=max(0,int(_pb.get(route_key) or 0)-1)
            sim['last_job_category']=key; sim['last_job_route']=route_key
            cursor=finish+timedelta(minutes=buffer_min)
        return out

    def live_status(self,state:dict[str,Any],now:datetime|None=None)->dict[str,Any]:
        now=now or datetime.now().astimezone(); working=copy.deepcopy(state)
        _budget={}
        for _ck,_cr in (working.get('categories') or {}).items():
            _cc=((self.settings.categories().get('categories') or {}).get(_ck) or {})
            if str(_cc.get('production_mode') or '')=='prepared_inventory':
                _budget[_ck]={rk:int(self.preparation.route_ready_count(_ck,rk,now) or 0) for rk in self.route_runtime.enabled_routes(_ck)}
        working['_prepared_inventory_budget']=_budget
        current=working.get('current_job'); current_info=None; projection_start=now
        if current:
            key=str(current.get('category') or '')
            started=self._iso(current.get('started_at')) or now
            row=working.get('categories',{}).get(key,{})
            runtime=self.runtime_minutes(key,row)
            est_finish=max(now,started+timedelta(minutes=runtime))
            current_route=str(current.get('route_key') or 'default'); current_info={'category':key,'route_key':current_route,'started_at':started.isoformat(timespec='seconds'),'elapsed_minutes':round(max(0,(now-started).total_seconds()/60.0),1),'estimated_finish':est_finish.isoformat(timespec='minutes'),'estimated_runtime_minutes':runtime,'job_id':current.get('job_id','')}
            # Project the queue after the current job succeeds.
            working['current_job']=None
            if key in working.get('categories',{}):
                working['categories'][key]['already_posted']=int(working['categories'][key].get('already_posted') or 0)+1
                working['categories'][key]['last_completed_at']=est_finish.isoformat(timespec='seconds')
                self.route_runtime.mark_finished(working,key,current_route,est_finish,True)
                _pb=((working.get('_prepared_inventory_budget') or {}).get(key))
                if isinstance(_pb,dict) and current_route in _pb:
                    _pb[current_route]=max(0,int(_pb.get(current_route) or 0)-1)
            working['last_job_category']=key; working['last_job_route']=current_route; projection_start=est_finish

        projection=self._simulate_projection(working,projection_start)
        first_projected_by_category={}
        first_projected_by_route={}
        for _item in projection:
            first_projected_by_category.setdefault(_item['category'],_item)
            first_projected_by_route.setdefault((_item['category'],str(_item.get('route_key') or 'default')),_item)
        rows=[]; total_remaining=0
        all_cats=self.settings.categories().get('categories') or {}
        rr_state=((state.get('route_runtime') or {}).get('routes') or {})
        for key,row in (state.get('categories') or {}).items():
            target=self._target(row); remaining=self._remaining(row) if row.get('run_today') else 0
            total_remaining+=remaining
            cand=self.category_candidate(key,row,state,now)
            _q=first_projected_by_category.get(key)
            route_rows=[]
            enabled=self.route_runtime.enabled_routes(key)
            single_enabled=len(enabled)==1
            cat_cfg=all_cats.get(key) or {}
            # Novel inventory is useful even while its routes are OFF. Keep all
            # configured Novel routes in this read-model so the dashboard can
            # expand the category and explain each route's state.
            display_routes=self.route_runtime.routes(key) if key=='novel' else enabled
            for rk,route in display_routes.items():
                route_enabled=rk in enabled
                rr=((rr_state.get(key) or {}).get(rk) or {})
                rdone=max(0,int(rr.get('already_posted') or 0))
                rtarget=target if route_enabled and single_enabled else max(0,int(route.get('daily_limit') or 0))
                rremaining=max(0,rtarget-rdone) if route_enabled and row.get('run_today') else 0
                rq=first_projected_by_route.get((key,rk))
                rpolicy=self.route_runtime.route_policy(key,rk)
                ready_count=self.preparation.route_ready_count(key,rk,now)
                active_count=self.preparation.lts_route_active_count(rk) if key=='long_to_short' else None
                if not route_enabled:
                    rreason='disabled'
                elif ready_count is not None and ready_count<=0 and not (row.get('pending_retry') and str(row.get('pending_route_key') or '')==rk):
                    rreason='waiting_for_preparation'
                else:
                    rreason=(rq or {}).get('reason') or ''
                route_rows.append({
                    'route_key':rk,'route_label':str(route.get('label') or rk),'target':rtarget,'already_posted':rdone,'remaining':rremaining,
                    'last_started_at':rr.get('last_started_at',''),'last_completed_at':rr.get('last_completed_at',''),'last_finished_at':rr.get('last_finished_at',''),
                    'failure_cooldown_until':rr.get('failure_cooldown_until',''),'consecutive_failures':int(rr.get('consecutive_failures') or 0),'last_error':rr.get('last_error',''),
                    'runtime_minutes':float(rpolicy.get('estimated_runtime_minutes') or self.runtime_minutes(key,row)),
                    'next_queue_at':rq['start'].isoformat(timespec='minutes') if rq else None,
                    'next_queue_finish':rq['finish'].isoformat(timespec='minutes') if rq else None,
                    'candidate_reason':rreason,'prepared_ready':ready_count,'prepared_active':active_count,
                    'output_mode':str(route.get('output_type') or ''),'enabled':route_enabled,
                })
            rows.append({'category':key,'run_today':bool(row.get('run_today')),'target':target,'already_posted':int(row.get('already_posted') or 0),'remaining':remaining,'last_started_at':row.get('last_started_at',''),'last_completed_at':row.get('last_completed_at',''),'runtime_minutes':self.runtime_minutes(key,row),'candidate_at':cand.get('candidate').isoformat(timespec='minutes') if cand.get('candidate') else None,'candidate_reason':cand.get('reason'),'next_queue_at':_q['start'].isoformat(timespec='minutes') if _q else None,'next_queue_finish':_q['finish'].isoformat(timespec='minutes') if _q else None,'failure_cooldown_until':row.get('failure_cooldown_until',''),'no_work_until':row.get('no_work_until',''),'manual_skip_until':row.get('manual_skip_until',''),'pending_retry':bool(row.get('pending_retry')),'consecutive_failures':int(row.get('consecutive_failures') or 0),'policy':self.policy(key),'next_route_key':cand.get('route_key'),'next_route_label':cand.get('route_label'),'routes':route_rows})

        next_item=projection[0] if projection else None
        projected_end=projection[-1]['finish'] if projection else (self._iso(current_info['estimated_finish']) if current_info else None)
        safe_end=self._global_bounds(now)[1]
        projected_jobs=len(projection)+(1 if current_info else 0)
        # total_remaining includes current until success, so compare directly.
        can_finish=(projected_jobs>=total_remaining) if total_remaining else True
        activity=list(state.get('events') or [])[-30:]
        preparation=self.preparation.snapshot(now)
        # Read-model only: attach today's existing route/day completion state to
        # the LTS posting inventory. Standalone inventory and pending semantics
        # are untouched.
        lts_row=next((x for x in rows if x.get('category')=='long_to_short'),None)
        if lts_row:
            route_map={str(x.get('route_key') or ''):x for x in (lts_row.get('routes') or [])}
            for item in (((preparation.get('long_to_short') or {}).get('today_routes')) or []):
                rr=route_map.get(str(item.get('route_key') or '')) or {}
                item['posted']=max(0,int(rr.get('already_posted') or 0))
                item['target']=max(0,int(rr.get('target') if rr.get('target') is not None else item.get('target') or 0))
                if item.get('active') is None:
                    item['active']=max(0,int(rr.get('prepared_active') or 0))
        return {
            'engine':'rolling_realtime_v2_route_page_gap',
            'now':now.isoformat(timespec='seconds'),
            'armed':bool(state.get('armed')),
            'stop_after_current':bool(state.get('stop_after_current')),
            'current':current_info,
            'next':{'category':next_item['category'],'route_key':next_item.get('route_key','default'),'route_label':next_item.get('route_label',''),'start':next_item['start'].isoformat(timespec='minutes'),'finish':next_item['finish'].isoformat(timespec='minutes'),'reason':next_item['reason']} if next_item else None,
            'upcoming':[{'category':x['category'],'route_key':x.get('route_key','default'),'route_label':x.get('route_label',''),'start':x['start'].isoformat(timespec='minutes'),'finish':x['finish'].isoformat(timespec='minutes'),'runtime_minutes':x['runtime_minutes'],'reason':x['reason'],'preferred':x['preferred']} for x in projection[:12]],
            'categories':rows,
            'remaining_total':total_remaining,
            'safe_end':safe_end.isoformat(timespec='minutes'),
            'time_left_minutes':max(0,round((safe_end-now).total_seconds()/60.0)),
            'projected_end':projected_end.isoformat(timespec='minutes') if projected_end else None,
            'can_finish_today':can_finish,
            'preparation':preparation,
            'activity':activity,
        }
