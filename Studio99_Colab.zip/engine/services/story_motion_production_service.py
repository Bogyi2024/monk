from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from services.story_motion_lab_service import StoryMotionLabService
from story_motion_production_test import ProductionTest, write_json, read_json


class StoryMotionProductionService:
    """Reusable Story Motion engine, independent from Story Board Drama.

    Production rule:
      1 story/visual set -> reusable across languages/routes.
      Each story scene gets its own voice-locked Gemini WAV. Subtitle chunks are
      changed only at verified pauses inside that scene WAV.
    """

    def __init__(self, project_root: str | Path = ".", config_path: str | Path = "config/story_motion_production.json"):
        self.root=Path(project_root).resolve();cfg_path=Path(config_path)
        if not cfg_path.is_absolute():cfg_path=self.root/cfg_path
        self.config_path=cfg_path;self.cfg=json.loads(cfg_path.read_text(encoding="utf-8"))
        self.engine=ProductionTest();self.engine.cfg=dict(self.cfg)
        # Production Story Motion owns its image route. ProductionTest constructs a
        # generic StoryCarouselService first, so explicitly copy only the supported
        # image knobs instead of silently inheriting FLUX.2 from story_carousel.json.
        for key in (
            "image_provider","fal_model","fal_width","fal_height",
            "fal_guidance_scale","fal_num_inference_steps","fal_output_format",
            "fal_timeout_seconds","fal_poll_interval_seconds",
        ):
            if key in self.cfg:
                self.engine.story.config[key]=self.cfg[key]
        output_root=Path(str(self.cfg.get("output_root") or "outputs/story_motion"))
        self.engine.output_root=output_root if output_root.is_absolute() else self.root/output_root
        self.engine.state=self.root/"state";self.engine.state.mkdir(parents=True,exist_ok=True)
        self.engine.fx=StoryMotionLabService(self.root,motion_config=self.cfg.get("motion_fx",{}))

    @staticmethod
    def _normalize_language(language:str)->str:
        lang=str(language or "mm").strip().lower()
        if lang in {"my","burmese","myanmar"}:lang="mm"
        if lang in {"eng","english"}:lang="en"
        if lang not in {"mm","en"}:raise ValueError("Story Motion language must be 'mm' or 'en'")
        return lang

    async def render_plan(self,*,plan:dict[str,Any],images:list[Path],root:Path,genre:str,language:str)->dict[str,Any]:
        lang=self._normalize_language(language)
        architecture=str(
            self.cfg.get('tts_architecture') or 'per_scene_exact_lock'
        ).strip().lower()
        if architecture == 'per_scene_exact_lock':
            return await self.engine.render_language_scene_lock(
                plan,images,str(genre or "horror").lower(),lang,root,provider='gemini',
            )
        if architecture != 'continuous_single_voice_exact_lock':
            raise ValueError(f"Unsupported Story Motion tts_architecture: {architecture}")
        return await self.engine.render_language(
            plan,images,str(genre or "horror").lower(),lang,root,
            safe_local_only=False,force_tts_only=False,strict_scene_boundaries=True,
        )

    def _latest_incomplete_asset_root(self, genre: str, max_age_hours: float = 24.0) -> Path | None:
        """Resume a recent Story Motion image build instead of paying for a new story.

        This is deliberately narrow: only roots with an unfinished image set or a
        persisted FAL queue checkpoint qualify. Completed old stories are never
        resurrected just because they are recent.
        """
        out=self.engine.output_root
        if not out.exists(): return None
        now=time.time(); candidates=[]
        for root in out.iterdir():
            if not root.is_dir() or not root.name.endswith('_'+genre): continue
            plan_path=root/'story_plan.json'; raw=root/'raw'
            if not plan_path.exists() or not raw.exists(): continue
            try:
                if now-root.stat().st_mtime > max(1.0,float(max_age_hours))*3600.0: continue
                plan=read_json(plan_path,{})
                scenes=plan.get('scenes') or []
                if not scenes: continue
                missing=[]; has_queue=False
                for i in range(1,len(scenes)+1):
                    img=raw/f'scene_{i:02d}.jpg'
                    if (not img.exists()) or img.stat().st_size < 5000:
                        missing.append(i)
                    if img.with_suffix(img.suffix+'.fal_queue.json').exists(): has_queue=True
                if missing or has_queue:
                    candidates.append(root)
            except Exception:
                continue
        return max(candidates,key=lambda x:x.stat().st_mtime) if candidates else None

    async def build_story_assets(self,*,genre:str="horror",seed:str="")->dict[str,Any]:
        genre=str(genre or "horror").strip().lower()
        if genre not in {"horror","thriller"}:raise ValueError("Story Motion genre must be horror or thriller")

        # V2.0.13: if FAL polling/network died halfway through scene generation,
        # continue the SAME root/plan/raw files. make_images() already reuses finished
        # JPGs, and StoryCarouselService resumes the SAME queued request_id from the
        # adjacent .fal_queue.json checkpoint. No new story/FAL spend is created.
        max_age=float(self.cfg.get('asset_resume_max_age_hours',24) or 24)
        root=self._latest_incomplete_asset_root(genre,max_age_hours=max_age)
        if root is not None:
            plan=read_json(root/'story_plan.json',{})
            story_id=str(plan.get('story_id') or root.name)
            raw=root/'raw'
            print("\n"+"="*74)
            print(f"STORY MOTION ASSET RESUME — {genre.upper()} — SAME STORY / SAME FAL REQUESTS")
            print("="*74)
            print(f"♻️ Story Motion incomplete asset resume → {root} (no new story plan; existing images/request checkpoints reused)")
            images=await self.engine.make_images(plan,raw)
        else:
            story_id=time.strftime("%Y%m%d_%H%M%S")+"_"+genre
            root=self.engine.output_root/story_id;raw=root/"raw";root.mkdir(parents=True,exist_ok=True)
            print("\n"+"="*74);print(f"STORY MOTION ASSETS — {genre.upper()} — ONE VISUAL SET FOR ALL LANGUAGES");print("="*74)
            plan=await self.engine.make_plan(genre,seed);plan["story_id"]=story_id;plan["genre"]=genre
            write_json(root/"story_plan.json",plan);self.engine._remember(genre,story_id,plan)
            images=await self.engine.make_images(plan,raw)

        asset={"story_id":story_id,"title":str(plan.get("title") or "").strip(),"genre":genre,"root":str(root),"story_plan":str(root/"story_plan.json"),"images":[str(x) for x in images],"caption_mm":str(plan.get("caption_mm") or "").strip(),"caption_en":str(plan.get("caption_en") or "").strip()}
        write_json(root/"asset_result.json",asset)
        return asset

    def load_assets(self,root:str|Path)->tuple[dict[str,Any],list[Path],Path]:
        root=Path(root).resolve();plan=read_json(root/"story_plan.json",{});scenes=plan.get("scenes") or []
        if not scenes:raise RuntimeError(f"Invalid Story Motion story_plan: {root}")
        images=[root/"raw"/f"scene_{i:02d}.jpg" for i in range(1,len(scenes)+1)]
        missing=[str(x) for x in images if not x.exists()]
        if missing:raise FileNotFoundError(f"Story Motion raw images missing: {missing[:3]}")
        return plan,images,root

    async def render_existing_assets(self,*,root:str|Path,language:str)->dict[str,Any]:
        plan,images,root_path=self.load_assets(root);genre=str(plan.get("genre") or "horror").lower();lang=self._normalize_language(language)
        render=await self.render_plan(plan=plan,images=images,root=root_path,genre=genre,language=lang)
        result={"success":True,"story_id":str(plan.get("story_id") or root_path.name),"title":str(plan.get("title") or ""),"genre":genre,"language":lang,"render":render,"root":str(root_path),"caption_mm":str(plan.get("caption_mm") or ""),"caption_en":str(plan.get("caption_en") or "")}
        write_json(root_path/f"production_result_{lang}.json",result)
        return result

    async def build_new_story(self,*,genre:str="horror",language:str="mm",seed:str="")->dict[str,Any]:
        assets=await self.build_story_assets(genre=genre,seed=seed)
        result=await self.render_existing_assets(root=assets["root"],language=language)
        print(f"✅ Story Motion production ready → {(result.get('render') or {}).get('full_video')}")
        return result
