from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime
from services.fb_profile_paths import PROFILE_STORES, profile_path

_HEALTH_LOCK = threading.RLock()
_REPAIRS = {}


class TTFBProfileService:
    """Profile storage and login purpose are independent: a Page may reuse a Share login."""
    _ALLOWED_STORES = PROFILE_STORES

    def __init__(self, project_root=".", *, profile_store="browser_sessions", purpose=None):
        self.root = Path(project_root).resolve()
        self.profile_store = str(profile_store).strip()
        if self.profile_store not in PROFILE_STORES:
            raise ValueError("Unsupported Facebook profile store")
        self.purpose = purpose or ("share" if self.profile_store == "browser_profiles" else "page")
        if self.purpose not in {"page", "share"}:
            raise ValueError("Invalid Facebook login purpose")
        self.profiles = self.root / self.profile_store
        self.profiles.mkdir(parents=True, exist_ok=True)
        self.helper = self.root / "tt_fb_profile_login.py"
        self.health_path = self.root / "state/tt_fb_profile_health.json"
        self._lock = _HEALTH_LOCK

    def _safe_profile_path(self, profile):
        return profile_path(self.root, profile, self.profile_store)

    def _key(self, profile):
        return f"{self.purpose}::{self.profile_store}::{str(profile).strip()}"

    def _repair_key(self, profile):
        return (str(self.root), self.profile_store, str(profile).strip())

    def _read_health(self):
        try:
            data = json.loads(self.health_path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def _record_health(self, profile, **changes):
        with self._lock:
            data = self._read_health()
            row = data.setdefault(self._key(profile), {})
            row.update(changes, store=self.profile_store, purpose=self.purpose,
                       updated_at=datetime.now().astimezone().isoformat(timespec="seconds"))
            if changes.get("logged_in") is True or changes.get("logged_in") is False:
                # Both purposes share Facebook auth when they use the SAME physical profile.
                # Business readiness remains purpose-specific; other stores/accounts stay independent.
                peer_purpose = "share" if self.purpose == "page" else "page"
                peer = data.setdefault(f"{peer_purpose}::{self.profile_store}::{str(profile).strip()}", {})
                peer.update({key: value for key, value in changes.items()
                             if key in {"logged_in", "last_test_at", "check_unknown", "reason"}})
                peer.update(store=self.profile_store, purpose=peer_purpose, updated_at=row["updated_at"])
            self.health_path.parent.mkdir(parents=True, exist_ok=True)
            temporary = None
            try:
                with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=self.health_path.parent,
                                                 suffix=".tmp", delete=False) as stream:
                    temporary = Path(stream.name); json.dump(data, stream, ensure_ascii=False, indent=2)
                for attempt in range(6):
                    try:
                        os.replace(temporary, self.health_path)
                        break
                    except PermissionError:
                        if attempt == 5:
                            raise
                        time.sleep(.05 * (attempt + 1))
            finally:
                if temporary is not None: temporary.unlink(missing_ok=True)

    def status(self, profile):
        try:
            path = self._safe_profile_path(profile)
        except ValueError as exc:
            return {"profile": str(profile or ""), "exists": False, "has_data": False, "error": str(exc)}
        exists = path.is_dir()
        try: has_data = exists and any(path.iterdir())
        except OSError: has_data = False
        health = self._read_health()
        row = health.get(self._key(profile), {})
        if not row and self.purpose == ("share" if self.profile_store == "browser_profiles" else "page"):
            legacy = health.get(f"{self.profile_store}::{profile}") or health.get(str(profile)) or {}
            if isinstance(legacy, dict) and legacy.get("store") == self.profile_store: row = legacy
        result = {"profile": str(profile), "path": str(path), "exists": exists, "has_data": has_data,
                  "profile_store": self.profile_store, "purpose": self.purpose}
        if isinstance(row, dict):
            for key in ("logged_in", "reason", "last_test_at", "repair_started_at", "repair_running", "check_unknown", "business_ready"):
                if key in row: result[key] = row[key]
        active = _REPAIRS.get(self._repair_key(profile))
        if active is not None and active.poll() is None:
            result["repair_running"] = True
        return result

    @staticmethod
    def _result(output):
        for line in reversed(str(output or "").splitlines()):
            try:
                data = json.loads(line)
                if isinstance(data, dict) and "logged_in" in data: return data
            except ValueError: pass
        return None

    def _finalize_test(self, profile, result):
        clean = dict(result)
        clean.update(profile=profile, profile_store=self.profile_store, purpose=self.purpose,
                     last_test_at=datetime.now().astimezone().isoformat(timespec="seconds"))
        changes = {key: clean[key] for key in ("reason", "last_test_at", "business_ready") if key in clean}
        known = clean.get("logged_in") is True or clean.get("logged_in") is False
        changes["check_unknown"] = not known
        clean["check_unknown"] = not known
        if known: changes["logged_in"] = clean["logged_in"]
        self._record_health(profile, **changes)
        return clean

    def _command(self, profile, check=False):
        args = [sys.executable, str(self.helper), str(profile), "--profile-store", self.profile_store,
                "--purpose", self.purpose]
        return args + (["--check"] if check else [])

    def open_login(self, profile):
        path = self._safe_profile_path(profile); path.mkdir(parents=True, exist_ok=True)
        if not self.helper.is_file(): raise FileNotFoundError(self.helper)
        key = self._repair_key(profile)
        with self._lock:
            old = _REPAIRS.get(key)
            if old is not None and old.poll() is None:
                return {"started": False, "already_open": True, "pid": old.pid, "profile": profile,
                        "reason": "Close this account's other Facebook login browser, then retry."}
            proc = subprocess.Popen(self._command(profile), cwd=str(self.root), stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, text=True, encoding="utf-8",
                                    errors="replace", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            _REPAIRS[key] = proc
            self._record_health(profile, repair_running=True,
                                repair_started_at=datetime.now().astimezone().isoformat(timespec="seconds"),
                                reason="Complete Facebook login/2FA in the browser")

        def watch():
            try:
                output, _ = proc.communicate()
                result = self._result(output)
                self._record_health(profile, repair_running=False)
                if result is not None and proc.returncode == 0:
                    # The visible browser already verified cookies + non-auth UI.
                    # Do not immediately open a competing headless context and overwrite that success.
                    self._finalize_test(profile, result)
                else:
                    self._finalize_test(profile, {"logged_in": None, "reason": "Login browser ended without a confirmation; use Test Login."})
            except Exception as exc:
                self._record_health(profile, repair_running=False, check_unknown=True,
                                    reason="Could not read login confirmation: " + str(exc)[:300])
            finally:
                with self._lock:
                    if _REPAIRS.get(key) is proc: _REPAIRS.pop(key, None)
        threading.Thread(target=watch, daemon=True, name=f"fb-repair-{profile}").start()
        return {"started": True, "pid": proc.pid, "profile": profile, "path": str(path),
                "profile_store": self.profile_store, "purpose": self.purpose, "persistent": True}

    def test_login(self, profile, timeout_seconds=120):
        path = self._safe_profile_path(profile)
        if not path.exists():
            return self._finalize_test(profile, {"logged_in": False, "reason": "profile folder does not exist"})
        if not self.helper.is_file(): raise FileNotFoundError(self.helper)
        with self._lock:
            active = _REPAIRS.get(self._repair_key(profile))
            if active is not None and active.poll() is None:
                return {"profile": profile, "logged_in": None, "check_unknown": True, "busy": True,
                        "reason": "Login browser is still open; finish login/2FA first."}
        try:
            process = subprocess.run(self._command(profile, check=True), cwd=str(self.root), capture_output=True,
                                     text=True, encoding="utf-8", errors="replace", timeout=timeout_seconds,
                                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except subprocess.TimeoutExpired:
            return self._finalize_test(profile, {"logged_in": None, "reason": "Login check timed out; previous login state was kept."})
        result = self._result(process.stdout)
        return self._finalize_test(profile, result if result is not None else
                                   {"logged_in": None, "reason": "Could not verify Facebook login; retry Test Login."})
