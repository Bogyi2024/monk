from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any


@dataclass
class DuplicateMatch:
    duplicate: bool
    score: float
    matched_story_id: str = ""
    matched_title: str = ""


class StoryUniquenessRegistry:
    """Persistent local story de-duplication for Story Board Drama.

    Stores compact plot information and performs a Unicode-safe similarity check.
    The check is intentionally local and cheap; Gemini is asked to regenerate when
    a near-duplicate is detected.
    """

    def __init__(self, path: str | Path = "downloads/story_uniqueness_registry.json") -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._save({"version": 1, "stories": []})

    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError
            data.setdefault("version", 1)
            data.setdefault("stories", [])
            return data
        except Exception:
            data = {"version": 1, "stories": []}
            self._save(data)
            return data

    def _save(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def _clean(value: Any) -> str:
        text = str(value or "").casefold()
        text = re.sub(r"[\s\u200b\u200c\u200d]+", "", text)
        text = re.sub(r"[^0-9a-z\u1000-\u109f\uaa60-\uaa7f\ua9e0-\ua9ff]+", "", text)
        return text

    @classmethod
    def _shingles(cls, value: str, n: int = 3) -> set[str]:
        text = cls._clean(value)
        if not text:
            return set()
        if len(text) <= n:
            return {text}
        return {text[i:i+n] for i in range(len(text) - n + 1)}

    @classmethod
    def _jaccard(cls, a: str, b: str) -> float:
        sa, sb = cls._shingles(a), cls._shingles(b)
        if not sa or not sb:
            return 0.0
        return len(sa & sb) / max(1, len(sa | sb))

    @staticmethod
    def _field(plan: dict[str, Any], key: str) -> str:
        return str(plan.get(key) or "").strip()

    @classmethod
    def signature(cls, plan: dict[str, Any]) -> dict[str, str]:
        slides = plan.get("slides") or []
        slide_headlines = " | ".join(str(x.get("headline") or "") for x in slides if isinstance(x, dict))
        slide_bodies = " | ".join(str(x.get("body") or "") for x in slides if isinstance(x, dict))
        premise = cls._field(plan, "premise")
        conflict = cls._field(plan, "conflict")
        twist = cls._field(plan, "twist")
        ending = cls._field(plan, "ending")
        title = cls._field(plan, "title")
        plot = " | ".join(x for x in [premise, conflict, twist, ending, slide_headlines, slide_bodies] if x)
        return {
            "title": title,
            "premise": premise,
            "conflict": conflict,
            "twist": twist,
            "ending": ending,
            "plot": plot,
        }

    def check(self, plan: dict[str, Any], threshold: float = 0.68) -> DuplicateMatch:
        sig = self.signature(plan)
        data = self._load()
        best = DuplicateMatch(False, 0.0)
        for old in data.get("stories", []):
            old_plot = str(old.get("plot") or "")
            old_title = str(old.get("title") or "")
            plot_score = self._jaccard(sig["plot"], old_plot)
            title_score = SequenceMatcher(None, self._clean(sig["title"]), self._clean(old_title)).ratio() if sig["title"] and old_title else 0.0
            premise_score = self._jaccard(sig["premise"], str(old.get("premise") or ""))
            twist_score = self._jaccard(sig["twist"], str(old.get("twist") or ""))
            ending_score = self._jaccard(sig["ending"], str(old.get("ending") or ""))

            # Plot carries the most weight; premise/twist/ending catch reworded titles.
            score = max(
                plot_score,
                0.55 * premise_score + 0.25 * twist_score + 0.20 * ending_score,
                0.70 * plot_score + 0.30 * title_score,
            )
            if score > best.score:
                best = DuplicateMatch(
                    duplicate=score >= threshold,
                    score=score,
                    matched_story_id=str(old.get("story_id") or ""),
                    matched_title=old_title,
                )
        return best

    def recent_avoidance_text(self, limit: int = 20) -> str:
        stories = list(self._load().get("stories", []))[-max(0, int(limit)):]
        if not stories:
            return ""
        lines = []
        for item in stories:
            title = str(item.get("title") or "").strip()
            premise = str(item.get("premise") or "").strip()
            twist = str(item.get("twist") or "").strip()
            ending = str(item.get("ending") or "").strip()
            compact = " / ".join(x for x in [title, premise, twist, ending] if x)
            if compact:
                lines.append("- " + compact[:420])
        return "\n".join(lines)

    def register(self, plan: dict[str, Any], story_id: str, *, source: str = "generated") -> None:
        sig = self.signature(plan)
        data = self._load()
        stories = data.setdefault("stories", [])
        if any(str(x.get("story_id") or "") == str(story_id) for x in stories):
            return
        stories.append({
            "story_id": str(story_id),
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "source": source,
            **sig,
        })
        # Keep enough history for long-term de-duplication without letting the file grow forever.
        max_entries = 1500
        if len(stories) > max_entries:
            data["stories"] = stories[-max_entries:]
        self._save(data)

    def bootstrap_from_outputs(self, output_root: str | Path = "outputs/story_carousel") -> int:
        root = Path(output_root)
        if not root.exists():
            return 0
        data = self._load()
        existing_ids = {str(x.get("story_id") or "") for x in data.get("stories", [])}
        added = 0
        for story_json in sorted(root.glob("*/story.json")):
            try:
                plan = json.loads(story_json.read_text(encoding="utf-8"))
                story_id = str(plan.get("story_id") or story_json.parent.name)
                if not story_id or story_id in existing_ids:
                    continue
                sig = self.signature(plan)
                data.setdefault("stories", []).append({
                    "story_id": story_id,
                    "created_at": datetime.fromtimestamp(story_json.stat().st_mtime).isoformat(timespec="seconds"),
                    "source": "bootstrap",
                    **sig,
                })
                existing_ids.add(story_id)
                added += 1
            except Exception:
                continue
        if added:
            if len(data["stories"]) > 1500:
                data["stories"] = data["stories"][-1500:]
            self._save(data)
        return added
