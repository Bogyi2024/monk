from __future__ import annotations

import base64
import json
import re
import time
from pathlib import Path
from typing import Any

from playwright.async_api import async_playwright


class GeminiWebStoryImageService:
    """Async Gemini Web image worker for Story Carousel.

    Phase 1.9.3 fixes:
    - no global body-text "Try again" false positives
    - save http(s) image URLs through BrowserContext.request (shared cookie jar, no page CORS)
    - blob URLs are saved from the already-loaded <img> (canvas -> screenshot fallback), no blob fetch
    - data URL support kept
    - screenshot fallback if the original image URL cannot be downloaded
    - browser engine/channel are configurable for A/B testing
    """

    def __init__(self, config: dict[str, Any]):
        self.config = config
        self._pw = None
        self._context = None
        self._page = None

    async def close(self) -> None:
        try:
            if self._context:
                await self._context.close()
        finally:
            self._context = None
            self._page = None
            if self._pw:
                await self._pw.stop()
                self._pw = None

    async def generate_image(
        self,
        *,
        prompt: str,
        save_path: Path,
        reference_image_path: str | Path | None = None,
    ) -> Path:
        attempts = int(self.config.get("gemini_web_attempts_per_image", 2))
        last_exc: Exception | None = None

        for attempt in range(1, attempts + 1):
            try:
                page = await self._ensure_ready()
                await self._goto_home(page)
                await self._ensure_logged_in(page)

                if bool(self.config.get("gemini_web_new_chat_each_image", True)):
                    await self._open_new_chat(page)

                if reference_image_path:
                    ref = Path(reference_image_path)
                    if ref.exists():
                        await self._attach_reference_image(page, ref)

                pre_existing = await self._snapshot_large_image_sources(page)
                started = time.time()
                await self._submit_prompt(page, prompt)
                image_src = await self._wait_for_new_generated_image(page, pre_existing)

                save_path.parent.mkdir(parents=True, exist_ok=True)
                await self._save_image_src(page, image_src, save_path)
                self._verify_image_file(save_path)

                elapsed = time.time() - started
                print(f"✅ Gemini Web image ready + saved in {elapsed:.1f}s")
                return save_path
            except Exception as exc:
                last_exc = exc
                print(f"⚠️ Gemini Web image attempt {attempt}/{attempts} failed: {exc}")
                if attempt >= attempts:
                    break

                # Safe retry: fresh chat in the same persistent browser context.
                try:
                    if self._page:
                        await self._open_new_chat(self._page)
                        await self._page.wait_for_timeout(
                            int(self.config.get("gemini_web_retry_grace_ms", 5000))
                        )
                except Exception:
                    pass

        raise RuntimeError(
            f"Gemini Web image generation failed after {attempts} attempts: {last_exc}"
        )

    # ------------------------------------------------------------------
    # Browser setup
    # ------------------------------------------------------------------
    async def _ensure_ready(self):
        if self._page:
            return self._page

        engine_name = str(
            self.config.get("gemini_web_browser_engine", "chromium")
        ).strip().lower()
        channel = str(self.config.get("gemini_web_browser_channel", "")).strip()
        user_data_dir = Path(
            self.config.get("gemini_web_user_data_dir", "browser_profiles/gemini_story")
        )
        user_data_dir.mkdir(parents=True, exist_ok=True)

        self._pw = await async_playwright().start()

        if engine_name == "firefox":
            browser_type = self._pw.firefox
        elif engine_name == "webkit":
            browser_type = self._pw.webkit
        else:
            engine_name = "chromium"
            browser_type = self._pw.chromium

        launch_kwargs: dict[str, Any] = {
            "user_data_dir": str(user_data_dir.resolve()),
            "headless": bool(self.config.get("gemini_web_headless", False)),
            "accept_downloads": True,
            "viewport": {
                "width": int(self.config.get("gemini_web_viewport_width", 1440)),
                "height": int(self.config.get("gemini_web_viewport_height", 1100)),
            },
        }

        if engine_name == "chromium":
            launch_kwargs["args"] = [
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--no-first-run",
                "--no-default-browser-check",
            ]
            if channel:
                launch_kwargs["channel"] = channel

        print(
            "🌐 Gemini Web browser: "
            f"engine={engine_name}"
            + (f", channel={channel}" if channel else "")
            + f", profile={user_data_dir}"
        )

        self._context = await browser_type.launch_persistent_context(**launch_kwargs)
        self._page = (
            self._context.pages[0]
            if self._context.pages
            else await self._context.new_page()
        )
        self._page.set_default_timeout(
            int(self.config.get("gemini_web_default_timeout_ms", 25000))
        )
        return self._page

    async def _goto_home(self, page) -> None:
        await page.goto(
            str(self.config.get("gemini_web_url", "https://gemini.google.com/app")),
            wait_until="domcontentloaded",
        )
        await page.wait_for_timeout(
            int(self.config.get("gemini_web_after_nav_wait_ms", 2000))
        )

    async def _ensure_logged_in(self, page) -> None:
        if "accounts.google.com" in (page.url or "").lower():
            raise RuntimeError(
                "Gemini Web login မဝင်ရသေးပါ။ setup_gemini_web_profile.py ကို run ပြီး manual login တစ်ခါလုပ်ပါ။"
            )

    async def _click_first_visible(
        self, page, selectors: list[str], timeout_ms: int = 2500
    ) -> bool:
        for sel in selectors:
            try:
                loc = page.locator(sel).first
                await loc.wait_for(state="visible", timeout=timeout_ms)
                await loc.click(timeout=timeout_ms)
                return True
            except Exception:
                continue
        return False

    async def _open_new_chat(self, page) -> None:
        await self._click_first_visible(
            page,
            [
                "button[aria-label*='New chat']",
                "button[aria-label*='new chat']",
                "button:has-text('New chat')",
                "a:has-text('New chat')",
                "button[title*='New chat']",
            ],
            3000,
        )
        await page.wait_for_timeout(
            int(self.config.get("gemini_web_after_new_chat_wait_ms", 1500))
        )

    async def _attach_reference_image(self, page, image_path: Path) -> None:
        input_loc = None
        try:
            loc = page.locator("input[type='file']")
            if await loc.count() > 0:
                input_loc = loc.first
        except Exception:
            pass

        if input_loc is None:
            await self._click_first_visible(
                page,
                [
                    "button[aria-label*='Upload']",
                    "button[aria-label*='upload']",
                    "button[aria-label*='Add files']",
                    "button[aria-label*='add files']",
                    "button:has-text('Add files')",
                    "button:has-text('Upload')",
                    "button:has-text('Add photos')",
                    "button:has-text('Insert assets')",
                ],
                3000,
            )
            try:
                loc = page.locator("input[type='file']")
                if await loc.count() > 0:
                    input_loc = loc.first
            except Exception:
                pass

        if input_loc is None:
            raise RuntimeError(
                "Gemini Web file upload input မတွေ့ပါ။ UI selector update လိုနိုင်ပါတယ်။"
            )

        await input_loc.set_input_files(str(image_path.resolve()))
        await page.wait_for_timeout(
            int(self.config.get("gemini_web_after_upload_wait_ms", 1800))
        )

    async def _prompt_box(self, page):
        for sel in ["textarea", "div[contenteditable='true']", "div[role='textbox']"]:
            try:
                loc = page.locator(sel).first
                if await loc.count() > 0:
                    await loc.wait_for(state="visible", timeout=2500)
                    return loc
            except Exception:
                continue
        raise RuntimeError("Gemini Web prompt box မတွေ့ပါ။")

    async def _submit_prompt(self, page, prompt: str) -> None:
        box = await self._prompt_box(page)
        try:
            await box.click()
        except Exception:
            pass

        try:
            await box.fill(prompt)
        except Exception:
            try:
                await box.press("Control+A")
                await box.press("Backspace")
            except Exception:
                pass
            await box.type(prompt, delay=0)

        if not await self._click_first_visible(
            page,
            [
                "button[aria-label*='Send']",
                "button[aria-label*='send']",
                "button[aria-label*='Submit']",
                "button:has-text('Send')",
            ],
            2500,
        ):
            await box.press("Enter")

        await page.wait_for_timeout(
            int(self.config.get("gemini_web_after_submit_wait_ms", 1200))
        )

    # ------------------------------------------------------------------
    # Image detection
    # ------------------------------------------------------------------
    async def _snapshot_large_image_sources(self, page) -> set[str]:
        try:
            items = await page.evaluate(
                """
                () => Array.from(document.images)
                    .filter(img => {
                        const r = img.getBoundingClientRect();
                        return r.width >= 180 && r.height >= 180;
                    })
                    .map(img => img.currentSrc || img.src)
                    .filter(Boolean)
                """
            )
            return set(items or [])
        except Exception:
            return set()

    async def _new_loaded_image_sources(self, page, pre_existing: set[str]) -> list[str]:
        try:
            srcs = await page.evaluate(
                """
                () => Array.from(document.images)
                    .map(img => {
                        const r = img.getBoundingClientRect();
                        return {
                            src: img.currentSrc || img.src || '',
                            bw: r.width,
                            bh: r.height,
                            nw: img.naturalWidth || 0,
                            nh: img.naturalHeight || 0,
                            complete: !!img.complete
                        };
                    })
                    .filter(x =>
                        x.src && x.complete &&
                        x.bw >= 180 && x.bh >= 180 &&
                        x.nw >= 256 && x.nh >= 256
                    )
                    .map(x => x.src)
                """
            )
        except Exception:
            srcs = []
        return [src for src in (srcs or []) if src not in pre_existing]

    async def _is_generation_active(self, page) -> bool:
        # Only use active-generation phrases for extending the wait.
        # Do NOT scan the whole page for generic "try again" failure text because
        # old chat/history/sidebar text can create false failures.
        active_pattern = re.compile(
            r"(adjusting|creating(?: an)? image|generating|refining|rendering|working on|"
            r"making(?: the)? image|preparing|composing|illustrating|processing)",
            re.I,
        )
        try:
            body_text = await page.locator("body").inner_text(timeout=1200)
        except Exception:
            return False
        return bool(active_pattern.search(body_text))

    async def _wait_for_new_generated_image(self, page, pre_existing: set[str]) -> str:
        soft_timeout_s = int(
            self.config.get("gemini_web_generation_timeout_seconds", 180)
        )
        hard_timeout_s = int(
            self.config.get("gemini_web_generation_hard_timeout_seconds", 600)
        )
        inactive_grace_s = int(
            self.config.get("gemini_web_inactive_grace_seconds", 25)
        )
        log_every_s = int(self.config.get("gemini_web_progress_log_seconds", 30))

        started = time.time()
        last_active_seen = started
        last_log = -9999.0

        while True:
            elapsed = time.time() - started

            new_srcs = await self._new_loaded_image_sources(page, pre_existing)
            if new_srcs:
                # Let the DOM settle for a moment so a low-res preview can be replaced
                # by the final loaded image URL.
                await page.wait_for_timeout(
                    int(self.config.get("gemini_web_image_settle_ms", 1800))
                )
                settled = await self._new_loaded_image_sources(page, pre_existing)
                src = (settled or new_srcs)[-1]
                print(f"🖼️ Gemini Web generated image detected at {elapsed:.1f}s")
                return src

            active = await self._is_generation_active(page)
            if active:
                last_active_seen = time.time()

            if elapsed - last_log >= log_every_s:
                print(
                    f"⏳ Gemini Web image {'ACTIVE' if active else 'WAITING'} — "
                    f"{int(elapsed)}s elapsed"
                )
                last_log = elapsed

            if elapsed >= hard_timeout_s:
                raise RuntimeError(
                    f"Gemini Web hard timeout after {hard_timeout_s}s"
                )

            if elapsed >= soft_timeout_s:
                if active or (time.time() - last_active_seen) <= inactive_grace_s:
                    await page.wait_for_timeout(1500)
                    continue
                raise RuntimeError(
                    f"Gemini Web stalled after {soft_timeout_s}s "
                    "(no new loaded image and generation no longer active)"
                )

            await page.wait_for_timeout(1500)

    # ------------------------------------------------------------------
    # Image save — avoids page fetch CORS
    # ------------------------------------------------------------------
    async def _save_image_src(self, page, src: str, save_path: Path) -> None:
        if src.startswith("data:image/"):
            save_path.write_bytes(base64.b64decode(src.split(",", 1)[1]))
            self._normalize_to_jpeg(save_path)
            return

        if src.startswith("blob:"):
            # IMPORTANT: Do not fetch Gemini blob URLs from page.evaluate().
            # Gemini can expose a blob URL that the utility/evaluate world cannot
            # fetch even though the <img> itself has already loaded it.
            # First try copying the already-loaded image into a canvas at its
            # natural resolution. If the canvas is blocked/tainted, fall back to
            # a screenshot of the exact generated <img> element.
            canvas_result = None
            try:
                canvas_result = await page.evaluate(
                    """
                    ({src}) => {
                        const img = Array.from(document.images).find(el =>
                            (el.currentSrc || el.src || '') === src
                        );
                        if (!img) {
                            return {ok: false, reason: 'image element not found'};
                        }
                        if (!img.complete || !img.naturalWidth || !img.naturalHeight) {
                            return {ok: false, reason: 'image not fully loaded'};
                        }
                        try {
                            const canvas = document.createElement('canvas');
                            canvas.width = img.naturalWidth;
                            canvas.height = img.naturalHeight;
                            const ctx = canvas.getContext('2d');
                            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                            const dataUrl = canvas.toDataURL('image/jpeg', 0.96);
                            return {
                                ok: true,
                                dataUrl,
                                width: canvas.width,
                                height: canvas.height
                            };
                        } catch (err) {
                            return {ok: false, reason: String(err)};
                        }
                    }
                    """,
                    {"src": src},
                )
            except Exception as exc:
                print(f"⚠️ Gemini blob canvas extraction failed: {exc}")

            if canvas_result and canvas_result.get("ok"):
                data_url = str(canvas_result.get("dataUrl") or "")
                if data_url.startswith("data:image/") and "," in data_url:
                    save_path.write_bytes(base64.b64decode(data_url.split(",", 1)[1]))
                    self._normalize_to_jpeg(save_path)
                    print(
                        "⬇️ Gemini blob image saved from loaded <img> canvas "
                        f"({canvas_result.get('width')}x{canvas_result.get('height')})"
                    )
                    return

            reason = (canvas_result or {}).get("reason", "unknown")
            print(
                f"⚠️ Gemini blob canvas unavailable ({reason}); "
                "using element-screenshot fallback"
            )
            await self._save_image_element_screenshot(page, src, save_path)
            self._normalize_to_jpeg(save_path)
            return

        # Important: use BrowserContext.request instead of page.evaluate(fetch()).
        # APIRequestContext shares the BrowserContext cookie jar and is not blocked
        # by browser-page CORS rules.
        try:
            headers = {"Referer": page.url}
            resp = await self._context.request.get(
                src,
                headers=headers,
                timeout=int(self.config.get("gemini_web_image_download_timeout_ms", 60000)),
                fail_on_status_code=False,
            )
            if resp.ok:
                body = await resp.body()
                if len(body) >= 8000:
                    save_path.write_bytes(body)
                    self._normalize_to_jpeg(save_path)
                    print(f"⬇️ Gemini image saved via BrowserContext.request ({len(body)/1024:.0f} KB)")
                    return
            print(f"⚠️ Direct image request returned HTTP {resp.status}; using screenshot fallback")
        except Exception as exc:
            print(f"⚠️ Direct image request failed: {exc}; using screenshot fallback")

        await self._save_image_element_screenshot(page, src, save_path)
        self._normalize_to_jpeg(save_path)

    async def _save_image_element_screenshot(self, page, src: str, save_path: Path) -> None:
        marker = "gemini-story-generated-target"
        found = await page.evaluate(
            """
            ({src, marker}) => {
                for (const img of Array.from(document.images)) {
                    const actual = img.currentSrc || img.src || '';
                    if (actual === src) {
                        img.setAttribute('data-gemini-story-target', marker);
                        img.scrollIntoView({block:'center', inline:'center'});
                        return true;
                    }
                }
                return false;
            }
            """,
            {"src": src, "marker": marker},
        )
        if not found:
            raise RuntimeError("Generated image element disappeared before save")

        loc = page.locator(f"img[data-gemini-story-target={json.dumps(marker)}]").first
        await loc.wait_for(state="visible", timeout=5000)
        await loc.screenshot(path=str(save_path), type="png")
        print("📸 Gemini image saved with element-screenshot fallback")

    def _normalize_to_jpeg(self, path: Path) -> None:
        from PIL import Image

        with Image.open(path) as img:
            # Keep the raw file predictable for the existing Story renderer.
            img = img.convert("RGB")
            img.save(path, format="JPEG", quality=95, subsampling=0)

    def _verify_image_file(self, path: Path) -> None:
        if not path.exists() or path.stat().st_size < 8000:
            raise RuntimeError(f"Gemini Web image file invalid: {path}")

        from PIL import Image

        try:
            with Image.open(path) as img:
                img.verify()
        except Exception as exc:
            raise RuntimeError(
                f"Gemini Web saved image verify failed: {exc}"
            ) from exc
