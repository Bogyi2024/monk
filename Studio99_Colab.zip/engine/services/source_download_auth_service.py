from __future__ import annotations

import asyncio
import json
import os
import shutil
import tempfile
import threading
import time
from urllib.parse import quote
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from playwright.async_api import async_playwright


def _project_root(default: str | Path | None = None) -> Path:
    if default is not None:
        return Path(default).resolve()
    return Path(__file__).resolve().parent.parent


def resolve_source_cookie_file(project_root: str | Path | None = None) -> Path:
    """Return the cookie file used by Recap source scan/download.

    Priority:
      1. SOURCE_COOKIE_FILE / RECAP_SOURCE_COOKIE_FILE
      2. <TT root>/cookie.txt
      3. <TT root>/config/cookie.txt (legacy/fallback)

    If none exists yet, the canonical writable location is <TT root>/cookie.txt.
    """
    root = _project_root(project_root)
    raw = str(os.getenv("SOURCE_COOKIE_FILE") or os.getenv("RECAP_SOURCE_COOKIE_FILE") or "").strip()
    if raw:
        p = Path(raw)
        if not p.is_absolute():
            p = root / p
        return p.resolve()

    canonical = root / "cookie.txt"
    if canonical.exists():
        return canonical
    legacy = root / "config" / "cookie.txt"
    if legacy.exists():
        return legacy
    return canonical


def cookiefile_ydl_option(project_root: str | Path | None = None) -> dict[str, Any]:
    path = resolve_source_cookie_file(project_root)
    if path.exists() and path.is_file() and path.stat().st_size > 20:
        return {"cookiefile": str(path)}
    return {}


def _parse_netscape_cookie_lines(text: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for raw in (text or "").splitlines():
        line = raw.rstrip("\r\n")
        if not line:
            continue
        http_only = False
        if line.startswith("#HttpOnly_"):
            line = line[len("#HttpOnly_") :]
            http_only = True
        elif line.lstrip().startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) < 7:
            # Some exporters use spaces, but cookie values can contain spaces;
            # reject those instead of corrupting authentication data.
            continue
        domain, include_subdomains, path, secure, expires, name = parts[:6]
        value = "\t".join(parts[6:])
        domain = domain.strip()
        name = name.strip()
        if not domain or not name:
            continue
        try:
            expires_i = int(float(str(expires or "0").strip() or 0))
        except Exception:
            expires_i = 0
        rows.append(
            {
                "domain": domain,
                "include_subdomains": str(include_subdomains).strip().upper() == "TRUE",
                "path": path or "/",
                "secure": str(secure).strip().upper() == "TRUE",
                "expires": expires_i,
                "name": name,
                "value": value,
                "http_only": http_only,
            }
        )
    return rows


def _format_netscape_cookie_rows(rows: Iterable[dict[str, Any]]) -> str:
    out = [
        "# Netscape HTTP Cookie File",
        "# This file is managed by TT Master Source Download Auth.",
        "# Do not share this file; it contains authenticated session cookies.",
        "",
    ]
    for row in sorted(
        rows,
        key=lambda r: (str(r.get("domain") or ""), str(r.get("path") or "/"), str(r.get("name") or "")),
    ):
        domain = str(row.get("domain") or "").strip()
        name = str(row.get("name") or "").strip()
        if not domain or not name:
            continue
        include_subdomains = bool(row.get("include_subdomains")) or domain.startswith(".")
        path = str(row.get("path") or "/")
        secure = bool(row.get("secure"))
        try:
            expires = int(float(row.get("expires") or 0))
        except Exception:
            expires = 0
        value = str(row.get("value") or "")
        prefix = "#HttpOnly_" if bool(row.get("http_only")) else ""
        out.append(
            "\t".join(
                [
                    prefix + domain,
                    "TRUE" if include_subdomains else "FALSE",
                    path,
                    "TRUE" if secure else "FALSE",
                    str(max(0, expires)),
                    name,
                    value,
                ]
            )
        )
    out.append("")
    return "\n".join(out)


class TTSourceDownloadAuthService:
    """Manage Recap source-download cookie.txt and optional login refresh browsers.

    This is intentionally separate from posting browser profiles. A Recap source
    may come from YouTube or TikTok; its download auth should never mutate the
    Facebook/TikTok posting sessions used to publish finished content.
    """

    YOUTUBE_COOKIE_MARKERS = {
        "SID",
        "HSID",
        "SSID",
        "APISID",
        "SAPISID",
        "LOGIN_INFO",
        "__Secure-1PSID",
        "__Secure-3PSID",
    }
    TIKTOK_COOKIE_MARKERS = {"sessionid", "sessionid_ss", "sid_tt", "uid_tt", "sid_guard"}

    def __init__(self, root: str | Path = ".") -> None:
        self.root = Path(root).resolve()
        self.cookie_path = resolve_source_cookie_file(self.root)
        self.state_path = self.root / "state" / "tt_source_download_auth.json"
        self.backup_dir = self.root / "state" / "source_cookie_backups"
        self.profiles_root = self.root / "browser_profiles"
        self._jobs_lock = threading.Lock()
        self._jobs: dict[str, dict[str, Any]] = {}
        self._state_lock = threading.Lock()

    def _read_state(self) -> dict[str, Any]:
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8")) if self.state_path.exists() else {}
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _update_state(self, **changes: Any) -> None:
        with self._state_lock:
            state = self._read_state()
            state.update(changes)
            state["updated_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.state_path.with_suffix(self.state_path.suffix + ".tmp")
            tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            os.replace(tmp, self.state_path)

    @staticmethod
    def _domain_platform(domain: str) -> str:
        d = str(domain or "").lower().lstrip(".")
        if d.endswith("youtube.com") or d.endswith("google.com") or d.endswith("googlevideo.com"):
            return "youtube"
        if d.endswith("tiktok.com") or d.endswith("tiktokv.com") or d.endswith("byteoversea.com"):
            return "tiktok"
        return "other"

    @staticmethod
    def _expiry_state(rows: list[dict[str, Any]]) -> tuple[int, int, str]:
        now = int(time.time())
        expired = 0
        future: list[int] = []
        for row in rows:
            exp = int(row.get("expires") or 0)
            if exp <= 0:
                continue
            if exp <= now:
                expired += 1
            else:
                future.append(exp)
        next_expiry = ""
        if future:
            next_expiry = datetime.fromtimestamp(min(future), tz=timezone.utc).astimezone().isoformat(timespec="minutes")
        return len(rows), expired, next_expiry

    def status(self) -> dict[str, Any]:
        path = resolve_source_cookie_file(self.root)
        exists = path.exists() and path.is_file()
        text = ""
        if exists:
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                text = ""
        rows = _parse_netscape_cookie_lines(text)
        yt_rows = [r for r in rows if self._domain_platform(str(r.get("domain") or "")) == "youtube"]
        tt_rows = [r for r in rows if self._domain_platform(str(r.get("domain") or "")) == "tiktok"]
        yt_count, yt_expired, yt_next = self._expiry_state(yt_rows)
        tt_count, tt_expired, tt_next = self._expiry_state(tt_rows)

        with self._jobs_lock:
            running = {
                platform: bool((job.get("thread") and job["thread"].is_alive()))
                for platform, job in self._jobs.items()
            }

        state = self._read_state()
        modified = ""
        size = 0
        if exists:
            try:
                stat = path.stat()
                size = int(stat.st_size)
                modified = datetime.fromtimestamp(stat.st_mtime).astimezone().isoformat(timespec="seconds")
            except Exception:
                pass
        return {
            "path": str(path),
            "exists": exists,
            "size": size,
            "modified_at": modified,
            "cookie_count": len(rows),
            "youtube": {
                "count": yt_count,
                "expired": yt_expired,
                "next_expiry": yt_next,
                "has_usable_cookie": yt_count > 0 and yt_expired < yt_count,
                "login_running": bool(running.get("youtube")),
                "last_refresh_at": str(state.get("youtube_last_refresh_at") or ""),
                "last_error": str(state.get("youtube_last_error") or ""),
            },
            "tiktok": {
                "count": tt_count,
                "expired": tt_expired,
                "next_expiry": tt_next,
                "has_usable_cookie": tt_count > 0 and tt_expired < tt_count,
                "login_running": bool(running.get("tiktok")),
                "last_refresh_at": str(state.get("tiktok_last_refresh_at") or ""),
                "last_error": str(state.get("tiktok_last_error") or ""),
            },
        }

    def import_cookie_text(self, text: str, source_name: str = "cookie.txt") -> dict[str, Any]:
        raw = str(text or "")
        rows = _parse_netscape_cookie_lines(raw)
        if not rows:
            raise ValueError(
                "cookie.txt format မမှန်ပါ။ Netscape cookie.txt (tab-separated) file ကိုရွေးပါ။"
            )
        self.cookie_path.parent.mkdir(parents=True, exist_ok=True)
        if self.cookie_path.exists() and self.cookie_path.stat().st_size > 0:
            self.backup_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            shutil.copy2(self.cookie_path, self.backup_dir / f"cookie_{stamp}.txt")
        # Normalize so malformed comments/line endings do not confuse yt-dlp.
        normalized = _format_netscape_cookie_rows(rows)
        fd, tmp_name = tempfile.mkstemp(prefix="cookie_", suffix=".tmp", dir=str(self.cookie_path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
                f.write(normalized)
            os.replace(tmp_name, self.cookie_path)
        finally:
            if os.path.exists(tmp_name):
                os.remove(tmp_name)
        self._update_state(last_import_at=datetime.now().astimezone().isoformat(timespec="seconds"), last_import_name=str(source_name or "cookie.txt"))
        return self.status()

    def _profile_path(self, platform: str) -> Path:
        p = str(platform or "").strip().lower()
        if p not in {"youtube", "tiktok"}:
            raise ValueError("platform must be youtube or tiktok")
        return self.profiles_root / ("SourceDownloadAuth_YouTube" if p == "youtube" else "SourceDownloadAuth_TikTok")

    @staticmethod
    def _login_start_url(platform: str) -> str:
        """Return an interactive login URL, not an already-authenticated landing page.

        YouTube's /account page can reuse the persistent profile's current Google
        session and jump straight into YouTube/Studio.  AccountChooser keeps the
        stored Google accounts available while still making the operator select
        which Gmail account should supply the exported download cookies.
        """
        if platform == "youtube":
            continue_url = quote("https://www.youtube.com/", safe="")
            return (
                "https://accounts.google.com/AccountChooser"
                f"?service=youtube&continue={continue_url}"
            )
        return "https://www.tiktok.com/"

    @staticmethod
    def _youtube_selection_completed(page_url: str, chooser_seen: bool) -> bool:
        """Only accept YouTube auth after the explicit Google chooser was left."""
        if not chooser_seen:
            return False
        url = str(page_url or "").strip().lower()
        if not url or "accounts.google." in url:
            return False
        return "youtube.com" in url or "youtu.be" in url

    @staticmethod
    def _proxy(platform: str) -> dict[str, str] | None:
        if platform == "youtube":
            raw = str(os.getenv("YOUTUBE_PROXY") or os.getenv("DOWNLOAD_PROXY") or "").strip()
        else:
            raw = str(os.getenv("TIKTOK_PROXY") or os.getenv("DOWNLOAD_PROXY") or "").strip()
        if not raw or raw.lower() in {"none", "off", "false", "0"}:
            return None
        return {"server": raw}

    @classmethod
    def _auth_detected(cls, platform: str, cookies: list[dict[str, Any]]) -> bool:
        names = {str(c.get("name") or "") for c in cookies}
        if platform == "youtube":
            # Require at least one strong account cookie plus another SID/APISID-style
            # cookie so a generic visitor cookie cannot close the browser by mistake.
            strong = bool(names & {"LOGIN_INFO", "SID", "__Secure-1PSID", "__Secure-3PSID"})
            support = bool(names & {"SAPISID", "APISID", "HSID", "SSID", "__Secure-1PSID", "__Secure-3PSID"})
            return strong and support
        return bool(names & {"sessionid", "sessionid_ss"})

    @staticmethod
    def _playwright_rows(cookies: list[dict[str, Any]]) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for c in cookies:
            domain = str(c.get("domain") or "").strip()
            name = str(c.get("name") or "").strip()
            if not domain or not name:
                continue
            expires_raw = c.get("expires")
            try:
                expires = int(float(expires_raw)) if expires_raw and float(expires_raw) > 0 else 0
            except Exception:
                expires = 0
            rows.append(
                {
                    "domain": domain,
                    "include_subdomains": domain.startswith("."),
                    "path": str(c.get("path") or "/"),
                    "secure": bool(c.get("secure")),
                    "expires": expires,
                    "name": name,
                    "value": str(c.get("value") or ""),
                    "http_only": bool(c.get("httpOnly")),
                }
            )
        return rows

    def _merge_exported_cookies(self, platform: str, cookies: list[dict[str, Any]]) -> None:
        existing_rows: list[dict[str, Any]] = []
        current = resolve_source_cookie_file(self.root)
        if current.exists():
            try:
                existing_rows = _parse_netscape_cookie_lines(current.read_text(encoding="utf-8", errors="replace"))
            except Exception:
                existing_rows = []

        exported = self._playwright_rows(cookies)
        # Keep only useful domains from this login context; Chrome/Playwright can
        # contain unrelated extension/service cookies in the same profile.
        if platform == "youtube":
            exported = [
                r
                for r in exported
                if self._domain_platform(str(r.get("domain") or "")) == "youtube"
            ]
        else:
            exported = [
                r
                for r in exported
                if self._domain_platform(str(r.get("domain") or "")) == "tiktok"
            ]
        if not exported:
            raise RuntimeError(f"{platform} login detected but no exportable cookies were found")

        keys_to_replace = {
            (str(r.get("domain") or ""), str(r.get("path") or "/"), str(r.get("name") or ""))
            for r in exported
        }
        merged = [
            r
            for r in existing_rows
            if (str(r.get("domain") or ""), str(r.get("path") or "/"), str(r.get("name") or ""))
            not in keys_to_replace
        ]
        merged.extend(exported)
        current.parent.mkdir(parents=True, exist_ok=True)
        current.write_text(_format_netscape_cookie_rows(merged), encoding="utf-8", newline="\n")

    async def _login_session(
        self,
        platform: str,
        ready: threading.Event,
        failed: threading.Event,
        box: dict[str, Any],
    ) -> None:
        profile_path = self._profile_path(platform)
        profile_path.mkdir(parents=True, exist_ok=True)
        context = None
        try:
            async with async_playwright() as pw:
                context = await pw.chromium.launch_persistent_context(
                    user_data_dir=str(profile_path),
                    headless=False,
                    args=["--disable-notifications", "--disable-blink-features=AutomationControlled"],
                    proxy=self._proxy(platform),
                )
                box["started_at"] = time.time()
                ready.set()
                page = context.pages[0] if context.pages else await context.new_page()
                start_url = self._login_start_url(platform)
                await page.goto(start_url, timeout=120_000, wait_until="domcontentloaded")

                deadline = time.time() + 900.0
                chooser_seen = platform != "youtube"
                while time.time() < deadline:
                    try:
                        page_url = str(page.url or "")
                    except Exception:
                        page_url = ""
                    if platform == "youtube" and "accounts.google." in page_url.lower():
                        chooser_seen = True
                    try:
                        cookies = await context.cookies()
                    except Exception:
                        cookies = []
                    selection_completed = (
                        self._youtube_selection_completed(page_url, chooser_seen)
                        if platform == "youtube"
                        else True
                    )
                    if selection_completed and self._auth_detected(platform, cookies):
                        # Let redirect/account state settle before export.
                        await page.wait_for_timeout(5000)
                        cookies = await context.cookies()
                        self._merge_exported_cookies(platform, cookies)
                        stamp = datetime.now().astimezone().isoformat(timespec="seconds")
                        self._update_state(
                            **{
                                f"{platform}_last_refresh_at": stamp,
                                f"{platform}_last_error": "",
                            }
                        )
                        box["authenticated"] = True
                        box["refreshed_at"] = stamp
                        await page.wait_for_timeout(1200)
                        return
                    await page.wait_for_timeout(1500)
                raise RuntimeError(f"{platform} login timed out after 15 minutes")
        except Exception as exc:
            msg = str(exc)
            low = msg.lower()
            if ready.is_set() and any(x in low for x in ("target page", "targetclosed", "browser has been closed")):
                box["closed_by_user"] = True
                self._update_state(**{f"{platform}_last_error": "Login browser was closed before authenticated cookies were exported."})
            else:
                box["error"] = msg
                failed.set()
                self._update_state(**{f"{platform}_last_error": msg[-1000:]})
        finally:
            if context is not None:
                try:
                    await context.close()
                except Exception:
                    pass
            with self._jobs_lock:
                job = self._jobs.get(platform)
                if job is not None:
                    job["finished_at"] = time.time()

    def _thread_main(self, platform: str, ready: threading.Event, failed: threading.Event, box: dict[str, Any]) -> None:
        try:
            asyncio.run(self._login_session(platform, ready, failed, box))
        except Exception as exc:
            box["error"] = str(exc)
            failed.set()

    def open_login(self, platform: str) -> dict[str, Any]:
        platform = str(platform or "").strip().lower()
        profile_path = self._profile_path(platform)
        profile_path.mkdir(parents=True, exist_ok=True)
        with self._jobs_lock:
            existing = self._jobs.get(platform)
            if existing:
                th = existing.get("thread")
                if th and th.is_alive():
                    return {
                        "started": True,
                        "already_running": True,
                        "platform": platform,
                        "path": str(profile_path),
                    }
            ready = threading.Event()
            failed = threading.Event()
            box: dict[str, Any] = {}
            th = threading.Thread(
                target=self._thread_main,
                args=(platform, ready, failed, box),
                daemon=True,
                name=f"tt-source-auth-{platform}",
            )
            self._jobs[platform] = {"thread": th, "ready": ready, "failed": failed, "box": box}
            th.start()

        deadline = time.time() + 20.0
        while time.time() < deadline:
            if ready.wait(timeout=0.2):
                return {
                    "started": True,
                    "already_running": False,
                    "platform": platform,
                    "path": str(profile_path),
                    "message": (
                        "Select the Gmail account in the opened Google chooser. TT will export cookies and close it automatically after YouTube opens."
                        if platform == "youtube"
                        else "Complete login in the opened Chromium window. TT will export cookies and close it automatically after auth is detected."
                    ),
                }
            if failed.is_set() or not th.is_alive():
                break
        if failed.is_set() or not th.is_alive():
            raise RuntimeError(str(box.get("error") or f"{platform} login browser failed before opening"))
        raise RuntimeError(f"{platform} login browser did not confirm start within 20 seconds")
