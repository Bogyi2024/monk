from __future__ import annotations

import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any


class TTShareExportService:
    """Bridge central Web Manager share accounts to the existing fb_group_service config."""

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings = settings_service
        self.root = Path(project_root).resolve()
        self.path = self.root / "config" / "fb_share_accounts.json"
        self.backups = self.root / "state" / "tt_settings_backup"
        self.backups.mkdir(parents=True, exist_ok=True)

    def sync_category(self, category_key: str) -> list[str]:
        return self._sync_resolved(self.settings.resolve_category(category_key))

    def sync_route(self, category_key: str, route_key: str = "default") -> list[str]:
        return self._sync_resolved(self.settings.resolve_route(category_key, route_key))

    def _sync_resolved(self, route) -> list[str]:
        selected = []
        exported = []
        for item in route.get("share_accounts") or []:
            if not item.get("enabled", True):
                continue
            profile = str(item.get("profile") or "").strip()
            if not profile:
                continue
            groups = [str(x).strip() for x in (item.get("groups") or []) if str(x).strip()]
            exported.append({
                "name": profile,
                "profile_folder": profile,
                "enabled": True,
                "groups": groups,
                "note": str(item.get("label") or item.get("key") or profile),
            })
            selected.append(profile)

        # Preserve non-selected legacy accounts too so a different category can sync later
        # without losing login metadata. Selected profile rows are replaced by central data.
        old = {"accounts": []}
        if self.path.exists():
            try:
                old = json.loads(self.path.read_text(encoding="utf-8"))
            except Exception:
                old = {"accounts": []}
        replacement = {x["profile_folder"].lower(): x for x in exported}
        merged = []
        seen = set()
        for row in old.get("accounts") or []:
            if not isinstance(row, dict):
                continue
            prof = str(row.get("profile_folder") or row.get("name") or "").strip()
            low = prof.lower()
            if low in replacement:
                row = replacement[low]
            merged.append(row)
            if low:
                seen.add(low)
        for row in exported:
            low = row["profile_folder"].lower()
            if low not in seen:
                merged.append(row)
                seen.add(low)

        payload = {"accounts": merged}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            shutil.copy2(self.path, self.backups / f"fb_share_accounts_before_bridge_{stamp}.json")
        fd, name = tempfile.mkstemp(prefix=self.path.name + ".", suffix=".tmp", dir=str(self.path.parent))
        os.close(fd)
        tmp = Path(name)
        try:
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            os.replace(tmp, self.path)
        finally:
            if tmp.exists():
                try: tmp.unlink()
                except Exception: pass
        return selected
