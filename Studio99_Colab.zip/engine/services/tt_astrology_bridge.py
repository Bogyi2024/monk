from __future__ import annotations

import asyncio
import json
from datetime import datetime
from pathlib import Path
from typing import Any

from services.astrology_real_output_service import AstrologyRealOutputService
from services.browser_service import BrowserService
from services.fb_group_service import auto_share_all_accounts
from services.tt_service import upload_to_tiktok
from services.tt_share_export_service import TTShareExportService
from services.tt_route_branding_service import TTRouteBrandingService


class TTAstrologyBridge:
    """Live TT bridge for Astrology.

    One daily asset pack is generated once, then each scheduler invocation posts the
    next logical item (Daily / Image Pick / Weekly / Monthly). Pending destination
    retries reuse the SAME rendered files and never regenerate paid FAL assets.
    """

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings=settings_service
        self.root=Path(project_root).resolve()
        self.pending_path=self.root/"state"/"tt_astrology_pending.json"
        self.pending_path.parent.mkdir(parents=True,exist_ok=True)
        self.share_export=TTShareExportService(settings_service,self.root)
        self.branding=TTRouteBrandingService(self.root)

    def _load(self)->dict[str,Any]:
        try:
            if self.pending_path.exists():
                data=json.loads(self.pending_path.read_text(encoding="utf-8"))
                return data if isinstance(data,dict) else {}
        except Exception:
            pass
        return {}

    def _save(self,data:dict[str,Any])->None:
        self.pending_path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

    def _master_completed_jobs(self, today: str) -> set[str]:
        """Recover Astrology content locks already counted by TT Master today.

        This is a duplicate guard for installs/restarts where the Astrology pending
        state is older than the Master daily state.
        """
        out:set[str]=set()
        path=self.root/"state"/"tt_daily_run"/f"{today}.json"
        try:
            data=json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
            row=((data.get("categories") or {}).get("astrology") or {})
            tokens=list(row.get("counted_content_ids") or [])
            for ev in (data.get("events") or []):
                if str(ev.get("category") or "")=="astrology" and ev.get("content_id"):
                    tokens.append(ev.get("content_id"))
            prefix=f"astrology:{today}:"
            for token in tokens:
                token=str(token or "")
                if token.startswith(prefix):
                    job=token[len(prefix):].strip()
                    if job in {"daily","image_pick","weekly","monthly"}: out.add(job)
        except Exception as exc:
            print(f"⚠️ Astrology Master completion reconcile warning: {exc}")
        return out

    @staticmethod
    def _today_jobs(now:datetime,rules:dict[str,Any])->list[str]:
        d=rules.get("daily") or {}; w=rules.get("weekly") or {}; m=rules.get("monthly") or {}
        jobs=[]
        # Locked special precedence: calendar day 30 monthly replaces Sunday weekly.
        if now.day==30 and bool(m.get("enabled",True)) and int(m.get("monthly_special",1) or 0)>0:
            jobs.append("monthly")
        elif now.weekday()==6 and bool(w.get("enabled",True)) and int(w.get("weekly_special",1) or 0)>0:
            jobs.append("weekly")
        if int(d.get("weekday_forecast",1) or 0)>0: jobs.append("daily")
        if int(d.get("pick_one_of_four",1) or 0)>0: jobs.append("image_pick")
        return jobs

    @staticmethod
    def _caption(result:dict[str,Any],job:str,platform:str)->str:
        if job in {"weekly","monthly"}:
            content=(result.get(job) or {})
        else:
            content=(result.get(job) or {})
        key="fb_caption" if platform=="fb" else "tt_caption"
        value=str(content.get(key) or content.get("caption") or content.get("title") or "").strip()
        if not value and job=="image_pick":
            value=str((result.get("image_pick") or {}).get("caption") or "").strip()
        return value

    def _paths(self,result:dict[str,Any],job:str)->dict[str,Any]:
        outputs=result.get("outputs") or {}
        if job=="daily":
            return {"motion":Path(str(outputs.get("daily_tt_motion") or "")),"carousel":Path(str(outputs.get("daily_fb_carousel") or ""))}
        if job=="image_pick":
            return {"motion":Path(str(outputs.get("image_pick_motion") or "")),"carousel":None}
        if job=="weekly":
            return {"motion":Path(str(outputs.get("weekly_motion") or "")),"carousel":Path(str(outputs.get("weekly_fb_carousel") or ""))}
        if job=="monthly":
            return {"motion":Path(str(outputs.get("monthly_motion") or "")),"carousel":Path(str(outputs.get("monthly_fb_carousel") or ""))}
        raise KeyError(job)

    @staticmethod
    def _carousel_images(path:Path|None)->list[str]:
        if path is None or not path.exists(): return []
        return [str(p) for p in sorted(path.glob("slide_*.jpg")) if p.is_file()]

    async def _ensure_assets(self,state:dict[str,Any],now:datetime)->dict[str,Any]:
        root=Path(str(state.get("asset_root") or "")) if state.get("asset_root") else None
        result_path=(root/"real_output_result.json") if root else None
        if result_path and result_path.exists():
            return json.loads(result_path.read_text(encoding="utf-8"))
        print("🔮 Astrology production pack build/resume start (paid assets are checkpointed)")
        root=await AstrologyRealOutputService("config/astrology_real_output_test.json").run_today(now)
        state["asset_root"]=str(root)
        self._save(state)
        rp=root/"real_output_result.json"
        if not rp.exists(): raise FileNotFoundError(f"Astrology result missing: {rp}")
        return json.loads(rp.read_text(encoding="utf-8"))

    async def run_once(self,route_key:str="default")->dict[str,Any]:
        now=datetime.now().astimezone()
        resolved=self.settings.resolve_route("astrology",route_key)
        cat=resolved.get("category") or {}; route=resolved.get("route") or {}
        if not cat.get("enabled",True) or not route.get("enabled",True):
            raise RuntimeError(f"Astrology route disabled: {route_key}")
        rules=cat.get("production_rules") or {}
        mode=str(rules.get("facebook_output_mode") or "video_only").strip().lower()
        if mode not in {"video_only","mixed"}: mode="video_only"

        state=self._load()
        today=now.date().isoformat()
        if state.get("date")!=today or state.get("route_key")!=route_key:
            state={
                "date":today,"route_key":route_key,"asset_root":"",
                "jobs":self._today_jobs(now,rules),"completed":[],"current":None,
            }
            self._save(state)
        jobs=list(state.get("jobs") or self._today_jobs(now,rules))
        completed=set(str(x) for x in (state.get("completed") or []))
        master_completed=self._master_completed_jobs(today)
        if master_completed-completed:
            newly=sorted(master_completed-completed)
            completed.update(master_completed)
            state["completed"]=list(completed)
            print(f"🔒 Astrology same-day primary completion reconcile → {', '.join(newly)} (will NOT repost)")
            self._save(state)
        current=state.get("current") if isinstance(state.get("current"),dict) else None
        if current and current.get("job") in completed:
            current=None; state["current"]=None; self._save(state)
        if not current:
            next_job=next((j for j in jobs if j not in completed),None)
            if not next_job:
                return {"success":True,"new_content_count":0,"maintenance_only":True,"no_work":True,"route_key":route_key,"failure_kind":"no_new_content"}
            current={"job":next_job,"mode":mode,"fb_done":False,"tt_done":False,"group_done":False,"fb_post_link":"","fb_post_baseline":[]}
            state["current"]=current; self._save(state)
            print(f"🔮 Astrology next item → {next_job} | FB mode={mode}")
        else:
            # Freeze the output mode for a pending item; changing UI mode applies to future items.
            mode=str(current.get("mode") or mode)
            print(f"♻️ Astrology pending retry → {current.get('job')} | frozen FB mode={mode}")

        result=await self._ensure_assets(state,now)
        job=str(current.get("job"))
        paths=self._paths(result,job)
        motion=paths["motion"]
        if not motion.exists(): raise FileNotFoundError(f"Astrology motion missing: {motion}")

        fb=resolved.get("facebook"); tt=resolved.get("tiktok")
        want_fb=bool(fb and fb.get("enabled",True)); want_tt=bool(tt and tt.get("enabled",True))
        if not want_fb and not want_tt:
            raise RuntimeError(f"Astrology route {route_key} has no enabled Facebook/TikTok destination")
        selected=self.share_export.sync_route("astrology",route_key)
        want_group=bool(want_fb and route.get("share_enabled",True) and selected)
        primary_this_run=[]
        browser=BrowserService()

        if want_fb and not current.get("fb_done"):
            fb_caption=self._caption(result,job,"fb")
            if mode=="mixed" and job in {"daily","weekly","monthly"}:
                images=self._carousel_images(paths.get("carousel"))
                if not images: raise FileNotFoundError(f"Astrology {job} carousel images missing")
                images=await asyncio.to_thread(self.branding.brand_images,images,"astrology",route_key,route.get("branding") or {},"facebook_post")
                if want_group and not current.get("fb_post_baseline"):
                    try:
                        current["fb_post_baseline"]=await browser.collect_page_post_baseline(
                            str(fb.get("profile") or "Main_FB_Account"),str(fb.get("page_id") or ""),timeout_ms=90000
                        )
                    except Exception as exc:
                        print(f"⚠️ Astrology FB Page baseline capture warning: {exc}")
                        current["fb_post_baseline"]=[]
                    self._save(state)
                from services.story_carousel_upload_service import upload_facebook_story_carousel
                ok=await upload_facebook_story_carousel(
                    images,fb_caption,profile_name=str(fb.get("profile") or "Main_FB_Account"),page_id=str(fb.get("page_id") or ""),headless=False,
                    capture_permalink=want_group,
                )
                current["fb_done"]=bool(ok)
                self._save(state)
            else:
                branded_motion=await asyncio.to_thread(self.branding.brand_video,str(motion),"astrology",route_key,route.get("branding") or {},"facebook_reel")
                outcome=await browser.upload_reel_stealth(
                    str(fb.get("profile") or "Main_FB_Account"),str(fb.get("page_id") or ""),fb_caption,branded_motion,
                    capture_permalink=want_group,
                )
                current["fb_done"]=bool((outcome or {}).get("success"))
                current["fb_post_link"]=str((outcome or {}).get("post_link") or "")
                self._save(state)
            if current.get("fb_done"): primary_this_run.append("facebook")
            else: return {"success":False,"new_content_count":0,"pending":True,"route_key":route_key,"failure_kind":"facebook_upload_pending"}

        if want_tt and not current.get("tt_done"):
            branded_motion=await asyncio.to_thread(self.branding.brand_video,str(motion),"astrology",route_key,route.get("branding") or {},"tiktok_reel")
            ok=await upload_to_tiktok(
                profile_folder_name=str(tt.get("profile") or ""),video_path=branded_motion,caption_text=self._caption(result,job,"tt"),headless=False
            )
            current["tt_done"]=bool(ok); self._save(state)
            if current.get("tt_done"): primary_this_run.append("tiktok")
            else: return {"success":False,"new_content_count":0,"pending":True,"route_key":route_key,"failure_kind":"tiktok_upload_pending"}

        primary_complete=((not want_fb) or current.get("fb_done")) and ((not want_tt) or current.get("tt_done"))
        content_id=f"astrology:{today}:{job}"

        # V2.0.13 PRIMARY LOCK: once FB/TT primary destinations are complete, this
        # Astrology item is finished for today's content quota. Group sharing is
        # secondary and must NEVER keep the item "current" or cause a repost.
        if primary_complete:
            if job not in completed:
                completed.add(job)
            state["completed"]=list(completed)
            state.setdefault("primary_receipts",{})[job]={
                "content_id":content_id,
                "completed_at":datetime.now().astimezone().isoformat(timespec="seconds"),
                "fb_done":bool(current.get("fb_done")),"tt_done":bool(current.get("tt_done")),
                "fb_post_link":str(current.get("fb_post_link") or ""),
            }
            # Clear current BEFORE any secondary share work. If the browser/process
            # dies during group sharing, the next run cannot upload this item again.
            state["current"]=None
            self._save(state)
            print(f"🔒 Astrology primary complete lock → {job} | same-day repost disabled")

        secondary_summary=None
        secondary_skipped_reason=""
        if primary_complete and want_group and not current.get("group_done"):
            post_link=str(current.get("fb_post_link") or "")
            expected=self._caption(result,job,"fb")
            if not post_link and mode=="mixed" and job in {"daily","weekly","monthly"}:
                # recover_latest_page_post_permalink itself is bounded to three feed passes.
                post_link=await browser.recover_latest_page_post_permalink(
                    str(fb.get("profile") or "Main_FB_Account"),str(fb.get("page_id") or ""),timeout_ms=150000,
                    baseline_urls=current.get("fb_post_baseline") or [],expected_caption=expected,
                )
                current["fb_post_link"]=str(post_link or "")
                receipt=(state.get("primary_receipts") or {}).get(job) or {}
                receipt["fb_post_link"]=str(post_link or "")
                state.setdefault("primary_receipts",{})[job]=receipt
                self._save(state)
            if not post_link:
                secondary_skipped_reason="fb_permalink_not_found_after_bounded_recovery"
                print("⏭️ Astrology secondary group-share skipped: FB permalink not found after bounded recovery; primary item remains COMPLETE")
            else:
                try:
                    secondary_summary=await auto_share_all_accounts(
                        post_link,account_names=selected,share_text=self._caption(result,job,"fb"),headless=False,
                        delay_between_groups_seconds=20.0,delay_between_accounts_seconds=120.0
                    )
                    current["group_done"]=True; current["group_summary"]=secondary_summary
                except Exception as exc:
                    secondary_skipped_reason=f"group_share_error:{exc}"
                    print(f"⏭️ Astrology secondary group-share skipped after error; primary item remains COMPLETE: {exc}")
            receipt=(state.get("primary_receipts") or {}).get(job) or {}
            receipt["group_summary"]=secondary_summary
            receipt["secondary_skipped_reason"]=secondary_skipped_reason
            state.setdefault("primary_receipts",{})[job]=receipt
            self._save(state)

        if primary_complete:
            return {
                "success":True,"new_content_count":1,"content_id":content_id,
                "route_key":route_key,"astrology_job":job,"facebook_output_mode":mode,
                "cleanup_assets":[str(p) for p in paths.values() if p],
                "primary_completed_this_run":primary_this_run,
                "secondary_skipped_reason":secondary_skipped_reason,
                "group_summary":secondary_summary,
            }
        return {"success":False,"new_content_count":0,"pending":True,"route_key":route_key,"failure_kind":"pending_destination_retry"}
