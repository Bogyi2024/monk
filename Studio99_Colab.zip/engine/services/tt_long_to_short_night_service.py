from __future__ import annotations

import asyncio
import codecs
import hashlib
import json
import os
import sys
import tempfile
import time
import uuid
from contextlib import suppress
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from services.tt_worker_lease_service import running_lease_status


class TTLongToShortNightService:
    """Idle-time producer for the standalone Long-to-Short tool.

    TT Master decides *when/how much* to prepare. All expensive media work stays
    in the sibling ``long_to_short`` project and is invoked as a subprocess.

    V2.0.21 adds a date-scoped preparation buffer. A content category can request
    1..7 future days. Each future day keeps its own standalone inventory JSON, so
    daytime posting still consumes only that day's READY files. On later nights,
    already-filled dates are reused and only the newly missing farthest date is
    replenished.
    """

    CATEGORY = "long_to_short"
    OUTPUT_ALIASES = {
        "video": "transformative_envo_mm",
        "transformative_envo_mm": "transformative_envo_mm",
        "voiceover_mm_sub": "transformative_envo_mm",
        "original_audio_mm": "original_audio_mm",
        "original_sound_mm_sub": "original_audio_mm",
        "transformative_envo_en": "transformative_envo_en",
        "voiceover_en_sub": "transformative_envo_en",
        "original_audio_en": "original_audio_en",
        "original_sound_en_sub": "original_audio_en",
    }
    OUTPUT_MODES = {"transformative_envo_mm", "original_audio_mm", "transformative_envo_en", "original_audio_en"}
    POST_COPY_SCHEMA = "lts_social_metadata_mm_title_en_hashtags_v2"

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings = settings_service
        self.root = Path(project_root).resolve()
        env = str(os.getenv("TT_LONG_TO_SHORT_DIR") or "").strip()
        self.lts_root = Path(env).expanduser().resolve() if env else (self.root.parent / "long_to_short").resolve()
        self.runner = self.lts_root / "tt_bridge_runner.py"
        self.state_path = self.root / "state" / "tt_long_to_short_night.json"
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.owner_pid = os.getpid()
        self.owner_token = uuid.uuid4().hex

    @staticmethod
    def _atomic(path: Path, data: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        os.close(fd)
        tmp = Path(name)
        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            for attempt in range(7):
                try:
                    os.replace(tmp, path)
                    break
                except OSError as exc:
                    retryable = isinstance(exc, PermissionError) or getattr(exc, "winerror", None) in {5, 32}
                    if not retryable or attempt == 6:
                        raise
                    time.sleep(0.05 * (2 ** attempt))
        finally:
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass

    def _load_state(self) -> dict[str, Any]:
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8")) if self.state_path.exists() else {}
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _save_state(self, data: dict[str, Any]) -> None:
        data["updated_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
        self._atomic(self.state_path, data)

    def _save_failure_state(self, data: dict[str, Any], context: str) -> None:
        """Best-effort error receipt; a locked state file must never stop TT Master."""
        try:
            self._save_state(data)
        except OSError as exc:
            print(f"⚠️ Long-to-Short {context} state receipt skipped after retries: {type(exc).__name__}: {exc}")

    @staticmethod
    def _clear_lease(data: dict[str, Any]) -> None:
        data.pop("owner_pid", None)
        data.pop("owner_token", None)
        data.pop("heartbeat_at", None)
        data.pop("current_target_date", None)

    def recover_stale_run(self, now: datetime | None = None) -> bool:
        """Release a RUNNING receipt whose owner died or stopped heartbeating."""
        night = self._load_state()
        if str(night.get("status") or "").lower() != "running":
            return False
        local_now = now or datetime.now().astimezone()
        live, reason = running_lease_status(night, local_now)
        if live:
            return False
        self._clear_lease(night)
        night.update({
            "status": "interrupted",
            "complete": False,
            "last_error": f"stale preparation recovered ({reason}); partial output kept and retry released",
            "finished_at": local_now.isoformat(timespec="seconds"),
        })
        self._save_state(night)
        print(f"[RECOVERY] Recovered stale Long-to-Short preparation ({reason}); partial inventory kept, retry released.")
        return True

    async def _heartbeat_lease(self, token: str) -> None:
        while True:
            await asyncio.sleep(15)
            try:
                current = self._load_state()
                if (
                    str(current.get("status") or "").lower() != "running"
                    or str(current.get("owner_token") or "") != token
                ):
                    return
                current["heartbeat_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
                self._save_state(current)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                # A transient Windows replace/file-lock race must not silently kill
                # the lease task and make a healthy preparation look INTERRUPTED.
                print(f"⚠️ Long-to-Short heartbeat write retry: {type(exc).__name__}: {exc}")

    def episode_handoff(self) -> dict[str, Any]:
        """Return the durable upstream gate consumed by Episode Splitter.

        This deliberately reads the last completed LTS plan instead of rebuilding
        target dates from the current clock.  A long render may cross midnight;
        that successful completion must still release Episode prep immediately.
        """
        plan = self.plan()
        if not plan:
            return {
                "ready": True,
                "status": "not_required",
                "complete": True,
                "handoff_id": "lts:not_required",
            }
        state = self._load_state()
        signature = str(state.get("requirements_signature") or "")
        complete = bool(state.get("complete")) and str(state.get("status") or "").lower() == "ready"
        handoff_id = ""
        if signature:
            handoff_id = "lts:" + hashlib.sha256(signature.encode("utf-8")).hexdigest()[:20]
        return {
            "ready": bool(complete and handoff_id),
            "status": str(state.get("status") or "waiting"),
            "complete": complete,
            "handoff_id": handoff_id,
            "finished_at": str(state.get("finished_at") or ""),
            "target_dates": list(state.get("target_dates") or []),
            "last_error": str(state.get("last_error") or ""),
        }

    @staticmethod
    def _clock(now: datetime, value: str, fallback: str = "21:00") -> datetime:
        try:
            h, m = [int(x) for x in str(value or fallback).split(":", 1)]
            return now.replace(hour=h, minute=m, second=0, microsecond=0)
        except Exception:
            h, m = [int(x) for x in fallback.split(":", 1)]
            return now.replace(hour=h, minute=m, second=0, microsecond=0)

    @classmethod
    def _mode(cls, route: dict[str, Any]) -> str | None:
        raw = str(route.get("output_type") or "transformative_envo_mm").strip().lower()
        mode = cls.OUTPUT_ALIASES.get(raw, raw)
        return mode if mode in cls.OUTPUT_MODES else None

    def plan(self) -> dict[str, dict[str, Any]]:
        """Build category-aware daily requirements from enabled LTS routes.

        Same content category + same content_group reuses the same moments across
        Voiceover/Original routes. ``prep_buffer_days`` belongs to the content
        category and controls how many future date inventories are kept full.
        """
        cats = self.settings.categories().get("categories") or {}
        cat = cats.get(self.CATEGORY) or {}
        if not cat.get("enabled", True):
            return {}
        profiles = cat.get("content_categories") or {}
        rules = cat.get("production_rules") or {}
        out: dict[str, dict[str, Any]] = {}
        for route_key, route in (cat.get("routes") or {}).items():
            if not isinstance(route, dict) or not route.get("enabled", True):
                continue
            target = max(0, int(route.get("daily_limit") or 0))
            if target <= 0:
                continue
            mode = self._mode(route)
            if not mode:
                continue
            try:
                resolved = self.settings.resolve_route(self.CATEGORY, str(route_key))
                fb = resolved.get("facebook"); tt = resolved.get("tiktok")
                want_fb = bool(fb and fb.get("enabled", True)); want_tt = bool(tt and tt.get("enabled", True))
            except Exception:
                want_fb = want_tt = False
            if not want_fb and not want_tt:
                continue
            content_category = str(route.get("lts_category") or route.get("content_type") or "motivation").strip().lower().replace("-", "_") or "motivation"
            profile_cfg = profiles.get(content_category) or {}
            if profile_cfg and not profile_cfg.get("enabled", True):
                continue
            reuse = str(route.get("content_group") or "main").strip() or "main"
            bucket = f"{content_category}::{reuse}"
            row = out.setdefault(bucket, {
                "content_category": content_category,
                "selector_profile": str(profile_cfg.get("selector_profile") or content_category),
                "source_urls": list(profile_cfg.get("source_urls") or []),
                "min_score": float(profile_cfg.get("min_editorial_score") or rules.get("min_editorial_score") or 8.8),
                "max_candidates_per_source": max(1, int(profile_cfg.get("max_candidates_per_source") or rules.get("max_candidates_per_source") or 5)),
                "scan_limit": max(1, int(profile_cfg.get("scan_limit") or 12)),
                "min_source_seconds": max(0.0, float(profile_cfg.get("min_source_minutes") or 10) * 60.0),
                "prep_buffer_days": max(1, min(7, int(profile_cfg.get("prep_buffer_days") or 3))),
                "requirements": {}, "routes": [],
            })
            # All routes in one bucket should normally share one content category,
            # but retain the largest requested buffer if legacy/mixed data exists.
            row["prep_buffer_days"] = max(int(row.get("prep_buffer_days") or 1), max(1, min(7, int(profile_cfg.get("prep_buffer_days") or 3))))
            row["routes"].append(str(route_key))
            req = row["requirements"]
            req[mode] = max(int(req.get(mode, 0)), target)
        return out

    def requirements(self) -> dict[str, dict[str, int]]:
        return {bucket: dict(row.get("requirements") or {}) for bucket, row in self.plan().items()}

    @staticmethod
    def _req_signature(value: Any) -> str:
        # A schema revision forces one safe catch-up prep so old video-only rows
        # receive their exact locked social copy before any future upload.
        return json.dumps({"post_copy_schema": TTLongToShortNightService.POST_COPY_SCHEMA, "plan": value}, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

    @staticmethod
    def _future_date_plans(now: datetime, plan: dict[str, dict[str, Any]]) -> list[tuple[str, dict[str, dict[str, Any]]]]:
        """Expand daily bucket requirements into date-scoped future plans."""
        max_days = max([max(1, int((row or {}).get("prep_buffer_days") or 1)) for row in plan.values()] or [0])
        result: list[tuple[str, dict[str, dict[str, Any]]]] = []
        for offset in range(1, max_days + 1):
            date = (now.date() + timedelta(days=offset)).isoformat()
            date_plan: dict[str, dict[str, Any]] = {}
            for bucket, row in plan.items():
                if offset > max(1, int((row or {}).get("prep_buffer_days") or 1)):
                    continue
                date_plan[bucket] = dict(row)
            if date_plan:
                result.append((date, date_plan))
        return result

    async def _prepare(
        self, target_date: str, plan: dict[str, dict[str, Any]], *, timeout_hours: float,
    ) -> dict[str, Any]:
        if not self.runner.exists():
            raise FileNotFoundError(f"Standalone Long-to-Short bridge runner missing: {self.runner}")
        tmp_dir = self.root / "state" / "tt_long_to_short_pending"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix="night_prepare_", suffix=".json", dir=str(tmp_dir))
        os.close(fd); result_path = Path(name)
        plan_path = result_path.with_suffix('.plan.json')
        log_path = self.root / 'logs' / f'lts_prepare_{target_date}_{result_path.stem}.log'
        log_path.parent.mkdir(parents=True, exist_ok=True)
        pump_task = None
        activity_path = result_path.with_suffix('.activity.json')
        try:
            self._atomic(plan_path, plan)
            cmd = [
                sys.executable, '-u', "-X", "utf8", str(self.runner), "prepare",
                "--date", target_date,
                '--plan-file', str(plan_path),
                "--json-out", str(result_path),
            ]
            print(f"🔋 TT IDLE PREP → Long-to-Short for {target_date} | categories={list(plan)}")
            print(f"   Standalone root: {self.lts_root}")
            print(f'   Worker log: {log_path}')
            proc = await asyncio.create_subprocess_exec(*cmd, cwd=str(self.lts_root), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
            try:
                self._atomic(activity_path, {
                    'category': self.CATEGORY, 'worker_pid': proc.pid,
                    'target_date': target_date, 'groups': list(plan),
                    'started_at': datetime.now().astimezone().isoformat(timespec='seconds'),
                    'worker_log': str(log_path),
                })
            except OSError as exc:
                print(f'⚠️ Preparation activity could not be saved: {exc}')

            async def mirror_output() -> None:
                decoder = codecs.getincrementaldecoder('utf-8')(errors='replace')
                with log_path.open('w', encoding='utf-8', newline='') as log:
                    while True:
                        chunk = await proc.stdout.read(8192)
                        text = decoder.decode(chunk, final=not chunk)
                        if text:
                            log.write(text); log.flush()
                            print(text.replace('\r\n', '\n'), end='', flush=True)
                        if not chunk:
                            break

            pump_task = asyncio.create_task(mirror_output())
            try:
                await asyncio.wait_for(proc.wait(), timeout=max(0.25, float(timeout_hours)) * 3600.0)
            except asyncio.CancelledError:
                print("🛑 Long-to-Short night prep cancelled; terminating standalone child process.")
                proc.terminate()
                try:
                    await asyncio.wait_for(proc.wait(), timeout=15.0)
                except asyncio.TimeoutError:
                    proc.kill(); await proc.wait()
                raise
            except asyncio.TimeoutError:
                print(f"⚠️ Long-to-Short night prep exceeded {timeout_hours:g}h for {target_date}; stopping this attempt safely.")
                proc.terminate()
                try:
                    await asyncio.wait_for(proc.wait(), timeout=15.0)
                except asyncio.TimeoutError:
                    proc.kill(); await proc.wait()
                raise RuntimeError(f'long_to_short_night_prep_timeout; worker log: {log_path}')
            await pump_task
            if not result_path.exists() or not result_path.stat().st_size:
                raise RuntimeError(f"Long-to-Short night prep returned no structured result (exit={proc.returncode}); worker log: {log_path}")
            try:
                data = json.loads(result_path.read_text(encoding='utf-8-sig'))
                if not isinstance(data, dict):
                    raise ValueError('result must be a JSON object')
            except ValueError as exc:
                raise RuntimeError(f'Invalid Long-to-Short worker JSON (exit={proc.returncode}); worker log: {log_path}') from exc
            if proc.returncode != 0 or not bool(data.get("ok")):
                raise RuntimeError(str(data.get("error") or f"Long-to-Short night prep exit={proc.returncode}") + f'; worker log: {log_path}')
            data['worker_log'] = str(log_path)
            return data
        finally:
            if pump_task is not None and not pump_task.done():
                pump_task.cancel()
                with suppress(asyncio.CancelledError):
                    await pump_task
            try:
                result_path.unlink(missing_ok=True)
                plan_path.unlink(missing_ok=True)
                activity_path.unlink(missing_ok=True)
            except OSError:
                pass

    async def run_if_due(self, state: dict[str, Any], decision: dict[str, Any], now: datetime) -> bool:
        """Fill the configured future buffer only when normal TT posting is idle."""
        cats = self.settings.categories().get("categories") or {}
        cat = cats.get(self.CATEGORY) or {}
        rules = cat.get("production_rules") or {}
        if not cat or not cat.get("enabled", True) or not bool(rules.get("night_prep_enabled", True)):
            return False
        if decision.get("status") not in {"complete", "no_safe_slot"}:
            return False
        if state.get("current_job"):
            return False
        plan = self.plan()
        if not plan:
            return False
        date_plans = self._future_date_plans(now, plan)
        if not date_plans:
            return False
        target_dates = [d for d, _ in date_plans]
        signature_payload = {d: p for d, p in date_plans}
        signature = self._req_signature(signature_payload)
        night = self._load_state()
        same_plan = list(night.get("target_dates") or []) == target_dates and str(night.get("requirements_signature") or "") == signature
        if str(night.get("status") or "").lower() == "running":
            live, _reason = running_lease_status(night, now)
            if live:
                return False
            self.recover_stale_run(now)
            night = self._load_state()
        if same_plan and bool(night.get("complete")):
            return False

        retry_minutes = max(5, int(rules.get("night_retry_minutes") or 60))
        retry_immediately = str(night.get("status") or "").lower() == "interrupted"
        retry_base = night.get('finished_at') or night.get('last_attempt_at')
        if same_plan and retry_base and not retry_immediately:
            try:
                last = datetime.fromisoformat(str(retry_base).replace("Z", "+00:00"))
                if last.tzinfo is None: last = last.astimezone()
                if now < last.astimezone(now.tzinfo) + timedelta(minutes=retry_minutes):
                    return False
            except Exception:
                pass

        night = {
            **(night if same_plan else {}),
            "version": 2,
            "target_date": target_dates[0],  # backwards-compatible first future date
            "target_dates": target_dates,
            "buffer_days": len(target_dates),
            "date_plans": signature_payload,
            "requirements": {k: dict(v.get("requirements") or {}) for k, v in plan.items()},
            "requirements_signature": signature,
            "status": "running",
            "complete": False,
            "last_attempt_at": now.isoformat(timespec="seconds"),
            "last_error": "",
            "date_results": dict(night.get("date_results") or {}) if same_plan else {},
            "owner_pid": self.owner_pid,
            "owner_token": self.owner_token,
            "heartbeat_at": now.isoformat(timespec="seconds"),
        }
        self._save_state(night)
        heartbeat_task = asyncio.create_task(self._heartbeat_lease(self.owner_token), name="tt:lts-prep-heartbeat")
        try:
            date_results: dict[str, Any] = dict(night.get("date_results") or {})
            all_complete = True
            timeout_hours = max(0.25, float(rules.get("max_runtime_hours") or 6))
            for target_date, date_plan in date_plans:
                night["current_target_date"] = target_date
                night["heartbeat_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
                self._save_state(night)
                result = await self._prepare(target_date, date_plan, timeout_hours=timeout_hours)
                date_results[target_date] = result
                date_complete = bool(result.get("complete"))
                all_complete = all_complete and date_complete
                night.update({
                    "status": "running" if date_complete else "shortfall",
                    "complete": False,
                    "date_results": date_results,
                    "last_completed_date": target_date,
                    "last_error": "",
                })
                self._save_state(night)
                if not date_complete:
                    # A shortfall means the standalone source pool could not fill
                    # this nearer date. Do not waste time trying farther dates in
                    # the same attempt; retry the deficit later instead.
                    break

            # All configured dates count as READY only when each returned complete.
            all_complete = len(date_results) >= len(target_dates) and all(bool((date_results.get(d) or {}).get("complete")) for d in target_dates)
            night.update({
                "status": "ready" if all_complete else "shortfall",
                "complete": all_complete,
                "date_results": date_results,
                "last_error": "",
                "finished_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            })
            self._clear_lease(night)
            self._save_state(night)
            if all_complete:
                print(f"✅ Long-to-Short future buffer READY → {target_dates[0]}..{target_dates[-1]} ({len(target_dates)} day(s))")
            else:
                print(f"⚠️ Long-to-Short future buffer SHORTFALL; will retry after {retry_minutes}m if night is still idle.")
        except asyncio.CancelledError:
            self._clear_lease(night)
            night.update({
                "status": "interrupted", "complete": False,
                "last_error": "TT Master stopped while preparation was running; partial output kept and retry released",
                "finished_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            })
            self._save_failure_state(night, "interrupted")
            print("[INTERRUPTED] Long-to-Short preparation stopped; partial inventory kept and retry released.")
            raise
        except Exception as exc:
            self._clear_lease(night)
            night.update({
                "status": "error", "complete": False,
                "last_error": f"{type(exc).__name__}: {exc}",
                "finished_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            })
            self._save_failure_state(night, "failure")
            print(f"⚠️ Long-to-Short night prep failed without affecting TT posting queue: {exc}")
        finally:
            heartbeat_task.cancel()
            with suppress(asyncio.CancelledError):
                await heartbeat_task
        return True
