import os
import asyncio
import json
import socket
import re
import time
import unicodedata
from pathlib import Path
from services.fb_profile_paths import page_store, profile_path
from playwright.async_api import async_playwright

try:
    from services.fb_session_snapshot import restore_snapshot, save_snapshot
except ImportError:
    from fb_session_snapshot import restore_snapshot, save_snapshot

try:
    from services.page_recovery import recover_blank_page, recover_page_ladder
except ImportError:
    from page_recovery import recover_blank_page, recover_page_ladder

try:
    from services.playwright_runtime import install_playwright_target_closed_filter
except ImportError:
    from playwright_runtime import install_playwright_target_closed_filter

try:
    from services.health_monitor import note_login_lost, note_processing, note_event
except ImportError:
    from health_monitor import note_login_lost, note_processing, note_event

try:
    from services.platform_caption_service import normalize_platform_caption_hashtags
except ImportError:
    from platform_caption_service import normalize_platform_caption_hashtags


def _fb_proxy_config():
    """Chromium uses the OS network / external VPN; no local proxy is required."""
    return None


class FacebookUploadStalled(TimeoutError):
    """Raised only while a pre-Share video transfer percentage is genuinely stuck."""


async def _select_file_via_native_windows_dialog(page, trigger, file_path: str) -> None:
    """Use the real Windows Open dialog for one explicitly scoped upload."""
    try:
        from services.tt_service import (
            _complete_windows_file_dialog,
            _visible_windows_file_dialogs,
        )
    except ImportError:
        from tt_service import _complete_windows_file_dialog, _visible_windows_file_dialogs

    existing = await asyncio.to_thread(_visible_windows_file_dialogs)
    session = await page.context.new_cdp_session(page)
    await session.send("Page.setInterceptFileChooserDialog", {"enabled": False})
    dialog_task = asyncio.create_task(
        asyncio.to_thread(_complete_windows_file_dialog, file_path, existing)
    )
    try:
        try:
            await trigger.click(timeout=60_000, force=True, no_wait_after=True)
        finally:
            await dialog_task
    finally:
        await session.detach()
    print("✅ Facebook video selected through the real Windows Open dialog")


async def _read_fb_upload_progress(page) -> float | None:
    """Read Meta's visible upload percentage without guessing from elapsed time."""
    try:
        value = await page.evaluate(r"""() => {
            const visible = (el) => {
                if (!el) return false;
                const style = getComputedStyle(el);
                const rect = el.getBoundingClientRect();
                return style.display !== 'none' && style.visibility !== 'hidden' &&
                       Number(style.opacity || 1) !== 0 && rect.width > 0 && rect.height > 0;
            };
            const values = [];
            for (const el of document.querySelectorAll('progress')) {
                if (!visible(el)) continue;
                const maximum = Number(el.max || 1);
                const current = Number(el.value || 0);
                if (Number.isFinite(current) && Number.isFinite(maximum) && maximum > 0) {
                    values.push(current / maximum * 100);
                }
            }
            for (const el of document.querySelectorAll('[role="progressbar"]')) {
                if (!visible(el)) continue;
                const current = Number(el.getAttribute('aria-valuenow'));
                if (Number.isFinite(current)) values.push(current);
            }
            for (const el of document.querySelectorAll('div,span,p')) {
                if (!visible(el)) continue;
                const text = (el.innerText || el.textContent || '').trim();
                const match = text.match(/^(\d{1,3}(?:\.\d+)?)\s*%$/);
                if (!match) continue;
                const current = Number(match[1]);
                if (Number.isFinite(current)) values.push(current);
            }
            const valid = values.filter(v => v >= 0 && v <= 100);
            return valid.length ? Math.max(...valid) : null;
        }""")
        return None if value is None else max(0.0, min(100.0, float(value)))
    except Exception:
        return None


async def _fb_video_selection_accepted(page) -> bool:
    """Return true only after Meta has hydrated the selected local video.

    A filename plus a 0% bar is not sufficient: for very large Episode Splitter
    files Meta can display both while its file-picker event was dispatched too
    quickly and the preview remains a permanently black Loading shell.
    """
    progress = await _read_fb_upload_progress(page)
    if progress is not None and progress > 0.05:
        return True
    try:
        next_button = page.get_by_role("button", name="Next").last
        if (
            await next_button.count()
            and await next_button.is_visible()
            and await next_button.is_enabled()
            and await next_button.get_attribute("aria-disabled") != "true"
        ):
            return True
    except Exception:
        pass
    try:
        return bool(await page.evaluate(r"""() => {
            const visible = (el) => {
                if (!el) return false;
                const s = getComputedStyle(el), r = el.getBoundingClientRect();
                return s.display !== 'none' && s.visibility !== 'hidden' &&
                       Number(s.opacity || 1) !== 0 && r.width > 0 && r.height > 0;
            };
            return [...document.querySelectorAll('video')].some(v =>
                visible(v) && v.readyState >= 1 && v.videoWidth > 0 &&
                Number.isFinite(v.duration) && v.duration > 0
            );
        }"""))
    except Exception:
        return False


async def _wait_fb_video_selection_accepted(page, timeout_ms: int) -> bool:
    """Bound the fragile large-file picker-to-upload transition."""
    loop = asyncio.get_running_loop()
    deadline = loop.time() + max(15_000, int(timeout_ms)) / 1000.0
    last_report = 0.0
    while loop.time() < deadline:
        if await _fb_video_selection_accepted(page):
            print("✅ Facebook selected video accepted — preview/upload state hydrated.")
            return True
        now = loop.time()
        if now - last_report >= 15.0:
            print("⏳ Facebook selected video acceptance wait — preview/progress not ready yet...")
            last_report = now
        await page.wait_for_timeout(2_000)
    return False


async def _wait_role_button_enabled(page, name: str, timeout_ms: int, *, label: str | None = None):
    """Wait for a Meta role=button to exist, be visible, enabled, and stable.

    Meta often renders Next/Share early with aria-disabled=true while a large video
    is still uploading/processing. Clicking immediately causes Playwright's 30s
    click timeout even though the upload is still healthy.
    """
    label = label or name
    loop = asyncio.get_running_loop()
    deadline = loop.time() + max(30_000, int(timeout_ms)) / 1000.0
    last_log_bucket = -1
    stable = 0
    monitor_transfer = label == "Next (video processing)"
    try:
        stall_seconds = max(60, int(os.getenv("FB_UPLOAD_STALL_SECONDS", "300")))
    except (TypeError, ValueError):
        stall_seconds = 300
    last_progress = None
    last_progress_change_at = loop.time()
    next_progress_probe_at = 0.0
    progress_visible = False

    while loop.time() < deadline:
        remaining = max(0, int(deadline - loop.time()))
        elapsed = max(0, int(timeout_ms / 1000) - remaining)
        bucket = elapsed // 15

        try:
            btn = page.get_by_role("button", name=name).last
            count = await btn.count()
            visible = bool(count) and await btn.is_visible()
            enabled = visible and await btn.is_enabled()
            aria_disabled = await btn.get_attribute("aria-disabled") if visible else None
            disabled_attr = await btn.get_attribute("disabled") if visible else None

            ready = (
                visible
                and enabled
                and aria_disabled != "true"
                and disabled_attr is None
            )

            if ready:
                stable += 1
                if stable >= 2:
                    print(f"✅ Facebook {label} ready.")
                    return btn
            else:
                stable = 0

            progress = last_progress if progress_visible else None
            if monitor_transfer and loop.time() >= next_progress_probe_at:
                progress = await _read_fb_upload_progress(page)
                progress_visible = progress is not None
                next_progress_probe_at = loop.time() + 5.0
            if progress is not None:
                # Facebook can update in coarse jumps. Only a new high-water mark
                # proves forward transfer; a bouncing/regressing value must not keep
                # an actually-stalled upload alive forever.
                if last_progress is None or progress >= last_progress + 0.5:
                    last_progress = progress
                    last_progress_change_at = loop.time()
                # Do not call stable 100% a transfer stall: Meta may spend several
                # minutes server-processing after the bytes have finished uploading.
                elif progress < 99.5 and loop.time() - last_progress_change_at >= stall_seconds:
                    raise FacebookUploadStalled(
                        f"Facebook video upload stuck at {progress:.1f}% for "
                        f"{stall_seconds // 60}m{stall_seconds % 60:02d}s"
                    )

            if bucket != last_log_bucket:
                progress_text = f", progress={progress:.1f}%" if progress is not None else ""
                print(
                    f"⏳ Facebook {label} စောင့်နေပါတယ်... "
                    f"visible={visible}, enabled={enabled}, "
                    f"remaining≈{remaining // 60}m{remaining % 60:02d}s{progress_text}"
                )
                last_log_bucket = bucket
        except FacebookUploadStalled:
            raise
        except Exception:
            stable = 0
            if bucket != last_log_bucket:
                print(
                    f"⏳ Facebook {label} UI စောင့်နေပါတယ်... "
                    f"remaining≈{remaining // 60}m{remaining % 60:02d}s"
                )
                last_log_bucket = bucket

        await page.wait_for_timeout(2000)

    raise TimeoutError(
        f"Facebook {label} button timeout: video upload/processing did not finish "
        f"within {max(30_000, int(timeout_ms)) // 1000}s."
    )


class BrowserService:
    def __init__(self, user_data_dir="./browser_sessions"):
        # Resolve the Page-login profile relative to the TT project root, not the
        # process working directory. This keeps Repair/Test and actual uploads on
        # the exact same persistent profile even when a bridge changes cwd.
        raw = Path(str(user_data_dir))
        if raw.is_absolute():
            self.user_data_dir = str(raw)
        else:
            self.user_data_dir = str((Path(__file__).resolve().parents[1] / raw).resolve())

    def _page_profile_store(self, profile_name, page_id):
        base = Path(self.user_data_dir)
        if base.name not in {"browser_sessions", "browser_profiles"}:
            return "browser_sessions"
        return page_store(base.parent, profile_name, page_id)

    def _page_profile_path(self, profile_name, page_id):
        base = Path(self.user_data_dir)
        if base.name not in {"browser_sessions", "browser_profiles"}:
            path = (base / str(profile_name)).resolve()
            if path.parent != base.resolve():
                raise ValueError("Invalid Facebook profile name")
            return path
        return profile_path(base.parent, profile_name, self._page_profile_store(profile_name, page_id))

    # ==========================================
    # 🎬 FB REELS + PERMALINK RETURN (V5.9)
    # ==========================================
    @staticmethod
    def _normalize_fb_permalink(href):
        """Return only a REAL Facebook Reel/video permalink.

        Important: /reel or /reel/ is just the Reels navigation route, not a
        published Reel. Older code accepted it and saved
        https://www.facebook.com/reel as if it were a post URL.
        """
        if not href:
            return ""
        href = str(href).strip()
        if href.startswith("/"):
            href = "https://www.facebook.com" + href
        if not href.startswith("http"):
            return ""

        base = href.split("?", 1)[0].split("#", 1)[0].rstrip("/")

        # Canonical Reel URL must contain a non-empty ID/token after /reel/.
        m = re.search(r"https?://(?:www\.)?facebook\.com/reel/([^/]+)$", base, re.I)
        if m:
            token = m.group(1).strip()
            if len(token) >= 5 and token.lower() not in {"reel", "reels", "videos"}:
                return f"https://www.facebook.com/reel/{token}"

        # Some Page layouts still expose /<page>/videos/<id>. Keep it only if
        # there is a real token after /videos/.
        m = re.search(r"https?://(?:www\.)?facebook\.com/(.+?/)?videos/([^/]+)$", base, re.I)
        if m:
            token = m.group(2).strip()
            if len(token) >= 5:
                return base

        return ""

    @staticmethod
    def _identity_text(value):
        value = re.sub(r"\s+", " ", str(value or "")).strip().casefold()
        # Facebook sometimes adds separators / verification labels around names.
        return value.replace("·", " ").strip()

    @classmethod
    def _clean_page_name(cls, value):
        value = re.sub(r"\s+", " ", str(value or "")).strip()
        value = re.sub(r"\s*[|\-–]\s*Facebook.*$", "", value, flags=re.I).strip()
        if not value:
            return ""
        identity = cls._identity_text(value)
        # Notification counters and follower labels are Facebook shell text, not
        # Page identities. Accepting them makes a brand-new Page scan unrelated
        # Reels from another Page managed by the same account.
        if re.fullmatch(r"\(?\d+\)?\s*facebook", identity) or re.fullmatch(r"[\d,.]+\s+(?:followers?|following)", identity):
            return ""
        generic = {
            "facebook", "chats", "chat", "reels", "reel", "home", "notifications",
            "notification", "menu", "watch", "videos", "video", "photos", "photo",
            "posts", "post", "about", "profile", "professional dashboard",
            "meta business suite", "business suite", "create", "settings", "search",
            "messages", "message",
            "manage page",
        }
        return "" if identity in generic else value

    @classmethod
    def _configured_page_identity_for_id(cls, page_id):
        """Resolve authoritative Page name/slug metadata from TT's registry.

        Upload bridges historically passed only profile/page_id, even though the
        registry already contained the real Page name.  Using that trusted mapping
        lets owner verification work when Facebook's profile route renders only a
        generic shell heading such as Chats or Manage Page.
        """
        target = str(page_id or "").strip()
        if not target:
            return {"page_name":"", "canonical_path":""}
        path = Path(__file__).resolve().parents[1] / "config" / "tt_accounts.json"
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            for account in (data.get("facebook_pages") or {}).values():
                if str((account or {}).get("page_id") or "").strip() != target:
                    continue
                return {
                    "page_name":cls._clean_page_name((account or {}).get("label")),
                    "canonical_path":cls._canonical_fb_profile_path(
                        (account or {}).get("canonical_path") or (account or {}).get("slug")
                    ),
                }
        except Exception:
            pass
        return {"page_name":"", "canonical_path":""}

    @classmethod
    def _configured_page_name_for_id(cls, page_id):
        return cls._configured_page_identity_for_id(page_id).get("page_name", "")

    @staticmethod
    def _canonical_fb_profile_path(value):
        if not value:
            return ""
        value = str(value).strip()
        if value.startswith("/"):
            value = "https://www.facebook.com" + value
        try:
            clean = value.split("?", 1)[0].split("#", 1)[0].rstrip("/")
            m = re.match(r"https?://(?:www\.)?facebook\.com(/[^/?#]+)", clean, re.I)
            if not m:
                return ""
            path = m.group(1).rstrip("/")
            if path.casefold() in {
                "/profile.php", "/reel", "/reels", "/watch", "/groups", "/marketplace",
                "/gaming", "/messages", "/notifications",
            }:
                return ""
            return path
        except Exception:
            return ""

    async def _resolve_page_identity(self, context, page_id, page_name_hint=""):
        """Resolve the real Page identity without mistaking Facebook shell headings for the Page name."""
        hinted_name = self._clean_page_name(page_name_hint)
        configured=self._configured_page_identity_for_id(page_id)
        configured_name = hinted_name or configured.get("page_name", "")
        configured_path = configured.get("canonical_path", "")
        if configured_name:
            source = "caller hint" if hinted_name else "TT account registry"
            extra=f", slug={configured_path}" if configured_path else ""
            print(f"✅ FB Page identity from {source}: {configured_name} (id={page_id}{extra})")
            return {
                'page_id': str(page_id),
                'page_name': configured_name,
                'page_name_key': self._identity_text(configured_name),
                'canonical_path': configured_path,
                'identity_source': 'configured_account_hint' if hinted_name else 'configured_account_registry',
            }

        probe = await context.new_page()
        target = f"https://www.facebook.com/profile.php?id={page_id}"
        try:
            try:
                await probe.goto(target, timeout=90000, wait_until="domcontentloaded")
            except Exception:
                pass
            await recover_blank_page(probe, target_url=target, label="FB Page identity", settle_ms=5000, max_reloads=2)

            page_name = ""
            for selector in ('meta[property="og:title"]', 'meta[name="twitter:title"]'):
                try:
                    loc = probe.locator(selector).first
                    if await loc.count():
                        candidate = self._clean_page_name(await loc.get_attribute("content"))
                        if candidate:
                            page_name = candidate
                            break
                except Exception:
                    pass

            if not page_name:
                try:
                    anchors = probe.locator('a[href]')
                    count = min(await anchors.count(), 180)
                    for i in range(count):
                        a = anchors.nth(i)
                        href = str(await a.get_attribute('href') or '').casefold()
                        if f'profile.php?id={page_id}' not in href and f'profile.php/?id={page_id}' not in href:
                            continue
                        vals=[]
                        try: vals.append(await a.inner_text())
                        except Exception: pass
                        for attr in ('aria-label','title'):
                            try: vals.append(await a.get_attribute(attr))
                            except Exception: pass
                        for v in vals:
                            cleaned=self._clean_page_name(v)
                            if cleaned:
                                page_name=cleaned; break
                        if page_name: break
                except Exception:
                    pass

            if not page_name:
                for selector in ('div[role="main"] h1','h1'):
                    try:
                        loc=probe.locator(selector).first
                        if await loc.count():
                            candidate=self._clean_page_name(await loc.inner_text())
                            if candidate:
                                page_name=candidate; break
                    except Exception:
                        pass

            if not page_name:
                try: page_name=self._clean_page_name(await probe.title())
                except Exception: pass

            canonical_path=""
            for selector,attr in (('meta[property="og:url"]','content'),('link[rel="canonical"]','href')):
                try:
                    loc=probe.locator(selector).first
                    if await loc.count():
                        canonical_path=self._canonical_fb_profile_path(await loc.get_attribute(attr))
                        if canonical_path: break
                except Exception: pass
            if not canonical_path:
                canonical_path=self._canonical_fb_profile_path(probe.url)

            identity={
                'page_id':str(page_id), 'page_name':page_name,
                'page_name_key':self._identity_text(page_name), 'canonical_path':canonical_path,
            }
            if page_name:
                print(f"✅ FB Page identity resolved: {page_name} (id={page_id}, slug={canonical_path or '?'})")
            else:
                print(f"⚠️ FB Page name unresolved (id={page_id}) — generic UI headings ignored")
            return identity
        finally:
            try: await probe.close()
            except Exception: pass

    async def _reel_belongs_to_target_page(self, context, reel_url, identity, quick=False):
        probe = await context.new_page()
        try:
            try:
                await probe.goto(reel_url, timeout=70000, wait_until='domcontentloaded')
            except Exception:
                return False
            await recover_blank_page(probe, target_url=reel_url, label="FB Reel owner probe", settle_ms=3500 if quick else 5000, max_reloads=1)

            page_id=str(identity.get('page_id') or '')
            name_key=str(identity.get('page_name_key') or '')
            canonical_path=str(identity.get('canonical_path') or '').casefold().rstrip('/')
            try:
                anchors=probe.locator('a[href]'); count=min(await anchors.count(),180)
                for i in range(count):
                    a=anchors.nth(i); href=str(await a.get_attribute('href') or ''); href_cf=href.casefold()
                    if page_id and (f'profile.php?id={page_id}' in href_cf or f'profile.php/?id={page_id}' in href_cf):
                        return True
                    if canonical_path:
                        absolute='https://www.facebook.com'+href if href.startswith('/') else href
                        m=re.match(r'https?://(?:www\.)?facebook\.com(/[^/?#]+)',absolute,re.I)
                        if m and m.group(1).casefold().rstrip('/')==canonical_path:
                            return True
                    if name_key:
                        values=[]
                        try: values.append(await a.inner_text())
                        except Exception: pass
                        for attr in ('aria-label','title'):
                            try: values.append(await a.get_attribute(attr))
                            except Exception: pass
                        if any(self._identity_text(v)==name_key or self._identity_text(v).startswith(name_key+' ') for v in values if v):
                            return True
            except Exception:
                pass

            if name_key:
                for selector,attr in (('meta[property="og:title"]','content'),('meta[name="twitter:title"]','content')):
                    try:
                        loc=probe.locator(selector).first
                        if await loc.count():
                            mk=self._identity_text(await loc.get_attribute(attr))
                            if mk==name_key or mk.startswith(name_key+' ') or mk.startswith(name_key+' |') or mk.startswith(name_key+' -'):
                                return True
                    except Exception: pass

            if page_id:
                try:
                    html=await probe.content(); pid=re.escape(page_id)
                    pats=[
                        rf'"owner"\s*:\s*\{{[^{{}}]{{0,700}}"id"\s*:\s*"?{pid}"?',
                        rf'"actor"\s*:\s*\{{[^{{}}]{{0,700}}"id"\s*:\s*"?{pid}"?',
                        rf'"author"\s*:\s*\{{[^{{}}]{{0,700}}"id"\s*:\s*"?{pid}"?',
                        rf'"page_id"\s*:\s*"?{pid}"?', rf'"pageID"\s*:\s*"?{pid}"?',
                    ]
                    if any(re.search(p,html,re.I|re.S) for p in pats): return True
                except Exception: pass
            return False
        finally:
            try: await probe.close()
            except Exception: pass

    async def _collect_page_raw_reel_links(self, context, page_id, max_links=40, quick=False):
        urls=[
            f"https://www.facebook.com/profile.php?id={page_id}&sk=reels_tab",
            f"https://www.facebook.com/profile.php?id={page_id}",
        ]
        raw=[]; seen=set(); probe=await context.new_page()
        try:
            for url in urls:
                try: await probe.goto(url,timeout=90000,wait_until='domcontentloaded')
                except Exception: pass
                await recover_blank_page(probe,target_url=url,label="FB Page Reels",settle_ms=3500 if quick else 5500,max_reloads=1)
                roots=[probe.locator('div[role="main"]').first,probe]
                for root in roots:
                    for selector in ('a[href*="/reel/"]','a[href*="/videos/"]'):
                        try:
                            anchors=root.locator(selector) if root is not probe else probe.locator(selector)
                            count=min(await anchors.count(),max(16,max_links*2))
                            for i in range(count):
                                link=self._normalize_fb_permalink(await anchors.nth(i).get_attribute('href'))
                                if link and link not in seen:
                                    seen.add(link); raw.append(link)
                                    if len(raw)>=max_links: break
                        except Exception: pass
                    if raw: break
                if raw and quick: break
                if len(raw)>=max_links: break
        finally:
            try: await probe.close()
            except Exception: pass
        return raw[:max_links]

    async def _collect_page_reel_links(
        self, context, page_id, max_links=40, quick=False, page_name_hint="",
    ):
        identity=await self._resolve_page_identity(context,page_id,page_name_hint=page_name_hint)
        if identity.get('page_name'):
            extra=f", slug={identity.get('canonical_path')}" if identity.get('canonical_path') else ''
            print(f"🪪 FB Page owner filter: {identity.get('page_name')} (id={page_id}{extra})")
        else:
            print(f"🪪 FB Page owner filter: id={page_id} (Page name unresolved; Chats/UI heading ignored)")
        if not identity.get('page_name_key') and not identity.get('canonical_path'):
            print(
                "🛡️ FB Reel lookup fail-closed: target Page identity unresolved; "
                "raw/recommended Reels will not be opened or guessed."
            )
            return []
        raw=await self._collect_page_raw_reel_links(context,page_id,max_links=max_links,quick=quick)
        verified=[]; cap=min(len(raw),max(10,max_links if not quick else 12))
        for link in raw[:cap]:
            try: owned=await self._reel_belongs_to_target_page(context,link,identity,quick=quick)
            except Exception: owned=False
            if owned:
                verified.append(link)
                if len(verified)>=max_links: break
            else:
                print(f"🔎 Owner metadata not verified; exclude from verified baseline: {link}")
        print(f"✅ Page-owned Reel links: {len(verified)} / raw candidates {len(raw)}")
        return verified

    def _recorded_prior_reel_links(self):
        """Exclude Reels already published by Recap when Page baseline loading fails."""
        registry = Path(__file__).resolve().parents[1] / "downloads" / "recap_source_registry.json"
        try:
            data = json.loads(registry.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return set()
        links = set()
        for entries in (data.get("posted_by_page") or {}).values():
            if not isinstance(entries, list):
                continue
            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                link = self._normalize_fb_permalink(entry.get("post_link"))
                if link:
                    links.add(link)
        return links

    async def _extract_published_reel_permalink(
        self, context, page, page_id, timeout_ms=240000,
        baseline_links=None, baseline_raw_links=None, page_name_hint="",
        expected_caption="",
    ):
        # None means the pre-upload baseline could not be established. An empty
        # set means it was established successfully and this was a brand-new Page
        # with zero Reels. That distinction lets the first owner-verified Reel be
        # accepted safely after Share without guessing another managed Page's Reel.
        baseline_known = baseline_links is not None
        raw_baseline_known = baseline_raw_links is not None
        baseline=set(baseline_links or []); baseline_raw=set(baseline_raw_links or [])
        recorded_prior=self._recorded_prior_reel_links()
        baseline.update(recorded_prior)
        baseline_raw.update(recorded_prior)
        if recorded_prior:
            print(f"Excluding {len(recorded_prior)} already-recorded Reel link(s) from recovery candidates")
        deadline=asyncio.get_event_loop().time()+max(30.0,timeout_ms/1000.0)
        last_latest=''
        prior_raw_candidates=set()
        raw_candidate_streaks={}

        async def from_page(pg):
            # Only explicit publish-confirmation actions on the composer are trusted.
            # Generic /reel/ anchors can be recommendations from another managed Page.
            for selector in ('a:has-text("View reel")','a:has-text("View Reel")','a:has-text("View post")','a:has-text("View Post")'):
                try:
                    loc=pg.locator(selector); count=min(await loc.count(),20)
                    for i in range(count):
                        link=self._normalize_fb_permalink(await loc.nth(i).get_attribute('href'))
                        compare=baseline_raw or baseline
                        if link and link not in recorded_prior and (not baseline_known or link not in compare): return link
                except Exception: pass
            link=self._normalize_fb_permalink(pg.url); compare=baseline_raw or baseline
            return link if link and link not in recorded_prior and (not baseline_known or link not in compare) else ''

        async def from_stable_caption_delta():
            nonlocal prior_raw_candidates, raw_candidate_streaks
            if not raw_baseline_known or not expected_caption:
                return ''
            try:
                raw_links=await self._collect_page_raw_reel_links(
                    context, str(page_id), max_links=30, quick=True,
                )
                current_candidates=[link for link in raw_links if link not in baseline_raw]
                current_set=set(current_candidates)
                next_streaks={}
                for candidate in current_candidates:
                    next_streaks[candidate]=(raw_candidate_streaks.get(candidate,0)+1
                                             if candidate in prior_raw_candidates else 1)
                raw_candidate_streaks=next_streaks
                prior_raw_candidates=current_set
                for candidate in current_candidates[:3]:
                    streak=raw_candidate_streaks.get(candidate,0)
                    print(f"🆕 New Page-route Reel candidate: {candidate} (stable {streak}/2)")
                    if streak < 2:
                        continue
                    matched=await self._page_post_matches_caption_fingerprint(
                        context, candidate, expected_caption, quick=True,
                    )
                    if matched:
                        print(f"✅ New Reel verified by baseline + stability + caption: {candidate}")
                        return candidate
                    print(f"🚫 New Reel candidate caption does not match this upload: {candidate}")
            except Exception as exc:
                print(f"⚠️ Reel caption-fingerprint rescue warning: {exc}")
            return ''

        print("🔗 Published Reel permalink ကို strong mode နဲ့ စောင့်ရှာနေပါတယ်...")
        attempt=0
        while asyncio.get_event_loop().time()<deadline:
            attempt+=1
            try:
                link=await from_page(page)
                if link:
                    print(f"✅ New Reel permalink found from publish UI: {link}"); return link
            except Exception: pass

            # Try the exact Page-route delta before opening every candidate for the
            # slower owner-metadata scan. On affected Meta layouts this resolves on
            # the second lightweight scan instead of spending minutes probing ten
            # Reels whose owner metadata is hidden.
            link=await from_stable_caption_delta()
            if link:
                return link

            # A full owner scan can consume the whole verification window before
            # a new raw candidate gets its second stability observation. When we
            # have this upload's baseline and caption, keep polling that evidence.
            if raw_baseline_known and expected_caption:
                print(f"⏳ Reel baseline/caption verification wait ({attempt})...")
                await page.wait_for_timeout(8000)
                continue

            try:
                links=await self._collect_page_reel_links(
                    context, str(page_id), max_links=30, quick=True,
                    page_name_hint=page_name_hint,
                )
                if links:
                    last_latest=links[0]; compare=baseline or baseline_raw
                    if baseline_known:
                        for link in links:
                            if link not in compare:
                                print(f"✅ New Page Reel detected (not in baseline): {link}"); return link
            except Exception as exc:
                print(f"⚠️ Reel owner probe warning: {exc}")

            print(f"⏳ Reel permalink မပေါ်သေးပါ — publish/indexing wait ({attempt})...")
            await page.wait_for_timeout(8000)

        if not baseline and not baseline_raw and last_latest:
            print("⚠️ Baseline မရှိတဲ့အတွက် visible Reel ကို guess မလုပ်ပါ။ Safe recovery လိုပါမည်။")
        print("⚠️ Facebook Reel တက်ပြီးပေမယ့် NEW Reel permalink ကို timeout အတွင်း မတွေ့သေးပါ။")
        return ''

    async def recover_latest_reel_permalink(
        self, profile_name, page_id, timeout_ms=180000, page_name_hint="",
    ):
        """Recovery helper for a Reel already published but saved without its link."""
        resolved_profile_path = self._page_profile_path(profile_name, page_id)
        async with async_playwright() as p:
            context = await p.chromium.launch_persistent_context(
                str(resolved_profile_path),
                headless=False,
                args=["--disable-blink-features=AutomationControlled", "--disable-notifications"],
                proxy=_fb_proxy_config(),
            )
            try:
                deadline = asyncio.get_event_loop().time() + max(30.0, timeout_ms / 1000.0)
                attempt = 0
                while asyncio.get_event_loop().time() < deadline:
                    attempt += 1
                    links = await self._collect_page_reel_links(
                        context, str(page_id), max_links=30, quick=False,
                        page_name_hint=page_name_hint,
                    )
                    if links:
                        print(f"✅ Recovery: latest Page Reel permalink = {links[0]}")
                        return links[0]
                    print(f"⏳ Recovery: Page Reel link မတွေ့သေးပါ ({attempt})...")
                    await asyncio.sleep(8)
                return ""
            finally:
                await context.close()

    async def recover_reel_permalink_by_caption(
        self,
        profile_name,
        page_id,
        expected_caption,
        timeout_ms=300000,
        page_name_hint="",
        baseline_links=None,
        baseline_raw_links=None,
    ):
        """Recover a Share-clicked Reel without risking a duplicate re-upload.

        Meta can accept and publish a large Reel while Page-route indexing lags
        beyond the original Composer verification window. On a later scheduler
        turn there is no safe pre-upload baseline, so owner + caption fingerprint
        is the required identity proof.
        """
        resolved_profile_path = self._page_profile_path(profile_name, page_id)
        resolved_profile_store = resolved_profile_path.parent.name if resolved_profile_path.parent.name in {"browser_sessions", "browser_profiles"} else "browser_sessions"
        async with async_playwright() as p:
            context = await p.chromium.launch_persistent_context(
                str(resolved_profile_path),
                headless=False,
                args=["--disable-blink-features=AutomationControlled", "--disable-notifications"],
                proxy=_fb_proxy_config(),
            )
            try:
                await restore_snapshot(context, profile_name, profile_store=resolved_profile_store)
                if baseline_raw_links is not None:
                    # Old restored tabs may point at an unrelated Reel; only the
                    # stored baseline and caption are publish evidence on recovery.
                    page = await context.new_page()
                    return await self._extract_published_reel_permalink(
                        context, page, str(page_id), timeout_ms=timeout_ms,
                        baseline_links=baseline_links,
                        baseline_raw_links=baseline_raw_links,
                        page_name_hint=page_name_hint,
                        expected_caption=expected_caption,
                    )
                deadline = asyncio.get_running_loop().time() + max(30.0, timeout_ms / 1000.0)
                attempt = 0
                while asyncio.get_running_loop().time() < deadline:
                    attempt += 1
                    links = await self._collect_page_reel_links(
                        context,
                        str(page_id),
                        max_links=20,
                        quick=False,
                        page_name_hint=page_name_hint,
                    )
                    for link in links[:8]:
                        if await self._page_post_matches_caption_fingerprint(
                            context, link, expected_caption, quick=False,
                        ):
                            print(f"✅ Pending Facebook Reel recovered by owner + caption: {link}")
                            return link
                    print(
                        f"⏳ Pending Facebook Reel not indexed/matched yet "
                        f"(recovery attempt {attempt})..."
                    )
                    await asyncio.sleep(12)
                return ""
            finally:
                await context.close()

    @staticmethod
    def _clean_page_post_candidate(url: str) -> str:
        """Canonicalize a normal Facebook post/photo URL without notification tracking."""
        raw=str(url or "").strip()
        if not raw:
            return ""
        try:
            from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
            parts=urlsplit(raw)
            if "facebook.com" not in (parts.netloc or "").casefold():
                return ""
            path=parts.path or ""
            # Keep only query parameters that are part of the actual content identity.
            keep=[]
            for k,v in parse_qsl(parts.query, keep_blank_values=True):
                if k.casefold() in {"story_fbid","id","fbid","set"}:
                    keep.append((k,v))
            return urlunsplit((parts.scheme or "https", parts.netloc or "www.facebook.com", path, urlencode(keep), "")).rstrip("?")
        except Exception:
            return raw.split("&__cft__",1)[0].split("?notif_id=",1)[0]

    @staticmethod
    def _caption_fingerprint(text: str, limit: int = 72) -> str:
        """Compact Unicode caption fingerprint for exact Facebook content recovery.

        Facebook can change whitespace/line-breaks and hide hashtags behind See-more.
        Keep only Unicode letters/marks/numbers so the beginning of the actual caption
        can still be compared deterministically across feed and permalink views.
        """
        raw=unicodedata.normalize("NFKC", str(text or ""))
        # Hashtags are useful for sharing but too generic to identify one Drama post.
        raw=re.sub(r"#[^\s#]+", " ", raw)
        compact="".join(
            ch.casefold() for ch in raw
            if unicodedata.category(ch)[:1] in {"L", "M", "N"}
        )
        if limit and limit > 0:
            return compact[:int(limit)]
        return compact

    async def _page_post_matches_caption_fingerprint(self, context, post_url, expected_caption, quick=False):
        """Verify that a candidate Page post/Reel is THIS job, not merely the same Page.

        A Page can contain many valid owner-verified posts.  Recovery must therefore
        match the Facebook caption fingerprint before group sharing.  This is also the
        safe rescue path for legacy pending jobs created before a pre-upload baseline
        was stored.
        """
        expected=self._caption_fingerprint(expected_caption, 72)
        if len(expected) < 12:
            print("⚠️ Facebook caption fingerprint unavailable/too short — fail closed")
            return False
        probe=await context.new_page()
        url=self._clean_page_post_candidate(post_url)
        try:
            try:
                await probe.goto(url, timeout=70000, wait_until="domcontentloaded")
            except Exception:
                return False
            await recover_blank_page(
                probe, target_url=url, label="FB Page post fingerprint probe",
                settle_ms=2200 if quick else 3800, max_reloads=1,
            )
            chunks=[]
            for sel in ('div[role="article"]', 'main', 'body'):
                try:
                    loc=probe.locator(sel)
                    count=min(await loc.count(), 6 if sel.startswith('div') else 1)
                    for i in range(count):
                        node=loc.nth(i)
                        if await node.is_visible():
                            txt=(await node.inner_text()).strip()
                            if txt:
                                chunks.append(txt)
                    if chunks and sel.startswith('div'):
                        break
                except Exception:
                    continue
            actual=self._caption_fingerprint(" ".join(chunks), 0)
            # Prefer a strong prefix, but tolerate Facebook's occasional first-word
            # decoration by allowing progressively shorter (still specific) prefixes.
            probes=[]
            for n in (72, 56, 44, 32, 24):
                if len(expected) >= n:
                    probes.append(expected[:n])
            if not probes:
                probes=[expected]
            matched=any(fp and fp in actual for fp in probes)
            if matched:
                print("🧬 Facebook caption fingerprint MATCH")
            else:
                print("🚫 Recovery reject Facebook content: caption fingerprint does not match")
            return matched
        finally:
            try: await probe.close()
            except Exception: pass

    async def _page_post_belongs_to_target_page(self, context, post_url, identity, quick=False):
        """Fail-closed owner check for normal Page posts/carousels.

        Never accept a /posts/ URL merely because it was visible while browsing the Page.
        Facebook can surface posts from the logged-in personal account in the same shell.
        """
        url=self._clean_page_post_candidate(post_url)
        if not url:
            return False
        page_id=str(identity.get("page_id") or "")
        canonical_path=str(identity.get("canonical_path") or "").casefold().rstrip("/")

        # Fast path: if a canonical Page slug is known, a direct /slug/posts/... URL
        # must match it.  This immediately rejects personal-profile URLs such as
        # /thar.laimar.52/posts/... when the configured destination is another Page.
        try:
            m=re.match(r"https?://(?:www\.)?facebook\.com(/[^/?#]+)/(?:posts|photos)(?:/|$)",url,re.I)
            if m and canonical_path:
                owner_path=m.group(1).casefold().rstrip("/")
                if owner_path != canonical_path:
                    return False
                return True
        except Exception:
            pass

        probe=await context.new_page()
        try:
            try:
                await probe.goto(url, timeout=70000, wait_until="domcontentloaded")
            except Exception:
                return False
            await recover_blank_page(probe,target_url=url,label="FB Page post owner probe",settle_ms=3000 if quick else 5000,max_reloads=1)

            name_key=str(identity.get("page_name_key") or "")
            try:
                anchors=probe.locator("a[href]"); count=min(await anchors.count(),220)
                for i in range(count):
                    a=anchors.nth(i); href=str(await a.get_attribute("href") or ""); href_cf=href.casefold()
                    if page_id and (f"profile.php?id={page_id}" in href_cf or f"profile.php/?id={page_id}" in href_cf):
                        return True
                    if canonical_path:
                        absolute="https://www.facebook.com"+href if href.startswith("/") else href
                        mm=re.match(r"https?://(?:www\.)?facebook\.com(/[^/?#]+)",absolute,re.I)
                        if mm and mm.group(1).casefold().rstrip("/")==canonical_path:
                            return True
                    if name_key:
                        vals=[]
                        try: vals.append(await a.inner_text())
                        except Exception: pass
                        for attr in ("aria-label","title"):
                            try: vals.append(await a.get_attribute(attr))
                            except Exception: pass
                        if any(self._identity_text(v)==name_key or self._identity_text(v).startswith(name_key+" ") for v in vals if v):
                            return True
            except Exception:
                pass

            if page_id:
                try:
                    html=await probe.content(); pid=re.escape(page_id)
                    pats=[
                        rf'"owner"\s*:\s*\{{[^{{}}]{{0,900}}"id"\s*:\s*"?{pid}"?',
                        rf'"actor"\s*:\s*\{{[^{{}}]{{0,900}}"id"\s*:\s*"?{pid}"?',
                        rf'"author"\s*:\s*\{{[^{{}}]{{0,900}}"id"\s*:\s*"?{pid}"?',
                        rf'"page_id"\s*:\s*"?{pid}"?', rf'"pageID"\s*:\s*"?{pid}"?',
                    ]
                    if any(re.search(p,html,re.I|re.S) for p in pats):
                        return True
                except Exception:
                    pass
            return False
        finally:
            try: await probe.close()
            except Exception: pass

    async def verify_page_post_permalink(self, profile_name, page_id, post_url, timeout_ms=90000, expected_caption=""):
        """Fail-closed owner + optional exact-caption verifier used before group share."""
        resolved_profile_path = self._page_profile_path(profile_name, page_id)
        async with async_playwright() as p:
            context=await p.chromium.launch_persistent_context(
                str(resolved_profile_path),headless=False,
                args=["--disable-blink-features=AutomationControlled","--disable-notifications"],
                proxy=_fb_proxy_config(),
            )
            try:
                identity=await self._resolve_page_identity(context,str(page_id))
                owned=await asyncio.wait_for(
                    self._page_post_belongs_to_target_page(context,post_url,identity,quick=True),
                    timeout=max(30.0,timeout_ms/1000.0),
                )
                if not owned:
                    return False
                if expected_caption:
                    return await asyncio.wait_for(
                        self._page_post_matches_caption_fingerprint(context,post_url,expected_caption,quick=True),
                        timeout=max(30.0,timeout_ms/1000.0),
                    )
                return True
            except Exception as exc:
                print(f"⚠️ FB Page post owner/fingerprint verification warning: {exc}")
                return False
            finally:
                await context.close()

    def _page_feed_post_targets(self, identity, page_id):
        """Stable Page FEED/POST routes only; never intentionally browse Photos."""
        pid=str(page_id or "").strip()
        canonical=str((identity or {}).get("canonical_path") or "").strip().rstrip("/")
        urls=[]
        if canonical:
            urls.extend([
                f"https://www.facebook.com{canonical}?sk=posts",
                f"https://www.facebook.com{canonical}/posts/",
            ])
        urls.extend([
            f"https://www.facebook.com/profile.php?id={pid}&sk=posts",
            f"https://www.facebook.com/profile.php?id={pid}",
        ])
        out=[]
        for u in urls:
            if u and u not in out: out.append(u)
        return out

    def _business_suite_post_targets(self, page_id):
        """Meta-owned content views used before public Page-feed scraping.

        These routes are asset-scoped, so they cannot surface an unrelated personal
        profile post as the current Page's latest content.
        """
        pid=str(page_id or "").strip()
        return [
            f"https://business.facebook.com/latest/content?asset_id={pid}",
            f"https://business.facebook.com/latest/content/posts?asset_id={pid}",
        ]

    async def _recover_page_post_from_business_suite(self, context, page, identity, page_id, baseline, expected_caption):
        if not expected_caption:
            return ""
        for target in self._business_suite_post_targets(page_id):
            try:
                print(f"🔎 Drama exact-post fallback → Meta Business Suite content: {target}")
                await page.goto(target,wait_until="domcontentloaded",timeout=80000)
                await recover_blank_page(page,target_url=target,label="FB Business Suite content recovery",settle_ms=3000,max_reloads=1)
                # The content table/card can lazy-load; caption-local resolution is
                # stronger than relying on Meta's constantly changing FeedUnit wrappers.
                for step in range(10):
                    ui_link=await self._resolve_caption_post_link_from_ui(page,expected_caption)
                    if ui_link:
                        candidate=self._clean_page_post_candidate(ui_link)
                        if baseline and candidate in baseline:
                            return ""
                        owned=await self._page_post_belongs_to_target_page(context,candidate,identity,quick=True)
                        if owned and await self._page_post_matches_caption_fingerprint(context,candidate,expected_caption,quick=True):
                            print(f"✅ Recovery: EXACT Page post resolved from Meta Business Suite content → {candidate}")
                            return candidate
                    try:
                        await page.mouse.wheel(0,900); await asyncio.sleep(1.0)
                    except Exception:
                        pass
            except Exception as exc:
                print(f"⚠️ Meta Business Suite exact-post recovery warning: {exc}")
        return ""

    async def _resolve_caption_post_link_from_ui(self, page, expected_caption: str) -> str:
        """Last-resort resolver for Meta Page layouts with no direct post href in feed DOM.

        Finds the smallest visible block containing this job's caption, then follows
        nearby short/timestamp-style links in a temporary tab and accepts only a final
        URL that canonicalizes as a real Facebook post permalink. The caller still
        performs owner + caption fingerprint verification, so this is discovery only.
        """
        snippet=str(expected_caption or "").split("\n",1)[0].strip()
        snippet=re.sub(r"#[^\s#]+"," ",snippet).strip()
        snippet=re.sub(r"\s+"," ",snippet)[:42]
        if len(snippet)<8:return ""
        try:
            candidates=await page.evaluate("""needle => {
                const rows=[]; const seen=new Set();
                const nodes=[...document.querySelectorAll('div,span')]
                  .filter(el=>{const t=(el.innerText||'').replace(/\\s+/g,' ').trim();return t.includes(needle)})
                  .sort((a,b)=>(a.innerText||'').length-(b.innerText||'').length)
                  .slice(0,6);
                for(const n of nodes){
                  let cur=n;
                  for(let depth=0;cur&&depth<8;depth++,cur=cur.parentElement){
                    for(const a of cur.querySelectorAll('a[href]')){
                      const href=a.href||''; if(!href||seen.has(href))continue; seen.add(href);
                      const text=(a.innerText||a.getAttribute('aria-label')||a.getAttribute('title')||'').trim();
                      let score=0; const h=href.toLowerCase();
                      if(h.includes('/posts/')||h.includes('story_fbid=')||h.includes('permalink.php')||h.includes('pfbid'))score+=100;
                      if(text.length>0&&text.length<=28)score+=8;
                      if(/(^|\\s)(just now|\\d+\\s*(m|h|d|min|hr|hrs|day|days))($|\\s)/i.test(text))score+=20;
                      rows.push({href,text,score});
                    }
                  }
                }
                return rows.sort((a,b)=>b.score-a.score).slice(0,16);
            }""",snippet)
        except Exception:
            return ""
        for item in candidates or []:
            href=str((item or {}).get("href") or "")
            direct=self._clean_page_post_candidate(href)
            if direct:
                cf=direct.casefold()
                if "/posts/" in cf or "story_fbid=" in cf or "permalink.php" in cf or "pfbid" in cf:
                    return direct
            # Some timestamp links are opaque tracking/story URLs. Follow them in a
            # disposable tab and inspect the final redirected address.
            try:
                probe=await page.context.new_page()
                try:
                    await probe.goto(href,wait_until="domcontentloaded",timeout=45000)
                    await asyncio.sleep(1.2)
                    final=self._clean_page_post_candidate(probe.url)
                    cf=final.casefold()
                    if final and ("/posts/" in cf or "story_fbid=" in cf or "permalink.php" in cf or "pfbid" in cf):
                        return final
                finally:
                    try:await probe.close()
                    except Exception:pass
            except Exception:
                continue
        return ""

    async def _collect_post_links_on_page_feed(self, page, *, max_links=30, expected_caption="", broad_fallback=False):
        """Collect likely normal-post permalinks from the current Page UI.

        Meta currently uses several feed shells. Some Page posts are not wrapped in
        ``div[role=article]`` at all, so V2.0.5 could scroll past a freshly-published
        post and still report zero candidates. We now inspect article + FeedUnit
        containers and, when a caption is known, the smallest DOM containers that
        actually contain that caption. A global href fallback is used only after the
        feed has been scrolled deeply; owner+caption verification remains mandatory.
        """
        selectors=[
            'div[role="article"] a[href]',
            '[data-pagelet*="FeedUnit"] a[href]',
            '[data-pagelet*="TimelineFeedUnit"] a[href]',
            'div[data-ad-preview="message"] a[href]',
        ]
        raw=[]

        def accept(href):
            h=self._clean_page_post_candidate(str(href or ""))
            if not h or "/reel/" in h or "/videos/" in h or "/photos/" in h or "photo.php" in h:
                return ""
            cf=h.casefold()
            if "/posts/" not in cf and "story_fbid=" not in cf and "permalink.php" not in cf and "pfbid" not in cf:
                return ""
            return h

        for sel in selectors:
            try:
                vals=await page.locator(sel).evaluate_all("els=>els.map(e=>e.href).filter(Boolean)")
            except Exception:
                vals=[]
            for href in vals:
                h=accept(href)
                if h and h not in raw:
                    raw.append(h)
                    if len(raw)>=max_links:return raw

        # Strong recovery path: locate DOM blocks that contain THIS post's caption,
        # then inspect links in that local ancestry. This survives Page UI wrappers
        # that have neither role=article nor data-pagelet=FeedUnit.
        if expected_caption:
            snippet=str(expected_caption or "").split("\n",1)[0].strip()
            snippet=re.sub(r"#[^\s#]+"," ",snippet).strip()
            snippet=re.sub(r"\s+"," ",snippet)[:42]
            if len(snippet)>=8:
                try:
                    vals=await page.evaluate("""([needle,limit]) => {
                        const out=[]; const seen=new Set();
                        const add=(a)=>{if(!a||!a.href||seen.has(a.href))return;seen.add(a.href);out.push(a.href)};
                        const nodes=[...document.querySelectorAll('div,span')]
                          .filter(el=>{const t=(el.innerText||'').replace(/\\s+/g,' ').trim();return t.includes(needle)})
                          .sort((a,b)=>(a.innerText||'').length-(b.innerText||'').length)
                          .slice(0,8);
                        for(const n of nodes){
                          let cur=n;
                          for(let depth=0;cur&&depth<7;depth++,cur=cur.parentElement){
                            for(const a of cur.querySelectorAll('a[href]')){add(a); if(out.length>=limit)return out}
                          }
                        }
                        return out;
                    }""",[snippet,max_links])
                except Exception:
                    vals=[]
                for href in vals:
                    h=accept(href)
                    if h and h not in raw:
                        raw.insert(0,h)
                        if len(raw)>=max_links:return raw[:max_links]

        if broad_fallback:
            # Safe now because every candidate is later owner-verified and, for
            # Drama/Astrology carousel recovery, caption-fingerprint verified too.
            try:
                vals=await page.locator('a[href]').evaluate_all("els=>els.map(e=>e.href).filter(Boolean)")
            except Exception:
                vals=[]
            for href in vals:
                h=accept(href)
                if h and h not in raw:
                    raw.append(h)
                    if len(raw)>=max_links:return raw
        return raw

    async def _scroll_page_feed_to_real_posts(self, page, *, label="FB Page feed", max_steps=20, max_links=30, expected_caption=""):
        """Scroll through Page header/media modules and locate real post candidates.

        New Meta layouts can lazy-load Posts much farther down than 14 viewport steps,
        and some use FeedUnit wrappers instead of role=article. The final deep-scan
        fallback is still fail-closed because recovery verifies Page owner + caption.
        """
        last_y=-1
        for step in range(1,max_steps+1):
            links=await self._collect_post_links_on_page_feed(page,max_links=max_links,expected_caption=expected_caption,broad_fallback=False)
            if links:
                if step>1: print(f"✅ {label}: Page post candidates reached after scroll step {step-1}")
                return links
            try:
                metrics=await page.evaluate("""() => ({
                    y: window.scrollY || 0,
                    h: window.innerHeight || 800,
                    sh: Math.max(document.body?.scrollHeight||0, document.documentElement?.scrollHeight||0)
                })""")
                y=int(metrics.get('y') or 0);h=max(600,int(metrics.get('h') or 800));sh=int(metrics.get('sh') or 0)
                if step==1:print(f"🔽 {label}: scanning below Page header/media blocks for Posts")
                await page.evaluate("dy => window.scrollBy(0, dy)",int(h*0.95))
                await asyncio.sleep(1.25)
                new_y=int(await page.evaluate("() => window.scrollY || 0"))
                if new_y==y==last_y and sh and (new_y+h)>=sh-80:
                    await asyncio.sleep(2.2)
                    await page.evaluate("() => window.scrollTo(0, document.body.scrollHeight)")
                    await asyncio.sleep(1.2)
                last_y=new_y
            except Exception:
                try:await page.mouse.wheel(0,1000);await asyncio.sleep(1.25)
                except Exception:pass
        links=await self._collect_post_links_on_page_feed(page,max_links=max_links,expected_caption=expected_caption,broad_fallback=True)
        if links:
            print(f"🧭 {label}: deep DOM fallback found {len(links)} post candidate(s) after {max_steps} scroll steps")
            return links
        print(f"⚠️ {label}: no Page post candidate found after {max_steps} scroll steps + deep DOM scan")
        return []

    async def collect_page_post_baseline(self, profile_name, page_id, timeout_ms=90000):
        """Capture current Page-feed post links before publishing, for safe pre/post delta."""
        resolved_profile_path = self._page_profile_path(profile_name, page_id)
        async with async_playwright() as p:
            context=await p.chromium.launch_persistent_context(
                str(resolved_profile_path), headless=False,
                args=["--disable-blink-features=AutomationControlled","--disable-notifications"],
                proxy=_fb_proxy_config(),
            )
            try:
                identity=await self._resolve_page_identity(context,str(page_id))
                page=context.pages[0] if context.pages else await context.new_page()
                baseline=[]
                deadline=asyncio.get_event_loop().time()+max(20.0,timeout_ms/1000.0)
                for target in self._page_feed_post_targets(identity,page_id):
                    if asyncio.get_event_loop().time()>=deadline: break
                    try:
                        await page.goto(target,wait_until="domcontentloaded",timeout=min(70000,timeout_ms))
                        await recover_blank_page(page,target_url=target,label="FB Page post baseline",settle_ms=3000,max_reloads=1)
                        links=await self._scroll_page_feed_to_real_posts(page,label="FB Page post baseline",max_steps=20,max_links=40)
                        for h in links:
                            if h not in baseline: baseline.append(h)
                        if baseline: break
                    except Exception as exc:
                        print(f"⚠️ Page post baseline warning: {exc}")
                print(f"🧾 Drama Page-feed post baseline: {len(baseline)} link(s)")
                return baseline
            finally:
                await context.close()

    async def recover_latest_page_post_permalink(self, profile_name, page_id, timeout_ms=120000, baseline_urls=None, expected_caption=""):
        """Recover a newly published OWNER-VERIFIED Page FEED post/carousel.

        Browse Posts/Feed routes, not Photos.  A fresh job must pass BOTH pre-upload
        baseline delta and Facebook-caption fingerprint.  Legacy pending jobs that
        predate baseline storage are recoverable only by a strong caption fingerprint.
        Personal-account links, old Page posts, and same-Page wrong posts fail closed.
        """
        resolved_profile_path = self._page_profile_path(profile_name, page_id)
        baseline={self._clean_page_post_candidate(x) for x in (baseline_urls or []) if self._clean_page_post_candidate(x)}
        async with async_playwright() as p:
            context = await p.chromium.launch_persistent_context(
                str(resolved_profile_path),
                headless=False,
                args=["--disable-blink-features=AutomationControlled", "--disable-notifications"],
                proxy=_fb_proxy_config(),
            )
            try:
                page=context.pages[0] if context.pages else await context.new_page()
                identity=await self._resolve_page_identity(context,str(page_id))
                targets=self._page_feed_post_targets(identity,page_id)
                # HARD recovery budget: never spin forever looking for a share link.
                # One call performs at most THREE complete recovery passes. The Drama
                # bridge also persists a 3-invocation budget before skipping secondary
                # group sharing and releasing the queue.
                deadline=asyncio.get_event_loop().time()+max(30.0,timeout_ms/1000.0)
                for attempt in range(1,4):
                    if asyncio.get_event_loop().time()>=deadline: break
                    found_any=False
                    print(f"🔎 Drama Page-post recovery pass {attempt}/3")
                    # Primary fallback for legacy pending jobs whose publish-time exact
                    # permalink was not captured: search the asset-scoped Business Suite
                    # content view by THIS caption before touching the public Page feed.
                    exact=await self._recover_page_post_from_business_suite(
                        context,page,identity,page_id,baseline,expected_caption
                    )
                    if exact:
                        return exact
                    for target in targets:
                        if asyncio.get_event_loop().time()>=deadline: break
                        try:
                            if attempt==1:
                                print(f"🔎 Drama Page-post recovery feed → {target}")
                            await page.goto(target,wait_until="domcontentloaded",timeout=min(60000,max(15000,int((deadline-asyncio.get_event_loop().time())*1000))))
                            await recover_blank_page(page,target_url=target,label="FB Page post recovery feed",settle_ms=2500,max_reloads=1)
                            seen=await self._scroll_page_feed_to_real_posts(page,label="FB Page post recovery",max_steps=20,max_links=50,expected_caption=expected_caption)
                            if not seen and expected_caption:
                                ui_link=await self._resolve_caption_post_link_from_ui(page,expected_caption)
                                if ui_link:
                                    print(f"🧭 Drama Page-post recovery: caption-local timestamp/link resolved → {ui_link}")
                                    seen=[ui_link]
                            if seen: found_any=True
                            for candidate in seen[:18]:
                                if baseline and candidate in baseline:
                                    continue
                                owned=await self._page_post_belongs_to_target_page(context,candidate,identity,quick=True)
                                if not owned:
                                    print(f"🚫 Recovery reject non-Page/personal post: {candidate}")
                                    continue
                                if expected_caption:
                                    matched=await self._page_post_matches_caption_fingerprint(
                                        context,candidate,expected_caption,quick=True
                                    )
                                    if not matched:
                                        continue
                                elif not baseline:
                                    print("🛡️ Recovery held: same-Page candidate found but no baseline/fingerprint identity")
                                    continue
                                print(f"✅ Recovery: EXACT new owner+fingerprint Page feed post permalink = {candidate}")
                                return candidate
                        except Exception as exc:
                            print(f"⚠️ Page feed permalink recovery warning: {exc}")
                    suffix="; only baseline/old posts visible" if found_any and baseline else ""
                    print(f"⏳ Recovery: new owner-verified Page FEED post not indexed yet ({attempt}/3){suffix}...")
                    if attempt<3 and asyncio.get_event_loop().time()<deadline:
                        await asyncio.sleep(5)
                print("⏭️ Drama Page-post recovery exhausted 3/3 passes — return empty and let bridge budget/log/skip decide.")
                return ""
            finally:
                await context.close()

    async def _close_stale_pages(self, context, keep_page, *, label="FB stale-tab cleanup") -> None:
        """Close every tab except the active workflow tab.

        Recovery can leave an old renderer-hung composer tab alive.  That stale tab
        later blocks/derails the permalink probe in some Chromium sessions.  Close it
        only after a healthy replacement tab is confirmed, and never fail the upload
        merely because Chromium refuses to close a wedged renderer immediately.
        """
        pages = list(context.pages)
        stale = [pg for pg in pages if pg is not keep_page]
        if not stale:
            return
        print(f"🧹 {label}: closing {len(stale)} stale tab(s) before continuing")
        for idx, pg in enumerate(stale, 1):
            try:
                await asyncio.wait_for(pg.close(run_before_unload=False), timeout=4.0)
                print(f"✅ {label}: stale tab {idx}/{len(stale)} closed")
            except Exception as exc:
                # A truly hung renderer may refuse a normal Page.close().  Keep the
                # active page usable and log it; the context will clean it on exit.
                print(f"⚠️ {label}: stale tab {idx}/{len(stale)} close warning: {exc}")

    @staticmethod
    def _page_is_attached(context, page) -> bool:
        """Return whether Playwright still owns the page, not merely its visible window.

        Chromium can leave a visible tab/window behind after its Playwright pipe has
        disconnected.  In that state the user still sees the tab, but every locator
        action raises TargetClosedError.  Always validate protocol ownership before
        starting the stateful file-upload step.
        """
        try:
            return page is not None and not page.is_closed() and page in context.pages
        except Exception:
            return False

    @staticmethod
    async def _select_reel_thumbnail(page, thumbnail_path: str) -> bool:
        """Select a custom Reel cover without affecting callers that omit it."""
        thumbnail = Path(thumbnail_path).resolve()
        if not thumbnail.exists() or thumbnail.stat().st_size < 500:
            raise FileNotFoundError(f"Facebook Reel thumbnail missing or invalid: {thumbnail}")

        async def visible_image_input():
            inputs = page.locator('input[type="file"]')
            for index in range(await inputs.count()):
                control = inputs.nth(index)
                accept = str(await control.get_attribute("accept") or "").casefold()
                if "image" in accept or any(ext in accept for ext in (".jpg", ".jpeg", ".png", ".webp")):
                    return control
            return None

        # Meta uses Thumbnail in some locales/builds and Cover in others.
        open_pattern = re.compile(r"^(edit\s+)?(thumbnail|cover)( photo| image)?$", re.I)
        for _ in range(8):
            image_input = await visible_image_input()
            if image_input is not None:
                await image_input.set_input_files(str(thumbnail))
                await page.wait_for_timeout(1800)
                break

            opened = False
            candidates = page.get_by_text(open_pattern)
            for index in range(min(await candidates.count(), 12)):
                candidate = candidates.nth(index)
                try:
                    if await candidate.is_visible():
                        await candidate.click(timeout=5000)
                        opened = True
                        await page.wait_for_timeout(900)
                        break
                except Exception:
                    continue

            upload_pattern = re.compile(r"^(upload|add|choose|select)( photo| image| thumbnail| cover)?$", re.I)
            uploaders = page.get_by_text(upload_pattern)
            chooser_used = False
            for index in range(min(await uploaders.count(), 12)):
                uploader = uploaders.nth(index)
                try:
                    if not await uploader.is_visible():
                        continue
                    async with page.expect_file_chooser(timeout=5000) as chooser_info:
                        await uploader.click(timeout=5000)
                    chooser = await chooser_info.value
                    await chooser.set_files(str(thumbnail))
                    chooser_used = True
                    await page.wait_for_timeout(1800)
                    break
                except Exception:
                    continue
            if chooser_used:
                break
            if not opened:
                await page.wait_for_timeout(1000)
        else:
            raise RuntimeError("Meta Reels custom thumbnail control was not found")

        # Crop dialogs use different confirmation labels across Meta builds.
        confirm_pattern = re.compile(r"^(save|done|apply|use|confirm)$", re.I)
        confirms = page.get_by_role("button", name=confirm_pattern)
        for index in range(min(await confirms.count(), 8)):
            button = confirms.nth(index)
            try:
                if await button.is_visible() and await button.is_enabled():
                    await button.click(timeout=5000)
                    await page.wait_for_timeout(1200)
                    break
            except Exception:
                continue
        print(f"✅ Facebook custom Reel thumbnail selected: {thumbnail.name}")
        return True

    async def upload_reel_stealth(
        self, profile_name, page_id, caption, video_path,
        thumbnail_path=None, page_name_hint="", capture_permalink=True,
        file_selection_delay_ms=0, upload_acceptance_timeout_ms=0,
        prefer_native_dialog=False,
    ):
        """Upload a Reel with two bounded retries for a proven transfer stall."""
        caption = normalize_platform_caption_hashtags(caption, "facebook", limit=5)
        receipt_path = self._reel_publish_receipt_path(video_path, page_id)
        if receipt_path.exists():
            receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
            if (str(receipt.get("page_id")) != str(page_id)
                    or receipt.get("caption_fingerprint") != self._caption_fingerprint(caption, 0)):
                raise RuntimeError("Facebook pending publication identity differs from this upload")
            link = self._normalize_fb_permalink(receipt.get("post_link"))
            if not link:
                print("♻️ Facebook Share already attempted — recover this Reel instead of re-uploading")
                link = self._normalize_fb_permalink(await self.recover_reel_permalink_by_caption(
                    profile_name, page_id, caption, timeout_ms=300000,
                    page_name_hint=page_name_hint,
                    baseline_links=receipt.get("baseline_links"),
                    baseline_raw_links=receipt.get("baseline_raw_links"),
                ))
            if link:
                receipt.update(status="verified", post_link=link)
                self._save_reel_publish_receipt(receipt_path, receipt)
            return {"success": bool(link), "post_link": link,
                    "verification_failed": not bool(link), "publish_pending": not bool(link)}
        install_playwright_target_closed_filter()
        outcome = {"success": False, "post_link": ""}
        max_attempts = 3
        try:
            retry_cooldown = max(10, int(os.getenv("FB_UPLOAD_RETRY_COOLDOWN_SECONDS", "60")))
        except (TypeError, ValueError):
            retry_cooldown = 60
        previous_selection_stalled = False
        for attempt in range(1, max_attempts + 1):
            attempt_selection_delay_ms = max(0, int(file_selection_delay_ms or 0))
            if previous_selection_stalled and attempt_selection_delay_ms:
                # A fresh Composer can paint before Meta's large-file worker is
                # ready. Give a selection-stall retry a longer settle on both
                # sides of the chooser instead of repeating identical timing.
                attempt_selection_delay_ms = min(
                    30_000, max(15_000, attempt_selection_delay_ms * 2)
                )
            outcome = await self._upload_reel_stealth_once(
                profile_name, page_id, caption, video_path,
                thumbnail_path=thumbnail_path, page_name_hint=page_name_hint,
                capture_permalink=bool(capture_permalink),
                file_selection_delay_ms=attempt_selection_delay_ms,
                upload_acceptance_timeout_ms=max(0, int(upload_acceptance_timeout_ms or 0)),
                prefer_native_dialog=bool(prefer_native_dialog),
            )
            if outcome.get("success") or not outcome.get("upload_stalled"):
                return outcome
            if attempt >= max_attempts:
                break
            retry_no = attempt
            selection_stalled = bool(outcome.get("selection_stalled"))
            previous_selection_stalled = selection_stalled
            cooldown = 15 if selection_stalled else retry_cooldown
            reason = "video selection did not hydrate" if selection_stalled else "upload percentage stalled"
            print(
                f"🔄 Facebook {reason} — clean Composer restart + "
                f"re-upload {retry_no}/2 after {cooldown}s cooldown"
            )
            note_event(
                "upload_stall_retry",
                "FB Reels video transfer",
                attempt=retry_no,
                progress=outcome.get("stalled_progress"),
            )
            await asyncio.sleep(float(cooldown))
        return outcome

    @staticmethod
    def _reel_publish_receipt_path(video_path, page_id):
        video = Path(video_path)
        if not str(page_id).isdigit():
            raise ValueError("Facebook Page ID must be numeric")
        return video.with_name(f"{video.name}.facebook.{page_id}.publish.json")

    @staticmethod
    def _save_reel_publish_receipt(path, receipt):
        # Write before Share; if Meta accepts the click but the automation dies,
        # the next scheduler turn must verify it instead of posting it again.
        path = Path(path)
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
        for attempt in range(7):
            try:
                temporary.replace(path)
                return
            except OSError as exc:
                if (not isinstance(exc, PermissionError) and getattr(exc, "winerror", None) not in {5, 32}) or attempt == 6:
                    raise
                time.sleep(0.1 * (attempt + 1))

    async def _upload_reel_stealth_once(
        self, profile_name, page_id, caption, video_path,
        thumbnail_path=None, page_name_hint="", capture_permalink=True,
        file_selection_delay_ms=0, upload_acceptance_timeout_ms=0,
        prefer_native_dialog=False,
    ):
        resolved_profile_path = self._page_profile_path(profile_name, page_id)
        resolved_profile_store = resolved_profile_path.parent.name if resolved_profile_path.parent.name in {"browser_sessions", "browser_profiles"} else "browser_sessions"
        async with async_playwright() as p:
            context = await p.chromium.launch_persistent_context(
                str(resolved_profile_path),
                headless=False,
                args=["--disable-blink-features=AutomationControlled", "--disable-notifications"],
                proxy=_fb_proxy_config()
            )
            restored = await restore_snapshot(context, profile_name, profile_store=resolved_profile_store)
            if restored:
                print(f"🔐 Facebook session recovery snapshot restored: {profile_name}")
            page = context.pages[0] if context.pages else await context.new_page()

            # Raw Page routes can contain recommendations, so raw links are never
            # trusted by themselves. They are still valuable as a pre-upload delta
            # when the post-Share candidate also passes stability + caption checks.
            # Publication verification is mandatory even when group sharing is
            # disabled.  ``capture_permalink`` is kept for API compatibility,
            # but Share-click alone is never accepted as a successful Facebook post.
            baseline_raw_reels = None
            baseline_reels = None
            try:
                baseline_raw_reels = set(await self._collect_page_raw_reel_links(
                    context, str(page_id), max_links=30, quick=True,
                ))
                print(f"🧾 Pre-upload raw Page-route Reel baseline: {len(baseline_raw_reels)} link(s)")
            except Exception as baseline_exc:
                baseline_raw_reels = None
                print(f"⚠️ Pre-upload raw Page-route baseline မယူနိုင်ပါ: {baseline_exc}")
            try:
                baseline_reels = set(await self._collect_page_reel_links(
                    context, str(page_id), max_links=30, quick=True,
                    page_name_hint=page_name_hint,
                ))
                print(f"🧾 Pre-upload verified Reel baseline: {len(baseline_reels)} link(s)")
            except Exception as baseline_exc:
                baseline_reels = None
                print(f"⚠️ Pre-upload verified Reel baseline မယူနိုင်ပါ: {baseline_exc}")

            print(f"🔄 Meta Business Suite → Reels Composer (Page ID: {page_id})")
            upload_url = f"https://business.facebook.com/latest/reels_composer?asset_id={page_id}"

            page_loaded = False
            for attempt in range(3):
                try:
                    await page.goto(upload_url, timeout=120000, wait_until="domcontentloaded")
                    page_loaded = True
                    break
                except Exception:
                    print(f"⚠️ Business Suite load retry {attempt + 1}/3")
                    await page.wait_for_timeout(3000)
            if page_loaded:
                page, healthy = await recover_page_ladder(
                    context, page, target_url=upload_url, label="FB Business Suite Reels Composer",
                    # A second tab in the same renderer context has repeatedly looked
                    # healthy while its Playwright pipe was already disconnecting.  It
                    # leaves two visible tabs and then fails at Add video.  Reload the
                    # original tab once; if that cannot hydrate the composer, the clean
                    # context-restart branch below owns the recovery instead.
                    settle_ms=2500, max_reloads=1, max_tab_reopens=0, new_tab_max_reloads=0, navigation_timeout_ms=60000,
                    expected_texts=("Add video",),
                    expected_wait_ms=20000,
                )
            else:
                # V6.0.1: the old early return here skipped the clean-context
                # recovery entirely when all three initial goto attempts raised.
                # Treat navigation exhaustion as an unhealthy context so the same
                # bounded restart path used by a blank/detached Composer can run.
                print(
                    "🧯 FB Business Suite initial navigation exhausted — "
                    "clean browser context restart required"
                )
                note_event(
                    "initial_navigation_exhausted",
                    "FB Business Suite Reels Composer",
                    attempts=3,
                )
                healthy = False

            if healthy and not self._page_is_attached(context, page):
                print("🧯 FB Reels composer Playwright connection detached before upload — clean context restart required")
                note_event("page_detached", "FB Business Suite Reels Composer", stage="pre_upload")
                healthy = False

            if not healthy:
                print("🧯 FB Business Suite Reels Composer: browser CONTEXT restart 1/1")
                note_event("context_restart", "FB Business Suite Reels Composer", attempt=1)
                try:
                    await context.close()
                except Exception:
                    pass
                # Give Chromium enough time to release the persistent-profile lock
                # before relaunching the same dedicated Facebook profile.
                await asyncio.sleep(2.0)
                context = await p.chromium.launch_persistent_context(
                    str(resolved_profile_path),
                    headless=False,
                    args=["--disable-blink-features=AutomationControlled", "--disable-notifications"],
                    proxy=_fb_proxy_config(),
                )
                await restore_snapshot(context, profile_name, profile_store=resolved_profile_store)
                page = context.pages[0] if context.pages else await context.new_page()
                try:
                    await page.goto(upload_url, timeout=120000, wait_until="domcontentloaded")
                except Exception:
                    pass
                page, healthy = await recover_page_ladder(
                    context, page, target_url=upload_url,
                    label="FB Business Suite Reels Composer AFTER CONTEXT RESTART",
                    settle_ms=2000, max_reloads=1, max_tab_reopens=0, new_tab_max_reloads=0, navigation_timeout_ms=60000,
                    expected_texts=("Add video",), expected_wait_ms=20000,
                )
                healthy = bool(healthy and self._page_is_attached(context, page))

            if not healthy:
                print("❌ FB Business Suite Reels Composer: recovery ladder exhausted — FB slot skip")
                note_event("safe_skip", "FB Business Suite Reels Composer recovery exhausted")
                await context.close()
                return {"success": False, "post_link": ""}

            # A dedicated profile can restore harmless older tabs after an unclean
            # browser exit. Do not touch them during stateful upload; the safe cleanup
            # point remains after Share and before the permalink probe.
            stale_count=max(0, len(context.pages)-1)
            if stale_count:
                print(f"🧷 FB Reels session: keeping {stale_count} pre-existing tab(s) parked until post-Share safe cleanup")
            await asyncio.sleep(1.5)

            if not self._page_is_attached(context, page):
                print("❌ FB Reels composer automation connection was lost before Add video; upload safely deferred")
                note_event("page_detached", "FB Business Suite Reels Composer", stage="add_video")
                try:
                    await context.close()
                except Exception:
                    pass
                return {"success": False, "post_link": ""}

            try:
                if "login" in page.url.lower() or await page.locator('input[name="email"]').count() > 0:
                    note_login_lost(profile_name, "facebook")
                    print(f"❌ Facebook profile login ပြုတ်နေပါတယ်: {profile_name}")
                    await context.close()
                    return {"success": False, "post_link": ""}
                try:
                    await save_snapshot(context, profile_name, profile_store=resolved_profile_store)
                except Exception:
                    pass
            except Exception:
                pass

            try:
                if file_selection_delay_ms:
                    print(
                        f"⏳ Episode large-file pacing — Composer settle "
                        f"{file_selection_delay_ms / 1000:.1f}s before Add video..."
                    )
                    await page.wait_for_timeout(file_selection_delay_ms)
                print("🎬 Add video...")
                add_video = page.get_by_text("Add video", exact=False).first
                if prefer_native_dialog:
                    await _select_file_via_native_windows_dialog(
                        page, add_video, video_path,
                    )
                else:
                    async with page.expect_file_chooser(timeout=60000) as fc_info:
                        await add_video.click(timeout=60000)
                    chooser = await fc_info.value
                    if file_selection_delay_ms:
                        print(
                            f"⏳ Episode file chooser pacing — selecting after "
                            f"{file_selection_delay_ms / 1000:.1f}s..."
                        )
                        await page.wait_for_timeout(file_selection_delay_ms)
                    await chooser.set_files(video_path)
                    print("✅ Facebook video selected")
            except Exception as exc:
                print(f"❌ Add video failed: {exc}")
                await context.close()
                return {"success": False, "post_link": ""}

            if upload_acceptance_timeout_ms:
                accepted = await _wait_fb_video_selection_accepted(
                    page, upload_acceptance_timeout_ms,
                )
                if not accepted:
                    print(
                        "❌ Facebook selected file stayed at the unhydrated 0%/black-preview state; "
                        "clean Composer retry required"
                    )
                    await context.close()
                    return {
                        "success": False,
                        "post_link": "",
                        "upload_stalled": True,
                        "selection_stalled": True,
                        "stalled_progress": 0.0,
                    }

            try:
                print("✍️ Facebook caption fill...")
                textbox = page.locator('div[role="textbox"]').first
                await textbox.wait_for(state="visible", timeout=60000)
                await textbox.fill(caption)
            except Exception as exc:
                print(f"⚠️ Facebook caption fill warning: {exc}")

            # Large files can keep Meta's Next button visible but disabled for many minutes.
            # Use an adaptive wait based on file size instead of a fixed 60s + 30s click timeout.
            try:
                size_mb = max(0.0, os.path.getsize(video_path) / (1024 * 1024))
            except Exception:
                size_mb = 0.0

            # Minimum 12 minutes; scale with file size; hard cap 45 minutes.
            process_timeout_s = int(min(45 * 60, max(12 * 60, 180 + size_mb * 12)))
            print(
                f"⏳ Facebook video upload/processing wait — "
                f"file={size_mb:.1f} MB, max_wait≈{process_timeout_s // 60}m{process_timeout_s % 60:02d}s"
            )

            try:
                _fb_processing_started = time.perf_counter()
                next_btn = await _wait_role_button_enabled(
                    page,
                    "Next",
                    process_timeout_s * 1000,
                    label="Next (video processing)",
                )
                note_processing(
                    "FB",
                    "video_upload_processing",
                    time.perf_counter() - _fb_processing_started,
                    account=profile_name,
                    detail=f"file={size_mb:.1f}MB",
                )
                _fb_processing_recorded = True
                thumbnail_selected = False
                if thumbnail_path:
                    try:
                        print("🖼️ Facebook custom Reel thumbnail selection (details step)...")
                        thumbnail_selected = await self._select_reel_thumbnail(page, str(thumbnail_path))
                    except Exception as first_thumbnail_exc:
                        print(f"ℹ️ Thumbnail control not on details step; retrying after Next: {first_thumbnail_exc}")
                await next_btn.click(timeout=30000)
                await page.wait_for_timeout(3000)

                if thumbnail_path and not thumbnail_selected:
                    print("🖼️ Facebook custom Reel thumbnail selection (settings step)...")
                    thumbnail_selected = await self._select_reel_thumbnail(page, str(thumbnail_path))

                # Some Meta layouts have a second Next step. Wait briefly if it exists but is disabled.
                try:
                    next_btn_2 = page.get_by_role("button", name="Next").last
                    if await next_btn_2.count() and await next_btn_2.is_visible():
                        next_btn_2 = await _wait_role_button_enabled(
                            page,
                            "Next",
                            5 * 60 * 1000,
                            label="Next (final settings)",
                        )
                        await next_btn_2.click(timeout=30000)
                        await page.wait_for_timeout(3000)
                except TimeoutError:
                    # If this UI has no required second Next, continue to Share.
                    pass
                except Exception:
                    pass

                print("🚀 Facebook Share ready wait...")
                share_btn = await _wait_role_button_enabled(
                    page,
                    "Share",
                    5 * 60 * 1000,
                    label="Share",
                )
                print("🚀 Facebook Share click...")
                publish_receipt = {
                    "page_id": str(page_id), "status": "share_attempted",
                    "caption_fingerprint": self._caption_fingerprint(caption, 0),
                    "baseline_links": sorted(baseline_reels) if baseline_reels is not None else None,
                    "baseline_raw_links": sorted(baseline_raw_reels) if baseline_raw_reels is not None else None,
                    "post_link": "", "attempted_at": time.time(),
                }
                publish_receipt_path = self._reel_publish_receipt_path(video_path, page_id)
                self._save_reel_publish_receipt(publish_receipt_path, publish_receipt)
                await share_btn.click(timeout=30000)

                print("⏳ Facebook publish confirmation + permalink wait...")
                # The active composer tab is the only tab that should remain before
                # opening the dedicated permalink probe. This prevents an old recovery
                # tab from blocking context.new_page() during strong-mode lookup.
                await self._close_stale_pages(
                    context, page, label="FB pre-permalink cleanup"
                )
                # Do not close the active composer immediately. Meta needs time to publish.
                await page.wait_for_timeout(10000)
                post_link = await self._extract_published_reel_permalink(
                    context,
                    page,
                    str(page_id),
                    timeout_ms=300000,
                    baseline_links=baseline_reels,
                    baseline_raw_links=baseline_raw_reels,
                    page_name_hint=page_name_hint,
                    expected_caption=caption,
                )
                if not post_link:
                    print(
                        "❌ Facebook Share was clicked, but the new Page Reel "
                        "could not be verified; upload is NOT marked successful."
                    )
                    await context.close()
                    return {
                        "success": False,
                        "post_link": "",
                        "verification_failed": True,
                        "error": "new Facebook Reel could not be verified",
                    }
                print("🎉 Facebook Reel publish step completed")
                publish_receipt.update(status="verified", post_link=post_link)
                self._save_reel_publish_receipt(publish_receipt_path, publish_receipt)
                await context.close()
                return {
                    "success": True,
                    "post_link": post_link,
                    "thumbnail_selected": thumbnail_selected,
                }
            except Exception as exc:
                upload_stalled = isinstance(exc, FacebookUploadStalled)
                if '_fb_processing_started' in locals() and not locals().get('_fb_processing_recorded', False):
                    note_processing(
                        "FB",
                        "video_upload_processing",
                        time.perf_counter() - _fb_processing_started,
                        status="failed",
                        account=profile_name,
                        detail=str(exc),
                    )
                print(f"❌ Facebook Next/Share failed: {exc}")
                await context.close()
                stalled_progress = None
                if upload_stalled:
                    match = re.search(r"stuck at (\d+(?:\.\d+)?)%", str(exc))
                    stalled_progress = float(match.group(1)) if match else None
                return {
                    "success": False,
                    "post_link": "",
                    "upload_stalled": upload_stalled,
                    "stalled_progress": stalled_progress,
                }

    # ==========================================
    # ✍️ 🌟 FB TEXT + IMAGE POST FUNCTION (FIXED SELECTORS)
    # ==========================================
    async def upload_post_stealth(self, profile_name, page_id, caption, image_path=None):
        """Meta Business Suite Composer ထဲသို့ စာသားနှင့် ပုံပါဝင်သော ပုံမှန်ပို့စ် (Feed Post) တင်ပေးမည့်စနစ်"""
        resolved_profile_path = self._page_profile_path(profile_name, page_id)
        resolved_profile_store = resolved_profile_path.parent.name if resolved_profile_path.parent.name in {"browser_sessions", "browser_profiles"} else "browser_sessions"
        caption = normalize_platform_caption_hashtags(caption, "facebook", limit=5)
        async with async_playwright() as p:
            context = await p.chromium.launch_persistent_context(
                str(resolved_profile_path),
                headless=False,
                args=["--disable-blink-features=AutomationControlled", "--disable-notifications"],
                proxy=_fb_proxy_config()
            )
            restored = await restore_snapshot(context, profile_name, profile_store=resolved_profile_store)
            if restored:
                print(f"🔐 Facebook session recovery snapshot restored: {profile_name}")
            page = await context.new_page()

            print(f"🔄 Meta Business Suite Post Composer သို့ သွားနေပါသည် (Page ID: {page_id})...")
            upload_url = f"https://business.facebook.com/latest/composer?asset_id={page_id}"
            
            try:
                await page.goto(upload_url, timeout=120000, wait_until="domcontentloaded")
                page, healthy = await recover_page_ladder(
                    context, page, target_url=upload_url, label="FB Business Suite Post Composer",
                    settle_ms=2500, max_reloads=2, max_tab_reopens=1, navigation_timeout_ms=60000,
                    expected_selectors=(
                        'div[contenteditable="true"]',
                        'div[role="textbox"]',
                    ),
                    expected_texts=("Add photo", "Publish"),
                    expected_wait_ms=20000,
                )
                if not healthy:
                    print("🧯 FB Business Suite Post Composer: browser CONTEXT restart 1/1")
                    note_event("context_restart", "FB Business Suite Post Composer", attempt=1)
                    try:
                        await context.close()
                    except Exception:
                        pass
                    context = await p.chromium.launch_persistent_context(
                        str(resolved_profile_path),
                        headless=False,
                        args=["--disable-blink-features=AutomationControlled", "--disable-notifications"],
                        proxy=_fb_proxy_config(),
                    )
                    await restore_snapshot(context, profile_name, profile_store=resolved_profile_store)
                    page = context.pages[0] if context.pages else await context.new_page()
                    try:
                        await page.goto(upload_url, timeout=120000, wait_until="domcontentloaded")
                    except Exception:
                        pass
                    page, healthy = await recover_page_ladder(
                        context, page, target_url=upload_url,
                        label="FB Business Suite Post Composer AFTER CONTEXT RESTART",
                        settle_ms=2000, max_reloads=2, max_tab_reopens=1, navigation_timeout_ms=60000,
                        expected_selectors=('div[contenteditable="true"]','div[role="textbox"]'),
                        expected_texts=("Add photo", "Publish"), expected_wait_ms=20000,
                    )
                if not healthy:
                    note_event("safe_skip", "FB Business Suite Post Composer recovery exhausted")
                    raise RuntimeError("Business Suite Post Composer recovery ladder exhausted")
                print("✅ Business Suite Post Composer စာမျက်နှာ ပွင့်လာပါပြီ။")
                await page.wait_for_timeout(5000)
                
                # 🌟 [CRITICAL FIX] ပုံမှန်ပိုစ့်တင်သည့် UI ၏ TextBox အစစ်အမှန်အား အမျိုးမျိုးသော Selector ဖြင့် ရှာဖွေခြင်း
                print("✍️ Post Caption ဖြည့်စွက်နေပါသည်...")
                input_selector = 'div[contenteditable="true"]'
                try:
                    await page.wait_for_selector(input_selector, timeout=45000)
                    # ၎င်းကောင်ကို အရင် နှိပ်ပြီးမှ စာရိုက်ထည့်ခြင်းပြုလုပ်မည်
                    await page.click(input_selector)
                    await page.fill(input_selector, caption)
                except:
                    # အကယ်၍ အပေါ်ကောင်ရှာမတွေ့ပါက အခြား အရန် Selector တစ်ခုဖြင့် ထပ်ရှာမည်
                    backup_selector = 'div[aria-label*="Share a photo"], div[role="textbox"]'
                    await page.wait_for_selector(backup_selector, timeout=30000)
                    await page.click(backup_selector)
                    await page.fill(backup_selector, caption)
                    
                await page.wait_for_timeout(3000)

                # ၂။ ပုံရှိပါက ပုံတင်ခြင်းလုပ်ငန်းစဉ်
                if image_path and os.path.exists(image_path):
                    print("🖼️ 'Add Photo' ခလုတ်အား ရှာဖွေ၍ ပုံတင်နေပါသည်...")
                    try:
                        # 🌟 [FIXED] File Chooser အား Coroutine ပုံစံမှ ကာကွယ်ရန် await သေချာစွာထည့်သွင်းထားသည်
                        async with page.expect_file_chooser(timeout=45000) as fc_info:
                            # UI ပေါ်ရှိ ပုံတင်ရန် ခလုတ်ကို စာသားဖြင့် ရှာနှိပ်ခြင်း
                            photo_btn = page.get_by_text("Add photo", exact=False).first
                            await photo_btn.click(timeout=45000)
                        
                        file_chooser = await fc_info.value # await ဖြည့်စွက်ပြီးဖြစ်သည်
                        await file_chooser.set_files(image_path)
                        print("✅ ပုံဖိုင် ထည့်သွင်းခြင်း အောင်မြင်ပါသည်။")
                        await page.wait_for_timeout(10000) # ပုံ Upload တက်သည်အထိ စောင့်ပေးခြင်း
                    except Exception as img_err:
                        print(f"⚠️ ပုံတင်ရာတွင် အခက်အခဲရှိခဲ့သော်လည်း စာသားသီးသန့် ဆက်တင်ပါမည်: {img_err}")

                # ၃။ Publish ခလုတ် နှိပ်ခြင်း
                print("🚀 Publish ခလုတ် နှိပ်ပါမည်...")
                # Business Suite အသစ်၏ Publish ခလုတ်ကို အတိအကျဆုံး ဖမ်းယူခြင်း
                publish_btn = page.locator('button:has-text("Publish")').last
                if not await publish_btn.is_visible():
                    publish_btn = page.get_by_role("button", name="Publish").last
                    
                await publish_btn.click(timeout=30000)
                print("⏳ ပို့စ်တင်ခြင်း ပြီးဆုံးသည်အထိ ခဏစောင့်နေပါသည်...")
                await page.wait_for_timeout(15000)
                print("🎉 စာသားပို့စ် တင်ခြင်း အောင်မြင်သွားပါပြီ ကိုကိုရေ!")
                await context.close()
                return True

            except Exception as e:
                print(f"❌ ပို့စ်တင်ရာတွင် Error တက်သွားပါသည်: {e}")
                await context.close()
                return False
