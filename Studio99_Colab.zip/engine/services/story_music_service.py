from __future__ import annotations

import json
import random
from datetime import datetime
from pathlib import Path
from typing import Any


class StoryMusicService:
    AUDIO_EXTENSIONS = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"}

    def __init__(
        self,
        music_root: str | Path = "assets/music",
        registry_path: str | Path = "downloads/story_music_registry.json",
    ) -> None:
        self.music_root = Path(music_root)
        self.registry_path = Path(registry_path)
        self.music_root.mkdir(parents=True, exist_ok=True)
        self.registry_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.registry_path.exists():
            self._save({"version": 1, "pools": {}})

    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.registry_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError
            data.setdefault("version", 1)
            data.setdefault("pools", {})
            return data
        except Exception:
            data = {"version": 1, "pools": {}}
            self._save(data)
            return data

    def _save(self, data: dict[str, Any]) -> None:
        tmp = self.registry_path.with_suffix(self.registry_path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.registry_path)

    def list_tracks(self, pool: str = "drama", mood: str | None = None) -> list[Path]:
        root = self.music_root / pool
        root.mkdir(parents=True, exist_ok=True)
        tracks = sorted(
            p.resolve() for p in root.rglob("*")
            if p.is_file() and p.suffix.lower() in self.AUDIO_EXTENSIONS
        )
        mood = str(mood or "").strip().casefold()
        if mood:
            matched = [
                p for p in tracks
                if mood in p.name.casefold()
                or mood in "/".join(x.casefold() for x in p.relative_to(root.resolve()).parts[:-1])
            ]
            if matched:
                return matched
        return tracks

    def _relative_key(self, path: Path) -> str:
        try:
            return path.resolve().relative_to(self.music_root.resolve()).as_posix()
        except Exception:
            return path.resolve().as_posix()

    def select_track(self, pool: str = "drama", *, mood: str | None = None, mark_used: bool = True) -> Path:
        tracks = self.list_tracks(pool, mood=mood)
        if not tracks:
            raise FileNotFoundError(
                f"Music pool is empty: {self.music_root / pool}. "
                "Download royalty-free tracks into this folder first."
            )

        data = self._load()
        pools = data.setdefault("pools", {})
        state_key = f"{pool}:{str(mood).strip().casefold()}" if mood else pool
        state = pools.setdefault(state_key, {
            "cycle": 1,
            "used_current_cycle": [],
            "last_track": "",
            "history": [],
        })

        all_keys = {self._relative_key(p): p for p in tracks}
        used = [x for x in state.get("used_current_cycle", []) if x in all_keys]
        unused_keys = [k for k in all_keys if k not in set(used)]

        if not unused_keys:
            state["cycle"] = int(state.get("cycle", 1)) + 1
            state["used_current_cycle"] = []
            used = []
            unused_keys = list(all_keys)

        last_track = str(state.get("last_track") or "")
        if len(unused_keys) > 1 and last_track in unused_keys:
            unused_keys = [k for k in unused_keys if k != last_track]

        chosen_key = random.SystemRandom().choice(unused_keys)
        chosen = all_keys[chosen_key]

        if mark_used:
            current = list(state.get("used_current_cycle", []))
            if chosen_key not in current:
                current.append(chosen_key)
            state["used_current_cycle"] = current
            state["last_track"] = chosen_key
            history = list(state.get("history", []))
            history.append({
                "track": chosen_key,
                "cycle": int(state.get("cycle", 1)),
                "used_at": datetime.now().isoformat(timespec="seconds"),
            })
            state["history"] = history[-1000:]
            pools[state_key] = state
            self._save(data)

        remaining = max(0, len(tracks) - len(state.get("used_current_cycle", [])))
        print(
            f"🎵 Music selected [{state_key}] → {chosen.name} | "
            f"cycle={state.get('cycle', 1)} | remaining_before_repeat={remaining}"
        )
        return chosen

    def status(self, pool: str = "drama", mood: str | None = None) -> dict[str, Any]:
        tracks = self.list_tracks(pool, mood=mood)
        data = self._load()
        state_key = f"{pool}:{str(mood).strip().casefold()}" if mood else pool
        state = data.get("pools", {}).get(state_key, {})
        used = [x for x in state.get("used_current_cycle", [])]
        return {
            "pool": state_key,
            "folder": str((self.music_root / pool).resolve()),
            "tracks": len(tracks),
            "cycle": int(state.get("cycle", 1) or 1),
            "used_current_cycle": len(used),
            "remaining_before_repeat": max(0, len(tracks) - len(used)),
            "last_track": str(state.get("last_track") or ""),
        }
