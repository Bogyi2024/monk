from __future__ import annotations

import re


_HASHTAG_RE = re.compile(r"(?<![\w#])#[^\s#]+", re.UNICODE)
_TRAILING_TAG_PUNCTUATION = ".,!?;:)]}>'\"၊။…"


def normalize_platform_caption_hashtags(
    caption: str,
    platform: str,
    *,
    limit: int = 5,
) -> str:
    """Keep at most five unique tags and inject the platform's required tag."""
    text = (caption or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    platform_key = str(platform or "").strip().lower()
    required = (
        "#viralreel"
        if platform_key in {"fb", "facebook", "meta"}
        else "#fyp"
        if platform_key in {"tt", "tiktok"}
        else ""
    )
    cap = max(1, min(5, int(limit or 5)))

    tags: list[str] = []
    seen: set[str] = set()
    if required:
        tags.append(required)
        seen.add(required.casefold())
    for match in _HASHTAG_RE.finditer(text):
        tag = match.group(0).rstrip(_TRAILING_TAG_PUNCTUATION)
        if len(tag) <= 1:
            continue
        key = tag.casefold()
        if key in seen:
            continue
        seen.add(key)
        tags.append(tag)
        if len(tags) >= cap:
            break

    body = _HASHTAG_RE.sub("", text)
    body = "\n".join(re.sub(r"[ \t]{2,}", " ", line).rstrip() for line in body.splitlines())
    body = re.sub(r"\n\s*\n(?:\s*\n)+", "\n\n", body).strip()
    tag_line = " ".join(tags[:cap])
    if body and tag_line:
        return f"{body}\n\n{tag_line}"
    return body or tag_line
