V5.9 Facebook Group Auto-Share

Replace:
  services/browser_service.py      <- browser_service_v5_9_permalink.py
  services/fb_group_service.py     <- fb_group_service_v5_9_auto_share.py
  recap_auto_scheduler.py          <- recap_auto_scheduler_v5_9_group_share.py
  config/recap_pages.json          <- recap_pages_v5_9_group_share.json

Before running:
1) Edit services/fb_group_service.py and replace placeholder group_link_* URLs with real Facebook group URLs.
2) Existing persistent profiles are expected under:
   browser_profiles/FB_Share_Acc_1 ... FB_Share_Acc_5
3) V2Ray proxy defaults to http://127.0.0.1:10808 via FB_PROXY.
4) Group sharing is configured headless=false.

Flow:
Facebook Page Reel publish
 -> wait/find actual /reel/... permalink
 -> mark Page destination posted FIRST
 -> auto share permalink to configured groups
 -> save each successful account+group in downloads/fb_group_share_registry.json
 -> interrupted/failed group shares retry on a later scheduler cycle
 -> already successful groups are skipped (no duplicate group posts)

Telegram share_bot.py is not required for this flow.
