from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional, Sequence

import yt_dlp
from yt_dlp.networking.impersonate import ImpersonateTarget

from services.source_download_auth_service import cookiefile_ydl_option


class _BufferedYTDLPLogger:
    """Keep transient TikTok extractor retries out of the operator log."""

    def __init__(self) -> None:
        self.errors: list[str] = []

    def debug(self, _message: str) -> None:
        return

    def warning(self, _message: str) -> None:
        return

    def error(self, message: str) -> None:
        self.errors.append(str(message or "").strip())


class RecapSourceService:
    """YouTube/TikTok source scan, candidate selection and destination history."""

    def __init__(
        self,
        registry_path: str = "downloads/recap_source_registry.json",
        playlist_limit: int = 30,
        proxy: Optional[str] = None,
    ) -> None:
        self.registry_path = Path(registry_path)
        self.registry_path.parent.mkdir(parents=True, exist_ok=True)
        self.playlist_limit = max(5, int(playlist_limit))
        self.proxy = proxy or os.getenv("DOWNLOAD_PROXY") or os.getenv("HTTPS_PROXY")
        self.registry = self._load_registry()

    @staticmethod
    def _now_iso() -> str:
        return datetime.now(timezone.utc).isoformat()

    def _load_registry(self) -> dict[str, Any]:
        if self.registry_path.exists():
            try:
                with self.registry_path.open("r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    data.setdefault("version", 2)
                    data.setdefault("channels", {})
                    data.setdefault("videos", {})
                    data.setdefault("posted_by_page", {})
                    data.setdefault("reservations", {})
                    return data
            except Exception as exc:
                print(f"⚠️ Registry ဖတ်မရပါ၊ အသစ်စမည်: {exc}")
        return {
            "version": 2,
            "channels": {},
            "videos": {},
            "posted_by_page": {},
            "reservations": {},
        }

    def _save_registry(self) -> None:
        """Persist the shared Recap registry despite brief Windows file locks.

        ``os.replace`` is atomic, but Windows can return WinError 5/32 for a few
        milliseconds when Defender/indexing or another in-process registry reader
        happens to have the destination open.  A source scan must not become a
        category failure merely because that replace raced with a transient lock.
        Keep the already-written temp file and retry the same atomic replace with a
        bounded backoff; all other errors still fail immediately.
        """
        self.registry_path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(
            prefix=self.registry_path.stem + "_",
            suffix=".tmp",
            dir=str(self.registry_path.parent),
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(self.registry, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())

            retry_delays = (0.05, 0.10, 0.20, 0.35, 0.50, 0.75, 1.00)
            for attempt in range(len(retry_delays) + 1):
                try:
                    os.replace(temp_name, self.registry_path)
                    if attempt:
                        print(
                            f"✅ Recap source registry Windows lock recovered "
                            f"after {attempt} retry attempt(s)."
                        )
                    return
                except OSError as exc:
                    # Windows sharing/access races are transient. Do not hide
                    # missing directories, invalid paths, disk errors, etc.
                    if getattr(exc, "winerror", None) not in {5, 32} or attempt >= len(retry_delays):
                        raise
                    delay = retry_delays[attempt]
                    print(
                        f"⚠️ Recap source registry temporarily locked "
                        f"(WinError {exc.winerror}); retry {attempt + 1}/{len(retry_delays)} "
                        f"in {delay:.2f}s..."
                    )
                    time.sleep(delay)
        finally:
            if os.path.exists(temp_name):
                os.remove(temp_name)

    @staticmethod
    def load_channel_urls(source_file: str) -> list[str]:
        path = Path(source_file)
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("# YouTube/TikTok channel, profile, or video URL တစ်ကြောင်းစီထည့်ပါ\n", encoding="utf-8")
            return []
        urls = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                urls.append(line)
        return list(dict.fromkeys(urls))

    @staticmethod
    def _channel_key(url: str, info: dict[str, Any]) -> str:
        value = info.get("channel_id") or info.get("uploader_id") or info.get("id")
        if value:
            return str(value)
        return hashlib.sha1(url.encode("utf-8")).hexdigest()[:16]

    @staticmethod
    def _platform(url: str) -> str:
        low = str(url or "").lower()
        if "tiktok.com" in low or "vt.tiktok.com" in low:
            return "tiktok"
        if "youtube.com" in low or "youtu.be" in low:
            return "youtube"
        return "other"

    @classmethod
    def _scan_url(cls, url: str) -> str:
        clean = str(url or "").strip().rstrip("/")
        if cls._platform(clean) != "youtube":
            return clean
        # Direct YouTube video/Short URLs must stay direct; only channel roots get /shorts.
        low = clean.lower()
        if any(x in low for x in ("/shorts/", "watch?", "youtu.be/", "/videos", "/shorts", "playlist?")):
            return clean
        return clean + "/shorts"

    @classmethod
    def _is_direct_video_url(cls, url: str) -> bool:
        low = str(url or "").lower()
        if cls._platform(url) == "youtube":
            return "/shorts/" in low or "watch?" in low or "youtu.be/" in low
        if cls._platform(url) == "tiktok":
            return "/video/" in low or "vt.tiktok.com/" in low or "vm.tiktok.com/" in low
        return False

    @staticmethod
    def _clean_title(value: Any, video_id: str = "") -> str:
        """Return a real source title, never a video-id placeholder."""
        title = str(value or "").strip()
        if not title:
            return ""
        if video_id and title == str(video_id).strip():
            return ""
        lowered = title.casefold()
        if lowered in {"none", "null", "n/a", "na", "youtube video", "video"}:
            return ""
        return title

    def ensure_candidate_metadata(self, candidate: dict[str, Any]) -> dict[str, Any]:
        """
        Make sure the selected source item has a real title before Gemini runs.

        Channel/profile scans use yt-dlp flat-playlist mode for speed. Usually that already
        includes the title.  If it does not, fetch metadata for ONLY the selected
        candidate (no media download) and update the registry.
        """
        enriched = dict(candidate)
        video_id = str(enriched.get("video_id") or "").strip()
        current_title = self._clean_title(enriched.get("title"), video_id)
        enriched["title"] = current_title
        enriched["source_title_status"] = "channel_scan" if current_title else "missing"

        if current_title:
            return enriched

        url = str(enriched.get("url") or "").strip()
        if not url:
            return enriched

        opts: dict[str, Any] = {
            "quiet": True,
            "no_warnings": True,
            "skip_download": True,
            "noplaylist": True,
        }
        if self.proxy:
            opts["proxy"] = self.proxy
        opts.update(cookiefile_ydl_option())

        try:
            print(f"🏷️ Source title missing in flat scan; refreshing metadata: {video_id or url}")
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False) or {}
            refreshed_title = self._clean_title(info.get("title"), video_id)
            if refreshed_title:
                enriched["title"] = refreshed_title
                enriched["source_title_status"] = "metadata_refresh"
                if info.get("channel") or info.get("uploader"):
                    enriched["channel_name"] = str(info.get("channel") or info.get("uploader"))
                if video_id and video_id in self.registry.get("videos", {}):
                    record = self.registry["videos"][video_id]
                    record["title"] = refreshed_title
                    record["source_title_status"] = "metadata_refresh"
                    if enriched.get("channel_name"):
                        record["channel_name"] = enriched["channel_name"]
                    self._save_registry()
                print(f"✅ Refreshed source title: {refreshed_title}")
            else:
                print("⚠️ Source metadata refresh still returned no usable title; Gemini will title from transcript.")
        except Exception as exc:
            print(f"⚠️ Source title metadata refresh failed: {exc}. Gemini will title from transcript.")

        return enriched

    def _extract_channel(
        self,
        channel_url: str,
        *,
        playlist_limit: Optional[int] = None,
    ) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        """Extract a YouTube channel/Short/video or TikTok profile/video source.

        Registry field names remain backward compatible (channel_id/channel_name/video_id)
        even when the source platform is TikTok.
        """
        target_url = self._scan_url(channel_url)
        platform = self._platform(channel_url)
        opts: dict[str, Any] = {
            "quiet": True,
            "no_warnings": True,
            "ignoreerrors": True,
            "extract_flat": "in_playlist",
            "lazy_playlist": False,
            "skip_download": True,
        }
        effective_limit = self.playlist_limit if playlist_limit is None else int(playlist_limit)
        # Zero is the explicit exhaustion scan: enumerate the complete channel.
        if effective_limit > 0:
            opts["playlistend"] = effective_limit
        opts.update(cookiefile_ydl_option())
        if self.proxy:
            opts["proxy"] = self.proxy

        if platform == "tiktok" and not self._is_direct_video_url(channel_url):
            # TikTok now frequently returns an incomplete profile shell to a
            # generic HTTP client. yt-dlp can see the item IDs but then fails to
            # resolve secUid. curl-cffi-backed browser impersonation restores the
            # same profile response a real browser receives.
            cached_id = ""
            normalized_source = str(channel_url).strip().rstrip("/")
            for channel in (self.registry.get("channels") or {}).values():
                if not isinstance(channel, dict):
                    continue
                if str(channel.get("source_url") or "").strip().rstrip("/") != normalized_source:
                    continue
                value = str(channel.get("channel_id") or "").strip()
                if value.startswith("MS4"):
                    cached_id = value
                    break

            scan_targets = ([f"tiktokuser:{cached_id}"] if cached_id else []) + [target_url]
            preferred = str(os.getenv("TIKTOK_IMPERSONATE_TARGET") or "chrome-131:macos-14").lower()
            browser_targets = list(dict.fromkeys([
                preferred,
                "chrome-136:macos-15",
                "edge-101:windows-10",
                "safari-18.4:ios-18.4",
            ]))
            info: dict[str, Any] = {}
            errors: list[str] = []
            for scan_target in scan_targets:
                for browser_target in browser_targets:
                    logger = _BufferedYTDLPLogger()
                    attempt_opts = dict(opts)
                    attempt_opts["logger"] = logger
                    attempt_opts["impersonate"] = ImpersonateTarget.from_str(browser_target)
                    try:
                        with yt_dlp.YoutubeDL(attempt_opts) as ydl:
                            candidate_info = ydl.extract_info(scan_target, download=False) or {}
                        if candidate_info.get("entries") or candidate_info.get("id"):
                            info = candidate_info
                            break
                    except Exception as exc:
                        errors.append(str(exc).strip())
                    errors.extend(x for x in logger.errors if x)
                if info:
                    break
            if not info:
                detail = next((x for x in reversed(errors) if x), "TikTok returned no profile videos")
                raise RuntimeError(detail)
        else:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(target_url, download=False) or {}

        raw_entries = list(info.get("entries") or [])
        if not raw_entries and info.get("id"):
            # Direct video URLs return a single info dict instead of playlist entries.
            raw_entries = [info]

        entries: list[dict[str, Any]] = []
        for rank, entry in enumerate(raw_entries):
            if not entry:
                continue
            video_id = str(entry.get("id") or "").strip()
            if not video_id:
                continue
            webpage_url = entry.get("webpage_url") or entry.get("original_url") or entry.get("url")
            if platform == "tiktok" and not self._is_direct_video_url(channel_url):
                # A tiktokuser:<secUid> scan reports the secUid as its display id,
                # which makes yt-dlp construct an ugly @MS4... URL.  Keep the
                # canonical public username from the configured profile instead;
                # retain the secUid separately as channel_id for the API download
                # fallback.
                match = re.search(r"tiktok\.com/@([^/?#]+)", str(channel_url), re.IGNORECASE)
                if match:
                    webpage_url = (
                        f"https://www.tiktok.com/@{match.group(1)}/video/{video_id}"
                        "?is_from_webapp=1&sender_device=pc"
                    )
            if not webpage_url or not str(webpage_url).startswith("http"):
                if platform == "youtube":
                    webpage_url = f"https://www.youtube.com/watch?v={video_id}"
                elif platform == "tiktok":
                    uploader_id = str(entry.get("uploader_id") or info.get("uploader_id") or "").strip().lstrip("@")
                    webpage_url = (
                        f"https://www.tiktok.com/@{uploader_id}/video/{video_id}"
                        if uploader_id
                        else str(channel_url)
                    )
                else:
                    webpage_url = str(channel_url)
            timestamp = entry.get("timestamp") or entry.get("release_timestamp") or 0
            try:
                timestamp = float(timestamp or 0)
            except (TypeError, ValueError):
                timestamp = 0.0
            entries.append({
                "video_id": video_id,
                "title": str(entry.get("title") or entry.get("description") or "").strip(),
                "url": str(webpage_url),
                "upload_date": str(entry.get("upload_date") or ""),
                "timestamp": timestamp,
                "rank": rank,
                "source_platform": platform,
            })
        return info, entries

    def release_stale_reservations(self, max_age_hours: int = 6) -> None:
        cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
        reservations = self.registry.get("reservations", {})
        stale: list[str] = []
        for key, item in reservations.items():
            try:
                reserved_at = datetime.fromisoformat(item.get("reserved_at", ""))
                if reserved_at.tzinfo is None:
                    reserved_at = reserved_at.replace(tzinfo=timezone.utc)
                if reserved_at < cutoff:
                    stale.append(key)
            except Exception:
                stale.append(key)
        for key in stale:
            reservations.pop(key, None)
        if stale:
            self._save_registry()

    def scan_channels(
        self,
        channel_urls: Sequence[str],
        *,
        playlist_limit: Optional[int] = None,
    ) -> dict[str, Any]:
        self.release_stale_reservations()
        discovered_now: list[str] = []
        inventory: list[dict[str, Any]] = []
        scan_time = self._now_iso()

        for channel_url in channel_urls:
            try:
                print(f"🔍 Source scan [{self._platform(channel_url)}]: {channel_url}")
                info, entries = self._extract_channel(
                    channel_url,
                    playlist_limit=playlist_limit,
                )
            except Exception as exc:
                print(f"❌ Channel scan error: {channel_url} → {exc}")
                continue

            channel_key = self._channel_key(channel_url, info)
            channel_name = str(
                info.get("channel")
                or info.get("uploader")
                or info.get("title")
                or channel_key
            )
            self.registry["channels"][channel_key] = {
                "channel_id": channel_key,
                "channel_name": channel_name,
                "source_url": channel_url,
                "scan_url": self._scan_url(channel_url),
                "source_platform": self._platform(channel_url),
                "last_scanned_at": scan_time,
            }
            if playlist_limit is not None and int(playlist_limit) <= 0:
                self.registry["channels"][channel_key]["deep_scan_completed_at"] = scan_time
                self.registry["channels"][channel_key]["deep_scan_entry_count"] = len(entries)

            for entry in entries:
                video_id = entry["video_id"]
                is_new = video_id not in self.registry["videos"]
                if is_new:
                    discovered_now.append(video_id)
                record = self.registry["videos"].setdefault(video_id, {})
                record.update({
                    **entry,
                    "channel_id": channel_key,
                    "channel_name": channel_name,
                    "channel_url": channel_url,
                    "last_seen_at": scan_time,
                })
                record.setdefault("first_seen_at", scan_time)
                # Keep old field name for compatibility. It now stores FB/TikTok destination keys.
                record.setdefault("posted_pages", {})
                record.setdefault("failures", {})
                record["is_new_this_scan"] = is_new
                inventory.append(dict(record))

        self.registry["last_scan_at"] = scan_time
        self._save_registry()
        inventory.sort(
            key=lambda item: (
                float(item.get("timestamp") or 0),
                -int(item.get("rank") or 0),
                item.get("first_seen_at", ""),
            ),
            reverse=True,
        )
        return {
            "inventory": inventory,
            "new_video_ids": discovered_now,
            "scanned_at": scan_time,
        }

    def inventory_for_sources(
        self,
        channel_urls: Sequence[str],
        current_inventory: Sequence[dict[str, Any]] = (),
    ) -> list[dict[str, Any]]:
        """Return current scan rows plus all previously discovered rows for these sources.

        A shallow freshness scan must not hide older unposted items that were
        discovered by an earlier deep scan.
        """
        allowed = {str(url or "").strip().rstrip("/") for url in channel_urls if str(url or "").strip()}
        by_id: dict[str, dict[str, Any]] = {}
        for video_id, record in (self.registry.get("videos") or {}).items():
            if not isinstance(record, dict):
                continue
            source_url = str(record.get("channel_url") or "").strip().rstrip("/")
            if source_url not in allowed:
                continue
            item = dict(record)
            item.setdefault("video_id", str(video_id))
            item["is_new_this_scan"] = False
            by_id[str(video_id)] = item
        for record in current_inventory or ():
            video_id = str((record or {}).get("video_id") or "").strip()
            if video_id:
                by_id[video_id] = dict(record)
        inventory = list(by_id.values())
        inventory.sort(
            key=lambda item: (
                float(item.get("timestamp") or 0),
                -int(item.get("rank") or 0),
                item.get("first_seen_at", ""),
            ),
            reverse=True,
        )
        return inventory

    def deep_scan_due(self, channel_urls: Sequence[str], max_age_hours: float = 24.0) -> bool:
        """True when at least one configured source has not had a recent full scan."""
        urls = {str(url or "").strip().rstrip("/") for url in channel_urls if str(url or "").strip()}
        seen: dict[str, str] = {}
        for row in (self.registry.get("channels") or {}).values():
            if not isinstance(row, dict):
                continue
            source_url = str(row.get("source_url") or "").strip().rstrip("/")
            if source_url in urls:
                seen[source_url] = str(row.get("deep_scan_completed_at") or "")
        cutoff = datetime.now(timezone.utc) - timedelta(hours=max(1.0, float(max_age_hours)))
        for url in urls:
            raw = seen.get(url, "")
            try:
                completed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
                if completed.tzinfo is None:
                    completed = completed.replace(tzinfo=timezone.utc)
                if completed < cutoff:
                    return True
            except Exception:
                return True
        return False

    def _globally_posted_video_ids(self) -> set[str]:
        """Return every source video id that has ANY successful Recap post evidence.

        Route V2 changed destination keys (for example old Recap_Entertainment_FB
        became recap_default_FB).  Destination-key-only de-duplication therefore
        made old successful sources look unposted again.  Source consumption is a
        Recap-wide property: once a source video has been successfully posted by
        any Recap route/page, another route must never create a new post from it.

        Same-route partial delivery is handled separately by choose_candidate():
        if FB already succeeded for this exact stream and TikTok is still pending,
        that one job may resume TikTok without creating a new content job.
        """
        out: set[str] = set()
        for vid, record in (self.registry.get("videos") or {}).items():
            if isinstance(record, dict) and (record.get("posted_pages") or record.get("source_consumed_at")):
                key = str(vid or "").strip()
                if key:
                    out.add(key)
        for _dest, rows in (self.registry.get("posted_by_page") or {}).items():
            for row in rows or []:
                if not isinstance(row, dict):
                    continue
                vid = str(row.get("video_id") or "").strip()
                if vid:
                    out.add(vid)
        return out

    @staticmethod
    def _posted_by_same_stream(record: dict[str, Any], page_key: str) -> bool:
        for _dest, meta in (record.get("posted_pages") or {}).items():
            if not isinstance(meta, dict):
                continue
            if str(meta.get("stream_key") or "").strip() == str(page_key).strip():
                return True
        return False

    @staticmethod
    def _destination_contract(
        record: dict[str, Any],
        page_key: str,
        current_destinations: Sequence[str],
        *,
        infer_legacy: bool = True,
    ) -> tuple[list[str], bool]:
        """Return the destinations promised when this source job was created.

        Destination configuration is mutable, but an already-consumed source is
        not.  Without a per-job contract, enabling TikTok today makes every old
        Facebook-only job look partial and silently backfills it.  Existing rows
        predate this field, so their successful/attempted destinations are frozen
        once as the legacy contract.  Brand-new jobs use the currently enabled
        destinations and persist them in :meth:`reserve` before rendering starts.
        """
        current = list(dict.fromkeys(
            str(key).strip() for key in current_destinations if str(key).strip()
        ))
        contracts = record.get("required_destinations_by_stream")
        if isinstance(contracts, dict):
            stored = contracts.get(page_key)
            if isinstance(stored, list):
                normalized = list(dict.fromkeys(
                    str(key).strip() for key in stored if str(key).strip()
                ))
                if normalized:
                    return normalized, False

        if not infer_legacy:
            return current, False

        observed: list[str] = []
        for field in ("posted_pages", "failures"):
            for key, meta in (record.get(field) or {}).items():
                if not isinstance(meta, dict):
                    continue
                if str(meta.get("stream_key") or "").strip() != str(page_key).strip():
                    continue
                normalized_key = str(key or "").strip()
                if normalized_key and normalized_key not in observed:
                    observed.append(normalized_key)

        # Only a successful old post proves that this is an already-created job.
        # Failed-only sources remain governed by today's complete destination set.
        has_success = any(
            isinstance(meta, dict)
            and str(meta.get("stream_key") or "").strip() == str(page_key).strip()
            for meta in (record.get("posted_pages") or {}).values()
        )
        if not has_success or not observed:
            return current, False

        contracts = record.setdefault("required_destinations_by_stream", {})
        contracts[page_key] = observed
        record.setdefault("destination_contract_migrated_at", RecapSourceService._now_iso())
        return observed, True

    def migrate_legacy_destination_contracts(
        self,
        page_key: str,
        destination_keys: Sequence[str],
    ) -> int:
        """Freeze old successful jobs before a scheduler takes its delta snapshot."""
        migrated = 0
        for record in (self.registry.get("videos") or {}).values():
            if not isinstance(record, dict):
                continue
            _contract, changed = self._destination_contract(
                record, page_key, destination_keys
            )
            if changed:
                migrated += 1
        if migrated:
            self._save_registry()
            print(
                f"🧷 [{page_key}] Frozen original destination contract for "
                f"{migrated} historical job(s)."
            )
        return migrated

    def choose_candidate(
        self,
        page_key: str,
        inventory: Sequence[dict[str, Any]],
        new_video_ids: Sequence[str],
        max_failures: int = 3,
        destination_keys: Optional[Sequence[str]] = None,
        retry_max_age_hours: float = 24.0,
        source_platform_order: Optional[Sequence[str]] = None,
        allowed_source_platforms: Optional[Sequence[str]] = None,
    ) -> Optional[dict[str, Any]]:
        """
        Select one source video for a content stream.

        Priority:
        1. A source already posted to one destination but still missing another.
        2. A newly discovered source not posted to all destinations.
        3. An older unposted source.
        """
        destinations = [str(x) for x in (destination_keys or [page_key]) if str(x).strip()]
        if not destinations:
            destinations = [page_key]

        new_set = set(new_video_ids)
        reservations = self.registry.get("reservations", {})
        globally_posted = self._globally_posted_video_ids()
        eligible: list[dict[str, Any]] = []
        contract_changed = False
        platform_order = [str(x).strip().lower() for x in (source_platform_order or ()) if str(x).strip()]
        platform_score = {name: len(platform_order) - index for index, name in enumerate(platform_order)}
        allowed_platforms = {
            str(x).strip().lower() for x in (allowed_source_platforms or ()) if str(x).strip()
        }

        def recent_retryable_failure(failure: dict[str, Any]) -> bool:
            count = int((failure or {}).get("count") or 0)
            if count <= 0 or count >= max_failures:
                return False
            if str((failure or {}).get("stream_key") or "") != page_key:
                return False
            if retry_max_age_hours <= 0:
                return True
            try:
                failed_at = datetime.fromisoformat(str((failure or {}).get("last_failed_at") or "").replace("Z", "+00:00"))
                if failed_at.tzinfo is None:
                    failed_at = failed_at.replace(tzinfo=timezone.utc)
                return datetime.now(timezone.utc) - failed_at.astimezone(timezone.utc) <= timedelta(hours=retry_max_age_hours)
            except Exception:
                return False

        # If this route has a recent failed destination, this turn is a strict
        # recovery turn. Never fall through to a different source just because
        # the failed source is temporarily held/missing from the current scan.
        strict_retry_ids: set[str] = set()
        for vid, record in (self.registry.get("videos") or {}).items():
            if not isinstance(record, dict):
                continue
            record_destinations, migrated = self._destination_contract(
                record, page_key, destinations
            )
            contract_changed = contract_changed or migrated
            posted = record.get("posted_pages") or {}
            for key in record_destinations:
                if key not in posted and recent_retryable_failure((record.get("failures") or {}).get(key) or {}):
                    strict_retry_ids.add(str(vid))
                    break

        for item in inventory:
            video_id = str(item.get("video_id") or "").strip()
            if not video_id:
                continue
            if strict_retry_ids and video_id not in strict_retry_ids:
                continue
            record = self.registry["videos"].get(video_id, {})
            source_platform = str(
                record.get("source_platform")
                or self._platform(record.get("url") or record.get("channel_url") or "")
            ).strip().lower()
            if allowed_platforms and source_platform not in allowed_platforms and video_id not in strict_retry_ids:
                continue
            if bool(record.get("source_unsuitable")):
                reason = str(record.get("source_unsuitable_reason") or "")
                # Older builds accepted a video-only TikTok file as a successful
                # download, then permanently quarantined the source in Whisper.
                # The downloader now retries an audio-bearing format, so release
                # only that exact historical false quarantine.
                if source_platform == "tiktok" and "ffprobe found no audio stream" in reason:
                    record.pop("source_unsuitable", None)
                    record.pop("source_unsuitable_at", None)
                    record.pop("source_unsuitable_reason", None)
                    record.pop("source_unsuitable_by_stream", None)
                    contract_changed = True
                else:
                    continue
            # Source transport/auth failures are temporary and must not consume FB/TikTok
            # destination retries. Hold only this source for its short download cooldown.
            dl_fail = record.get("source_download_failure") or {}
            retry_after = str(dl_fail.get("retry_after") or "").strip() if isinstance(dl_fail, dict) else ""
            if retry_after:
                try:
                    dt = datetime.fromisoformat(retry_after.replace("Z", "+00:00"))
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    if dt > datetime.now(timezone.utc):
                        continue
                except Exception:
                    pass
            posted = record.get("posted_pages", {})
            record_destinations, migrated = self._destination_contract(
                record, page_key, destinations
            )
            contract_changed = contract_changed or migrated
            pending = [key for key in record_destinations if key not in posted]
            if not pending:
                continue

            # GLOBAL SOURCE DEDUPE:
            # A Recap source is consumed after its first successful post anywhere.
            # Only the SAME route/stream may resume missing destinations from that
            # already-created job (e.g. FB succeeded, TikTok still pending).
            if video_id in globally_posted and not self._posted_by_same_stream(record, page_key):
                continue

            # Treat reservations as source-wide, not route-wide.  This prevents two
            # routes from selecting the same source before the first route finishes.
            reserved_elsewhere = False
            for reservation in reservations.values():
                if not isinstance(reservation, dict):
                    continue
                if str(reservation.get("video_id") or "").strip() != video_id:
                    continue
                same_stream = str(reservation.get("page_key") or "").strip() == page_key
                guard_type = str(reservation.get("guard_type") or "").strip()
                # A failed job's own stale reservation must not block the strict
                # retry that exists specifically to resume that same source.
                if same_stream and video_id in strict_retry_ids and not guard_type:
                    continue
                reserved_elsewhere = True
                break
            if reserved_elsewhere:
                continue

            retryable: list[str] = []
            for destination_key in pending:
                failures = record.get("failures", {}).get(destination_key, {})
                failure_count = int(failures.get("count", 0))
                if failure_count >= max_failures:
                    continue
                # Enabling retries must not resurrect months-old failed uploads.
                # A fresh failure can resume across a restart/overnight boundary,
                # but stale legacy failures remain held for manual review.
                if failure_count > 0 and retry_max_age_hours > 0:
                    try:
                        failed_at = datetime.fromisoformat(str(failures.get("last_failed_at") or "").replace("Z", "+00:00"))
                        if failed_at.tzinfo is None:
                            failed_at = failed_at.replace(tzinfo=timezone.utc)
                        if datetime.now(timezone.utc) - failed_at.astimezone(timezone.utc) > timedelta(hours=retry_max_age_hours):
                            continue
                    except Exception:
                        continue
                retryable.append(destination_key)
            if not retryable:
                continue

            posted_count = len(record_destinations) - len(pending)
            same_stream_partial = video_id in globally_posted and self._posted_by_same_stream(record, page_key)
            if same_stream_partial or posted_count > 0:
                reason = "resume_partial"
                priority = 3
            elif any(
                int((record.get("failures", {}).get(key) or {}).get("count") or 0) > 0
                and str((record.get("failures", {}).get(key) or {}).get("stream_key") or "") == page_key
                for key in retryable
            ):
                # Both primaries can fail in the first attempt.  Prefer the same
                # already-rendered source on the next Master turn instead of
                # creating a different content job. prepare_rendered_video() then
                # reuses final.mp4 + smart_sync_plan.json losslessly.
                reason = "resume_failed"
                priority = 2
            elif video_id in new_set:
                reason = "new_upload"
                priority = 1
            else:
                reason = "old_unposted"
                priority = 0

            candidate = dict(record)
            candidate["selection_reason"] = reason
            candidate["pending_destinations"] = retryable
            candidate["all_destinations"] = record_destinations
            candidate["selection_priority"] = priority
            candidate["resume_failed_at"] = max(
                [
                    str((record.get("failures", {}).get(key) or {}).get("last_failed_at") or "")
                    for key in retryable
                ]
                or [""]
            )
            candidate["source_platform"] = source_platform
            eligible.append(candidate)

        if contract_changed:
            self._save_registry()

        if not eligible:
            return None

        def selection_key(item: dict[str, Any]):
            priority = int(item.get("selection_priority", 0))
            recovery = priority >= 2
            platform = str(item.get("source_platform") or "other").lower()
            return (
                1 if recovery else 0,
                priority if recovery else 0,
                platform_score.get(platform, 0),
                priority,
                str(item.get("resume_failed_at") or ""),
                float(item.get("timestamp") or 0),
                -int(item.get("rank") or 0),
                item.get("first_seen_at", ""),
            )

        eligible.sort(key=selection_key, reverse=True)
        return eligible[0]

    def reserve(self, page_key: str, candidate: dict[str, Any]) -> None:
        video_id = candidate["video_id"]
        record = self.registry["videos"].setdefault(video_id, {})
        contracts = record.setdefault("required_destinations_by_stream", {})
        if not contracts.get(page_key):
            contract = list(dict.fromkeys(
                str(key).strip()
                for key in candidate.get("all_destinations", [])
                if str(key).strip()
            ))
            if contract:
                contracts[page_key] = contract
                record.setdefault("destination_contract_created_at", self._now_iso())
        self.registry["reservations"][f"{page_key}:{video_id}"] = {
            "page_key": page_key,
            "video_id": video_id,
            "pending_destinations": candidate.get("pending_destinations", []),
            "reserved_at": self._now_iso(),
        }
        self._save_registry()

    def release_reservation(self, page_key: str, candidate: dict[str, Any]) -> None:
        self.registry["reservations"].pop(f"{page_key}:{candidate['video_id']}", None)
        self._save_registry()

    def mark_source_unsuitable(
        self,
        page_key: str,
        candidate: dict[str, Any],
        reason: str,
    ) -> None:
        """Exclude a source globally without counting it as a destination/job failure."""
        video_id = str(candidate.get("video_id") or "").strip()
        if not video_id:
            return
        record = self.registry["videos"].setdefault(video_id, {})
        record["source_unsuitable"] = True
        record["source_unsuitable_at"] = self._now_iso()
        record["source_unsuitable_reason"] = str(reason)[-1500:]
        record["source_unsuitable_by_stream"] = str(page_key or "")
        self._save_registry()

    def mark_source_download_failed(
        self,
        page_key: str,
        candidate: dict[str, Any],
        error: str,
    ) -> None:
        """Temporarily cool down one source after transport/auth download failure.

        This intentionally does NOT increment destination failure counters because
        Facebook/TikTok posting has not started yet.
        """
        video_id = str(candidate.get("video_id") or "").strip()
        if not video_id:
            return
        record = self.registry["videos"].setdefault(video_id, {})
        old = record.get("source_download_failure") or {}
        count = int(old.get("count") or 0) + 1 if isinstance(old, dict) else 1
        # Short first hold so another candidate can run now; repeated failures back off.
        hold_minutes = min(360, 20 * (2 ** min(count - 1, 4)))
        now = datetime.now(timezone.utc)
        record["source_download_failure"] = {
            "count": count,
            "stream_key": str(page_key or ""),
            "last_failed_at": now.isoformat(),
            "retry_after": (now + timedelta(minutes=hold_minutes)).isoformat(),
            "last_error": str(error)[-1500:],
        }
        self._save_registry()

    def clear_source_download_failure(self, candidate: dict[str, Any]) -> None:
        video_id = str(candidate.get("video_id") or "").strip()
        if not video_id:
            return
        record = self.registry["videos"].setdefault(video_id, {})
        if record.pop("source_download_failure", None) is not None:
            self._save_registry()

    def mark_destination_posted(
        self,
        page_key: str,
        destination_key: str,
        candidate: dict[str, Any],
        post_link: str = "",
        output_path: str = "",
        platform: str = "",
    ) -> None:
        video_id = candidate["video_id"]
        posted_at = self._now_iso()
        record = self.registry["videos"].setdefault(video_id, {})
        contracts = record.setdefault("required_destinations_by_stream", {})
        if not contracts.get(page_key):
            contract = list(dict.fromkeys(
                str(key).strip()
                for key in candidate.get("all_destinations", [destination_key])
                if str(key).strip()
            ))
            contracts[page_key] = contract or [destination_key]
        record.setdefault("posted_pages", {})[destination_key] = {
            "stream_key": page_key,
            "platform": platform,
            "posted_at": posted_at,
            "post_link": post_link,
            "output_path": output_path,
        }
        record.setdefault("failures", {}).pop(destination_key, None)
        # Source-level permanent de-duplication marker. Destination keys may change
        # when routes are renamed/migrated, while the native source video id remains stable.
        record.setdefault("source_consumed_at", posted_at)
        record.setdefault("source_consumed_by_stream", page_key)
        record.setdefault("source_video_url", str(candidate.get("url") or ""))

        history = self.registry["posted_by_page"].setdefault(destination_key, [])
        history.append({
            "posted_at": posted_at,
            "stream_key": page_key,
            "destination_key": destination_key,
            "platform": platform,
            "video_id": video_id,
            "title": candidate.get("title", ""),
            "channel_id": candidate.get("channel_id", ""),
            "channel_name": candidate.get("channel_name", ""),
            "channel_url": candidate.get("channel_url", ""),
            "source_video_url": candidate.get("url", ""),
            "selection_reason": candidate.get("selection_reason", ""),
            "post_link": post_link,
            "output_path": output_path,
        })
        self._save_registry()

    def mark_destination_failed(
        self,
        page_key: str,
        destination_key: str,
        candidate: dict[str, Any],
        error: str,
    ) -> None:
        video_id = candidate["video_id"]
        record = self.registry["videos"].setdefault(video_id, {})
        contracts = record.setdefault("required_destinations_by_stream", {})
        if not contracts.get(page_key):
            contract = list(dict.fromkeys(
                str(key).strip()
                for key in candidate.get("all_destinations", [destination_key])
                if str(key).strip()
            ))
            contracts[page_key] = contract or [destination_key]
        failures = record.setdefault("failures", {}).setdefault(destination_key, {"count": 0})
        failures["stream_key"] = page_key
        failures["count"] = int(failures.get("count", 0)) + 1
        failures["last_failed_at"] = self._now_iso()
        failures["last_error"] = str(error)[-1500:]
        self._save_registry()

    # Backward-compatible wrappers for older callers.
    def mark_posted(
        self,
        page_key: str,
        candidate: dict[str, Any],
        post_link: str = "",
        output_path: str = "",
    ) -> None:
        self.mark_destination_posted(
            page_key=page_key,
            destination_key=page_key,
            candidate=candidate,
            post_link=post_link,
            output_path=output_path,
        )
        self.release_reservation(page_key, candidate)

    def mark_failed(self, page_key: str, candidate: dict[str, Any], error: str) -> None:
        self.mark_destination_failed(page_key, page_key, candidate, error)
        self.release_reservation(page_key, candidate)
