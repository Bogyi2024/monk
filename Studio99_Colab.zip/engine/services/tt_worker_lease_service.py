from __future__ import annotations

import os
from datetime import datetime
from typing import Any


DEFAULT_STALE_SECONDS = 90


def _as_local_datetime(value: Any) -> datetime | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return parsed if parsed.tzinfo is not None else parsed.astimezone()
    except (TypeError, ValueError):
        return None


def pid_is_alive(pid_value: Any) -> bool:
    """Check a worker PID without sending a signal to it on Windows."""
    try:
        pid = int(pid_value)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            process_query_limited_information = 0x1000
            still_active = 259
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel32.OpenProcess.restype = wintypes.HANDLE
            kernel32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
            kernel32.GetExitCodeProcess.restype = wintypes.BOOL
            kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel32.CloseHandle.restype = wintypes.BOOL
            handle = kernel32.OpenProcess(process_query_limited_information, False, pid)
            if not handle:
                return False
            try:
                code = wintypes.DWORD()
                return bool(kernel32.GetExitCodeProcess(handle, ctypes.byref(code))) and code.value == still_active
            finally:
                kernel32.CloseHandle(handle)
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except (OSError, PermissionError):
        return False


def running_lease_status(
    state: dict[str, Any],
    now: datetime | None = None,
    *,
    stale_after_seconds: int = DEFAULT_STALE_SECONDS,
) -> tuple[bool, str]:
    """Return whether a persisted RUNNING state still owns a live, fresh worker."""
    if str(state.get("status") or "").lower() != "running":
        return False, "not_running"
    pid = state.get("owner_pid")
    token = str(state.get("owner_token") or "").strip()
    heartbeat = _as_local_datetime(state.get("heartbeat_at"))
    if not pid or not token:
        return False, "legacy_state_without_owner"
    if not pid_is_alive(pid):
        return False, "owner_process_not_alive"
    if heartbeat is None:
        return False, "heartbeat_missing"
    local_now = now or datetime.now().astimezone()
    if local_now.tzinfo is None:
        local_now = local_now.astimezone()
    age = (local_now.astimezone(heartbeat.tzinfo) - heartbeat).total_seconds()
    if age > max(15, int(stale_after_seconds)):
        return False, f"heartbeat_stale_{int(age)}s"
    return True, "live"
