from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import tempfile
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

from services.fb_group_service import auto_share_all_accounts
from services.story_carousel_upload_service import upload_facebook_story_carousel
from services.tt_share_export_service import TTShareExportService
from services.tt_route_branding_service import TTRouteBrandingService


class TTNovelBridge:
    """Post one scheduled Novel part as one Facebook photo + long caption."""

    CATEGORY = "novel"

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings = settings_service
        self.root = Path(project_root).resolve()
        self.standalone_root = (self.root.parent / "novel_standalone").resolve()
        self.registry_path = self.root / "state" / "tt_novel_posts.json"
        self.generation_lock_path = self.root / "state" / "tt_novel_generation.lock.json"
        self.generation_log_path = self.standalone_root / "logs" / "scheduler_generation.log"
        self.share_export = TTShareExportService(settings_service, self.root)
        self.branding = TTRouteBrandingService(self.root)

    @classmethod
    def capability(cls, project_root: str | Path) -> dict[str, Any]:
        root = Path(project_root).resolve()
        standalone = root.parent / "novel_standalone"
        required = [
            root / "services" / "tt_novel_bridge.py",
            root / "services" / "story_carousel_upload_service.py",
            standalone / "run_novel.py",
            standalone / "services" / "novel_service.py",
            standalone / "config" / "novel.json",
        ]
        ok = all(path.exists() for path in required)
        return {
            "live": ok,
            "label": "LIVE — READY INVENTORY" if ok else "Novel bridge/files missing",
            "standalone_root": str(standalone),
        }

    @staticmethod
    def _read_json(path: Path, default: dict[str, Any]) -> dict[str, Any]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else dict(default)
        except (OSError, json.JSONDecodeError):
            return dict(default)

    @staticmethod
    def _atomic_json(path: Path, data: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        os.close(fd)
        tmp = Path(name)
        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            os.replace(tmp, path)
        finally:
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass

    def _config(self) -> dict[str, Any]:
        return self._read_json(self.standalone_root / "config" / "novel.json", {})

    def _output_roots(self) -> list[Path]:
        config = self._config()
        value = Path(str(config.get("output_root") or "outputs"))
        roots = [value.resolve() if value.is_absolute() else (self.standalone_root / value).resolve()]
        for raw in config.get("legacy_output_roots") or []:
            path = Path(str(raw))
            path = path.resolve() if path.is_absolute() else (self.standalone_root / path).resolve()
            if path not in roots:
                roots.append(path)
        return roots

    @staticmethod
    def _style_stats(text: str) -> dict[str, Any]:
        compact = "".join(str(text or "").split())
        count = str(text or "").count("သည်")
        return {
            "visible_chars": len(compact),
            "thi_count": count,
            "thi_per_1000_chars": round(count * 1000.0 / len(compact), 3) if compact else 0.0,
        }

    def _style_ok(self, text: str) -> tuple[bool, dict[str, Any]]:
        cfg = self._config()
        stats = self._style_stats(text)
        ok = (
            stats["thi_count"] <= int(cfg.get("max_thi_count_per_part", 6))
            and stats["thi_per_1000_chars"] <= float(cfg.get("max_thi_per_1000_chars", 1.5))
        )
        return ok, stats

    @staticmethod
    def _path_from(value: Any, series_dir: Path, fallback: Path) -> Path:
        raw = str(value or "").strip()
        if not raw:
            return fallback.resolve()
        path = Path(raw)
        return path.resolve() if path.is_absolute() else (series_dir / path).resolve()

    def _series(self) -> list[dict[str, Any]]:
        found: list[tuple[float, Path]] = []
        for root in self._output_roots():
            if not root.exists():
                continue
            for folder in root.iterdir():
                state_path = folder / "series.json"
                if folder.is_dir() and state_path.exists():
                    found.append((state_path.stat().st_mtime, folder))

        rows: list[dict[str, Any]] = []
        for _, folder in sorted(found, key=lambda item: item[0]):
            state = self._read_json(folder / "series.json", {})
            if int(state.get("parts_count") or 0) != 4 or not bool(state.get("complete")):
                continue
            blueprint = state.get("blueprint") or {}
            series_id = str(state.get("series_id") or folder.name)
            tt_route_key = str(state.get("tt_route_key") or "")
            start_raw = str(state.get("publish_start_date") or "").strip()
            if not start_raw:
                start_raw = str(state.get("created_at") or date.today().isoformat())[:10]
            try:
                start = date.fromisoformat(start_raw)
            except ValueError:
                start = date.today()
            plan_by_part = {
                int(item.get("part_no") or 0): item
                for item in (state.get("publishing_plan") or [])
                if isinstance(item, dict)
            }
            cover_parts = list((state.get("cover") or {}).get("parts") or [])
            page_state_by_part = {
                int(row.get("part_no") or 0): row
                for row in ((state.get("story_pages") or {}).get("parts") or [])
                if isinstance(row, dict)
            }
            parts: list[dict[str, Any]] = []
            for number in range(1, 5):
                part_state = next(
                    (x for x in state.get("parts") or [] if int(x.get("part_no") or 0) == number),
                    {},
                )
                plan = plan_by_part.get(number) or {}
                text_path = self._path_from(
                    plan.get("post_text"), folder, folder / "parts" / f"part_{number:02d}_post.txt"
                )
                cover_fallback = folder / "covers" / f"part_{number:02d}_cover.jpg"
                cover_value = plan.get("cover") or (cover_parts[number - 1] if len(cover_parts) >= number else "")
                cover_path = self._path_from(cover_value, folder, cover_fallback)
                raw_pages = plan.get("story_pages") or [
                    item.get("path") for item in (page_state_by_part.get(number) or {}).get("pages") or []
                ]
                story_page_paths = [
                    self._path_from(value, folder, folder / "story_pages" / f"part_{number:02d}" / "missing.jpg")
                    for value in raw_pages
                    if str(value or "").strip()
                ]
                publish_raw = str(plan.get("publish_date") or (start + timedelta(days=number - 1)).isoformat())
                try:
                    publish_date = date.fromisoformat(publish_raw).isoformat()
                except ValueError:
                    publish_date = (start + timedelta(days=number - 1)).isoformat()
                post_text = text_path.read_text(encoding="utf-8") if text_path.exists() else ""
                style_source = str(part_state.get("episode_text") or post_text)
                style_ok, style_stats = self._style_ok(style_source)
                parts.append({
                    "series_id": series_id,
                    "title": str(state.get("title") or blueprint.get("title") or folder.name),
                    "genre": str(state.get("genre_requested") or blueprint.get("genre") or ""),
                    "story_seed": str(state.get("story_seed") or ""),
                    "series_dir": str(folder),
                    "route_key": tt_route_key,
                    "part_no": number,
                    "part_title": str(part_state.get("part_title") or f"Part {number}"),
                    "publish_date": publish_date,
                    "text_path": str(text_path),
                    "cover_path": str(cover_path),
                    "story_page_paths": [str(path) for path in story_page_paths],
                    "story_page_count": len(story_page_paths),
                    "screenshot_pages_ready": bool(
                        story_page_paths and all(path.exists() for path in story_page_paths)
                    ),
                    "post_text": post_text,
                    "style_ok": style_ok,
                    "style_stats": style_stats,
                    "files_ready": bool(post_text.strip() and cover_path.exists()),
                    "content_id": f"novel:{series_id}:part:{number}",
                })
            rows.append({
                "series_id": series_id,
                "title": str(state.get("title") or blueprint.get("title") or folder.name),
                "genre": str(state.get("genre_requested") or blueprint.get("genre") or ""),
                "story_seed": str(state.get("story_seed") or ""),
                "series_dir": str(folder),
                "route_key": tt_route_key,
                "parts": parts,
            })
        return rows

    def _registry(self) -> dict[str, Any]:
        return self._read_json(self.registry_path, {"version": 1, "posts": {}})

    def inventory_snapshot(
        self,
        now: datetime | None = None,
        *,
        route_key: str = "",
        genre: str = "",
    ) -> dict[str, Any]:
        today = (now or datetime.now().astimezone()).date().isoformat()
        registry = self._registry()
        posted = registry.get("posts") or {}
        series_rows = self._series()
        if route_key or genre:
            series_rows = [
                series for series in series_rows
                if (
                    str(series.get("route_key") or "") == str(route_key or "")
                    or (
                        not str(series.get("route_key") or "")
                        and (not genre or str(series.get("genre") or "") == str(genre))
                    )
                )
            ]
        flat: list[dict[str, Any]] = []
        sequence_blocked = False
        for series in series_rows:
            for item in series["parts"]:
                row = {k: v for k, v in item.items() if k != "post_text"}
                receipt = posted.get(item["content_id"])
                if receipt:
                    row["status"] = "posted"
                    row["posted_at"] = str(receipt.get("posted_at") or "")
                elif sequence_blocked:
                    row["status"] = "waiting_previous_part"
                elif not item["files_ready"]:
                    row["status"] = "files_missing"
                    sequence_blocked = True
                elif not item["style_ok"]:
                    row["status"] = "style_repair_needed"
                    sequence_blocked = True
                elif item["publish_date"] > today:
                    row["status"] = "scheduled"
                    sequence_blocked = True
                else:
                    row["status"] = "ready"
                    sequence_blocked = True
                flat.append(row)
        next_item = next((row for row in flat if row["status"] == "ready"), None)
        latest = series_rows[-1] if series_rows else None
        cfg = self._config()
        return {
            "standalone_root": str(self.standalone_root),
            "genres": list(cfg.get("genres") or []),
            "series_count": len(series_rows),
            "latest_series": ({k: v for k, v in latest.items() if k != "parts"} if latest else None),
            "parts": flat[-12:],
            "ready_count": sum(1 for row in flat if row["status"] == "ready"),
            "style_blocked_count": sum(1 for row in flat if row["status"] == "style_repair_needed"),
            "next_part": next_item,
            "today": today,
            "style_limits": {
                "max_thi_count_per_part": int(cfg.get("max_thi_count_per_part", 6)),
                "max_thi_per_1000_chars": float(cfg.get("max_thi_per_1000_chars", 1.5)),
            },
        }

    def _next_ready(self, route_key: str, genre: str) -> dict[str, Any] | None:
        snap = self.inventory_snapshot(route_key=route_key, genre=genre)
        wanted = snap.get("next_part") or {}
        content_id = str(wanted.get("content_id") or "")
        if not content_id:
            return None
        for series in self._series():
            owner = str(series.get("route_key") or "")
            if owner and owner != route_key:
                continue
            if not owner and genre and str(series.get("genre") or "") != genre:
                continue
            for item in series["parts"]:
                if item["content_id"] == content_id:
                    return item
        return None

    def _save_primary_receipt(self, item: dict[str, Any], route_key: str, post_link: str) -> None:
        registry = self._registry()
        registry.setdefault("posts", {})[item["content_id"]] = {
            "content_id": item["content_id"],
            "series_id": item["series_id"],
            "part_no": item["part_no"],
            "route_key": route_key,
            "posted_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "facebook_post_link": post_link,
            "primary_complete": True,
        }
        self._atomic_json(self.registry_path, registry)

    def _today_receipt(self, route_key: str) -> dict[str, Any] | None:
        today = date.today().isoformat()
        posts = (self._registry().get("posts") or {}).values()
        rows = [
            row for row in posts
            if str(row.get("route_key") or "") == route_key
            and str(row.get("posted_at") or "")[:10] == today
            and bool(row.get("primary_complete"))
        ]
        return sorted(rows, key=lambda row: str(row.get("posted_at") or ""))[-1] if rows else None

    @staticmethod
    def _pid_alive(pid: Any) -> bool:
        try:
            value = int(pid)
            if value <= 0:
                return False
            os.kill(value, 0)
            return True
        except (TypeError, ValueError, OSError):
            return False

    def _route_series(self, route_key: str, genre: str) -> list[dict[str, Any]]:
        return [
            series for series in self._series()
            if (
                str(series.get("route_key") or "") == route_key
                or (
                    not str(series.get("route_key") or "")
                    and genre
                    and str(series.get("genre") or "") == genre
                )
            )
        ]

    def _unposted_items(self, route_key: str, genre: str) -> list[dict[str, Any]]:
        posted = (self._registry().get("posts") or {})
        return [
            item
            for series in self._route_series(route_key, genre)
            for item in series.get("parts") or []
            if item.get("content_id") not in posted
        ]

    def _latest_incomplete_dir(self, route_key: str) -> Path | None:
        found: list[tuple[float, Path]] = []
        for root in self._output_roots():
            if not root.exists():
                continue
            for folder in root.iterdir():
                state_path = folder / "series.json"
                if not folder.is_dir() or not state_path.exists():
                    continue
                state = self._read_json(state_path, {})
                if (
                    int(state.get("parts_count") or 0) == 4
                    and not bool(state.get("complete"))
                    and str(state.get("tt_route_key") or "") == route_key
                ):
                    found.append((state_path.stat().st_mtime, folder.resolve()))
        return sorted(found, key=lambda row: row[0], reverse=True)[0][1] if found else None

    def _acquire_generation_lock(self, route_key: str, operation: str) -> None:
        self.generation_lock_path.parent.mkdir(parents=True, exist_ok=True)
        for _ in range(2):
            payload = {
                "route_key": route_key,
                "operation": operation,
                "owner_pid": os.getpid(),
                "worker_pid": 0,
                "started_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            }
            try:
                fd = os.open(
                    self.generation_lock_path,
                    os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                )
                try:
                    os.write(fd, (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
                finally:
                    os.close(fd)
                return
            except FileExistsError:
                current = self._read_json(self.generation_lock_path, {})
                pid = current.get("worker_pid") or current.get("owner_pid")
                if self._pid_alive(pid):
                    raise RuntimeError(
                        f"Novel generation already active for route {current.get('route_key') or '?'}"
                    )
                self.generation_lock_path.unlink(missing_ok=True)
        raise RuntimeError("Novel generation lock could not be acquired")

    async def _run_standalone(
        self,
        args: list[str],
        *,
        route_key: str,
        operation: str,
    ) -> None:
        self._acquire_generation_lock(route_key, operation)
        self.generation_log_path.parent.mkdir(parents=True, exist_ok=True)
        process = None
        pump_task = None
        try:
            with self.generation_log_path.open("a", encoding="utf-8") as log:
                log.write(
                    f"\n===== {datetime.now().astimezone().isoformat(timespec='seconds')} "
                    f"{operation} route={route_key} =====\n"
                )
                log.flush()
                process = await asyncio.create_subprocess_exec(
                    sys.executable,
                    "-u",
                    "-X",
                    "utf8",
                    "run_novel.py",
                    *args,
                    cwd=str(self.standalone_root),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.STDOUT,
                    creationflags=(subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0),
                )
                self._atomic_json(self.generation_lock_path, {
                    "route_key": route_key,
                    "operation": operation,
                    "owner_pid": os.getpid(),
                    "worker_pid": process.pid,
                    "started_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                })

                async def pump_output() -> None:
                    if process is None or process.stdout is None:
                        return
                    while True:
                        raw_line = await process.stdout.readline()
                        if not raw_line:
                            break
                        line = raw_line.decode("utf-8", errors="replace")
                        log.write(line)
                        log.flush()
                        print(f"📖 NOVEL │ {line}", end="", flush=True)

                pump_task = asyncio.create_task(pump_output())
                try:
                    returncode = await asyncio.wait_for(process.wait(), timeout=3 * 60 * 60)
                    await pump_task
                except asyncio.TimeoutError:
                    process.kill()
                    await process.wait()
                    if pump_task:
                        await pump_task
                    raise TimeoutError("Novel generation exceeded the 3-hour hard timeout")
            if returncode != 0:
                try:
                    tail = " | ".join(
                        self.generation_log_path.read_text(
                            encoding="utf-8", errors="replace"
                        ).splitlines()[-8:]
                    )
                except OSError:
                    tail = ""
                raise RuntimeError(
                    f"Novel standalone exited {returncode}; see {self.generation_log_path}"
                    + (f"; {tail[-1800:]}" if tail else "")
                )
        finally:
            self.generation_lock_path.unlink(missing_ok=True)

    @staticmethod
    def _route_modes(route: dict[str, Any]) -> tuple[bool, bool]:
        long_text = bool(route.get("novel_long_text_enabled", True))
        photo_pages = bool(route.get("novel_screenshot_pages_enabled", False))
        if not long_text and not photo_pages:
            raise RuntimeError("Novel route must enable Long text, 9:16 photo pages, or both")
        return long_text, photo_pages

    @staticmethod
    def _photo_caption(item: dict[str, Any]) -> str:
        lines = [line.strip() for line in str(item.get("post_text") or "").splitlines() if line.strip()]
        heading = lines[:2]
        hashtags = next((line for line in reversed(lines) if line.startswith("#")), "")
        body = [*heading, "ဓာတ်ပုံများကို အစဉ်လိုက်ဖတ်ပါ။"]
        if hashtags and hashtags not in body:
            body.append(hashtags)
        return "\n\n".join(body) + "\n"

    async def _resume_series(
        self,
        series_dir: str | Path,
        *,
        route_key: str,
        repair_style: bool = False,
        screenshot_pages: bool = False,
    ) -> None:
        folder = str(Path(series_dir).resolve())
        if not repair_style and not screenshot_pages:
            await self._run_standalone(
                ["--resume", folder],
                route_key=route_key,
                operation="resume_series_assets",
            )
            return
        if repair_style:
            await self._run_standalone(
                ["--resume", folder, "--repair-style"],
                route_key=route_key,
                operation="auto_style_repair",
            )
        if screenshot_pages:
            await self._run_standalone(
                ["--resume", folder, "--screenshot-pages"],
                route_key=route_key,
                operation="render_screenshot_pages",
            )

    async def _ensure_route_inventory(
        self,
        *,
        route_key: str,
        route: dict[str, Any],
        photo_pages: bool,
    ) -> None:
        genre = str(route.get("novel_genre") or "")
        unposted = self._unposted_items(route_key, genre)
        if unposted:
            blocked = next((item for item in unposted if not item.get("style_ok")), None)
            if blocked:
                await self._resume_series(
                    blocked["series_dir"],
                    route_key=route_key,
                    repair_style=True,
                    screenshot_pages=photo_pages,
                )
                return
            missing = next((item for item in unposted if not item.get("files_ready")), None)
            if missing:
                await self._resume_series(
                    missing["series_dir"],
                    route_key=route_key,
                    screenshot_pages=photo_pages,
                )
            # Scheduled future stock is intentionally not replenished here.
            return

        incomplete = self._latest_incomplete_dir(route_key)
        if incomplete:
            args = ["--resume", str(incomplete)]
            if photo_pages:
                args.append("--screenshot-pages")
            await self._run_standalone(
                args,
                route_key=route_key,
                operation="resume_generation",
            )
            return

        # Route-driven Novel publishing always starts on the day the enabled
        # route reaches its scheduler turn; there is no separate date gate.
        start = date.today().isoformat()
        args = [
            "--genre", genre,
            "--synopsis", str(route.get("novel_story_seed") or ""),
            "--start-date", start,
            "--route-key", route_key,
        ]
        if photo_pages:
            args.append("--screenshot-pages")
        await self._run_standalone(args, route_key=route_key, operation="on_demand_generation")

    async def run_once(self, route_key: str = "default") -> dict[str, Any]:
        resolved = self.settings.resolve_route(self.CATEGORY, route_key)
        category = resolved.get("category") or {}
        route = resolved.get("route") or {}
        if not category.get("enabled", True) or not route.get("enabled", True):
            raise RuntimeError(f"Novel route disabled: {route_key}")
        if resolved.get("tiktok"):
            raise RuntimeError("Novel long-text route supports Facebook only; remove the TikTok account")
        facebook = resolved.get("facebook")
        if not facebook or not facebook.get("enabled", True):
            raise RuntimeError("Novel route needs an enabled Facebook Page")

        long_text, photo_pages = self._route_modes(route)
        route_genre = str(route.get("novel_genre") or "")
        item = self._next_ready(route_key, route_genre)
        if item is None:
            receipt = self._today_receipt(route_key)
            if receipt:
                return {
                    "success": True,
                    "new_content_count": 1,
                    "content_id": str(receipt.get("content_id") or ""),
                    "route_key": route_key,
                    "recovered_primary_receipt": True,
                }
            await self._ensure_route_inventory(
                route_key=route_key,
                route=route,
                photo_pages=photo_pages,
            )
            item = self._next_ready(route_key, route_genre)

        if item is not None and photo_pages and not item.get("screenshot_pages_ready"):
            await self._resume_series(
                item["series_dir"],
                route_key=route_key,
                screenshot_pages=True,
            )
            item = self._next_ready(route_key, route_genre)

        if item is None:
            snap = self.inventory_snapshot(route_key=route_key, genre=route_genre)
            if snap.get("style_blocked_count"):
                raise RuntimeError(
                    "Novel automatic style repair did not produce a READY part "
                    f"('သည်' limit {snap['style_limits']['max_thi_count_per_part']})"
                )
            return {
                "success": True,
                "new_content_count": 0,
                "maintenance_only": True,
                "no_work": True,
                "route_key": route_key,
                "failure_kind": "no_new_content",
            }

        image_paths = [item["cover_path"]]
        if photo_pages:
            story_pages = list(item.get("story_page_paths") or [])
            if not story_pages or not item.get("screenshot_pages_ready"):
                raise RuntimeError("Novel 9:16 screenshot pages are not ready after rendering")
            image_paths.extend(story_pages)
        image_paths = await asyncio.to_thread(
            self.branding.brand_images,image_paths,self.CATEGORY,route_key,
            route.get("branding") or {},"facebook_post",
        )
        caption = item["post_text"] if long_text else self._photo_caption(item)
        selected = self.share_export.sync_route(self.CATEGORY, route_key)
        want_group = bool(route.get("share_enabled", True) and selected)
        detail = await upload_facebook_story_carousel(
            image_paths,
            caption,
            profile_name=str(facebook.get("profile") or "Main_FB_Account"),
            page_id=str(facebook.get("page_id") or ""),
            headless=False,
            return_detail=True,
            capture_permalink=want_group,
        )
        if not (detail or {}).get("success"):
            return {
                "success": False,
                "new_content_count": 0,
                "pending": True,
                "route_key": route_key,
                "failure_kind": "facebook_upload_pending",
                "error": str((detail or {}).get("error") or "Novel Facebook photo post failed"),
            }

        post_link = str((detail or {}).get("post_link") or "")
        # Primary receipt is durable before optional group sharing, preventing reposts.
        self._save_primary_receipt(item, route_key, post_link)
        secondary_reason = ""
        group_summary = None
        if want_group:
            if not post_link:
                secondary_reason = "facebook_permalink_not_found"
                print("⏭️ Novel secondary group share skipped: permalink unavailable; primary remains COMPLETE")
            else:
                try:
                    group_summary = await auto_share_all_accounts(
                        post_link,
                        account_names=selected,
                        share_text=caption,
                        headless=False,
                        delay_between_groups_seconds=20.0,
                        delay_between_accounts_seconds=120.0,
                    )
                except Exception as exc:
                    secondary_reason = f"group_share_error:{exc}"
                    print(f"⏭️ Novel secondary group share skipped; primary remains COMPLETE: {exc}")

        return {
            "success": True,
            "new_content_count": 1,
            "content_id": item["content_id"],
            "route_key": route_key,
            "series_id": item["series_id"],
            "part_no": item["part_no"],
            "long_text_enabled": long_text,
            "screenshot_pages_enabled": photo_pages,
            "photo_count": len(image_paths),
            "cleanup_assets": [str(item['series_dir'])],
            "facebook_post_link": post_link,
            "group_summary": group_summary,
            "secondary_skipped_reason": secondary_reason,
        }
