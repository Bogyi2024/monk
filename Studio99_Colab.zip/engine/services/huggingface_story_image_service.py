from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Optional

from huggingface_hub import InferenceClient


class HuggingFaceStoryImageService:
    def __init__(self, config: dict):
        self.config = config or {}
        self.token = (
            os.getenv("HF_TOKEN")
            or os.getenv("HUGGINGFACEHUB_API_TOKEN")
            or os.getenv("HUGGING_FACE_HUB_TOKEN")
        )
        if not self.token:
            raise RuntimeError("HF_TOKEN not set in .env")

        self.model = self.config.get("hf_image_model", "black-forest-labs/FLUX.1-schnell")
        self.provider = self.config.get("hf_provider", "auto")
        self.width = int(self.config.get("hf_width", 1024))
        self.height = int(self.config.get("hf_height", 1024))
        self.num_inference_steps = int(self.config.get("hf_num_inference_steps", 4))
        self.guidance_scale = float(self.config.get("hf_guidance_scale", 3.5))
        self.negative_prompt = self.config.get("hf_negative_prompt", "")
        self.timeout_seconds = int(self.config.get("hf_timeout_seconds", 180))

        self.client = InferenceClient(
            provider=self.provider,
            api_key=self.token,
            timeout=self.timeout_seconds,
        )

    def generate_image(
        self,
        *,
        prompt: str,
        save_path: str | Path,
        negative_prompt: Optional[str] = None,
    ) -> str:
        prompt = (prompt or "").strip()
        if not prompt:
            raise RuntimeError("Hugging Face image prompt is empty")

        save_path = Path(save_path)
        save_path.parent.mkdir(parents=True, exist_ok=True)

        merged_negative = (negative_prompt or self.negative_prompt or "").strip()

        t0 = time.time()
        kwargs = {
            "model": self.model,
            "width": self.width,
            "height": self.height,
            "num_inference_steps": self.num_inference_steps,
            "guidance_scale": self.guidance_scale,
        }
        if merged_negative:
            kwargs["negative_prompt"] = merged_negative

        image = self.client.text_to_image(prompt, **kwargs)

        if save_path.suffix.lower() in {".jpg", ".jpeg"} and getattr(image, "mode", "") == "RGBA":
            image = image.convert("RGB")
        image.save(save_path)
        dt = time.time() - t0
        print(f"✅ HF image saved → {save_path} ({dt:.1f}s) | provider={self.provider} | model={self.model}")
        return str(save_path)
