from __future__ import annotations

import json
import re
import os
import tempfile
import time
from pathlib import Path
from typing import Any
from services.fb_profile_paths import profile_store as validate_profile_store

ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT_DIR = ROOT / "state" / "fb_session_snapshots"


def _safe_profile(profile: str) -> str:
    value = str(profile or "").strip()
    if not value or any(x in value for x in ("/", "\\", "..")):
        raise ValueError("Invalid Facebook profile name")
    return value


def snapshot_path(profile: str, profile_store: str = "browser_sessions") -> Path:
    store = validate_profile_store(profile_store)
    base = SNAPSHOT_DIR if store == "browser_sessions" else SNAPSHOT_DIR / store
    return base / f"{_safe_profile(profile)}.json"


def load_snapshot(profile: str, profile_store: str = "browser_sessions") -> dict[str, Any] | None:
    p = snapshot_path(profile, profile_store)
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


async def save_snapshot(context, profile: str, profile_store: str = "browser_sessions") -> str:
    p = snapshot_path(profile, profile_store)
    p.parent.mkdir(parents=True, exist_ok=True)
    state = await context.storage_state()
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=p.parent, suffix=".tmp", delete=False) as stream:
            tmp = Path(stream.name)
            json.dump(state, stream, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
    finally:
        if tmp is not None:
            tmp.unlink(missing_ok=True)
    return str(p)


async def restore_snapshot(context, profile: str, profile_store: str = "browser_sessions") -> bool:
    """Restore saved auth cookies into the already-open persistent context.

    The persistent browser profile remains the primary store. This snapshot is only
    a recovery copy for cases where Chromium/Meta drops the reusable login between
    launches. It does not contain passwords.
    """
    state = load_snapshot(profile, profile_store)
    if not state:
        return False

    cookies = state.get("cookies") or []
    valid = []
    for row in cookies:
        if not isinstance(row, dict):
            continue
        domain = str(row.get("domain") or "").lower()
        if domain.lstrip(".") != "facebook.com" and not domain.endswith(".facebook.com"):
            continue
        try:
            if float(row.get("expires") or -1) > 0 and float(row["expires"]) <= time.time():
                continue
        except (TypeError, ValueError):
            continue
        # Playwright rejects some browser-export-only keys; retain supported ones.
        keep = {
            k: v for k, v in row.items()
            if k in {
                "name", "value", "domain", "path", "expires",
                "httpOnly", "secure", "sameSite", "url", "partitionKey",
            }
        }
        if keep.get("name") and keep.get("value"):
            valid.append(keep)

    if not valid:
        return False
    try:
        await context.add_cookies(valid)
        return True
    except Exception:
        # Older Playwright builds can reject partitionKey or a newer sameSite value.
        simplified = []
        for row in valid:
            clean = {k: v for k, v in row.items() if k != "partitionKey"}
            if str(clean.get("sameSite") or "") not in {"Strict", "Lax", "None"}:
                clean.pop("sameSite", None)
            simplified.append(clean)
        try:
            await context.add_cookies(simplified)
            return True
        except Exception:
            return False


def has_login_cookie(profile: str, profile_store: str = "browser_sessions") -> bool:
    state = load_snapshot(profile, profile_store) or {}
    names = {str(x.get("name") or "") for x in (state.get("cookies") or []) if isinstance(x, dict)}
    # c_user is the strongest Facebook login marker; xs normally accompanies it.
    return "c_user" in names and "xs" in names
