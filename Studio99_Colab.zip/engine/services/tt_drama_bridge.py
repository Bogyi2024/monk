from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path
from typing import Any

from services.tt_share_export_service import TTShareExportService
from services.tt_route_branding_service import TTRouteBrandingService


class TTDramaBridge:
    """Existing Story Board Drama pipeline with staged resume + route-level destinations.

    Important: the Story Board generator itself is unchanged.  This bridge only makes
    generation resumable after FAL succeeds and wires the already-configured route to
    FB/TikTok/group sharing.
    """

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings = settings_service
        self.root = Path(project_root).resolve()
        self.pending_path = self.root / "state" / "tt_drama_pending.json"
        self.pending_path.parent.mkdir(parents=True, exist_ok=True)
        self.share_export = TTShareExportService(settings_service, self.root)
        self.branding = TTRouteBrandingService(self.root)

    def _load_pending(self) -> dict[str, Any] | None:
        try:
            if self.pending_path.exists():
                data = json.loads(self.pending_path.read_text(encoding="utf-8"))
                return data if isinstance(data, dict) else None
        except Exception:
            pass
        return None

    def _recover_latest_orphan_generation(self, route_key: str) -> dict[str, Any] | None:
        """Recover a Story Carousel/FAL job that finished before old bridge TTS failed."""
        root=self.root/'outputs'/'story_carousel'
        if not root.exists(): return None
        candidates=[]
        stale_count=0
        max_age_hours=float(os.getenv("TT_DRAMA_ORPHAN_MAX_AGE_HOURS", "24") or 24)
        now=time.time()
        for folder in root.iterdir():
            if not folder.is_dir(): continue
            result_path=folder/'result.json'
            if not result_path.exists(): continue
            # A completed motion file means this is not the TTS-failed orphan we want.
            if (folder/'story_drama_motion_v2.mp4').exists(): continue
            try:
                mtime=result_path.stat().st_mtime
                age_hours=max(0.0,(now-mtime)/3600.0)
                if age_hours>max_age_hours:
                    stale_count+=1
                    continue
                data=json.loads(result_path.read_text(encoding='utf-8'))
                if str(data.get('genre') or '').lower()!='drama': continue
                candidates.append((mtime,folder,data))
            except Exception: continue
        if stale_count:
            print(f"🧹 Drama orphan recovery skipped {stale_count} stale generation(s) older than {max_age_hours:g}h")
        if not candidates: return None
        _ts,folder,result=max(candidates,key=lambda x:x[0])
        print(f"♻️ Drama orphan recovery: reusing existing FAL/story output → {folder}")
        return {'route_key':route_key,'result':result,'stage':'carousel_ready','fb_done':False,'tt_done':False,'group_done':False,'fb_post_link':'','group_summary':None}

    def _save_pending(self, data: dict[str, Any] | None) -> None:
        if data is None:
            if self.pending_path.exists(): self.pending_path.unlink()
            return
        self.pending_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    @staticmethod
    def _caption(result: dict[str, Any]) -> str:
        base = str(result.get("tt_caption") or result.get("title") or "").strip()
        tags=[]
        for raw in result.get("hashtags") or []:
            x=str(raw).strip()
            if x: tags.append(x if x.startswith("#") else "#"+x)
        return (base + ("\n\n" + " ".join(tags) if tags else "")).strip()

    @staticmethod
    def _fb_caption(result: dict[str, Any]) -> str:
        """Exact caption contract used by Story Carousel Facebook upload."""
        base = str(result.get("fb_caption") or result.get("title") or "").strip()
        tags=[]
        for raw in result.get("hashtags") or []:
            x=str(raw).strip()
            if x: tags.append(x if x.startswith("#") else "#"+x)
        return (base + ("\n\n" + " ".join(tags) if tags else "")).strip()

    @staticmethod
    def _content_id(result: dict[str, Any]) -> str:
        sid=str(result.get("story_id") or "").strip()
        if sid:
            return sid
        try:
            story_json=Path(str(result.get("story_json") or ""))
            if story_json.name:
                return story_json.resolve().parent.name
        except Exception:
            pass
        return ""

    async def _ensure_generated(self, pending: dict[str, Any]) -> dict[str, Any]:
        from services.story_carousel_service import StoryCarouselService
        from services.story_narration_service import StoryNarrationService
        from services.story_motion_video_service import StoryMotionVideoService

        # Stage 1: Story/FAL carousel. Save IMMEDIATELY so a later TTS failure never
        # pays for the seven images again.
        if not isinstance(pending.get("result"), dict):
            svc=StoryCarouselService(config_path="config/story_carousel.json")
            result=await svc.build_story(genre="drama", topic="")
            pending.update({"result":result,"stage":"carousel_ready"})
            self._save_pending(pending)
            print("💾 Drama resume checkpoint: Story/FAL carousel saved before narration/TTS")

        result=pending["result"]
        story_json=Path(str(result.get("story_json") or ""))
        if not story_json.exists():
            raise FileNotFoundError(f"Drama story_json missing: {story_json}")
        story_dir=story_json.resolve().parent
        story=json.loads(story_json.read_text(encoding="utf-8"))
        video_cfg=json.loads((self.root/"config"/"story_video.json").read_text(encoding="utf-8"))

        # Stage 2: narration plan. It is local text once created, so reuse it too.
        narration_path=story_dir/"narration_plan.json"
        narration=pending.get("narration_plan")
        if not isinstance(narration, dict):
            if narration_path.exists():
                try: narration=json.loads(narration_path.read_text(encoding="utf-8"))
                except Exception: narration=None
            if not isinstance(narration, dict):
                narration=await StoryNarrationService(video_cfg).create_plan(story)
                narration_path.write_text(json.dumps(narration,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
            pending["narration_plan"]=narration;pending["stage"]="narration_ready";self._save_pending(pending)
            print("💾 Drama resume checkpoint: narration plan saved")

        # Stage 3: continuous Gemini TTS + motion. GeminiStoryTTSService now retries
        # no-audio payloads. If it still fails, stages 1/2 remain in pending JSON.
        if not isinstance(pending.get("motion_report"), dict):
            motion=StoryMotionVideoService(video_cfg)
            report=await asyncio.to_thread(
                motion.build,
                story_dir=story_dir,
                story=story,
                narration_plan=narration,
                force_tts=False,
            )
            pending["motion_report"]=report;pending["stage"]="motion_ready";self._save_pending(pending)
            print("💾 Drama resume checkpoint: motion/TTS ready")
        return pending

    async def run_once(self, route_key: str = "default") -> dict[str, Any]:
        pending=self._load_pending()
        if pending:
            print(
                "♻️ Drama pending retry: reusing the SAME story/FAL images intentionally "
                "(no paid image regeneration until this pending item completes)"
            )
        if not pending:
            pending=self._recover_latest_orphan_generation(route_key)
            if pending:self._save_pending(pending)
        if pending and pending.get("route_key"):
            route_key=str(pending.get("route_key"))
        resolved=self.settings.resolve_route("drama",route_key)
        cat=resolved["category"]; route_cfg=resolved.get("route") or {}
        if not cat.get("enabled",True) or not route_cfg.get("enabled",True):
            raise RuntimeError(f"Drama route disabled: {route_key}")

        if not pending:
            pending={"route_key":route_key,"fb_done":False,"tt_done":False,"group_done":False,"fb_post_link":"","group_summary":None,"stage":"start"}
            self._save_pending(pending)
        pending=await self._ensure_generated(pending)
        result=pending["result"]

        fb=resolved.get("facebook"); tt=resolved.get("tiktok")
        want_fb=bool(fb and fb.get("enabled",True)); want_tt=bool(tt and tt.get("enabled",True))
        selected_profiles=self.share_export.sync_route("drama",route_key)
        want_group=bool(want_fb and route_cfg.get("share_enabled",True) and selected_profiles)

        # Count only NEW primary destination work performed in THIS invocation.
        # A later run that merely finishes old group-share retries must never be
        # reported as a new Drama post for today's scheduler counter.
        primary_completed_this_run: list[str] = []

        if not want_fb and not want_tt:
            raise RuntimeError(f"Drama route {route_key} has no enabled Facebook/TikTok destination")

        if want_fb and not pending.get("fb_done"):
            # Capture the Page FEED baseline before publishing. Recovery later accepts
            # only a new owner-verified post absent from this baseline.
            if want_group and not isinstance(pending.get("fb_post_baseline"), list):
                try:
                    from services.browser_service import BrowserService
                    pending["fb_post_baseline"] = await BrowserService().collect_page_post_baseline(
                        str(fb.get("profile") or "Main_FB_Account"),
                        str(fb.get("page_id") or ""),
                        timeout_ms=90000,
                    )
                except Exception as exc:
                    print(f"⚠️ Drama Page-feed baseline capture failed; publish will continue fail-closed: {exc}")
                    pending["fb_post_baseline"] = []
                pending["fb_upload_started_at"] = time.time()
                self._save_pending(pending)

            from services.story_carousel_upload_service import upload_story_result
            branded_images=await asyncio.to_thread(
                self.branding.brand_images,result.get("square_images") or [],"drama",route_key,
                route_cfg.get("branding") or {},"facebook_post",
            )
            branded_result={**result,"square_images":branded_images}
            summary=await upload_story_result(
                branded_result,upload_fb=True,upload_tt=False,
                fb_profile=str(fb.get("profile") or "Main_FB_Account"),
                fb_page_id=str(fb.get("page_id") or ""),tt_profile="",
                capture_fb_permalink=want_group,
            )
            pending["fb_done"]=summary.get("facebook") is True
            direct_link=str(summary.get("facebook_post_link") or "")
            if direct_link:
                pending["fb_post_link"]=direct_link
                print(f"🔐 Drama exact FB post permalink saved directly from publish confirmation → {direct_link}")
            self._save_pending(pending)
            if pending["fb_done"]:
                primary_completed_this_run.append("facebook")
            if not pending["fb_done"]:
                return {"success":False,"new_content_count":0,"pending":True,"route_key":route_key,"failure_kind":"facebook_upload_pending"}

        if want_tt and not pending.get("tt_done"):
            from services.tt_service import upload_to_tiktok
            video=str((pending.get("motion_report") or {}).get("final_video") or "")
            if not video or not Path(video).exists(): raise FileNotFoundError(f"Drama motion video missing: {video}")
            branded_video=await asyncio.to_thread(self.branding.brand_video,video,"drama",route_key,route_cfg.get("branding") or {},"tiktok_reel")
            ok=await upload_to_tiktok(profile_folder_name=str(tt.get("profile") or ""),video_path=branded_video,caption_text=self._caption(result),headless=False)
            pending["tt_done"]=bool(ok);self._save_pending(pending)
            if pending["tt_done"]:
                primary_completed_this_run.append("tiktok")
            if not pending["tt_done"]:
                return {"success":False,"new_content_count":0,"pending":True,"route_key":route_key,"failure_kind":"tiktok_upload_pending"}

        # Primary posting is complete when every configured FB/TikTok destination for
        # THIS story has succeeded.  Group sharing is secondary maintenance and must
        # never prevent Today/Done from counting the actual content item.
        fb_complete=(not want_fb) or bool(pending.get("fb_done"))
        tt_complete=(not want_tt) or bool(pending.get("tt_done"))
        primary_complete=bool(fb_complete and tt_complete)
        content_id=self._content_id(result)

        # Per-PAGE route share accounts. No category-wide share fallback.
        if not want_group:
            pending["group_done"]=True;self._save_pending(pending)
        elif not pending.get("group_done"):
            from services.browser_service import BrowserService
            browser=BrowserService()
            post_link=str(pending.get("fb_post_link") or "")

            # Never trust a cached/recovered normal post link without proving it belongs
            # to the configured Facebook Page.  This blocks a logged-in personal-account
            # /posts/... URL from being auto-shared to all groups.
            if post_link:
                owned=await browser.verify_page_post_permalink(
                    str(fb.get("profile") or ""),str(fb.get("page_id") or ""),post_link,timeout_ms=90000,
                    expected_caption=self._fb_caption(result),
                )
                if not owned:
                    print(f"🚫 Drama group-share guard rejected cached permalink (owner/fingerprint mismatch): {post_link}")
                    post_link="";pending["fb_post_link"]="";self._save_pending(pending)

            if not post_link:
                # Secondary permalink recovery has a HARD persistent budget. Three
                # scheduler invocations are enough; after that we log/skip group share
                # and release the story so the whole Master can never loop here forever.
                link_try=int(pending.get("permalink_recovery_attempts") or 0)+1
                pending["permalink_recovery_attempts"]=link_try;self._save_pending(pending)
                print(f"🔎 Drama Page permalink recovery attempt {link_try}/3")
                post_link=await browser.recover_latest_page_post_permalink(
                    str(fb.get("profile") or ""),str(fb.get("page_id") or ""),timeout_ms=120000,
                    baseline_urls=pending.get("fb_post_baseline") or [],
                    expected_caption=self._fb_caption(result),
                )
                pending["fb_post_link"]=str(post_link or "");self._save_pending(pending)
            if not post_link:
                link_try=int(pending.get("permalink_recovery_attempts") or 0)
                if link_try>=3:
                    print("⏭️ Drama Page permalink not found after 3 attempts — logged and SKIPPED group share; queue will continue.")
                    pending["group_done"]=True
                    pending["group_summary"]={"skipped":True,"reason":"permalink_not_found_after_3","attempts":link_try}
                    pending["secondary_skipped_reason"]="permalink_not_found_after_3"
                    self._save_pending(pending)
                else:
                    print(f"🛡️ Drama group-share held: no owner-verified Page permalink yet ({link_try}/3)")
                    if primary_complete:
                        # Count the content now; only the bounded secondary recovery remains.
                        return {
                            "success":True,"new_content_count":1,"pending":True,"pending_secondary":True,
                            "route_key":route_key,"failure_kind":"group_permalink_pending",
                            "content_id":content_id,"story_id":content_id,
                            "primary_completed_this_run":primary_completed_this_run,
                        }
                    return {"success":False,"new_content_count":0,"pending":True,"route_key":route_key,"failure_kind":"group_permalink_pending"}
            if post_link and not pending.get("group_done"):
                from services.fb_group_service import auto_share_all_accounts
                group_try=int(pending.get("group_share_attempts") or 0)+1
                pending["group_share_attempts"]=group_try;self._save_pending(pending)
                print(f"👥 Drama group-share whole-run attempt {group_try}/3")
                try:
                    summary=await auto_share_all_accounts(
                        post_link,account_names=selected_profiles,share_text=self._caption(result),
                        headless=False,delay_between_groups_seconds=20.0,delay_between_accounts_seconds=120.0,
                    )
                    pending["group_summary"]=summary;pending["group_done"]=True;self._save_pending(pending)
                    if int((summary or {}).get("failed") or 0)>0:
                        print(f"⚠️ Drama group-share completed best-effort with {(summary or {}).get('failed')} failed group(s); failures logged, queue continues.")
                except Exception as exc:
                    if group_try>=3:
                        print(f"⏭️ Drama group-share failed after 3 whole-run attempts — logged and SKIPPED; queue will continue: {exc}")
                        pending["group_done"]=True
                        pending["group_summary"]={"skipped":True,"reason":"group_share_failed_after_3","attempts":group_try,"error":str(exc)}
                        pending["secondary_skipped_reason"]="group_share_failed_after_3"
                        self._save_pending(pending)
                    else:
                        print(f"⚠️ Drama group-share secondary retry remains pending ({group_try}/3): {exc}")
                        if primary_complete:
                            return {
                                "success":True,"new_content_count":1,"pending":True,"pending_secondary":True,
                                "route_key":route_key,"failure_kind":"group_share_pending",
                                "content_id":content_id,"story_id":content_id,
                                "primary_completed_this_run":primary_completed_this_run,
                                "secondary_error":str(exc),
                            }
                        raise

        group_complete=bool(pending.get("group_done"))
        if fb_complete and tt_complete and group_complete:
            sid=content_id;summary=pending.get("group_summary")
            try:
                sp=Path(str(result.get('story_json') or '')).resolve().parent/'tt_master_completed.json'
                sp.write_text(
                    json.dumps({
                        'completed':True,'route_key':route_key,'content_id':sid,
                        'primary_complete':True,'completed_at':time.time(),
                        'group_summary':pending.get('group_summary'),
                        'secondary_skipped_reason':pending.get('secondary_skipped_reason',''),
                    },ensure_ascii=False,indent=2),encoding='utf-8'
                )
            except Exception: pass
            self._save_pending(None)
            # Always report the stable content token. TTDailyRunService counts this
            # story exactly once even when FB/TT succeeded in an earlier retry and
            # this invocation only completed the final group-share step.
            return {
                "success": True,
                "new_content_count": 1,
                "content_id": sid,
                "story_id": sid,
                "route_key": route_key,
                "group_share": summary if want_group else "not_configured",
                "primary_completed_this_run": primary_completed_this_run,
                "completed_pending_secondary": not bool(primary_completed_this_run),
            }
        return {"success":False,"new_content_count":0,"pending":True,"route_key":route_key,"failure_kind":"pending_destination_retry"}
