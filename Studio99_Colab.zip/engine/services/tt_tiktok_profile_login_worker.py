from __future__ import annotations

import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.tt_service import init_tiktok_profile


def main() -> int:
    profile = str(sys.argv[1] if len(sys.argv) > 1 else "").strip()
    if not profile:
        print("TikTok profile name missing")
        return 2
    try:
        asyncio.run(init_tiktok_profile(profile, login_wait_seconds=900))
        return 0
    except Exception as exc:
        # Manually closing the Chromium window after login may interrupt the wait.
        # Persistent profile data is already saved, so keep this non-fatal.
        print(f"TikTok profile login worker ended: {exc}")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
