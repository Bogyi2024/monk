from __future__ import annotations

import asyncio
import json
import os
import re
import socket
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Optional

from playwright.async_api import BrowserContext, Page, async_playwright

from services.platform_caption_service import normalize_platform_caption_hashtags

try:
    from services.page_recovery import recover_blank_page, recover_page_ladder
except Exception:
    recover_blank_page = None
    recover_page_ladder = None

# Reuse the proven TikTok session/caption/post-confirmation helpers from Recap.
from services.tt_service import (
    _debug_tiktok_page,
    _fill_caption,
    _find_post_button,
    _grant_tiktok_local_network_permission,
    _normalize_tiktok_caption_payload,
    _profile_path,
    _proxy_config,
    _wait_for_real_post_confirmation,
)


DEFAULT_FB_PROFILE = "Main_FB_Account"
DEFAULT_FB_PAGE_ID = ""
DEFAULT_TT_PROFILE = "TikTok_SoulStar"


def _project_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _fb_proxy_config():
    """Chromium uses the OS network / external VPN; no local proxy is required."""
    return None


def _clean_fb_story_post_permalink(url: str) -> str:
    raw=str(url or "").strip()
    if not raw:
        return ""
    if raw.startswith("/"):
        raw="https://www.facebook.com"+raw
    raw=raw.replace("https://m.facebook.com/","https://www.facebook.com/")
    raw=raw.replace("https://facebook.com/","https://www.facebook.com/")
    # Strip notification/tracking query args but preserve story_fbid/id style permalinks.
    if "/posts/" in raw:
        raw=raw.split("?",1)[0]
    elif "story_fbid=" in raw or "permalink.php" in raw:
        # keep only identity-bearing args
        try:
            from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit
            parts=urlsplit(raw)
            keep=[(k,v) for k,v in parse_qsl(parts.query, keep_blank_values=True) if k in {"story_fbid","id"}]
            raw=urlunsplit((parts.scheme or "https",parts.netloc or "www.facebook.com",parts.path,urlencode(keep),""))
        except Exception:
            pass
    cf=raw.casefold()
    if not ("facebook.com" in cf and ("/posts/" in cf or "story_fbid=" in cf or "permalink.php" in cf or "pfbid" in cf)):
        return ""
    if "/groups/" in cf:
        return ""
    return raw


def _score_fb_confirmation_link(text: str, href: str) -> int:
    t=(text or "").strip().casefold(); h=(href or "").casefold(); score=0
    if any(x in t for x in ("view post","see post","view your post","go to post","see your post")):
        score += 300
    if "/posts/" in h or "story_fbid=" in h or "permalink.php" in h or "pfbid" in h:
        score += 180
    if "business.facebook.com" in h:
        score += 15
    if any(x in h for x in ("notif_id=","ref=notif","comment_id=")):
        score -= 40
    return score


async def _capture_exact_fb_post_permalink_after_publish(page: Page, timeout_ms: int = 35_000) -> str:
    """Capture the exact just-published post from Meta's confirmation UI.

    This is intentionally primary over public-Page feed scraping.  The composer
    knows which post it just created; using its View/See Post link prevents both
    personal-account mixups and 'new post not indexed yet' races.
    """
    loop=asyncio.get_running_loop(); deadline=loop.time()+max(8.0,timeout_ms/1000.0)
    while loop.time()<deadline:
        candidates=[]
        try:
            here=_clean_fb_story_post_permalink(page.url)
            if here:
                candidates.append((250,"current-url",here))
        except Exception:
            pass
        selectors=[
            'a:has-text("View post")','a:has-text("View Post")',
            'a:has-text("See post")','a:has-text("See Post")',
            'a:has-text("View your post")','a:has-text("See your post")',
            'div[role="alert"] a[href]','div[role="status"] a[href]',
            'div[role="dialog"] a[href]','a[href]',
        ]
        seen=set()
        for sel in selectors:
            try:
                loc=page.locator(sel); count=min(await loc.count(),120 if sel=='a[href]' else 20)
                for i in range(count):
                    a=loc.nth(i)
                    try:
                        href=str(await a.get_attribute('href') or '')
                        text=str(await a.inner_text() or '')
                    except Exception:
                        continue
                    key=(href,text)
                    if key in seen: continue
                    seen.add(key)
                    direct=_clean_fb_story_post_permalink(href)
                    score=_score_fb_confirmation_link(text,href)
                    if direct and score>0:
                        candidates.append((score,text,direct))
                    elif score>=300 and href:
                        # Some Meta confirmation links are redirect/tracking URLs. Follow
                        # only explicit View/See Post links in a disposable tab.
                        try:
                            probe=await page.context.new_page()
                            try:
                                await probe.goto(href,wait_until='domcontentloaded',timeout=45_000)
                                await probe.wait_for_timeout(900)
                                final=_clean_fb_story_post_permalink(probe.url)
                                if final: candidates.append((score+20,text,final))
                            finally:
                                try: await probe.close()
                                except Exception: pass
                        except Exception:
                            pass
            except Exception:
                continue
        if candidates:
            candidates.sort(key=lambda x:x[0],reverse=True)
            best=candidates[0]
            print(f"🔒 Facebook publish confirmation captured exact post permalink → {best[2]}")
            return best[2]
        await page.wait_for_timeout(1200)
    print("⚠️ Facebook publish confirmation had no direct View/See Post permalink; secondary recovery will be used")
    return ""


def _validate_images(paths: Iterable[str | Path]) -> list[Path]:
    out: list[Path] = []
    for raw in paths:
        p = Path(raw)
        if not p.is_absolute():
            p = (_project_root() / p).resolve()
        else:
            p = p.resolve()
        if not p.exists() or not p.is_file() or p.stat().st_size < 5_000:
            raise FileNotFoundError(f"Story image missing/broken: {p}")
        out.append(p)
    if not out:
        raise ValueError("No Story Carousel images supplied")
    return out


async def _debug_fb_page(page: Page, label: str) -> None:
    try:
        debug_dir = _project_root() / "downloads" / "story_carousel_debug"
        debug_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        png = debug_dir / f"fb_{label}_{stamp}.png"
        html = debug_dir / f"fb_{label}_{stamp}.html"
        await page.screenshot(path=str(png), full_page=True)
        html.write_text(await page.content(), encoding="utf-8")
        print(f"🧪 FB debug screenshot: {png}")
        print(f"🧪 FB debug HTML: {html}")
    except Exception as exc:
        print(f"⚠️ FB debug capture failed: {exc}")


async def _visible(locator) -> bool:
    try:
        return await locator.count() > 0 and await locator.first.is_visible()
    except Exception:
        return False


async def _fill_fb_caption(page: Page, caption: str) -> None:
    candidates = [
        'div[contenteditable="true"][role="textbox"]',
        'div[contenteditable="true"][aria-label*="post" i]',
        'div[contenteditable="true"][aria-label*="caption" i]',
        'div[contenteditable="true"]',
        'textarea[placeholder*="post" i]',
        'textarea[placeholder*="caption" i]',
    ]
    last_exc: Optional[Exception] = None
    for selector in candidates:
        loc = page.locator(selector)
        try:
            count = await loc.count()
        except Exception as exc:
            last_exc = exc
            continue
        for i in range(min(count, 8)):
            editor = loc.nth(i)
            try:
                if not await editor.is_visible():
                    continue
                tag = (await editor.evaluate("el => el.tagName.toLowerCase()")) or ""
                if tag == "textarea":
                    await editor.fill(caption)
                else:
                    await editor.click()
                    await editor.press("Control+A")
                    await editor.fill(caption)
                print("✅ Facebook caption filled")
                return
            except Exception as exc:
                last_exc = exc
    raise RuntimeError(f"Facebook post caption editor not found: {last_exc}")


async def _set_fb_photos(page: Page, image_paths: list[Path]) -> None:
    files = [str(p) for p in image_paths]

    # Prefer a real multi-image input. Meta frequently keeps it attached but hidden.
    inputs = page.locator('input[type="file"]')
    try:
        count = await inputs.count()
    except Exception:
        count = 0

    best = None
    for i in range(count):
        inp = inputs.nth(i)
        try:
            accept = (await inp.get_attribute("accept") or "").lower()
            multiple = await inp.get_attribute("multiple")
            if "image" in accept and multiple is not None:
                best = inp
                break
            if best is None and "image" in accept:
                best = inp
        except Exception:
            continue

    if best is not None:
        try:
            await best.set_input_files(files)
            print(f"✅ Facebook {len(files)} photos selected via file input")
            return
        except Exception:
            pass

    button_candidates = [
        page.get_by_text("Add photo", exact=False),
        page.get_by_text("Add photos", exact=False),
        page.get_by_text("Photo/video", exact=False),
        page.get_by_text("Photos/videos", exact=False),
        page.get_by_text("Add media", exact=False),
    ]
    last_exc: Optional[Exception] = None
    for candidate in button_candidates:
        try:
            if await candidate.count() == 0 or not await candidate.first.is_visible():
                continue
            async with page.expect_file_chooser(timeout=45_000) as fc_info:
                await candidate.first.click(timeout=30_000)
            chooser = await fc_info.value
            await chooser.set_files(files)
            print(f"✅ Facebook {len(files)} photos selected via file chooser")
            return
        except Exception as exc:
            last_exc = exc

    raise RuntimeError(f"Facebook multi-photo selector not found: {last_exc}")


async def _fb_visible_photo_sources(page: Page) -> set[str]:
    """Identify rendered photo previews, excluding tiny page icons and avatars."""
    return set(await page.evaluate("""() => Array.from(document.querySelectorAll('img'))
      .filter(img => {
        const rect = img.getBoundingClientRect();
        return rect.width >= 80 && rect.height >= 80 &&
          img.naturalWidth >= 100 && img.naturalHeight >= 100 &&
          getComputedStyle(img).visibility !== 'hidden';
      })
      .map(img => img.currentSrc || img.src).filter(Boolean)"""))


async def _wait_fb_photo_preview(page: Page, before: set[str], timeout_ms: int = 90_000) -> None:
    """Do not publish a caption-only post when Meta drops the selected photos."""
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout_ms / 1000.0
    while loop.time() < deadline:
        try:
            added = await _fb_visible_photo_sources(page) - before
            if added:
                print(f"✅ Facebook photo preview visible before Publish: {len(added)} new image(s)")
                return
        except Exception:
            pass
        await page.wait_for_timeout(2000)
    await _debug_fb_page(page, "photo_preview_missing")
    raise RuntimeError("Facebook photo preview missing after file selection; Publish was not clicked")


async def _find_enabled_fb_publish(page: Page, timeout_ms: int = 180_000):
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout_ms / 1000.0
    stable = 0
    last_log = -1
    while loop.time() < deadline:
        elapsed = int(timeout_ms / 1000 - max(0, deadline - loop.time()))
        if elapsed // 15 != last_log:
            print(f"⏳ Facebook photos processing / Publish readiness... {elapsed}s")
            last_log = elapsed // 15

        candidates = [
            page.get_by_role("button", name="Publish", exact=True),
            page.get_by_role("button", name="Post", exact=True),
            page.locator('button:has-text("Publish")'),
        ]
        found = None
        for candidate in candidates:
            try:
                if await candidate.count() == 0:
                    continue
                btn = candidate.last
                if not await btn.is_visible():
                    continue
                aria = await btn.get_attribute("aria-disabled")
                disabled = await btn.get_attribute("disabled")
                if await btn.is_enabled() and aria != "true" and disabled is None:
                    found = btn
                    break
            except Exception:
                continue
        if found is not None:
            stable += 1
            if stable >= 2:
                return found
        else:
            stable = 0
        await page.wait_for_timeout(2000)
    raise TimeoutError("Facebook Publish button did not become ready")


async def _wait_fb_publish_confirmation(page: Page, timeout_ms: int = 120_000) -> bool:
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout_ms / 1000.0
    success_patterns = [
        "post published",
        "published successfully",
        "your post was published",
        "your post is published",
        "post is published",
    ]
    while loop.time() < deadline:
        try:
            body = (await page.locator("body").inner_text()).lower()
            if any(pat in body for pat in success_patterns):
                return True
            # Meta often returns to content/home after a successful composer publish.
            if "latest/composer" not in page.url.lower():
                await page.wait_for_timeout(3000)
                return True
        except Exception:
            pass
        await page.wait_for_timeout(2000)
    return False


async def _upload_facebook_story_carousel_once(
    image_paths: Iterable[str | Path],
    caption: str,
    *,
    profile_name: str = DEFAULT_FB_PROFILE,
    page_id: str = DEFAULT_FB_PAGE_ID,
    headless: bool = False,
    return_detail: bool = False,
    capture_permalink: bool = True,
):
    caption = normalize_platform_caption_hashtags(caption, "facebook", limit=5)
    images = _validate_images(image_paths)
    user_data_dir = _project_root() / "browser_sessions" / profile_name
    user_data_dir.mkdir(parents=True, exist_ok=True)
    upload_url = f"https://business.facebook.com/latest/composer?asset_id={page_id}"

    print(f"\n📘 Facebook Story Carousel upload → {len(images)} photos | Page={page_id}")
    context: Optional[BrowserContext] = None
    publish_clicked = False
    stage = "launch"
    async with async_playwright() as p:
        try:
            context = await p.chromium.launch_persistent_context(
                user_data_dir=str(user_data_dir),
                headless=headless,
                args=["--disable-notifications", "--disable-blink-features=AutomationControlled"],
                proxy=_fb_proxy_config(),
            )
            page = context.pages[0] if context.pages else await context.new_page()
            await page.goto(upload_url, timeout=120_000, wait_until="domcontentloaded")
            if recover_page_ladder is not None:
                page, ok = await recover_page_ladder(
                    context,
                    page,
                    target_url=upload_url,
                    label="FB Story Carousel Composer",
                    settle_ms=5000,
                    max_reloads=1,
                    max_tab_reopens=0,
                    navigation_timeout_ms=120000,
                    expected_texts=("Create post", "Add photos", "Photo/video", "Post"),
                    expected_wait_ms=25000,
                )
                if not ok:
                    raise RuntimeError("Facebook carousel composer recovery failed before upload")
            elif recover_blank_page is not None:
                ok = await recover_blank_page(
                    page,
                    target_url=upload_url,
                    label="FB Story Carousel Composer",
                    settle_ms=6000,
                    max_reloads=2,
                    navigation_timeout_ms=120000,
                )
                if not ok:
                    raise RuntimeError("Facebook composer blank-page recovery failed")
            stage = "composer_ready"
            await page.wait_for_timeout(4000)

            if "login" in page.url.lower():
                raise RuntimeError(f"Facebook profile '{profile_name}' login expired")

            await _fill_fb_caption(page, caption)
            stage = "caption_filled"
            photo_sources_before = await _fb_visible_photo_sources(page)
            await _set_fb_photos(page, images)
            stage = "photos_selected"
            await _wait_fb_photo_preview(page, photo_sources_before)
            stage = "photos_previewed"

            publish_btn = await _find_enabled_fb_publish(page, timeout_ms=180_000)
            print("🚀 Facebook Publish click")
            await publish_btn.click(timeout=30_000)
            publish_clicked = True
            stage = "publish_clicked"

            confirmed = await _wait_fb_publish_confirmation(page, timeout_ms=120_000)
            if not confirmed:
                await _debug_fb_page(page, "publish_confirmation_timeout")
                raise TimeoutError("Facebook Publish clicked but confirmation was not detected")

            if capture_permalink:
                post_link = await _capture_exact_fb_post_permalink_after_publish(page, timeout_ms=35_000)
            else:
                post_link = ""
                print("⏭️ Facebook post permalink search skipped — this route has no group share")
            print("🎉 Facebook Story Carousel published")
            if return_detail:
                return {"success": True, "post_link": post_link}
            return True
        except Exception as exc:
            print(f"❌ Facebook Story Carousel upload failed: {exc}")
            if context is not None:
                try:
                    page = context.pages[-1]
                    await _debug_fb_page(page, "upload_failed")
                except Exception:
                    pass
            safe_retry = not publish_clicked and (
                "target page, context or browser has been closed" in str(exc).lower()
                or "composer recovery failed" in str(exc).lower()
                or "blank-page recovery failed" in str(exc).lower()
                or "photo preview missing" in str(exc).lower()
            )
            if return_detail:
                return {
                    "success": False,
                    "post_link": "",
                    "safe_context_retry": safe_retry,
                    "failure_stage": stage,
                    "error": str(exc),
                }
            return False
        finally:
            if context is not None:
                try:
                    await context.close()
                except Exception:
                    pass


async def upload_facebook_story_carousel(
    image_paths: Iterable[str | Path],
    caption: str,
    *,
    profile_name: str = DEFAULT_FB_PROFILE,
    page_id: str = DEFAULT_FB_PAGE_ID,
    headless: bool = False,
    return_detail: bool = False,
    capture_permalink: bool = True,
):
    """Publish a photo carousel with one safe clean-context retry.

    This uploader is separate from the Reel uploader. A retry is allowed only
    before Publish is clicked, so a lost confirmation can never create a duplicate
    Facebook post.
    """
    result: dict[str, Any] = {"success": False, "post_link": ""}
    for attempt in range(1, 3):
        result = await _upload_facebook_story_carousel_once(
            image_paths,
            caption,
            profile_name=profile_name,
            page_id=page_id,
            headless=headless,
            return_detail=True,
            capture_permalink=capture_permalink,
        )
        if result.get("success") or not result.get("safe_context_retry"):
            break
        if attempt >= 2:
            break
        print(
            "🧯 Facebook Story Carousel browser closed before Publish — "
            "clean CONTEXT restart 1/1 after 3s..."
        )
        await asyncio.sleep(3.0)

    if return_detail:
        return result
    return bool(result.get("success"))


async def _click_tiktok_photo_mode(page: Page) -> None:
    # TikTok Studio can change this from tabs to buttons; try several visible labels.
    labels = ["Photo", "Photos", "Image", "Images", "Photo post", "Upload photo", "Upload photos"]
    for label in labels:
        candidates = [
            page.get_by_role("tab", name=label, exact=False),
            page.get_by_role("button", name=label, exact=False),
            page.get_by_text(label, exact=True),
        ]
        for candidate in candidates:
            try:
                if await candidate.count() and await candidate.first.is_visible():
                    await candidate.first.click(timeout=12_000)
                    await page.wait_for_timeout(1800)
                    print(f"🖼️ TikTok photo mode selected: {label}")
                    return
            except Exception:
                continue


async def _set_tiktok_photos(page: Page, image_paths: list[Path], timeout_ms: int) -> None:
    files = [str(p) for p in image_paths]
    await _click_tiktok_photo_mode(page)

    # Prefer inputs explicitly accepting images or a multi-file input.
    deadline = asyncio.get_running_loop().time() + 30.0
    while asyncio.get_running_loop().time() < deadline:
        inputs = page.locator('input[type="file"]')
        try:
            count = await inputs.count()
        except Exception:
            count = 0
        fallback = None
        for i in range(count):
            inp = inputs.nth(i)
            try:
                accept = (await inp.get_attribute("accept") or "").lower()
                multiple = await inp.get_attribute("multiple")
                if "image" in accept and multiple is not None:
                    await inp.set_input_files(files)
                    print(f"✅ TikTok {len(files)} photos selected")
                    return
                if "image" in accept and fallback is None:
                    fallback = inp
                if multiple is not None and "video" not in accept and fallback is None:
                    fallback = inp
            except Exception:
                continue
        if fallback is not None:
            try:
                await fallback.set_input_files(files)
                print(f"✅ TikTok {len(files)} photos selected")
                return
            except Exception:
                pass
        await page.wait_for_timeout(1500)

    button_labels = ["Select photos", "Upload photos", "Select images", "Upload images", "Upload"]
    last_exc: Optional[Exception] = None
    for label in button_labels:
        for candidate in [page.get_by_role("button", name=label, exact=False), page.get_by_text(label, exact=False)]:
            try:
                if await candidate.count() == 0 or not await candidate.first.is_visible():
                    continue
                async with page.expect_file_chooser(timeout=timeout_ms) as chooser_info:
                    await candidate.first.click(timeout=20_000)
                chooser = await chooser_info.value
                await chooser.set_files(files)
                print(f"✅ TikTok {len(files)} photos selected via chooser")
                return
            except Exception as exc:
                last_exc = exc

    await _debug_tiktok_page(page, "photo_selector_not_found")
    raise RuntimeError(f"TikTok photo file selector not found: {last_exc}")


async def _wait_tiktok_photo_post_ready(page: Page, timeout_ms: int = 180_000):
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout_ms / 1000.0
    stable = 0
    last_bucket = -1
    while loop.time() < deadline:
        elapsed = int(timeout_ms / 1000 - max(0, deadline - loop.time()))
        if elapsed // 15 != last_bucket:
            print(f"⏳ TikTok photo processing / Post readiness... {elapsed}s")
            last_bucket = elapsed // 15
        try:
            btn = await _find_post_button(page)
            aria = await btn.get_attribute("aria-disabled")
            disabled = await btn.get_attribute("disabled")
            ready = await btn.is_visible() and await btn.is_enabled() and aria != "true" and disabled is None
        except Exception:
            ready = False
            btn = None
        if ready:
            stable += 1
            if stable >= 3:
                return btn
        else:
            stable = 0
        await page.wait_for_timeout(2000)
    await _debug_tiktok_page(page, "photo_post_not_ready")
    raise TimeoutError("TikTok photo Post button did not become ready")


async def _upload_tiktok_story_photos_once(
    images: list[Path],
    caption: str,
    *,
    profile_name: str = DEFAULT_TT_PROFILE,
    headless: bool = False,
    proxy: Optional[str] = None,
    timeout_ms: int = 240_000,
) -> dict[str, Any]:
    profile_path = _profile_path(profile_name)

    cleanup_fingerprints = None
    try:
        from services.tiktok_draft_cleanup import fingerprint
        cleanup_fingerprints = await asyncio.to_thread(lambda: [fingerprint(path) for path in images])
    except Exception as exc:
        print(f"⚠️ TikTok photo draft fingerprint unavailable; draft will be retained: {exc}")

    context: Optional[BrowserContext] = None
    publish_clicked = False
    stage = "launch"
    async with async_playwright() as p:
        try:
            context = await p.chromium.launch_persistent_context(
                user_data_dir=str(profile_path),
                headless=headless,
                args=["--disable-notifications", "--disable-blink-features=AutomationControlled"],
                proxy=_proxy_config(proxy),
            )
            await _grant_tiktok_local_network_permission(context)
            page = context.pages[0] if context.pages else await context.new_page()
            upload_url = "https://www.tiktok.com/tiktokstudio/upload"
            await page.goto(upload_url, timeout=120_000, wait_until="domcontentloaded")
            stage = "initial_navigation"

            if recover_page_ladder is not None:
                page, healthy = await recover_page_ladder(
                    context,
                    page,
                    target_url=upload_url,
                    label="TikTok Story Photo Uploader",
                    settle_ms=2500,
                    max_reloads=2,
                    max_tab_reopens=1,
                    new_tab_max_reloads=1,
                    navigation_timeout_ms=120_000,
                    expected_selectors=('input[type="file"][accept*="image" i]',),
                    expected_attached_selectors=('input[type="file"]',),
                    expected_texts=("Photo", "Photos", "Select photos", "Upload"),
                    expected_wait_ms=20_000,
                )
                if not healthy:
                    raise RuntimeError("TikTok photo uploader recovery failed before file selection")

                # The ladder returns the healthy replacement tab. Remove stale
                # black/hung tabs before any stateful upload interaction begins.
                for stale_page in list(context.pages):
                    if stale_page is page:
                        continue
                    try:
                        await stale_page.close()
                    except Exception:
                        pass
            elif recover_blank_page is not None:
                healthy = await recover_blank_page(
                    page,
                    target_url=upload_url,
                    label="TikTok Story Photo Uploader",
                    settle_ms=3000,
                    max_reloads=2,
                    navigation_timeout_ms=120_000,
                    expected_attached_selectors=('input[type="file"]',),
                    expected_texts=("Photo", "Photos", "Select photos", "Upload"),
                    expected_wait_ms=20_000,
                )
                if not healthy:
                    raise RuntimeError("TikTok photo uploader blank-page recovery failed")

            stage = "uploader_ready"
            await page.wait_for_timeout(1500)

            if "login" in page.url.lower() or await page.locator('input[name="username"]').count() > 0:
                raise RuntimeError(f"TikTok profile '{profile_name}' login expired")

            await _set_tiktok_photos(page, images, timeout_ms)
            stage = "photos_selected"
            await page.wait_for_timeout(5000)

            cleaned_caption = _normalize_tiktok_caption_payload(caption)
            await _fill_caption(page, cleaned_caption)
            stage = "caption_filled"
            print("✅ TikTok photo caption filled")

            post_btn = await _wait_tiktok_photo_post_ready(page, timeout_ms=max(180_000, timeout_ms))
            print("🔎 TikTok photo caption final verify")
            await _fill_caption(page, cleaned_caption)
            post_btn = await _wait_tiktok_photo_post_ready(page, timeout_ms=120_000)

            before_url = page.url
            print("🚀 TikTok Photo Post click")
            await post_btn.click(timeout=30_000)
            publish_clicked = True
            stage = "post_clicked"
            explicit_post_success = await _wait_for_real_post_confirmation(
                page,
                before_url=before_url,
                timeout_ms=max(180_000, timeout_ms),
            )
            await page.wait_for_timeout(8000)
            print("🎉 TikTok Story photo post published")
            if cleanup_fingerprints and explicit_post_success is True:
                try:
                    from services.tiktok_draft_cleanup import record_photo_success, cleanup_page
                    record_photo_success(profile_name, images, cleanup_fingerprints)
                    cleanup_result = await cleanup_page(page, profile_name)
                    print(f"🧹 TikTok confirmed-photo draft cleanup: records={cleanup_result['deleted_records']}")
                except Exception as exc:
                    print(f"⚠️ TikTok confirmed-photo draft cleanup deferred: {exc}")
            return {"success": True, "safe_context_retry": False, "failure_stage": "confirmed"}
        except Exception as exc:
            print(f"❌ TikTok Story photo upload failed: {exc}")
            if context is not None:
                try:
                    await _debug_tiktok_page(context.pages[-1], "story_photo_upload_failed")
                except Exception:
                    pass
            login_lost = "login expired" in str(exc).casefold()
            return {
                "success": False,
                "safe_context_retry": bool(not publish_clicked and not login_lost),
                "failure_stage": stage,
                "error": str(exc),
            }
        finally:
            if context is not None:
                try:
                    await context.close()
                except Exception:
                    pass


async def upload_tiktok_story_photos(
    image_paths: Iterable[str | Path],
    caption: str,
    *,
    profile_name: str = DEFAULT_TT_PROFILE,
    headless: bool = False,
    proxy: Optional[str] = None,
    timeout_ms: int = 240_000,
) -> bool:
    """Upload photos with pre-Post reload/new-tab/context-restart recovery."""
    images = _validate_images(image_paths)
    print(f"\n🎵 TikTok Story photo upload → {len(images)} photos | profile={profile_name}")

    result: dict[str, Any] = {"success": False, "safe_context_retry": False}
    for attempt in range(1, 3):
        result = await _upload_tiktok_story_photos_once(
            images,
            caption,
            profile_name=profile_name,
            headless=headless,
            proxy=proxy,
            timeout_ms=timeout_ms,
        )
        if result.get("success") or not result.get("safe_context_retry") or attempt >= 2:
            break
        print(
            "🧯 TikTok Story Photo Uploader မကောင်းသေးပါ — "
            "clean CONTEXT restart 1/1 after 3s..."
        )
        await asyncio.sleep(3.0)

    return bool(result.get("success"))


def _join_caption(base: str, hashtags: Iterable[str]) -> str:
    base = (base or "").strip()
    tags: list[str] = []
    seen: set[str] = set()
    for raw in hashtags or []:
        tag = str(raw or "").strip()
        if not tag:
            continue
        if not tag.startswith("#"):
            tag = "#" + tag
        key = tag.casefold()
        if key not in seen:
            seen.add(key)
            tags.append(tag)
    if base and tags:
        return base + "\n\n" + " ".join(tags)
    return base or " ".join(tags)


async def upload_story_result(
    result: dict[str, Any],
    *,
    upload_fb: bool = True,
    upload_tt: bool = True,
    fb_profile: str = DEFAULT_FB_PROFILE,
    fb_page_id: str = DEFAULT_FB_PAGE_ID,
    tt_profile: str = DEFAULT_TT_PROFILE,
    capture_fb_permalink: bool = True,
) -> dict[str, Any]:
    images = result.get("square_images") or []
    images = [str(p) for p in _validate_images(images)]
    hashtags = result.get("hashtags") or []

    fb_caption = _join_caption(str(result.get("fb_caption") or result.get("title") or ""), hashtags)
    tt_caption = _join_caption(str(result.get("tt_caption") or result.get("title") or ""), hashtags)

    summary: dict[str, Any] = {
        "story_id": result.get("story_id", ""),
        "title": result.get("title", ""),
        "facebook": None,
        "tiktok": None,
    }

    if upload_fb:
        fb_detail = await upload_facebook_story_carousel(
            images,
            fb_caption,
            profile_name=fb_profile,
            page_id=fb_page_id,
            headless=False,
            return_detail=True,
            capture_permalink=capture_fb_permalink,
        )
        summary["facebook"] = bool((fb_detail or {}).get("success"))
        summary["facebook_post_link"] = str((fb_detail or {}).get("post_link") or "")
    if upload_tt:
        summary["tiktok"] = await upload_tiktok_story_photos(
            images,
            tt_caption,
            profile_name=tt_profile,
            headless=False,
        )

    return summary
