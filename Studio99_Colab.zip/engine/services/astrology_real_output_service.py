from __future__ import annotations

import asyncio
import base64
import html
import json
import os
import random
import re
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageEnhance
from playwright.async_api import async_playwright

from services.ai_service import AIService
from services.story_carousel_service import StoryCarouselService

try:
    from google.genai import types as genai_types
except Exception:
    genai_types = None

WEEKDAY_BORN_MM = {
    0: "တနင်္လာသားသမီးများ",
    1: "အင်္ဂါသားသမီးများ",
    2: "ဗုဒ္ဓဟူးသားသမီးများ",
    3: "ကြာသပတေးသားသမီးများ",
    4: "သောကြာသားသမီးများ",
    5: "စနေသားသမီးများ",
    6: "တနင်္ဂနွေသားသမီးများ",
}
WEEKDAY_DAY_MM = {
    0: "တနင်္လာနေ့", 1: "အင်္ဂါနေ့", 2: "ဗုဒ္ဓဟူးနေ့", 3: "ကြာသပတေးနေ့",
    4: "သောကြာနေ့", 5: "စနေနေ့", 6: "တနင်္ဂနွေနေ့",
}
MONTH_MM = {
    1:"ဇန်နဝါရီ",2:"ဖေဖော်ဝါရီ",3:"မတ်",4:"ဧပြီ",5:"မေ",6:"ဇွန်",
    7:"ဇူလိုင်",8:"ဩဂုတ်",9:"စက်တင်ဘာ",10:"အောက်တိုဘာ",11:"နိုဝင်ဘာ",12:"ဒီဇင်ဘာ",
}
# Image Picker used to call random.choice() on only five themes. That made an
# identical 2x2 subject set recur every few days even though the generated pixels
# were slightly different. Keep a much wider, deliberately distinct catalogue and
# rotate by calendar date so every theme is used once before the cycle repeats.
THEMES = [
    {"id":"moon_animals", "prompt":"moon rabbit, tiny red fox, sleepy silver cat, baby snow owl"},
    {"id":"lucky_symbols", "prompt":"blue butterfly, pink lotus, silver crescent moon, crystal wish tree"},
    {"id":"magic_objects", "prompt":"glowing moon lamp, crystal flower, tiny celestial cottage, bottled starlight"},
    {"id":"dream_places", "prompt":"cloud swing, moon garden, glowing doorway, tiny mushroom house"},
    {"id":"celestial_friends", "prompt":"star bear, moon bunny, cloud kitten, tiny comet fox"},
    {"id":"precious_stones", "prompt":"golden sunstone, purple amethyst cluster, luminous pearl shell, polished green jade"},
    {"id":"graceful_birds", "prompt":"white crane, jeweled peacock, moonlit swan, blue kingfisher"},
    {"id":"ocean_guides", "prompt":"golden koi fish, wise sea turtle, pastel seahorse, joyful silver dolphin"},
    {"id":"spirit_flowers", "prompt":"cherry blossom branch, bright sunflower, lavender bouquet, white moon orchid"},
    {"id":"nature_paths", "prompt":"hidden waterfall, sunrise mountain path, misty forest bridge, glowing ocean horizon"},
    {"id":"destiny_tools", "prompt":"ornate golden key, antique compass, white blessing feather, crystal hourglass"},
    {"id":"wish_lanterns", "prompt":"lotus water lantern, floating sky lantern, crescent table lantern, firefly glass lantern"},
    {"id":"gentle_skies", "prompt":"rainbow cloud, rosy sunrise, starry night cloud, silver rain cloud"},
    {"id":"woodland_friends", "prompt":"gentle deer, red squirrel, tiny hedgehog, masked raccoon"},
    {"id":"quiet_treasures", "prompt":"celestial tea cup, ancient story book, moon hand mirror, tiny music box"},
    {"id":"blessing_rituals", "prompt":"gold temple bell, sandalwood prayer beads, white candle, fragrant incense burner"},
    {"id":"four_seasons", "prompt":"spring blossom tree, summer meadow, autumn maple, peaceful snowy pine"},
    {"id":"deep_space", "prompt":"ringed planet, spiral galaxy, sparkling meteor, blue nebula"},
    {"id":"magic_portals", "prompt":"forest arch portal, round moon gate, crystal cave entrance, doorway in the clouds"},
    {"id":"crystal_forms", "prompt":"rose quartz heart, blue crystal pyramid, rainbow crystal sphere, clear crystal tower"},
    {"id":"floating_worlds", "prompt":"floating flower island, tiny castle island, waterfall island, moon observatory island"},
    {"id":"lucky_charms", "prompt":"four-leaf clover charm, golden horseshoe, red wish knot, small guardian bell"},
    {"id":"fantasy_insects", "prompt":"luminous dragonfly, jeweled moth, golden ladybird, firefly in a flower"},
    {"id":"abundance_fruits", "prompt":"ruby pomegranate, golden orange, crystal grapes, moonlit pear"},
    {"id":"sacred_trees", "prompt":"banyan tree, cherry blossom tree, golden ginkgo tree, moonlit willow tree"},
    {"id":"guiding_lights", "prompt":"north star, lighthouse beam, glowing trail marker, sunrise over a calm road"},
    {"id":"royal_tokens", "prompt":"delicate silver crown, jeweled brooch, moonstone ring, golden ceremonial fan"},
    {"id":"peaceful_waters", "prompt":"lotus pond, forest stream, moonlit lake, sparkling healing spring"},
]
CONTENT_VERSION = "v1.0.4"


def read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default
    except Exception:
        return default


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_json(raw: str) -> dict[str, Any]:
    text = str(raw or "").strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except Exception:
        a, b = text.find("{"), text.rfind("}")
        if a >= 0 and b > a:
            return json.loads(text[a:b+1])
        raise


def mm_digits(value: Any) -> str:
    return str(value).translate(str.maketrans("0123456789", "၀၁၂၃၄၅၆၇၈၉"))


def mm_date_label(when: datetime) -> str:
    return f"{mm_digits(when.year)} ခုနှစ်၊ {MONTH_MM[when.month]}လ {mm_digits(when.day)} ရက် • {WEEKDAY_DAY_MM[when.weekday()]}"


class AstrologyRealOutputService:
    def __init__(self, config_path: str = "config/astrology_real_output_test.json"):
        self.cfg = read_json(Path(config_path), {})
        self.ai = AIService()
        self.story = StoryCarouselService()
        self.ffmpeg = self._resolve_binary(r"C:\ffmpeg\bin\ffmpeg.exe", "ffmpeg")
        self.out_root = Path(self.cfg.get("output_root", "outputs/astrology_real_output_test"))

    @staticmethod
    def _resolve_binary(win: str, fallback: str) -> str:
        if os.name == "nt" and Path(win).exists():
            return win
        return shutil.which(fallback) or fallback

    def _run(self, cmd: list[str]) -> None:
        p = subprocess.run(cmd, text=True, capture_output=True, encoding="utf-8", errors="replace")
        if p.returncode:
            raise RuntimeError((p.stderr or p.stdout or "")[-6000:])

    @staticmethod
    def _theme_for_date(when: datetime) -> dict[str, str]:
        """Return a stable no-repeat theme for a calendar date."""
        return dict(THEMES[when.date().toordinal() % len(THEMES)])

    def _select_image_pick_theme(self, when: datetime, pick_dir: Path) -> dict[str, str]:
        """Persist the selected theme so same-day resume never changes a paid asset."""
        checkpoint=pick_dir/"theme.json"
        date_key=when.strftime("%Y-%m-%d")
        saved=read_json(checkpoint,{})
        valid_ids={item["id"] for item in THEMES}
        if (isinstance(saved,dict) and saved.get("date")==date_key
                and saved.get("id") in valid_ids and saved.get("prompt")):
            print(f"♻️ Astrology image-pick theme resume → {saved['id']}")
            return saved

        # An incomplete/older run may already contain a paid grid but predate the
        # theme checkpoint. Preserve that asset instead of paying to regenerate it.
        grid=pick_dir/"grid_raw.jpg"
        if grid.exists() and grid.stat().st_size > 10_000:
            legacy={
                "date":date_key,
                "id":"legacy_existing_grid",
                "prompt":"existing paid grid retained; original theme was not recorded",
            }
            write_json(checkpoint,legacy)
            print("♻️ Existing paid image-pick grid kept (legacy theme metadata unavailable)")
            return legacy

        chosen=self._theme_for_date(when)
        chosen.update({
            "date":date_key,
            "rotation_index":when.date().toordinal() % len(THEMES),
            "rotation_size":len(THEMES),
        })
        write_json(checkpoint,chosen)
        print(f"🎨 Astrology image-pick theme → {chosen['id']} ({chosen['rotation_index'] + 1}/{len(THEMES)})")
        return chosen

    async def _gemini_text(self, prompt: str) -> str:
        self.ai._enable_proxy()
        try:
            resp = await asyncio.to_thread(
                self.ai.generate_content,
                model=self.ai.text_model,
                contents=prompt,
            )
            return str(resp.text or "").strip()
        finally:
            self.ai._disable_proxy()

    async def _gemini_analyze_image(self, image_path: Path, prompt: str) -> str:
        if genai_types is None:
            raise RuntimeError("google.genai types unavailable")
        mime = "image/png" if image_path.suffix.lower() == ".png" else "image/jpeg"
        content = genai_types.Content(
            role="user",
            parts=[
                genai_types.Part.from_text(text=prompt),
                genai_types.Part.from_bytes(data=image_path.read_bytes(), mime_type=mime),
            ],
        )
        self.ai._enable_proxy()
        try:
            resp = await asyncio.to_thread(
                self.ai.generate_content,
                model=self.ai.text_model,
                contents=[content],
            )
            return str(resp.text or "").strip()
        finally:
            self.ai._disable_proxy()

    async def _fal_square(self, prompt: str, save_path: Path) -> Path:
        # Paid-asset safety: if a valid image already exists, never regenerate it.
        if save_path.exists() and save_path.stat().st_size > 10_000:
            try:
                with Image.open(save_path) as im:
                    im.verify()
                print(f"♻️ Astrology FAL resume — reuse existing image → {save_path}")
                return save_path
            except Exception:
                pass
        old_w = self.story.config.get("fal_width")
        old_h = self.story.config.get("fal_height")
        size = int(self.cfg.get("fal_size", 1024))
        self.story.config["fal_width"] = size
        self.story.config["fal_height"] = size
        try:
            full = (
                f"{prompt}. Square 1:1 composition, high quality polished digital illustration, "
                "no text, no letters, no numbers, no watermark, no logo."
            )
            return await asyncio.to_thread(self.story._generate_scene_image_fal, full, save_path)
        finally:
            if old_w is None: self.story.config.pop("fal_width", None)
            else: self.story.config["fal_width"] = old_w
            if old_h is None: self.story.config.pop("fal_height", None)
            else: self.story.config["fal_height"] = old_h

    async def _daily_content(self, born: str, date_label: str) -> dict[str, Any]:
        prompt = f"""
Return JSON only. Myanmar language only.
Create a clear DAILY horoscope specifically for {born}.
Exact date: {date_label}.

IDENTITY IS CRITICAL FOR DAILY HOROSCOPE ONLY:
- title MUST include the exact date and {born}.
- slide 1 MUST clearly say this is TODAY'S forecast for {born}.
- every DAILY visual will show date + {born}.

Exactly 6 slides:
1) today overview: mood, opportunity, caution
2) general life: people, plans, decision-making
3) love / relationship / family
4) work / business / money
5) lucky color, lucky numbers, helpful practical caution/direction
6) ယတြာ: one simple, culturally familiar, harmless daily remedy / good-luck practice for {born}

YADAYA RULES:
- headline must contain "ယတြာ".
- give one practical, gentle action people can actually do today (for example a small act of kindness, donation, mindful prayer/metta, a simple lucky-color habit, or another harmless traditional-style remedy).
- no dangerous acts, no medical claims, no guaranteed outcomes, no fear-based wording.
- keep it entertainment-friendly and respectful.

JSON schema:
{{
 "title":"...",
 "slides":[
   {{"headline":"ဒီနေ့ {born}အတွက်","body":"..."}},
   {{"headline":"အထွေထွေ","body":"..."}},
   {{"headline":"အချစ်ရေး / မိသားစု","body":"..."}},
   {{"headline":"အလုပ် / ငွေကြေး","body":"..."}},
   {{"headline":"ကံကောင်းခြင်း / သတိပြုရန်","body":"..."}},
   {{"headline":"ယနေ့အတွက် ယတြာ","body":"..."}}
 ],
 "fb_caption":"...",
 "tt_caption":"..."
}}

Writing style:
- slides 1-5 can stay concise and useful; do NOT pad them merely to make the video longer.
- slide 6 remedy should be complete enough to read naturally and add one useful extra scene.
- warm entertainment tone, no absolute certainty.
- fb_caption and tt_caption must explicitly state {date_label} and {born}.
No markdown.
"""
        data = parse_json(await self._gemini_text(prompt))
        slides = data.get("slides") or []
        if len(slides) != 6:
            raise RuntimeError(f"Daily horoscope Gemini returned {len(slides)} slides, expected 6 (including ယတြာ)")
        if "ယတြာ" not in str(slides[-1].get("headline") or ""):
            slides[-1]["headline"] = "ယနေ့အတွက် ယတြာ"
        return data

    async def _period_content(self, period: str, when: datetime) -> dict[str, Any]:
        period=str(period).strip().lower()
        if period not in {"weekly","monthly"}:
            raise ValueError(period)
        label="တစ်ပတ်စာဗေဒင်" if period=="weekly" else "လစဉ်ဗေဒင်"
        date_context=(
            f"{mm_digits(when.year)} ခုနှစ်၊ {MONTH_MM[when.month]}လ • {label}"
            if period=="monthly"
            else f"{mm_date_label(when)} မှစ၍ • {label}"
        )
        groups=[WEEKDAY_BORN_MM[i] for i in range(7)]
        schema_items=",\n   ".join('{"headline":"'+g+'","body":"..."}' for g in groups)
        prompt=f"""
Return JSON only. Myanmar language only.
Create one {label} entertainment horoscope covering ALL 7 weekday-born groups.
Context: {date_context}.

Exactly 8 slides:
1) cover / overview for the period
2-8) one slide each, in this exact order: {', '.join(groups)}

JSON schema:
{{
 "title":"...",
 "slides":[
   {{"headline":"{label}","body":"..."}},
   {schema_items}
 ],
 "fb_caption":"...",
 "tt_caption":"..."
}}

Rules:
- Warm, shareable Myanmar; entertainment tone, no absolute certainty.
- Each weekday-born slide should include opportunity + caution + one practical positive direction.
- Keep it readable; no markdown.
"""
        data=parse_json(await self._gemini_text(prompt))
        slides=data.get("slides") or []
        if len(slides)!=8:
            raise RuntimeError(f"{period} Astrology Gemini returned {len(slides)} slides, expected 8")
        data["context_line"]=date_context
        return data

    async def _render_period(self, root: Path, period: str, when: datetime) -> dict[str, Any]:
        period=str(period).strip().lower()
        out=root/period; (out/"fb_carousel").mkdir(parents=True,exist_ok=True)
        ckpt=out/f"{period}_content.json"
        data=read_json(ckpt,{})
        version=f"{CONTENT_VERSION}_{period}_1"
        if not (isinstance(data,dict) and len(data.get("slides") or [])==8 and data.get("_content_version")==version):
            data=await self._period_content(period,when)
            data["_content_version"]=version
            write_json(ckpt,data)
            print(f"💾 Astrology {period} text checkpoint → {ckpt}")
        else:
            print(f"♻️ Astrology {period} text resume → {ckpt}")
        label="weekly" if period=="weekly" else "monthly"
        bg=await self._fal_square(
            f"cute dreamy astrology illustration for a {label} horoscope, moon, stars, seven subtle lucky symbols, calm elegant magical atmosphere",
            out/f"{period}_background.jpg",
        )
        context=str(data.get("context_line") or "")
        durs=[self._duration(x.get("body", ""),cover=(i==0)) for i,x in enumerate(data["slides"])]
        durs=self._enforce_min_total(durs,float(self.cfg.get(period,{}).get("min_total_seconds",65.0)))
        clips=[]; txt=self.cfg.get("text",{})
        for i,(slide,dur) in enumerate(zip(data["slides"],durs),1):
            await self._fb_square_card(bg,out/"fb_carousel"/f"slide_{i:02d}.jpg",slide,context)
            bgv=out/f"motion_bg_{i:02d}.jpg"; ov=out/f"motion_text_{i:02d}.png"; clip=out/f"scene_{i:02d}.mp4"
            self._full_source_vertical(bg,bgv)
            await self._render_text_png(
                headline=slide.get("headline", ""), body=slide.get("body", ""), out=ov,
                title_px=int(txt.get("daily_title_px",52)), body_px=int(txt.get("daily_body_px",40)),
                y_top=int(txt.get("daily_text_y",1130)), context_line=context,
            )
            self._scene_clip(bgv,ov,dur,clip); clips.append(clip)
        motion=out/f"{period}_motion.mp4"
        self._concat_with_music(clips,motion)
        print(f"✅ Astrology {period} output ready → {motion} | {sum(durs):.1f}s")
        return {"content":data,"fb_carousel":str(out/"fb_carousel"),"motion":str(motion)}

    async def _pick_content_from_grid(self, grid_path: Path) -> dict[str, Any]:
        min_chars = int(self.cfg.get("image_pick", {}).get("interpretation_min_chars", 170))
        max_chars = int(self.cfg.get("image_pick", {}).get("interpretation_max_chars", 230))
        prompt = f"""
Look carefully at the attached 2x2 grid.
1=top-left, 2=top-right, 3=bottom-left, 4=bottom-right.

This is a TIMELESS pick-an-image entertainment post for EVERYONE.
Do NOT mention a date, weekday, birthday weekday group, horoscope day, or words like အင်္ဂါသားသမီး / တနင်္လာသားသမီး etc.
Do NOT use time-specific words such as ဒီနေ့ or ယနေ့.
The result must make sense no matter what day somebody watches it.

Write Myanmar-only light entertainment interpretations based on what is ACTUALLY visible in each quadrant.
Do not invent a different animal/object.

Return JSON only:
{{
 "prompt":"ပုံ ၄ ပုံထဲက စိတ်ထဲမှာ အကြိုက်ဆုံးတစ်ပုံကိုရွေးပါ",
 "items":[
   {{"no":1,"seen":"actual visible subject","headline":"...","body":"..."}},
   {{"no":2,"seen":"actual visible subject","headline":"...","body":"..."}},
   {{"no":3,"seen":"actual visible subject","headline":"...","body":"..."}},
   {{"no":4,"seen":"actual visible subject","headline":"...","body":"..."}}
 ],
 "cta":"သင်ရွေးတာ ဘယ်ပုံလဲ comment မှာပြောပါ",
 "caption":"..."
}}
Each body about {min_chars}-{max_chars} Myanmar characters. Warm, reflective and entertainment-friendly, not an absolute prediction. No markdown.
"""
        data = parse_json(await self._gemini_analyze_image(grid_path, prompt))
        if len(data.get("items") or []) != 4:
            raise RuntimeError("Image-pick Gemini must return exactly 4 items")
        # Defensive cleanup: image-pick is intentionally timeless and for everyone.
        forbidden = list(WEEKDAY_BORN_MM.values()) + list(WEEKDAY_DAY_MM.values())
        weekday_roots = "တနင်္လာ|အင်္ဂါ|ဗုဒ္ဓဟူး|ကြာသပတေး|သောကြာ|စနေ|တနင်္ဂနွေ"
        def clean(value: Any) -> str:
            t = str(value or "")
            for token in forbidden:
                t = t.replace(token, "")
            t = re.sub(rf"(?:{weekday_roots})\s*သားသမီး(?:များ|တွေ)?", "", t)
            t = t.replace("ဒီနေ့", "").replace("ယနေ့", "")
            t = re.sub(r"\s{2,}", " ", t).strip(" •၊,-")
            return t
        data["prompt"] = clean(data.get("prompt")) or "ပုံ ၄ ပုံထဲက စိတ်ထဲမှာ အကြိုက်ဆုံးတစ်ပုံကိုရွေးပါ"
        data["cta"] = clean(data.get("cta")) or "သင်ရွေးတာ ဘယ်ပုံလဲ comment မှာပြောပါ"
        data["caption"] = clean(data.get("caption"))
        for i, item in enumerate(data.get("items") or [], 1):
            item["headline"] = clean(item.get("headline")) or f"ပုံ {i} ကိုရွေးသူ"
            item["body"] = clean(item.get("body"))
        return data

    def _font_b64(self) -> str:
        try:
            p = self.story._find_story_font_file()
            if p and Path(p).exists():
                return base64.b64encode(Path(p).read_bytes()).decode("ascii")
        except Exception:
            pass
        return ""

    async def _render_text_png(
        self, *, headline: str, body: str, out: Path, title_px: int, body_px: int,
        y_top: int, context_line: str, canvas_h: int = 1920,
    ) -> None:
        w, h = 1080, int(canvas_h)
        b64 = self._font_b64()
        face = f"@font-face{{font-family:AstroMM;src:url(data:font/ttf;base64,{b64}) format('truetype');}}" if b64 else ""
        stroke = float(self.cfg.get("text", {}).get("stroke_px", 2.6))
        hh = html.escape(str(headline or ""), quote=True)
        bb = html.escape(str(body or ""), quote=True)
        cc = html.escape(str(context_line or ""), quote=True)
        ctx_px = int(self.cfg.get("text", {}).get("context_px", 34 if h > 1200 else 27))
        side = 62 if h > 1200 else 50
        bottom = 72 if h > 1200 else 44
        page_html = f'''<!doctype html><html><head><meta charset="utf-8"><style>
{face}
html,body{{margin:0;width:{w}px;height:{h}px;background:transparent;overflow:hidden}}
body{{font-family:AstroMM,'Myanmar Text','Pyidaungsu','Noto Sans Myanmar',sans-serif}}
.ctx{{position:absolute;left:{side}px;right:{side}px;top:44px;text-align:center;font-size:{ctx_px}px;line-height:1.35;font-weight:800;color:white;-webkit-text-stroke:{max(1.5,stroke-0.8):.1f}px #000;paint-order:stroke fill;text-shadow:0 2px 4px #000}}
.wrap{{position:absolute;left:{side}px;right:{side}px;top:{y_top}px;bottom:{bottom}px;display:flex;flex-direction:column;justify-content:center;text-align:center}}
.h{{font-size:{title_px}px;line-height:1.28;font-weight:800;color:white;-webkit-text-stroke:{stroke}px #000;paint-order:stroke fill;text-shadow:0 3px 5px #000;margin-bottom:20px}}
.b{{font-size:{body_px}px;line-height:1.48;font-weight:600;color:white;-webkit-text-stroke:{max(1.7,stroke-0.6):.1f}px #000;paint-order:stroke fill;text-shadow:0 3px 5px #000}}
</style></head><body><div class="ctx">{cc}</div><div class="wrap"><div class="h">{hh}</div><div class="b">{bb}</div></div></body></html>'''
        out.parent.mkdir(parents=True, exist_ok=True)
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            try:
                page = await browser.new_page(viewport={"width":w,"height":h})
                await page.set_content(page_html, wait_until="domcontentloaded")
                await page.wait_for_timeout(300)
                await page.screenshot(path=str(out), omit_background=True)
            finally:
                await browser.close()

    @staticmethod
    def _full_source_vertical(src_path: Path, out_path: Path) -> None:
        """Keep the entire picture visible in 9:16. No blur, liquid, ripple or smoky horror ambience."""
        W, H = 1080, 1920
        src = Image.open(src_path).convert("RGB")
        avg = src.resize((1,1), Image.Resampling.BILINEAR).getpixel((0,0))
        bgc = tuple(max(10, min(105, int(c * 0.45))) for c in avg)
        canvas = Image.new("RGB", (W,H), bgc)
        # Scale UP or down so a quadrant crop is also large and clearly visible.
        scale = min(1020/src.width, 1020/src.height)
        img = src.resize((max(1,int(src.width*scale)), max(1,int(src.height*scale))), Image.Resampling.LANCZOS)
        x = (W-img.width)//2
        y = 165
        frame = Image.new("RGB", (img.width+10,img.height+10), (18,18,24))
        canvas.paste(frame, (x-5,y-5))
        canvas.paste(img, (x,y))
        out_path.parent.mkdir(parents=True, exist_ok=True)
        canvas.save(out_path, quality=96)

    @staticmethod
    def _full_square_background(src_path: Path, out_path: Path) -> None:
        src = Image.open(src_path).convert("RGB").resize((1080,1080), Image.Resampling.LANCZOS)
        src = ImageEnhance.Brightness(src).enhance(0.78)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        src.save(out_path, quality=96)

    @staticmethod
    def _number_grid(src: Path, out: Path) -> None:
        im = Image.open(src).convert("RGB")
        d = ImageDraw.Draw(im)
        W,H = im.size
        spots = [(W*.08,H*.08),(W*.58,H*.08),(W*.08,H*.58),(W*.58,H*.58)]
        r = max(28,int(W*.045))
        for i,(x,y) in enumerate(spots,1):
            d.ellipse((x-r,y-r,x+r,y+r), fill=(0,0,0), outline=(255,255,255), width=max(3,int(W*.004)))
            d.text((x-r*.28,y-r*.62), str(i), fill=(255,255,255), stroke_width=1, stroke_fill=(0,0,0))
        out.parent.mkdir(parents=True, exist_ok=True)
        im.save(out, quality=96)

    @staticmethod
    def _crop_quadrants(src: Path, out_dir: Path) -> list[Path]:
        im = Image.open(src).convert("RGB")
        W,H = im.size; mx,my = W//2,H//2
        boxes = [(0,0,mx,my),(mx,0,W,my),(0,my,mx,H),(mx,my,W,H)]
        outs=[]; out_dir.mkdir(parents=True, exist_ok=True)
        for i,b in enumerate(boxes,1):
            p=out_dir/f"pick_{i}.jpg"
            im.crop(b).save(p, quality=96)
            outs.append(p)
        return outs

    def _duration(self, text: str, cover: bool=False) -> float:
        m=self.cfg.get("motion",{})
        if cover: return float(m.get("cover_seconds", 6.0))
        n=len(re.sub(r"\s+","",str(text or "")))
        if n<=120: return float(m.get("short_seconds", 7.0))
        if n<=180: return float(m.get("medium_seconds", 8.5))
        if n<=240: return float(m.get("long_seconds", 10.0))
        return float(m.get("very_long_seconds", 11.5))

    @staticmethod
    def _enforce_min_total(durations: list[float], minimum: float) -> list[float]:
        """Scale scene holds gently so a music-only post never ends below the requested floor."""
        vals=[max(0.1,float(x)) for x in durations]
        total=sum(vals)
        floor=max(0.0,float(minimum))
        if total >= floor or total <= 0 or floor <= 0:
            return vals
        factor=floor/total
        return [round(x*factor,3) for x in vals]

    def _scene_clip(self, bg: Path, overlay: Path, duration: float, out: Path) -> None:
        """ZOOM ONLY. Background moves; text overlay stays fixed."""
        fps=int(self.cfg.get("motion",{}).get("fps",30))
        step=float(self.cfg.get("motion",{}).get("zoom_step",0.00022))
        zmax=float(self.cfg.get("motion",{}).get("zoom_max",1.03))
        vf=(
            f"[0:v]scale=1080:1920,zoompan=z='min(1+on*{step},{zmax})':"
            f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=1080x1920:fps={fps}[m];"
            f"[m][1:v]overlay=0:0:format=auto[v]"
        )
        cmd=[self.ffmpeg,"-y","-loop","1","-i",str(bg),"-loop","1","-i",str(overlay),
             "-filter_complex",vf,"-map","[v]","-t",f"{duration:.3f}","-r",str(fps),"-an",
             "-c:v","h264_nvenc","-preset","p5","-pix_fmt","yuv420p",str(out)]
        p=subprocess.run(cmd,text=True,capture_output=True,encoding="utf-8",errors="replace")
        if p.returncode:
            cmd[cmd.index("h264_nvenc")]="libx264"
            self._run(cmd)

    def _pick_music(self) -> Path|None:
        files=[]
        for d in self.cfg.get("music_dirs",[]):
            p=Path(d)
            if p.exists():
                files += [x for x in p.rglob("*") if x.suffix.lower() in {".mp3",".wav",".m4a",".aac"}]
        return random.choice(files) if files else None

    def _concat_with_music(self, clips: list[Path], out: Path) -> None:
        with tempfile.TemporaryDirectory(prefix="astro_concat_") as td:
            lst=Path(td)/"list.txt"
            lst.write_text("\n".join(f"file '{p.resolve().as_posix()}'" for p in clips),encoding="utf-8")
            tmp=Path(td)/"video.mp4"
            self._run([self.ffmpeg,"-y","-f","concat","-safe","0","-i",str(lst),"-c","copy",str(tmp)])
            music=self._pick_music()
            if not music:
                shutil.copy2(tmp,out)
                print("🎵 Astrology music not found — silent motion rendered.")
                return
            vol=float(self.cfg.get("motion",{}).get("bgm_volume",0.28))
            self._run([self.ffmpeg,"-y","-i",str(tmp),"-stream_loop","-1","-i",str(music),
                       "-filter_complex",f"[1:a]volume={vol}[a]","-map","0:v","-map","[a]","-shortest",
                       "-c:v","copy","-c:a","aac","-b:a","160k",str(out)])
            print(f"🎵 Astrology BGM → {music}")

    async def _fb_square_card(self, bg: Path, out: Path, slide: dict[str,Any], context_line: str) -> None:
        tmp_bg=out.with_name(out.stem+"_bg_tmp.jpg")
        tmp_ov=out.with_name(out.stem+"_ov_tmp.png")
        self._full_square_background(bg,tmp_bg)
        txt=self.cfg.get("text",{})
        await self._render_text_png(
            headline=slide.get("headline", ""), body=slide.get("body", ""), out=tmp_ov,
            title_px=int(txt.get("fb_title_px",46)), body_px=int(txt.get("fb_body_px",36)),
            y_top=int(txt.get("fb_text_y",510)), context_line=context_line, canvas_h=1080)
        base=Image.open(tmp_bg).convert("RGBA")
        ov=Image.open(tmp_ov).convert("RGBA")
        grad=Image.new("RGBA",base.size,(0,0,0,0)); gd=ImageDraw.Draw(grad)
        for yy in range(400,1080):
            a=int(10+130*(yy-400)/(1080-400))
            gd.line((0,yy,1080,yy),fill=(0,0,0,min(140,a)))
        base=Image.alpha_composite(base,grad)
        base=Image.alpha_composite(base,ov)
        out.parent.mkdir(parents=True,exist_ok=True)
        base.convert("RGB").save(out,quality=96)
        for p in (tmp_bg,tmp_ov):
            try: p.unlink()
            except Exception: pass

    def _find_incomplete_root(self, when: datetime) -> Path | None:
        if not bool(self.cfg.get("resume_incomplete", True)) or not self.out_root.exists():
            return None
        prefix=when.strftime("%Y%m%d_")
        candidates=[p for p in self.out_root.iterdir() if p.is_dir() and p.name.startswith(prefix)]
        for p in sorted(candidates,key=lambda x:x.name,reverse=True):
            if (p/"real_output_result.json").exists():
                continue
            if (p/"daily"/"daily_background.jpg").exists() or (p/"image_pick"/"grid_raw.jpg").exists():
                return p
        return None

    def _find_latest_asset_root(self, when: datetime) -> Path | None:
        if not bool(self.cfg.get("reuse_latest_same_day_assets", True)) or not self.out_root.exists():
            return None
        prefix=when.strftime("%Y%m%d_")
        candidates=[p for p in self.out_root.iterdir() if p.is_dir() and p.name.startswith(prefix)]
        for p in sorted(candidates,key=lambda x:x.name,reverse=True):
            if (p/"daily"/"daily_background.jpg").exists() and (p/"image_pick"/"grid_raw.jpg").exists():
                return p
        return None

    async def run_today(self, when: datetime|None=None) -> Path:
        when=when or datetime.now()
        born=WEEKDAY_BORN_MM[when.weekday()]
        date_label=mm_date_label(when)
        context_line=f"{date_label} • {born}"
        stamp=when.strftime("%Y%m%d_%H%M%S")
        resume_root=self._find_incomplete_root(when)
        root=resume_root if resume_root else self.out_root/stamp
        root.mkdir(parents=True,exist_ok=True)
        print(f"🌙 Astrology REAL OUTPUT {CONTENT_VERSION} → {when:%Y-%m-%d %A} | {born}")
        print(f"📅 Daily horoscope identity → {context_line}")
        print("🧩 Image Picker identity → timeless / everyone (NO date, NO weekday-born label)")

        if resume_root:
            print(f"♻️ SAFE RESUME → {root}")
        else:
            prior=self._find_latest_asset_root(when)
            if prior and prior != root:
                for rel in (
                    Path("daily/daily_background.jpg"),
                    Path("image_pick/grid_raw.jpg"),
                    Path("image_pick/theme.json"),
                ):
                    srcp=prior/rel; dst=root/rel
                    if srcp.exists():
                        dst.parent.mkdir(parents=True,exist_ok=True)
                        shutil.copy2(srcp,dst)
                        print(f"♻️ SAME-DAY FAL asset reused → {dst}")

        daily_dir=root/"daily"; (daily_dir/"fb_carousel").mkdir(parents=True,exist_ok=True)
        daily_ckpt=daily_dir/"daily_content.json"
        daily=read_json(daily_ckpt,{})
        if not (isinstance(daily,dict) and len(daily.get("slides") or [])==6 and daily.get("_content_version")==CONTENT_VERSION):
            daily=await self._daily_content(born,date_label)
            daily["_content_version"]=CONTENT_VERSION; daily["_context_line"]=context_line
            write_json(daily_ckpt,daily)
            print(f"💾 Daily horoscope + ယတြာ text checkpoint → {daily_ckpt}")
        else:
            print(f"♻️ Daily text resume → {daily_ckpt}")

        daily_bg=await self._fal_square(
            f"cute dreamy astrology illustration for {WEEKDAY_DAY_MM[when.weekday()]}, moon, stars, soft lucky symbols, calm elegant magical atmosphere",
            daily_dir/"daily_background.jpg")
        clips=[]; txt=self.cfg.get("text",{})
        daily_durations=[self._duration(s.get("body",""),cover=(i==1)) for i,s in enumerate(daily["slides"],1)]
        # Keep the existing horoscope pacing. The NEW Yadaya scene alone supplies
        # the extra runtime needed to clear the one-minute floor.
        if daily_durations:
            daily_cfg=self.cfg.get("daily",{})
            yadaya_min=float(daily_cfg.get("yadaya_min_seconds",10.0))
            daily_floor=float(daily_cfg.get("min_total_seconds",62.0))
            daily_durations[-1]=max(daily_durations[-1],yadaya_min)
            if sum(daily_durations) < daily_floor:
                daily_durations[-1]+=daily_floor-sum(daily_durations)
        print(f"⏱️ Daily horoscope planned motion = {sum(daily_durations):.1f}s across {len(daily_durations)} scenes (includes ယတြာ; existing horoscope pacing unchanged)")
        for i,(s,dur) in enumerate(zip(daily["slides"],daily_durations),1):
            await self._fb_square_card(daily_bg,daily_dir/"fb_carousel"/f"slide_{i:02d}.jpg",s,context_line)
            bgv=daily_dir/f"motion_bg_{i:02d}.jpg"; ov=daily_dir/f"motion_text_{i:02d}.png"; clip=daily_dir/f"scene_{i:02d}.mp4"
            self._full_source_vertical(daily_bg,bgv)
            await self._render_text_png(
                headline=s.get("headline",""), body=s.get("body",""), out=ov,
                title_px=int(txt.get("daily_title_px",52)), body_px=int(txt.get("daily_body_px",40)),
                y_top=int(txt.get("daily_text_y",1130)), context_line=context_line)
            self._scene_clip(bgv,ov,dur,clip)
            clips.append(clip)
        self._concat_with_music(clips,daily_dir/"tiktok_daily_motion.mp4")

        pick_dir=root/"image_pick"; pick_dir.mkdir(parents=True,exist_ok=True)
        theme_info=self._select_image_pick_theme(when,pick_dir)
        theme=theme_info["prompt"]
        grid_raw=await self._fal_square(
            f"A clear 2x2 grid with exactly four separate cute mystical choices. {theme}. Each quadrant one centered distinct subject, equal panels, same dreamy style",
            pick_dir/"grid_raw.jpg")
        grid_numbered=pick_dir/"grid_numbered.jpg"; self._number_grid(grid_raw,grid_numbered)
        pick_ckpt=pick_dir/"image_pick_content.json"
        pick=read_json(pick_ckpt,{})
        if not (isinstance(pick,dict) and len(pick.get("items") or [])==4 and pick.get("_content_version")==CONTENT_VERSION):
            pick=await self._pick_content_from_grid(grid_raw)
            pick["_content_version"]=CONTENT_VERSION; pick["_context_line"]=""
            write_json(pick_ckpt,pick)
            print(f"💾 Timeless image-pick text checkpoint → {pick_ckpt}")
        else:
            print(f"♻️ Image-pick text resume → {pick_ckpt}")
        crops=self._crop_quadrants(grid_raw,pick_dir/"crops")

        # Image Picker is for EVERYONE: no date and no weekday-born label anywhere on the visual.
        pick_context=""
        cover_dur=float(self.cfg.get("motion",{}).get("pick_cover_seconds",6.0))
        item_durs=[self._duration(item.get("body","")) for item in pick["items"]]
        cta_dur=float(self.cfg.get("motion",{}).get("cta_seconds",5.5))
        raw_pick_durations=[cover_dur,*item_durs,cta_dur]
        min_pick_total=float(self.cfg.get("image_pick",{}).get("min_total_seconds",65.0))
        pick_durations=self._enforce_min_total(raw_pick_durations,min_pick_total)
        if sum(raw_pick_durations) < min_pick_total:
            print(f"⏱️ Image Picker duration floor: {sum(raw_pick_durations):.1f}s → {sum(pick_durations):.1f}s (minimum {min_pick_total:.0f}s)")
        else:
            print(f"⏱️ Image Picker planned motion = {sum(pick_durations):.1f}s")

        pick_clips=[]
        bg=pick_dir/"scene_01_bg.jpg"; ov=pick_dir/"scene_01_text.png"; clip=pick_dir/"scene_01.mp4"
        self._full_source_vertical(grid_numbered,bg)
        await self._render_text_png(
            headline="ပုံ ၄ ပုံထဲက တစ်ပုံရွေးပါ", body="စိတ်ထဲမှာ အကြိုက်ဆုံးဖြစ်တဲ့ ပုံတစ်ပုံကိုရွေးထားပါ", out=ov,
            title_px=int(txt.get("pick_prompt_px",49)), body_px=int(txt.get("pick_body_px",38)),
            y_top=int(txt.get("pick_text_y",1130)), context_line=pick_context)
        self._scene_clip(bg,ov,pick_durations[0],clip); pick_clips.append(clip)

        for i,item in enumerate(pick["items"],1):
            bg=pick_dir/f"scene_{i+1:02d}_bg.jpg"; ov=pick_dir/f"scene_{i+1:02d}_text.png"; clip=pick_dir/f"scene_{i+1:02d}.mp4"
            self._full_source_vertical(crops[i-1],bg)
            await self._render_text_png(
                headline=item.get("headline") or f"ပုံ {i} ကိုရွေးသူ", body=item.get("body") or "", out=ov,
                title_px=int(txt.get("pick_title_px",46)), body_px=int(txt.get("pick_body_px",38)),
                y_top=int(txt.get("pick_text_y",1130)), context_line=pick_context)
            self._scene_clip(bg,ov,pick_durations[i],clip); pick_clips.append(clip)

        bg=pick_dir/"scene_06_bg.jpg"; ov=pick_dir/"scene_06_text.png"; clip=pick_dir/"scene_06.mp4"
        self._full_source_vertical(grid_numbered,bg)
        await self._render_text_png(
            headline="သင်ရွေးတာ ဘယ်ပုံလဲ?", body="comment မှာ 1 / 2 / 3 / 4 လို့ရေးပေးပါ", out=ov,
            title_px=int(txt.get("pick_prompt_px",49)), body_px=int(txt.get("pick_body_px",38)),
            y_top=int(txt.get("pick_text_y",1130)), context_line=pick_context)
        self._scene_clip(bg,ov,pick_durations[-1],clip); pick_clips.append(clip)
        self._concat_with_music(pick_clips,pick_dir/"image_pick_motion.mp4")

        # Special cadence locked by product spec:
        # - Sunday: Weekly + Daily + Image Pick
        # - Calendar day 30: Monthly + Daily + Image Pick
        # - If day 30 is Sunday, Monthly replaces Weekly (never 4 posts).
        special_outputs={}
        if when.day==30:
            special_outputs["monthly"]=await self._render_period(root,"monthly",when)
        elif when.weekday()==6:
            special_outputs["weekly"]=await self._render_period(root,"weekly",when)

        result={
            "version":CONTENT_VERSION,
            "date":when.strftime("%Y-%m-%d"),"weekday":when.strftime("%A"),
            "born_label":born,"date_label":date_label,"context_line":context_line,
            "daily":daily,"image_pick":pick,
            "image_pick_theme":theme_info,
            "weekly":(special_outputs.get("weekly") or {}).get("content"),
            "monthly":(special_outputs.get("monthly") or {}).get("content"),
            "special_outputs":special_outputs,
            "image_pick_visual_identity":"timeless_everyone_no_date_no_weekday_born",
            "motion_contract":"center zoom only; no liquid/ripple/wave/pan/horror FX",
            "outputs":{
                "daily_fb_carousel":str(daily_dir/"fb_carousel"),
                "daily_tt_motion":str(daily_dir/"tiktok_daily_motion.mp4"),
                "image_pick_motion":str(pick_dir/"image_pick_motion.mp4"),
                "image_pick_grid":str(grid_numbered),
                "weekly_fb_carousel":str(root/"weekly"/"fb_carousel") if "weekly" in special_outputs else "",
                "weekly_motion":str(root/"weekly"/"weekly_motion.mp4") if "weekly" in special_outputs else "",
                "monthly_fb_carousel":str(root/"monthly"/"fb_carousel") if "monthly" in special_outputs else "",
                "monthly_motion":str(root/"monthly"/"monthly_motion.mp4") if "monthly" in special_outputs else "",
            },
        }
        write_json(root/"real_output_result.json",result)
        print("\n✅ ASTROLOGY REAL OUTPUT V1.0.4 READY")
        print(f"📁 {root}")
        print(f"📅 Daily only → {context_line}")
        print("🧩 Image Picker → everyone / timeless / no date / no weekday-born label")
        print("🔍 Motion = ZOOM ONLY | full source picture preserved | no liquid/horror FX")
        print("🚫 Social upload was NOT run.")
        return root
