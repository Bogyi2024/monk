from __future__ import annotations
import json, shutil, sys
from pathlib import Path
CONFIG=Path("config/story_carousel.json")
BACKUP=Path("config/story_carousel.before_fal_switch.json")
def load():
    if not CONFIG.exists(): raise FileNotFoundError(f"Missing: {CONFIG}")
    return json.loads(CONFIG.read_text(encoding="utf-8"))
def save(d):
    tmp=CONFIG.with_suffix(".json.tmp"); tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding="utf-8"); tmp.replace(CONFIG)
def backup_once():
    if not BACKUP.exists():
        BACKUP.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(CONFIG,BACKUP); print(f"Backup saved -> {BACKUP}")
    else: print(f"Backup already exists -> {BACKUP}")
def show(d):
    print("\nCURRENT STORY IMAGE SETTINGS")
    for k in ["image_provider","fal_model","fal_width","fal_height","fal_output_format","fal_num_inference_steps","fal_guidance_scale","fal_timeout_seconds"]: print(f"{k:28s}: {d.get(k)}")
def set_fal():
    d=load(); backup_once(); d["image_provider"]="fal"; d["fal_model"]=str(d.get("fal_model") or "fal-ai/flux-2/flash"); d["fal_width"]=720; d["fal_height"]=1280; d["fal_output_format"]=str(d.get("fal_output_format") or "jpeg"); d["fal_num_inference_steps"]=int(d.get("fal_num_inference_steps") or 20); d["fal_guidance_scale"]=float(d.get("fal_guidance_scale") or 3.5); d["fal_safety_tolerance"]=str(d.get("fal_safety_tolerance") or "2"); d["fal_timeout_seconds"]=max(180,int(d.get("fal_timeout_seconds") or 180)); d["fal_poll_interval_seconds"]=float(d.get("fal_poll_interval_seconds") or 2.0); save(d); print("\nStory image provider switched to FAL"); print("Generation size = 720x1280 (9:16, ~0.92MP)"); print("FAL_KEY must exist in .env/environment"); show(d)
def set_gemini():
    d=load(); backup_once(); d["image_provider"]="gemini_web"; save(d); print("\nStory image provider switched to gemini_web"); show(d)
def restore():
    if not BACKUP.exists(): raise FileNotFoundError(f"Backup not found: {BACKUP}")
    shutil.copy2(BACKUP,CONFIG); print(f"Restored from {BACKUP}"); show(load())
def main():
    m=(sys.argv[1] if len(sys.argv)>1 else "show").lower().strip()
    if m=="fal": set_fal()
    elif m in {"gemini","gemini_web"}: set_gemini()
    elif m=="restore": restore()
    elif m=="show": show(load())
    else: raise SystemExit("Usage: python set_story_image_provider.py [fal|gemini_web|restore|show]")
if __name__=="__main__": main()
