"""Read-only login check after confirmed draft cleanup."""
import asyncio
import json
from pathlib import Path
from services.tt_tiktok_profile_service import TTTikTokProfileService
from services.post_publish_cleanup import atomic

async def main():
    root=Path(__file__).resolve().parent
    service=TTTikTokProfileService(root)
    rows=[]
    for profile in ['zawwwlinn.no123','recapx-movie','TikTok_SoulStar','TikTok_RecapX','TikTok_Recapentertainment']:
        row=await service._test_async(profile)
        rows.append(row)
        print(json.dumps(row,ensure_ascii=False),flush=True)
    atomic(root/'state/tiktok_cleanup_session_check.json',{'results':rows})

asyncio.run(main())
