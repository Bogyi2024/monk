from __future__ import annotations

import argparse
from pathlib import Path

from services.story_animation_fx_service import StoryAnimationFXService


def choose() -> tuple[str, str]:
    print("\nSTORY ANIMATION FX LAB V0.1")
    print("1) Horror QUICK (~15.4s)")
    print("2) Thriller QUICK (~15.4s)")
    print("3) Horror LONG (~63s)")
    print("4) Thriller LONG (~63s)")
    print("5) BOTH quick")
    value = input("Choose [1]: ").strip() or "1"
    return {
        "1": ("horror", "quick"),
        "2": ("thriller", "quick"),
        "3": ("horror", "long"),
        "4": ("thriller", "long"),
        "5": ("both", "quick"),
    }.get(value, ("horror", "quick"))


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--preset", choices=["horror", "thriller", "both"], default="")
    p.add_argument("--mode", choices=["quick", "long"], default="")
    p.add_argument("--input-dir", default="")
    p.add_argument("--no-music", action="store_true")
    args = p.parse_args()

    preset, mode = (args.preset, args.mode) if args.preset and args.mode else choose()
    service = StoryAnimationFXService()
    input_dir = Path(args.input_dir) if args.input_dir else service.newest_story_raw_dir()

    print(f"\n📁 Source RAW images: {input_dir}")
    print("🧪 ISOLATED TEST: no Gemini/HF/fal, no FB/TT upload, no scheduler state changes.\n")

    presets = ["horror", "thriller"] if preset == "both" else [preset]
    for item in presets:
        service.build(input_dir=input_dir, preset=item, mode=mode, music=not args.no_music)


if __name__ == "__main__":
    main()
