from __future__ import annotations

import argparse
import asyncio
import json
import time
from pathlib import Path
from urllib.parse import urlsplit
from playwright.async_api import async_playwright
from services.fb_profile_paths import PROFILE_STORES, profile_path, profile_store as validate_store
from services.fb_session_snapshot import restore_snapshot, save_snapshot, has_login_cookie

ROOT = Path(__file__).resolve().parent


def safe_path(profile, profile_store="browser_sessions"):
    return profile_path(ROOT, profile, profile_store)


def login_purpose(profile_store, purpose=None):
    validate_store(profile_store)
    purpose = purpose or ("share" if profile_store == "browser_profiles" else "page")
    if purpose not in {"page", "share"}:
        raise ValueError("Invalid Facebook login purpose")
    return purpose


def facebook_start_url(profile_store, purpose=None):
    return ("https://business.facebook.com/latest/home" if login_purpose(profile_store, purpose) == "page"
            else "https://www.facebook.com/")


def _facebook_host(page):
    return (urlsplit(str(page.url or "")).hostname or "").lower()


async def _context_has_login_cookie(context):
    try:
        names = set()
        for cookie in await context.cookies():
            domain = str(cookie.get("domain") or "").lower().lstrip(".")
            if domain != "facebook.com" and not domain.endswith(".facebook.com"):
                continue
            expires = float(cookie.get("expires") or -1)
            if cookie.get("value") and (expires <= 0 or expires > time.time()):
                names.add(cookie.get("name"))
        return {"c_user", "xs"}.issubset(names)
    except Exception:
        return False


async def _page_logged_in(page):
    try:
        url = urlsplit(str(page.url or ""))
        host = (url.hostname or "").lower()
        if host != "facebook.com" and not host.endswith(".facebook.com"):
            return False
        if any(token in url.path.lower() for token in ("/login", "login.php", "checkpoint", "two_factor",
                "two-factor", "approvals_code", "auth_platform", "/recover", "challenge")):
            return False
        for selector in ('input[name="email"]:visible, input[type="email"]:visible',
                         'input[name="pass"]:visible, input[type="password"]:visible',
                         'input[name="approvals_code"]:visible, input[name="code"]:visible, '
                         'input[autocomplete="one-time-code"]:visible, input[name*="otp" i]:visible, '
                         'input[name*="two_factor" i]:visible'):
            if await page.locator(selector).count():
                return False
        return True
    except Exception:
        return False


async def _login_confirmed(context, purpose=None):
    if not await _context_has_login_cookie(context) or not context.pages:
        return False
    page = context.pages[-1]
    if not await _page_logged_in(page):
        return False
    return purpose != "page" or _facebook_host(page) == "business.facebook.com"


async def open_login(profile, profile_store="browser_sessions", purpose=None):
    purpose = login_purpose(profile_store, purpose)
    path = safe_path(profile, profile_store); path.mkdir(parents=True, exist_ok=True)
    target = facebook_start_url(profile_store, purpose)
    print(f"Facebook {purpose} login: {profile}; network: system / external VPN", flush=True)
    async with async_playwright() as p:
        try:
            context = await p.chromium.launch_persistent_context(str(path), headless=False,
                args=["--disable-notifications", "--disable-blink-features=AutomationControlled"])
        except Exception as exc:
            return {"profile": profile, "logged_in": None, "check_unknown": True, "busy": True,
                    "reason": "Close this account's other Facebook browser, then retry. " + str(exc)[:300]}
        authenticated, business_ready, last_business_try = False, False, 0.0
        try:
            await restore_snapshot(context, profile, profile_store=profile_store)
            page = context.pages[0] if context.pages else await context.new_page()
            try:
                await page.goto(target, wait_until="domcontentloaded", timeout=60_000)
            except Exception:
                pass  # keep the requested Business page; never replace it with a personal-feed fallback
            for _ in range(900):
                await asyncio.sleep(2)
                if not context.pages:
                    break
                page = context.pages[-1]
                if await _login_confirmed(context):
                    await save_snapshot(context, profile, profile_store=profile_store)
                    authenticated = True
                    if purpose == "page" and _facebook_host(page) != "business.facebook.com":
                        if time.monotonic() - last_business_try > 15:
                            last_business_try = time.monotonic()
                            try:
                                await page.goto(target, wait_until="domcontentloaded", timeout=15_000)
                            except Exception:
                                pass
                    business_ready = await _login_confirmed(context, "page") if purpose == "page" else False
                    if purpose == "share" or business_ready:
                        await asyncio.sleep(15)  # allow Chromium to commit the final auth/2FA redirect
                        break
        finally:
            try:
                if context.pages and not context.pages[-1].is_closed():
                    authenticated = await _login_confirmed(context)
                    if authenticated:
                        await save_snapshot(context, profile, profile_store=profile_store)
                    business_ready = authenticated and _facebook_host(context.pages[-1]) == "business.facebook.com" if purpose == "page" else False
            except Exception:
                pass
            try:
                await context.close()
            except Exception:
                pass
        return {"profile": profile, "logged_in": authenticated, "business_ready": business_ready,
                "profile_store": profile_store, "purpose": purpose,
                "reason": ("Facebook login saved" if purpose == "share" or business_ready else
                           "Facebook login saved; Business Suite still needs to be opened") if authenticated else
                          "Login was not confirmed. Complete Facebook login/2FA and retry."}


async def check_login(profile, profile_store="browser_sessions", purpose=None):
    purpose = login_purpose(profile_store, purpose)
    path = safe_path(profile, profile_store)
    if not path.exists():
        return {"profile": profile, "logged_in": False, "reason": "profile folder missing"}
    async with async_playwright() as p:
        try:
            context = await p.chromium.launch_persistent_context(str(path), headless=True,
                args=["--disable-notifications", "--disable-blink-features=AutomationControlled"])
        except Exception as exc:
            return {"profile": profile, "logged_in": None, "check_unknown": True, "busy": True,
                    "reason": "Profile is open/locked; close that account's browser and retry. " + str(exc)[:300]}
        try:
            restored = await restore_snapshot(context, profile, profile_store=profile_store)
            page = context.pages[0] if context.pages else await context.new_page()
            await page.goto(facebook_start_url(profile_store, purpose), timeout=60_000, wait_until="domcontentloaded")
            await page.wait_for_timeout(2500)
            logged_in = await _login_confirmed(context)
            ready = logged_in and _facebook_host(page) == "business.facebook.com" if purpose == "page" else False
            if logged_in:
                await save_snapshot(context, profile, profile_store=profile_store)
            return {"profile": profile, "logged_in": logged_in, "business_ready": ready,
                    "snapshot_restored": restored, "snapshot_has_login_cookie": has_login_cookie(profile, profile_store),
                    "reason": "Facebook login active" if logged_in else "Facebook login/2FA is required"}
        except Exception as exc:
            return {"profile": profile, "logged_in": None, "check_unknown": True,
                    "reason": "Could not reach Facebook to verify login. " + str(exc)[:500]}
        finally:
            try:
                await context.close()
            except Exception:
                pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("profile")
    parser.add_argument("--profile-store", choices=sorted(PROFILE_STORES), default="browser_sessions")
    parser.add_argument("--purpose", choices=("page", "share"))
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    operation = check_login if args.check else open_login
    print(json.dumps(asyncio.run(operation(args.profile, args.profile_store, args.purpose)), ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
