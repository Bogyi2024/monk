from pathlib import Path
from playwright.sync_api import sync_playwright

PROFILE_DIR = Path('browser_profiles/gemini_story')
GEMINI_URL = 'https://gemini.google.com/app'


def main():
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)

    print('\n🔐 GEMINI WEB PROFILE SETUP')
    print(f'📁 Profile folder: {PROFILE_DIR.resolve()}')
    print('🌐 Chromium ဖွင့်နေပါတယ်...')
    print('➡️ Google/Gemini login ဝင်ပါ။')
    print('➡️ Gemini main chat page ရောက်ပြီး login အောင်မြင်တာသေချာရင် ဒီ console ကိုပြန်လာပါ။\n')

    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(PROFILE_DIR.resolve()),
            headless=False,
            viewport={'width': 1440, 'height': 1100},
            accept_downloads=True,
            args=[
                '--disable-blink-features=AutomationControlled',
                '--disable-dev-shm-usage',
                '--no-first-run',
                '--no-default-browser-check',
            ],
        )

        page = context.pages[0] if context.pages else context.new_page()
        page.goto(GEMINI_URL, wait_until='domcontentloaded')

        input(
            '✅ Login ပြီး Gemini chat page ရောက်သွားရင် ENTER နှိပ်ပါ '
            '(browser ကို ကိုယ်တိုင်မပိတ်ပါနဲ့) > '
        )

        page.wait_for_timeout(1500)
        context.close()

    print('\n✅ Gemini persistent profile saved.')
    print(f'📁 {PROFILE_DIR.resolve()}')
    print('Next: python .\\run_story_carousel_test.py')


if __name__ == '__main__':
    main()
