from __future__ import annotations

import json
import shutil
from pathlib import Path


def read_json(path: Path, default):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        pass
    return default


def folder_size(path: Path) -> int:
    total = 0
    try:
        for p in path.rglob('*'):
            if p.is_file():
                try:
                    total += p.stat().st_size
                except OSError:
                    pass
    except OSError:
        pass
    return total


def human(n: int) -> str:
    x = float(n)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if x < 1024 or unit == 'TB':
            return f'{x:.1f}{unit}' if unit != 'B' else f'{int(x)}B'
        x /= 1024
    return f'{x:.1f}TB'


def main() -> None:
    cfg = read_json(Path('config/story_motion_production_test.json'), {})
    root = Path(cfg.get('output_root', 'outputs/story_motion_production_test'))
    if not root.exists():
        print(f'Nothing to clean: {root} does not exist.')
        return

    deleted = 0
    freed = 0
    skipped_incomplete = 0
    for story in sorted(root.iterdir()):
        if not story.is_dir():
            continue
        result = read_json(story / 'result.json', {})
        # Never touch failed/incomplete runs because their work cache is useful for Resume.
        if not result.get('success'):
            skipped_incomplete += 1
            continue
        for work in sorted(story.glob('work_*')):
            if not work.is_dir():
                continue
            size = folder_size(work)
            shutil.rmtree(work)
            deleted += 1
            freed += size
            print(f'Deleted {work}  ({human(size)})')

    print('-' * 68)
    print(f'Completed Story Motion work folders deleted: {deleted}')
    print(f'Disk space freed: {human(freed)}')
    print(f'Incomplete/failed story folders preserved for Resume: {skipped_incomplete}')
    print('Raw images, narration audio, story plans, registries and final videos were NOT deleted.')


if __name__ == '__main__':
    main()
