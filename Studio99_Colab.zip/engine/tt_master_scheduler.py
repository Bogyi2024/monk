from __future__ import annotations

import asyncio
import ctypes
from datetime import datetime
import hashlib
import os
import sys
import threading
from pathlib import Path

from services.tt_settings_service import TTSettingsService
from services.tt_daily_run_service import TTDailyRunService
from services.tt_pipeline_service import TTPipelineService
from services.tt_rolling_schedule_service import TTRollingScheduleService
from services.tt_telegram_notify_service import TTTelegramNotifyService
from services.tt_long_to_short_night_service import TTLongToShortNightService
from services.tt_episode_splitter_night_service import TTEpisodeSplitterNightService
from services.post_publish_cleanup import (
    PostPublishCleanup,
    PROFILE_MAINTENANCE_LOCK,
    posting_allows_profile_cleanup,
)
import tt_web_manager


_ERROR_ALREADY_EXISTS = 183


def _acquire_single_instance_guard(project_root: str | Path = "."):
    """Hold an OS-level guard so a second TT Master exits before any workers start.

    Dashboard-port binding is not a sufficient singleton on Windows: two processes
    can overlap long enough to start Telegram polling and Playwright work.  A named
    mutex is released automatically by Windows if the owning process crashes.
    """
    root = str(Path(project_root).resolve()).casefold()
    suffix = hashlib.sha1(root.encode("utf-8")).hexdigest()[:16]
    if os.name == "nt":
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
        kernel32.CreateMutexW.restype = ctypes.c_void_p
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel32.CloseHandle.restype = ctypes.c_bool
        ctypes.set_last_error(0)
        handle = kernel32.CreateMutexW(None, False, f"Local\\TTMasterScheduler_{suffix}")
        if not handle:
            raise ctypes.WinError(ctypes.get_last_error())
        if ctypes.get_last_error() == _ERROR_ALREADY_EXISTS:
            kernel32.CloseHandle(handle)
            return None
        return ("windows_mutex", kernel32, handle)

    # Non-Windows fallback for development/test environments.
    import fcntl
    lock_path = Path(project_root).resolve() / "state" / "tt_master.instance.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    handle = lock_path.open("a+b")
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        handle.close()
        return None
    return ("file_lock", fcntl, handle)


def _release_single_instance_guard(guard) -> None:
    if not guard:
        return
    kind, api, handle = guard
    try:
        if kind == "windows_mutex":
            api.CloseHandle(handle)
        else:
            api.flock(handle.fileno(), api.LOCK_UN)
            handle.close()
    except Exception:
        pass


class _TeeStream:
    def __init__(self, terminal, path: str | Path):
        self.terminal = terminal
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.file = self.path.open("a", encoding="utf-8", buffering=1)
        self.lock = threading.Lock()

    def write(self, data):
        with self.lock:
            try:
                self.terminal.write(data)
                self.terminal.flush()
            except Exception:
                pass
            try:
                self.file.write(data)
                self.file.flush()
            except Exception:
                pass
        return len(data)

    def flush(self):
        try: self.terminal.flush()
        except Exception: pass
        try: self.file.flush()
        except Exception: pass

    def isatty(self):
        try: return self.terminal.isatty()
        except Exception: return False


def _enable_master_log():
    # All Recap/Drama print output now mirrors to logs/tt_master.log so the
    # localhost Health/Logs tab can show the exact live terminal stream.
    if not isinstance(sys.stdout, _TeeStream):
        sys.stdout = _TeeStream(sys.stdout, Path("logs") / "tt_master.log")
    if not isinstance(sys.stderr, _TeeStream):
        sys.stderr = _TeeStream(sys.stderr, Path("logs") / "tt_master.log")


async def main()->None:
    _enable_master_log()
    root='.';settings=TTSettingsService(root);daily=TTDailyRunService(settings,root);pipelines=TTPipelineService(settings,root);rolling=TTRollingScheduleService(settings);telegram=TTTelegramNotifyService(root,settings);lts_night=TTLongToShortNightService(settings,root);episode_night=TTEpisodeSplitterNightService(settings,root)
    telegram.configure_read_only_commands(
        status_provider=lambda: rolling.live_status(daily.get(datetime.now().astimezone()), datetime.now().astimezone()),
        state_provider=lambda: daily.get(datetime.now().astimezone()),
    )
    telegram.start_command_listener()
    daily.recover_stale_current_job(datetime.now().astimezone(),max_age_seconds=90)
    lts_night.recover_stale_run(datetime.now().astimezone())
    episode_night.recover_stale_run(datetime.now().astimezone())
    web_server,web_thread=tt_web_manager.start_in_thread(open_browser=not os.environ.get('TT_NO_BROWSER'))  # Studio99: shown in its own window
    print('\n'+'='*76);print('TT MASTER SCHEDULER V2.0.24 — TELEGRAM CONTROL + FRIENDLY ROUTES');print('='*76)
    print(f'Web Manager: http://127.0.0.1:{tt_web_manager.PORT}')
    print('Today = WHAT/HOW MANY. Category Timing = WHEN ALLOWED/PREFERRED. Master recalculates after every actual finish.')
    print('Live bridges:',pipelines.capabilities());print('='*76)
    last_date=datetime.now().astimezone().date()
    def profile_cleanup_allowed() -> bool:
        """Give scheduled posting priority over slow browser-profile maintenance."""
        now = datetime.now().astimezone()
        state = daily.get(now)
        decision = rolling.next_decision(state, now)
        return posting_allows_profile_cleanup(state, decision, now)

    cleanup_task=asyncio.create_task(
        PostPublishCleanup(root, profile_cleanup_allowed=profile_cleanup_allowed).monitor(),
        name='tt:24h-media-cleanup',
    )
    try:
        while True:
            now=datetime.now().astimezone()
            if now.date()!=last_date:
                last_date=now.date();sch=settings.scheduler();daily.get(now)
                if bool(sch.get('auto_arm_next_day',True)):
                    daily.arm(now);print(f'🌅 New day rolling scheduler auto-armed: {now.date()}')
            # Startup recovery alone is insufficient: a stale snapshot can be
            # reintroduced by a concurrent dashboard read after a job completes.
            # Active jobs heartbeat every second, so this only clears abandoned
            # locks and lets the rolling queue continue without a Master restart.
            daily.recover_stale_current_job(now,max_age_seconds=90)
            state=daily.get(now)
            if not state.get('armed'):
                await asyncio.sleep(3);continue
            decision=rolling.next_decision(state,now)
            if decision.get('status') in {'complete','no_safe_slot'}:
                # Studio99 Desktop: tools prepare separately; this process only posts.
                if os.environ.get("STUDIO99_POSTING_ONLY") == "1":
                    await asyncio.sleep(8);continue
                # Preparation is separate from posting. Long-to-Short keeps first
                # priority. Episode Splitter is released only by LTS's durable
                # complete/not-required handoff; shortfall/error never releases it.
                try:
                    lts_attempted=await lts_night.run_if_due(state,decision,now)
                    lts_gate=lts_night.episode_handoff()
                except Exception as prep_exc:
                    lts_attempted=False
                    lts_gate={"ready": False, "status": "error"}
                    print(f"⚠️ Long-to-Short idle preparation error contained; TT Master remains live: {type(prep_exc).__name__}: {prep_exc}")
                try:
                    episode_attempted=await episode_night.run_if_due(state,decision,now,upstream_gate=lts_gate)
                except Exception as prep_exc:
                    episode_attempted=False
                    print(f"⚠️ Episode Splitter idle preparation error contained; TT Master remains live: {type(prep_exc).__name__}: {prep_exc}")
                if episode_attempted:
                    await asyncio.sleep(2);continue
                if lts_attempted:
                    await asyncio.sleep(2);continue
                await asyncio.sleep(8);continue
            if decision.get('status')=='running':
                await asyncio.sleep(2);continue
            key=decision.get('next_category');route_key=str(decision.get('next_route') or 'default');due=decision.get('next_at')
            if not key or due is None:
                await asyncio.sleep(5);continue
            if due>now:
                wait=min(20.0,max(1.0,(due-now).total_seconds()));await asyncio.sleep(wait);continue
            try:
                job_id=daily.mark_started(key,now,route_key=route_key)
            except RuntimeError as lock_exc:
                print(f"🔒 Queue lock kept sequential execution: {lock_exc}")
                await asyncio.sleep(2)
                continue
            print(f"\n▶ ROLLING MASTER → {key.upper()} / {route_key} start @ {now:%H:%M:%S} | job={job_id} | reason={decision.get('reason')}")
            async def run_pipeline():
                async with PROFILE_MAINTENANCE_LOCK:
                    return await pipelines.run_once(key,route_key=route_key)
            task=asyncio.create_task(run_pipeline(),name=f"tt:{job_id}")
            dashboard_interrupted=False
            try:
                # Keep an on-disk heartbeat so a killed terminal can never leave a
                # permanent current_job lock. Dashboard Clear/Skip removes this job_id;
                # the live coroutine notices and cancels itself here.
                heartbeat_state_warn_at=0.0
                while not task.done():
                    try:
                        heartbeat_ok=daily.touch_current_job(job_id,datetime.now().astimezone())
                    except (PermissionError,OSError) as state_exc:
                        winerror=getattr(state_exc,'winerror',None)
                        if isinstance(state_exc,PermissionError) or winerror in (5,32):
                            loop_now=asyncio.get_running_loop().time()
                            if loop_now-heartbeat_state_warn_at>=30.0:
                                print(f"⚠️ Heartbeat state write busy; live {key}/{route_key} job continues safely: {state_exc}")
                                heartbeat_state_warn_at=loop_now
                            await asyncio.sleep(1.0);continue
                        raise
                    if not heartbeat_ok:
                        dashboard_interrupted=True
                        print(f"⏭️ Dashboard control released {job_id}; cancelling the live coroutine and moving on.")
                        task.cancel()
                        try:
                            await asyncio.wait_for(task,timeout=12.0)
                        except (asyncio.CancelledError,asyncio.TimeoutError,Exception):
                            pass
                        break
                    await asyncio.sleep(1.0)
                if dashboard_interrupted:
                    await asyncio.sleep(1)
                    continue
                result=await task;success=bool(result.get('success'));reported_inc=int(result.get('new_content_count') or 0) if success else 0
                if success:
                    failure_detail=''
                else:
                    failure_kind=str(result.get('failure_kind') or 'pipeline_failure').strip()
                    underlying_error=str(result.get('error') or result.get('reason') or '').strip()
                    failure_detail=(
                        f"{failure_kind}: {underlying_error}" if underlying_error else failure_kind
                    )[-2000:]
                finished=datetime.now().astimezone();inc=daily.mark_finished(key,success=success,count_increment=reported_inc,error=failure_detail,result=result,now=finished)
                real_success=bool(success and inc>0)
                maintenance=bool(success and (result.get('maintenance_only') or (inc==0 and result.get('pending_secondary')) or (inc==0 and reported_inc>0)))
                if real_success and result.get('pending_secondary'):
                    print(f"✅ {key}/{route_key} primary post counted @ {finished:%H:%M:%S} | new={inc} | secondary permalink/group retry remains pending")
                elif maintenance:
                    print(f"🧹 {key}/{route_key} maintenance finished @ {finished:%H:%M:%S} | new=0 | Today count unchanged")
                else:
                    print(f"{'✅' if real_success else '⚠️'} {key}/{route_key} finished @ {finished:%H:%M:%S} | new={inc} | actual rolling queue will recalculate now")
                # Telegram operator surface is read-only with respect to scheduler state.
                # Success/failure messages include friendly route/destination names and
                # the freshly recalculated next job. Maintenance/no-content waits stay quiet.
                if telegram.enabled and (real_success or (not success and str(result.get('failure_kind') or '') != 'no_new_content' and not result.get('transient_wait'))):
                    try:
                        after=daily.get(finished);live=rolling.live_status(after,finished);next_info=live.get('next')
                        crow=(after.get('categories') or {}).get(key) or {}
                        target_raw=crow.get('target_override')
                        target=int(target_raw if target_raw not in (None,'') else (crow.get('normal_target') or 0))
                        done=int(crow.get('already_posted') or 0)
                        if real_success:
                            await asyncio.to_thread(
                                telegram.notify_primary_success,
                                category=key,route_key=route_key,done=done,target=target,
                                result=result,job_id=job_id,finished_at=finished,next_info=next_info,
                            )
                        else:
                            cooldown=str(crow.get('failure_cooldown_until') or '')
                            await asyncio.to_thread(
                                telegram.notify_failure,
                                category=key,route_key=route_key,error=failure_detail,
                                job_id=job_id,finished_at=finished,cooldown_until=cooldown,next_info=next_info,
                            )
                    except Exception as notify_exc:
                        print(f"⚠️ Telegram notification skipped: {notify_exc}")
            except asyncio.CancelledError:
                # Usually a dashboard Clear/Skip. State was already released by the
                # control endpoint, so do not write a fake failure/cooldown.
                print(f"⏭️ {key}/{route_key} coroutine cancelled by queue control; scheduler will recalculate.")
            except Exception as exc:
                if 'task' in locals() and task is not None and not task.done():
                    print(f"🧯 Scheduler exception while {key}/{route_key} task is still live — cancelling orphan before queue release.")
                    task.cancel()
                    try:
                        await asyncio.wait_for(task,timeout=12.0)
                    except (asyncio.CancelledError,asyncio.TimeoutError,Exception):
                        pass
                finished=datetime.now().astimezone()
                try:
                    daily.mark_finished(key,success=False,count_increment=0,error=str(exc),now=finished)
                except Exception as state_finish_exc:
                    print(f"⚠️ TT state finish write failed after pipeline exception; no second fake failure will be created: {state_finish_exc}")
                print(f'❌ {key} failed @ {finished:%H:%M:%S}: {exc}')
                if telegram.enabled:
                    try:
                        after=daily.get(finished);live=rolling.live_status(after,finished);crow=(after.get('categories') or {}).get(key) or {}
                        await asyncio.to_thread(
                            telegram.notify_failure,
                            category=key,route_key=route_key,error=str(exc),job_id=job_id,finished_at=finished,
                            cooldown_until=str(crow.get('failure_cooldown_until') or ''),next_info=live.get('next'),
                        )
                    except Exception as notify_exc:
                        print(f"⚠️ Telegram exception notification skipped: {notify_exc}")
            # The rolling decision engine enforces inter_job_buffer_minutes using
            # the real last-finished timestamp. This short sleep is only polling relief.
            await asyncio.sleep(2)
    except KeyboardInterrupt:print('\n🛑 TT Master stopped by user.')
    finally:
        cleanup_task.cancel()
        try: await cleanup_task
        except asyncio.CancelledError: pass
        telegram.stop_command_listener()
        web_server.shutdown();web_server.server_close()

if __name__=='__main__':
    _instance_guard=_acquire_single_instance_guard('.')
    if _instance_guard is None:
        print('⛔ TT Master is already running for this project. Duplicate launch exits before Telegram/browser workers start.')
        raise SystemExit(2)
    try:
        asyncio.run(main())
    finally:
        _release_single_instance_guard(_instance_guard)
