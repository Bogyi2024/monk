from __future__ import annotations

import json
from pathlib import Path

ROUTES = Path("config/tt_master_routes.json")


def save(data):
    ROUTES.parent.mkdir(parents=True, exist_ok=True)
    ROUTES.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def main():
    if not ROUTES.exists():
        raise FileNotFoundError(f"{ROUTES} not found")
    data = json.loads(ROUTES.read_text(encoding="utf-8"))
    route = data.setdefault("storyboard_drama", {})

    print("\n🎭 Drama destination setup")
    old_fb = route.get("facebook", {}).get("page_id", "")
    fb = input(f"Facebook Page ID [{old_fb or 'skip'}] > ").strip()
    if not fb:
        fb = old_fb
    route.setdefault("facebook", {})["page_id"] = fb
    route["facebook"]["profile"] = route["facebook"].get("profile") or "Main_FB_Account"
    route["facebook"]["enabled"] = bool(fb)

    profiles_root = Path("browser_profiles")
    profiles = sorted(p.name for p in profiles_root.iterdir() if p.is_dir()) if profiles_root.exists() else []
    if profiles:
        print("\nTikTok profiles:")
        for i, name in enumerate(profiles, 1):
            print(f"  {i}. {name}")
    old_tt = route.get("tiktok", {}).get("profile", "")
    raw = input(f"TikTok profile/name [{old_tt or 'skip'}] > ").strip()
    tt = old_tt
    if raw.isdigit() and 1 <= int(raw) <= len(profiles):
        tt = profiles[int(raw)-1]
    elif raw:
        tt = raw
    route.setdefault("tiktok", {})["profile"] = tt
    route["tiktok"]["enabled"] = bool(tt)

    route["setup_complete"] = True
    save(data)
    print("\n✅ Saved → config/tt_master_routes.json")


if __name__ == "__main__":
    main()
