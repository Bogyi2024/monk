from __future__ import annotations

import json
import os
import py_compile
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path.cwd().resolve()
_env = str(os.getenv("TT_EPISODE_SPLITTER_DIR") or "").strip()
ES_ROOT = Path(_env).expanduser().resolve() if _env else (ROOT.parent / "episode_splitter").resolve()


def fail(msg: str) -> int:
    print(f"FAIL: {msg}")
    return 1


def main() -> int:
    checks = [
        ROOT / "bridges" / "episode_splitter_bridge.py",
        ROOT / "services" / "tt_pipeline_service.py",
        ROOT / "services" / "tt_daily_run_service.py",
        ROOT / "config" / "tt_categories.json",
        ES_ROOT / "run_episode_splitter.py",
        ES_ROOT / "tt_bridge_runner.py",
    ]
    for p in checks:
        if not p.exists():
            return fail(f"missing {p}")

    for p in [x for x in checks if x.suffix == ".py"]:
        py_compile.compile(str(p), doraise=True)

    cats = json.loads((ROOT / "config" / "tt_categories.json").read_text(encoding="utf-8"))
    cat = (cats.get("categories") or {}).get("episode_splitter")
    if not isinstance(cat, dict):
        return fail("episode_splitter category missing")
    routes = cat.get("routes") or {}
    if not routes:
        return fail("episode_splitter has no routes")

    # Ask the standalone runner to peek each mapped pool. Empty READY inventory is OK;
    # this verifies path/config/pool access without triggering a heavy render.
    for rk, route in routes.items():
        pool = str((route or {}).get("content_type") or rk)
        fd, name = tempfile.mkstemp(prefix="verify_es_", suffix=".json")
        os.close(fd)
        out = Path(name)
        try:
            cp = subprocess.run(
                [sys.executable, str(ES_ROOT / "tt_bridge_runner.py"), "peek", "--pool", pool, "--json-out", str(out)],
                cwd=str(ES_ROOT),
            )
            if cp.returncode != 0 or not out.exists():
                return fail(f"standalone peek failed for route={rk} pool={pool}")
            data = json.loads(out.read_text(encoding="utf-8"))
            if not data.get("ok"):
                return fail(f"standalone peek error for pool={pool}: {data.get('error')}")
            inv = data.get("inventory") or {}
            print(
                f"OK pool route {rk} -> {pool}: READY={inv.get('ready_parts',0)} "
                f"MIN={inv.get('min_ready_parts',0)} TARGET={inv.get('target_ready_parts',0)}"
            )
        finally:
            out.unlink(missing_ok=True)

    pipeline_text = (ROOT / "services" / "tt_pipeline_service.py").read_text(encoding="utf-8")
    daily_text = (ROOT / "services" / "tt_daily_run_service.py").read_text(encoding="utf-8")
    if "TTEpisodeSplitterBridge" not in pipeline_text or '"episode_splitter"' not in pipeline_text:
        return fail("episode_splitter pipeline dispatch missing")
    if "episode_splitter" not in daily_text or "LIVE_RUNNERS" not in daily_text:
        return fail("episode_splitter not registered in LIVE_RUNNERS")

    print("OK: TT Episode Splitter bridge integration surface is LIVE.")
    print("Routes are intentionally left disabled until Page/TikTok assignments are set in TT Web Manager.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
