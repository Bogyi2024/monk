from __future__ import annotations

import argparse
from datetime import datetime

from services.astrology_standalone_service import AstrologyStandaloneService


def main() -> None:
    ap = argparse.ArgumentParser(description="Astrology standalone test bundle writer")
    ap.add_argument("--date", default="", help="YYYY-MM-DD; default=today")
    args = ap.parse_args()
    when = datetime.strptime(args.date, "%Y-%m-%d") if args.date else datetime.now()
    svc = AstrologyStandaloneService()
    out = svc.export_test_bundle(when)
    print("🌙 Astrology standalone test bundle ready")
    print(f"📁 {out}")
    print("This test writes the posting plan + render contracts only.")
    print("No social upload and no paid generation are triggered in this standalone test.")


if __name__ == "__main__":
    main()
