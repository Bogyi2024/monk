from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path

from dotenv import load_dotenv

from services.story_narration_service import StoryNarrationService
from services.story_motion_video_service import StoryMotionVideoService


def newest_story_dir(root: Path) -> Path:
    candidates = [
        p for p in root.iterdir()
        if p.is_dir() and (p / "story.json").exists() and (p / "square").exists()
    ]
    if not candidates:
        raise FileNotFoundError(f"No Story Carousel outputs found under {root}")
    return max(candidates, key=lambda p: p.stat().st_mtime)


async def run(args: argparse.Namespace) -> None:
    load_dotenv()

    cfg_path = Path(args.config)
    config = json.loads(cfg_path.read_text(encoding="utf-8"))

    story_root = Path(args.story_root)
    story_dir = Path(args.story_dir) if args.story_dir else newest_story_dir(story_root)
    story_file = story_dir / "story.json"
    story = json.loads(story_file.read_text(encoding="utf-8"))

    print("\n" + "=" * 72)
    print("🎭 STORY BOARD DRAMA → NARRATED MOTION VIDEO TEST")
    print("=" * 72)
    print(f"📁 Story: {story_dir}")
    print(f"📖 Title: {story.get('title', '')}")
    print(f"🎙️ TTS: {config.get('tts_model')} / voice={config.get('tts_voice')}")
    print(f"🎵 Music pool: {config.get('music_root')}")
    print("=" * 72 + "\n")

    narration_file = story_dir / "narration_plan.json"
    if narration_file.exists() and not args.force_narration:
        narration = json.loads(narration_file.read_text(encoding="utf-8"))
        print(f"♻️ Reuse narration plan → {narration_file}")
    else:
        narration = await StoryNarrationService(config).create_plan(story)
        narration_file.write_text(
            json.dumps(narration, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        print(f"✅ Narration plan saved → {narration_file}")

    service = StoryMotionVideoService(config)
    report = await asyncio.to_thread(
        service.build,
        story_dir=story_dir,
        story=story,
        narration_plan=narration,
        force_tts=args.force_tts,
    )

    print("\n✅ TEST COMPLETE")
    print(json.dumps(report, ensure_ascii=False, indent=2))


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="config/story_video.json")
    p.add_argument("--story-root", default="outputs/story_carousel")
    p.add_argument("--story-dir", default="")
    p.add_argument("--force-narration", action="store_true")
    p.add_argument("--force-tts", action="store_true")
    return p.parse_args()


if __name__ == "__main__":
    asyncio.run(run(parse_args()))
