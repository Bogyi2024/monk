from __future__ import annotations

import asyncio
import inspect
import json
import os
import traceback
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from services.ai_service import AIService
from services.browser_service import BrowserService
from services.fb_group_service import auto_share_all_accounts, retry_incomplete_group_shares, get_share_accounts
from services.recap_source_service import RecapSourceService
from services.tt_service import upload_to_tiktok
from services.video_service import SourceDownloadError, VideoService
from services.voice_service import VoiceService
from services.whisper_service import NoUsableSpeechError, WhisperTimestampService
from services.storage_cleanup import cleanup_completed_jobs
from services.health_monitor import (
    finish_cycle_health,
    note_event,
    record_group_summary,
    record_stage,
    set_health_context,
    start_cycle_health,
)

load_dotenv()

CONFIG_PATH = os.getenv("RECAP_CONFIG_PATH", "config/recap_pages.json")


def load_config(path: str) -> dict[str, Any]:
    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Recap config မတွေ့ပါ: {config_path}")
    with config_path.open("r", encoding="utf-8") as f:
        config = json.load(f)
    if not config.get("pages"):
        raise ValueError("recap_pages.json ထဲမှာ pages မရှိပါ။")
    return config


def _parse_account_selection(raw: str, accounts: list[str]) -> list[str]:
    raw = (raw or "").strip()
    if not raw or raw.lower() in {"a", "all", "*"}:
        return list(accounts)
    if raw.lower() in {"n", "none", "0", "skip"}:
        return []

    chosen: list[str] = []
    tokens = [x.strip() for x in raw.split(",") if x.strip()]
    for token in tokens:
        # Accept exact account names too.
        if token in accounts:
            if token not in chosen:
                chosen.append(token)
            continue
        # Accept numeric ranges like 2-5.
        if "-" in token:
            try:
                left, right = token.split("-", 1)
                a, b = int(left), int(right)
                if a > b:
                    a, b = b, a
                for idx in range(a, b + 1):
                    if 1 <= idx <= len(accounts):
                        name = accounts[idx - 1]
                        if name not in chosen:
                            chosen.append(name)
                continue
            except Exception:
                pass
        # Accept a single numeric index.
        try:
            idx = int(token)
            if 1 <= idx <= len(accounts):
                name = accounts[idx - 1]
                if name not in chosen:
                    chosen.append(name)
        except Exception:
            pass
    return chosen


def choose_runtime_group_accounts(config: dict[str, Any]) -> list[str]:
    active = get_share_accounts(enabled_only=True)
    names = list(active.keys())
    if not names:
        print("👥 Enabled FB share account မရှိပါ။ ဒီ run မှာ group share skip လုပ်ပါမည်။")
        return []

    settings = config.get("facebook_group_share_runtime_selection") or {}
    prompt_on_start = bool(settings.get("prompt_on_start", True))
    default_mode = str(settings.get("default", "all")).strip().lower()

    print("\n👥 Facebook Group Share — ဒီ run အတွက် account ရွေးပါ")
    print("   (ဒီရွေးချယ်မှုက config ထဲ account enabled/disabled ကို မပြောင်းပါ)\n")
    for idx, name in enumerate(names, 1):
        cfg = active[name]
        note = str(cfg.get("note") or "").strip()
        note_text = f" | {note}" if note else ""
        print(f"  {idx}. {name}   groups={len(cfg.get('groups') or [])}{note_text}")

    if not prompt_on_start:
        selected = [] if default_mode == "none" else names
    else:
        print("\nရွေးနည်း: Enter/all = အကုန် | none/0 = မသုံး | 1,3,5-7 = ရွေးထားတာပဲ")
        try:
            raw = input("Share accounts > ").strip()
        except (EOFError, KeyboardInterrupt):
            raw = "" if default_mode != "none" else "none"
        if not raw:
            raw = "none" if default_mode == "none" else "all"
        selected = _parse_account_selection(raw, names)

    if selected:
        print("✅ ဒီ run မှာ group share သုံးမယ့် accounts:")
        for name in selected:
            print(f"   • {name}")
    else:
        print("⏭️ ဒီ run မှာ Facebook group auto-share ကို account အားလုံး skip လုပ်ထားပါတယ်။")
    return selected


def _parse_hhmm(value: str, default_hour: int, default_minute: int = 0) -> tuple[int, int]:
    raw = str(value or "").strip()
    try:
        hour_s, minute_s = raw.split(":", 1)
        hour = int(hour_s)
        minute = int(minute_s)
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            raise ValueError
        return hour, minute
    except Exception:
        return default_hour, default_minute


def _daily_window(config: dict[str, Any], now: datetime) -> tuple[datetime, datetime]:
    """Return today's local posting-window start/end using the PC's local clock."""
    window = config.get("posting_window") or {}
    start_h, start_m = _parse_hhmm(window.get("start", "09:00"), 9, 0)
    end_h, end_m = _parse_hhmm(window.get("end", "22:00"), 22, 0)
    start = now.replace(hour=start_h, minute=start_m, second=0, microsecond=0)
    end = now.replace(hour=end_h, minute=end_m, second=0, microsecond=0)
    if end <= start:
        raise ValueError("posting_window.end must be later than posting_window.start on the same day")
    return start, end


def _next_window_start(config: dict[str, Any], now: datetime) -> datetime:
    start, end = _daily_window(config, now)
    if now < start:
        return start
    return start + timedelta(days=1)


async def _sleep_until(target: datetime, label: str = "Next scan/post") -> None:
    seconds = max(0.0, (target - datetime.now()).total_seconds())
    print(f"😴 {label}: {target:%Y-%m-%d %H:%M:%S}")
    if seconds > 0:
        await asyncio.sleep(seconds)


def normalize_destinations(page_config: dict[str, Any]) -> list[dict[str, Any]]:
    raw = page_config.get("destinations")
    if isinstance(raw, list) and raw:
        destinations = [dict(item) for item in raw if isinstance(item, dict)]
    else:
        legacy = dict(page_config)
        legacy["platform"] = str(page_config.get("platform", "fb")).lower()
        destinations = [legacy]

    normalized: list[dict[str, Any]] = []
    stream_key = str(page_config["page_key"])
    for index, destination in enumerate(destinations, 1):
        if not destination.get("enabled", True):
            continue
        platform = str(destination.get("platform", "fb")).lower()
        if platform in {"facebook", "meta"}:
            platform = "fb"
        destination["platform"] = platform
        destination.setdefault("destination_key", f"{stream_key}_{platform}_{index}")
        normalized.append(destination)
    return normalized


def ensure_plan_title(plan: dict[str, Any], source_title: str = "") -> str:
    """Final defensive title fallback for render + FB/TikTok captions."""
    title = str(plan.get("title") or "").strip()
    if title:
        return title

    translated = str(plan.get("source_title_translation") or "").strip()
    source = str(source_title or "").strip()
    summary = str(plan.get("summary") or "").strip()

    if translated:
        title = translated
    elif source:
        title = source
    elif summary:
        # Do not slice Burmese by character count; keep the first natural sentence.
        import re as _re
        parts = [x.strip() for x in _re.split(r"(?<=[။!?])\s*", summary) if x.strip()]
        title = parts[0] if parts else summary
    else:
        title = "ဒီဇာတ်လမ်းမှာ ဘာတွေဖြစ်သွားတာလဲ"

    plan["title"] = title
    return title


def build_caption(plan: dict[str, Any], page_config: dict[str, Any], destination: dict[str, Any]) -> str:
    title = str(plan.get("title", "")).strip()
    body = str(plan.get("caption", "")).strip()
    prefix = str(destination.get("caption_prefix", "")).strip()
    suffix = str(destination.get("caption_suffix", "")).strip()

    fixed_hashtags = destination.get("hashtags", page_config.get("hashtags", []))
    if isinstance(fixed_hashtags, str):
        tags = fixed_hashtags.split()
    else:
        tags = [token for tag in fixed_hashtags for token in str(tag).split() if token]

    if destination.get("use_ai_hashtags", page_config.get("use_ai_hashtags", True)):
        tags.extend(str(tag).strip() for tag in (plan.get("hashtags") or []) if str(tag).strip())

    # Platform contract: never publish a hashtag wall. Facebook always carries
    # #viralreel and TikTok always carries #fyp, within the same five-tag cap.
    platform = str(destination.get("platform") or "").strip().lower()
    required_tag = "#viralreel" if platform in {"fb", "facebook", "meta"} else "#fyp" if platform in {"tt", "tiktok"} else ""
    normalized_tags: list[str] = []
    seen_tags: set[str] = set()
    if required_tag:
        normalized_tags.append(required_tag)
        seen_tags.add(required_tag.casefold())
    for raw in tags:
        tag = str(raw).strip()
        if not tag:
            continue
        tag = tag if tag.startswith("#") else f"#{tag}"
        key = tag.casefold()
        if key in seen_tags:
            continue
        seen_tags.add(key)
        normalized_tags.append(tag)
        if len(normalized_tags) >= 5:
            break
    tags = normalized_tags[:5]
    hashtag_text = " ".join(tags)

    parts = []
    if prefix:
        parts.append(prefix)
    if destination.get("include_title_in_caption", True) and title:
        parts.append(title)
    if body:
        parts.append(body)
    if suffix:
        parts.append(suffix)
    if hashtag_text:
        parts.append(hashtag_text)

    caption = "\n\n".join(parts).strip()
    max_chars = int(destination.get("caption_max_chars", 2200))
    if max_chars > 0 and len(caption) > max_chars:
        caption = caption[: max_chars - 1].rstrip() + "…"
    return caption


def build_group_share_text(plan: dict[str, Any], max_chars: int = 420) -> str:
    """Build a short, natural Facebook-group share text from the same Gemini plan.

    Keep the Reel preview attached separately; this text replaces the visible permalink
    after Facebook has generated the preview card.
    """
    title = str(plan.get("title", "")).strip()
    body = str(plan.get("caption", "")).strip()

    # Group posts look cleaner without a wall of hashtags. Keep only the story text.
    if body:
        body = " ".join(part for part in body.split() if not part.startswith("#")).strip()

    parts: list[str] = []
    if title:
        parts.append(title)
    if body and body != title:
        parts.append(body)

    value = "\n\n".join(parts).strip()
    if not value:
        value = title or "ဒီအပိုင်းလေးကို ကြည့်ကြည့်ပါ။"

    if max_chars > 0 and len(value) > max_chars:
        value = value[: max_chars - 1].rstrip() + "…"
    return value


def _file_is_ready(path: Path, minimum_size: int = 5_000) -> bool:
    return path.exists() and path.is_file() and path.stat().st_size >= minimum_size


def resolve_whisper_groups(
    plan: dict[str, Any],
    transcript: dict[str, Any],
    video_duration: float,
    coverage_mode: str = "full",
) -> list[dict[str, Any]]:
    """
    Convert Gemini's source_segment_ids back to exact local Whisper timestamps.

    Gemini is never trusted to invent start/end values.
    In full mode, boundaries are extended across silence/gaps so the whole source timeline
    from 0 -> video_duration is covered continuously.
    """
    source_segments = {int(seg["id"]): seg for seg in transcript.get("segments") or []}
    groups = []

    for group in plan.get("segments") or []:
        ids = [int(x) for x in group.get("source_segment_ids") or [] if int(x) in source_segments]
        ids = sorted(dict.fromkeys(ids))
        if not ids:
            continue
        if any(b != a + 1 for a, b in zip(ids, ids[1:])):
            raise ValueError(f"Non-consecutive Whisper IDs: {ids}")
        first = source_segments[ids[0]]
        last = source_segments[ids[-1]]
        narration = str(group.get("narration", "")).strip()
        if not narration:
            continue
        groups.append({
            "source_segment_ids": ids,
            "video_start": float(first["start"]),
            "video_end": float(last["end"]),
            "narration": narration,
            "visual_reason": str(group.get("reason", "")).strip(),
        })

    groups.sort(key=lambda x: x["video_start"])
    if not groups:
        raise RuntimeError("Resolved Whisper sync groups မရှိပါ။")

    coverage_mode = str(coverage_mode or "full").lower()
    if coverage_mode == "full":
        # Cover intro silence before first speech.
        groups[0]["video_start"] = 0.0

        # Split the silent gap between adjacent groups at its midpoint.
        # This keeps the original video continuous while preserving Whisper speech anchors.
        for idx in range(len(groups) - 1):
            left = groups[idx]
            right = groups[idx + 1]
            left_speech_end = float(left["video_end"])
            right_speech_start = float(right["video_start"])
            if right_speech_start >= left_speech_end:
                boundary = (left_speech_end + right_speech_start) / 2.0
            else:
                boundary = max(left_speech_end, right_speech_start)
            left["video_end"] = boundary
            right["video_start"] = boundary

        # Cover trailing silence/outro after last spoken line.
        groups[-1]["video_end"] = float(video_duration)

    cleaned = []
    previous_end = 0.0
    for group in groups:
        start = max(0.0, min(float(video_duration), float(group["video_start"])))
        end = max(start, min(float(video_duration), float(group["video_end"])))
        if coverage_mode == "full":
            start = previous_end
        if end - start < 0.15:
            continue
        cleaned.append({
            **group,
            "video_start": round(start, 3),
            "video_end": round(end, 3),
        })
        previous_end = end

    if coverage_mode == "full" and cleaned:
        cleaned[0]["video_start"] = 0.0
        cleaned[-1]["video_end"] = round(float(video_duration), 3)

    return cleaned


async def prepare_rendered_video(
    *,
    page_config: dict[str, Any],
    candidate: dict[str, Any],
    job_dir: Path,
    ai: AIService,
    video_svc: VideoService,
    voice_svc: VoiceService,
    whisper_svc: WhisperTimestampService,
) -> tuple[Path, dict[str, Any]]:
    raw_video = job_dir / "source.mp4"
    voice_audio = job_dir / "voice.m4a"
    final_video = job_dir / "final.mp4"
    transcript_file = job_dir / "whisper_transcript.json"
    plan_file = job_dir / "smart_sync_plan.json"

    force_rebuild = bool(page_config.get("force_rebuild", False))
    if not force_rebuild and _file_is_ready(final_video) and plan_file.exists():
        try:
            plan = json.loads(plan_file.read_text(encoding="utf-8"))
            ensure_plan_title(plan, str(candidate.get("title") or ""))
            print(f"♻️ Existing V5 render reuse: {final_video}")
            record_stage("DOWNLOAD", "reused", 0.0, detail="existing source/render reused")
            record_stage("GEMINI", "reused", 0.0, detail="existing smart_sync_plan reused")
            record_stage("RENDER", "reused", 0.0, detail=str(final_video))
            return final_video, plan
        except Exception as exc:
            print(f"⚠️ Existing plan ဖတ်မရလို့ ပြန် render မည်: {exc}")

    _download_started = time.perf_counter()
    try:
        await asyncio.to_thread(
            video_svc.download_video,
            candidate["url"],
            str(raw_video),
            candidate,
        )
        duration = await asyncio.to_thread(video_svc.get_media_duration, str(raw_video))
    except Exception as exc:
        record_stage("DOWNLOAD", "failed", time.perf_counter() - _download_started, detail=str(exc))
        raise
    else:
        record_stage(
            "DOWNLOAD",
            "ok",
            time.perf_counter() - _download_started,
            detail=str(raw_video),
            meta={"duration_s": round(duration, 3)},
        )

    # 1) LOCAL WHISPER = timing source of truth
    _whisper_started = time.perf_counter()
    transcript = await asyncio.to_thread(whisper_svc.transcribe, str(raw_video), duration)
    note_event(
        "whisper_complete",
        f"segments={len(transcript.get('segments') or [])}, language={transcript.get('language', '')}",
        duration_s=round(time.perf_counter() - _whisper_started, 3),
    )
    transcript["source_title"] = candidate.get("title", "")
    transcript_file.write_text(json.dumps(transcript, ensure_ascii=False, indent=2), encoding="utf-8")

    # 2) GEMINI = semantic grouping + Burmese narration/title only. No timestamps.
    coverage_mode = str(page_config.get("coverage_mode", "full")).lower()
    _gemini_started = time.perf_counter()
    try:
        plan = await ai.analyze_whisper_transcript_for_recap(
            transcript=transcript,
            source_title=candidate.get("title", ""),
            source_duration=duration,
            min_segments=int(page_config.get("min_segments", 10)),
            max_segments=int(page_config.get("max_segments", 14)),
            coverage_mode=coverage_mode,
            semantic_audit=bool(page_config.get("semantic_audit", True)),
            audit_rounds=int(page_config.get("semantic_audit_rounds", 2)),
            max_source_ids_per_group=int(page_config.get("max_source_ids_per_group", 3)),
        )
    except Exception as exc:
        record_stage("GEMINI", "failed", time.perf_counter() - _gemini_started, detail=str(exc))
        raise
    else:
        record_stage(
            "GEMINI",
            "ok",
            time.perf_counter() - _gemini_started,
            detail=f"groups={len(plan.get('groups') or plan.get('segments') or [])}",
        )

    audit_info = plan.get("semantic_audit") or {}
    if audit_info.get("enabled"):
        print(
            f"✅ V5 Lossless semantic audit: passed={audit_info.get('passed')} "
            f"rounds={audit_info.get('rounds_run')} rewrites={audit_info.get('rewrite_count')}"
        )

    # Final title guard: AI Burmese title -> source translation -> source title -> summary -> generic.
    ensure_plan_title(plan, str(candidate.get("title") or ""))

    # 3) Map Gemini IDs back to exact Whisper timestamps locally.
    plan["segments"] = resolve_whisper_groups(plan, transcript, duration, coverage_mode)
    plan["original_title"] = str(candidate.get("title") or "").strip()
    plan["source_duration"] = round(duration, 3)
    plan["whisper_backend"] = transcript.get("backend", "")
    plan["whisper_model"] = transcript.get("model", "")
    plan["whisper_language"] = transcript.get("language", "")

    # 4) TTS each resolved segment and get actual Burmese audio durations.
    _tts_started = time.perf_counter()
    voice_result = await voice_svc.create_segmented_voice(
        segments=plan["segments"],
        output_path=str(voice_audio),
        work_dir=str(job_dir / "tts_parts"),
    )
    note_event(
        "tts_complete",
        f"audio_duration={voice_result.get('audio_duration', 0)}",
        duration_s=round(time.perf_counter() - _tts_started, 3),
    )
    plan["actual_audio_duration"] = voice_result["audio_duration"]
    plan["sync_segments"] = voice_result["sync_segments"]
    plan["subtitle_segments"] = voice_result["subtitle_segments"]
    plan["script_text"] = voice_result["script_text"]
    plan["source"] = candidate

    plan_file.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")

    # AI-generated clickbait title can become the top overlay automatically.
    if page_config.get("use_ai_title_as_top_text", True):
        render_top_text = str(plan.get("title", "")).strip() or str(page_config.get("top_text", ""))
    else:
        render_top_text = str(page_config.get("top_text", ""))

    _render_started = time.perf_counter()
    try:
        render_kwargs = {
            "video_input": str(raw_video),
            "audio_input": str(voice_audio),
            "output_path": str(final_video),
            "caption_text": voice_result["script_text"],
            "logo_path": page_config.get("logo_path", "logo.png"),
            "logo_width": int(page_config.get("logo_width", 180)),
            "logo_x": int(page_config.get("logo_x", 50)),
            "logo_y": int(page_config.get("logo_y", 50)),
            "top_text": render_top_text,
            "bottom_text": page_config.get("bottom_text", ""),
            "output_ratio": page_config.get("output_ratio", "9:16"),
            "smart_sync": True,
            "sync_segments": voice_result["sync_segments"],
            "subtitle_segments": voice_result["subtitle_segments"],
            "subtitle_font_size": int(page_config.get("subtitle_font_size", 36)),
            "subtitle_y_fraction": float(page_config.get("subtitle_y_fraction", 0.85)),
            "mirror_video": bool(page_config.get("mirror_video", True)),
            "blur_original_subtitles": bool(page_config.get("blur_original_subtitles", True)),
            "max_video_speed": float(page_config.get("max_video_speed", 1.5)),
            "max_video_slow": float(page_config.get("max_video_slow", 1.35)),
        }
        # TT Master can still have the previous VideoService loaded in memory
        # while this scheduler module is reloaded for a Recap turn. Only send
        # the new option when that live renderer actually supports it.
        if "logo_opacity" in inspect.signature(video_svc.edit_video_with_audio).parameters:
            render_kwargs["logo_opacity"] = float(page_config.get("logo_opacity", 1.0))
        rendered = await asyncio.to_thread(
            video_svc.edit_video_with_audio,
            **render_kwargs,
        )
        if not rendered or not _file_is_ready(final_video):
            raise RuntimeError("Final render မအောင်မြင်ပါ။")
    except Exception as exc:
        record_stage("RENDER", "failed", time.perf_counter() - _render_started, detail=str(exc))
        raise
    else:
        record_stage(
            "RENDER",
            "ok",
            time.perf_counter() - _render_started,
            detail=str(final_video),
            meta={"file_size_mb": round(final_video.stat().st_size / (1024 * 1024), 2)},
        )
    return final_video, plan


async def upload_destination(
    *,
    destination: dict[str, Any],
    page_config: dict[str, Any],
    plan: dict[str, Any],
    final_video: Path,
    browser_svc: BrowserService,
) -> tuple[bool, str]:
    platform = destination["platform"]
    caption = build_caption(plan, page_config, destination)

    if platform == "fb":
        page_id = str(destination.get("page_id") or page_config.get("page_id") or "").strip()
        if not page_id:
            raise ValueError("Facebook destination မှာ page_id မရှိပါ။")
        profile_name = str(
            destination.get("browser_profile")
            or page_config.get("browser_profile")
            or "Main_FB_Account"
        )
        group_cfg = destination.get("group_share") or {}
        capture_permalink = bool(group_cfg.get("enabled", False))
        upload_result = await browser_svc.upload_reel_stealth(
            profile_name=profile_name,
            page_id=page_id,
            caption=caption,
            video_path=str(final_video),
            capture_permalink=capture_permalink,
        )
        if isinstance(upload_result, dict):
            success = bool(upload_result.get("success"))
            raw_post_link = str(upload_result.get("post_link") or "").strip()
        else:
            success = bool(upload_result)
            raw_post_link = ""

        # IMPORTANT: never save a Page URL or bare /reel route as a post permalink.
        # BrowserService V6.4 accepts only URLs containing a real Reel/video ID.
        post_link = browser_svc._normalize_fb_permalink(raw_post_link)
        if success and not post_link:
            # Defense in depth for older/custom BrowserService implementations:
            # Share-click without a newly verified Reel must never consume source
            # history or increment TT Master's completed count.
            print("❌ FB upload returned success without a verified Reel permalink; treating it as failed.")
            success = False
        return success, post_link

    if platform == "tiktok":
        profile_name = str(
            destination.get("profile_name")
            or destination.get("browser_profile")
            or "TikTok_Recapentertainment"
        )
        success = await upload_to_tiktok(
            profile_folder_name=profile_name,
            video_path=str(final_video),
            caption_text=caption,
            headless=bool(destination.get("headless", False)),
            proxy=destination.get("proxy"),
            timeout_ms=int(destination.get("upload_timeout_ms", 240_000)),
            content_check_wait_ms=int(destination.get("content_check_wait_ms", 600_000)),
            allow_post_while_content_checking=bool(destination.get("allow_post_while_content_checking", False)),
        )
        return success, str(destination.get("profile_url") or "")

    raise ValueError(f"Unsupported destination platform: {platform}")


async def process_one_page(
    page_config: dict[str, Any],
    global_config: dict[str, Any],
    ai: AIService,
    video_svc: VideoService,
    voice_svc: VoiceService,
    whisper_svc: WhisperTimestampService,
    browser_svc: BrowserService,
    runtime_group_accounts: list[str],
    _soft_skip_depth: int = 0,
    _download_skip_depth: int = 0,
    _platform_skip_counts: dict[str, int] | None = None,
) -> bool:
    stream_key = str(page_config["page_key"])
    set_health_context(page_key=stream_key, destination_key="")
    source_file = str(page_config["source_file"])
    destinations = normalize_destinations(page_config)
    if not destinations:
        print(f"⚠️ [{stream_key}] Enabled destination မရှိပါ။")
        return False

    destination_map = {str(item["destination_key"]): item for item in destinations}
    destination_keys = list(destination_map)

    source_svc = RecapSourceService(
        registry_path=global_config.get("registry_path", "downloads/recap_source_registry.json"),
        playlist_limit=int(global_config.get("playlist_limit", 30)),
    )
    channel_urls = source_svc.load_channel_urls(source_file)
    if not channel_urls:
        print(f"⚠️ [{stream_key}] Source channel URL မရှိပါ: {source_file}")
        return False

    platform_order = [
        str(x).strip().lower()
        for x in (global_config.get("source_platform_priority") or ["youtube", "tiktok", "other"])
        if str(x).strip()
    ]
    configured_platforms = list(dict.fromkeys(
        source_svc._platform(url) for url in channel_urls
    ))
    platform_order = list(dict.fromkeys(platform_order + configured_platforms))
    platform_skip_counts = dict(_platform_skip_counts or {})
    per_platform_limit = max(1, int(global_config.get("max_source_soft_skips_per_platform", 5) or 5))
    active_platforms = [
        platform for platform in platform_order
        if platform in configured_platforms and int(platform_skip_counts.get(platform, 0)) < per_platform_limit
    ]
    if not active_platforms:
        print(f"😴 [{stream_key}] YouTube/TikTok source attempts exhausted; this route cycle ends as no-work.")
        return False

    scan_result = await asyncio.to_thread(source_svc.scan_channels, channel_urls)
    inventory = source_svc.inventory_for_sources(channel_urls, scan_result["inventory"])
    candidate = source_svc.choose_candidate(
        page_key=stream_key,
        inventory=inventory,
        new_video_ids=scan_result["new_video_ids"],
        max_failures=int(global_config.get("max_failures_per_video", 3)),
        destination_keys=destination_keys,
        retry_max_age_hours=float(global_config.get("destination_retry_max_age_hours", 24)),
        source_platform_order=platform_order,
        allowed_source_platforms=active_platforms,
    )
    if (
        not candidate
        and bool(global_config.get("deep_source_scan_on_exhaustion", True))
        and source_svc.deep_scan_due(
            channel_urls,
            max_age_hours=float(global_config.get("deep_source_scan_interval_hours", 24)),
        )
    ):
        deep_limit = int(global_config.get("deep_source_scan_limit", 0) or 0)
        scope = "channel end" if deep_limit <= 0 else f"{deep_limit} items/source"
        print(f"🧭 [{stream_key}] Shallow inventory exhausted — deep source scan → {scope}")
        deep_result = await asyncio.to_thread(
            source_svc.scan_channels,
            channel_urls,
            playlist_limit=deep_limit,
        )
        inventory = source_svc.inventory_for_sources(channel_urls, deep_result["inventory"])
        candidate = source_svc.choose_candidate(
            page_key=stream_key,
            inventory=inventory,
            new_video_ids=deep_result["new_video_ids"],
            max_failures=int(global_config.get("max_failures_per_video", 3)),
            destination_keys=destination_keys,
            retry_max_age_hours=float(global_config.get("destination_retry_max_age_hours", 24)),
            source_platform_order=platform_order,
            allowed_source_platforms=active_platforms,
        )
    if not candidate:
        print(
            f"😴 [{stream_key}] Shallow + saved deep inventory ထဲမှာ "
            "တကယ်အသုံးပြုလို့ရတဲ့ unposted video မကျန်တော့ပါ။"
        )
        return False

    # Flat channel scans normally include the real YouTube title. If a selected
    # candidate has no title, refresh metadata for only that video before Gemini.
    candidate = await asyncio.to_thread(source_svc.ensure_candidate_metadata, candidate)

    source_svc.reserve(stream_key, candidate)
    video_id = candidate["video_id"]
    pending_keys = [
        key for key in candidate.get("pending_destinations", destination_keys)
        if key in destination_map
    ]
    print(
        f"🎯 [{stream_key}] Selected {candidate.get('selection_reason')}: "
        f"{candidate.get('channel_name')} → {candidate.get('title') or '[title unavailable — transcript fallback]'} ({video_id})"
    )
    print(f"📤 Pending destinations: {', '.join(pending_keys)}")
    note_event(
        "candidate_selected",
        str(candidate.get("title") or ""),
        video_id=video_id,
        channel_name=str(candidate.get("channel_name") or ""),
        pending_destinations=list(pending_keys),
    )

    job_dir = Path(global_config.get("job_root", "downloads/recap_jobs")) / stream_key / video_id
    job_dir.mkdir(parents=True, exist_ok=True)

    try:
        final_video, plan = await prepare_rendered_video(
            page_config=page_config,
            candidate=candidate,
            job_dir=job_dir,
            ai=ai,
            video_svc=video_svc,
            voice_svc=voice_svc,
            whisper_svc=whisper_svc,
        )
        source_svc.clear_source_download_failure(candidate)
        print(f"🏷️ Source title: {candidate.get('title') or '[not available]'}")
        print(f"🧲 Final Burmese title: {plan.get('title', '')}")
    except SourceDownloadError as exc:
        # Source transport/auth problem: posting never started, so FB/TikTok
        # destination failure counters must remain untouched. Cool down only this
        # source and immediately try another eligible candidate in the same cycle.
        source_svc.mark_source_download_failed(stream_key, candidate, str(exc))
        source_svc.release_reservation(stream_key, candidate)
        source_platform = str(candidate.get("source_platform") or source_svc._platform(candidate.get("url") or "") or "other")
        platform_skip_counts[source_platform] = int(platform_skip_counts.get(source_platform, 0)) + 1
        print(
            f"⏭️ [{stream_key}] SOURCE_DOWNLOAD soft-skip → {video_id} "
            f"({source_platform} {platform_skip_counts[source_platform]}/{per_platform_limit}); destination failure counters NOT incremented."
        )
        note_event(
            "source_download_soft_skip",
            str(exc),
            video_id=video_id,
            soft_skip_depth=_download_skip_depth + 1,
        )
        if platform_skip_counts[source_platform] >= per_platform_limit:
            remaining = [p for p in active_platforms if p != source_platform]
            if remaining:
                print(f"🔄 [{stream_key}] {source_platform} source budget exhausted — switching to {remaining[0]}.")
        return await process_one_page(
            page_config=page_config,
            global_config=global_config,
            ai=ai,
            video_svc=video_svc,
            voice_svc=voice_svc,
            whisper_svc=whisper_svc,
            browser_svc=browser_svc,
            runtime_group_accounts=runtime_group_accounts,
            _soft_skip_depth=_soft_skip_depth,
            _download_skip_depth=_download_skip_depth + 1,
            _platform_skip_counts=platform_skip_counts,
        )
    except NoUsableSpeechError as exc:
        # Content suitability problem, NOT a scheduler/browser/API failure.
        # Quarantine this source globally, leave destination failure counters untouched,
        # release reservation, and immediately try the next candidate.
        source_svc.mark_source_unsuitable(stream_key, candidate, str(exc))
        source_svc.release_reservation(stream_key, candidate)
        source_platform = str(candidate.get("source_platform") or source_svc._platform(candidate.get("url") or "") or "other")
        platform_skip_counts[source_platform] = int(platform_skip_counts.get(source_platform, 0)) + 1
        print(
            f"⏭️ [{stream_key}] NO_USABLE_SPEECH soft-skip → {video_id} "
            f"({source_platform} {platform_skip_counts[source_platform]}/{per_platform_limit}); destination failure/cooldown NOT incremented."
        )
        note_event(
            "source_soft_skip",
            str(exc),
            video_id=video_id,
            soft_skip_depth=_soft_skip_depth + 1,
        )
        if platform_skip_counts[source_platform] >= per_platform_limit:
            remaining = [p for p in active_platforms if p != source_platform]
            if remaining:
                print(f"🔄 [{stream_key}] {source_platform} speech budget exhausted — switching to {remaining[0]}.")
        return await process_one_page(
            page_config=page_config,
            global_config=global_config,
            ai=ai,
            video_svc=video_svc,
            voice_svc=voice_svc,
            whisper_svc=whisper_svc,
            browser_svc=browser_svc,
            runtime_group_accounts=runtime_group_accounts,
            _soft_skip_depth=_soft_skip_depth + 1,
            _download_skip_depth=_download_skip_depth,
            _platform_skip_counts=platform_skip_counts,
        )
    except Exception as exc:
        for destination_key in pending_keys:
            source_svc.mark_destination_failed(stream_key, destination_key, candidate, str(exc))
        source_svc.release_reservation(stream_key, candidate)
        print(f"❌ [{stream_key}] Processing failed: {exc}")
        traceback.print_exc()
        return False

    any_success = False
    for destination_key in pending_keys:
        destination = destination_map[destination_key]
        platform = destination["platform"]
        set_health_context(page_key=stream_key, destination_key=destination_key)
        _upload_stage = "FB" if platform == "fb" else "TT" if platform == "tiktok" else platform.upper()
        _upload_started = time.perf_counter()
        _upload_stage_recorded = False
        try:
            print(f"\n📤 [{stream_key}] Upload → {destination_key} ({platform})")
            success, post_link = await upload_destination(
                destination=destination,
                page_config=page_config,
                plan=plan,
                final_video=final_video,
                browser_svc=browser_svc,
            )
            if not success:
                record_stage(
                    _upload_stage,
                    "failed",
                    time.perf_counter() - _upload_started,
                    detail=f"{platform} upload function returned False",
                )
                _upload_stage_recorded = True
                raise RuntimeError(f"{platform} upload function returned False")
            record_stage(
                _upload_stage,
                "ok",
                time.perf_counter() - _upload_started,
                detail=post_link or destination_key,
            )
            _upload_stage_recorded = True
            source_svc.mark_destination_posted(
                page_key=stream_key,
                destination_key=destination_key,
                candidate=candidate,
                post_link=post_link,
                output_path=str(final_video),
                platform=platform,
            )
            any_success = True
            print(f"✅ [{destination_key}] Upload complete")

            # Facebook group-sharing is a secondary job. Mark the Page upload
            # successful FIRST so a group failure can never cause a duplicate
            # Page Reel on the next scheduler cycle.
            if platform == "fb":
                group_cfg = destination.get("group_share") or {}
                if bool(group_cfg.get("enabled", False)):
                    if "/reel/" in post_link or "/videos/" in post_link or "fb.watch" in post_link:
                        try:
                            print(f"\n👥 Auto group-share start → {post_link}")
                            configured_accounts = group_cfg.get("accounts")
                            if configured_accounts:
                                allowed = set(runtime_group_accounts)
                                selected_accounts = [n for n in configured_accounts if n in allowed]
                            else:
                                selected_accounts = list(runtime_group_accounts)

                            if not selected_accounts:
                                print("⏭️ ဒီ run account selection အရ Facebook group share skip လုပ်ထားပါတယ်။")
                            else:
                                group_share_text = build_group_share_text(
                                    plan,
                                    max_chars=int(group_cfg.get("share_text_max_chars", 420)),
                                )
                                print(f"📝 Group share text: {group_share_text[:120]}{'…' if len(group_share_text) > 120 else ''}")
                                group_result = await auto_share_all_accounts(
                                    post_link,
                                    account_names=selected_accounts,
                                    share_text=group_share_text,
                                    headless=bool(group_cfg.get("headless", False)),
                                    delay_between_groups_seconds=float(group_cfg.get("delay_between_groups_seconds", 20)),
                                    delay_between_accounts_seconds=float(group_cfg.get("delay_between_accounts_seconds", 120)),
                                )
                                record_group_summary(group_result, current=True, post_link=post_link)
                        except Exception as group_exc:
                            # Do NOT fail the Facebook destination here. The group
                            # registry remembers successful groups and retries only
                            # the remaining groups on a later cycle.
                            print(f"⚠️ Facebook Reel တက်ပြီးပါပြီ၊ group share မှာ error: {group_exc}")
                    else:
                        print(
                            "⚠️ Facebook Reel တက်ပြီးပေမယ့် actual Reel permalink မရသေးလို့ "
                            "group auto-share ကို ဒီ cycle မှာ skip လုပ်ထားပါတယ်။"
                        )
        except Exception as exc:
            if not _upload_stage_recorded:
                record_stage(
                    _upload_stage,
                    "failed",
                    time.perf_counter() - _upload_started,
                    detail=str(exc),
                )
            source_svc.mark_destination_failed(stream_key, destination_key, candidate, str(exc))
            print(f"❌ [{destination_key}] Upload failed: {exc}")
            traceback.print_exc()

        await asyncio.sleep(float(global_config.get("delay_between_destinations_seconds", 20)))

    source_svc.release_reservation(stream_key, candidate)
    return any_success


async def run_cycle(
    config: dict[str, Any],
    *,
    ai: AIService,
    video_svc: VideoService,
    voice_svc: VoiceService,
    whisper_svc: WhisperTimestampService,
    browser_svc: BrowserService,
    runtime_group_accounts: list[str],
) -> None:
    # Retry interrupted/partially completed Facebook group shares first.
    # The group registry skips groups that were already shared successfully.
    group_defaults = config.get("facebook_group_share_retry") or {}
    if bool(group_defaults.get("enabled", True)):
        try:
            recovery_results = await retry_incomplete_group_shares(
                account_names=runtime_group_accounts,
                headless=bool(group_defaults.get("headless", False)),
                delay_between_groups_seconds=float(group_defaults.get("delay_between_groups_seconds", 20)),
                delay_between_accounts_seconds=float(group_defaults.get("delay_between_accounts_seconds", 120)),
                limit_posts=int(group_defaults.get("limit_posts_per_cycle", 2)),
            )
            for recovery_result in recovery_results or []:
                record_group_summary(recovery_result, current=False, post_link=str(recovery_result.get("post_link") or ""))
        except Exception as group_retry_exc:
            print(f"⚠️ Pending group-share retry error: {group_retry_exc}")

    enabled_pages = [page for page in config["pages"] if page.get("enabled", True)]
    for page_config in enabled_pages:
        await process_one_page(
            page_config=page_config,
            global_config=config,
            ai=ai,
            video_svc=video_svc,
            voice_svc=voice_svc,
            whisper_svc=whisper_svc,
            browser_svc=browser_svc,
            runtime_group_accounts=runtime_group_accounts,
        )
        await asyncio.sleep(float(config.get("delay_between_pages_seconds", 30)))


async def main() -> None:
    config = load_config(CONFIG_PATH)
    # Snapshot the account set once per scheduler run. Restart scheduler to choose a different set.
    runtime_group_accounts = choose_runtime_group_accounts(config)

    # Services live across cycles; Whisper model loads only once.
    ai = AIService()
    video_svc = VideoService(
        subtitle_font_size=int(config.get("default_subtitle_font_size", 36)),
        subtitle_y_fraction=float(config.get("default_subtitle_y_fraction", 0.85)),
    )
    voice_svc = VoiceService(
        ffmpeg_path=video_svc.ffmpeg_path,
        ffprobe_path=video_svc.ffprobe_path,
    )
    whisper_svc = WhisperTimestampService(
        model_size=str(config.get("whisper_model", os.getenv("WHISPER_MODEL", "medium"))),
        backend=str(config.get("whisper_backend", os.getenv("WHISPER_BACKEND", "auto"))),
        device=str(config.get("whisper_device", os.getenv("WHISPER_DEVICE", "cuda"))),
        compute_type=str(config.get("whisper_compute_type", os.getenv("WHISPER_COMPUTE_TYPE", "float16"))),
        language=config.get("whisper_language") or None,
    )
    browser_svc = BrowserService()

    print("🚀 Personal Recap Auto Scheduler V5.3 — Day Window + No Catch-up + Persistent History")
    print("🎙️ Timestamp source: LOCAL WHISPER (Gemini cannot alter timestamps)")
    window_cfg = config.get("posting_window") or {}
    print(
        f"🕘 Posting window: {window_cfg.get('start', '09:00')} → {window_cfg.get('end', '22:00')} "
        f"(PC local time), interval={float(config.get('interval_hours', 2)):g}h"
    )
    print("♻️ Restart behavior: active window အတွင်းဆို ချက်ချင်းစ; missed cycles catch-up မလုပ်ပါ။")
    print(f"🧾 Persistent post history: {config.get('registry_path', 'downloads/recap_source_registry.json')}")

    while True:
        # Reload on every loop so schedule/config edits can take effect without code changes.
        config = load_config(CONFIG_PATH)
        now = datetime.now()
        window_start, window_end = _daily_window(config, now)

        # No new post outside 09:00–22:00. At 22:00 or later, wait for next day's 09:00.
        if now < window_start or now >= window_end:
            next_start = _next_window_start(config, now)
            print(
                f"🌙 Posting window ပိတ်ထားပါသည် ({window_start:%H:%M}–{window_end:%H:%M}). "
                "ညဘက် catch-up post မတင်ပါ။"
            )
            await _sleep_until(next_start, label="Next day window opens")
            continue

        # Startup/restart within the active window intentionally runs immediately.
        cycle_started = datetime.now()
        print(f"\n🔄 Recap cycle start: {cycle_started:%Y-%m-%d %H:%M:%S}")
        health_cfg = config.get("health_monitor") or {}
        start_cycle_health(
            cycle_started=cycle_started,
            output_root=str(health_cfg.get("output_dir", "downloads/health")),
        )
        _cycle_error = ""
        try:
            await run_cycle(
                config,
                ai=ai,
                video_svc=video_svc,
                voice_svc=voice_svc,
                whisper_svc=whisper_svc,
                browser_svc=browser_svc,
                runtime_group_accounts=runtime_group_accounts,
            )
        except Exception as exc:
            _cycle_error = str(exc)
            print(f"❌ Cycle-level error: {exc}")
            traceback.print_exc()
        finally:
            # Storage safety: only terminal jobs older than the retention window are removed.
            # Registries/history are preserved, so deleted media can never make an old source
            # look unposted again. Cleanup failure must never fail the posting cycle.
            _cleanup_started = time.perf_counter()
            try:
                cleanup_result = await asyncio.to_thread(cleanup_completed_jobs, config)
                note_event(
                    "storage_cleanup",
                    f"deleted={int(cleanup_result.get('deleted_jobs', 0) or 0)}, "
                    f"freed={cleanup_result.get('freed_human', '0B')}",
                    **cleanup_result,
                )
                record_stage(
                    "CLEANUP",
                    "ok",
                    time.perf_counter() - _cleanup_started,
                    detail=(
                        f"deleted={int(cleanup_result.get('deleted_jobs', 0) or 0)}; "
                        f"freed={cleanup_result.get('freed_human', '0B')}"
                    ),
                    meta=cleanup_result,
                )
            except Exception as cleanup_exc:
                record_stage(
                    "CLEANUP",
                    "failed",
                    time.perf_counter() - _cleanup_started,
                    detail=str(cleanup_exc),
                )
                note_event("storage_cleanup_error", str(cleanup_exc))
                print(f"⚠️ Storage cleanup error (posting cycle unaffected): {cleanup_exc}")

            finish_cycle_health(cycle_error=_cycle_error)

        interval_hours = float(config.get("interval_hours", 2))
        interval_seconds = max(300.0, interval_hours * 3600.0)
        finished_at = datetime.now()

        # Normal cadence is based on this run's start. If a render/upload itself takes
        # longer than the interval, do NOT fire catch-up cycles immediately: restart the
        # cadence from 'now' instead.
        next_run = cycle_started + timedelta(seconds=interval_seconds)
        if next_run <= finished_at:
            next_run = finished_at + timedelta(seconds=interval_seconds)

        # Never start a fresh cycle at/after the daily close. Sleep through the night.
        _start_today, end_today = _daily_window(config, cycle_started)
        if next_run >= end_today:
            next_run = _next_window_start(config, finished_at)
            print("🌙 ဒီနေ့အတွက် posting ပြီးပါပြီ။ ညဘက် post မတင်တော့ပါ။")
            await _sleep_until(next_run, label="Tomorrow first scan/post")
            continue

        await _sleep_until(next_run)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Recap scheduler ကို user ရပ်လိုက်ပါပြီ။")
