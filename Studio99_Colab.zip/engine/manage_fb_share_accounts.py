from __future__ import annotations

import asyncio
import json
import re
import shutil
from datetime import datetime
from pathlib import Path

from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / "config" / "fb_share_accounts.json"
PROFILES = ROOT / "browser_profiles"
PROXY = None  # OS network / external VPN


def load_config() -> dict:
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    if not CONFIG.exists():
        data = {"version": 1, "accounts": []}
        save_config(data)
        return data
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
        data.setdefault("accounts", [])
        return data
    except Exception as exc:
        raise SystemExit(f"Config ဖတ်မရပါ: {CONFIG}\n{exc}")


def save_config(data: dict) -> None:
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(CONFIG)


def account_sort_key(acc_or_name):
    name = acc_or_name if isinstance(acc_or_name, str) else str(acc_or_name.get("name", ""))
    m = re.search(r"(\d+)$", name)
    return (0, int(m.group(1))) if m else (1, name.lower())


def account_by_name(data: dict, name: str) -> dict | None:
    for acc in data["accounts"]:
        if acc.get("name") == name:
            return acc
    return None


def next_account_name(data: dict) -> str:
    used = {str(a.get("name", "")) for a in data["accounts"]}
    n = 1
    while f"FB_Share_Acc_{n}" in used:
        n += 1
    return f"FB_Share_Acc_{n}"


def normalize_group_url(raw: str) -> str:
    url = raw.strip()
    if not url:
        return ""
    if url.isdigit():
        return f"https://www.facebook.com/groups/{url}/"
    if "facebook.com/groups/" not in url:
        return ""
    return url.split("?")[0].rstrip("/") + "/"


def list_accounts(data: dict) -> None:
    data["accounts"].sort(key=account_sort_key)
    print("\n========== FB SHARE ACCOUNTS ==========")
    if not data["accounts"]:
        print("(အကောင့်မရှိသေးပါ)")
        return
    for i, acc in enumerate(data["accounts"], 1):
        name = acc.get("name")
        enabled = "ON " if acc.get("enabled", True) else "OFF"
        folder = acc.get("profile_folder") or name
        exists = "✅" if (PROFILES / folder).exists() else "❌"
        groups = len(acc.get("groups") or [])
        note = str(acc.get("note", "")).strip()
        note_display = f" | {note}" if note else ""
        print(f"{i:>2}. [{enabled}] {name:<18} profile={exists} groups={groups}{note_display}")
    print("=======================================\n")


def import_existing_profiles(data: dict) -> int:
    PROFILES.mkdir(parents=True, exist_ok=True)
    added = 0
    folders = sorted(
        [p for p in PROFILES.iterdir() if p.is_dir() and p.name.startswith("FB_Share_Acc_")],
        key=lambda p: account_sort_key(p.name),
    )
    for folder in folders:
        if account_by_name(data, folder.name):
            continue
        data["accounts"].append({
            "name": folder.name,
            "profile_folder": folder.name,
            "enabled": True,
            "groups": [],
            "note": "auto-imported existing profile",
        })
        added += 1
    if added:
        data["accounts"].sort(key=account_sort_key)
        save_config(data)
    return added


async def login_profile(acc: dict) -> None:
    folder = str(acc.get("profile_folder") or acc["name"])
    path = PROFILES / folder
    path.mkdir(parents=True, exist_ok=True)
    print(f"\n🌐 Login/Re-login: {acc['name']} → {path}")
    print("Network: System / external VPN")
    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=str(path),
            headless=False,
            proxy=None,
            args=["--disable-notifications", "--disable-blink-features=AutomationControlled"],
        )
        page = context.pages[0] if context.pages else await context.new_page()
        await page.goto("https://www.facebook.com/", timeout=90_000, wait_until="domcontentloaded")
        print("✅ Browser ပွင့်ပြီ။ Account ကို login ဝင်/စစ်ပါ။")
        input("Login ပြီးပြီဆို ENTER နှိပ်ပါ (browser ကို manager ကပိတ်မယ်)... ")
        await context.close()


def add_account(data: dict) -> None:
    default = next_account_name(data)
    name = input(f"Account slot name [{default}]: ").strip() or default
    if account_by_name(data, name):
        print("❌ ဒီ account name ရှိပြီးသားပါ")
        return
    folder = input(f"Profile folder [{name}]: ").strip() or name
    acc = {"name": name, "profile_folder": folder, "enabled": True, "groups": [], "note": ""}
    data["accounts"].append(acc)
    data["accounts"].sort(key=account_sort_key)
    save_config(data)
    print(f"✅ Added: {name}")
    yn = input("အခုတစ်ခါတည်း Facebook login ဝင်မလား? [Y/n]: ").strip().lower()
    if yn not in {"n", "no"}:
        asyncio.run(login_profile(acc))


def choose_account(data: dict, prompt: str = "Account no/name: ") -> dict | None:
    data["accounts"].sort(key=account_sort_key)
    list_accounts(data)
    value = input(prompt).strip()
    if not value:
        return None
    if value.isdigit():
        idx = int(value) - 1
        if 0 <= idx < len(data["accounts"]):
            return data["accounts"][idx]
    acc = account_by_name(data, value)
    if not acc:
        print("❌ Account မတွေ့ပါ")
    return acc


def parse_index_selection(raw: str, max_index: int) -> list[int]:
    result: set[int] = set()
    for part in raw.replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            if a.isdigit() and b.isdigit():
                start, end = sorted((int(a), int(b)))
                for n in range(start, end + 1):
                    if 1 <= n <= max_index:
                        result.add(n)
        elif part.isdigit():
            n = int(part)
            if 1 <= n <= max_index:
                result.add(n)
    return sorted(result)


def add_group_links(data: dict, acc: dict) -> None:
    groups = acc.setdefault("groups", [])
    print("\nGroup links ထည့်ပါ။")
    print("• တစ်ကြောင်းချင်း paste လုပ်နိုင်ပါတယ်")
    print("• Numeric group ID ပဲထည့်လည်းရပါတယ်")
    print("• အလွတ် ENTER နှိပ်ရင်ပြီးပါပြီ\n")
    added = 0
    while True:
        raw = input("Group URL/ID: ").strip()
        if not raw:
            break
        # allow multiple links pasted with whitespace on one line
        candidates = [x for x in re.split(r"\s+", raw) if x]
        for item in candidates:
            url = normalize_group_url(item)
            if not url:
                print(f"  ❌ Invalid: {item}")
                continue
            if url in groups:
                print(f"  ⏭️ Already exists: {url}")
                continue
            groups.append(url)
            added += 1
            print(f"  ✅ Added: {url}")
    if added:
        save_config(data)
    print(f"✅ Added {added} group(s). Total={len(groups)}")


def remove_group_links(data: dict, acc: dict) -> None:
    groups = acc.setdefault("groups", [])
    if not groups:
        print("(ဒီ account မှာ group မရှိသေးပါ)")
        return
    print(f"\n👥 {acc['name']} groups ({len(groups)}):")
    for i, url in enumerate(groups, 1):
        print(f" {i:>2}. {url}")
    raw = input("Remove no. (ဥပမာ 2 သို့ 1,3,5-7) [blank=cancel]: ").strip()
    if not raw:
        return
    indexes = parse_index_selection(raw, len(groups))
    if not indexes:
        print("❌ Valid group number မတွေ့ပါ")
        return
    print("ဖျက်မယ့် group(s):")
    for idx in indexes:
        print(f" - {idx}. {groups[idx - 1]}")
    if input("Confirm remove? [y/N]: ").strip().lower() not in {"y", "yes"}:
        print("Cancelled")
        return
    for idx in reversed(indexes):
        groups.pop(idx - 1)
    save_config(data)
    print(f"✅ Removed {len(indexes)} group(s). Total={len(groups)}")


def edit_note_for_account(data: dict, acc: dict) -> None:
    current = str(acc.get("note", ""))
    print(f"Current note: {current or '(empty)'}")
    new = input("New note (blank = clear note): ").strip()
    acc["note"] = new
    save_config(data)
    print("✅ Note saved")


def show_account_detail(acc: dict) -> None:
    folder = str(acc.get("profile_folder") or acc.get("name"))
    groups = acc.get("groups") or []
    print("\n--------------------------------------------")
    print(f"Account : {acc.get('name')}")
    print(f"Status  : {'ENABLED' if acc.get('enabled', True) else 'DISABLED'}")
    print(f"Profile : {folder} {'✅' if (PROFILES / folder).exists() else '❌'}")
    print(f"Note    : {acc.get('note') or '(empty)'}")
    print(f"Groups  : {len(groups)}")
    if groups:
        for i, url in enumerate(groups, 1):
            print(f"  {i:>2}. {url}")
    else:
        print("  (group list empty)")
    print("--------------------------------------------")


def account_details_submenu(data: dict) -> None:
    """Menu 8: choose account first, then manage its own groups/note in one place."""
    while True:
        acc = choose_account(data, "Manage လုပ်မယ့် account no/name [blank=back]: ")
        if not acc:
            return

        while True:
            show_account_detail(acc)
            print("\n===== ACCOUNT DETAIL MENU =====")
            print("1. Add group link(s)")
            print("2. Remove group link(s)")
            print("3. Edit account note")
            print("4. Enable / disable this account")
            print("5. Login / re-login this account")
            print("6. Choose another account")
            print("0. Back to main menu")
            choice = input("Choose: ").strip()

            if choice == "1":
                add_group_links(data, acc)
            elif choice == "2":
                remove_group_links(data, acc)
            elif choice == "3":
                edit_note_for_account(data, acc)
            elif choice == "4":
                acc["enabled"] = not bool(acc.get("enabled", True))
                save_config(data)
                print(f"✅ {acc['name']} = {'ENABLED' if acc['enabled'] else 'DISABLED'}")
            elif choice == "5":
                asyncio.run(login_profile(acc))
            elif choice == "6":
                break
            elif choice == "0":
                return
            else:
                print("❌ Unknown option")


def toggle_account(data: dict) -> None:
    acc = choose_account(data)
    if not acc:
        return
    acc["enabled"] = not bool(acc.get("enabled", True))
    save_config(data)
    print(f"✅ {acc['name']} = {'ENABLED' if acc['enabled'] else 'DISABLED'}")


def relogin_account(data: dict) -> None:
    acc = choose_account(data)
    if acc:
        asyncio.run(login_profile(acc))


def replace_account_login(data: dict) -> None:
    acc = choose_account(data, "Replace လုပ်မယ့် account slot no/name: ")
    if not acc:
        return
    folder = str(acc.get("profile_folder") or acc["name"])
    path = PROFILES / folder
    print(f"⚠️ {acc['name']} slot ကို Facebook account အသစ်နဲ့ replace မယ်။")
    print("Group list နဲ့ duplicate history ကို မဖျက်ပါဘူး။ Login profile data ပဲ backup ပြီး reset လုပ်မယ်။")
    if input("type REPLACE to continue: ").strip() != "REPLACE":
        return
    if path.exists():
        backup_root = PROFILES / "_account_backups"
        backup_root.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = backup_root / f"{folder}_{stamp}"
        shutil.move(str(path), str(backup))
        print(f"📦 Old profile backup: {backup}")
    path.mkdir(parents=True, exist_ok=True)
    acc["enabled"] = True
    acc["note"] = f"login replaced {datetime.now().isoformat(timespec='seconds')}"
    save_config(data)
    asyncio.run(login_profile(acc))


def main() -> None:
    data = load_config()
    imported = import_existing_profiles(data)
    if imported:
        print(f"✅ Existing FB_Share_Acc_* profile {imported} ခု auto-import လုပ်ပြီးပါပြီ။")

    while True:
        print("\n======= FB GROUP SHARE ACCOUNT MANAGER =======")
        print("1. List accounts")
        print("2. Add new account + optional login")
        print("3. Login / re-login existing account")
        print("4. Enable / disable account")
        print("5. Replace dead account login (keep slot/groups/history)")
        print("6. Re-scan/import existing profile folders")
        print("8. Account details / Groups / Note")
        print("0. Exit")
        choice = input("Choose: ").strip()

        if choice == "1":
            list_accounts(data)
        elif choice == "2":
            add_account(data)
        elif choice == "3":
            relogin_account(data)
        elif choice == "4":
            toggle_account(data)
        elif choice == "5":
            replace_account_login(data)
        elif choice == "6":
            print(f"✅ Imported {import_existing_profiles(data)} new profile(s)")
        elif choice == "8":
            account_details_submenu(data)
        elif choice == "0":
            break
        else:
            print("❌ Unknown option")


if __name__ == "__main__":
    main()
