"""Movie profiles shared by TT route settings and the existing Movie worker."""
from __future__ import annotations

from urllib.parse import urlsplit

GENERAL_SOURCES = (
    "rogerebert.com", "variety.com", "hollywoodreporter.com", "indiewire.com",
    "theguardian.com", "empireonline.com", "ign.com", "avclub.com",
    "slantmagazine.com", "thewrap.com", "deadline.com", "collider.com",
    "screenrant.com", "gamesradar.com", "rottentomatoes.com", "letterboxd.com",
    "reddit.com", "deepfocusreview.com",
)
HORROR_SOURCES = ("bloody-disgusting.com", "fangoria.com", "dreadcentral.com", "rue-morgue.com")
PROFILES = {
    "movie_general": "General Movies",
    "movie_horror_thriller": "Horror / Thriller",
}


def normalize_profile(value: str | None) -> str:
    key = str(value or "movie_general").strip()
    if key in {"", "default", "general"}:
        key = "movie_general"
    if key not in PROFILES:
        raise ValueError("Unknown Movie Review profile")
    return key


def normalize_domain(value: str) -> str:
    raw = str(value or "").strip()
    parsed = urlsplit(raw if "://" in raw else "//" + raw)
    return (parsed.hostname or "").lower().removeprefix("www.").rstrip(".")


def profile_sources(profile: str) -> list[str]:
    key = normalize_profile(profile)
    return list(GENERAL_SOURCES + (HORROR_SOURCES if key == "movie_horror_thriller" else ()))


def accepts_genres(profile: str, genres: list[str]) -> bool:
    return normalize_profile(profile) == "movie_general" or bool(
        {"horror", "thriller", "mystery"}.intersection(str(g).strip().lower() for g in genres)
    )
