from __future__ import annotations
import argparse, json, os
from datetime import datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def atomic(path:Path,data:dict):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,path)

def load(path:Path,default):
    try:return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default
    except Exception:return default

def pin(category:str,count:int,date:str,route='default',ids=None):
    path=ROOT/'state'/'tt_completion_receipts'/f'{date}.json'
    data=load(path,{'date':date,'version':1,'categories':{}})
    data['date']=date;data['version']=1
    receipts=data.setdefault('categories',{}).setdefault(category,{}).setdefault('receipts',{})
    ids=list(ids or [])
    while len(ids)<count:
        ids.append(f'manualpin:{category}:{date}:{len(ids)+1}')
    for token in ids[:count]:
        receipts.setdefault(token,{
            'content_id':token,'route_key':route,'count_increment':1,
            'completed_at':datetime.now().astimezone().isoformat(timespec='seconds'),
            'job_id':'manual_pin','primary_destinations':['operator_confirmed']
        })
    atomic(path,data)
    return path

def heal_daily(date:str):
    receipt_path=ROOT/'state'/'tt_completion_receipts'/f'{date}.json'
    data=load(receipt_path,{'categories':{}})
    state_path=ROOT/'state'/'tt_daily_run'/f'{date}.json'
    if not state_path.exists():return None
    st=load(state_path,{})
    for cat,crow in (data.get('categories') or {}).items():
        rec=(crow or {}).get('receipts') or {}
        count=sum(max(1,int((v or {}).get('count_increment') or 1)) for v in rec.values() if isinstance(v,dict))
        row=(st.get('categories') or {}).get(cat)
        if isinstance(row,dict) and int(row.get('already_posted') or 0)<count:
            row['already_posted']=count;row['count_source']='durable_receipts_manual_pin';row['pending_retry']=False;row['pending_route_key']=''
        routes=((st.get('route_runtime') or {}).get('routes') or {}).get(cat) or {}
        per={}
        for v in rec.values():
            if isinstance(v,dict):
                rk=str(v.get('route_key') or 'default');per[rk]=per.get(rk,0)+max(1,int(v.get('count_increment') or 1))
        for rk,n in per.items():
            if rk in routes and int(routes[rk].get('already_posted') or 0)<n:routes[rk]['already_posted']=n
    atomic(state_path,st);return state_path

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--date',default=datetime.now().astimezone().date().isoformat())
    ap.add_argument('--astrology',type=int,default=None)
    ap.add_argument('--story-motion',type=int,default=None,dest='story_motion')
    ap.add_argument('--drama',type=int,default=None)
    ap.add_argument('--recap',type=int,default=None)
    a=ap.parse_args()
    exact={}
    # Current known Astrology day uses deterministic content IDs where possible.
    if a.astrology is not None:
        ids=[]
        if a.astrology>=1:ids.append(f'astrology:{a.date}:daily')
        if a.astrology>=2:ids.append(f'astrology:{a.date}:image_pick')
        if a.astrology>=3:ids.append(f'astrology:{a.date}:special')
        pin('astrology',a.astrology,a.date,ids=ids)
    for cat,n in [('story_motion',a.story_motion),('drama',a.drama),('recap',a.recap)]:
        if n is not None:pin(cat,n,a.date)
    healed=heal_daily(a.date)
    print(f'✅ Durable completion pins saved for {a.date}')
    print(f'🔐 Ledger: {ROOT / "state" / "tt_completion_receipts" / (a.date+".json")}')
    if healed:print(f'🩹 Daily state healed: {healed}')
    print('These receipts are a lower bound: routine Clear/Restart cannot reduce Done below them.')
if __name__=='__main__':main()
