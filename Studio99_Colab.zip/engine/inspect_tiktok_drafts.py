import asyncio
import json
import sys
from pathlib import Path
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parent

async def main():
    profile = sys.argv[1]
    async with async_playwright() as pw:
        context = await pw.chromium.launch_persistent_context(
            str(ROOT/'browser_profiles'/profile), headless=True,
            args=['--disable-background-networking', '--disable-notifications'])
        try:
            await context.route('**/*', lambda route: route.fulfill(status=200, content_type='text/html', body='<html></html>'))
            page = await context.new_page()
            await page.goto('https://www.tiktok.com/')
            data = await page.evaluate('''async () => {
                const results=[];
                function shape(v, depth=0) {
                    if(v instanceof Blob) return {blob:true, size:v.size, type:v.type, name:v.name||null};
                    if(v===null||v===undefined) return null;
                    if(depth>7) return typeof v;
                    if(Array.isArray(v)) return v.slice(0,3).map(x=>shape(x,depth+1));
                    if(typeof v==='object') return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,['originalKey','createTime','updateTime','ttl','isLocked','isTemp'].includes(k)?x:shape(x,depth+1)]));
                    if(typeof v==='string') return {stringLength:v.length};
                    return typeof v;
                }
                for(const info of await indexedDB.databases()) {
                    const db = await new Promise((ok,no)=>{const r=indexedDB.open(info.name);r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error.message)});
                    const stores=[];
                    for(const name of db.objectStoreNames) {
                        const store=db.transaction(name,'readonly').objectStore(name);
                        const rows=await new Promise((ok,no)=>{const a=[];const r=store.openCursor();r.onsuccess=()=>{const c=r.result;if(!c)return ok(a);a.push({key:c.key,shape:shape(c.value)});c.continue()};r.onerror=()=>no(r.error.message)});
                        stores.push({name,count:rows.length,keyPath:store.keyPath,rows});
                    }
                    results.push({name:info.name,version:info.version,stores});db.close();
                }
                return results;
            }''')
            target=ROOT/'state'/f'tiktok_draft_structure_{profile}.json'
            target.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
            print(json.dumps([{'database':d['name'],'stores':[{'name':s['name'],'count':s['count'],'sample':s['rows'][:4]} for s in d['stores']]} for d in data if d['name']=='web_creation_draft'],ensure_ascii=False))
        finally:
            await context.close()

asyncio.run(main())
