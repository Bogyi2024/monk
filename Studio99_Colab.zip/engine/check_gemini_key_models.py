from __future__ import annotations

import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

API_URL = "https://generativelanguage.googleapis.com/v1beta/models"
ENV_FILE = Path(".env")
REPORT_JSON = Path("gemini_key_model_report.json")
REPORT_TXT = Path("gemini_key_model_report.txt")


def load_dotenv_simple(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    if not path.exists():
        return data
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key:
            data[key] = value
    return data


def discover_keys() -> list[tuple[str, str, str]]:
    env_file = load_dotenv_simple(ENV_FILE)
    merged = dict(os.environ)
    merged.update(env_file)  # project .env wins for this checker

    wanted: list[tuple[int, str, str]] = []
    seen_values: set[str] = set()

    def add(priority: int, alias: str, env_name: str) -> None:
        value = str(merged.get(env_name) or "").strip()
        if not value or value in seen_values:
            return
        seen_values.add(value)
        wanted.append((priority, alias, env_name))

    # Dynamic Story Carousel pool keys
    project_re = re.compile(r"^GEMINI_IMAGE_PROJECT_(\d+)_KEY$")
    for name in merged:
        m = project_re.match(name)
        if m:
            add(1000 + int(m.group(1)), f"project_{int(m.group(1))}", name)

    # Paid / normal project keys
    add(9000, "paid", "GEMINI_IMAGE_PAID_KEY")
    add(9100, "gemini_api", "GEMINI_API_KEY")
    add(9200, "google_api", "GOOGLE_API_KEY")

    # Any other Gemini API key-like vars, so future custom aliases still show up.
    skip = {
        "GEMINI_IMAGE_PAID_KEY",
        "GEMINI_API_KEY",
        "GOOGLE_API_KEY",
    }
    for name in merged:
        if name in skip or project_re.match(name):
            continue
        if name.startswith("GEMINI_") and name.endswith("_KEY"):
            add(8000, name.lower(), name)

    wanted.sort(key=lambda x: x[0])
    out: list[tuple[str, str, str]] = []
    for _, alias, env_name in wanted:
        value = str(merged.get(env_name) or "").strip()
        if value:
            out.append((alias, env_name, value))
    return out


def mask_key(value: str) -> str:
    if len(value) <= 8:
        return "***"
    return f"{value[:4]}...{value[-4:]}"


def fetch_models(api_key: str) -> list[dict[str, Any]]:
    models: list[dict[str, Any]] = []
    page_token = ""

    while True:
        params = {"pageSize": "1000"}
        if page_token:
            params["pageToken"] = page_token
        url = API_URL + "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(
            url,
            headers={
                "x-goog-api-key": api_key,
                "Accept": "application/json",
                "User-Agent": "GeminiKeyModelChecker/1.0",
            },
            method="GET",
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            try:
                detail = exc.read().decode("utf-8", errors="replace")
                detail_json = json.loads(detail)
                msg = detail_json.get("error", {}).get("message") or detail
            except Exception:
                msg = str(exc)
            raise RuntimeError(f"HTTP {exc.code}: {msg}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Network error: {exc.reason}") from exc

        models.extend(payload.get("models") or [])
        page_token = str(payload.get("nextPageToken") or "")
        if not page_token:
            break

    return models


def model_id(model: dict[str, Any]) -> str:
    return str(model.get("name") or "").removeprefix("models/")


def classify(model: dict[str, Any]) -> str:
    mid = model_id(model).lower()
    display = str(model.get("displayName") or "").lower()
    desc = str(model.get("description") or "").lower()
    blob = " ".join([mid, display])

    # Generation categories first. Model name is more reliable than description,
    # because normal multimodal Gemini models can *understand* audio/video without
    # being audio/video generators.
    if mid.startswith("veo-") or "omni" in mid and "video" in desc:
        return "VIDEO"
    if "image" in mid or mid.startswith("imagen-") or "nano banana" in display:
        return "IMAGE"
    if "tts" in mid or "native-audio" in mid or "live-translate" in mid or "flash-live" in mid:
        return "AUDIO"
    if mid.startswith("lyria-"):
        return "MUSIC"
    if "embedding" in mid:
        return "EMBEDDING"

    methods = [str(x) for x in (model.get("supportedGenerationMethods") or [])]
    if "generateContent" in methods or mid.startswith("gemini-") or mid.startswith("gemma-"):
        return "TEXT"
    return "OTHER"


def method_text(model: dict[str, Any]) -> str:
    methods = [str(x) for x in (model.get("supportedGenerationMethods") or [])]
    return ", ".join(methods) if methods else "-"


def sort_models(models: list[dict[str, Any]]) -> list[dict[str, Any]]:
    order = {"IMAGE": 0, "AUDIO": 1, "VIDEO": 2, "TEXT": 3, "MUSIC": 4, "EMBEDDING": 5, "OTHER": 6}
    return sorted(models, key=lambda m: (order.get(classify(m), 99), model_id(m)))


def print_group(category: str, models: list[dict[str, Any]]) -> list[str]:
    group = [m for m in models if classify(m) == category]
    lines: list[str] = []
    if not group:
        lines.append(f"   {category:<9}: none visible")
        return lines
    lines.append(f"   {category:<9}: {len(group)} model(s)")
    for m in group:
        mid = model_id(m)
        display = str(m.get("displayName") or "").strip()
        suffix = f" — {display}" if display and display.lower() != mid.lower() else ""
        lines.append(f"      • {mid}{suffix}")
        lines.append(f"        methods: {method_text(m)}")
    return lines


def main() -> int:
    print("\n🔎 GEMINI API KEY → MODEL CAPABILITY CHECKER")
    print("   Reads keys from project .env; it does NOT print full keys.")
    print("   This checker lists models visible to each key and groups them by output type.\n")

    keys = discover_keys()
    if not keys:
        print("❌ No Gemini keys found in .env / environment.")
        print("   Example: GEMINI_IMAGE_PROJECT_1_KEY=... or GEMINI_API_KEY=...")
        return 1

    print("🔑 Keys found:")
    for alias, env_name, value in keys:
        print(f"   • {alias:<14} {env_name:<36} {mask_key(value)}")

    all_reports: list[dict[str, Any]] = []
    text_lines: list[str] = []

    for index, (alias, env_name, value) in enumerate(keys, 1):
        print("\n" + "═" * 86)
        print(f"[{index}/{len(keys)}] 🔑 {alias}  ({env_name}, {mask_key(value)})")
        print("═" * 86)

        report: dict[str, Any] = {
            "alias": alias,
            "env_name": env_name,
            "key_masked": mask_key(value),
            "ok": False,
            "models": [],
            "counts": {},
        }

        try:
            models = sort_models(fetch_models(value))
            report["ok"] = True
            report["models"] = [
                {
                    "id": model_id(m),
                    "display_name": m.get("displayName"),
                    "category": classify(m),
                    "supported_generation_methods": m.get("supportedGenerationMethods") or [],
                    "input_token_limit": m.get("inputTokenLimit"),
                    "output_token_limit": m.get("outputTokenLimit"),
                }
                for m in models
            ]

            counts: dict[str, int] = {}
            for m in models:
                counts[classify(m)] = counts.get(classify(m), 0) + 1
            report["counts"] = counts

            categories = ["IMAGE", "AUDIO", "VIDEO", "TEXT", "MUSIC", "EMBEDDING", "OTHER"]
            section_lines: list[str] = []
            for category in categories:
                section_lines.extend(print_group(category, models))

            for line in section_lines:
                print(line)
            text_lines.extend([
                f"KEY: {alias} ({env_name}, {mask_key(value)})",
                *section_lines,
                "",
            ])

        except Exception as exc:
            report["error"] = str(exc)
            print(f"❌ KEY CHECK FAILED: {exc}")
            text_lines.extend([
                f"KEY: {alias} ({env_name}, {mask_key(value)})",
                f"ERROR: {exc}",
                "",
            ])

        all_reports.append(report)

    REPORT_JSON.write_text(json.dumps(all_reports, ensure_ascii=False, indent=2), encoding="utf-8")
    REPORT_TXT.write_text("\n".join(text_lines), encoding="utf-8")

    print("\n" + "═" * 86)
    print(f"💾 JSON report: {REPORT_JSON}")
    print(f"💾 TXT report : {REPORT_TXT}")
    print("\nℹ️  Important: 'visible' means the model is returned by models.list for that key/project.")
    print("   It does NOT spend image/audio/video quota, and it does not guarantee that a free-tier")
    print("   generation request will succeed if that model requires billing or its quota is zero.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
