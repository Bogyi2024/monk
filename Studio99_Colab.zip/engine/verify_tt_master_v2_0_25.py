from __future__ import annotations

import py_compile
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks = {
    "services/source_download_auth_service.py": [
        "class TTSourceDownloadAuthService",
        "resolve_source_cookie_file",
        "SourceDownloadAuth_YouTube",
        "SourceDownloadAuth_TikTok",
    ],
    "services/video_service.py": [
        "class SourceDownloadError",
        "cookiefile_ydl_option",
        "youtube-progressive",
        "tiktok-best",
    ],
    "services/recap_source_service.py": [
        "YouTube/TikTok source scan",
        "source_platform",
        "mark_source_download_failed",
        "source_download_failure",
    ],
    "recap_auto_scheduler.py": [
        "except SourceDownloadError as exc",
        "SOURCE_DOWNLOAD soft-skip",
        "destination failure counters NOT incremented",
    ],
    "tt_web_manager.py": [
        "TTSourceDownloadAuthService",
        "/api/source-cookie-import",
        "/api/source-auth-login",
        "/api/source-download-auth",
    ],
    "tt_web/index.html": [
        "Source Download Auth",
        "Import / Replace cookie.txt",
        "YouTube Login / Refresh",
        "TikTok Login / Refresh",
        "YouTube / TikTok, one per line",
    ],
}

print("VERIFY TT MASTER V2.0.25 RECAP SOURCE AUTH + TIKTOK")
for rel, needles in checks.items():
    p = ROOT / rel
    assert p.exists(), f"missing: {rel}"
    text = p.read_text(encoding="utf-8", errors="replace")
    for needle in needles:
        assert needle in text, f"surface missing in {rel}: {needle}"
    if p.suffix == ".py":
        py_compile.compile(str(p), doraise=True)
    print(f"OK: {rel}")

# Confirm dangerous execution surfaces were not part of this patch payload.
payload = ROOT / "_patch_payload_v2025"
for forbidden in [
    "tt_bridge_runner.py",
    "services/tt_pipeline_service.py",
    "services/browser_service.py",
    "services/tt_service.py",
]:
    assert not (payload / forbidden).exists(), f"unexpected execution file in patch: {forbidden}"
print("OK: posting/bridge execution surfaces are not in payload")

# Real JavaScript syntax check when Node is installed.
node = shutil.which("node")
if node:
    html = (ROOT / "tt_web/index.html").read_text(encoding="utf-8")
    m = re.search(r"<script>(.*)</script>", html, re.S)
    assert m, "inline script not found"
    with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8", delete=False) as f:
        f.write(m.group(1))
        tmp = f.name
    proc = subprocess.run([node, "--check", tmp], capture_output=True, text=True)
    Path(tmp).unlink(missing_ok=True)
    assert proc.returncode == 0, proc.stderr or proc.stdout
    print("OK: JavaScript syntax (node --check)")
else:
    print("SKIP: node not found; Python/source surface checks passed")

print("VERIFY OK")
