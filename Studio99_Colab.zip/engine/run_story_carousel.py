from __future__ import annotations

import asyncio
import json

from dotenv import load_dotenv

from services.story_carousel_service import StoryCarouselService

load_dotenv()


async def main():
    print("\n📚 STORY CAROUSEL — Phase 1 manual test")
    print("   1 = Drama")
    print("   2 = Ghost / Horror")
    print("   3 = Thriller")
    raw = input("Genre [1/2/3] > ").strip()
    genre = {"1": "drama", "2": "ghost", "3": "thriller"}.get(raw, "drama")

    topic = input(
        "Topic/idea (Enter = Gemini ကို original idea ကိုယ်တိုင်ဖန်တီးခိုင်းမယ်) > "
    ).strip()

    svc = StoryCarouselService()
    result = await svc.build_story(genre=genre, topic=topic)

    print("\n✅ DONE")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
