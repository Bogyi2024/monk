from __future__ import annotations

import os
import time
from pathlib import Path

from dotenv import load_dotenv

from services.huggingface_story_image_service import HuggingFaceStoryImageService


def main():
    load_dotenv()
    config = {
        "hf_provider": "auto",
        "hf_image_model": "black-forest-labs/FLUX.1-schnell",
        "hf_width": 1024,
        "hf_height": 1024,
        "hf_num_inference_steps": 4,
        "hf_guidance_scale": 3.5,
        "hf_negative_prompt": "blurry, low quality, distorted face, deformed hands, watermark, text",
        "hf_timeout_seconds": 180,
    }

    print("\n🧪 HUGGING FACE STORY IMAGE TEST")
    print("1 = FLUX.1 Schnell")
    print("2 = FLUX.1 Dev")
    model_choice = input("Model [1/2] > ").strip() or "1"
    if model_choice == "2":
        config["hf_image_model"] = "black-forest-labs/FLUX.1-dev"

    prompt = input("Prompt (Enter = default) > ").strip()
    if not prompt:
        prompt = "cinematic Burmese story illustration, a worried young woman standing alone in the rain at night, moody lighting, dramatic atmosphere"

    out_dir = Path("outputs/hf_test")
    out_dir.mkdir(parents=True, exist_ok=True)
    save_path = out_dir / f"hf_test_{time.strftime('%Y%m%d_%H%M%S')}.png"

    svc = HuggingFaceStoryImageService(config)
    svc.generate_image(prompt=prompt, save_path=save_path)
    print(f"\n🎉 Done → {save_path}")


if __name__ == "__main__":
    main()
