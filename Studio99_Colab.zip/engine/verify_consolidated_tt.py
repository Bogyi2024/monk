from __future__ import annotations
import py_compile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PATCH=ROOT/'_consolidated_patch'
PY_FILES=[p for p in PATCH.rglob('*.py')]
for p in PY_FILES:
    py_compile.compile(str(p), doraise=True)

checks={
    'FB direct new-tab on initial stalled composer': ('services/browser_service.py','max_reloads=0, max_tab_reopens=1, new_tab_max_reloads=1'),
    'FB stale-tab cleanup deferred until safe post-Share point': ('services/browser_service.py','keeping {stale_count} stale tab(s) parked until post-Share safe cleanup'),
    'FB pre-permalink cleanup': ('services/browser_service.py','FB pre-permalink cleanup'),
    'TikTok noisy transfer log removed': ('services/tt_service.py','📶 TikTok transfer check —'),
    'Drama staged resume': ('services/tt_drama_bridge.py','Drama resume checkpoint: Story/FAL carousel saved before narration/TTS'),
    'Drama orphan recovery': ('services/tt_drama_bridge.py','Drama orphan recovery: reusing existing FAL/story output'),
    'Gemini TTS retry': ('services/gemini_story_tts_service.py','Gemini continuous TTS no-audio/retry'),
    'Recap global video-id dedupe': ('services/recap_source_service.py','_globally_posted_video_ids'),
    'Same-page gap only': ('services/tt_route_runtime_service.py','NO category/route-to-route spacing'),
    'Group hashtag popup dismiss': ('services/fb_group_service.py','hashtag suggestion popup dismissed before Post'),
    'Group stable dialog lock restored': ('services/fb_group_service.py','Return the visible Create-post dialog only; never fall back to the page body.'),
    'Group stable modal-scoped composer restored': ('services/fb_group_service.py','Find composer strictly INSIDE the modal dialog.'),
    'Group normal Page-post permalink support retained': ('services/fb_group_service.py',"'/posts/'"),
    'Normal Facebook posts allowed': ('services/fb_group_service.py',"'/posts/'"),
    'Web Astrology helper restored': ('tt_web/index.html','function renderAstro()'),
    'Daily scheduler maintenance branch': ('services/tt_daily_run_service.py','job_maintenance'),
    'Drama recovered post owner guard': ('services/browser_service.py','Recovery reject non-Page/personal post'),
    'Drama real Posts scroll recovery': ('services/browser_service.py','_scroll_page_feed_to_real_posts'),
    'Drama multi-shell Page post collector': ('services/browser_service.py','FeedUnit'),
    'Drama caption-local Page recovery': ('services/browser_service.py','_resolve_caption_post_link_from_ui'),
    'Drama deep DOM Page-post fallback': ('services/browser_service.py','deep DOM fallback found'),
    'Drama cached permalink re-verification': ('services/tt_drama_bridge.py','Drama group-share guard rejected cached permalink (owner/fingerprint mismatch)'),
    'Drama narration has no hard max': ('services/story_narration_service.py','Character-count maximum မရှိ'),
    'Drama long narration warning removed': ('services/story_motion_video_service.py','Continuous narration is long'),
    'Drama Page-feed baseline delta': ('services/tt_drama_bridge.py','fb_post_baseline'),
    'Drama recovery uses Page feed not Photos': ('services/browser_service.py','Drama Page-post recovery feed'),
    'Drama pending image reuse is explicit': ('services/tt_drama_bridge.py','reusing the SAME story/FAL images intentionally'),
    'Drama stale orphan age guard': ('services/tt_drama_bridge.py','TT_DRAMA_ORPHAN_MAX_AGE_HOURS'),
    'Drama exact caption fingerprint recovery': ('services/browser_service.py','Drama Page-post caption fingerprint MATCH'),
    'Drama same-page wrong-post reject': ('services/browser_service.py','owner is correct but Drama caption fingerprint does not match'),
    'Drama bridge passes FB caption fingerprint': ('services/tt_drama_bridge.py','expected_caption=self._fb_caption(result)'),
    'FAL policy 422 detector': ('services/story_carousel_service.py','_is_fal_content_policy_violation'),
    'FAL policy-safe Gemini rewrite': ('services/story_carousel_service.py','FAL content-policy 422 detected — blind retry skipped'),
    'FAL safety checker remains enabled': ('services/story_carousel_service.py',"'enable_safety_checker': True"),
    'Drama primary counts before secondary share finishes': ('services/tt_drama_bridge.py','pending_secondary'),
    'Drama stable content token': ('services/tt_drama_bridge.py','"content_id":content_id'),
    'Daily count token dedupe': ('services/tt_daily_run_service.py','counted_content_ids'),
    'Daily same-day count heal': ('services/tt_daily_run_service.py','Drama Today count reconciled'),
    'Drama pending respects configured primary + secondary': ('services/tt_daily_run_service.py','pending_retry=not (primary_complete and secondary_complete)'),
    'Story Motion no 900 hard max': ('story_motion_production_test.py','THERE IS NO MAXIMUM CHARACTER LIMIT'),
    'Story Motion long narration audio locked': ('story_motion_production_test.py','Longer narration is valid: final scene motion durations will follow the real scene audio exactly.'),
    'Story Motion split parts >=60s': ('story_motion_production_test.py',"minimum_part_seconds',60"),
    'Astrology daily Yadaya slide': ('services/astrology_real_output_service.py','Exactly 6 slides:'),
    'Astrology Yadaya heading': ('services/astrology_real_output_service.py','ယနေ့အတွက် ယတြာ'),
    'Astrology daily floor via Yadaya': ('services/astrology_real_output_service.py','existing horoscope pacing unchanged'),
    'Astrology picker timeless': ('services/astrology_real_output_service.py','TIMELESS pick-an-image entertainment post for EVERYONE'),
    'Astrology picker no visual context': ('services/astrology_real_output_service.py','context_line=pick_context'),
    'Astrology picker >=65s': ('services/astrology_real_output_service.py','Image Picker duration floor'),
    'Astrology LIVE bridge': ('services/tt_pipeline_service.py','TTAstrologyBridge'),
    'Astrology pipeline bridge file': ('services/tt_astrology_bridge.py','class TTAstrologyBridge'),
    'Astrology Today one-time live migration': ('services/tt_daily_run_service.py','astrology_live_migrated_v209'),
    'Astrology FB video-only mode': ('services/tt_astrology_bridge.py','video_only'),
    'Astrology FB mixed mode': ('services/tt_astrology_bridge.py','mode=="mixed"'),
    'Astrology UI output mode': ('tt_web/index.html','FACEBOOK OUTPUT MODE'),
    'Astrology dynamic route target UI': ('tt_web/index.html','/day dynamic'),
    'Astrology calendar day 30 cadence': ('services/tt_adaptive_schedule_service.py','is_day_30 = now.day == 30'),
    'Astrology day30 Sunday precedence': ('services/tt_adaptive_schedule_service.py','Monthly replaces Weekly'),
    'Astrology weekly renderer': ('services/astrology_real_output_service.py','_render_period(root,"weekly"'),
    'Astrology monthly renderer': ('services/astrology_real_output_service.py','_render_period(root,"monthly"'),
    'FB carousel exact publish permalink capture': ('services/story_carousel_upload_service.py','Facebook publish confirmation captured exact post permalink'),
    'Drama stores publish-time exact permalink': ('services/tt_drama_bridge.py','Drama exact FB post permalink saved directly from publish confirmation'),
    'Drama Business Suite exact-post fallback': ('services/browser_service.py','Drama exact-post fallback → Meta Business Suite content'),
    'Drama Business Suite caption lock': ('services/browser_service.py','EXACT Page post resolved from Meta Business Suite content'),
    'Queue startup stale heartbeat recovery': ('services/tt_daily_run_service.py','STALE CURRENT JOB auto-cleared'),
    'Queue active job heartbeat': ('services/tt_daily_run_service.py','heartbeat_at'),
    'Dashboard clear process endpoint': ('tt_web_manager.py','/api/master-clear-current'),
    'Dashboard skip current endpoint': ('tt_web_manager.py','/api/master-skip-current'),
    'Dashboard queue escape controls': ('tt_web/index.html','Skip Current → Next'),
    'Scheduler cancels dashboard-released coroutine': ('tt_master_scheduler.py','Dashboard control released'),
    'Manual skip hold respected': ('services/tt_rolling_schedule_service.py','manual_skip_until'),
    'Drama permalink hard 3-pass browser budget': ('services/browser_service.py','Drama Page-post recovery pass {attempt}/3'),
    'Drama persistent permalink 3-attempt budget': ('services/tt_drama_bridge.py','permalink_recovery_attempts'),
    'Drama persistent group-share 3-attempt budget': ('services/tt_drama_bridge.py','group_share_attempts'),
    'Drama exhausted secondary skip releases queue': ('services/tt_drama_bridge.py','logged and SKIPPED group share; queue will continue'),
    'FAL queue request checkpoint resume': ('services/story_carousel_service.py','FAL queue resume'),
    'FAL transient poll keeps same request': ('services/story_carousel_service.py','keeping SAME request'),
    'Astrology primary completion lock': ('services/tt_astrology_bridge.py','Astrology primary complete lock'),
    'Astrology Master same-day completion reconcile': ('services/tt_astrology_bridge.py','same-day primary completion reconcile'),
    'Astrology secondary failure never reopens content item': ('services/tt_astrology_bridge.py','primary item remains COMPLETE'),
    'Drama secondary skip persisted in completion receipt': ('services/tt_drama_bridge.py','secondary_skipped_reason'),
    'Story Motion resumes recent incomplete asset root': ('services/story_motion_production_service.py','Story Motion incomplete asset resume'),
    'Story Motion transient FAL is maintenance not failure': ('services/tt_story_motion_bridge.py','same request will resume on next turn; NOT treated as a failed content job'),
    'Story Motion FAL checkpoint keeps pending retry': ('services/tt_daily_run_service.py','Story Motion FAL queue checkpoint detected'),
    'Story Motion primary destination completion rule': ('services/tt_story_motion_bridge.py','PRIMARY completion is based ONLY on enabled FB/TikTok destinations'),
    'Story Motion primary same-day receipt lock': ('services/tt_story_motion_bridge.py','Story Motion primary complete lock'),
    'Story Motion secondary permalink 3-attempt budget': ('services/tt_story_motion_bridge.py','Story Motion Reel permalink recovery attempt {n}/3'),
    'Story Motion secondary share 3-attempt budget': ('services/tt_story_motion_bridge.py','Story Motion group-share whole-run attempt {n}/3'),
    'Story Motion Today receipt reconciliation': ('services/tt_daily_run_service.py','Story Motion Today count reconciled'),
    'Configured-destination pending completion': ('services/tt_daily_run_service.py','completion follows configured ENABLED primary destinations'),
    'Single-route counter drift repair': ('services/tt_daily_run_service.py','Single-route runtime count reconciled to category Done count'),
    'Disabled destinations excluded from page gap': ('services/tt_route_runtime_service.py','Only enabled primary destinations participate in repeat-gap timing'),
    'Specific route unavailable diagnostics': ('services/tt_route_runtime_service.py','same_destination_gap_until_'),
}
for label,(rel,needle) in checks.items():
    text=(PATCH/rel).read_text(encoding='utf-8',errors='replace')
    if label in {'TikTok noisy transfer log removed','Drama long narration warning removed'}:
        assert needle not in text, f'FAILED: {label}'
    else:
        assert needle in text, f'FAILED: {label}'

sm=(PATCH/'story_motion_production_test.py').read_text(encoding='utf-8',errors='replace')
assert 'mm_narration_hard_max_chars' not in sm, 'FAILED: Story Motion still reads mm_narration_hard_max_chars'
assert 'Myanmar HARD MAX' not in sm, 'FAILED: Story Motion prompt still contains Myanmar HARD MAX'
astro=(PATCH/'services/astrology_real_output_service.py').read_text(encoding='utf-8',errors='replace')
assert 'headline=f"{born}အတွက် ပုံရွေးမယ်"' not in astro, 'FAILED: Image Picker still renders weekday-born cover'
assert 'This post is specifically for {born}' not in astro, 'FAILED: Image Picker Gemini prompt still receives weekday-born identity'
# Reproduce the user-visible old 57.5s picker timing and verify the new floor logic reaches 65s.
raw=[6.0,11.5,11.5,11.5,11.5,5.5]
floor=65.0
factor=floor/sum(raw)
scaled=[round(x*factor,3) for x in raw]
assert sum(scaled) >= 64.999, f'FAILED: picker floor simulation {sum(scaled)}'
# Reproduce the user's 52s daily output: add a 7s Yadaya, then extend only Yadaya to the 62s floor.
old_daily=52.0; yadaya=7.0; daily_floor=62.0
yadaya=max(yadaya,10.0)
if old_daily+yadaya < daily_floor: yadaya += daily_floor-(old_daily+yadaya)
assert old_daily+yadaya >= 62.0, f'FAILED: daily Yadaya floor simulation {old_daily+yadaya}'
rolling=(PATCH/'services/tt_rolling_schedule_service.py').read_text(encoding='utf-8',errors='replace')
assert 'no_route_ready_or_route_targets_complete' not in rolling, 'FAILED: vague no-route reason still present'
route=(PATCH/'services/tt_route_runtime_service.py').read_text(encoding='utf-8',errors='replace')
assert "fb_key and fb and fb.get('enabled',True)" in route, 'FAILED: disabled FB still blocks route gap'

fb_group=(PATCH/'services/fb_group_service.py').read_text(encoding='utf-8',errors='replace')
assert 'Reacquire the live Create-post modal every pass' not in fb_group, 'FAILED: broad live modal reacquire returned'
assert 'prefer the scope that owns BOTH the' not in fb_group, 'FAILED: active modal scoring returned'
assert '_replace_caption_keep_preview_resilient' not in fb_group, 'FAILED: resilient modal replacement loop returned'


# V2.0.16 durable completion safety checks
_daily=(PATCH/'services/tt_daily_run_service.py').read_text(encoding='utf-8',errors='replace')
assert '_record_completion_receipt' in _daily, 'FAILED: durable completion receipt writer missing'
assert '_reconcile_durable_completion_receipts' in _daily, 'FAILED: durable completion reconciliation missing'
assert 'tt_completion_receipts' in _daily, 'FAILED: durable completion ledger path missing'
assert 'master+durable_receipt' in _daily, 'FAILED: primary success does not mark durable receipt count source'
assert (PATCH/'tt_pin_today_completion.py').exists(), 'FAILED: operator completion pin utility missing'
assert (PATCH/'CHECK_TT_PROCESSES.bat').exists(), 'FAILED: corrected process checker missing'
assert (PATCH/'STOP_TT_PROCESSES_SAFE.bat').exists(), 'FAILED: safe TT stop helper missing'
print(f'PASS: {len(PY_FILES)} Python files compiled; {len(checks)} consolidated feature checks passed; Story Motion max-limit negative checks + Astrology timing simulations + route diagnostic negative check passed.')
