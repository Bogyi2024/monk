from __future__ import annotations
import os
from typing import Any
from services.tt_settings_service import TTSettingsService


def clear(): os.system("cls" if os.name=="nt" else "clear")
def pause(): input("\nPress Enter to continue...")
def yn(prompt, default=True):
    raw=input(prompt + (" [Y/n] " if default else " [y/N] ")).strip().lower()
    return default if not raw else raw in {"y","yes","1","true"}

def choose_one(title:str, reg:dict[str,Any], allow_none=True)->str:
    print(f"\n{title}")
    keys=list(reg)
    if allow_none: print("0. NONE / Unassigned")
    for i,k in enumerate(keys,1):
        v=reg[k]; print(f"{i}. {k} | {v.get('label',k)} | {'ON' if v.get('enabled',True) else 'OFF'}")
    if not keys: return ""
    while True:
        raw=input("Select > ").strip()
        if allow_none and raw=="0": return ""
        try: return keys[int(raw)-1]
        except: print("Invalid selection.")

def choose_many(title:str, reg:dict[str,Any], current:list[str]|None=None)->list[str]:
    print(f"\n{title}")
    keys=list(reg); current=current or []
    if not keys:
        print("(No share accounts registered.)"); return []
    for i,k in enumerate(keys,1):
        v=reg[k]; mark="*" if k in current else " "
        print(f"{i}. [{mark}] {k} | {v.get('label',k)} | profile={v.get('profile','')}")
    print("Enter multiple numbers separated by comma, e.g. 1,2,4")
    print("0 = none | Enter = keep current")
    raw=input("Select > ").strip()
    if raw=="": return list(current)
    if raw=="0": return []
    chosen=[]
    for part in raw.split(','):
        try:
            k=keys[int(part.strip())-1]
            if k not in chosen: chosen.append(k)
        except: pass
    return chosen

class Manager:
    def __init__(self): self.s=TTSettingsService('.')
    def header(self,title): clear(); print('='*76); print(title); print('='*76)

    def review(self):
        self.header('TT — FULL SAVED SETUP')
        acc=self.s.accounts(); cats=self.s.categories()['categories']
        print('\nFB SHARE ACCOUNTS')
        for k,v in acc['fb_share_accounts'].items():
            print(f"  {k:<18} | {v.get('label',''):<20} | {v.get('profile','')} | groups={len(v.get('groups') or [])}")
        print('\nCATEGORY ROUTES')
        for k,c in cats.items():
            shares=', '.join(c.get('fb_share_accounts') or []) or '-'
            if k=='astrology':
                r=c.get('production_rules') or {}; d=r.get('daily',{}); w=r.get('weekly',{}); m=r.get('monthly',{})
                limit=f"DYNAMIC daily={sum(int(x) for x in d.values() if isinstance(x,int))} + weekly={w.get('weekly_special',0) if w.get('enabled') else 0} + monthly={m.get('monthly_special',0) if m.get('enabled') else 0}"
            else: limit=f"daily={c.get('daily_limit',0)}"
            print(f"  {k:<18} | {limit:<42} | FB={c.get('facebook_page') or '-'} | TT={c.get('tiktok_account') or '-'} | SHARE=[{shares}]")
        issues=self.s.validate(); print('\nVALIDATION')
        print('  ✅ No broken references.' if not issues else '\n'.join('  ⚠️ '+x for x in issues)); pause()

    def manage_share(self):
        while True:
            self.header('TT — MANAGE FB SHARE ACCOUNTS')
            reg=self.s.accounts()['fb_share_accounts']
            for i,(k,v) in enumerate(reg.items(),1):
                print(f"{i}. {k} | {v.get('label')} | profile={v.get('profile')} | groups={len(v.get('groups') or [])} | {'ON' if v.get('enabled',True) else 'OFF'}")
            if not reg: print('(No FB Share accounts yet.)')
            print('\nA. Add  E. Edit  T. Toggle  R. Remove  G. Groups  B. Back')
            cmd=input('> ').strip().lower()
            try:
                if cmd=='a':
                    label=input('Display name > ').strip()
                    requested=input('Registry key (same base name is OK; duplicate gets _2/_3) > ').strip() or label
                    profile=input('Playwright FB share profile name > ').strip()
                    key=self.s.add_share_account(key=requested,label=label,profile=profile,auto_suffix=True)
                    print(f'✅ Added {key}'); pause()
                elif cmd in {'e','t','r','g'}:
                    key=choose_one('Choose FB Share account',reg,False)
                    if not key: continue
                    if cmd=='e':
                        cur=reg[key]; label=input(f"Label [{cur.get('label','')}] > ").strip(); profile=input(f"Profile [{cur.get('profile','')}] > ").strip()
                        self.s.update_share_account(key,label=label or cur.get('label',''),profile=profile or cur.get('profile','')); print('✅ Updated.')
                    elif cmd=='t': self.s.update_share_account(key,enabled=not bool(reg[key].get('enabled',True))); print('✅ Toggled.')
                    elif cmd=='r': self.s.remove_account('fb_share_accounts',key); print('✅ Removed.')
                    else: self.groups(key)
                    pause()
                elif cmd=='b': return
            except Exception as e: print(f'\n❌ {e}'); pause()

    def groups(self,key):
        while True:
            reg=self.s.accounts()['fb_share_accounts']; cur=reg.get(key)
            if not cur:return
            groups=list(cur.get('groups') or [])
            self.header(f'TT — SHARE GROUPS — {key} ({len(groups)}/5 recommended)')
            for i,g in enumerate(groups,1): print(f'{i}. {g}')
            if not groups: print('(No groups saved.)')
            print('\nA. Add  R. Remove  B. Back')
            cmd=input('> ').strip().lower()
            if cmd=='a':
                val=input('Group name / ID / URL reference > ').strip()
                if val and val not in groups:
                    groups.append(val); self.s.update_share_account(key,groups=groups)
                    if len(groups)>5: print('⚠️ More than 5 groups saved. Allowed, but your current plan is ~5 per account.')
            elif cmd=='r' and groups:
                try: del groups[int(input('Group number > '))-1]; self.s.update_share_account(key,groups=groups)
                except: pause()
            elif cmd=='b': return

    def astrology_rules(self):
        cats=self.s.categories()['categories']; a=cats.get('astrology',{}); r=a.get('production_rules') or {}
        d=r.get('daily',{}); w=r.get('weekly',{}); m=r.get('monthly',{})
        self.header('TT — ASTROLOGY DYNAMIC PRODUCTION RULES')
        print('Astrology does NOT use one fixed daily limit.\n')
        def askint(label,current):
            raw=input(f'{label} [{current}] > ').strip(); return int(raw) if raw else int(current)
        weekday=askint('Daily weekday-born forecast posts',d.get('weekday_forecast',1))
        pick=askint('Daily Pick 1 of 4 posts',d.get('pick_one_of_four',1))
        weekly=yn('Enable Sunday weekly special?',w.get('enabled',True))
        weekly_count=askint('Weekly special posts on Sunday',w.get('weekly_special',1)) if weekly else 0
        monthly=yn('Enable month-end monthly special?',m.get('enabled',True))
        monthly_count=askint('Monthly special posts on last day',m.get('monthly_special',1)) if monthly else 0
        self.s.set_astrology_rules(weekday_forecast=weekday,pick_one_of_four=pick,weekly_enabled=weekly,weekly_weekday='sunday',weekly_special=weekly_count,monthly_enabled=monthly,monthly_special=monthly_count)
        print('\n✅ Astrology dynamic rules saved.'); pause()

    def categories(self):
        while True:
            self.header('TT — MANAGE CATEGORIES')
            cats=self.s.categories()['categories']
            for i,(k,c) in enumerate(cats.items(),1):
                mode=c.get('production_mode','fixed_daily')
                limit='DYNAMIC' if mode=='astrology_dynamic' else str(c.get('daily_limit',0))
                shares=','.join(c.get('fb_share_accounts') or []) or '-'
                print(f"{i}. {k:<18} | daily={limit:<8} | share=[{shares}] | {'ON' if c.get('enabled',True) else 'OFF'}")
            print('\nROUTE. Assign Page/TT/MULTI-Share  ASTRO. Astrology rules  E. Edit fixed limit  T. Toggle  B. Back')
            cmd=input('> ').strip().lower()
            try:
                if cmd=='route':
                    key=choose_one('Choose category',cats,False); self.assign_route(key); pause()
                elif cmd=='astro': self.astrology_rules()
                elif cmd=='e':
                    key=choose_one('Choose category',cats,False)
                    if key=='astrology': print('ℹ️ Astrology is dynamic. Use ASTRO menu instead.'); pause(); continue
                    cur=cats[key]; raw=input(f"Daily limit [{cur.get('daily_limit',0)}] > ").strip()
                    if raw: self.s.update_category(key,daily_limit=int(raw),production_mode='fixed_daily')
                elif cmd=='t':
                    key=choose_one('Choose category',cats,False); self.s.update_category(key,enabled=not bool(cats[key].get('enabled',True)))
                elif cmd=='b': return
            except Exception as e: print(f'\n❌ {e}'); pause()

    def assign_route(self,key):
        acc=self.s.accounts(); c=self.s.categories()['categories'][key]
        self.header(f'TT — ASSIGN ROUTE — {key}')
        fb=choose_one('Facebook Page',acc['facebook_pages'],True)
        tt=choose_one('TikTok Account',acc['tiktok_accounts'],True)
        current=list(c.get('fb_share_accounts') or [])
        shares=choose_many('FB Share Accounts (MULTIPLE allowed)',acc['fb_share_accounts'],current)
        sharing=yn('Enable group sharing for this category?',True)
        self.s.assign_route(key,facebook_page=fb,tiktok_account=tt,fb_share_accounts=shares,share_enabled=sharing)
        print(f'\n✅ Route saved. Share accounts: {shares or "NONE"}')

    def simple_registry(self, kind):
        # Keep Page/TikTok CRUD concise in V1.1
        title='FACEBOOK PAGES' if kind=='fb' else 'TIKTOK ACCOUNTS'
        while True:
            self.header('TT — MANAGE '+title); acc=self.s.accounts(); reg=acc['facebook_pages' if kind=='fb' else 'tiktok_accounts']
            for i,(k,v) in enumerate(reg.items(),1): print(f"{i}. {k} | {v.get('label')} | profile={v.get('profile')} | {'ON' if v.get('enabled',True) else 'OFF'}")
            print('\nA. Add  E. Edit  T. Toggle  R. Remove  B. Back'); cmd=input('> ').strip().lower()
            try:
                if cmd=='a':
                    label=input('Display name > ').strip(); key=input('Registry key > ').strip() or label; profile=input('Playwright profile name > ').strip()
                    if kind=='fb': page=input('Facebook Page ID > ').strip(); self.s.add_facebook_page(key=key,label=label,page_id=page,profile=profile)
                    else: self.s.add_tiktok_account(key=key,label=label,profile=profile)
                    pause()
                elif cmd in {'e','t','r'}:
                    key=choose_one('Choose',reg,False); cur=reg[key]
                    if cmd=='e':
                        label=input(f"Label [{cur.get('label','')}] > ").strip(); profile=input(f"Profile [{cur.get('profile','')}] > ").strip()
                        if kind=='fb': page=input(f"Page ID [{cur.get('page_id','')}] > ").strip(); self.s.update_facebook_page(key,label=label or cur.get('label',''),profile=profile or cur.get('profile',''),page_id=page or cur.get('page_id',''))
                        else:self.s.update_tiktok_account(key,label=label or cur.get('label',''),profile=profile or cur.get('profile',''))
                    elif cmd=='t':
                        (self.s.update_facebook_page if kind=='fb' else self.s.update_tiktok_account)(key,enabled=not bool(cur.get('enabled',True)))
                    else:self.s.remove_account('facebook_pages' if kind=='fb' else 'tiktok_accounts',key)
                    pause()
                elif cmd=='b':return
            except Exception as e: print(f'\n❌ {e}'); pause()

    def run(self):
        while True:
            self.header('TT — CENTRAL ACCOUNT / ROUTE MANAGER V1.1')
            print('1. Review Full Setup')
            print('2. Manage Categories')
            print('3. Manage Facebook Pages')
            print('4. Manage TikTok Accounts')
            print('5. Manage FB Share Accounts')
            print('6. Backup Settings Now')
            print('0. Exit')
            cmd=input('\nSelect > ').strip()
            if cmd=='1':self.review()
            elif cmd=='2':self.categories()
            elif cmd=='3':self.simple_registry('fb')
            elif cmd=='4':self.simple_registry('tt')
            elif cmd=='5':self.manage_share()
            elif cmd=='6': print('✅ Backup →',self.s.backup_all()); pause()
            elif cmd=='0':return

if __name__=='__main__': Manager().run()
