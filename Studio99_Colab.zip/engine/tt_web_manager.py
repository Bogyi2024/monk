from __future__ import annotations

import json
import threading
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from services.tt_settings_service import TTSettingsService
from services.tt_legacy_share_importer import import_existing_fb_share_accounts
from services.tt_fb_profile_service import TTFBProfileService
from services.tt_tiktok_profile_service import TTTikTokProfileService
from services.tt_adaptive_schedule_service import TTAdaptiveScheduleService
from services.tt_rolling_schedule_service import TTRollingScheduleService
from services.tt_daily_run_service import TTDailyRunService
from services.tt_pipeline_service import TTPipelineService
from services.tt_health_log_service import TTHealthLogService
from services.source_download_auth_service import TTSourceDownloadAuthService
from services.tt_novel_dashboard_service import TTNovelDashboardService
from services.tt_route_branding_service import TTRouteBrandingService
from tavily_live import TavilyLiveService
from movie_review_profiles import PROFILES


HOST = "127.0.0.1"
# Studio99 Desktop engine: port, product name and hidden tabs from the environment (tools/sync_engine.py).
PORT = int(__import__("os").environ.get("TT_WEB_PORT") or 8787)
UI_PROFILE = {
    "product": __import__("os").environ.get("TT_UI_PRODUCT") or "",
    "hide_tabs": [x.strip() for x in (__import__("os").environ.get("TT_UI_HIDE_TABS") or "").split(",") if x.strip()],
}
ROOT = Path(".").resolve()
SERVICE = TTSettingsService(ROOT)
LEGACY_IMPORT_MARKER = ROOT / "state" / "tt_legacy_share_import_v14.json"

def _initial_legacy_import() -> dict[str, Any]:
    legacy_path = ROOT / "config" / "fb_share_accounts.json"
    if LEGACY_IMPORT_MARKER.exists():
        return {
            "source": str(legacy_path),
            "found": legacy_path.exists(),
            "skipped": True,
            "reason": "one_time_import_already_completed",
            "accounts_seen": 0,
            "accounts_added": 0,
            "accounts_matched": 0,
            "groups_seen": 0,
            "groups_added": 0,
            "assigned_to_recap": [],
            "warnings": [],
        }

    report = import_existing_fb_share_accounts(SERVICE, assign_to_recap=False)
    if report.get("found"):
        LEGACY_IMPORT_MARKER.parent.mkdir(parents=True, exist_ok=True)
        LEGACY_IMPORT_MARKER.write_text(
            json.dumps({
                "completed": True,
                "source": report.get("source"),
                "accounts_seen": report.get("accounts_seen", 0),
                "groups_seen": report.get("groups_seen", 0),
                "note": "V1.4 one-time legacy group import. Category routes were not changed.",
            }, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    return report

LEGACY_IMPORT_REPORT = _initial_legacy_import()
FB_PROFILES = TTFBProfileService(ROOT)
FB_SHARE_PROFILES = TTFBProfileService(ROOT, profile_store="browser_profiles")
FB_PAGE_SHARED_PROFILES = TTFBProfileService(ROOT, profile_store="browser_profiles", purpose="page")


def _page_fb_profiles(account):
    store = str(account.get("profile_store") or "browser_sessions")
    if store not in {"browser_sessions", "browser_profiles"}:
        raise ValueError("Invalid Facebook profile store")
    return FB_PAGE_SHARED_PROFILES if store == "browser_profiles" else FB_PROFILES
TIKTOK_PROFILES = TTTikTokProfileService(ROOT)
ADAPTIVE_SCHEDULE = TTAdaptiveScheduleService(SERVICE)
ROLLING_SCHEDULE = TTRollingScheduleService(SERVICE)
DAILY_RUN = TTDailyRunService(SERVICE, ROOT)
PIPELINES = TTPipelineService(SERVICE, ROOT)
HEALTH_LOG = TTHealthLogService(ROOT)
SOURCE_AUTH = TTSourceDownloadAuthService(ROOT)
NOVEL_DASHBOARD = TTNovelDashboardService(SERVICE, ROOT)
ROUTE_BRANDING = TTRouteBrandingService(ROOT)
TAVILY_LIVE = TavilyLiveService(ROOT)
INDEX = Path(__file__).resolve().parent / "tt_web" / "index.html"
_LIVE_SCHEDULE_CACHE: dict[str, Any] = {}
_LIVE_SCHEDULE_CACHE_AT = 0.0
_LIVE_SCHEDULE_REFRESHING = False
_LIVE_SCHEDULE_LOCK = threading.Lock()


def _refresh_live_schedule_cache() -> None:
    """Build the expensive projection once while HTTP requests use the last result."""
    global _LIVE_SCHEDULE_CACHE, _LIVE_SCHEDULE_CACHE_AT, _LIVE_SCHEDULE_REFRESHING
    try:
        result = ROLLING_SCHEDULE.live_status(DAILY_RUN.get())
        with _LIVE_SCHEDULE_LOCK:
            _LIVE_SCHEDULE_CACHE = result
            _LIVE_SCHEDULE_CACHE_AT = time.monotonic()
    except Exception as exc:
        # Keep a previously good dashboard instead of turning a read-model failure
        # into an HTTP connection failure. The scheduler execution loop is separate.
        print(f"⚠️ Scheduler dashboard refresh failed: {type(exc).__name__}")
    finally:
        with _LIVE_SCHEDULE_LOCK:
            _LIVE_SCHEDULE_REFRESHING = False


def live_schedule_snapshot() -> dict[str, Any]:
    """Return immediately; refresh a 5-second-old projection in one background thread."""
    global _LIVE_SCHEDULE_REFRESHING
    with _LIVE_SCHEDULE_LOCK:
        cached = dict(_LIVE_SCHEDULE_CACHE)
        stale = not cached or (time.monotonic() - _LIVE_SCHEDULE_CACHE_AT) >= 5.0
        if stale and not _LIVE_SCHEDULE_REFRESHING:
            _LIVE_SCHEDULE_REFRESHING = True
            threading.Thread(
                target=_refresh_live_schedule_cache,
                name="TTLiveScheduleRefresh",
                daemon=True,
            ).start()
        if cached:
            cached['active_preparation'] = ROLLING_SCHEDULE.preparation.active_preparation()
            return cached
    return {"loading": True}


def jb(data: Any) -> bytes:
    return json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "TTLocalManager/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        pass

    def send_bytes(self, status: int, content: bytes, ctype: str) -> None:
        try:
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(content)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(content)
        except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
            # Browser navigation/refresh can close a localhost request mid-write.
            # It is not a scheduler failure and must not trigger a second response.
            return

    def send_json(self, data: Any, status: int = 200) -> None:
        self.send_bytes(status, jb(data), "application/json; charset=utf-8")

    def body(self) -> dict[str, Any]:
        n = int(self.headers.get("Content-Length", "0") or "0")
        if n > 12 * 1024 * 1024:
            raise ValueError("Request is too large (12 MiB maximum)")
        raw = self.rfile.read(n) if n else b"{}"
        data = json.loads(raw.decode("utf-8"))
        if not isinstance(data, dict):
            raise ValueError("JSON body must be an object")
        return data

    def do_GET(self) -> None:
        parsed = urllib.parse.urlsplit(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)
        try:
            if path == "/":
                self.send_bytes(200, INDEX.read_bytes(), "text/html; charset=utf-8")
            elif path == "/api/snapshot":
                snap = SERVICE.full_snapshot()
                for _, item in snap.get("accounts", {}).get("facebook_pages", {}).items():
                    item["profile_status"] = _page_fb_profiles(item).status(str(item.get("profile") or ""))
                for _, item in snap.get("accounts", {}).get("fb_share_accounts", {}).items():
                    item["profile_status"] = FB_SHARE_PROFILES.status(str(item.get("profile") or ""))
                for _, item in snap.get("accounts", {}).get("tiktok_accounts", {}).items():
                    item["profile_status"] = TIKTOK_PROFILES.status(str(item.get("profile") or ""))
                snap["source_download_auth"] = SOURCE_AUTH.status()
                snap["novel"] = NOVEL_DASHBOARD.snapshot()
                snap["search_backend"] = TAVILY_LIVE.status()
                snap["movie_review_profiles"] = PROFILES
                self.send_json(snap)
            elif path == "/api/search-backend":
                self.send_json({"ok": True, **TAVILY_LIVE.status()})
            elif path == "/api/source-download-auth":
                self.send_json({"ok": True, **SOURCE_AUTH.status()})
            elif path == "/api/novel-status":
                self.send_json({"ok": True, **NOVEL_DASHBOARD.snapshot()})
            elif path == "/api/ui-profile":
                self.send_json({"ok": True, **UI_PROFILE})
            elif path == "/health":
                self.send_json({"ok": True, "host": HOST, "port": PORT})
            elif path == "/api/legacy-share-status":
                self.send_json(LEGACY_IMPORT_REPORT)
            elif path == "/api/today-control":
                self.send_json({"ok": True, "state": DAILY_RUN.get(), "capabilities": PIPELINES.capabilities(), "active_preparation": ROLLING_SCHEDULE.preparation.active_preparation()})
            elif path == "/api/live-schedule":
                self.send_json(live_schedule_snapshot())
            elif path == "/api/health-log":
                self.send_json(HEALTH_LOG.snapshot(DAILY_RUN.get(), PIPELINES.capabilities()))
            elif path == "/api/route-logo":
                category_key=str((query.get("category") or [""])[0])
                route_key=str((query.get("route") or [""])[0])
                routes=SERVICE.category_routes(category_key)
                if route_key not in routes:
                    self.send_json({"error":"Unknown route"},404);return
                logo=ROUTE_BRANDING.logo_path(category_key,route_key)
                if not logo.is_file():
                    self.send_json({"error":"No logo configured"},404);return
                self.send_bytes(200,logo.read_bytes(),"image/png")
            else:
                self.send_json({"error": "Not found"}, 404)
        except Exception as exc:
            self.send_json({"error": str(exc)}, 500)

    def do_POST(self) -> None:
        path = urllib.parse.urlsplit(self.path).path
        try:
            b = self.body()

            if path in {"/api/tavily-key", "/api/tavily-disable"}:
                try:
                    status = TAVILY_LIVE.clear() if path.endswith("-disable") else TAVILY_LIVE.save(b.get("key") or "")
                except (ValueError, OSError):
                    self.send_json({"error": "Could not save Tavily settings. Enter one key and check file access."}, 400)
                    return
                self.send_json({"ok": True, **status})
                return

            if path == "/api/source-cookie-import":
                result = SOURCE_AUTH.import_cookie_text(
                    str(b.get("content") or ""),
                    source_name=str(b.get("filename") or "cookie.txt"),
                )
                self.send_json({"ok": True, "status": result}); return

            if path == "/api/route-branding":
                category_key=str(b.get("category_key") or "")
                route_key=str(b.get("route_key") or "")
                routes=SERVICE.category_routes(category_key)
                if route_key not in routes:
                    raise KeyError(f"Unknown route: {category_key}/{route_key}")
                branding=dict(b.get("branding") or {})
                if bool(b.get("logo_remove")):
                    ROUTE_BRANDING.remove_logo(category_key,route_key)
                    branding.update({"enabled":False,"logo_path":""})
                upload=b.get("logo_upload") or {}
                if isinstance(upload,dict) and str(upload.get("data_url") or ""):
                    relative=ROUTE_BRANDING.save_logo(category_key,route_key,str(upload.get("data_url") or ""))
                    branding.update({"enabled":True,"logo_path":relative})
                SERVICE.update_route(category_key,route_key,branding=branding)
                saved=(SERVICE.category_routes(category_key).get(route_key) or {}).get("branding") or {}
                self.send_json({"ok":True,"category_key":category_key,"route_key":route_key,"branding":saved});return

            if path == "/api/novel-generate":
                result = NOVEL_DASHBOARD.generate(
                    genre=str(b.get("genre") or ""),
                    story_seed=str(b.get("story_seed") or ""),
                    publish_start_date=str(b.get("publish_start_date") or ""),
                    route_key=str(b.get("route_key") or ""),
                    screenshot_pages=bool(b.get("screenshot_pages", False)),
                )
                self.send_json({"ok": True, "generation": result}); return

            if path == "/api/novel-generate-route":
                result = NOVEL_DASHBOARD.generate_route(str(b.get("route_key") or "default"))
                self.send_json({"ok": True, "generation": result}); return

            if path == "/api/novel-repair-style":
                result = NOVEL_DASHBOARD.repair_latest_style()
                self.send_json({"ok": True, "generation": result}); return

            if path == "/api/source-auth-login":
                result = SOURCE_AUTH.open_login(str(b.get("platform") or ""))
                self.send_json({"ok": True, **result}); return

            if path == "/api/facebook-page":
                old = str(b.get("old_key") or "")
                store = str(b.get("profile_store") or
                            SERVICE.accounts().get("facebook_pages", {}).get(old, {}).get("profile_store") or "browser_sessions")
                if old:
                    SERVICE.update_facebook_page(
                        old,
                        label=str(b.get("label") or old),
                        page_id=str(b.get("page_id") or ""),
                        profile=str(b.get("profile") or ""),
                        profile_store=store,
                        enabled=bool(b.get("enabled", True)),
                    )
                    key = old
                else:
                    key = SERVICE.add_facebook_page(
                        key=str(b.get("key") or b.get("label") or "fb_page"),
                        label=str(b.get("label") or ""),
                        page_id=str(b.get("page_id") or ""),
                        profile=str(b.get("profile") or ""),
                        profile_store=store,
                        enabled=bool(b.get("enabled", True)),
                    )
                self.send_json({"ok": True, "key": key}); return

            if path == "/api/tiktok-account":
                old = str(b.get("old_key") or "")
                if old:
                    SERVICE.update_tiktok_account(
                        old,
                        label=str(b.get("label") or old),
                        profile=str(b.get("profile") or ""),
                        enabled=bool(b.get("enabled", True)),
                    )
                    key = old
                else:
                    key = SERVICE.add_tiktok_account(
                        key=str(b.get("key") or b.get("label") or "tt_account"),
                        label=str(b.get("label") or ""),
                        profile=str(b.get("profile") or ""),
                        enabled=bool(b.get("enabled", True)),
                    )
                self.send_json({"ok": True, "key": key}); return

            if path == "/api/share-account":
                old = str(b.get("old_key") or "")
                group_items = b.get("group_items") or []
                groups: list[str] = []
                group_names: dict[str, str] = {}
                if isinstance(group_items, list) and group_items:
                    for item in group_items:
                        if not isinstance(item, dict):
                            continue
                        url = str(item.get("url") or "").strip()
                        name = str(item.get("name") or "").strip()
                        if url and url not in groups:
                            groups.append(url)
                            if name:
                                group_names[url] = name
                else:
                    groups = [str(x).strip() for x in (b.get("groups") or []) if str(x).strip()]
                    incoming_names = b.get("group_names") or {}
                    if isinstance(incoming_names, dict):
                        group_names = {
                            str(k): str(v).strip()
                            for k, v in incoming_names.items()
                            if str(k) in groups and str(v).strip()
                        }

                if old:
                    SERVICE.update_share_account(
                        old,
                        label=str(b.get("label") or old),
                        profile=str(b.get("profile") or ""),
                        enabled=bool(b.get("enabled", True)),
                        groups=groups,
                        group_names=group_names,
                    )
                    key = old
                else:
                    key = SERVICE.add_share_account(
                        key=str(b.get("key") or b.get("label") or "share"),
                        label=str(b.get("label") or ""),
                        profile=str(b.get("profile") or ""),
                        enabled=bool(b.get("enabled", True)),
                        auto_suffix=True,
                    )
                    SERVICE.update_share_account(
                        key,
                        groups=groups,
                        group_names=group_names,
                    )

                # V1.4: category assignment can be edited directly from Share Account.
                # Internal key is only an ID; it does NOT decide the category.
                if "categories" in b:
                    requested_categories = {
                        str(x).strip()
                        for x in (b.get("categories") or [])
                        if str(x).strip()
                    }
                    cats = SERVICE.categories().get("categories", {})
                    unknown = sorted(requested_categories.difference(cats.keys()))
                    if unknown:
                        raise KeyError(f"Unknown categories: {', '.join(unknown)}")

                    for category_key, category in cats.items():
                        current = list(category.get("fb_share_accounts") or [])
                        legacy_single = str(category.get("fb_share_account") or "").strip()
                        if legacy_single and legacy_single not in current:
                            current.append(legacy_single)

                        if category_key in requested_categories:
                            if key not in current:
                                current.append(key)
                        else:
                            current = [x for x in current if x != key]

                        SERVICE.assign_route(
                            category_key,
                            fb_share_accounts=current,
                            share_enabled=bool(category.get("share_enabled", True)),
                        )

                self.send_json({"ok": True, "key": key}); return

            if path == "/api/route":
                category_key=str(b.get("category_key") or "")
                old_route=str(b.get("old_route_key") or "")
                route_key=str(b.get("route_key") or old_route or b.get("label") or "route")
                values={
                    "label":str(b.get("label") or route_key),
                    "content_type":str(b.get("content_type") or "default"),
                    "output_type":str(b.get("output_type") or "video"),
                    "language":str(b.get("language") or "mm"),
                    "genre_mode":str(b.get("genre_mode") or "alternate"),
                    "fixed_genre":str(b.get("fixed_genre") or "horror"),
                    "content_group":str(b.get("content_group") or "main"),
                    "novel_genre":str(b.get("novel_genre") or ""),
                    "novel_story_seed":str(b.get("novel_story_seed") or ""),
                    "novel_publish_start_date":str(b.get("novel_publish_start_date") or ""),
                    "novel_long_text_enabled":bool(b.get("novel_long_text_enabled",True)),
                    "novel_screenshot_pages_enabled":bool(b.get("novel_screenshot_pages_enabled",False)),
                    "lts_category":str(b.get("lts_category") or b.get("content_type") or "motivation"),
                    "daily_limit":max(0,int(b.get("daily_limit") or 0)),
                    "facebook_page":str(b.get("facebook_page") or ""),
                    "tiktok_account":str(b.get("tiktok_account") or ""),
                    "fb_share_accounts":list(b.get("fb_share_accounts") or []),
                    "share_enabled":bool(b.get("share_enabled",True)),
                    "enabled":bool(b.get("enabled",True)),
                    "schedule_policy":dict(b.get("schedule_policy") or {}),
                    "branding":dict(b.get("branding") or {}),
                }
                if category_key == "movie_review" and "movie_review_profile" in b:
                    values["movie_review_profile"] = b["movie_review_profile"]
                # Keep source bridge inputs intact: structured records preferred,
                # with legacy list/newline-separated source_urls still accepted.
                if "sources" in b:
                    values["sources"] = b.get("sources")
                elif "source_urls" in b:
                    values["source_urls"] = b.get("source_urls")
                if category_key == "episode_splitter":
                    values["episode_hashtags"] = b.get("episode_hashtags") or []
                if old_route:
                    SERVICE.update_route(category_key,old_route,**values)
                    saved=old_route
                else:
                    saved=SERVICE.add_route(category_key,key=route_key,**values)
                if bool(b.get("logo_remove")):
                    ROUTE_BRANDING.remove_logo(category_key,saved)
                    branding=dict(values.get("branding") or {})
                    branding.update({"enabled":False,"logo_path":""})
                    SERVICE.update_route(category_key,saved,branding=branding)
                logo_upload=b.get("logo_upload") or {}
                if isinstance(logo_upload,dict) and str(logo_upload.get("data_url") or ""):
                    relative=ROUTE_BRANDING.save_logo(category_key,saved,str(logo_upload.get("data_url") or ""))
                    branding=dict(values.get("branding") or {})
                    branding.update({"enabled":True,"logo_path":relative})
                    SERVICE.update_route(category_key,saved,branding=branding)
                self.send_json({"ok":True,"category_key":category_key,"route_key":saved});return

            if path == "/api/route-remove":
                category_key=str(b.get("category_key") or "")
                route_key=str(b.get("route_key") or "")
                # A deleted route must not leave a logo that can be inherited if
                # somebody later reuses the same route key.
                if route_key not in SERVICE.category_routes(category_key):
                    raise KeyError(f"Unknown route: {category_key}/{route_key}")
                ROUTE_BRANDING.remove_logo(category_key,route_key)
                SERVICE.remove_route(category_key,route_key)
                self.send_json({"ok":True});return

            if path == "/api/lts-content-category":
                old=str(b.get("old_key") or "").strip()
                requested=str(b.get("key") or old or b.get("label") or "category").strip()
                if old and requested and SERVICE.normalize_key(requested)!=old:
                    raise ValueError("Long-to-Short content category key stays stable after creation. Change the display name instead.")
                saved=SERVICE.upsert_lts_content_category(
                    old or requested,
                    label=str(b.get("label") or requested),
                    selector_profile=str(b.get("selector_profile") or "generic"),
                    source_urls=list(b.get("source_urls") or []),
                    min_editorial_score=float(b.get("min_editorial_score") or 8.8),
                    max_candidates_per_source=max(1,int(b.get("max_candidates_per_source") or 5)),
                    scan_limit=max(1,int(b.get("scan_limit") or 12)),
                    min_source_minutes=max(0.0,float(b.get("min_source_minutes") or 10)),
                    prep_buffer_days=max(1,min(7,int(b.get("prep_buffer_days") or 3))),
                    enabled=bool(b.get("enabled",True)),
                )
                self.send_json({"ok":True,"key":saved});return

            if path == "/api/lts-content-category-remove":
                SERVICE.remove_lts_content_category(str(b.get("key") or ""))
                self.send_json({"ok":True});return

            if path == "/api/category":
                key = str(b.get("category_key") or "")
                SERVICE.assign_route(
                    key,
                    facebook_page=str(b.get("facebook_page") or ""),
                    tiktok_account=str(b.get("tiktok_account") or ""),
                    fb_share_accounts=list(b.get("fb_share_accounts") or []),
                    share_enabled=bool(b.get("share_enabled", True)),
                )
                if "daily_limit" in b and key != "astrology":
                    SERVICE.update_category(
                        key,
                        daily_limit=max(0, int(b.get("daily_limit") or 0)),
                        production_mode="fixed_daily",
                    )
                self.send_json({"ok": True}); return

            if path == "/api/category-toggle":
                SERVICE.update_category(str(b["key"]), enabled=bool(b.get("enabled")))
                self.send_json({"ok": True}); return

            if path == "/api/account-toggle":
                typ, key, enabled = str(b["type"]), str(b["key"]), bool(b.get("enabled"))
                if typ == "facebook_pages":
                    SERVICE.update_facebook_page(key, enabled=enabled)
                elif typ == "tiktok_accounts":
                    SERVICE.update_tiktok_account(key, enabled=enabled)
                elif typ == "fb_share_accounts":
                    SERVICE.update_share_account(key, enabled=enabled)
                else:
                    raise ValueError("Unknown account type")
                self.send_json({"ok": True}); return

            if path == "/api/account-remove":
                SERVICE.remove_account(str(b["type"]), str(b["key"]))
                self.send_json({"ok": True}); return

            if path == "/api/facebook-page-profile-open":
                key = str(b.get("key") or "")
                account = SERVICE.accounts().get("facebook_pages", {}).get(key)
                if not account:
                    raise KeyError(f"Unknown Facebook Page: {key}")
                result = _page_fb_profiles(account).open_login(str(account.get("profile") or ""))
                self.send_json({"ok": True, **result}); return

            if path == "/api/facebook-page-profile-test":
                key = str(b.get("key") or "")
                account = SERVICE.accounts().get("facebook_pages", {}).get(key)
                if not account:
                    raise KeyError(f"Unknown Facebook Page: {key}")
                result = _page_fb_profiles(account).test_login(str(account.get("profile") or ""))
                self.send_json({"ok": True, **result}); return

            if path == "/api/tiktok-profile-open":
                key = str(b.get("key") or "")
                account = SERVICE.accounts().get("tiktok_accounts", {}).get(key)
                if not account:
                    raise KeyError(f"Unknown TikTok account: {key}")
                result = TIKTOK_PROFILES.open_login(str(account.get("profile") or ""))
                self.send_json({"ok": True, **result}); return

            if path == "/api/tiktok-profile-test":
                key = str(b.get("key") or "")
                account = SERVICE.accounts().get("tiktok_accounts", {}).get(key)
                if not account:
                    raise KeyError(f"Unknown TikTok account: {key}")
                result = TIKTOK_PROFILES.test_login(str(account.get("profile") or ""))
                self.send_json({"ok": True, **result}); return

            if path == "/api/share-profile-open":
                key = str(b.get("key") or "")
                account = SERVICE.accounts().get("fb_share_accounts", {}).get(key)
                if not account:
                    raise KeyError(f"Unknown FB Share account: {key}")
                result = FB_SHARE_PROFILES.open_login(str(account.get("profile") or ""))
                self.send_json({"ok": True, **result}); return

            if path == "/api/share-profile-test":
                key = str(b.get("key") or "")
                account = SERVICE.accounts().get("fb_share_accounts", {}).get(key)
                if not account:
                    raise KeyError(f"Unknown FB Share account: {key}")
                result = FB_SHARE_PROFILES.test_login(str(account.get("profile") or ""))
                self.send_json({"ok": True, **result}); return

            if path == "/api/schedule-preview":
                key=str(b.get("category_key") or "recap")
                live=ROLLING_SCHEDULE.live_status(DAILY_RUN.get())
                row=next((x for x in live.get("categories",[]) if x.get("category")==key),None)
                if row is None:raise KeyError(f"Unknown Today category: {key}")
                self.send_json({"ok":True,"category":row,"live":live});return

            if path == "/api/category-schedule":
                key=str(b.get("category_key") or "")
                policy=dict(b.get("policy") or {})
                SERVICE.update_category_schedule(key,policy)
                self.send_json({"ok":True,"category_key":key,"policy":SERVICE.categories()["categories"][key].get("schedule_policy",{})});return

            if path == "/api/episode-prep-rules":
                cats=SERVICE.categories().get("categories") or {}
                episode=cats.get("episode_splitter") or {}
                rules=dict(episode.get("production_rules") or {})
                rules["prep_buffer_days"]=max(1,min(14,int(b.get("prep_buffer_days") or 3)))
                SERVICE.update_category("episode_splitter",production_rules=rules)
                self.send_json({"ok":True,"production_rules":rules});return

            if path == "/api/today-save":
                state = DAILY_RUN.save_controls(dict(b.get("categories") or {}))
                self.send_json({"ok": True, "state": state}); return

            if path == "/api/today-preset":
                state = DAILY_RUN.preset(str(b.get("mode") or ""))
                self.send_json({"ok": True, "state": state}); return

            if path == "/api/today-autodetect-recap":
                state = DAILY_RUN.autodetect_recap()
                self.send_json({"ok": True, "state": state}); return

            if path == "/api/today-arm":
                state = DAILY_RUN.arm()
                self.send_json({"ok": True, "state": state}); return

            if path == "/api/today-stop":
                state = DAILY_RUN.request_stop()
                self.send_json({"ok": True, "state": state}); return

            if path == "/api/master-clear-current":
                result = DAILY_RUN.clear_current_job(reason="dashboard_clear_current")
                self.send_json({"ok": True, **result}); return

            if path == "/api/master-skip-current":
                result = DAILY_RUN.skip_current_to_next(hold_minutes=max(1,int(b.get("hold_minutes") or 10)))
                self.send_json({"ok": True, **result}); return

            if path == "/api/astrology":
                SERVICE.set_astrology_rules(
                    weekday_forecast=int(b.get("weekday_forecast", 1)),
                    pick_one_of_four=int(b.get("pick_one_of_four", 1)),
                    weekly_enabled=bool(b.get("weekly_enabled", True)),
                    weekly_weekday="sunday",
                    weekly_special=int(b.get("weekly_special", 1)),
                    monthly_enabled=bool(b.get("monthly_enabled", True)),
                    monthly_special=int(b.get("monthly_special", 1)),
                    facebook_output_mode=str(b.get("facebook_output_mode") or "video_only"),
                )
                self.send_json({"ok": True}); return

            if path == "/api/scheduler":
                SERVICE.update_scheduler(
                    startup_mode=str(b.get("startup_mode") or "ask"),
                    sequential_queue=bool(b.get("sequential_queue", True)),
                    posting_window=dict(b.get("posting_window") or {"start": "09:00", "end": "21:00"}),
                    adaptive_catchup=dict(b.get("adaptive_catchup") or {}),
                    rolling_realtime=dict(b.get("rolling_realtime") or SERVICE.scheduler().get("rolling_realtime") or {}),
                    auto_arm_next_day=bool(b.get("auto_arm_next_day", True)),
                )
                self.send_json({"ok": True}); return

            if path == "/api/import-existing-share":
                global LEGACY_IMPORT_REPORT
                LEGACY_IMPORT_REPORT = import_existing_fb_share_accounts(
                    SERVICE,
                    assign_to_recap=False,
                )
                self.send_json({"ok": True, **LEGACY_IMPORT_REPORT}); return

            if path == "/api/backup":
                p = SERVICE.backup_all()
                self.send_json({"ok": True, "path": str(p)}); return

            self.send_json({"error": "Not found"}, 404)
        except Exception as exc:
            self.send_json({"error": str(exc)}, 400)


def create_server() -> ThreadingHTTPServer:
    return ThreadingHTTPServer((HOST, PORT), Handler)


def start_in_thread(*, open_browser: bool = True):
    server = create_server()
    url = f"http://{HOST}:{PORT}/"
    thread = threading.Thread(target=server.serve_forever, name="TTWebManager", daemon=True)
    thread.start()
    if open_browser:
        threading.Timer(0.7, lambda: webbrowser.open(url)).start()
    return server, thread


def main() -> None:
    server = create_server()
    url = f"http://{HOST}:{PORT}/"
    print("=" * 72)
    print("TT LOCAL WEB MANAGER V1.7 — Rolling Real-Time Queue")
    print("=" * 72)
    print(f"WEB: {url}")
    print("For live automation use TT_MASTER.bat instead of this standalone manager.")
    print("Press Ctrl+C to stop.")
    print("=" * 72)
    threading.Timer(0.7, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping...")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
