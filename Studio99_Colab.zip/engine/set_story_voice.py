from __future__ import annotations

import json
from pathlib import Path


VOICE_CANDIDATES = [
    ("Vindemiatrix", "Gentle"),
    ("Erinome", "Clear"),
    ("Despina", "Smooth"),
    ("Achernar", "Soft"),
    ("Kore", "Firm"),
    ("Aoede", "Breezy"),
    ("Sulafat", "Warm"),
]


def main() -> None:
    cfg_path = Path("config/story_video.json")
    if not cfg_path.exists():
        raise FileNotFoundError(cfg_path)

    print("\nChoose Story Drama narrator:\n")
    for i, (voice, style) in enumerate(VOICE_CANDIDATES, 1):
        print(f"{i}. {voice:<14} - {style}")

    raw = input("\nVoice number > ").strip()
    try:
        index = int(raw) - 1
        voice, style = VOICE_CANDIDATES[index]
    except Exception:
        raise SystemExit("Invalid voice number.")

    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    old = cfg.get("tts_voice", "")
    cfg["tts_model"] = "gemini-3.1-flash-tts-preview"
    cfg["tts_voice"] = voice
    cfg["selected_voice_style"] = style

    cfg_path.write_text(
        json.dumps(cfg, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"\n✅ Story voice changed: {old} -> {voice} ({style})")
    print("Next video must regenerate TTS once:")
    print(r"python .\run_story_drama_video_test.py --force-tts")


if __name__ == "__main__":
    main()
