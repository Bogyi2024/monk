from __future__ import annotations
import json
from pathlib import Path

TARGET_DATE='2026-08-18'
TARGET_JOB='122027_drama_default_1'
TARGET_AT='2026-08-18T12:24:45+07:00'
path=Path('state/tt_daily_run')/f'{TARGET_DATE}.json'
if not path.exists():
    raise SystemExit(f'No state file: {path}')
data=json.loads(path.read_text(encoding='utf-8'))
events=data.get('events') or []
match=None
for e in events:
    if e.get('job_id')==TARGET_JOB and e.get('category')=='drama' and e.get('type') in {'job_complete','job_maintenance'}:
        match=e;break
if not match:
    print('ℹ️ Target false-count job is not present; nothing changed.')
    raise SystemExit(0)
if match.get('maintenance_only_fixed'):
    print('ℹ️ Target job was already repaired; nothing changed.')
    raise SystemExit(0)
if int(match.get('count_increment') or 0)!=1:
    print('ℹ️ Target job no longer increments count; nothing changed.')
    raise SystemExit(0)

cat=(data.get('categories') or {}).get('drama') or {}
cat['already_posted']=max(0,int(cat.get('already_posted') or 0)-1)
route=((data.get('route_runtime') or {}).get('routes') or {}).get('drama',{}).get('default') or {}
route['already_posted']=max(0,int(route.get('already_posted') or 0)-1)
# This job was only old group-share maintenance; don't retain a fake primary completion time.
if str(cat.get('last_completed_at') or '')==TARGET_AT: cat['last_completed_at']=''
if str(route.get('last_completed_at') or '')==TARGET_AT: route['last_completed_at']=''
for dkey in ('fb:tadin_sone','tt:tt_drama'):
    d=((data.get('route_runtime') or {}).get('destinations') or {}).get(dkey)
    if isinstance(d,dict) and str(d.get('last_completed_at') or '')==TARGET_AT:
        d.pop('last_completed_at',None)
match['type']='job_maintenance'
match['success']=True
match['count_increment']=0
match['maintenance_kind']='pending_secondary_completed'
match['maintenance_only_fixed']=True
path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('✅ False Drama Today count repaired: 1 → 0 for job 122027_drama_default_1.')
print('✅ Old group-share maintenance event preserved as job_maintenance.')
