from __future__ import annotations
import hashlib,json,py_compile,sys,tempfile,shutil,types,re
from datetime import datetime,timedelta
from pathlib import Path

ROOT=Path.cwd().resolve()
FILES=[
 'tt_master_scheduler.py','tt_web_manager.py','services/tt_settings_service.py',
 'services/tt_long_to_short_night_service.py','services/tt_preparation_status_service.py',
]
for x in FILES: py_compile.compile(str(ROOT/x),doraise=True)
html=(ROOT/'tt_web/index.html').read_text(encoding='utf-8')
for marker in ['Prep buffer days','Future buffer','REFILL NEEDED','Today posting inventory','routeGroupOpen']:
    assert marker in html, marker

pkg=types.ModuleType('services'); pkg.__path__=[str(ROOT/'services')]; sys.modules['services']=pkg
from services.tt_settings_service import TTSettingsService
from services.tt_preparation_status_service import TTPreparationStatusService
from services.tt_long_to_short_night_service import TTLongToShortNightService

settings=TTSettingsService(ROOT)
lts=((settings.categories().get('categories') or {}).get('long_to_short') or {})
for key,row in (lts.get('content_categories') or {}).items():
    days=int((row or {}).get('prep_buffer_days') or 0)
    assert 1 <= days <= 7, f'{key}: invalid prep_buffer_days={days}'

# Synthetic fixture verifies the exact bug that showed READY while counts stayed 0:
# standalone-relative output paths must resolve from long_to_short, not recap_personal.
base=Path(tempfile.mkdtemp(prefix='tt_v2021_verify_'))
try:
    fake_root=base/'recap_personal'; fake_lts=base/'long_to_short'
    fake_root.mkdir(); (fake_lts/'state/tt_bridge/inventory').mkdir(parents=True); (fake_lts/'outputs/run').mkdir(parents=True)
    class FakeSettings:
        def __init__(self): self.root=fake_root
        def categories(self):
            return {'categories':{'long_to_short':{'enabled':True,'content_categories':{'motivation':{
                'label':'Motivation / Self Development','enabled':True,'prep_buffer_days':3,
                'selector_profile':'motivation','source_urls':['https://example.invalid'],
                'min_editorial_score':8.8,'max_candidates_per_source':5,'scan_limit':12,'min_source_minutes':10,
            }},'production_rules':{'night_prep_enabled':True},'routes':{
                'vo':{'label':'Voiceover + MM Sub','enabled':True,'daily_limit':2,'output_type':'transformative_envo_mm','lts_category':'motivation','content_group':'main','facebook_page':'p'},
                'og':{'label':'Original Sound + MM Sub','enabled':True,'daily_limit':2,'output_type':'original_audio_mm','lts_category':'motivation','content_group':'main','facebook_page':'p'},
            }}}}
        def resolve_route(self,cat,rk): return {'facebook':{'enabled':True},'tiktok':None}
    fake=FakeSettings(); svc=TTPreparationStatusService(fake,fake_root); now=datetime.now().astimezone()
    def write_day(offset,n):
        date=(now.date()+timedelta(days=offset)).isoformat(); items=[]
        for i in range(n):
            vo=Path('outputs/run')/f'{date}_{i}_vo.mp4'; og=Path('outputs/run')/f'{date}_{i}_og.mp4'
            (fake_lts/vo).write_bytes(b'x'); (fake_lts/og).write_bytes(b'x')
            items.append({'content_id':f'{date}-{i}','outputs':{'transformative_envo_mm':str(vo),'original_audio_mm':str(og)},'primary_by_route':{}})
        data={'version':1,'date':date,'groups':{'motivation::main':{'items':items}}}
        (fake_lts/'state/tt_bridge/inventory'/f'{date}.json').write_text(json.dumps(data),encoding='utf-8')
        return date
    d1=write_day(1,2)
    snap=svc.lts_snapshot(now)
    assert snap['status']=='REFILL NEEDED'
    assert (snap['unique_ready'],snap['unique_target'])==(2,6)
    assert (snap['files_ready'],snap['files_target'])==(4,12)
    assert svc.lts_route_ready_count(d1,'vo')==2
    write_day(2,2); write_day(3,2)
    snap=svc.lts_snapshot(now)
    assert snap['status']=='READY' and snap['unique_ready']==6 and snap['files_ready']==12
    night=TTLongToShortNightService(fake,fake_root)
    plan=night.plan(); date_plans=night._future_date_plans(now,plan)
    assert len(date_plans)==3
    assert plan['motivation::main']['requirements']=={'transformative_envo_mm':2,'original_audio_mm':2}
finally:
    shutil.rmtree(base,ignore_errors=True)

receipt=ROOT/'state/tt_v2_0_21_install.json'
if receipt.exists():
    rec=json.loads(receipt.read_text(encoding='utf-8'))
    def sha(p):
        h=hashlib.sha256();h.update(p.read_bytes());return h.hexdigest()
    for rel,expected in (rec.get('stable_hashes') or {}).items():
        assert (ROOT/rel).exists() and sha(ROOT/rel)==expected, f'stable hash changed: {rel}'

# Optional live diagnostic: do not fail if the user has no generated LTS stock yet.
try:
    live=TTPreparationStatusService(settings,ROOT).lts_snapshot(datetime.now().astimezone())
    print(f"  live LTS buffer: status={live.get('status')} moments={live.get('unique_ready')}/{live.get('unique_target')} files={live.get('files_ready')}/{live.get('files_target')}")
except Exception as exc:
    print('  live LTS diagnostic skipped:',exc)

print('VERIFY OK — V2.0.21')
print('  prep_buffer_days setting/API/UI: PASS')
print('  3-day date-scoped buffer calculation: PASS')
print('  relative LTS output path reconciliation: PASS')
print('  posting-ready count uses real standalone files: PASS')
print('  stable Recap/Drama/group-share hashes: PASS')
