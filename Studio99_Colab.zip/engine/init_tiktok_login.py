import asyncio
from services.tt_service import init_tiktok_profile

if __name__ == "__main__":
    asyncio.run(init_tiktok_profile("TikTok_Recapentertainment"))
