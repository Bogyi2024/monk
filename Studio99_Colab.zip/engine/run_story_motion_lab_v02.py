from __future__ import annotations

import argparse
from pathlib import Path

from services.story_motion_lab_service import StoryMotionLabService


def menu() -> tuple[str, str]:
    print("\nSTORY MOTION AUDIO + SERIES LAB V0.2")
    print("1) Horror — auto single/Part 1+2")
    print("2) Thriller — auto single/Part 1+2")
    print("3) Horror — FORCE 2-part continuity demo")
    print("4) Thriller — FORCE 2-part continuity demo")
    print("5) Scan Horror audio folders only")
    print("6) Scan Thriller audio folders only")
    value = input("Choose [1]: ").strip() or "1"
    return {
        "1": ("horror", "auto"),
        "2": ("thriller", "auto"),
        "3": ("horror", "2"),
        "4": ("thriller", "2"),
        "5": ("scan_horror", "auto"),
        "6": ("scan_thriller", "auto"),
    }.get(value, ("horror", "auto"))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", choices=["horror", "thriller"], default="")
    ap.add_argument("--parts", choices=["auto", "1", "2"], default="auto")
    ap.add_argument("--input-dir", default="")
    ap.add_argument("--scan-audio", action="store_true")
    ap.add_argument("--no-music", action="store_true")
    args = ap.parse_args()

    service = StoryMotionLabService(Path.cwd())
    if args.preset:
        preset, mode = args.preset, args.parts
    else:
        preset, mode = menu()

    if preset.startswith("scan_"):
        actual = preset.split("_", 1)[1]
        data = service.scan_audio(actual)
        print(f"\nAUDIO POOL — {actual.upper()}")
        for k, vals in data.items():
            print(f"{k:10s}: {len(vals)}")
            for p in vals[:5]:
                print(f"   - {p}")
            if len(vals) > 5:
                print(f"   ... +{len(vals)-5} more")
        return

    if args.scan_audio:
        data = service.scan_audio(preset)
        print(data)
        return

    input_dir = Path(args.input_dir) if args.input_dir else service.newest_story_raw_dir(Path("outputs/story_carousel"))
    print(f"📁 Source: {input_dir}")
    service.build(input_dir=input_dir, preset=preset, part_mode=mode, music=not args.no_music)


if __name__ == "__main__":
    main()
