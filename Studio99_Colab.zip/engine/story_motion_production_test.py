from __future__ import annotations

import asyncio
import base64
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import time
import wave
from pathlib import Path
from typing import Any

from playwright.async_api import async_playwright

from services.story_carousel_service import StoryCarouselService
from services.story_image_sheet_service import StoryImageSheetService
from services.story_motion_lab_service import StoryMotionLabService
from services.gemini_tts_pool_service import GeminiFreeTTSPoolService

try:
    from services.gemini_web_story_image_service import GeminiWebStoryImageService
except Exception:
    GeminiWebStoryImageService = None

def read_json(path: Path, default):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def clean_json_text(raw: str) -> str:
    text = str(raw or "").strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def parse_json(raw: str) -> dict[str, Any]:
    text = clean_json_text(raw)
    try:
        return json.loads(text)
    except Exception:
        a, b = text.find("{"), text.rfind("}")
        if a >= 0 and b > a:
            return json.loads(text[a:b + 1])
        raise


def ffmpeg_run(cmd: list[str], *, quiet: bool = True) -> None:
    p = subprocess.run(
        cmd,
        capture_output=quiet,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if p.returncode != 0:
        raise RuntimeError((p.stderr or p.stdout or "")[-5000:])


class CaptionPNG:
    def __init__(self, story: StoryCarouselService, style: dict | None = None):
        self.story = story
        self.style = dict(style or {})
        self.pw = None
        self.browser = None
        self.page = None
        self.font_b64 = ""

    async def __aenter__(self):
        try:
            font = self.story._find_story_font_file()
            if font and Path(font).exists():
                self.font_b64 = base64.b64encode(Path(font).read_bytes()).decode("ascii")
        except Exception:
            pass
        self.pw = await async_playwright().start()
        self.browser = await self.pw.chromium.launch(headless=True)
        self.page = await self.browser.new_page(viewport={"width": 1000, "height": 460})
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if self.browser:
            await self.browser.close()
        if self.pw:
            await self.pw.stop()

    async def render(self, text: str, path: Path, lang: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        face = ""
        if self.font_b64:
            face = f"""@font-face{{font-family:StoryMM;src:url(data:font/ttf;base64,{self.font_b64}) format('truetype');}}"""
        family = "StoryMM,'Myanmar Text','Pyidaungsu','Noto Sans Myanmar',Arial,sans-serif" if lang == "mm" else "Arial,'Arial Black',sans-serif"
        body = html.escape(str(text or "").strip(), quote=True)
        font_size = int(self.style.get('mm_font_size' if lang == 'mm' else 'en_font_size', self.style.get('font_size', 76)))
        min_font_size = int(self.style.get('mm_min_font_size' if lang == 'mm' else 'en_min_font_size', self.style.get('min_font_size', 42)))
        stroke = float(self.style.get("stroke_px", 3.0))
        # Reference look: pure white letters, crisp black outline, tiny hard shadow.
        # No grey rectangle and no large blurred shadow cloud behind the caption.
        italic = "normal" if lang == "mm" else ("italic" if self.style.get("english_italic", True) else "normal")
        markup = f"""<!doctype html><html><head><meta charset="utf-8"><style>
        {face}
        html,body{{width:1000px;height:460px;margin:0;background:transparent!important;overflow:hidden}}
        body{{display:flex;align-items:center;justify-content:center;background:transparent!important}}
        #t{{width:930px;max-height:400px;box-sizing:border-box;text-align:center;padding:14px;background:transparent!important;
            font-family:{family};font-size:{font_size}px;line-height:1.20;font-weight:900;font-style:{italic};color:#fff;
            -webkit-text-stroke:{stroke:.1f}px #000;paint-order:stroke fill;
            text-shadow:0 2px 0 #000}}
        </style></head><body><div id="t">{body}</div>
        <script>let e=document.getElementById('t'),s={font_size};
        while(s>{min_font_size}&&(e.scrollHeight>400||e.scrollWidth>930)){{s-=2;e.style.fontSize=s+'px';}}</script>
        </body></html>"""
        await self.page.set_content(markup, wait_until="domcontentloaded")
        await self.page.wait_for_timeout(60)
        fits = await self.page.locator("#t").evaluate(
            "e => { const r=e.getBoundingClientRect(); return e.scrollHeight<=400 && e.scrollWidth<=930 && r.top>=0 && r.bottom<=460; }"
        )
        if not fits:
            raise RuntimeError(
                f"Story Motion subtitle exceeds the safe caption box at minimum font size ({lang})."
            )
        await self.page.locator("#t").screenshot(path=str(path), omit_background=True)


class ProductionTest:
    def __init__(self):
        self.cfg = read_json(Path("config/story_motion_production_test.json"), {})
        self.story = StoryCarouselService()
        self.fx = StoryMotionLabService(Path.cwd(), motion_config=self.cfg.get("motion_fx", {}))
        self.state = Path("state")
        self.state.mkdir(parents=True, exist_ok=True)
        self.output_root = Path(self.cfg.get("output_root", "outputs/story_motion_production_test"))
        self._tts_pool = None

    def _free_tts_pool(self) -> GeminiFreeTTSPoolService:
        # ProductionStoryMotionService replaces self.cfg after construction, so the
        # pool must be lazy and read the final production config on first TTS use.
        if self._tts_pool is None:
            self._tts_pool = GeminiFreeTTSPoolService(self.cfg)
        return self._tts_pool

    def _recent(self, genre: str) -> str:
        reg = read_json(self.state / "story_motion_story_registry.json", {"stories": []})
        rows = [x for x in reg.get("stories", []) if x.get("genre") == genre][-25:]
        if not rows:
            return "(none)"
        return "\n".join(f"- {x.get('title','')} | {x.get('premise','')} | {x.get('ending_signature','')}" for x in rows)

    def _remember(self, genre: str, story_id: str, plan: dict) -> None:
        path = self.state / "story_motion_story_registry.json"
        reg = read_json(path, {"stories": []})
        sig = re.sub(r"\s+", " ", f"{plan.get('title','')}|{plan.get('premise','')}|{plan.get('ending_signature','')}".casefold()).strip()
        if sig in {x.get("signature") for x in reg.get("stories", [])}:
            raise RuntimeError("Exact story signature already exists. Run again.")
        reg.setdefault("stories", []).append({
            "story_id": story_id,
            "genre": genre,
            "title": plan.get("title", ""),
            "premise": plan.get("premise", ""),
            "ending_signature": plan.get("ending_signature", ""),
            "signature": sig,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        })
        reg["stories"] = reg["stories"][-300:]
        write_json(path, reg)

    def _narration_counts(self, plan: dict) -> tuple[int, int]:
        scenes = plan.get("scenes") or []
        mm = sum(len(str(x.get("narration_mm") or "")) for x in scenes)
        en = sum(len(re.findall(r"\S+", str(x.get("narration_en") or ""))) for x in scenes)
        return mm, en

    async def _repair_narration_lengths(self, plan: dict, *, genre: str) -> dict:
        """Repair ONLY narration that is too short. Long narration is valid.

        Story Motion/Horror no longer has a maximum character/word budget. The
        renderer is audio-locked, so longer narration simply gives each scene a
        longer matching motion duration instead of being trimmed or compressed.
        """
        mm_min = int(self.cfg.get("mm_narration_min_chars", 650))
        en_min = int(self.cfg.get("en_narration_min_words", 145))
        retries = int(self.cfg.get("narration_repair_retries", 5))

        for repair_attempt in range(0, retries + 1):
            mm, en = self._narration_counts(plan)
            mm_ok = mm >= mm_min
            en_ok = en >= en_min
            if mm_ok and en_ok:
                print(f"✅ Story Motion narration minimum locked | MM={mm} chars | EN={en} words | NO upper limit")
                return plan

            if repair_attempt >= retries:
                raise RuntimeError(
                    f"Narration expansion failed after {retries} tries: "
                    f"MM={mm} (need at least {mm_min}), EN={en} (need at least {en_min})"
                )

            print(
                f"➕ Story Motion narration expansion {repair_attempt+1}/{retries} — "
                f"MM={mm}, EN={en} | only undersized narration is repaired"
            )

            compact = {
                "genre": genre,
                "title": plan.get("title", ""),
                "premise": plan.get("premise", ""),
                "scenes": [
                    {
                        "scene_no": int(s.get("scene_no") or i),
                        "narration_mm": str(s.get("narration_mm") or ""),
                        "narration_en": str(s.get("narration_en") or ""),
                    }
                    for i, s in enumerate(plan.get("scenes") or [], 1)
                ],
            }

            repair_prompt = f"""
Rewrite ONLY narration_mm and narration_en in this existing {genre} story, and ONLY to make an undersized narration long enough.

DO NOT change:
- title, premise, story events, scene order or scene count
- hook, twist, ending, character identity, visual prompts or captions
- any narration language that is already comfortably above its minimum; never shorten it just to fit a budget

CURRENT MEASURED LENGTHS:
Myanmar = {mm} characters
English = {en} words

MINIMUM-ONLY RULES:
- Exactly {len(compact['scenes'])} scenes.
- Myanmar TOTAL must be at least {mm_min} characters. THERE IS NO MAXIMUM CHARACTER LIMIT.
- English TOTAL must be at least {en_min} words. THERE IS NO MAXIMUM WORD LIMIT.
- Never trim, summarize away, or remove story facts/ending because narration is long.
- Keep Scene 1 punchy, then let later scenes breathe naturally.
- Preserve the SAME meaning/event in Myanmar and English.
- Natural spoken Burmese and natural cinematic English.

Return JSON ONLY:
{{
  "scenes": [
    {{"scene_no": 1, "narration_mm": "...", "narration_en": "..."}}
  ]
}}

INPUT:
{json.dumps(compact, ensure_ascii=False)}
"""
            try:
                try:
                    self.story.ai._enable_proxy()
                except Exception:
                    pass
                res = self.story.ai.generate_content(
                    model=self.story.ai.text_model, contents=repair_prompt
                )
                fixed = parse_json(res.text)
                rows = fixed.get("scenes") or []
                if len(rows) != len(plan.get("scenes") or []):
                    raise ValueError(f"repair scene count {len(rows)} != {len(plan.get('scenes') or [])}")

                by_no = {}
                for i, row in enumerate(rows, 1):
                    no = int(row.get("scene_no") or i)
                    mm_text = re.sub(r"\s+", " ", str(row.get("narration_mm") or "")).strip()
                    en_text = re.sub(r"\s+", " ", str(row.get("narration_en") or "")).strip()
                    if not mm_text or not en_text:
                        raise ValueError(f"repair scene {no} missing narration")
                    by_no[no] = (mm_text, en_text)

                for i, scene in enumerate(plan["scenes"], 1):
                    no = int(scene.get("scene_no") or i)
                    if no not in by_no:
                        raise ValueError(f"repair missing scene {no}")
                    old_mm = str(scene.get("narration_mm") or "")
                    old_en = str(scene.get("narration_en") or "")
                    new_mm, new_en = by_no[no]
                    # Never shorten a language that was already at/above minimum.
                    scene["narration_mm"] = old_mm if mm_ok else new_mm
                    scene["narration_en"] = old_en if en_ok else new_en

            except Exception as exc:
                print(f"⚠️ Story Motion narration expansion API attempt failed: {exc}")
                await asyncio.sleep(min(2 * (repair_attempt + 1), 6))
            finally:
                try:
                    self.story.ai._disable_proxy()
                except Exception:
                    pass

        return plan

    async def make_plan(self, genre: str, seed: str = "") -> dict:
        n = int(self.cfg.get("scene_count", 12))
        recent = self._recent(genre)
        style = "supernatural/psychological horror" if genre == "horror" else "psychological thriller/suspense"
        mm_min = int(self.cfg.get("mm_narration_min_chars", 650))
        en_min = int(self.cfg.get("en_narration_min_words", 145))

        prompt = f"""
Create one ORIGINAL {style} vertical short-film story.

Target: at least 60 seconds of narration; it may naturally run longer when the story needs it.
Exactly {n} scenes.
Strong 0-2 second hook. Escalate every scene. Ending must have a memorable sting.
No copying movies, novels, creepypasta, urban legends or viral scripts.
No graphic gore.
Recurring characters must keep one clear visual identity.
Images are 9:16, cinematic, dark, text-free, with foreground/midground/background depth.
VISUAL STYLE IS LOCKED ACROSS ALL SCENES: dark stylized 2D horror/thriller comic, clean inked outlines, cel-shaded illustrated characters, moody cinematic lighting.
NEVER describe scenes as photos, photorealistic, live-action, DSLR, realistic portrait, 3D render, glossy CGI, Pixar-like 3D, watercolor, oil painting, or mixed art styles.
Keep the same character face, hairstyle, clothing, skin tone, body proportions, and accessories from scene to scene.
Every visual_prompt must restate the complete appearance and clothing of each character actually visible in that scene; never rely on character_bible alone.
For every scene return present_characters and absent_characters arrays. A character who is only remembered, mentioned, represented by an object/wisp, has already left, or is explicitly missing belongs in absent_characters, not present_characters.
Each scene must support a long slow push/pan shot, not a slideshow-looking composition.
Every visual_prompt must describe ONE CONTINUOUS FULL-FRAME SHOT: exactly one camera viewpoint, one instant in time and one undivided 9:16 environment. Never request a collage, comic page, storyboard, contact sheet, split screen, stacked rows, tiled/repeated copies, repeated subject, panel border, before-and-after, or picture-in-picture.
Each visual_prompt must show the exact narrative moment spoken in that same scene, never an event from the previous or next scene.
Concrete details must agree exactly across narration and visual_prompt: object type/color, clothing, location, who is present, and the action already completed at that moment.

Write the SAME story in natural spoken Burmese and natural international English.

NARRATION LENGTH RULES:
- Myanmar TOTAL must be at least {mm_min} characters. THERE IS NO MAXIMUM CHARACTER LIMIT.
- English TOTAL must be at least {en_min} words. THERE IS NO MAXIMUM WORD LIMIT.
- Do not trim, compress, or remove story events/ending just because narration is long.
- Longer narration is valid: final scene motion durations will follow the real scene audio exactly.
- Keep narration meaningful rather than padded; do not repeat visual description unnecessarily.

Each scene also gets one VERY SHORT bold center caption (2-7 words / short Burmese phrase).
Choose a natural candidate cliffhanger around scene 6-8 for possible Part 1/2.
Optional seed: {seed or "(invent a new premise)"}

RECENT STORIES TO AVOID:
{recent}

Return JSON only:
{{
  "title":"...",
  "premise":"...",
  "character_bible":"...",
  "ending_signature":"...",
  "part_break_after_scene":7,
  "caption_mm":"...",
  "caption_en":"...",
  "scenes":[
    {{
      "scene_no":1,
      "narration_mm":"...",
      "narration_en":"...",
      "caption_mm":"...",
      "caption_en":"...",
      "present_characters":["exact character names visibly present"],
      "absent_characters":["mentioned but not visibly present character names"],
      "visual_prompt":"English 9:16 cinematic image prompt; no text",
      "cliffhanger_score":0
    }}
  ]
}}
"""
        last = None
        # Structural generation retries are now separate from narration-length
        # repair. A good story is not thrown away just because Burmese is verbose.
        for attempt in range(1, int(self.cfg.get("plan_retries", 4)) + 1):
            try:
                try:
                    self.story.ai._enable_proxy()
                except Exception:
                    pass
                res = self.story.ai.generate_content(
                    model=self.story.ai.text_model,
                    contents=prompt,
                )
                plan = parse_json(res.text)
                scenes = plan.get("scenes") or []
                if len(scenes) != n:
                    raise ValueError(f"scene count {len(scenes)} != {n}")
                for i, scene in enumerate(scenes, 1):
                    scene["scene_no"] = i
                    for key in ("narration_mm","narration_en","caption_mm","caption_en","visual_prompt"):
                        if not str(scene.get(key) or "").strip():
                            raise ValueError(f"scene {i} missing {key}")
                    scene["present_characters"]=[str(x).strip() for x in (scene.get("present_characters") or []) if str(x).strip()]
                    scene["absent_characters"]=[str(x).strip() for x in (scene.get("absent_characters") or []) if str(x).strip()]
                    overlap=set(x.casefold() for x in scene["present_characters"]) & set(x.casefold() for x in scene["absent_characters"])
                    if overlap:
                        raise ValueError(f"scene {i} cast overlap: {sorted(overlap)}")

                mm, en = self._narration_counts(plan)
                print(f"📝 Initial narration | MM={mm} chars | EN={en} words")

                # Preserve the accepted story/visual plan and repair only narration.
                plan = await self._repair_narration_lengths(plan, genre=genre)

                mm, en = self._narration_counts(plan)
                print(f"✅ Story plan ready | scenes={n} | MM={mm} chars | EN={en} words")
                return plan
            except Exception as exc:
                last = exc
                print(f"⚠️ Plan retry {attempt}: {exc}")
                await asyncio.sleep(min(2 * attempt, 6))
            finally:
                try:
                    self.story.ai._disable_proxy()
                except Exception:
                    pass
        raise RuntimeError(f"Story plan failed: {last}")

    def locked_visual_prompt(
        self, genre: str, scene_prompt: str, character_bible: str,
        present_characters: list[str] | None = None,
        absent_characters: list[str] | None = None,
    ) -> str:
        """Hard style/character lock for every image provider."""
        if genre == "horror":
            style = (
                "STRICT VISUAL STYLE LOCK: polished dark 2D horror comic / animated-series frame, "
                "clean confident inked outlines, stylized human anatomy, expressive illustrated faces, "
                "controlled cel shading with subtle cinematic gradients, deep teal-blue-green and charcoal palette, "
                "moody low-key lighting, deep readable shadows, eerie rim light, supernatural dread, "
                "cinematic foreground/midground/background depth. "
                "The image must look DRAWN / ILLUSTRATED, never photographic."
            )
        else:
            style = (
                "STRICT VISUAL STYLE LOCK: polished dark 2D psychological-thriller comic / animated-series frame, "
                "clean confident inked outlines, stylized human anatomy, expressive illustrated faces, "
                "controlled cel shading with subtle cinematic gradients, cold blue-green and charcoal palette, "
                "high-contrast suspense lighting, cinematic foreground/midground/background depth. "
                "The image must look DRAWN / ILLUSTRATED, never photographic."
            )

        consistency = (
            "CHARACTER CONSISTENCY LOCK: preserve the exact same face shape, skin tone, hairstyle, hair color, age, "
            "body proportions, clothing colors, accessories and overall character design in every scene. "
            "If a mirror/reflection appears, it must clearly be the SAME character unless the story explicitly "
            "requires a supernatural variation; never invent an unrelated second person."
        )

        cast_lock = (
            "SCENE CAST LOCK: the character bible is an appearance reference, NOT a list of people that must appear. "
            "Show only the character or characters explicitly present in SCENE ACTION. If the action names or implies "
            "one person, draw exactly one person. If a character has left, is absent, or has not entered yet, do not "
            "show that character, their reflection, silhouette, portrait, or duplicate. Never invent an extra person."
        )

        composition = (
            "VERTICAL VIDEO COMPOSITION: 9:16, readable on a phone, important faces and actions away from the "
            "extreme top/bottom edges, useful depth for slow zoom/pan motion, some clean center/lower-center space "
            "for later caption overlay, no baked-in text. ONE CONTINUOUS FULL-FRAME SHOT: exactly one camera "
            "viewpoint, one instant in time, and one coherent undivided environment filling the entire canvas. "
            "This is a single cinematic illustration, NOT a comic page or panel layout. Never collage, storyboard, "
            "contact sheet, split screen, stacked rows, tiled copies, repeated scene, repeated subject, panel border, "
            "frame divider, before-and-after, or picture-in-picture."
        )

        avoid = (
            "STRICTLY AVOID: photorealism, realistic photography, live-action look, DSLR/camera photo, realistic skin pores, "
            "3D render, Pixar-like 3D, glossy CGI, clay render, watercolor, oil painting, sketch-only style, chibi, "
            "cute comedy cartoon, random anime style changes, mixed art styles, inconsistent faces, different outfit, "
            "bright cheerful lighting, flat daylight, text, subtitles, letters, watermark, logo."
        )

        present=[str(x).strip() for x in (present_characters or []) if str(x).strip()]
        absent=[str(x).strip() for x in (absent_characters or []) if str(x).strip()]
        model=str(getattr(getattr(self,'story',None),'config',{}).get('fal_model') or '').rstrip('/')
        if model in {'fal-ai/flux/schnell','fal-ai/flux-1/schnell'}:
            # Schnell follows short concrete prompts better than a large global bible.
            # The planner repeats visible appearance in scene_prompt, while explicit
            # cast arrays prevent mentioned/absent characters from leaking in.
            cast=(", ".join(present) if present else "only the people explicitly visible in the scene action")
            excluded=(", ".join(absent) if absent else "all people not explicitly visible in the scene action")
            return (
                f"Vertical 9:16 dark polished 2D {genre} single cinematic illustration, clean ink outlines, cel shading, "
                "deep teal and charcoal cinematic lighting, illustrated not photo or 3D. "
                "ONE CONTINUOUS FULL-FRAME SHOT: exactly one camera viewpoint, one instant, and one coherent "
                "undivided environment filling the entire canvas. Never collage, comic page, storyboard, contact "
                "sheet, split screen, stacked rows, tiled copies, repeated scene, repeated subject, panel border, "
                "frame divider, before-and-after, or picture-in-picture. "
                f"VISIBLE CAST ONLY: {cast}. EXCLUDE COMPLETELY: {excluded}. "
                f"SCENE: {str(scene_prompt or '').strip()} "
                "Character names are identifiers only and must never appear as writing. Exactly follow the location, "
                "action, props, clothing, shot size and cast stated in SCENE. No extra person, portrait, reflection, "
                "silhouette or duplicate. No text, name, caption, letters, numbers, watermark, logo, border or poster layout."
            )

        return (
            f"{style}\n"
            f"{consistency}\n"
            f"CHARACTER BIBLE: {str(character_bible or '').strip()}\n"
            f"{cast_lock}\n"
            f"SCENE ACTION: {str(scene_prompt or '').strip()}\n"
            f"{composition}\n"
            f"{avoid}"
        )

    async def _generate_locked_fal_with_policy_rewrite(
        self,
        locked_prompt: str,
        save_path: Path,
        *,
        width: int | None = None,
        height: int | None = None,
    ) -> Path:
        """Story-Motion-specific FAL wrapper with safe 422 rewrite.

        Story Motion intentionally sends the fully locked 2D prompt directly to FAL so
        StoryCarouselService._build_image_prompt() cannot append conflicting realistic
        wording.  The direct call used to bypass StoryCarouselService's content-policy
        rewrite loop; this wrapper restores that protection while keeping the SAME story,
        SAME scene, SAME output path and safety checker.
        """
        active_prompt = str(locked_prompt or '').strip()
        max_rewrites = max(0, int(self.story.config.get('fal_policy_rewrite_retries', 2) or 2))
        rewrite_no = 0
        while True:
            try:
                return self.story._generate_scene_image_fal(
                    active_prompt,
                    save_path,
                    width=width,
                    height=height,
                )
            except Exception as exc:
                if not self.story._is_fal_content_policy_violation(exc):
                    raise
                if rewrite_no >= max_rewrites:
                    print(
                        f"🛡️ Story Motion FAL 422 remains after {rewrite_no} safe rewrite(s) — "
                        "stopping without regenerating the story."
                    )
                    raise
                rewrite_no += 1
                print(
                    f"🛡️ Story Motion FAL 422 content_policy_violation — "
                    f"safe rewrite {rewrite_no}/{max_rewrites}; SAME story / SAME scene."
                )
                # The previous FAL request is terminally rejected. Never resume that
                # request_id after the prompt changes; the rewritten prompt gets a fresh
                # request while already-completed scene JPGs remain untouched.
                try:
                    save_path.with_suffix(save_path.suffix + '.fal_queue.json').unlink(missing_ok=True)
                except Exception:
                    pass
                active_prompt = await self.story._rewrite_fal_policy_prompt(active_prompt, rewrite_no)
                print('✍️ Story Motion policy-safe prompt ready → retrying SAME scene only')
                await asyncio.sleep(0.5)

    async def _make_images_fal_sheets(self, plan: dict, raw: Path) -> list[Path]:
        scenes = list(plan.get('scenes') or [])
        targets = [raw / f'scene_{i:02d}.jpg' for i in range(1, len(scenes) + 1)]
        scene_groups = StoryImageSheetService.groups(scenes)
        target_groups = StoryImageSheetService.groups(targets)
        sheet_dir = raw / '_sheets'
        sheet_dir.mkdir(parents=True, exist_ok=True)
        sheet_width = int(self.cfg.get('image_sheet_width', 1152))
        sheet_height = int(self.cfg.get('image_sheet_height', 2048))
        crop_width = int(self.cfg.get('image_sheet_crop_width', 720))
        crop_height = int(self.cfg.get('image_sheet_crop_height', 1280))
        inset = float(self.cfg.get('image_sheet_crop_inset_fraction', 0.008))
        genre = str(plan.get('genre') or 'horror').lower()
        character_bible = str(plan.get('character_bible') or '')
        palette = 'deep teal-blue-green and charcoal' if genre == 'horror' else 'cold blue-green and charcoal'
        global_style = (
            f"Polished dark 2D {genre} comic / animated-series frames; clean ink outlines, "
            f"cel shading, {palette} palette, moody cinematic lighting. Drawn illustration only, "
            "never photo or 3D. Same character design and clothing in all relevant panels."
        )
        print(
            f"🧩 Story Motion 2x2 image sheets: {len(scene_groups)} FAL call(s) "
            f"→ {len(scenes)} scene crop(s)"
        )

        for group_index, (scene_group, target_group) in enumerate(
            zip(scene_groups, target_groups),
            1,
        ):
            if StoryImageSheetService.all_valid(target_group):
                print(f"♻️ Story Motion sheet group {group_index}: all crops already ready")
                continue
            sheet_path = sheet_dir / f'sheet_{group_index:02d}.jpg'
            if not StoryImageSheetService.all_valid([sheet_path]):
                prompt = StoryImageSheetService.build_prompt(
                    scene_prompts=[str(x.get('visual_prompt') or '') for x in scene_group],
                    character_bible=character_bible,
                    global_style=global_style,
                )
                await self._generate_locked_fal_with_policy_rewrite(
                    prompt,
                    sheet_path,
                    width=sheet_width,
                    height=sheet_height,
                )
            StoryImageSheetService.crop_sheet(
                sheet_path=sheet_path,
                output_paths=target_group,
                output_size=(crop_width, crop_height),
                inset_fraction=inset,
                overwrite=False,
                manifest_path=sheet_dir / f'sheet_{group_index:02d}_manifest.json',
            )
            if not StoryImageSheetService.all_valid(target_group):
                raise RuntimeError(
                    f'Story Motion 2x2 crop validation failed for group {group_index}'
                )
        return targets

    async def make_images(self, plan: dict, raw: Path) -> list[Path]:
        raw.mkdir(parents=True, exist_ok=True)
        provider = str(self.story.config.get("image_provider") or "fal").lower().strip()
        print(f"🖼️ Image provider = {provider}")
        if provider == 'fal' and bool(self.cfg.get('image_sheet_enabled', False)):
            return await self._make_images_fal_sheets(plan, raw)
        web = None
        if provider == "gemini_web":
            if GeminiWebStoryImageService is None:
                raise RuntimeError("gemini_web provider selected but service import failed")
            web = GeminiWebStoryImageService(self.story.config)
        out = []
        try:
            for i, scene in enumerate(plan["scenes"], 1):
                p = raw / f"scene_{i:02d}.jpg"
                if p.exists() and p.stat().st_size >= 5000:
                    print(f"♻️ Image {i:02d}/{len(plan['scenes'])} reuse → {p}")
                    out.append(p)
                    continue
                print(f"🎨 Image {i:02d}/{len(plan['scenes'])}")
                locked_prompt = self.locked_visual_prompt(
                    plan.get("genre", "horror"),
                    scene["visual_prompt"],
                    plan.get("character_bible", ""),
                    scene.get("present_characters"),
                    scene.get("absent_characters"),
                )
                if web:
                    prompt = self.story._build_image_prompt(locked_prompt, plan.get("character_bible", ""))
                    ref = raw / "scene_01.jpg" if i > 1 and (raw / "scene_01.jpg").exists() else None
                    await web.generate_image(prompt=prompt, save_path=p, reference_image_path=ref)
                else:
                    if provider == "fal":
                        # V0.3.2: locked_prompt is already complete. Call FAL directly
                        # so the generic Story Carousel prompt wrapper cannot append
                        # conflicting "realistic dramatic lighting" language.
                        await self._generate_locked_fal_with_policy_rewrite(locked_prompt, p)
                    else:
                        await self.story._generate_scene_image(
                            locked_prompt,
                            plan.get("character_bible", ""),
                            p,
                        )
                if not p.exists() or p.stat().st_size < 5000:
                    raise RuntimeError(f"Bad image: {p}")
                out.append(p)
        finally:
            if web:
                await web.close()
        return out

    def _save_pcm_or_wav(self, data: bytes, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        if data[:4] == b"RIFF":
            path.write_bytes(data)
            return
        with wave.open(str(path), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(24000)
            wf.writeframes(data)

    def tts(self, text: str, lang: str, path: Path, *, force: bool = False) -> None:
        # Resume-safe: do not pay for TTS again if a valid file already exists.
        if not force:
            try:
                if path.exists() and path.stat().st_size >= 5000 and self.fx.duration(path) > 3.0:
                    print(f"♻️ TTS {lang.upper()} reuse → {path}")
                    return
            except Exception:
                pass

        model = str(self.cfg.get("tts_model", "gemini-3.1-flash-tts-preview"))
        voice = str(self.cfg.get("myanmar_voice" if lang == "mm" else "english_voice") or ("Gacrux" if lang == "mm" else "Algenib"))
        direction = str(self.cfg.get("myanmar_tts_direction" if lang == "mm" else "english_tts_direction") or "")
        prompt = f"{direction}\n\n{text}"
        print(f"🎙️ TTS {lang.upper()} | {voice}")
        try:
            self.story.ai._enable_proxy()
        except Exception:
            pass
        try:
            result = self._free_tts_pool().synthesize(
                prompt=prompt,
                model=model,
                voice=voice,
            )
            self._save_pcm_or_wav(result.data, path)
            print(f"✅ TTS FREE pool ready → {result.key_alias}")
        finally:
            try:
                self.story.ai._disable_proxy()
            except Exception:
                pass

    def tts_story(self, scenes: list[dict], lang: str, path: Path, *, force: bool = False) -> None:
        """Generate one continuous narrator track with explicit inter-scene pauses.

        This mirrors the proven live Drama Motion architecture: scene boundaries are
        intentionally audible/silent in the source WAV so the renderer can recover
        exact image timing from the audio instead of guessing from text length.
        """
        key = "narration_mm" if lang == "mm" else "narration_en"
        texts=[re.sub(r"\s+", " ", str(s.get(key) or "")).strip() for s in scenes]
        if not texts or any(not x for x in texts):
            raise RuntimeError(f"TTS story has empty {lang.upper()} scene narration")
        # Resume-safe by default; force=True is used only by the explicit
        # "TTS ONLY regenerate" menu, which never touches story text or images.
        if not force:
            try:
                if path.exists() and path.stat().st_size >= 5000 and self.fx.duration(path) > 3.0:
                    print(f"♻️ TTS {lang.upper()} reuse → {path}")
                    return
            except Exception:
                pass
        else:
            print(f"🎙️ FORCE TTS ONLY regenerate → {lang.upper()} | images remain untouched")
        # One continuous voice is retained, but the transcript now has two distinct
        # boundary classes. Long pauses lock image/scene changes; brief pauses lock
        # subtitle changes inside that scene. This removes the old ambiguity where
        # ordinary dramatic silences could be mistaken for scene boundaries.
        chunk_limit=int(self.cfg.get('subtitle_mm_max_chars',44) if lang=='mm' else self.cfg.get('subtitle_en_max_chars',42))
        chunked=[self._subtitle_chunks(text,lang,chunk_limit) for text in texts]
        transcript = " [long scene pause] ".join(
            " [brief subtitle pause] ".join(parts) for parts in chunked
        )
        pause_min=max(1.20,float(self.cfg.get('scene_pause_min_seconds',2.20)))
        pause_max=max(pause_min,float(self.cfg.get('scene_pause_max_seconds',2.60)))
        brief_min=max(0.28,float(self.cfg.get('subtitle_pause_min_seconds',0.52)))
        brief_max=max(brief_min,float(self.cfg.get('subtitle_pause_max_seconds',0.72)))
        if lang == "mm":
            rules=(
                f"There are exactly {len(texts)} Burmese story sections. Use ONE single Burmese narrator for the entire recording. "
                f"Read only the story text. At every [long scene pause] tag, make a clean silent gap around {pause_min:.2f} to {pause_max:.2f} seconds. "
                f"At every [brief subtitle pause] tag, make a smaller clean silent gap around {brief_min:.2f} to {brief_max:.2f} seconds. "
                "Inside each text chunk, keep all natural pauses below 0.35 seconds. Never replace a long scene pause with a brief pause. "
                "Do not speak tags, labels, or instructions. "
            )
        else:
            rules=(
                f"There are exactly {len(texts)} English story sections. Use ONE single English narrator for the entire recording. "
                f"Read only the story text. At every [long scene pause] tag, make a clean silent gap around {pause_min:.2f} to {pause_max:.2f} seconds. "
                f"At every [brief subtitle pause] tag, make a smaller clean silent gap around {brief_min:.2f} to {brief_max:.2f} seconds. "
                "Inside each text chunk, keep all natural pauses below 0.35 seconds. Never replace a long scene pause with a brief pause. "
                "Do not speak tags, labels, or instructions. "
            )
        self.tts(
            rules + "\n\nTRANSCRIPT:\n" + transcript,
            lang,
            path,
            force=force,
        )

    def _dur(self, media: Path) -> float:
        return self.fx.duration(media)

    def _expected_boundaries(self, plan: dict, lang: str, total_duration: float) -> list[float]:
        key = "narration_mm" if lang == "mm" else "narration_en"
        weights = []
        for scene in plan.get("scenes") or []:
            value = re.sub(r"\s+", "", str(scene.get(key) or ""))
            weights.append(max(1, len(value)))
        total_weight = float(sum(weights) or 1.0)
        out=[]
        cumulative=0.0
        for weight in weights[:-1]:
            cumulative += float(weight)
            out.append(float(total_duration) * cumulative / total_weight)
        return out

    def _detect_silences(self, audio_path: Path, *, noise: str, minimum: float) -> list[tuple[float, float]]:
        cmd = [
            self.fx.ffmpeg, '-hide_banner', '-i', str(audio_path),
            '-af', f'silencedetect=noise={noise}:d={minimum:.3f}',
            '-f', 'null', '-'
        ]
        p = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace')
        lines = ((p.stderr or '') + '\n' + (p.stdout or '')).splitlines()
        starts=[]
        intervals=[]
        for line in lines:
            m=re.search(r'silence_start:\s*([0-9.]+)', line)
            if m:
                starts.append(float(m.group(1)))
                continue
            m=re.search(r'silence_end:\s*([0-9.]+)', line)
            if m and starts:
                s=starts.pop(0); e=float(m.group(1))
                if e>s:
                    intervals.append((s,e))
        return intervals

    def _scene_timing_from_global_subtitle_pauses(
        self,
        plan: dict,
        lang: str,
        audio_path: Path,
        total: float,
    ) -> tuple[list[float], str, list[dict]] | None:
        """Recover scene cuts from the verified sequence of subtitle pauses.

        Gemini can shorten one requested long scene delimiter while still keeping
        every requested subtitle delimiter. Matching the complete ordered chunk
        sequence to real pauses identifies each scene-ending chunk without using a
        guessed text-ratio cut.
        """
        if not bool(self.cfg.get('subtitle_chunk_sync_enabled',False)):
            return None
        if not bool(self.cfg.get('scene_global_subtitle_pause_fallback_enabled',True)):
            return None
        scenes=plan.get('scenes') or []
        key='narration_mm' if lang=='mm' else 'narration_en'
        capkey='caption_mm' if lang=='mm' else 'caption_en'
        chunk_limit=int(
            self.cfg.get('subtitle_mm_max_chars',44)
            if lang=='mm' else self.cfg.get('subtitle_en_max_chars',42)
        )
        chunks=[];scene_end_chunk_counts=[]
        for scene in scenes:
            text=re.sub(r"\s+"," ",str(scene.get(key) or scene.get(capkey) or "")).strip()
            parts=self._subtitle_chunks(text,lang,chunk_limit)
            if not parts:
                return None
            chunks.extend(parts);scene_end_chunk_counts.append(len(chunks))
        if len(chunks) <= 1:
            return None

        weights=[max(1,len(re.sub(r"\s+","",text))) for text in chunks]
        total_weight=float(sum(weights) or 1.0)
        expected=[];cumulative=0.0
        for weight in weights[:-1]:
            cumulative+=float(weight)
            expected.append(float(total)*cumulative/total_weight)
        noise=str(self.cfg.get('subtitle_silence_noise','-40dB'))
        minimum=float(self.cfg.get('subtitle_silence_min_seconds',0.42))
        candidates=[]
        for start,end in self._detect_silences(audio_path,noise=noise,minimum=minimum):
            center=(start+end)/2.0
            if start < 0.60 or end > total-0.60:
                continue
            candidates.append({
                'start':start,'end':end,'duration':end-start,'center':center,
                'noise':noise,'minimum':minimum,
            })
        chosen=self._pick_monotonic_boundaries(candidates,expected,total)
        if len(chosen) != len(expected):
            print(
                f"⚠️ {lang.upper()} global subtitle pause map incomplete: "
                f"needed {len(expected)}, selected {len(chosen)}/{len(candidates)}"
            )
            return None
        max_deviation=max(
            (abs(float(actual)-float(target)) for actual,target in zip(chosen,expected)),
            default=0.0,
        )
        allowed=max(0.5,float(self.cfg.get('scene_global_chunk_max_deviation_seconds',2.5)))
        if max_deviation > allowed:
            print(
                f"⚠️ {lang.upper()} global subtitle pause map rejected: "
                f"max deviation {max_deviation:.2f}s > {allowed:.2f}s"
            )
            return None
        scene_boundaries=[chosen[count-1] for count in scene_end_chunk_counts[:-1]]
        if len(scene_boundaries) != max(0,len(scenes)-1):
            return None
        points=[0.0]+scene_boundaries+[float(total)]
        durations=[max(0.05,points[i+1]-points[i]) for i in range(len(scenes))]
        print(
            f"🎯 {lang.upper()} scene sync from GLOBAL VERIFIED SUBTITLE PAUSES | "
            f"selected {len(chosen)}/{len(candidates)} | max deviation={max_deviation:.2f}s"
        )
        print('   boundaries: '+', '.join(f'{x:.2f}' for x in scene_boundaries))
        return durations,f'global_subtitle_pause:{noise}:{minimum:.2f}',candidates

    @staticmethod
    def _pick_monotonic_boundaries(candidates: list[dict], expected: list[float], total_duration: float) -> list[float]:
        usable=[
            row for row in sorted(candidates,key=lambda x:float(x['center']))
            if float(row['center']) > 0.30 and float(row['center']) < total_duration-0.25
        ]
        needed=len(expected)
        if len(usable) < needed:
            return []

        # Choose the complete ordered subset globally. The old greedy picker could
        # consume a later pause for an early scene and leave no candidate for the
        # final scene even when a valid one-to-one map existed.
        count=len(usable);inf=float('inf')
        costs=[[inf]*(count+1) for _ in range(needed+1)]
        take=[[False]*(count+1) for _ in range(needed+1)]
        for j in range(count+1):
            costs[0][j]=0.0
        for i in range(1,needed+1):
            for j in range(1,count+1):
                skip_cost=costs[i][j-1]
                row=usable[j-1]
                duration_bonus=min(1.0,max(0.0,float(row.get('duration') or 0.0)))*0.05
                match_cost=costs[i-1][j-1]+abs(float(row['center'])-float(expected[i-1]))-duration_bonus
                if match_cost < skip_cost:
                    costs[i][j]=match_cost;take[i][j]=True
                else:
                    costs[i][j]=skip_cost
        if costs[needed][count] == inf:
            return []
        indices=[];i=needed;j=count
        while i>0 and j>0:
            if take[i][j]:
                indices.append(j-1);i-=1;j-=1
            else:
                j-=1
        if i:
            return []
        indices.reverse()
        chosen=[float(usable[idx]['center']) for idx in indices]
        if any(b-a <= 0.30 for a,b in zip(chosen,chosen[1:])):
            return []
        return chosen

    def scene_timing_from_audio(self, plan: dict, lang: str, audio_path: Path, total: float) -> tuple[list[float], str, list[dict]]:
        """Drama V2 timing architecture: derive image scene cuts from REAL narration pauses.

        We first try the same long-pause strategy used by live Drama Motion. For older
        Story Motion WAVs that were created before explicit [short pause] tags existed,
        progressively more permissive silence scans are tried. Text ratio is only a
        last-resort fallback.
        """
        scene_count=len(plan.get('scenes') or [])
        needed=max(0, scene_count-1)
        expected=self._expected_boundaries(plan, lang, total)
        profiles = [(
            str(self.cfg.get('scene_silence_noise', '-38dB')),
            float(self.cfg.get('scene_silence_min_seconds', 1.40)),
        )]
        relaxed_min=float(self.cfg.get('scene_silence_relaxed_min_seconds',1.0))
        if 0.90 <= relaxed_min < profiles[0][1]:
            # Gemini sometimes shortens a requested long delimiter to roughly one
            # second. This stays longer than subtitle pauses, while the ordered
            # global matcher and deviation guard reject unrelated dramatic pauses.
            profiles.append((profiles[0][0],relaxed_min))
        # Compatibility profiles are opt-in only. Fresh production must never use
        # normal speech pauses as scene cuts merely because enough of them exist.
        if bool(self.cfg.get('scene_silence_legacy_fallback_enabled', False)):
            profiles.extend([('-40dB', 0.34),('-42dB', 0.26),('-44dB', 0.18)])
        best_candidates=[]
        for noise, minimum in profiles:
            intervals=self._detect_silences(audio_path, noise=noise, minimum=minimum)
            candidates=[]
            for s,e in intervals:
                dur=e-s; center=(s+e)/2.0
                # Ignore leading/trailing room tone. Only internal long pauses can
                # represent the explicit scene delimiter.
                if s < 0.60 or e > total-0.60:
                    continue
                candidates.append({'start':s,'end':e,'duration':dur,'center':center,'noise':noise,'minimum':minimum})
            if len(candidates) > len(best_candidates):
                best_candidates=candidates
            exact_count=bool(self.cfg.get('scene_boundary_exact_count', True))
            allow_extra=bool(self.cfg.get('scene_boundary_allow_extra_candidates', False))
            if exact_count and len(candidates) != needed and not (allow_extra and len(candidates) > needed):
                print(
                    f"⚠️ {lang.upper()} scene pause count invalid: "
                    f"expected {needed}, detected {len(candidates)} at {noise}/{minimum:.2f}s"
                )
                continue
            chosen=self._pick_monotonic_boundaries(candidates, expected, total)
            if allow_extra and len(candidates) > needed and len(chosen) == needed:
                max_deviation=max(
                    (abs(float(actual)-float(target)) for actual,target in zip(chosen,expected)),
                    default=0.0,
                )
                # Explicit long delimiters may drift several seconds because TTS
                # speech rate is not uniform. Natural-silence fallback is much
                # denser, so require it to sit very close to the text-weighted
                # expectation; this avoids cutting at an unrelated dramatic pause.
                deviation_key=(
                    'scene_natural_boundary_max_deviation_seconds'
                    if minimum < 1.0
                    else 'scene_boundary_max_deviation_seconds'
                )
                deviation_default=1.5 if minimum < 1.0 else 4.5
                allowed_deviation=max(
                    0.5,
                    float(self.cfg.get(deviation_key,deviation_default)),
                )
                if max_deviation > allowed_deviation:
                    print(
                        f"⚠️ {lang.upper()} extra-pause boundary selection rejected: "
                        f"max deviation {max_deviation:.2f}s > {allowed_deviation:.2f}s"
                    )
                    continue
                print(
                    f"🎯 {lang.upper()} extra dramatic pauses filtered: "
                    f"selected {needed}/{len(candidates)} | max deviation={max_deviation:.2f}s"
                )
            if needed == 0 or len(chosen) == needed:
                points=[0.0]+chosen+[float(total)]
                durations=[max(0.05, points[i+1]-points[i]) for i in range(scene_count)]
                print(f"🎯 {lang.upper()} scene sync from REAL narration pauses | profile={noise}/{minimum:.2f}s")
                print('   boundaries: ' + ', '.join(f'{x:.2f}' for x in chosen))
                return durations, f'silence_detect:{noise}:{minimum:.2f}', candidates

        global_pause_map=self._scene_timing_from_global_subtitle_pauses(
            plan,lang,audio_path,total,
        )
        if global_pause_map is not None:
            return global_pause_map

        # Last resort only. This preserves total length but cannot guarantee semantic scene cuts.
        points=[0.0]+expected+[float(total)]
        durations=[max(0.05, points[i+1]-points[i]) for i in range(scene_count)]
        print(f"⚠️ {lang.upper()} narration has insufficient clean scene pauses; using text-ratio fallback.")
        return durations, 'text_ratio_fallback', best_candidates

    def _extract_scene_audio(self, source_audio: Path, output_path: Path, start: float, end: float) -> None:
        """Cut one exact narration scene like live Drama Motion.

        The cut points are silence-boundary centers, so one WAV maps 1:1 to one
        story scene/image/text block. No time-stretching is applied.
        """
        duration = max(0.05, float(end) - float(start))
        output_path.parent.mkdir(parents=True, exist_ok=True)
        ffmpeg_run([
            self.fx.ffmpeg, '-y', '-hide_banner', '-loglevel', 'error',
            '-i', str(source_audio),
            '-af', (
                f"atrim=start={float(start):.6f}:end={float(end):.6f},"
                "asetpts=PTS-STARTPTS,aresample=48000,"
                f"atrim=duration={duration:.6f}"
            ),
            '-ar', '48000', '-ac', '2', '-c:a', 'pcm_s16le',
            str(output_path),
        ])

    def _concat_audio_files(self, paths: list[Path], output: Path, work: Path) -> None:
        manifest = work / f"concat_{output.stem}.txt"
        rows=[]
        for item in paths:
            value=item.resolve().as_posix().replace("'", r"'\''")
            rows.append(f"file '{value}'")
        manifest.write_text("\n".join(rows)+"\n", encoding='utf-8')
        ffmpeg_run([
            self.fx.ffmpeg, '-y', '-hide_banner', '-loglevel', 'error',
            '-f', 'concat', '-safe', '0', '-i', str(manifest),
            '-ar', '48000', '-ac', '2', '-c:a', 'pcm_s16le', str(output),
        ])

    @staticmethod
    def _subtitle_chunks(text: str, lang: str, max_chars: int | None = None) -> list[str]:
        """Split one scene narration into readable local subtitle chunks.

        This is deliberately local/offline.  Story Motion scenes already align one
        narration block to one image; we only split that existing narration into
        1-3 readable overlays and distribute them across that scene duration.
        """
        text = re.sub(r"\s+", " ", str(text or "")).strip()
        if not text:
            return []
        limit = int(max_chars or (34 if lang == "mm" else 42))
        if len(text) <= limit:
            return [text]

        # Prefer natural punctuation, then greedily pack words/phrases.
        parts = [x.strip() for x in re.split(r"(?<=[။!?…])\s*|(?<=[,;:])\s+", text) if x.strip()]
        if len(parts) == 1:
            # Burmese commonly has few spaces; words are still safe break points when present.
            parts = text.split(" ") if " " in text else [text[i:i+limit] for i in range(0, len(text), limit)]

        chunks: list[str] = []
        cur = ""
        for part in parts:
            candidate = part if not cur else f"{cur} {part}".strip()
            if cur and len(candidate) > limit:
                chunks.append(cur.strip())
                cur = part
            else:
                cur = candidate
        if cur.strip():
            chunks.append(cur.strip())

        # Hard-split any unusually long remaining chunk without losing characters.
        fixed: list[str] = []
        for chunk in chunks:
            if len(chunk) <= limit * 1.25:
                fixed.append(chunk)
                continue
            if " " in chunk:
                words = chunk.split()
                row = ""
                for word in words:
                    candidate = word if not row else f"{row} {word}"
                    if row and len(candidate) > limit:
                        fixed.append(row)
                        row = word
                    else:
                        row = candidate
                if row:
                    fixed.append(row)
            else:
                fixed.extend(chunk[i:i+limit] for i in range(0, len(chunk), limit))
        return [x for x in fixed if x.strip()]

    @staticmethod
    def _duration_close(media: Path, fx: StoryMotionLabService, target: float, tol: float = 0.18) -> bool:
        try:
            return media.exists() and media.stat().st_size > 10000 and abs(fx.duration(media) - float(target)) <= tol
        except Exception:
            return False

    @staticmethod
    def _subtitle_weight(text: str, lang: str) -> float:
        cleaned = re.sub(r"\s+", " ", str(text or "")).strip()
        if not cleaned:
            return 1.0
        if lang == "mm":
            punct = len(re.findall(r"[၊။!?…]", cleaned))
            return max(1.0, len(cleaned) * 1.0 + punct * 6.0)
        words = max(1, len(re.findall(r"\S+", cleaned)))
        punct = len(re.findall(r"[,.!?;:]", cleaned))
        return max(1.0, words * 3.0 + len(cleaned) * 0.06 + punct * 1.8)

    def _chunk_time_ranges(self, texts: list[str], lang: str, duration: float) -> list[tuple[float, float]]:
        count = max(1, len(texts))
        if count == 1:
            return [(0.0, max(0.0, float(duration)))]
        min_key = "subtitle_mm_min_chunk_seconds" if lang == "mm" else "subtitle_en_min_chunk_seconds"
        min_chunk = float(self.cfg.get(min_key, 1.18 if lang == "mm" else 1.02))
        min_chunk = max(0.35, min_chunk)
        if min_chunk * count > duration:
            min_chunk = max(0.35, duration / count * 0.82)
        weights = [self._subtitle_weight(t, lang) for t in texts]
        total_weight = sum(weights) or 1.0
        base_total = min_chunk * count
        extra = max(0.0, duration - base_total)
        ranges=[]
        cursor=0.0
        for i,w in enumerate(weights,1):
            seg = min_chunk + (extra * w / total_weight)
            end = duration if i == count else min(duration, cursor + seg)
            ranges.append((cursor, end))
            cursor = end
        if ranges:
            s,_ = ranges[-1]
            ranges[-1] = (s, duration)
        return ranges

    def _chunk_time_ranges_from_audio(
        self,
        *,
        texts: list[str],
        lang: str,
        duration: float,
        audio_path: Path,
    ) -> tuple[list[tuple[float, float]], str, list[dict]]:
        """Place readable subtitle changes on real within-scene narration pauses.

        Text weight supplies only the expected location.  A nearby detected pause is
        the preferred boundary; when Gemini speaks through a phrase without a usable
        pause, the deterministic weighted boundary remains the safe fallback.
        """
        weighted = self._chunk_time_ranges(texts, lang, duration)
        if len(texts) <= 1:
            return weighted, 'single_chunk', []
        expected = [end for _start, end in weighted[:-1]]
        profiles = [
            (
                str(self.cfg.get('subtitle_silence_noise', '-40dB')),
                float(self.cfg.get('subtitle_silence_min_seconds', 0.42)),
            ),
        ]
        # Fresh TTS explicitly creates 0.5s+ subtitle delimiters and keeps normal
        # speech pauses below 0.35s. Never fall back to tiny breath gaps in
        # production, because those make the next subtitle appear mid-sentence.
        if bool(self.cfg.get('subtitle_silence_legacy_fallback_enabled', False)):
            profiles.extend([('-42dB', 0.14), ('-44dB', 0.10)])
        best_candidates: list[dict] = []
        min_gap = max(0.42, min(0.9, duration / max(2.0, len(texts) * 2.2)))
        search_window = max(0.75, min(2.6, duration * 0.22))

        for noise, minimum in profiles:
            candidates=[]
            edge_guard=max(0.28,float(self.cfg.get('subtitle_edge_guard_seconds',0.80)))
            for start, end in self._detect_silences(audio_path, noise=noise, minimum=minimum):
                center=(start+end)/2.0
                # Scene WAVs are cut at the middle of a long delimiter. Ignore the
                # remaining half-delimiter at each edge; it is not a subtitle break.
                if start < edge_guard or end > duration-edge_guard:
                    continue
                candidates.append({
                    'start':start,
                    'end':end,
                    'duration':end-start,
                    'center':center,
                    'noise':noise,
                    'minimum':minimum,
                })
            if len(candidates) > len(best_candidates):
                best_candidates=candidates
            chosen_centers=self._pick_monotonic_boundaries(candidates,expected,duration)
            if len(chosen_centers) != len(expected):
                continue
            max_deviation=max(
                (abs(float(actual)-float(target)) for actual,target in zip(chosen_centers,expected)),
                default=0.0,
            )
            if max_deviation > search_window:
                continue
            selected=[];search_from=0
            for center in chosen_centers:
                match=None
                for idx in range(search_from,len(candidates)):
                    if abs(float(candidates[idx]['center'])-float(center)) < 0.0001:
                        match=candidates[idx];search_from=idx+1;break
                if match is None:
                    selected=[];break
                selected.append(match)
            if len(selected) != len(expected):
                continue
            # Keep the current subtitle visible through the whole silence and
            # switch only when the next spoken phrase is about to begin.
            chosen=[float(row['end']) for row in selected]
            points=[0.0]+chosen+[float(duration)]
            ranges=[(points[i],points[i+1]) for i in range(len(texts))]
            if all((end-start) >= min_gap for start,end in ranges):
                return ranges, f'audio_pause:{noise}:{minimum:.2f}', candidates
        return weighted, 'weighted_text_fallback', best_candidates

    def _validate_subtitle_pause_map(
        self,
        *,
        plan: dict,
        lang: str,
        source_audio: Path,
        durations: list[float],
        root: Path,
    ) -> tuple[bool, list[dict]]:
        """Preflight every subtitle boundary before expensive video rendering.

        A weighted fallback looks plausible in JSON but can visibly lead/lag speech.
        Fresh production therefore regenerates the one continuous TTS track unless
        every multi-chunk scene has real pause-backed subtitle boundaries.
        """
        if not bool(self.cfg.get('subtitle_chunk_sync_enabled',False)):
            return True, []
        key='narration_mm' if lang=='mm' else 'narration_en'
        capkey='caption_mm' if lang=='mm' else 'caption_en'
        preflight=root/'audio'/f'_sync_preflight_{lang}'
        preflight.mkdir(parents=True,exist_ok=True)
        cursor=0.0;rows=[];valid=True
        for i,(scene,dur) in enumerate(zip(plan.get('scenes') or [],durations),1):
            wav=preflight/f'scene_{i:02d}.wav'
            self._extract_scene_audio(source_audio,wav,cursor,cursor+float(dur))
            cursor+=float(dur)
            full_text=re.sub(r"\s+"," ",str(scene.get(key) or scene.get(capkey) or "")).strip()
            texts=self._subtitle_chunks(
                full_text,lang,
                int(self.cfg.get('subtitle_mm_max_chars',44) if lang=='mm' else self.cfg.get('subtitle_en_max_chars',42)),
            )
            _ranges,mode,candidates=self._chunk_time_ranges_from_audio(
                texts=texts,lang=lang,duration=self._dur(wav),audio_path=wav,
            )
            row={'scene_no':i,'chunks':len(texts),'mode':mode,'candidates':len(candidates)}
            rows.append(row)
            if len(texts)>1 and mode=='weighted_text_fallback':
                valid=False
        return valid,rows

    def _pad_video_to_duration(self, video: Path, target: float) -> Path:
        actual = self._dur(video)
        if actual >= target - 0.02:
            return video
        extra = max(0.0, float(target) - actual)
        out = video.with_name(video.stem + '_padded' + video.suffix)
        ffmpeg_run([
            self.fx.ffmpeg, '-y', '-hide_banner', '-loglevel', 'error',
            '-i', str(video),
            '-vf', f"tpad=stop_mode=clone:stop_duration={extra:.3f}",
            '-an',
            *self.fx.encoder,
            '-pix_fmt', 'yuv420p',
            str(out),
        ])
        return out

    async def render_language(self, plan: dict, images: list[Path], genre: str, lang: str, root: Path, *, safe_local_only: bool = False, force_tts_only: bool = False, strict_scene_boundaries: bool = True) -> dict:
        """Production renderer: ONE Gemini narrator call, then exact scene triple-lock.

        Scene N is always: image N + extracted scene_N.wav + ONE scene-N subtitle PNG.
        We never estimate subtitle timing inside a scene.  For fresh production, clean
        silence boundaries are mandatory; if Gemini misses them we retry the audio
        call instead of silently falling back to text-ratio timing.
        """
        key="narration_mm" if lang=="mm" else "narration_en"
        capkey="caption_mm" if lang=="mm" else "caption_en"
        audio=root/"audio"/f"narration_{lang}.wav"
        tts_attempts=max(1,int(self.cfg.get("tts_retries",3) or 3))
        boundary_mode=""; silence_candidates=[]; durations=[]; total=0.0

        if safe_local_only:
            if not audio.exists() or audio.stat().st_size<5000:
                raise RuntimeError(f"SAFE RERENDER requires existing narration WAV: {audio}")
            print(f"🔒 SAFE TTS reuse only → {audio}")
            total=self._dur(audio)
            durations,boundary_mode,silence_candidates=self.scene_timing_from_audio(plan,lang,audio,total)
            if strict_scene_boundaries and boundary_mode=="text_ratio_fallback":
                raise RuntimeError(
                    f"{lang.upper()} existing narration has no reliable {len(plan.get('scenes') or [])}-scene pause map. "
                    "SAFE mode stopped instead of guessing scene cuts. Regenerate TTS only."
                )
            subtitle_ok,subtitle_preflight=self._validate_subtitle_pause_map(
                plan=plan,lang=lang,source_audio=audio,durations=durations,root=root,
            )
            if bool(self.cfg.get('strict_subtitle_boundaries',True)) and not subtitle_ok:
                failed=[str(x['scene_no']) for x in subtitle_preflight if x['mode']=='weighted_text_fallback']
                raise RuntimeError(
                    f"{lang.upper()} existing narration has unverified subtitle timing in scene(s) {', '.join(failed)}. "
                    "SAFE mode stopped instead of displaying guessed subtitle timing."
                )
        else:
            last_mode=""
            subtitle_ok=True;subtitle_preflight=[]
            for attempt in range(1,tts_attempts+1):
                self.tts_story(plan.get("scenes") or [],lang,audio,force=bool(force_tts_only or attempt>1))
                total=self._dur(audio)
                durations,boundary_mode,silence_candidates=self.scene_timing_from_audio(plan,lang,audio,total)
                last_mode=boundary_mode
                scene_ok=(not strict_scene_boundaries or boundary_mode!="text_ratio_fallback")
                subtitle_ok=False
                if scene_ok:
                    subtitle_ok,subtitle_preflight=self._validate_subtitle_pause_map(
                        plan=plan,lang=lang,source_audio=audio,durations=durations,root=root,
                    )
                subtitle_required=bool(self.cfg.get('strict_subtitle_boundaries',True))
                if scene_ok and (subtitle_ok or not subtitle_required):
                    break
                failed=[str(x['scene_no']) for x in subtitle_preflight if x.get('mode')=='weighted_text_fallback']
                detail=(f"subtitle scene(s) {', '.join(failed)}" if scene_ok else "scene pause map")
                print(f"⚠️ {lang.upper()} TTS {detail} validation failed {attempt}/{tts_attempts}; regenerating ONE continuous narrator track...")
            if (strict_scene_boundaries and last_mode=="text_ratio_fallback") or (
                bool(self.cfg.get('strict_subtitle_boundaries',True)) and not subtitle_ok
            ):
                raise RuntimeError(
                    f"{lang.upper()} continuous Gemini TTS failed strict scene/subtitle boundary validation after {tts_attempts} attempts. "
                    "Video was NOT rendered with guessed timings."
                )

        if abs(sum(durations)-total)>0.08 and durations:
            durations[-1]+=total-sum(durations)
        print(f"🎯 EXACT SCENE BOUNDARY LOCK | {lang.upper()} | {boundary_mode} | audio={total:.2f}s")

        # Split the ONE narrator recording into exact scene WAVs.
        scene_audio_dir=root/'audio'/f'scene_audio_{lang}';scene_audio_dir.mkdir(parents=True,exist_ok=True)
        points=[0.0];cursor=0.0
        for d in durations[:-1]:
            cursor+=float(d);points.append(cursor)
        points.append(float(total))
        scene_audio_files=[];actual_durations=[]
        for i in range(len(durations)):
            scene_wav=scene_audio_dir/f'scene_{i+1:02d}.wav'
            self._extract_scene_audio(audio,scene_wav,points[i],points[i+1])
            d=self._dur(scene_wav);scene_audio_files.append(scene_wav);actual_durations.append(d)
            print(f"🔒 Scene {i+1:02d}: image + WAV + subtitle = {d:.2f}s")
        durations=actual_durations;total=sum(durations)

        chunk_sync_enabled=bool(self.cfg.get('subtitle_chunk_sync_enabled',False))
        cache_tag=str(self.cfg.get("render_cache_tag","v2_route_exact_scene")).strip() or "v2_route_exact_scene"
        if chunk_sync_enabled:
            cache_tag += '_chunk_sync_v1'
        work=root/f"work_{lang}_{cache_tag}";scene_dir=work/'scenes';caption_dir=work/'caption_png';shared_visual_dir=root/f"work_visual_{cache_tag}"/'scenes_raw'
        scene_dir.mkdir(parents=True,exist_ok=True);caption_dir.mkdir(parents=True,exist_ok=True);shared_visual_dir.mkdir(parents=True,exist_ok=True)

        # Scene/image/audio remain exactly locked.  Optional subtitle chunks change
        # only at real within-scene narration pauses, avoiding a full future paragraph
        # being visible from the first word of the scene.
        scene_caption_sets=[]
        async with CaptionPNG(self.story,self.cfg.get("caption_style",{})) as renderer:
            for i,(scene,wav,dur) in enumerate(zip(plan.get("scenes") or [],scene_audio_files,durations),1):
                full_text=re.sub(r"\s+"," ",str(scene.get(key) or scene.get(capkey) or "")).strip()
                if not full_text: raise RuntimeError(f"Scene {i} {lang.upper()} subtitle text empty")
                texts=self._subtitle_chunks(
                    full_text,
                    lang,
                    int(self.cfg.get('subtitle_mm_max_chars',34) if lang=='mm' else self.cfg.get('subtitle_en_max_chars',42)),
                ) if chunk_sync_enabled else [full_text]
                ranges,sync_mode,pause_candidates=self._chunk_time_ranges_from_audio(
                    texts=texts,
                    lang=lang,
                    duration=dur,
                    audio_path=wav,
                ) if chunk_sync_enabled else ([(0.0,dur)],'one_scene_one_text',[])
                pngs=[]
                for chunk_no,text_value in enumerate(texts,1):
                    cp=caption_dir/f"scene_{i:02d}_chunk_{chunk_no:02d}.png"
                    if cp.exists() and cp.stat().st_size>=1000:
                        print(f"♻️ Scene subtitle {i:02d}.{chunk_no:02d} reuse")
                    else:
                        await renderer.render(text_value,cp,lang)
                    pngs.append(cp)
                scene_caption_sets.append({
                    'texts':texts,
                    'ranges':ranges,
                    'pngs':pngs,
                    'sync_mode':sync_mode,
                    'pause_candidates':pause_candidates,
                })
                if chunk_sync_enabled:
                    print(
                        f"📝 Scene {i:02d} subtitle sync: {len(texts)} chunk(s) | "
                        f"{sync_mode}"
                    )

        rendered=[];timeline=[];acc=0.0;y_fraction=float(self.cfg.get("subtitle_y_fraction",0.75))
        for i,(img,wav,caption_set,dur) in enumerate(zip(images,scene_audio_files,scene_caption_sets,durations),1):
            dur_ms=int(round(float(dur)*1000))
            # Include language in final cache; MM/EN durations/text can differ while raw
            # visual may still be reused only when exact duration matches.
            raw_scene=shared_visual_dir/f"scene_{i:02d}_{dur_ms:06d}ms_raw.mp4"
            final_scene=scene_dir/f"scene_{i:02d}_{dur_ms:06d}ms.mp4"
            if not self._duration_close(raw_scene,self.fx,dur,tol=0.16):
                self.fx._render_scene(img,raw_scene,duration=dur,index=i,preset=genre)
            else:
                print(f"♻️ Motion scene {i:02d} raw reuse")
            if not self._duration_close(final_scene,self.fx,dur,tol=0.16):
                cmd=[self.fx.ffmpeg,'-y','-hide_banner','-loglevel','error','-i',str(raw_scene)]
                for cap in caption_set['pngs']:
                    cmd.extend(['-loop','1','-framerate',str(self.fx.fps),'-i',str(cap)])
                chains=[]
                previous='0:v'
                for chunk_no,(_cap,(start,end)) in enumerate(
                    zip(caption_set['pngs'],caption_set['ranges']),
                    1,
                ):
                    output_label='v' if chunk_no==len(caption_set['pngs']) else f'v{chunk_no}'
                    chains.append(
                        f"[{previous}][{chunk_no}:v]overlay=x=(W-w)/2:"
                        f"y=H*{y_fraction:.4f}-h/2:eof_action=pass:repeatlast=1:"
                        f"enable='between(t\\,{start:.4f}\\,{end:.4f})'[{output_label}]"
                    )
                    previous=output_label
                cmd.extend([
                    '-filter_complex',';'.join(chains),'-map','[v]','-an',
                    *self.fx.encoder,'-pix_fmt','yuv420p','-t',f'{dur:.3f}',str(final_scene),
                ])
                ffmpeg_run(cmd)
            else:
                print(f"♻️ Scene {i:02d} exact subtitle render reuse")
            rendered.append(final_scene)
            timeline.append({
                'scene_no':i,'start':acc,'end':acc+dur,'duration':dur,
                'image':str(img),'scene_audio':str(wav),
                'subtitle_mode':'audio_pause_chunks' if chunk_sync_enabled else 'one_scene_one_text',
                'subtitle_sync_mode':caption_set['sync_mode'],
                'subtitle_chunks':[
                    {'text':text_value,'start':start,'end':end,'png':str(png)}
                    for text_value,(start,end),png in zip(
                        caption_set['texts'],caption_set['ranges'],caption_set['pngs']
                    )
                ],
            })
            acc+=dur

        silent=work/f"story_motion_{genre}_{lang}_silent.mp4";self.fx._concat(rendered,silent);silent_mix_source=self._pad_video_to_duration(silent,total)
        bed=work/f"story_motion_{genre}_{lang}_bed.mp4";self.fx._mix_audio(silent_mix_source,bed,preset=genre,scene_durations=durations);bed_mix_source=self._pad_video_to_duration(bed,total)
        narration_scene_synced=root/'audio'/f'narration_{lang}_scene_synced.wav';self._concat_audio_files(scene_audio_files,narration_scene_synced,work)
        synced_total=self._dur(narration_scene_synced);total=min(total,synced_total) if abs(total-synced_total)>0.25 else synced_total

        final=root/'video'/f'story_motion_{genre}_{lang}.mp4';final.parent.mkdir(parents=True,exist_ok=True)
        ffmpeg_run([
            self.fx.ffmpeg,'-y','-hide_banner','-loglevel','error','-i',str(bed_mix_source),'-i',str(narration_scene_synced),
            '-filter_complex',
            f"[0:a]loudnorm=I={float(self.cfg.get('background_lufs',-15.0)):.1f}:TP=-1.2:LRA=11,volume={float(self.cfg.get('final_bed_volume',0.5)):.3f}[bed];"
            f"[1:a]aresample=48000,loudnorm=I={float(self.cfg.get('narration_lufs',-10.5)):.1f}:TP=-1.0:LRA=7,volume={float(self.cfg.get('narration_gain',1.06)):.3f}[nar];"
            "[bed][nar]amix=inputs=2:duration=longest:dropout_transition=2:normalize=0,alimiter=limit=0.94[a]",
            '-map','0:v:0','-map','[a]','-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-t',f'{total:.3f}','-movflags','+faststart',str(final)
        ])

        parts=[str(final)];threshold=float(self.cfg.get('split_threshold_seconds',105));min_part=float(self.cfg.get('minimum_part_seconds',60));cut_scene=int(plan.get('part_break_after_scene') or 7)
        if total>threshold and 2<=cut_scene<len(timeline):
            cut=timeline[cut_scene-1]['end']
            if cut>=min_part and total-cut>=min_part:
                p1=root/'video'/f'story_motion_{genre}_{lang}_part1.mp4';p2=root/'video'/f'story_motion_{genre}_{lang}_part2.mp4'
                ffmpeg_run([self.fx.ffmpeg,'-y','-i',str(final),'-t',f'{cut:.3f}','-c:v','libx264','-preset','veryfast','-crf','21','-c:a','aac','-b:a','192k',str(p1)])
                ffmpeg_run([self.fx.ffmpeg,'-y','-ss',f'{cut:.3f}','-i',str(final),'-c:v','libx264','-preset','veryfast','-crf','21','-c:a','aac','-b:a','192k',str(p2)])
                parts=[str(p1),str(p2)]

        write_json(root/f'timeline_{lang}.json',{'language':lang,'audio_duration':round(total,3),'boundary_mode':boundary_mode,'detected_silence_candidates':silence_candidates,'scenes':timeline})
        return {'language':lang,'duration_seconds':round(total,2),'boundary_mode':boundary_mode,'full_video':str(final),'outputs':parts}

    def _cleanup_success_work(self, root: Path) -> None:
        """Remove only disposable render intermediates after a successful test.

        Raw generated story images, narration WAV, plan/registry JSON and final videos
        are kept.  This targets the large duplicate scene/silent/bed files that made
        repeated Story Motion tests balloon the project folder.
        """
        if not bool(self.cfg.get("cleanup_work_after_success", True)):
            return
        freed = 0
        removed = []
        for child in root.iterdir() if root.exists() else []:
            if not child.is_dir() or not child.name.startswith("work_"):
                continue
            try:
                for f in child.rglob("*"):
                    if f.is_file():
                        try:
                            freed += f.stat().st_size
                        except OSError:
                            pass
                shutil.rmtree(child, ignore_errors=False)
                removed.append(child.name)
            except Exception as exc:
                print(f"⚠️ Work cleanup skipped {child.name}: {exc}")
        if removed:
            mb = freed / (1024 * 1024)
            print(f"🧹 Story Motion work cleanup: {len(removed)} folder(s), freed ~{mb:.1f} MB")

    def latest_reusable_story_root(self, mode: str = "dual") -> Path | None:
        """Find the newest Story Motion job that can be rerendered with ZERO paid API calls.

        Completed jobs are intentionally allowed.  A job is reusable only when it has:
          * story_plan.json
          * the complete raw scene JPG set
          * already-generated narration WAV for every requested language

        This method never generates story text, images, or TTS.
        """
        if not self.output_root.exists():
            return None
        langs = ["mm", "en"] if mode == "dual" else [mode]
        candidates: list[Path] = []
        for p in self.output_root.iterdir():
            if not p.is_dir():
                continue
            plan_path = p / "story_plan.json"
            raw = p / "raw"
            if not plan_path.exists() or not raw.exists():
                continue
            plan = read_json(plan_path, {})
            scenes = plan.get("scenes") or []
            if not scenes:
                continue
            images = [raw / f"scene_{i:02d}.jpg" for i in range(1, len(scenes) + 1)]
            if any((not img.exists()) or img.stat().st_size < 5000 for img in images):
                continue

            # SAFE means SAFE: require existing TTS so rerender cannot accidentally
            # call Gemini TTS and incur cost.
            audio_ok = True
            for lang in langs:
                wav = p / "audio" / f"narration_{lang}.wav"
                try:
                    if not wav.exists() or wav.stat().st_size < 5000 or self.fx.duration(wav) <= 3.0:
                        audio_ok = False
                        break
                except Exception:
                    audio_ok = False
                    break
            if not audio_ok:
                continue
            candidates.append(p)
        if not candidates:
            return None
        return max(candidates, key=lambda x: x.stat().st_mtime)


    def _scene_tts_payload(self, text: str, lang: str) -> tuple[list[str], str]:
        """Build one voice-locked Gemini request for one scene and its captions."""
        limit = int(
            self.cfg.get('subtitle_mm_max_chars', 44)
            if lang == 'mm' else self.cfg.get('subtitle_en_max_chars', 42)
        )
        chunks = self._subtitle_chunks(text, lang, limit)
        if not chunks:
            raise RuntimeError(f'Empty {lang.upper()} scene narration')
        pause_min = max(0.42, float(self.cfg.get('subtitle_pause_min_seconds', 0.52)))
        pause_max = max(pause_min, float(self.cfg.get('subtitle_pause_max_seconds', 0.72)))
        voice_lock = (
            'VOICE LOCK FOR EVERY SCENE: keep exactly the same narrator identity, vocal age, pitch range, '
            'timbre, accent, speaking pace, emotional intensity, microphone distance and recording character. '
            'Do not create a new character voice for this scene. Do not speed up or slow down near the end. '
        )
        language_rule = (
            'Speak natural Burmese with clear articulation. '
            if lang == 'mm' else
            'Speak natural international English with clear articulation. '
        )
        boundary_rule = (
            f'This scene contains exactly {len(chunks)} subtitle phrases. Read only the transcript. '
            f'At every [brief subtitle pause] tag, make a clean silent gap of {pause_min:.2f} to {pause_max:.2f} seconds. '
            'Finish the current phrase completely, keep its silence, then begin the next phrase. '
            'Keep ordinary pauses inside a phrase below 0.30 seconds. '
            'Never speak the tag, instructions, labels, or phrase numbers. '
        )
        transcript = ' [brief subtitle pause] '.join(chunks)
        return chunks, f'{voice_lock}{language_rule}{boundary_rule}\n\nTRANSCRIPT:\n{transcript}'

    async def _generate_scene_audio_gemini(self, text: str, lang: str, output_wav: Path) -> tuple[list[str], list[tuple[float, float]], str]:
        """Generate and verify one Gemini WAV for exactly one story scene."""
        output_wav.parent.mkdir(parents=True, exist_ok=True)
        chunks, payload = self._scene_tts_payload(text, lang)
        signature = hashlib.sha256(json.dumps({
            'version': 'per_scene_subtitle_pause_v1',
            'lang': lang,
            'voice': self.cfg.get('myanmar_voice' if lang == 'mm' else 'english_voice'),
            'model': self.cfg.get('tts_model'),
            'chunks': chunks,
        }, ensure_ascii=False, sort_keys=True).encode('utf-8')).hexdigest()
        meta_path = output_wav.with_suffix(output_wav.suffix + '.sync.json')
        try:
            meta = read_json(meta_path, {})
            if (
                output_wav.exists() and output_wav.stat().st_size >= 5000
                and self._dur(output_wav) > 0.25 and meta.get('signature') == signature
            ):
                duration = self._dur(output_wav)
                ranges, mode, _ = self._chunk_time_ranges_from_audio(
                    texts=chunks, lang=lang, duration=duration, audio_path=output_wav,
                )
                if len(chunks) == 1 or mode != 'weighted_text_fallback':
                    print(f"♻️ Verified per-scene TTS reuse → {output_wav.name} | {mode}")
                    return chunks, ranges, mode
        except Exception:
            pass
        attempts = max(1, int(self.cfg.get('tts_retries', 3) or 3))
        last_mode = 'not_generated'
        for attempt in range(1, attempts + 1):
            tmp = output_wav.with_name(output_wav.stem + '_new.wav')
            try:
                if tmp.exists():
                    tmp.unlink()
            except OSError:
                pass
            self.tts(payload, lang, tmp)
            duration = self._dur(tmp)
            ranges, mode, candidates = self._chunk_time_ranges_from_audio(
                texts=chunks, lang=lang, duration=duration, audio_path=tmp,
            )
            last_mode = mode
            if len(chunks) > 1 and mode == 'weighted_text_fallback':
                print(
                    f'⚠️ Scene subtitle pauses unverified {attempt}/{attempts} '
                    f'({len(candidates)} pause candidate(s)); regenerating this scene only...'
                )
                try:
                    tmp.unlink()
                except OSError:
                    pass
                continue
            os.replace(tmp, output_wav)
            write_json(meta_path, {
                'signature': signature,
                'chunks': chunks,
                'duration_seconds': duration,
                'subtitle_ranges': [{'start': s, 'end': e} for s, e in ranges],
                'subtitle_sync_mode': mode,
            })
            return chunks, ranges, mode
        raise RuntimeError(
            f'{lang.upper()} scene TTS did not produce {max(0, len(chunks)-1)} verified subtitle pause(s) '
            f'after {attempts} attempts (last mode: {last_mode}).'
        )

    def _scene_audio_complete(self, root: Path, lang: str, scene_count: int) -> list[Path]:
        scene_dir = root / 'audio' / f'scene_audio_{lang}'
        paths = [scene_dir / f'scene_{i:02d}.wav' for i in range(1, scene_count + 1)]
        for item in paths:
            try:
                if not item.exists() or item.stat().st_size < 3000 or self._dur(item) <= 0.25:
                    return []
            except Exception:
                return []
        return paths

    async def render_language_scene_lock(
        self,
        plan: dict,
        images: list[Path],
        genre: str,
        lang: str,
        root: Path,
        *,
        provider: str = 'existing',
    ) -> dict:
        """Exact lock: one image, one independently generated WAV, timed captions."""
        key = 'narration_mm' if lang == 'mm' else 'narration_en'
        scenes = plan.get('scenes') or []
        if not scenes or len(images) != len(scenes):
            raise RuntimeError('Scene-lock requires 1:1 story scenes and raw images.')

        scene_audio_dir = root / 'audio' / f'scene_audio_{lang}'
        scene_audio_dir.mkdir(parents=True, exist_ok=True)
        scene_audio_files = [scene_audio_dir / f'scene_{i:02d}.wav' for i in range(1, len(scenes)+1)]

        provider = str(provider or 'existing').lower().strip()
        generated_caption_sets: list[dict] = []
        if provider == 'gemini':
            print(f'🎙️ {provider.upper()} PER-SCENE TTS: {len(scenes)} scene(s) | NO image/story generation')
            for i, (scene, out_wav) in enumerate(zip(scenes, scene_audio_files), 1):
                narration = re.sub(r'\s+', ' ', str(scene.get(key) or '')).strip()
                if not narration:
                    raise RuntimeError(f'Scene {i:02d} has empty {key}')
                print(f'   🎙️ Scene {i:02d}/{len(scenes)}')
                chunks, ranges, sync_mode = await self._generate_scene_audio_gemini(narration, lang, out_wav)
                generated_caption_sets.append({
                    'texts': chunks, 'ranges': ranges, 'sync_mode': sync_mode,
                })
        else:
            existing = self._scene_audio_complete(root, lang, len(scenes))
            if not existing:
                raise RuntimeError(
                    f'Existing scene audio is incomplete: {scene_audio_dir}. '
                    'Choose Gemini per-scene TTS first.'
                )
            scene_audio_files = existing
            print(f'🔒 Reusing {len(scene_audio_files)} existing scene WAVs — NO TTS API')

        # Actual scene WAV length is the ONLY timing source.
        durations = [self._dur(p) for p in scene_audio_files]
        total = sum(durations)
        print(f'🎯 EXACT SCENE LOCK | {lang.upper()} | total={total:.2f}s')
        for i, d in enumerate(durations, 1):
            print(f'   Scene {i:02d}: image {i:02d} + audio {i:02d} + text {i:02d} = {d:.2f}s')

        cache_tag = str(self.cfg.get('render_cache_tag', 'v041_gemini_audio_fluid_boost')).strip() or 'v041_gemini_audio_fluid_boost'
        work = root / f'work_{lang}_{cache_tag}'
        scene_dir = work / 'scenes'
        caption_dir = work / 'scene_caption_png'
        visual_dir = root / f'work_visual_{cache_tag}' / f'{lang}_scenes_raw'
        for d in (scene_dir, caption_dir, visual_dir):
            d.mkdir(parents=True, exist_ok=True)

        # Split only the text that belongs to this scene. Each change is locked to
        # a real pause inside that scene's own WAV.
        caption_sets: list[dict] = []
        async with CaptionPNG(self.story, self.cfg.get('caption_style', {})) as renderer:
            for i, (scene, wav, dur) in enumerate(zip(scenes, scene_audio_files, durations), 1):
                narration = re.sub(r'\s+', ' ', str(scene.get(key) or '')).strip()
                if provider == 'gemini':
                    caption_set = dict(generated_caption_sets[i-1])
                else:
                    chunks, _payload = self._scene_tts_payload(narration, lang)
                    ranges, sync_mode, _ = self._chunk_time_ranges_from_audio(
                        texts=chunks, lang=lang, duration=dur, audio_path=wav,
                    )
                    if len(chunks) > 1 and sync_mode == 'weighted_text_fallback':
                        raise RuntimeError(
                            f'Existing scene {i:02d} WAV has no verified subtitle pause map.'
                        )
                    caption_set = {'texts': chunks, 'ranges': ranges, 'sync_mode': sync_mode}
                pngs = []
                for chunk_no, chunk in enumerate(caption_set['texts'], 1):
                    cap = caption_dir / f'scene_{i:02d}_chunk_{chunk_no:02d}.png'
                    if not cap.exists() or cap.stat().st_size < 1000:
                        await renderer.render(chunk, cap, lang)
                    pngs.append(cap)
                caption_set['pngs'] = pngs
                caption_sets.append(caption_set)
                print(
                    f"📝 Scene {i:02d}: {len(caption_set['texts'])} subtitle chunk(s) | "
                    f"{caption_set['sync_mode']}"
                )

        rendered=[]
        timeline=[]
        acc=0.0
        y_fraction=float(self.cfg.get('subtitle_y_fraction', 0.75))
        for i, (img, wav, caption_set, dur) in enumerate(zip(images, scene_audio_files, caption_sets, durations), 1):
            dur_ms=int(round(dur*1000))
            raw_scene=visual_dir / f'scene_{i:02d}_{dur_ms:06d}ms_raw.mp4'
            final_scene=scene_dir / f'scene_{i:02d}_{dur_ms:06d}ms.mp4'
            if not self._duration_close(raw_scene, self.fx, dur, tol=0.15):
                self.fx._render_scene(img, raw_scene, duration=dur, index=i, preset=genre)
            if not self._duration_close(final_scene, self.fx, dur, tol=0.15):
                cmd = [self.fx.ffmpeg, '-y', '-hide_banner', '-loglevel', 'error', '-i', str(raw_scene)]
                for cap in caption_set['pngs']:
                    cmd.extend(['-loop', '1', '-framerate', str(self.fx.fps), '-i', str(cap)])
                chains = []
                previous = '0:v'
                for chunk_no, (_cap, (start, end)) in enumerate(
                    zip(caption_set['pngs'], caption_set['ranges']), 1,
                ):
                    output_label = 'vout' if chunk_no == len(caption_set['pngs']) else f'v{chunk_no}'
                    chains.append(
                        f"[{previous}][{chunk_no}:v]overlay=x=(W-w)/2:"
                        f"y=H*{y_fraction:.4f}-h/2:eof_action=pass:repeatlast=1:"
                        f"enable='between(t\\,{start:.4f}\\,{end:.4f})'[{output_label}]"
                    )
                    previous = output_label
                cmd.extend([
                    '-filter_complex', ';'.join(chains), '-map', '[vout]', '-an',
                    *self.fx.encoder, '-pix_fmt', 'yuv420p', '-t', f'{dur:.3f}', str(final_scene),
                ])
                ffmpeg_run(cmd)
            rendered.append(final_scene)
            timeline.append({
                'scene_no': i, 'start': acc, 'end': acc+dur, 'duration': dur,
                'image': str(img), 'scene_audio': str(wav),
                'subtitle_mode': 'per_scene_audio_pause_chunks',
                'subtitle_sync_mode': caption_set['sync_mode'],
                'subtitle_chunks': [
                    {'text': text_value, 'start': start, 'end': end, 'png': str(png)}
                    for text_value, (start, end), png in zip(
                        caption_set['texts'], caption_set['ranges'], caption_set['pngs']
                    )
                ],
            })
            acc += dur

        silent=work / f'story_motion_{genre}_{lang}_silent.mp4'
        self.fx._concat(rendered, silent)
        silent_mix_source=self._pad_video_to_duration(silent, total)

        narration_scene_synced=root / 'audio' / f'narration_{lang}_scene_synced.wav'
        self._concat_audio_files(scene_audio_files, narration_scene_synced, work)

        bed=work / f'story_motion_{genre}_{lang}_bed.mp4'
        self.fx._mix_audio(silent_mix_source, bed, preset=genre, scene_durations=durations)
        bed_mix_source=self._pad_video_to_duration(bed, total)

        final=root / 'video' / f'story_motion_{genre}_{lang}.mp4'
        final.parent.mkdir(parents=True, exist_ok=True)
        ffmpeg_run([
            self.fx.ffmpeg, '-y', '-hide_banner', '-loglevel', 'error',
            '-i', str(bed_mix_source), '-i', str(narration_scene_synced),
            '-filter_complex',
            f"[0:a]loudnorm=I={float(self.cfg.get('background_lufs', -15.0)):.1f}:TP=-1.2:LRA=11,volume={float(self.cfg.get('final_bed_volume', 1.0)):.3f}[bed];"
            f"[1:a]aresample=48000,loudnorm=I={float(self.cfg.get('narration_lufs', -10.5)):.1f}:TP=-1.0:LRA=7,volume={float(self.cfg.get('narration_gain', 1.06)):.3f}[nar];"
            "[bed][nar]amix=inputs=2:duration=first:dropout_transition=1:normalize=0,alimiter=limit=0.94[a]",
            '-map', '0:v:0', '-map', '[a]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000',
            '-t', f'{total:.3f}', '-movflags', '+faststart', str(final),
        ])
        write_json(root / f'timeline_{lang}.json', timeline)
        return {
            'language':lang, 'duration_seconds':round(total,2), 'full_video':str(final),
            'outputs':[str(final)], 'scene_lock':True, 'tts_provider':provider,
            'boundary_mode':'per_scene_exact', 'subtitle_sync_mode':'per_scene_audio_pause_exact',
        }

    async def scene_lock_existing_story(self, provider: str = 'existing', lang: str = 'mm') -> None:
        root=self.latest_story_with_images()
        if root is None:
            raise RuntimeError('No existing Story Motion story with complete raw images was found.')
        plan=read_json(root/'story_plan.json',{})
        scenes=plan.get('scenes') or []
        genre=str(plan.get('genre') or root.name.split('_')[-1] or 'horror').lower()
        raw=root/'raw'
        images=[raw/f'scene_{i:02d}.jpg' for i in range(1,len(scenes)+1)]
        print('\n' + '='*74)
        print('STORY MOTION V0.4.3 — GEMINI MM/EN LOUD AUDIO MIX')
        print(f'📁 {root}')
        print(f'🖼️ EXISTING images only: {len(images)} — NO IMAGE API')
        print('📝 EXISTING story_plan.json only — NO STORY GENERATION')
        if provider == 'gemini':
            print('🎙️ GEMINI per-scene TTS only (paid TTS calls)')
        else:
            print('🔒 EXISTING scene WAVs only — NO TTS API')
        print('🎯 Rule: Scene N image + Scene N audio + Scene N full subtitle share ONE duration')
        print('='*74)
        render=await self.render_language_scene_lock(plan, images, genre, lang, root, provider=provider)
        write_json(root/'result.json',{
            'success':True,'story_id':str(plan.get('story_id') or root.name),'title':plan.get('title',''),
            'genre':genre,'mode':lang,'renders':[render],'root':str(root),'scene_triple_lock':True,
            'tts_provider':provider,'images_reused':True,'story_reused':True,
        })
        print('\n✅ EXACT SCENE TRIPLE LOCK COMPLETE')
        print(f"🎥 {render['full_video']}")

    async def scene_lock_existing_story_dual(self, provider: str = 'existing') -> None:
        root=self.latest_story_with_images()
        if root is None:
            raise RuntimeError('No existing Story Motion story with complete raw images was found.')
        plan=read_json(root/'story_plan.json',{})
        scenes=plan.get('scenes') or []
        genre=str(plan.get('genre') or root.name.split('_')[-1] or 'horror').lower()
        raw=root/'raw'
        images=[raw/f'scene_{i:02d}.jpg' for i in range(1,len(scenes)+1)]
        print('\n' + '='*74)
        print('STORY MOTION V0.4.2 — DUAL MM+EN EXACT SCENE LOCK')
        print(f'📁 {root}')
        print(f'🖼️ EXISTING images only: {len(images)} — NO IMAGE API')
        print('📝 EXISTING story_plan.json only — NO STORY GENERATION')
        if provider == 'gemini':
            print('🎙️ GEMINI per-scene TTS for MM + EN (paid TTS only)')
        else:
            print('🔒 EXISTING MM + EN scene WAVs only — NO TTS API')
        print('🎯 Each language uses its OWN scene WAV durations; no cross-language cache timing.')
        print('='*74)
        renders=[]
        for lang in ('mm','en'):
            renders.append(await self.render_language_scene_lock(plan, images, genre, lang, root, provider=provider))
        write_json(root/'result.json',{
            'success':True,'story_id':str(plan.get('story_id') or root.name),'title':plan.get('title',''),
            'genre':genre,'mode':'dual','renders':renders,'root':str(root),'scene_triple_lock':True,
            'tts_provider':provider,'images_reused':True,'story_reused':True,
        })
        print('\n✅ DUAL EXACT SCENE LOCK COMPLETE')
        for row in renders:
            print(f"🎥 {row['language'].upper()} → {row['full_video']}")

    def latest_story_with_images(self) -> Path | None:
        """Newest existing Story Motion story with plan + complete raw images.

        Existing narration is NOT required because this path is specifically for
        regenerating TTS only. Story/image generation is never called here.
        """
        if not self.output_root.exists():
            return None
        candidates=[]
        for p in self.output_root.iterdir():
            if not p.is_dir():
                continue
            plan_path=p/'story_plan.json'; raw=p/'raw'
            if not plan_path.exists() or not raw.exists():
                continue
            plan=read_json(plan_path,{})
            scenes=plan.get('scenes') or []
            if not scenes:
                continue
            images=[raw/f'scene_{i:02d}.jpg' for i in range(1,len(scenes)+1)]
            if any((not img.exists()) or img.stat().st_size < 5000 for img in images):
                continue
            candidates.append(p)
        return max(candidates, key=lambda x:x.stat().st_mtime) if candidates else None

    async def regenerate_tts_only(self, mode: str = 'mm') -> None:
        root=self.latest_story_with_images()
        if root is None:
            raise RuntimeError('No existing Story Motion story with complete raw images was found.')
        plan=read_json(root/'story_plan.json',{})
        scenes=plan.get('scenes') or []
        genre=str(plan.get('genre') or root.name.split('_')[-1] or 'horror').lower()
        raw=root/'raw'
        images=[raw/f'scene_{i:02d}.jpg' for i in range(1,len(scenes)+1)]
        langs=['mm','en'] if mode=='dual' else [mode]

        print('\n' + '='*74)
        print('STORY MOTION V0.3.9 — TTS ONLY REGENERATE + DRAMA SCENE-AUDIO LOCK')
        print(f'📁 {root}')
        print(f'🎞️ {plan.get("title","")}')
        print(f'🖼️ LOCKED: reusing {len(images)} existing images — NO IMAGE API')
        print('📝 LOCKED: reusing existing story_plan.json — NO STORY GENERATION')
        print(f'🎙️ Regenerating only {" + ".join(x.upper() for x in langs)} narration')
        print('🎯 ONE continuous TTS call per language → [short pause] → scene_XX.wav')
        print('='*74)

        # Back up old narrator WAVs before replacing them.
        backup=root/'audio'/'backup_before_v039'
        backup.mkdir(parents=True, exist_ok=True)
        for lang in langs:
            old=root/'audio'/f'narration_{lang}.wav'
            if old.exists() and old.stat().st_size > 0:
                stamp=time.strftime('%Y%m%d_%H%M%S')
                shutil.copy2(old, backup/f'narration_{lang}_{stamp}.wav')

        renders=[]
        for lang in langs:
            renders.append(await self.render_language(plan, images, genre, lang, root, safe_local_only=False, force_tts_only=True))

        write_json(root/'result.json',{
            'success':True,'story_id':str(plan.get('story_id') or root.name),
            'title':plan.get('title',''),'genre':genre,'mode':mode,
            'renders':renders,'root':str(root),'tts_only_regenerated':True,
            'images_reused':True,'story_reused':True,
        })
        self._cleanup_success_work(root)
        print('\n✅ TTS-ONLY REGEN + SCENE LOCK COMPLETE')
        for row in renders:
            for path in row['outputs']:
                print(f'🎥 {path}')

    async def resume(self, mode: str = "dual") -> None:
        root = self.latest_reusable_story_root(mode)
        if root is None:
            langs = "MM+EN" if mode == "dual" else mode.upper()
            raise RuntimeError(
                "No reusable Story Motion production folder was found with a full raw image set "
                f"and existing {langs} narration WAV. SAFE RERENDER stopped before any paid API call."
            )

        plan = read_json(root / "story_plan.json", {})
        scenes = plan.get("scenes") or []
        if not scenes:
            raise RuntimeError(f"Invalid story_plan.json: {root}")

        genre = str(plan.get("genre") or root.name.split("_")[-1] or "horror").lower()
        raw = root / "raw"
        images = [raw / f"scene_{i:02d}.jpg" for i in range(1, len(scenes) + 1)]
        missing = [str(p) for p in images if not p.exists() or p.stat().st_size < 5000]
        if missing:
            raise RuntimeError(f"Safe rerender raw images missing: {missing[:3]}")

        langs = ["mm", "en"] if mode == "dual" else [mode]
        for lang in langs:
            wav = root / "audio" / f"narration_{lang}.wav"
            try:
                valid = wav.exists() and wav.stat().st_size >= 5000 and self.fx.duration(wav) > 3.0
            except Exception:
                valid = False
            if not valid:
                raise RuntimeError(
                    f"SAFE RERENDER requires existing TTS: {wav}. "
                    "Stopped before any Gemini/TTS API call."
                )

        print("\n" + "=" * 74)
        print("STORY MOTION V0.3.9 — DRAMA SCENE-AUDIO LOCK")
        print(f"📁 {root}")
        print(f"🎞️ {plan.get('title','')}")
        print(f"🖼️ Reusing {len(images)} existing images")
        print(f"🎙️ Reusing existing {' + '.join(x.upper() for x in langs)} narration WAV")
        print("🔒 SAFE MODE: NO story generation / NO image API / NO TTS API")
        print("🧩 Only local full-subtitle PNG + FFmpeg zoom/liquid/audio render will run")
        print("=" * 74)

        renders = []
        for lang in langs:
            renders.append(await self.render_language(plan, images, genre, lang, root, safe_local_only=True))

        series = {
            "series_id": str(plan.get("story_id") or root.name),
            "genre": genre,
            "title": plan.get("title", ""),
            "part_break_after_scene": plan.get("part_break_after_scene"),
            "same_story_locked": True,
            "same_images_locked": True,
            "part2_requires_part1_posted": True,
            "renders": renders,
            "post_status": {"part1": "not_posted", "part2": "not_posted"},
        }
        write_json(root / "series.json", series)
        write_json(root / "result.json", {
            "success": True,
            "story_id": str(plan.get("story_id") or root.name),
            "title": plan.get("title", ""),
            "genre": genre,
            "mode": mode,
            "image_provider": self.story.config.get("image_provider"),
            "renders": renders,
            "root": str(root),
            "resumed": True,
        })

        self._cleanup_success_work(root)
        print("\n✅ RESUME COMPLETE")
        for row in renders:
            for path in row["outputs"]:
                print(f"🎥 {path}")

    async def run(self, genre: str, mode: str, seed: str = "") -> None:
        story_id = time.strftime("%Y%m%d_%H%M%S") + "_" + genre
        root = self.output_root / story_id
        raw = root / "raw"
        root.mkdir(parents=True, exist_ok=True)

        print("\n" + "=" * 74)
        print(f"STORY MOTION PRODUCTION TEST V0.4.3 — ZOOM + LIQUID + FULL SUBS — {genre.upper()} — {mode.upper()}")
        print("Standalone test only: no social upload, no TT Master scheduler changes.")
        print("=" * 74)

        plan = await self.make_plan(genre, seed)
        plan["story_id"] = story_id
        plan["genre"] = genre
        write_json(root / "story_plan.json", plan)
        self._remember(genre, story_id, plan)

        images = await self.make_images(plan, raw)

        langs = ["mm","en"] if mode=="dual" else [mode]
        renders = []
        for lang in langs:
            renders.append(await self.render_language(plan, images, genre, lang, root))

        series = {
            "series_id": story_id,
            "genre": genre,
            "title": plan.get("title", ""),
            "part_break_after_scene": plan.get("part_break_after_scene"),
            "same_story_locked": True,
            "same_images_locked": True,
            "part2_requires_part1_posted": True,
            "renders": renders,
            "post_status": {"part1": "not_posted", "part2": "not_posted"},
        }
        write_json(root / "series.json", series)
        write_json(root / "result.json", {
            "success": True,
            "story_id": story_id,
            "title": plan.get("title", ""),
            "genre": genre,
            "mode": mode,
            "image_provider": self.story.config.get("image_provider"),
            "renders": renders,
            "root": str(root),
        })

        self._cleanup_success_work(root)
        print("\n✅ PRODUCTION TEST COMPLETE")
        print(f"📁 {root}")
        for row in renders:
            for path in row["outputs"]:
                print(f"🎥 {path}")


async def main():
    print("""
STORY MOTION PRODUCTION TEST V0.4.3
1) Horror   — Myanmar
2) Thriller — Myanmar
3) Horror   — English
4) Thriller — English
5) Horror   — Dual (same story/images)
6) Thriller — Dual (same story/images)
7) Audio scan only
8) SAFE RERENDER latest existing production — Dual (sync fix, NO paid API)
9) SAFE RERENDER latest existing production — Myanmar only (NO paid API)
10) GEMINI TTS PER-SCENE — Myanmar (reuse story/images, paid TTS only)
11) SAFE RERENDER — Myanmar from existing scene_XX.wav (NO TTS/image/story API)
12) GEMINI TTS PER-SCENE — English (reuse story/images, paid TTS only)
13) SAFE RERENDER — English from existing scene_XX.wav (NO TTS/image/story API)
14) GEMINI TTS PER-SCENE — Dual MM+EN (reuse story/images, paid TTS only)
15) SAFE RERENDER — Dual MM+EN from existing scene_XX.wav (NO TTS/image/story API)
""")
    choice = input("Choose [1]: ").strip() or "1"
    mapping = {
        "1": ("horror","mm"),
        "2": ("thriller","mm"),
        "3": ("horror","en"),
        "4": ("thriller","en"),
        "5": ("horror","dual"),
        "6": ("thriller","dual"),
    }
    test = ProductionTest()
    if choice == "7":
        genre = (input("Genre [horror]: ").strip() or "horror").lower()
        data = test.fx.scan_audio(genre if genre in {"horror","thriller"} else "horror")
        print(json.dumps({k: len(v) for k,v in data.items()}, indent=2))
        return
    if choice == "8":
        await test.resume("dual")
        return
    if choice == "9":
        await test.resume("mm")
        return
    if choice == "10":
        await test.scene_lock_existing_story("gemini", "mm")
        return
    if choice == "11":
        await test.scene_lock_existing_story("existing", "mm")
        return
    if choice == "12":
        await test.scene_lock_existing_story("gemini", "en")
        return
    if choice == "13":
        await test.scene_lock_existing_story("existing", "en")
        return
    if choice == "14":
        await test.scene_lock_existing_story_dual("gemini")
        return
    if choice == "15":
        await test.scene_lock_existing_story_dual("existing")
        return
    genre, mode = mapping.get(choice, ("horror","mm"))
    seed = input("Optional story seed (Enter = auto original idea): ").strip()
    await test.run(genre, mode, seed)

if __name__ == "__main__":
    asyncio.run(main())
