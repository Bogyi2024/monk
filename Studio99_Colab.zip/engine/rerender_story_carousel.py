from __future__ import annotations

import argparse
import json
from pathlib import Path

from services.story_carousel_service import StoryCarouselService


def _find_latest_story(root: Path) -> Path:
    if not root.exists():
        raise FileNotFoundError(f"Story output root မတွေ့ပါ: {root}")

    candidates = []
    for p in root.iterdir():
        if not p.is_dir():
            continue
        story_json = p / "story.json"
        raw_dir = p / "raw"
        if story_json.exists() and raw_dir.exists():
            try:
                mtime = max(story_json.stat().st_mtime, p.stat().st_mtime)
            except Exception:
                mtime = 0
            candidates.append((mtime, p))

    if not candidates:
        raise FileNotFoundError(
            f"{root} ထဲမှာ story.json + raw/ ပါတဲ့ existing story မတွေ့ပါ။"
        )

    candidates.sort(key=lambda x: x[0], reverse=True)
    return candidates[0][1]


def rerender_story(story_dir: Path) -> None:
    story_dir = story_dir.resolve()
    story_json = story_dir / "story.json"
    raw_dir = story_dir / "raw"
    square_dir = story_dir / "square"

    if not story_json.exists():
        raise FileNotFoundError(f"story.json မတွေ့ပါ: {story_json}")
    if not raw_dir.exists():
        raise FileNotFoundError(f"raw image folder မတွေ့ပါ: {raw_dir}")

    plan = json.loads(story_json.read_text(encoding="utf-8"))
    slides = plan.get("slides") or []
    if not slides:
        raise RuntimeError("story.json ထဲမှာ slides မရှိပါ။")

    # This only loads local config/renderer. No Gemini/FAL image request is made.
    svc = StoryCarouselService()

    total = len(slides)
    print("\n♻️ STORY CAROUSEL — LOCAL RE-RENDER ONLY")
    print(f"📁 Existing story: {story_dir}")
    print("🚫 Gemini story generation: OFF")
    print("🚫 FAL/FLUX image generation: OFF")
    print("🚫 Google image generation: OFF")
    print(f"🖼️ Existing raw images reuse: {total} slides")
    print("🔒 Layout mode: FIXED font sizes + fixed line limits + overflow trim\n")

    for idx, slide in enumerate(slides, 1):
        raw_path = raw_dir / f"slide_{idx:02d}.jpg"
        if not raw_path.exists():
            # Also accept png/webp if an older test used a different extension.
            alternatives = [
                raw_dir / f"slide_{idx:02d}.png",
                raw_dir / f"slide_{idx:02d}.webp",
                raw_dir / f"slide_{idx:02d}.jpeg",
            ]
            raw_path = next((p for p in alternatives if p.exists()), raw_path)

        if not raw_path.exists():
            raise FileNotFoundError(
                f"Slide {idx}/{total} raw image မတွေ့ပါ: {raw_dir / f'slide_{idx:02d}.*'}"
            )

        square_path = square_dir / f"slide_{idx:02d}.jpg"
        svc._render_card(
            raw_path,
            square_path,
            slide,
            canvas_size=(1080, 1080),
            index=idx,
            total=total,
            platform="square",
        )
        print(f"✅ Slide {idx}/{total}: existing raw → unified square re-rendered")

    print("\n🎉 LOCAL RE-RENDER COMPLETE")
    print(f"Square: {square_dir}")
    print("💰 Image generation API cost: $0 for this re-render")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Re-render an existing Story Carousel using existing raw images only."
    )
    parser.add_argument(
        "story_dir",
        nargs="?",
        default="",
        help="Existing story folder. Omit to use the latest outputs/story_carousel story.",
    )
    args = parser.parse_args()

    svc_config = Path("config/story_carousel.json")
    if not svc_config.exists():
        raise FileNotFoundError("config/story_carousel.json မတွေ့ပါ။ project root ကနေ run ပါ။")

    config = json.loads(svc_config.read_text(encoding="utf-8"))
    root = Path(config.get("output_root", "outputs/story_carousel"))

    if args.story_dir.strip():
        story_dir = Path(args.story_dir.strip())
    else:
        story_dir = _find_latest_story(root)

    rerender_story(story_dir)


if __name__ == "__main__":
    main()
