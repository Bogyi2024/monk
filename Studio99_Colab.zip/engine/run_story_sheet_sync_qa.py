from __future__ import annotations

import argparse
import asyncio
import json
import shutil
import sys
import time
from pathlib import Path

from dotenv import load_dotenv

from services.story_carousel_service import StoryCarouselService
from services.story_motion_video_service import StoryMotionVideoService
from story_motion_production_test import ProductionTest, read_json, write_json


ROOT = Path(__file__).resolve().parent

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass


def newest_complete(root: Path, required: tuple[str, ...], excluded: str = '_sheet_sync_qa') -> Path:
    candidates=[]
    for folder in root.iterdir():
        if not folder.is_dir() or excluded in folder.name:
            continue
        if all((folder / name).exists() for name in required):
            candidates.append(folder)
    if not candidates:
        raise FileNotFoundError(f'No complete QA source under {root}')
    return max(candidates, key=lambda x: x.stat().st_mtime)


def sheet_overrides(target: dict) -> None:
    target.update({
        'image_sheet_enabled': True,
        'image_sheet_width': 1152,
        'image_sheet_height': 2048,
        'image_sheet_crop_width': 720,
        'image_sheet_crop_height': 1280,
        'image_sheet_crop_inset_fraction': 0.008,
    })


async def qa_drama(stamp: str) -> dict:
    source = newest_complete(
        ROOT / 'outputs' / 'story_carousel',
        ('story.json', 'narration_plan.json', 'video_build_v2/continuous_female_narration.wav'),
    )
    target = ROOT / 'outputs' / 'story_carousel' / f'{stamp}_sheet_sync_qa_drama'
    target.mkdir(parents=True, exist_ok=True)
    story = read_json(source / 'story.json', {})
    narration = read_json(source / 'narration_plan.json', {})
    story['story_id'] = target.name
    story['output_root'] = str(target)
    write_json(target / 'story.json', story)
    write_json(target / 'narration_plan.json', narration)

    carousel = StoryCarouselService('config/story_carousel.json')
    sheet_overrides(carousel.config)
    images = await carousel._build_story_images(plan=story, raw_dir=target / 'raw')
    total = len(story.get('slides') or [])
    for index, (slide, raw_path) in enumerate(zip(story['slides'], images), 1):
        carousel._render_card(
            raw_path,
            target / 'square' / f'slide_{index:02d}.jpg',
            slide,
            canvas_size=(1080, 1080),
            index=index,
            total=total,
            platform='square',
        )

    voice_target = target / 'video_build_v2' / 'continuous_female_narration.wav'
    voice_target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / 'video_build_v2' / 'continuous_female_narration.wav', voice_target)
    video_cfg = read_json(ROOT / 'config' / 'story_video.json', {})
    video_cfg['minimum_scene_tail_seconds'] = 0.0
    report = await asyncio.to_thread(
        StoryMotionVideoService(video_cfg).build,
        story_dir=target,
        story=story,
        narration_plan=narration,
        force_tts=False,
    )
    return {
        'source': str(source),
        'root': str(target),
        'sheet_count': len(list((target / 'raw' / '_sheets').glob('sheet_??.jpg'))),
        'scene_count': len(images),
        'report': report,
    }


async def qa_story_motion(stamp: str) -> dict:
    source = newest_complete(
        ROOT / 'outputs' / 'story_motion',
        ('story_plan.json', 'audio/narration_mm.wav'),
    )
    target = ROOT / 'outputs' / 'story_motion' / f'{stamp}_sheet_sync_qa_thriller'
    target.mkdir(parents=True, exist_ok=True)
    plan = read_json(source / 'story_plan.json', {})
    plan['story_id'] = target.name
    write_json(target / 'story_plan.json', plan)

    engine = ProductionTest()
    sheet_overrides(engine.cfg)
    engine.cfg.update({
        'subtitle_chunk_sync_enabled': True,
        'subtitle_silence_noise': '-40dB',
        'subtitle_silence_min_seconds': 0.18,
        'cleanup_work_after_success': False,
        'render_cache_tag': 'v044_sheet_audio_pause_sync_qa',
    })
    images = await engine.make_images(plan, target / 'raw')
    audio_target = target / 'audio' / 'narration_mm.wav'
    audio_target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / 'audio' / 'narration_mm.wav', audio_target)
    render = await engine.render_language(
        plan,
        images,
        str(plan.get('genre') or 'thriller'),
        'mm',
        target,
        safe_local_only=True,
        strict_scene_boundaries=True,
    )
    timeline = read_json(target / 'timeline_mm.json', {})
    scenes = timeline.get('scenes') if isinstance(timeline, dict) else []
    fallback_count = sum(
        1 for row in (scenes or [])
        if str(row.get('subtitle_sync_mode') or '').startswith('weighted_text_fallback')
    )
    return {
        'source': str(source),
        'root': str(target),
        'sheet_count': len(list((target / 'raw' / '_sheets').glob('sheet_??.jpg'))),
        'scene_count': len(images),
        'subtitle_fallback_scenes': fallback_count,
        'render': render,
    }


async def main(args: argparse.Namespace) -> None:
    load_dotenv(ROOT / '.env')
    stamp = time.strftime('%Y%m%d_%H%M%S')
    result={'success':False,'stamp':stamp}
    if args.mode in {'both','drama'}:
        result['drama'] = await qa_drama(stamp)
    if args.mode in {'both','story'}:
        result['story_motion'] = await qa_story_motion(stamp)
    result['success']=True
    out=ROOT / 'outputs' / f'{stamp}_story_sheet_sync_qa_result.json'
    write_json(out,result)
    print('\nQA_RESULT=' + str(out))
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=('both','drama','story'),default='both')
    asyncio.run(main(parser.parse_args()))
