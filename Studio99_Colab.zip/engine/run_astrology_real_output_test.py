from __future__ import annotations
import argparse, asyncio
from datetime import datetime
from services.astrology_real_output_service import AstrologyRealOutputService

async def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--date',default='',help='YYYY-MM-DD; default today')
    args=ap.parse_args()
    when=datetime.strptime(args.date,'%Y-%m-%d') if args.date else datetime.now()
    await AstrologyRealOutputService().run_today(when)

if __name__=='__main__': asyncio.run(main())
