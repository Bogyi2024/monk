"""Authoritative, job-scoped Tavily credentials shared by all search workers."""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

ENABLED_LOG = "[Search backend] Tavily enabled via live key file"
DISABLED_LOG = "[Search backend] Tavily disabled -> DDGS primary"
LIVE_KEY_PATH = Path(__file__).resolve().parent / "tavily_key.txt"


def read_live_key(path: Path | None = None) -> str:
    # No environment fallback: missing/unreadable/blank means disabled.
    try:
        value = (path or LIVE_KEY_PATH).read_text(encoding="utf-8-sig").strip()
    except (OSError, UnicodeError):
        return ""
    return value if value and not any(c.isspace() for c in value) else ""


def start_search_job(path: Path | None = None) -> str:
    key = read_live_key(path)
    print(ENABLED_LOG if key else DISABLED_LOG)
    return key


class TavilyLiveService:
    def __init__(self, project_root: Path | str):
        self.path = Path(project_root).resolve() / "tavily_key.txt"

    def status(self) -> dict:
        key = read_live_key(self.path)
        # Short/malformed keys must never be revealed by a suffix mask.
        masked = ("tvly-****" + key[-4:]) if len(key) >= 12 else ("****" if key else "")
        return {
            "tavily": "ENABLED" if key else "DISABLED",
            "enabled": bool(key),
            "masked_key": masked,
            "ddgs": "AVAILABLE",
        }

    def save(self, value: str) -> dict:
        key = str(value or "").strip()
        if len(key) > 4096 or any(c.isspace() for c in key):
            raise ValueError("Enter exactly one Tavily key, without internal whitespace.")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=".tavily-", suffix=".tmp", dir=self.path.parent)
        tmp = Path(name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
                handle.write(key)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, self.path)
        finally:
            tmp.unlink(missing_ok=True)
        return self.status()

    def clear(self) -> dict:
        return self.save("")
