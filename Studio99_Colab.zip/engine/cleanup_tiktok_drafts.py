"""One-off confirmed TikTok draft cleanup; browser close never authorizes deletion."""
import argparse
import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path
from playwright.async_api import async_playwright
from services.tiktok_draft_cleanup import cleanup_page, import_published_report, ROOT

async def run(profile, dry_run, import_report=True):
    blob_root=ROOT/'browser_profiles'/profile/'Default/IndexedDB/https_www.tiktok.com_0.indexeddb.blob'
    def media_bytes():
        return sum(p.stat().st_size for p in blob_root.rglob('*') if p.is_file())
    before=media_bytes()
    report_path=ROOT/'state'/f'tiktok_posts_readonly_{profile}.json'
    if import_report and report_path.exists():
        report=json.loads(report_path.read_text(encoding='utf-8-sig'))
        import_published_report(report)
    async with async_playwright() as pw:
        context=await pw.chromium.launch_persistent_context(str(ROOT/'browser_profiles'/profile),headless=True,args=['--disable-background-networking','--disable-notifications'])
        try:
            await context.route('**/*',lambda route:route.fulfill(status=200,content_type='text/html',body='<html></html>'))
            page=await context.new_page();await page.goto('https://www.tiktok.com/')
            result=await cleanup_page(page,profile,dry_run=dry_run)
        finally:await context.close()
    after=media_bytes()
    result.update(blob_bytes_before=before,blob_bytes_after=after,freed_bytes=max(0,before-after))
    from services.post_publish_cleanup import atomic
    atomic(ROOT/'state/tiktok_draft_cleanup'/f'{profile}_last_run.json',result)
    atomic(ROOT/'state/tiktok_draft_cleanup/history'/f"{datetime.now(timezone.utc):%Y%m%dT%H%M%S%fZ}_{profile}.json",result)
    print('🧹 TikTok confirmed-draft cleanup: ' + json.dumps(
        {k:v for k,v in result.items() if k!='groups'}, ensure_ascii=False), flush=True)

async def process_profiles(profiles, *, dry_run, refresh_published):
    for profile in profiles:
        try:
            if refresh_published:
                # Refresh the newest server-published IDs before each hourly
                # cleanup. This makes cleanup independent of the long-lived
                # Master's imported tt_service version.
                from inspect_tiktok_posts import inspect_profile
                await inspect_profile(profile,paginate=False)
            await run(profile,dry_run,True)
        except Exception as exc:
            # Chromium's persistent-profile lock prevents touching a browser
            # in use by uploading/login. Retry on the next maintenance pass.
            print(json.dumps({'profile':profile,'retained':True,'error':str(exc).splitlines()[0]},ensure_ascii=False),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('profile',nargs='?');parser.add_argument('--delete',action='store_true');parser.add_argument('--pending',action='store_true')
    args=parser.parse_args()
    if not args.profile and not args.pending:parser.error('Provide a profile or --pending')
    async def main():
        profiles=[args.profile] if args.profile else [p.stem for p in (ROOT/'state/tiktok_confirmed_posts').glob('*.json')]
        await process_profiles(profiles,dry_run=not args.delete,refresh_published=args.pending)
    asyncio.run(main())
