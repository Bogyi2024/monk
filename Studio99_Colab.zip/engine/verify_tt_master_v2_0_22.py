from __future__ import annotations

import hashlib
import json
import py_compile
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path.cwd().resolve()
FILES = [
    "services/tt_preparation_status_service.py",
    "services/tt_rolling_schedule_service.py",
    "services/tt_fb_profile_service.py",
    "tt_web_manager.py",
    "tt_web/index.html",
]


def sha(path: Path) -> str:
    h = hashlib.sha256(); h.update(path.read_bytes()); return h.hexdigest()


def require(text: str, marker: str, label: str) -> None:
    if marker not in text:
        raise RuntimeError(f"Missing {label}: {marker}")


def main() -> None:
    missing = [x for x in FILES if not (ROOT / x).exists()]
    if missing:
        raise SystemExit("Missing patched files: " + ", ".join(missing))
    for rel in FILES:
        if rel.endswith(".py"):
            py_compile.compile(str(ROOT / rel), doraise=True)
    print("PASS: Python syntax")

    prep = (ROOT / "services/tt_preparation_status_service.py").read_text(encoding="utf-8")
    rolling = (ROOT / "services/tt_rolling_schedule_service.py").read_text(encoding="utf-8")
    mgr = (ROOT / "tt_web_manager.py").read_text(encoding="utf-8")
    html = (ROOT / "tt_web/index.html").read_text(encoding="utf-8")
    fbsvc = (ROOT / "services/tt_fb_profile_service.py").read_text(encoding="utf-8")
    helper = (ROOT / "tt_fb_profile_login.py").read_text(encoding="utf-8")

    require(prep, "lts_route_active_count", "LTS active reader")
    require(prep, "inventory_primary_marked", "secondary-only pending guard")
    require(rolling, "prepared_active", "Scheduler LTS active field")
    require(rolling, "item['posted']", "Scheduler LTS posted field")
    require(html, "Ready</th><th>Active</th><th>Posted / Target", "LTS Today inventory columns")
    require(html, "Re-login / Repair", "FB repair action")
    require(mgr, "/api/facebook-page-profile-open", "FB Page profile open endpoint")
    require(mgr, "/api/facebook-page-profile-test", "FB Page profile test endpoint")
    require(fbsvc, "browser_profiles/<profile>", "persistent profile contract")
    require(helper, "launch_persistent_context", "persistent Playwright context")
    print("PASS: LTS read-model + FB profile repair surface")

    scripts = re.findall(r"<script[^>]*>(.*?)</script>", html, re.S | re.I)
    node = shutil.which("node")
    if node and scripts:
        tmp = ROOT / "state" / "_tt_v2022_verify_inline.js"
        tmp.parent.mkdir(parents=True, exist_ok=True)
        tmp.write_text("\n".join(scripts), encoding="utf-8")
        try:
            p = subprocess.run([node, "--check", str(tmp)], capture_output=True, text=True)
            if p.returncode != 0:
                raise RuntimeError("JavaScript syntax failed:\n" + (p.stderr or p.stdout)[-3000:])
            print("PASS: JavaScript syntax (node --check)")
        finally:
            tmp.unlink(missing_ok=True)
    else:
        print("INFO: Node.js not found; JavaScript marker checks passed (delivery build was node --check tested).")

    receipt_path = ROOT / "state" / "tt_v2_0_22_install.json"
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        stable = receipt.get("stable_hashes") or {}
        for rel, expected in stable.items():
            p = ROOT / rel
            if p.exists() and sha(p) != expected:
                raise RuntimeError(f"Stable execution hash changed after install: {rel}")
        ext_path = str(receipt.get("standalone_lts_runner") or "")
        ext_hash = str(receipt.get("standalone_lts_runner_sha256") or "")
        if ext_path and ext_path != "not_found_at_install_time" and ext_hash:
            p = Path(ext_path)
            if p.exists() and sha(p) != ext_hash:
                raise RuntimeError("Standalone Long-to-Short tt_bridge_runner.py changed after install")
        print("PASS: stable execution hashes unchanged")

    print("\nVERIFY OK — TT Master V2.0.22")
    print("FB Page rows can now Test Login or Re-login/Repair the SAME persistent profile.")
    print("LTS posting UI now separates Ready, Active primary upload, and Posted/Target.")


if __name__ == "__main__":
    main()
