from __future__ import annotations

import json
from pathlib import Path

p = Path("downloads/story_uniqueness_registry.json")
if not p.exists():
    print("No story uniqueness registry yet. Run Story Board once; existing outputs will auto-bootstrap.")
else:
    data = json.loads(p.read_text(encoding="utf-8"))
    stories = data.get("stories", [])
    print(f"Stored unique stories: {len(stories)}")
    for item in stories[-20:]:
        print(f"- {item.get('story_id','')} | {item.get('title','')} | {item.get('premise','')[:80]}")
