from __future__ import annotations

import argparse
import asyncio
import os
import socket
from pathlib import Path

from playwright.async_api import async_playwright


def _project_root() -> Path:
    return Path(__file__).resolve().parent




def _fb_proxy():
    return None  # OS network / external VPN


async def init_facebook(profile_name: str = "Main_FB_Account", wait_seconds: int = 300) -> None:
    profile = _project_root() / "browser_sessions" / profile_name
    profile.mkdir(parents=True, exist_ok=True)
    proxy = _fb_proxy()
    print(f"👉 Facebook profile: {profile}")
    print(f"🌐 Facebook proxy: {proxy['server'] if proxy else 'OFF'}")
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile),
            headless=False,
            args=["--disable-notifications", "--disable-blink-features=AutomationControlled"],
            proxy=proxy,
        )
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()
        await page.goto("https://business.facebook.com/", timeout=120_000, wait_until="domcontentloaded")
        print("\n✅ Browser ဖွင့်ပြီးပါပြီ။ Facebook/Meta account ကို login ဝင်ပါ။")
        print("✅ Recap Entertainment page ကို Business Suite ထဲမြင်ရတာ သေချာစစ်ပါ။")
        print(f"⏳ {wait_seconds} seconds အတွင်း login ပြီးအောင်လုပ်ပါ။ Browser ကို script ကပိတ်တဲ့အထိထားပါ။\n")
        await page.wait_for_timeout(max(30, wait_seconds) * 1000)
        await ctx.close()
        print("✅ Facebook persistent session သိမ်းပြီးပါပြီ။")


async def init_tiktok(profile_name: str = "TikTok_Recapentertainment", wait_seconds: int = 300) -> None:
    profile = _project_root() / "browser_profiles" / profile_name
    profile.mkdir(parents=True, exist_ok=True)
    proxy_value = os.getenv("TIKTOK_PROXY", "").strip()
    proxy = {"server": proxy_value} if proxy_value and proxy_value.lower() not in {"none", "off", "false", "0"} else None
    print(f"👉 TikTok profile: {profile}")
    print(f"🌐 TikTok proxy: {proxy['server'] if proxy else 'OFF'}")
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile),
            headless=False,
            args=["--disable-notifications", "--disable-blink-features=AutomationControlled"],
            proxy=proxy,
        )
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()
        await page.goto("https://www.tiktok.com/tiktokstudio/upload", timeout=120_000, wait_until="domcontentloaded")
        print("\n✅ TikTok Studio ဖွင့်ပြီးပါပြီ။ TikTok account ကို login ဝင်ပါ။")
        print(f"⏳ {wait_seconds} seconds အတွင်း login ပြီးအောင်လုပ်ပါ။ Browser ကို script ကပိတ်တဲ့အထိထားပါ။\n")
        await page.wait_for_timeout(max(30, wait_seconds) * 1000)
        await ctx.close()
        print("✅ TikTok persistent session သိမ်းပြီးပါပြီ။")


async def main(args):
    if args.platform in {"fb", "all"}:
        await init_facebook(args.fb_profile, args.wait)
    if args.platform in {"tiktok", "all"}:
        await init_tiktok(args.tiktok_profile, args.wait)


def parse_args():
    p = argparse.ArgumentParser(description="Initialize persistent FB/TikTok login profiles for Recap auto-post.")
    p.add_argument("platform", nargs="?", choices=["fb", "tiktok", "all"], default="all")
    p.add_argument("--wait", type=int, default=300)
    p.add_argument("--fb-profile", default="Main_FB_Account")
    p.add_argument("--tiktok-profile", default="TikTok_Recapentertainment")
    return p.parse_args()


if __name__ == "__main__":
    asyncio.run(main(parse_args()))
