from __future__ import annotations
import json, py_compile, subprocess, sys, tempfile
from datetime import datetime, timedelta
from pathlib import Path

root=Path.cwd().resolve(); lts=(root.parent/'long_to_short').resolve()
checks=[]
def check(name, ok, detail=''):
    checks.append((name,bool(ok),detail)); print(('OK   ' if ok else 'FAIL ')+name+(f' — {detail}' if detail else ''))

required=[
 root/'bridges/long_to_short_bridge.py', root/'services/tt_long_to_short_night_service.py',
 root/'services/tt_pipeline_service.py', root/'services/tt_daily_run_service.py', root/'tt_master_scheduler.py',
 lts/'tt_bridge_runner.py', lts/'run_long_to_short_test.py', lts/'services/gemini_moment_selector.py'
]
for p in required: check(str(p.relative_to(root) if p.is_relative_to(root) else p),p.exists())
try:
    cfg=json.loads((root/'config/tt_categories.json').read_text(encoding='utf-8')); cat=(cfg.get('categories') or {}).get('long_to_short') or {}
    check('Long-to-Short category card',bool(cat),'routes='+','.join((cat.get('routes') or {}).keys()))
    outs={str(r.get('output_type') or '') for r in (cat.get('routes') or {}).values()}
    check('Route output modes',{'transformative_envo_mm','original_audio_mm'} <= outs,str(sorted(outs)))
except Exception as exc: check('TT category config',False,str(exc))

for p in [x for x in required if x.suffix=='.py']:
    try: py_compile.compile(str(p),doraise=True); check('compile '+p.name,True)
    except Exception as exc: check('compile '+p.name,False,str(exc))

try:
    target=(datetime.now().astimezone().date()+timedelta(days=1)).isoformat()
    with tempfile.NamedTemporaryFile(suffix='.json',delete=False) as f: out=Path(f.name)
    cmd=[sys.executable,str(lts/'tt_bridge_runner.py'),'status','--date',target,'--json-out',str(out)]
    rc=subprocess.run(cmd,cwd=str(lts)).returncode
    data=json.loads(out.read_text(encoding='utf-8')) if out.exists() else {}
    out.unlink(missing_ok=True)
    check('Standalone structured status',rc==0 and data.get('ok') is True,str(data.get('inventory_path') or ''))
except Exception as exc: check('Standalone structured status',False,str(exc))

bad=[p for p in ['services/tt_recap_bridge.py','services/tt_drama_bridge.py','services/fb_group_service.py'] if not (root/p).exists()]
check('Stable Recap/Drama/group-share files still present',not bad,','.join(bad))
print('\nRESULT:', 'PASS' if all(ok for _,ok,_ in checks) else 'FAIL')
raise SystemExit(0 if all(ok for _,ok,_ in checks) else 1)
