from datetime import datetime
from services.tt_telegram_notify_service import TTTelegramNotifyService

svc = TTTelegramNotifyService('.')
if not svc.enabled:
    print('Telegram notifier is DISABLED.')
    print('Add TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID to recap_personal/.env, then run again.')
    raise SystemExit(2)

ok = svc.send_text(
    '✅ TT Master Telegram test\n\n'
    f'Time: {datetime.now().astimezone():%Y-%m-%d %H:%M:%S}\n'
    'If you can read this, TT Telegram notifications are ready.'
)
print('Telegram test:', 'PASS' if ok else 'FAILED')
raise SystemExit(0 if ok else 1)
