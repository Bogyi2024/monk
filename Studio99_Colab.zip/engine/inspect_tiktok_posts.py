import asyncio, json, sys
from urllib.parse import urlsplit, parse_qs, urlencode, urlunsplit
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent
async def inspect_profile(profile, *, paginate=True):
    async with async_playwright() as pw:
        context=await pw.chromium.launch_persistent_context(str(ROOT/'browser_profiles'/profile),headless=True,args=['--disable-notifications'])
        tasks=[]; results=[]; request_urls=[]; request_configs=[]
        async def inspect(response):
            if 'tiktok.com' not in response.url or not any(x in response.url for x in ['/api/','/creator/']):return
            try:
                data=await response.json()
                if 'item_list' in data:
                    request_urls.append(response.url)
                    request_configs.append({'method':response.request.method,'body':response.request.post_data,'contentType':response.request.headers.get('content-type','')})
                    results.append({'url':response.url.split('?')[0],'data':data})
            except Exception:pass
        try:
            page=await context.new_page();page.on('response',lambda r:tasks.append(asyncio.create_task(inspect(r))))
            await page.goto('https://www.tiktok.com/tiktokstudio/content',wait_until='domcontentloaded',timeout=120000)
            await page.wait_for_timeout(20000)
            if not request_urls:
                await page.reload(wait_until='domcontentloaded',timeout=120000)
                await page.wait_for_timeout(15000)
            if tasks:await asyncio.gather(*tasks,return_exceptions=True)
            if request_urls and paginate:
                original=urlsplit(request_urls[-1]);params=parse_qs(original.query)
                config=request_configs[-1]
                body=json.loads(config['body']) if config['body'] and 'json' in config['contentType'] else None
                print('pagination fields: '+json.dumps({'method':config['method'],'body_keys':list(body) if isinstance(body,dict) else [],'query_keys':[k for k in params if k in ['cursor','count']]},ensure_ascii=False),flush=True)
                cursor=0;seen=set()
                for _ in range(100):
                    if isinstance(body,dict):
                        body['cursor']=cursor
                        if 'count' in body:body['count']=30
                        if 'size' in body:body['size']=30
                    elif 'cursor' in params:params['cursor']=[str(cursor)]
                    else:break
                    if 'count' in params:params['count']=['30']
                    url=urlunsplit((original.scheme,original.netloc,original.path,urlencode(params,doseq=True),''))
                    response=await page.evaluate('async x => {const r=await fetch(x.url,{credentials:"include",method:x.method,headers:x.body?{"Content-Type":x.contentType}:{},body:x.body?JSON.stringify(x.body):undefined});return await r.json()}',{'url':url,'method':config['method'],'body':body,'contentType':config['contentType']})
                    results.append({'url':original.path,'data':response})
                    if response.get('status_code')!=0:break
                    nxt=response.get('cursor')
                    if not response.get('has_more') or nxt in seen or nxt==cursor:break
                    seen.add(cursor);cursor=nxt
                    await page.wait_for_timeout(250)
            posts={}
            for row in results:
                for item in row['data'].get('item_list') or []:
                    vids=set()
                    for url in [*(item.get('play_addr') or []),*((item.get('download_info') or {}).get('download_urls') or [])]:
                        vids.update(parse_qs(urlsplit(url).query).get('video_id',[]))
                    if item.get('vid'):vids.add(item['vid'])
                    posts[str(item['item_id'])]={'item_id':str(item['item_id']),'video_ids':sorted(vids),'status':item.get('status'),'in_review':item.get('in_review'),'post_time':item.get('post_time')}
            text=(await page.locator('body').inner_text()).lower()
            report={'profile':profile,'page_url':page.url,'posts':list(posts.values()),'last_status':results[-1]['data'].get('status_code') if results else None,'has_more':results[-1]['data'].get('has_more') if results else None,'body_length':len(text),'login_marker':bool(await page.locator('input[type="password"], input[name="username"]').count()),'verification_marker':any(x in text for x in ['verify to continue','captcha','verify you are human'])}
            (ROOT/'state'/f'tiktok_posts_readonly_{profile}.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            print(json.dumps({'profile':profile,'posts':len(posts),'last_status':report['last_status'],'has_more':report['has_more'],'body_length':report['body_length'],'login_marker':report['login_marker'],'verification_marker':report['verification_marker'],'sample':list(posts.values())[:2]},ensure_ascii=False),flush=True)
            return report
        finally:await context.close()
async def batch():
    for profile in sys.argv[1:]:
        try:await inspect_profile(profile)
        except Exception as exc:print(json.dumps({'profile':profile,'retained':True,'error':str(exc).splitlines()[0]},ensure_ascii=False),flush=True)
if __name__=='__main__':
    asyncio.run(batch())
