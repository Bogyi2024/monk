from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from services.tt_share_export_service import TTShareExportService
from services.tt_route_branding_service import TTRouteBrandingService


_MM_DIGITS = str.maketrans("0123456789", "၀၁၂၃၄၅၆၇၈၉")


def _mm_number(value: int) -> str:
    return str(int(value)).translate(_MM_DIGITS)


def _utf8_subprocess_env() -> dict[str, str]:
    """Force standalone Python workers to encode redirected output as UTF-8.

    Windows may otherwise give a redirected child process the active ANSI
    codepage (often cp1252). Episode Splitter progress messages contain emoji,
    so the child can crash while *printing* before any preparation work starts.
    """
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    return env


class TTEpisodeSplitterBridge:
    """Thin TT adapter for the standalone Episode Splitter pool inventory.

    TT Master owns route scheduling, destination spacing, uploads, retries,
    completion counting and optional FB group share.

    Standalone Episode Splitter owns input/work/ready/posted/source_done,
    speech-safe splitting, rendering, inventory MIN/TARGET replenishment and
    the actual ready -> posted file movement.
    """

    CATEGORY = "episode_splitter"

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings = settings_service
        self.root = Path(project_root).resolve()
        self.branding = TTRouteBrandingService(self.root)
        env = str(os.getenv("TT_EPISODE_SPLITTER_DIR") or "").strip()
        self.es_root = Path(env).expanduser().resolve() if env else (self.root.parent / "episode_splitter").resolve()
        self.runner = self.es_root / "tt_bridge_runner.py"
        self.pending_dir = self.root / "state" / "tt_episode_splitter_pending"
        self.pending_dir.mkdir(parents=True, exist_ok=True)
        self.share_export = TTShareExportService(settings_service, self.root)

    @classmethod
    def capability(cls, project_root: str | Path = ".") -> dict[str, Any]:
        root = Path(project_root).resolve()
        env = str(os.getenv("TT_EPISODE_SPLITTER_DIR") or "").strip()
        es_root = Path(env).expanduser().resolve() if env else (root.parent / "episode_splitter").resolve()
        runner = es_root / "tt_bridge_runner.py"
        main = es_root / "run_episode_splitter.py"
        live = runner.exists() and main.exists()
        return {
            "live": live,
            "label": "LIVE — POOL INVENTORY" if live else f"Missing standalone Episode Splitter bridge: {runner}",
        }

    def _pending_path(self, route_key: str) -> Path:
        safe = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in str(route_key or "default"))
        return self.pending_dir / f"{safe}.json"

    @staticmethod
    def _mp4_has_faststart(path: str | Path) -> bool:
        """Return whether the top-level MP4 moov atom precedes media data."""
        target = Path(path)
        try:
            file_size = target.stat().st_size
            atoms: dict[bytes, int] = {}
            with target.open("rb") as handle:
                position = 0
                while position + 8 <= file_size:
                    handle.seek(position)
                    header = handle.read(8)
                    if len(header) != 8:
                        break
                    atom_size, atom_type = struct.unpack(">I4s", header)
                    header_size = 8
                    if atom_size == 1:
                        extended = handle.read(8)
                        if len(extended) != 8:
                            break
                        atom_size = struct.unpack(">Q", extended)[0]
                        header_size = 16
                    elif atom_size == 0:
                        atom_size = file_size - position
                    if atom_size < header_size or position + atom_size > file_size:
                        break
                    if atom_type in {b"moov", b"mdat"} and atom_type not in atoms:
                        atoms[atom_type] = position
                    if b"moov" in atoms and b"mdat" in atoms:
                        return atoms[b"moov"] < atoms[b"mdat"]
                    position += atom_size
        except OSError:
            return False
        return False

    @classmethod
    def _ensure_mp4_faststart(cls, path: str | Path) -> str:
        """Losslessly move MP4 metadata to the front for browser upload hydration."""
        target = Path(path).resolve()
        if cls._mp4_has_faststart(target):
            return str(target)
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            raise FileNotFoundError("ffmpeg is required to faststart Episode Splitter MP4 files")
        temp = target.with_name(target.stem + ".faststart.tmp.mp4")
        temp.unlink(missing_ok=True)
        print(f"📦 Episode MP4 faststart remux (lossless) → {target.name}")
        try:
            cp = subprocess.run(
                [
                    ffmpeg, "-y", "-hide_banner", "-nostdin", "-loglevel", "error",
                    "-i", str(target), "-map", "0", "-c", "copy",
                    "-movflags", "+faststart", str(temp),
                ],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            if cp.returncode != 0:
                raise RuntimeError(f"Episode faststart remux failed: {cp.stderr[-3000:]}")
            if not temp.exists() or temp.stat().st_size < 100_000:
                raise RuntimeError("Episode faststart remux produced no valid output")
            if not cls._mp4_has_faststart(temp):
                raise RuntimeError("Episode faststart verification failed: moov is still after mdat")
            os.replace(temp, target)
            print("✅ Episode MP4 faststart verified — browser metadata is at file front")
            return str(target)
        finally:
            temp.unlink(missing_ok=True)

    def _load_pending(self, route_key: str) -> dict[str, Any] | None:
        p = self._pending_path(route_key)
        try:
            data = json.loads(p.read_text(encoding="utf-8")) if p.exists() else None
            return data if isinstance(data, dict) else None
        except Exception:
            return None

    def _save_pending(self, route_key: str, data: dict[str, Any] | None) -> None:
        p = self._pending_path(route_key)
        if data is None:
            p.unlink(missing_ok=True)
            return
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, p)

    def _invoke(self, args: list[str]) -> dict[str, Any]:
        if not self.runner.exists():
            raise FileNotFoundError(f"Standalone Episode Splitter bridge runner missing: {self.runner}")
        fd, name = tempfile.mkstemp(prefix="tt_es_", suffix=".json", dir=str(self.pending_dir))
        os.close(fd)
        result_path = Path(name)
        try:
            cmd = [sys.executable, "-u", str(self.runner), *args, "--json-out", str(result_path)]
            proc = subprocess.Popen(
                cmd,
                cwd=str(self.es_root),
                env=_utf8_subprocess_env(),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
            )
            assert proc.stdout is not None
            with proc.stdout:
                for line in proc.stdout:
                    print(line.rstrip("\r\n"), flush=True)
            returncode = proc.wait()
            if not result_path.exists():
                raise RuntimeError(f"Episode Splitter bridge returned no JSON (exit={returncode})")
            data = json.loads(result_path.read_text(encoding="utf-8"))
            if returncode != 0 or not bool(data.get("ok")):
                raise RuntimeError(str(data.get("error") or f"Episode Splitter bridge exit={returncode}"))
            return data
        finally:
            result_path.unlink(missing_ok=True)

    @staticmethod
    def _pool_name(route_key: str, route_cfg: dict[str, Any]) -> str:
        # Generic TT Route UI already exposes content_type, so use it as the pool
        # mapping field without adding a special UI dependency.
        return str(
            route_cfg.get("episode_pool")
            or route_cfg.get("pool_name")
            or route_cfg.get("content_type")
            or route_key
            or "main"
        ).strip() or "main"

    @staticmethod
    def _part_total(item: dict[str, Any]) -> int:
        raw = str(item.get("video") or "")
        m = re.search(r"_part_(\d+)_of_(\d+)", Path(raw).name, re.I)
        return int(m.group(2)) if m else max(1, int(item.get("part_count") or item.get("part_index") or 1))

    @staticmethod
    def _normalize_hashtags(values: Any) -> list[str]:
        if isinstance(values, str):
            raw_values = re.split(r"[\s,]+", values)
        elif isinstance(values, (list, tuple, set)):
            raw_values = values
        else:
            raw_values = []

        clean: list[str] = []
        seen: set[str] = set()
        for raw in raw_values:
            tag = str(raw or "").strip().lstrip("#")
            tag = "".join(
                ch for ch in tag
                if ch.isalnum() or ch == "_" or unicodedata.category(ch).startswith("M")
            )
            if not tag:
                continue
            normalized = f"#{tag}"
            key = normalized.casefold()
            if key not in seen:
                seen.add(key)
                clean.append(normalized)
        return clean

    @classmethod
    def _caption(cls, item: dict[str, Any], hashtags: Any = None) -> str:
        title = str(item.get("title") or item.get("source_folder") or "Episode").strip()
        idx = max(1, int(item.get("part_index") or 1))
        caption = f"{title} အပိုင်း {_mm_number(idx)}"
        clean_tags = cls._normalize_hashtags(hashtags)
        return f"{caption}\n\n{' '.join(clean_tags)}" if clean_tags else caption

    @staticmethod
    def _content_id(pool: str, item: dict[str, Any]) -> str:
        source = str(item.get("source_folder") or "source").strip()
        idx = max(1, int(item.get("part_index") or 1))
        return f"episode:{pool}:{source}:part{idx:03d}"

    async def _prepare(
        self,
        pool: str,
        source_urls: list[str] | None = None,
        scan_limit: int = 12,
        prep_buffer_days: int = 3,
        daily_upload_parts: int = 2,
    ) -> dict[str, Any]:
        args = [
            "prepare", "--pool", pool,
            "--scan-limit", str(max(1, int(scan_limit))),
            "--prep-buffer-days", str(max(1, int(prep_buffer_days))),
            "--daily-upload-parts", str(max(1, int(daily_upload_parts))),
        ]
        for url in source_urls or []:
            clean = str(url or "").strip()
            if clean:
                args.extend(["--source-url", clean])
        cookie_file = self.root / "cookie.txt"
        if cookie_file.exists() and cookie_file.stat().st_size > 0:
            args.extend(["--cookie-file", str(cookie_file)])
        return await asyncio.to_thread(self._invoke, args)

    async def _peek(self, pool: str) -> dict[str, Any] | None:
        result = await asyncio.to_thread(self._invoke, ["peek", "--pool", pool])
        return result.get("item") if result.get("found") else None

    async def _mark_primary(self, pool: str, source_folder: str, part_index: int) -> dict[str, Any]:
        return await asyncio.to_thread(
            self._invoke,
            ["mark-primary", "--pool", pool, "--source-folder", source_folder, "--part-index", str(int(part_index))],
        )

    async def run_once(self, route_key: str = "default") -> dict[str, Any]:
        resolved = self.settings.resolve_route(self.CATEGORY, route_key)
        cat = resolved["category"]
        route_cfg = resolved.get("route") or {}
        if not cat.get("enabled", True) or not route_cfg.get("enabled", True):
            raise RuntimeError(f"Episode Splitter route disabled: {route_key}")

        pool = self._pool_name(route_key, route_cfg)
        pending = self._load_pending(route_key)

        if not pending:
            # V2.0.20: posting jobs consume READY inventory only. Heavy split/render
            # replenishment moved to the separate night Preparation phase.
            item = await self._peek(pool)
            if not item:
                return {
                    "success": False,
                    "new_content_count": 0,
                    "no_work": True,
                    "failure_kind": "no_new_content",
                    "route_key": route_key,
                    "pool": pool,
                    "message": f"No READY Episode Splitter part in pool '{pool}'.",
                }

            video_path = str(item.get("video") or "")
            if not video_path or not Path(video_path).exists():
                raise FileNotFoundError(f"Episode Splitter READY video missing: {video_path}")
            thumbnail_path = str(item.get("thumbnail") or "").strip()
            if thumbnail_path and not Path(thumbnail_path).exists():
                raise FileNotFoundError(f"Episode Splitter READY thumbnail missing: {thumbnail_path}")

            pending = {
                "route_key": route_key,
                "pool": pool,
                "item": item,
                "video_path": video_path,
                "thumbnail_path": thumbnail_path,
                "content_id": self._content_id(pool, item),
                "caption": self._caption(item, route_cfg.get("episode_hashtags")),
                "fb_done": False,
                "fb_thumbnail_done": False,
                "tt_done": False,
                "tt_thumbnail_done": False,
                "group_done": False,
                "fb_post_link": "",
                "inventory_primary_marked": False,
                "group_summary": None,
            }
            self._save_pending(route_key, pending)
            print(
                f"📦 Episode Splitter READY claim → pool={pool} | "
                f"{item.get('source_folder')} part {item.get('part_index')} | {Path(video_path).name}"
            )
        else:
            pool = str(pending.get("pool") or pool)
            print(f"♻️ Episode Splitter pending retry → route={route_key} | {pending.get('content_id', '')}")

        item = pending.get("item") or {}
        video_path = str(pending.get("video_path") or "")
        thumbnail_path = str(pending.get("thumbnail_path") or item.get("thumbnail") or "").strip()
        if not video_path or not Path(video_path).exists():
            # After primary completion the standalone runner may have moved READY -> POSTED.
            # That is safe for group-share-only maintenance, but a pending primary upload
            # still requires the actual file.
            if not pending.get("inventory_primary_marked"):
                raise FileNotFoundError(f"Episode Splitter pending video missing: {video_path}")

        if video_path and Path(video_path).exists() and not pending.get("inventory_primary_marked"):
            video_path = await asyncio.to_thread(self._ensure_mp4_faststart, video_path)
            pending["video_path"] = video_path
            pending["mp4_faststart_verified"] = True
            self._save_pending(route_key, pending)

        caption = str(pending.get("caption") or self._caption(item, route_cfg.get("episode_hashtags")))
        content_id = str(pending.get("content_id") or self._content_id(pool, item))
        fb = resolved.get("facebook")
        tt = resolved.get("tiktok")
        want_fb = bool(fb and fb.get("enabled", True))
        want_tt = bool(tt and tt.get("enabled", True))
        if not want_fb and not want_tt:
            raise RuntimeError(f"Episode Splitter route {route_key} has no enabled Facebook/TikTok destination")
        selected_profiles = self.share_export.sync_route(self.CATEGORY, route_key)
        want_group = bool(want_fb and route_cfg.get("share_enabled", True) and selected_profiles)

        primary_completed_this_run: list[str] = []

        if want_fb and not pending.get("fb_done"):
            from services.browser_service import BrowserService

            browser = BrowserService()

            # Share may have succeeded even when Meta's Page-route indexing did
            # not expose the new permalink inside the original 5-minute window.
            # Never upload the same 0.6-1.0 GiB Episode again from that ambiguous
            # state. Recover by target-Page owner + exact caption fingerprint.
            if pending.get("fb_publish_verification_pending"):
                recovery_attempt = int(pending.get("fb_publish_recovery_attempts") or 0) + 1
                pending["fb_publish_recovery_attempts"] = recovery_attempt
                self._save_pending(route_key, pending)
                print(
                    f"🔎 Episode Facebook Share-click recovery {recovery_attempt} "
                    f"— re-upload blocked until owner+caption verification"
                )
                recovered_link = await browser.recover_reel_permalink_by_caption(
                    str(fb.get("profile") or "Main_FB_Account"),
                    str(fb.get("page_id") or ""),
                    caption,
                    timeout_ms=300_000,
                    page_name_hint=str(fb.get("label") or ""),
                )
                if recovered_link:
                    pending["fb_done"] = True
                    pending["fb_post_link"] = str(recovered_link)
                    pending["fb_publish_verification_pending"] = False
                    pending["fb_verified_by_recovery_at"] = datetime.now(timezone.utc).isoformat()
                    self._save_pending(route_key, pending)
                    primary_completed_this_run.append("facebook")
                else:
                    pending["fb_publish_last_recovery_at"] = datetime.now(timezone.utc).isoformat()
                    self._save_pending(route_key, pending)
                    return {
                        "success": False,
                        "new_content_count": 0,
                        "pending": True,
                        "route_key": route_key,
                        "failure_kind": "facebook_publish_verification_pending",
                        "content_id": content_id,
                        "retry_cooldown_minutes": 15,
                    }

            if not pending.get("fb_done") and (
                not thumbnail_path or not Path(thumbnail_path).exists()
            ):
                raise FileNotFoundError(
                    f"Episode Splitter Facebook thumbnail is required but missing: {thumbnail_path}"
                )

            if not pending.get("fb_done"):
                branded_video = await asyncio.to_thread(
                    self.branding.brand_video, video_path, self.CATEGORY, route_key,
                    route_cfg.get("branding") or {}, "facebook_reel",
                )
                branded_thumbnail = thumbnail_path
                if thumbnail_path:
                    branded_thumbnail = await asyncio.to_thread(
                        self.branding.brand_image, thumbnail_path, self.CATEGORY, route_key,
                        route_cfg.get("branding") or {}, "facebook_post",
                    )
                summary = await browser.upload_reel_stealth(
                    str(fb.get("profile") or "Main_FB_Account"),
                    str(fb.get("page_id") or ""),
                    caption,
                    branded_video,
                    thumbnail_path=branded_thumbnail,
                    page_name_hint=str(fb.get("label") or ""),
                    capture_permalink=want_group,
                    # Episode parts are ~0.6-1.0 GiB. Meta can paint Add-video before
                    # its large-file worker is ready; 5s still produced an occasional
                    # permanent 0% shell. Settle both sides of the chooser for 15s.
                    file_selection_delay_ms=15_000,
                    upload_acceptance_timeout_ms=180_000,
                    prefer_native_dialog=True,
                )
                pending["fb_done"] = bool((summary or {}).get("success"))
                pending["fb_thumbnail_done"] = bool((summary or {}).get("thumbnail_selected"))
                if (summary or {}).get("post_link"):
                    pending["fb_post_link"] = str(summary.get("post_link"))
                if (summary or {}).get("verification_failed"):
                    pending["fb_publish_verification_pending"] = True
                    pending["fb_share_clicked_at"] = datetime.now(timezone.utc).isoformat()
                    pending["fb_publish_recovery_attempts"] = 0
                self._save_pending(route_key, pending)
            if pending["fb_done"]:
                if "facebook" not in primary_completed_this_run:
                    primary_completed_this_run.append("facebook")
            else:
                return {
                    "success": False,
                    "new_content_count": 0,
                    "pending": True,
                    "route_key": route_key,
                    "failure_kind": "facebook_upload_pending",
                    "content_id": content_id,
                }

        if want_tt and not pending.get("tt_done"):
            from services.tt_service import upload_to_tiktok

            branded_video = await asyncio.to_thread(
                self.branding.brand_video, video_path, self.CATEGORY, route_key,
                route_cfg.get("branding") or {}, "tiktok_reel",
            )
            branded_thumbnail = thumbnail_path
            if thumbnail_path:
                branded_thumbnail = await asyncio.to_thread(
                    self.branding.brand_image, thumbnail_path, self.CATEGORY, route_key,
                    route_cfg.get("branding") or {}, "tiktok_image",
                )

            ok = await upload_to_tiktok(
                profile_folder_name=str(tt.get("profile") or ""),
                video_path=branded_video,
                caption_text=caption,
                headless=False,
                thumbnail_path=branded_thumbnail,
                first_frame_is_thumbnail=bool(item.get("tiktok_cover_embedded")),
                require_thumbnail=True,
                # Keep normal short-form routes unchanged. A 0.6-1.0 GiB Episode
                # can legitimately remain on TikTok's loading picker for several
                # minutes while the browser ingests it. The previous 45s/90s
                # thresholds repeatedly cancelled a healthy large-file ingest.
                # Give each accepted selection a real large-file window before
                # the one bounded reselect/reload recovery sequence.
                file_selection_delay_ms=15_000,
                timeout_ms=1_800_000,
                upload_entry_reselect_seconds=300.0,
                upload_entry_reload_seconds=600.0,
                prefer_drag_drop=True,
                prefer_native_dialog=True,
            )
            pending["tt_done"] = bool(ok)
            pending["tt_thumbnail_done"] = bool(ok)
            self._save_pending(route_key, pending)
            if pending["tt_done"]:
                primary_completed_this_run.append("tiktok")
            else:
                return {
                    "success": False,
                    "new_content_count": 0,
                    "pending": True,
                    "route_key": route_key,
                    "failure_kind": "tiktok_upload_pending",
                    "content_id": content_id,
                }

        fb_complete = (not want_fb) or bool(pending.get("fb_done"))
        tt_complete = (not want_tt) or bool(pending.get("tt_done"))
        primary_complete = fb_complete and tt_complete
        primary_new = False

        # The standalone READY item is consumed only after all enabled PRIMARY
        # destinations have succeeded. This preserves retry safety: if FB succeeds
        # but TikTok fails, the same READY file stays in place for the retry.
        if primary_complete and not pending.get("inventory_primary_marked"):
            marked = await self._mark_primary(
                pool,
                str(item.get("source_folder") or ""),
                int(item.get("part_index") or 1),
            )
            pending["inventory_primary_marked"] = True
            pending["posted_files"] = list(marked.get("moved") or [])
            posted_video = next((str(x) for x in pending["posted_files"] if str(x).lower().endswith(".mp4")), "")
            if posted_video:
                pending["video_path"] = posted_video
                video_path = posted_video
            self._save_pending(route_key, pending)
            primary_new = True
            print(
                f"✅ Episode Splitter PRIMARY complete → READY→POSTED | pool={pool} | "
                f"{item.get('source_folder')} part {item.get('part_index')}"
            )

        if not want_group:
            pending["group_done"] = True
            self._save_pending(route_key, pending)
        elif primary_complete and not pending.get("group_done"):
            post_link = str(pending.get("fb_post_link") or "")
            if not post_link:
                attempt = int(pending.get("permalink_recovery_attempts") or 0) + 1
                pending["permalink_recovery_attempts"] = attempt
                self._save_pending(route_key, pending)
                print(f"🔎 Episode Splitter Reel permalink recovery {attempt}/3")
                from services.browser_service import BrowserService

                post_link = await BrowserService().recover_latest_reel_permalink(
                    str(fb.get("profile") or "Main_FB_Account"),
                    str(fb.get("page_id") or ""),
                    timeout_ms=120000,
                )
                pending["fb_post_link"] = str(post_link or "")
                self._save_pending(route_key, pending)

            if not post_link:
                if int(pending.get("permalink_recovery_attempts") or 0) >= 3:
                    pending["group_done"] = True
                    pending["group_summary"] = {"skipped": True, "reason": "reel_permalink_not_found_after_3"}
                    self._save_pending(route_key, pending)
                else:
                    return {
                        "success": True,
                        "new_content_count": 1 if primary_new else 0,
                        "pending": True,
                        "pending_secondary": True,
                        "maintenance_only": not primary_new,
                        "route_key": route_key,
                        "failure_kind": "group_permalink_pending",
                        "content_id": content_id,
                        "pool": pool,
                        "primary_completed_this_run": primary_completed_this_run,
                    }

            if post_link and not pending.get("group_done"):
                from services.fb_group_service import auto_share_all_accounts

                attempt = int(pending.get("group_share_attempts") or 0) + 1
                pending["group_share_attempts"] = attempt
                self._save_pending(route_key, pending)
                try:
                    summary = await auto_share_all_accounts(
                        post_link,
                        account_names=selected_profiles,
                        share_text=caption,
                        headless=False,
                        delay_between_groups_seconds=20.0,
                        delay_between_accounts_seconds=120.0,
                    )
                    pending["group_summary"] = summary
                    pending["group_done"] = True
                    self._save_pending(route_key, pending)
                except Exception as exc:
                    if attempt >= 3:
                        pending["group_done"] = True
                        pending["group_summary"] = {
                            "skipped": True,
                            "reason": "group_share_failed_after_3",
                            "error": str(exc),
                        }
                        self._save_pending(route_key, pending)
                    else:
                        return {
                            "success": True,
                            "new_content_count": 1 if primary_new else 0,
                            "pending": True,
                            "pending_secondary": True,
                            "maintenance_only": not primary_new,
                            "route_key": route_key,
                            "failure_kind": "group_share_pending",
                            "content_id": content_id,
                            "pool": pool,
                            "primary_completed_this_run": primary_completed_this_run,
                            "secondary_error": str(exc),
                        }

        if primary_complete and bool(pending.get("group_done")):
            group_summary = pending.get("group_summary")
            posted_files = list(pending.get("posted_files") or [])
            final_video_path = str(pending.get("video_path") or video_path)
            self._save_pending(route_key, None)
            return {
                "success": True,
                "new_content_count": 1 if primary_new else 0,
                "maintenance_only": not primary_new,
                "content_id": content_id,
                "route_key": route_key,
                "pool": pool,
                "source_folder": str(item.get("source_folder") or ""),
                "part_index": int(item.get("part_index") or 1),
                "part_count": self._part_total(item),
                "video_path": final_video_path,
                "title": caption,
                "posted_files": posted_files,
                "group_share": group_summary if want_group else "not_configured",
                "primary_completed_this_run": primary_completed_this_run,
                "primary_destinations_completed": [
                    x for x, done in (("facebook", fb_complete), ("tiktok", tt_complete)) if done
                ],
            }

        return {
            "success": False,
            "new_content_count": 0,
            "pending": True,
            "route_key": route_key,
            "failure_kind": "pending_destination_retry",
            "content_id": content_id,
        }
