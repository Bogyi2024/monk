from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

from services.tt_share_export_service import TTShareExportService
from services.tt_route_branding_service import TTRouteBrandingService


class TTLongToShortBridge:
    """Thin TT adapter for the standalone Long-to-Short inventory.

    TT owns scheduling/uploads/retries/completion. Long-to-Short owns analysis,
    selection, TTS, subtitles, framing, rendering and its expensive caches.
    """

    CATEGORY = "long_to_short"
    OUTPUT_ALIASES = {
        "video": "transformative_envo_mm",
        "transformative_envo_mm": "transformative_envo_mm",
        "voiceover_mm_sub": "transformative_envo_mm",
        "original_audio_mm": "original_audio_mm",
        "original_sound_mm_sub": "original_audio_mm",
        "transformative_envo_en": "transformative_envo_en",
        "voiceover_en_sub": "transformative_envo_en",
        "original_audio_en": "original_audio_en",
        "original_sound_en_sub": "original_audio_en",
    }

    def __init__(self, settings_service, project_root: str | Path = "."):
        self.settings = settings_service
        self.root = Path(project_root).resolve()
        env = str(os.getenv("TT_LONG_TO_SHORT_DIR") or "").strip()
        self.lts_root = Path(env).expanduser().resolve() if env else (self.root.parent / "long_to_short").resolve()
        self.runner = self.lts_root / "tt_bridge_runner.py"
        self.pending_dir = self.root / "state" / "tt_long_to_short_pending"
        self.pending_dir.mkdir(parents=True, exist_ok=True)
        self.share_export = TTShareExportService(settings_service, self.root)
        self.branding = TTRouteBrandingService(self.root)

    @classmethod
    def capability(cls, project_root: str | Path = ".") -> dict[str, Any]:
        root = Path(project_root).resolve()
        env = str(os.getenv("TT_LONG_TO_SHORT_DIR") or "").strip()
        lts = Path(env).expanduser().resolve() if env else (root.parent / "long_to_short").resolve()
        runner = lts / "tt_bridge_runner.py"
        main = lts / "run_long_to_short_test.py"
        live = runner.exists() and main.exists()
        return {"live": live, "label": "LIVE — READY INVENTORY" if live else f"Missing standalone bridge: {runner}"}

    def _pending_path(self, route_key: str) -> Path:
        safe = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in str(route_key or "default"))
        return self.pending_dir / f"{safe}.json"

    def _load_pending(self, route_key: str) -> dict[str, Any] | None:
        p = self._pending_path(route_key)
        try:
            data = json.loads(p.read_text(encoding="utf-8")) if p.exists() else None
            return data if isinstance(data, dict) else None
        except Exception:
            return None

    def _save_pending(self, route_key: str, data: dict[str, Any] | None) -> None:
        p = self._pending_path(route_key)
        if data is None:
            if p.exists(): p.unlink()
            return
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, p)

    def _invoke(self, args: list[str]) -> dict[str, Any]:
        if not self.runner.exists():
            raise FileNotFoundError(f"Standalone Long-to-Short bridge runner missing: {self.runner}")
        fd, name = tempfile.mkstemp(prefix="tt_lts_", suffix=".json", dir=str(self.pending_dir))
        os.close(fd); result_path = Path(name)
        try:
            cmd = [sys.executable, '-u', '-X', 'utf8', str(self.runner), *args, "--json-out", str(result_path)]
            proc = subprocess.run(cmd, cwd=str(self.lts_root), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace')
            output = str(getattr(proc, 'stdout', '') or '')
            if output:
                print(output, end='', flush=True)
            if not result_path.exists() or not result_path.stat().st_size:
                raise RuntimeError(f"Long-to-Short bridge returned no JSON (exit={proc.returncode}): {output[-3000:]}")
            try:
                data = json.loads(result_path.read_text(encoding='utf-8-sig'))
                if not isinstance(data, dict):
                    raise ValueError('result must be an object')
            except ValueError as exc:
                raise RuntimeError(f'Invalid Long-to-Short bridge JSON (exit={proc.returncode}): {output[-3000:]}') from exc
            if proc.returncode != 0 or not bool(data.get("ok")):
                raise RuntimeError(str(data.get("error") or f"Long-to-Short bridge exit={proc.returncode}"))
            return data
        finally:
            try: result_path.unlink(missing_ok=True)
            except OSError: pass

    @classmethod
    def _output_mode(cls, route_cfg: dict[str, Any]) -> str:
        raw = str(route_cfg.get("output_type") or "transformative_envo_mm").strip().lower()
        mode = cls.OUTPUT_ALIASES.get(raw, raw)
        if mode not in {"transformative_envo_mm", "original_audio_mm", "transformative_envo_en", "original_audio_en"}:
            raise ValueError(f"Unsupported Long-to-Short output mode: {raw}")
        return mode

    @staticmethod
    def _caption(item: dict[str, Any], platform: str = "tt") -> str:
        """Use cached AI social copy from the standalone inventory.

        A READY item must have been produced with matching AI copy. Refuse a
        generic/default fallback so a video can never be posted with unrelated text.
        """
        key = "fb_caption" if platform == "fb" else "tt_caption"
        base = str(item.get(key) or "").strip()
        tags: list[str] = []
        for raw in item.get("hashtags") or []:
            tag = str(raw or "").strip().replace(" ", "")
            if tag:
                tags.append(tag if tag.startswith("#") else "#" + tag)
        if not base or not tags:
            raise RuntimeError("Long-to-Short item is missing locked AI social copy; refusing upload")
        return (base + ("\n\n" + " ".join(tags[:6]) if tags else "")).strip()

    @staticmethod
    def _tt_content_id(base_content_id: str, route_key: str) -> str:
        # Same candidate can intentionally feed two different output routes. TT's
        # durable ledger is category-wide, so route identity must be part of token.
        return f"lts:{base_content_id}:{route_key}"

    def _peek(self, date: str, group: str, route_key: str, output_mode: str) -> dict[str, Any] | None:
        result = self._invoke([
            "peek", "--date", date, "--group", group, "--route-key", route_key, "--output-mode", output_mode,
        ])
        return result.get("item") if result.get("found") else None

    def _mark_primary(self, date: str, group: str, route_key: str, base_content_id: str, output_mode: str) -> None:
        self._invoke([
            "mark-primary", "--date", date, "--group", group, "--route-key", route_key,
            "--content-id", base_content_id, "--output-mode", output_mode,
        ])

    async def run_once(self, route_key: str = "default") -> dict[str, Any]:
        resolved = self.settings.resolve_route(self.CATEGORY, route_key)
        cat = resolved["category"]; route_cfg = resolved.get("route") or {}
        if not cat.get("enabled", True) or not route_cfg.get("enabled", True):
            raise RuntimeError(f"Long-to-Short route disabled: {route_key}")
        output_mode = self._output_mode(route_cfg)
        content_category = str(route_cfg.get("lts_category") or route_cfg.get("content_type") or "motivation").strip().lower().replace("-", "_") or "motivation"
        reuse_group = str(route_cfg.get("content_group") or "main").strip() or "main"
        group = f"{content_category}::{reuse_group}"
        today = datetime.now().astimezone().date().isoformat()

        pending = self._load_pending(route_key)
        if not pending:
            item = await asyncio.to_thread(self._peek, today, group, route_key, output_mode)
            if not item:
                return {
                    "success": False, "new_content_count": 0, "no_work": True,
                    "failure_kind": "no_new_content", "route_key": route_key,
                    "message": f"No prepared Long-to-Short inventory for {today}/{content_category}/{reuse_group}/{output_mode}",
                }
            video_path = str((item.get("outputs") or {}).get(output_mode) or "")
            if not video_path or not Path(video_path).exists():
                raise FileNotFoundError(f"Prepared Long-to-Short output missing: {video_path}")
            pending = {
                "route_key": route_key, "date": today, "group": group, "content_category": content_category, "reuse_group": reuse_group, "output_mode": output_mode,
                "base_content_id": str(item.get("content_id") or ""), "item": item, "video_path": video_path,
                "fb_done": False, "tt_done": False, "group_done": False, "fb_post_link": "",
                "inventory_primary_marked": False, "group_summary": None,
            }
            self._save_pending(route_key, pending)
            print(f"📦 Long-to-Short READY claim → {content_category}/{reuse_group} | {route_key} | {output_mode} | {Path(video_path).name}")
        else:
            output_mode = str(pending.get("output_mode") or output_mode)
            group = str(pending.get("group") or group)
            print(f"♻️ Long-to-Short pending retry → route={route_key} | content={pending.get('base_content_id','')}")

        item = pending.get("item") or {}
        video_path = str(pending.get("video_path") or "")
        if not video_path or not Path(video_path).exists():
            raise FileNotFoundError(f"Long-to-Short pending video missing: {video_path}")
        fb_caption = self._caption(item, "fb")
        tt_caption = self._caption(item, "tt")
        fb = resolved.get("facebook"); tt = resolved.get("tiktok")
        want_fb = bool(fb and fb.get("enabled", True)); want_tt = bool(tt and tt.get("enabled", True))
        if not want_fb and not want_tt:
            raise RuntimeError(f"Long-to-Short route {route_key} has no enabled Facebook/TikTok destination")
        selected_profiles = self.share_export.sync_route(self.CATEGORY, route_key)
        want_group = bool(want_fb and route_cfg.get("share_enabled", True) and selected_profiles)
        primary_completed_this_run: list[str] = []

        if want_fb and not pending.get("fb_done"):
            from services.browser_service import BrowserService
            branded_video = await asyncio.to_thread(
                self.branding.brand_video, video_path, self.CATEGORY, route_key,
                route_cfg.get("branding") or {}, "facebook_reel",
            )
            summary = await BrowserService().upload_reel_stealth(
                str(fb.get("profile") or "Main_FB_Account"), str(fb.get("page_id") or ""), fb_caption, branded_video,
                capture_permalink=want_group,
            )
            pending["fb_done"] = bool((summary or {}).get("success"))
            if (summary or {}).get("post_link"): pending["fb_post_link"] = str(summary.get("post_link"))
            self._save_pending(route_key, pending)
            if pending["fb_done"]: primary_completed_this_run.append("facebook")
            else:
                return {"success": False, "new_content_count": 0, "pending": True, "route_key": route_key, "failure_kind": "facebook_upload_pending"}

        if want_tt and not pending.get("tt_done"):
            from services.tt_service import upload_to_tiktok
            branded_video = await asyncio.to_thread(
                self.branding.brand_video, video_path, self.CATEGORY, route_key,
                route_cfg.get("branding") or {}, "tiktok_reel",
            )
            ok = await upload_to_tiktok(
                profile_folder_name=str(tt.get("profile") or ""), video_path=branded_video,
                caption_text=tt_caption, headless=False,
            )
            pending["tt_done"] = bool(ok); self._save_pending(route_key, pending)
            if pending["tt_done"]: primary_completed_this_run.append("tiktok")
            else:
                return {"success": False, "new_content_count": 0, "pending": True, "route_key": route_key, "failure_kind": "tiktok_upload_pending"}

        fb_complete = (not want_fb) or bool(pending.get("fb_done"))
        tt_complete = (not want_tt) or bool(pending.get("tt_done"))
        primary_complete = fb_complete and tt_complete
        base_content_id = str(pending.get("base_content_id") or "")
        content_id = self._tt_content_id(base_content_id, route_key)

        # Mark standalone inventory immediately after PRIMARY completion. Group
        # sharing is secondary and must never make the same primary item reappear.
        if primary_complete and not pending.get("inventory_primary_marked"):
            await asyncio.to_thread(
                self._mark_primary, str(pending.get("date") or today), group, route_key, base_content_id, output_mode,
            )
            pending["inventory_primary_marked"] = True; self._save_pending(route_key, pending)

        if not want_group:
            pending["group_done"] = True; self._save_pending(route_key, pending)
        elif not pending.get("group_done"):
            post_link = str(pending.get("fb_post_link") or "")
            if not post_link:
                link_try = int(pending.get("permalink_recovery_attempts") or 0) + 1
                pending["permalink_recovery_attempts"] = link_try; self._save_pending(route_key, pending)
                print(f"🔎 Long-to-Short Reel permalink recovery {link_try}/3")
                from services.browser_service import BrowserService
                post_link = await BrowserService().recover_latest_reel_permalink(
                    str(fb.get("profile") or "Main_FB_Account"), str(fb.get("page_id") or ""), timeout_ms=120000,
                )
                pending["fb_post_link"] = str(post_link or ""); self._save_pending(route_key, pending)
            if not post_link:
                if int(pending.get("permalink_recovery_attempts") or 0) >= 3:
                    pending["group_done"] = True
                    pending["group_summary"] = {"skipped": True, "reason": "reel_permalink_not_found_after_3"}
                    self._save_pending(route_key, pending)
                elif primary_complete:
                    return {
                        "success": True, "new_content_count": 1, "pending": True, "pending_secondary": True,
                        "route_key": route_key, "failure_kind": "group_permalink_pending", "content_id": content_id,
                        "source_content_id": base_content_id, "primary_completed_this_run": primary_completed_this_run,
                        "primary_destinations_completed": [x for x, done in (("facebook", fb_complete), ("tiktok", tt_complete)) if done],
                    }
            if post_link and not pending.get("group_done"):
                from services.fb_group_service import auto_share_all_accounts
                group_try = int(pending.get("group_share_attempts") or 0) + 1
                pending["group_share_attempts"] = group_try; self._save_pending(route_key, pending)
                try:
                    summary = await auto_share_all_accounts(
                        post_link, account_names=selected_profiles, share_text=fb_caption, headless=False,
                        delay_between_groups_seconds=20.0, delay_between_accounts_seconds=120.0,
                    )
                    pending["group_summary"] = summary; pending["group_done"] = True; self._save_pending(route_key, pending)
                except Exception as exc:
                    if group_try >= 3:
                        pending["group_done"] = True
                        pending["group_summary"] = {"skipped": True, "reason": "group_share_failed_after_3", "error": str(exc)}
                        self._save_pending(route_key, pending)
                    elif primary_complete:
                        return {
                            "success": True, "new_content_count": 1, "pending": True, "pending_secondary": True,
                            "route_key": route_key, "failure_kind": "group_share_pending", "content_id": content_id,
                            "source_content_id": base_content_id, "primary_completed_this_run": primary_completed_this_run,
                            "primary_destinations_completed": [x for x, done in (("facebook", fb_complete), ("tiktok", tt_complete)) if done],
                            "secondary_error": str(exc),
                        }
                    else:
                        raise

        if primary_complete and bool(pending.get("group_done")):
            group_summary = pending.get("group_summary")
            maintenance_only = not bool(primary_completed_this_run)
            self._save_pending(route_key, None)
            return {
                "success": True, "new_content_count": 1, "content_id": content_id,
                "source_content_id": base_content_id, "route_key": route_key, "content_category": str(pending.get("content_category") or content_category), "output_mode": output_mode,
                "video_path": video_path, "title": str(item.get("title") or "Long-to-Short"),
                "group_share": group_summary if want_group else "not_configured",
                "primary_completed_this_run": primary_completed_this_run,
                "primary_destinations_completed": [x for x, done in (("facebook", fb_complete), ("tiktok", tt_complete)) if done],
                "maintenance_only": maintenance_only,
            }
        return {"success": False, "new_content_count": 0, "pending": True, "route_key": route_key, "failure_kind": "pending_destination_retry"}
