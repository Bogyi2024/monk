"""Studio99 Desktop: PostingListBridge — the TT master's Long-to-Short posting code, fed by the Posting list
(posting_list.py). Not part of the master: tools/sync_engine.py never overwrites this folder."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from bridges.long_to_short_bridge import TTLongToShortBridge
from studio99.posting_list import (kind_of, ledger_path, list_path, load, load_ledger, locked, next_item,
                                   posted_before, record_posted, save, wanted_routes)


# ---------------------------------------------------------------------------------------------- the bridge
class PostingListBridge(TTLongToShortBridge):
    def __init__(self, category_key: str, settings_service, project_root: str | Path = "."):
        super().__init__(settings_service, project_root)
        self.CATEGORY = category_key
        self.list_file = list_path(self.root)
        self.pending_dir = self.root / "state" / "studio99_posting_pending" / category_key
        self.pending_dir.mkdir(parents=True, exist_ok=True)

    @classmethod
    def capability(cls, project_root: str | Path = ".") -> dict[str, Any]:
        return {"live": True, "label": "LIVE — POSTING LIST"}

    @classmethod
    def _output_mode(cls, route_cfg: dict[str, Any]) -> str:
        return "video"

    @staticmethod
    def _caption(item: dict[str, Any], platform: str = "tt") -> str:
        caption = str(item.get("caption") or "").strip()
        return caption or Path(str(item.get("video") or "video")).stem

    def _enabled_routes(self) -> list[str]:
        routes = self.settings.category_routes(self.CATEGORY)
        return [k for k, r in routes.items() if isinstance(r, dict) and r.get("enabled", True)]

    def _peek(self, date: str, group: str, route_key: str, output_mode: str) -> dict[str, Any] | None:
        now = datetime.now().astimezone()
        with locked(self.list_file):
            items = load(self.list_file)
            changed = False
            ledger = load_ledger(ledger_path(self.root))
            while True:
                item = next_item(items, self.CATEGORY, route_key, now, kind="video")
                if item is None:
                    break
                if posted_before(ledger, item, self.CATEGORY, route_key):     # never the same video twice on a Page
                    item.setdefault("failed", {})[route_key] = "already posted"
                    changed = True
                    print(f"⏭️ Posting list: already posted on {route_key}, skipped → {item.get('video')}")
                    continue
                if Path(str(item.get("video") or "")).is_file():
                    break
                item.setdefault("failed", {})[route_key] = "video file missing"      # deleted / moved by the user
                changed = True
                print(f"⚠️ Posting list: video missing, skipped → {item.get('video')}")
            if changed:
                save(self.list_file, items)
        if item is None:
            return None
        print(f"📮 Posting list → {self.CATEGORY}/{route_key}: {Path(item['video']).name}")
        return {"content_id": str(item["id"]), "outputs": {output_mode: str(item["video"])},
                "caption": item.get("caption") or "", "video": item["video"], "title": item.get("caption") or ""}

    @staticmethod
    def _tt_content_id(base_content_id: str, route_key: str) -> str:
        return f"s99:{base_content_id}:{route_key}"

    def _mark_primary(self, date: str, group: str, route_key: str, base_content_id: str, output_mode: str) -> None:
        with locked(self.list_file):
            items = load(self.list_file)
            for item in items:
                if str(item.get("id")) != base_content_id:
                    continue
                item.setdefault("done", {})[route_key] = datetime.now().strftime("%Y-%m-%d %H:%M")
                record_posted(ledger_path(self.root), item, self.CATEGORY, route_key)
                left = [r for r in wanted_routes(item, self._enabled_routes())
                        if r not in item["done"] and r not in (item.get("failed") or {})]
                item["status"] = "posting" if left else "posted"
                if not left:
                    item["posted"] = item["done"][route_key]
            save(self.list_file, items)

    async def run_once(self, route_key: str = "default") -> dict[str, Any]:
        if not self._load_pending(route_key):              # a Reel half way through always goes on first
            item = self._next_photo(route_key)
            if item is not None:
                result = await self._post_photo(item, route_key)
                if result.get("success") and not result.get("pending"):
                    self.delete_posted()
                return result
        result = await super().run_once(route_key)
        if result.get("success") and not result.get("pending"):
            self.delete_posted()
        return result

    # ------------------------------------------------------------------ photo posts (Novel parts, Movie Review posts)
    def _fail(self, item_id: str, route_key: str, why: str) -> None:
        with locked(self.list_file):
            items = load(self.list_file)
            for item in items:
                if str(item.get("id")) == item_id:
                    item.setdefault("failed", {})[route_key] = why
            save(self.list_file, items)
        print(f"⚠️ Posting list: {why} → skipped for {route_key}")

    def _next_photo(self, route_key: str) -> dict[str, Any] | None:
        """The route's next item when it is a photo post (a video comes first when it is older: then None)."""
        now = datetime.now().astimezone()
        while True:
            with locked(self.list_file):
                item = next_item(load(self.list_file), self.CATEGORY, route_key, now)
            if item is None or kind_of(item) != "photo":
                return None
            images = [str(x) for x in item.get("images") or [] if str(x)]
            if not images or not all(Path(x).is_file() for x in images):
                self._fail(str(item["id"]), route_key, "picture file missing")
                continue
            resolved = self.settings.resolve_route(self.CATEGORY, route_key)
            fb = resolved.get("facebook") or {}
            if not fb or not fb.get("enabled", True) or not str(fb.get("page_id") or "").strip():
                self._fail(str(item["id"]), route_key, "photo post needs a Facebook Page")
                continue
            return item

    async def _post_photo(self, item: dict[str, Any], route_key: str) -> dict[str, Any]:
        import asyncio
        from services.story_carousel_upload_service import upload_facebook_story_carousel
        resolved = self.settings.resolve_route(self.CATEGORY, route_key)
        route, fb = resolved.get("route") or {}, resolved.get("facebook") or {}
        images = await asyncio.to_thread(self.branding.brand_images, list(item.get("images") or []), self.CATEGORY,
                                         route_key, route.get("branding") or {}, "facebook_post")
        caption = str(item.get("text") or item.get("caption") or "").strip()
        selected = self.share_export.sync_route(self.CATEGORY, route_key)
        want_group = bool(route.get("share_enabled", True) and selected)
        print(f"📮 Posting list → {self.CATEGORY}/{route_key}: photo post {item.get('caption') or item['id']}")
        detail = await upload_facebook_story_carousel(
            images, caption, profile_name=str(fb.get("profile") or "Main_FB_Account"),
            page_id=str(fb.get("page_id") or ""), headless=False, return_detail=True, capture_permalink=want_group)
        if not (detail or {}).get("success"):
            return {"success": False, "new_content_count": 0, "pending": True, "route_key": route_key,
                    "failure_kind": "facebook_upload_pending", "content_id": str(item["id"]),
                    "error": str((detail or {}).get("error") or "Facebook photo post failed")}
        # the post is noted before the optional group share, so it is never posted twice
        self._mark_primary(datetime.now().date().isoformat(), "", route_key, str(item["id"]), "photo")
        post_link = str((detail or {}).get("post_link") or "")
        if want_group and post_link:
            try:
                from services.fb_group_service import auto_share_all_accounts
                await auto_share_all_accounts(post_link, account_names=selected, share_text=caption, headless=False,
                                              delay_between_groups_seconds=20.0, delay_between_accounts_seconds=120.0)
            except Exception as exc:  # noqa: BLE001 - the post itself is done
                print(f"⏭️ Group share skipped, the post is done: {exc}")
        return {"success": True, "new_content_count": 1, "content_id": str(item["id"]), "route_key": route_key,
                "post_link": post_link}

    def _files_in_use(self) -> set[str]:
        """Videos a route is still sharing to groups (its pending file names the video)."""
        used = set()
        for pending in (self.root / "state" / "studio99_posting_pending").glob("*/*.json"):
            try:
                used.add(str(Path(json.loads(pending.read_text(encoding="utf-8")).get("video_path") or "")))
            except (OSError, ValueError):
                pass
        return used

    def delete_posted(self) -> None:
        """'Delete after posting': a video posted on all its routes (group shares finished) is deleted."""
        in_use = self._files_in_use()
        with locked(self.list_file):
            items = load(self.list_file)
            changed = False
            for item in items:
                video = str(item.get("video") or "")
                if (item.get("status") != "posted" or not item.get("delete_after_post") or item.get("deleted")
                        or str(Path(video)) in in_use):
                    continue
                try:
                    Path(video).unlink(missing_ok=True)
                    item["deleted"] = True
                    changed = True
                    print(f"🧹 Posted everywhere — video deleted: {video}")
                except OSError as exc:
                    print(f"⚠️ Could not delete posted video: {exc}")
            if changed:
                save(self.list_file, items)
