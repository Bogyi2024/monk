"""Studio99 Desktop Posting list: the list file, its categories and which item a route posts next.

Used by posting_bridge.py (engine) and imported by the master's category registry, so it imports nothing heavy.

Overview — post the videos the app's tools made (the Posting list) with the TT master's own posting code.

Each tool has a posting category = one card in the app's Auto Posting page (user, 2026-10-23: "the same cards as
outside: Recap, Splitter, Dubbing, Subtitle …; every tool has Send to Auto Posting"). A category's routes are the master's
routes — one Facebook Page + TikTok account + group-share accounts + daily target + page timing — so the master's
scheduler decides WHEN; this bridge only decides WHAT: the oldest list item meant for that route.

Uploading, TikTok, group sharing, branding and the retry/pending rules are the master's Long-to-Short bridge
(bridges/long_to_short_bridge.py, subclassed): its inventory calls (_peek/_mark_primary) read and mark the list.

This folder is not part of the master: tools/sync_engine.py never overwrites it."""
from __future__ import annotations

import json
import os
import time
import uuid
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any


PROCESSOR_KIND = "studio99_posting"
CATEGORIES = {                                   # card order in the app
    "post_recap": ("Recap", ("recap", "channel")),
    "post_splitter": ("Splitter", ("splitter",)),
    "post_dubbing": ("Dubbing", ("dubbing",)),
    "post_subtitle": ("Subtitle", ("subtitle",)),
    "post_storytelling": ("Original → Recap", ("storytelling",)),
    "post_story": ("Story Motion", ("story_motion",)),
    "post_lts": ("Long to Short", ("lts",)),
    "post_novel": ("Novel", ("novel",)),
    "post_review": ("Movie Review", ("movie_review",)),
}
# Item kinds: "video" (default; Facebook Reel + TikTok, the master's Long-to-Short upload) and "photo" (pictures +
# a long text as one Facebook photo post, the master's Novel / Movie Review post upload; Facebook only).
KINDS = ("video", "photo")
LIST_NAME = "studio99_posting_list.json"
LEDGER_NAME = "studio99_posted.json"           # every post ever made: never posted twice, kept when an item is removed


def list_path(root: str | Path = ".") -> Path:
    env = str(os.getenv("STUDIO99_POSTING_LIST") or "").strip()
    return Path(env) if env else Path(root).resolve() / "state" / LIST_NAME


def ledger_path(root: str | Path = ".") -> Path:
    return list_path(root).with_name(LEDGER_NAME)


def item_key(item: dict[str, Any]) -> str:
    """What makes two list items the same video: the source link (a channel video) or else the video file."""
    source = str(item.get("source") or "").strip()
    if source.startswith("http"):
        return source
    video = str(item.get("video") or "").strip()
    try:
        return str(Path(video).resolve()).lower()
    except OSError:
        return video.lower()


def item_keys(item: dict[str, Any]) -> set[str]:
    """Every name one video has: its source link AND its video file. 2026-10-31: a video posted under its file
    (sent by hand) came back under its YouTube link (Recap Auto) and the list took it as new."""
    keys = {item_key(item)}
    video = str(item.get("video") or "").strip()
    if video:
        keys.add(item_key({"video": video}))
    keys.discard("")
    return keys


def posted_before(ledger: dict[str, Any], item: dict[str, Any], category: str, route_key: str | None = None) -> bool:
    """Did this card already post this video (on that route, when one is given), under any of its names?"""
    keys = item_keys(item)
    for key, entry in ledger.items():
        if not isinstance(entry, dict) or entry.get("category") != category:
            continue
        names = {key} | (item_keys({"video": entry["video"]}) if entry.get("video") else set())
        routes = entry.get("routes") or {}
        if names & keys and routes and (route_key is None or route_key in routes):
            return True
    return False


def load_ledger(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def record_posted(path: Path, item: dict[str, Any], category: str, route_key: str) -> None:
    """The engine's note of a post (call while holding the list lock): {key: {category, video, caption, routes}}."""
    ledger = load_ledger(path)
    entry = ledger.setdefault(item_key(item), {"category": category, "video": str(item.get("video") or ""),
                                               "caption": str(item.get("caption") or ""), "routes": {}})
    entry.setdefault("routes", {})[route_key] = datetime.now().strftime("%Y-%m-%d %H:%M")
    tmp = path.with_name(f"{path.name}.{uuid.uuid4().hex[:6]}.tmp")
    tmp.write_text(json.dumps(ledger, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, path)


def category_for_origin(origin: str) -> str:
    """Every tool has its own card (user, 2026-10-23: no "Other videos" card — there is no such tool)."""
    for key, (_label, origins) in CATEGORIES.items():
        if origin in origins:
            return key
    raise ValueError(f"No Auto Posting card for: {origin}")


# ---------------------------------------------------------------------------------------------- the list file
@contextmanager
def locked(path: Path, timeout: float = 20.0):
    """A lock file shared with the app (app/posting_queue.py): both read-modify-write the same list."""
    lock = path.with_suffix(".lock")
    path.parent.mkdir(parents=True, exist_ok=True)
    end = time.time() + timeout
    while True:
        try:
            fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(fd)
            break
        except FileExistsError:
            try:
                if time.time() - lock.stat().st_mtime > 60:      # left by a crashed process
                    lock.unlink(missing_ok=True)
                    continue
            except OSError:
                pass
            if time.time() > end:
                raise TimeoutError(f"Posting list is busy: {lock}")
            time.sleep(0.1)
    try:
        yield
    finally:
        lock.unlink(missing_ok=True)


def load(path: Path) -> list[dict[str, Any]]:
    try:
        return list(json.loads(path.read_text(encoding="utf-8")).get("items") or [])
    except (OSError, ValueError):
        return []


def save(path: Path, items: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.{uuid.uuid4().hex[:6]}.tmp")
    tmp.write_text(json.dumps({"items": items}, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _due(item: dict[str, Any], now: datetime) -> bool:
    raw = str(item.get("post_at") or "").strip()
    if not raw:
        return True
    try:
        return datetime.strptime(raw, "%Y-%m-%d %H:%M") <= now.replace(tzinfo=None)
    except ValueError:
        return True


def wanted_routes(item: dict[str, Any], enabled_routes: list[str]) -> list[str]:
    """The routes an item goes to: the ones picked for it, or every enabled route of its category."""
    targets = [str(t) for t in item.get("targets") or [] if str(t)]
    return targets or list(enabled_routes)


def kind_of(item: dict[str, Any]) -> str:
    return str(item.get("kind") or "video")


def next_item(items: list[dict[str, Any]], category: str, route_key: str, now: datetime,
              kind: str | None = None) -> dict[str, Any] | None:
    """The oldest item this route still has to post (kind: only that kind)."""
    for item in items:
        if item.get("category") != category or item.get("status") in ("removed", "posted"):
            continue
        if kind and kind_of(item) != kind:
            continue
        targets = [str(t) for t in item.get("targets") or [] if str(t)]
        if targets and route_key not in targets:
            continue
        if route_key in (item.get("done") or {}) or route_key in (item.get("failed") or {}):
            continue
        if _due(item, now):
            return item
    return None


def _default_route(key: str, label: str) -> dict[str, Any]:
    return {
        "label": f"{label} — Page 1", "enabled": False, "content_type": key, "output_type": "video", "language": "mm",
        "genre_mode": "", "fixed_genre": "", "content_group": "main", "daily_limit": 3,
        "facebook_page": "", "tiktok_account": "", "fb_share_accounts": [], "share_enabled": False,
        "sources": [], "source_urls": [],
        "schedule_policy": {"earliest_start": "09:00", "latest_finish": "23:00", "page_gap_minutes": 120,
                            "route_spacing_minutes": 30, "estimated_runtime_minutes": 10, "priority": 50},
    }


def register(registry: dict[str, dict[str, Any]]) -> None:
    """Add the posting categories to the master's content-category registry (OFF until a route has a page).
    STUDIO99_POSTING_ONLY=1: the master's own content categories (news, movie review) are left out."""
    if os.getenv("STUDIO99_POSTING_ONLY") == "1":
        registry.clear()
    for key, (label, _origins) in CATEGORIES.items():
        registry[key] = {
            "display_name": label,
            "processor": key,
            "processor_kind": PROCESSOR_KIND,
            "default_output": "video",
            "supported_outputs": ["video"],
            "supported_languages": ["mm", "en"],
            "supports_sources": False,
            "supports_automatic_discovery": False,
            "minimum_configured_sources": 0,
            "ensure_category": True,
            "category_defaults": {
                "label": label, "enabled": False, "daily_limit": 3, "production_mode": "fixed_daily",
                "facebook_page": "", "tiktok_account": "", "fb_share_account": "", "fb_share_accounts": [],
                "share_enabled": False,
                "schedule_policy": {"earliest_start": "09:00", "latest_finish": "23:00", "preferred_gap_minutes": 120,
                                    "minimum_gap_minutes": 60, "estimated_runtime_minutes": 10, "priority": 50,
                                    "prefer_preferred_windows": False, "preferred_windows_only": False,
                                    "preferred_windows": []},
                "routes": {"default": _default_route(key, label)},
            },
        }
