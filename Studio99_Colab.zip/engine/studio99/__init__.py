"""Studio99 Desktop's own part of the posting engine (never overwritten by tools/sync_engine.py).

The engine lives only as long as the Studio99 app that started it (2026-10-30: an engine from an app that had been
closed kept running for hours, held port 8799 and answered for a newer one). app/engine_runner.py passes its process
id as STUDIO99_PARENT_PID; when that process is gone the engine exits."""
from __future__ import annotations

import os
import threading
import time


def _watch_parent(pid: int, every: float = 15.0) -> None:
    import psutil
    while True:
        time.sleep(every)
        try:
            alive = psutil.pid_exists(pid) and psutil.Process(pid).status() != psutil.STATUS_ZOMBIE
        except Exception:  # noqa: BLE001 - when unsure, keep running
            alive = True
        if not alive:
            print("🛑 Studio99 app closed — the posting engine stops too.", flush=True)
            os._exit(0)


def _start_watch() -> None:
    try:
        pid = int(os.environ.get("STUDIO99_PARENT_PID") or 0)
    except ValueError:
        pid = 0
    if pid > 0 and pid != os.getpid():
        threading.Thread(target=_watch_parent, args=(pid,), name="studio99:parent-watch", daemon=True).start()


_start_watch()
