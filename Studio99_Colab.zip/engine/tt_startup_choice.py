from __future__ import annotations

from services.tt_settings_service import TTSettingsService


def resolve_startup_choice(project_root: str = ".") -> str:
    """
    Return one of:
      "saved"
      "manage"
      "full_setup"
      "cancel"

    Future recap_auto/master scheduler can import this function.
    """
    s = TTSettingsService(project_root)
    mode = str(s.scheduler().get("startup_mode") or "ask")

    if mode == "saved":
        return "saved"
    if mode == "full_setup":
        return "full_setup"

    print("\nSaved TT setup found ✅\n")
    print("1. Start with saved settings")
    print("2. Review / edit settings")
    print("3. Full setup wizard")
    print("4. Cancel")

    choice = input("> ").strip()
    return {
        "1": "saved",
        "2": "manage",
        "3": "full_setup",
        "4": "cancel",
    }.get(choice, "cancel")


if __name__ == "__main__":
    print("Startup choice =", resolve_startup_choice("."))
