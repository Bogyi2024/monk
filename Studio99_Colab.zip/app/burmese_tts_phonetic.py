"""Burmese TTS-only pronunciation & natural phrasing (အသံထွက် + အဖြတ်အတောက်) normalizer.

Applied ONLY to text sent into TTS engines when `tts_pronunciation_fix` is enabled.
Subtitles (SRT / burned-in PNG) and script review text remain completely untouched.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

# High-confidence Burmese spelling -> spoken phonetic reading pairs (longest-first at runtime)
DEFAULT_PRONUNCIATION_MAP: dict[str, str] = {
    "လက်ဖက်ရည်": "လဖက်ရည်",
    "လက်ဖက်": "လဖက်",
    "ခုတင်": "ကုတင်",
    "ပုစွန်": "ပဇွန်",
    "ခုနစ်": "ခွန်နစ်",
    "သင်္ဘော": "သင်ဘော",
    "သင်္ကြန်": "သင်ကြန်",
    "သင်္ကန်း": "သင်ကန်း",
    "သင်္ချိုင်း": "သင်ချိုင်း",
    "မင်္ဂလာ": "မင်ဂလာ",
    "အင်္ဂလိပ်": "အင်ဂလိပ်",
    "အင်္ကျီ": "အင်းကျီ",
    "စင်္ကာပူ": "စင်ကာပူ",
    "တက္ကသိုလ်": "တက်ကသိုလ်",
    "မန္တလေး": "မန်တလေး",
    "စက္ကန့်": "စက်ကန့်",
    "စက္ကူ": "စက်ကူ",
    "ပစ္စည်း": "ပစ်စည်း",
    "ပြဿနာ": "ပြတ်သနာ",
    "သစ္စာ": "သစ်စာ",
    "မေတ္တာ": "မစ်တာ",
    "ကိစ္စ": "ကိတ်စ",
    "ဥက္ကဋ္ဌ": "အုတ်ကထ",
    "ဗုဒ္ဓ": "ဗုတ်ဒ",
    "ကမ္ဘာ": "ကဘာ",
    "ဘဏ်": "ဘန်",
    "ပုဂ္ဂိုလ်": "ပုတ်ကို",
    "ဝိညာဉ်": "ဝိညင်",
    "အဓိပ္ပာယ်": "အဒိတ်ပယ်",
    "တိရစ္ဆာန်": "တိရစ်ဆန်",
    "အန္တရာယ်": "အန်တရာယ်",
    "သုသာန်": "သုသန်",
}

# Burmese clause connectors where a subtle pause (၊ ) improves TTS rhythm on longer sentences
_PAUSE_AFTER_CONNECTORS = (
    "ဘာလို့လဲဆိုတော့",
    "အဲဒါကြောင့်",
    "ဒါကြောင့်",
    "ဒါပေမဲ့",
    "တကယ်တော့",
    "အမှန်တော့",
    "ပြီးတော့",
    "ပြီးနောက်",
    "လိုက်ပြီး",
    "နေရင်း",
    "တဲ့အခါ",
    "တဲ့အတွက်",
    "နေတုန်း",
    "ဆိုပေမဲ့",
)

_CUSTOM_CACHE: tuple[float, dict[str, str]] | None = None


def _load_custom_map() -> dict[str, str]:
    """Optional user overrides from STUDIO99_COLAB_DATA/tts_pronunciation_dict.json or E:\Studio99\tts_pronunciation_dict.json."""
    global _CUSTOM_CACHE
    candidates = [
        Path(os.environ.get("STUDIO99_COLAB_DATA", "/content/Studio99Data")) / "tts_pronunciation_dict.json",
        Path(__file__).resolve().parent.parent / "tts_pronunciation_dict.json",
    ]
    for path in candidates:
        if path.is_file():
            try:
                mtime = path.stat().st_mtime
                if _CUSTOM_CACHE and _CUSTOM_CACHE[0] == mtime:
                    return _CUSTOM_CACHE[1]
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    clean = {str(k).strip(): str(v).strip() for k, v in data.items() if str(k).strip() and str(v).strip()}
                    _CUSTOM_CACHE = (mtime, clean)
                    return clean
            except Exception:
                pass
    return {}


def _apply_phrasing(text: str) -> str:
    """Add natural Burmese pauses (၊ ) in long unbroken clauses so TTS breathes smoothly."""
    s = " ".join(str(text or "").split()).strip()
    if not s:
        return s

    # Ensure clean spacing after Burmese sentence/clause marks
    s = re.sub(r"([။၊])(?=\S)", r"\1 ", s)

    # Process each sentence independently
    sents = [x.strip() for x in re.split(r"(?<=။)\s+", s) if x.strip()]
    out_sents: list[str] = []
    for sent in sents:
        # Only add phrasing pauses to medium/long sentences (> 48 chars) that lack pauses
        if len(sent) > 48:
            for conn in _PAUSE_AFTER_CONNECTORS:
                # Insert `၊ ` after connector only when preceded by >= 14 chars and followed by >= 14 chars without punctuation
                pattern = re.compile(rf"(.{{14,}}?{re.escape(conn)})(?![၊။,!?\s]*[၊။,!?])\s+(?=.{{14,}})")
                sent = pattern.sub(r"\1၊ ", sent, count=1)
        out_sents.append(sent)

    res = " ".join(out_sents)
    res = re.sub(r"၊\s*၊", "၊", res)
    res = re.sub(r"\s{2,}", " ", res).strip()
    return res


def normalize_for_tts(text: str) -> str:
    """Convert written Burmese text into TTS-friendly phonetic + naturally phrased Burmese."""
    s = " ".join(str(text or "").split()).strip()
    if not s:
        return s

    merged = dict(DEFAULT_PRONUNCIATION_MAP)
    merged.update(_load_custom_map())
    for src in sorted(merged.keys(), key=len, reverse=True):
        if src in s:
            s = s.replace(src, merged[src])

    return _apply_phrasing(s)
