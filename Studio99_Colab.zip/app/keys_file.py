"""The user's Gemini keys, FAL key and optional TMDB token (Profile, DPAPI-encrypted in token_store) as the
.env file every tool reads:
%APPDATA%\\Studio99Desktop\\run_keys\\.env, GEMINI_IMAGE_PROJECT_<N>_KEY lines. Written while Studio99 runs and
removed when it closes (keys at rest stay encrypted)."""
from __future__ import annotations

import io
from pathlib import Path
import re
import threading

import token_store

KEYS_DIR = token_store.APP_DIR / "run_keys"
KEYS_FILE = KEYS_DIR / ".env"
_LOCK = threading.RLock()
_GEMINI_ALIAS = re.compile(r"^(?:GEMINI_IMAGE_PROJECT_\d+_KEY|GEMINI_(?:API_KEY|TEXT_FREE_KEY|TTS_FREE_KEY)|GOOGLE_API_KEY)$", re.I)


def parse_gemini(text: str) -> list[str]:
    """Accept raw keys or copied .env assignments, without storing an assignment as a key."""
    text = str(text).lstrip("\ufeff").strip()
    if not text:
        return []
    lines = [line.strip() for line in text.splitlines() if line.strip() and not line.lstrip().startswith("#")]
    if any("=" in line for line in lines):
        from dotenv import dotenv_values
        values = dotenv_values(stream=io.StringIO(text), interpolate=False)
        keys = [str(value).strip() for name, value in values.items() if _GEMINI_ALIAS.fullmatch(name) and value]
        if not keys:
            raise ValueError("FREE Gemini key မတွေ့ပါ။ API key သို့မဟုတ် FREE Gemini .env စာသားကို ထည့်ပါ။")
    else:
        keys = [line.strip('"\'') for line in lines]
    if any(any(char.isspace() for char in key) or "=" in key for key in keys):
        raise ValueError("Gemini key တစ်ကြောင်းစီ မှန်အောင် ထည့်ပေးပါ။")
    return list(dict.fromkeys(keys))


def _gemini(record: dict) -> list[str]:
    values = record.get("gemini") or []
    return parse_gemini(values if isinstance(values, str) else "\n".join(str(value) for value in values))


def gemini_keys() -> list[str]:
    rec = token_store.load_keys()
    keys = _gemini(rec)
    if keys:
        return keys
    custom = str(rec.get("api_key") or "").strip()
    return [custom] if custom else []


def write(record: dict | None = None) -> Path | None:
    """The keys file, or None when the Profile has no Gemini key."""
    with _LOCK:
        record = token_store.load_keys(strict=True) if record is None else record
        keys = _gemini(record)
        api_mode = str(record.get("api_mode") or "gemini").strip().lower()
        if api_mode not in {"gemini", "openai", "anthropic"}:
            api_mode = "gemini"
        api_base_url = str(record.get("api_base_url") or "").strip()
        api_key = str(record.get("api_key") or "").strip()
        api_models = str(record.get("api_models") or "").strip()
        effective_keys = keys if keys else ([api_key] if api_key else [])
        if not effective_keys and not api_base_url:
            remove()
            return None
        lines = [f"GEMINI_IMAGE_PROJECT_{i}_KEY={key}" for i, key in enumerate(effective_keys, 1)]
        if not effective_keys and api_base_url:
            lines.append("GEMINI_IMAGE_PROJECT_1_KEY=custom-local-key")
        fal = str(record.get("fal") or "").strip()
        if fal:
            lines.append(f"FAL_KEY={fal}")
        tmdb = str(record.get("tmdb") or "").strip()
        if tmdb:
            lines.append(f"TMDB_BEARER_TOKEN={tmdb}")
        lines.append(f"STUDIO99_API_MODE={api_mode}")
        if api_base_url:
            lines.append(f"STUDIO99_API_BASE_URL={api_base_url}")
        if api_key:
            lines.append(f"STUDIO99_API_KEY={api_key}")
        if api_models:
            lines.append(f"STUDIO99_API_MODELS={api_models}")
            first_model = next((m.strip() for m in api_models.replace("\n", ",").split(",") if m.strip()), "")
            if first_model:
                lines.append(f"GEMINI_TEXT_MODEL={first_model}")
        content = ("\n".join(lines) + "\n").encode("utf-8")
        try:
            if not KEYS_FILE.is_file() or KEYS_FILE.read_bytes() != content:
                token_store._atomic_write(KEYS_FILE, content)
            if KEYS_FILE.read_bytes() != content:
                raise OSError("Key file verification failed")
        except OSError:
            raise OSError(f"Tool အားလုံးအတွက် key ဖိုင် သိမ်း/ဖတ်မရပါ: {KEYS_FILE}။ Profile မှာ Save ပြန်လုပ်ပေးပါ။") from None
        return KEYS_FILE.resolve()


def _status(record: dict, path: Path | None, error: str = "") -> dict:
    ak = str(record.get("api_key") or "").strip()
    return {
        "gemini": [key[:4] + "•" * 10 + key[-3:] for key in _gemini(record)],
        "fal": bool(str(record.get("fal") or "").strip()),
        "tmdb": bool(str(record.get("tmdb") or "").strip()),
        "api_mode": str(record.get("api_mode") or "gemini").strip().lower(),
        "api_base_url": str(record.get("api_base_url") or "").strip(),
        "api_key_set": bool(ak),
        "api_key_masked": (ak[:4] + "•" * 8 + ak[-3:]) if len(ak) >= 8 else ("•" * len(ak) if ak else ""),
        "api_models": str(record.get("api_models") or "").strip(),
        "env_file": str(path or KEYS_FILE),
        "env_ready": path is not None and not error,
        "error": error,
    }


def status() -> dict:
    """Restore the shared runtime file on reopening Profile, while returning only masked keys."""
    record = {}
    try:
        record = token_store.load_keys(strict=True)
        return _status(record, write(record))
    except (OSError, ValueError) as exc:
        try:
            return _status(record, None, str(exc))
        except ValueError:
            return _status({}, None, str(exc))


def save(gemini_text, fal, tmdb=None, custom_api: dict | None = None) -> dict:
    """Report success only after both the encrypted store and shared .env round-trip."""
    with _LOCK:
        old = token_store.load_keys()
        custom = custom_api if isinstance(custom_api, dict) else {}
        api_mode = str(custom.get("api_mode") if "api_mode" in custom and custom.get("api_mode") is not None else old.get("api_mode") or "gemini").strip().lower()
        if api_mode not in {"gemini", "openai", "anthropic"}:
            raise ValueError("API Compatibility mode ကို gemini / openai / anthropic ထဲက ရွေးပါ။")
        api_base_url = str(old.get("api_base_url") or "") if custom.get("api_base_url") is None else str(custom.get("api_base_url")).strip()
        api_key = str(old.get("api_key") or "") if custom.get("api_key") is None else str(custom.get("api_key")).strip()
        api_models = str(old.get("api_models") or "") if custom.get("api_models") is None else str(custom.get("api_models")).strip()
        record = {
            "gemini": _gemini(old) if gemini_text is None else parse_gemini(gemini_text),
            "fal": str(old.get("fal") or "") if fal is None else str(fal).strip(),
            "tmdb": str(old.get("tmdb") or "") if tmdb is None else str(tmdb).strip(),
            "api_mode": api_mode,
            "api_base_url": api_base_url,
            "api_key": api_key,
            "api_models": api_models,
        }
        if "\n" in record["fal"] or "\r" in record["fal"]:
            raise ValueError("FAL key ကို တစ်ကြောင်းတည်း ထည့်ပေးပါ။")
        if "\n" in record["tmdb"] or "\r" in record["tmdb"]:
            raise ValueError("TMDB token ကို တစ်ကြောင်းတည်း ထည့်ပေးပါ။")
        token_store.save_keys(record)
        return _status(record, write(record))


def remove() -> None:
    with _LOCK:
        KEYS_FILE.unlink(missing_ok=True)
        (token_store.APP_DIR / "gemini_run.env").unlink(missing_ok=True)      # the old name (before 2026-10-17)
