"""Movie Search: find videos on YouTube, Dailymotion, Bilibili, Douyin (抖音) and RedNote (小红书), preview them in the app
and download them with yt-dlp.

- YouTube: yt-dlp's own search (flat, no download).
- Dailymotion: the public API (no key).
- Bilibili: the public web search API; it wants the visitor cookies the home page sets, so one session first
  visits bilibili.com.
- Douyin and RedNote: their search pages answer only a logged-in browser, so the app's Chromium profile (the one
  the Recap channel feature uses, logged in once by the user with `open_login`) opens the search page and the
  site's own JSON answer is read. yt-dlp gets that profile's cookies for the download.

Every result: {source, id, title, url, thumb, duration (s), channel, views, embed (in-app player URL or "")}."""
from __future__ import annotations

import html
import os
import re
import tempfile
import threading
import time
import urllib.parse
from contextlib import closing
from pathlib import Path
from typing import Any, Callable

import requests

from channel_source import BROWSER_PROFILE

_REFERERS = {"bilibili": "https://www.bilibili.com/", "douyin": "https://www.douyin.com/",
             "rednote": "https://www.xiaohongshu.com/"}
SOURCES = ("youtube", "dailymotion", "bilibili", "douyin", "rednote")
LOGIN_URLS = {"douyin": "https://www.douyin.com/", "rednote": "https://www.xiaohongshu.com/explore"}
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0 Safari/537.36")
_browser_lock = threading.Lock()          # one Playwright window on the shared profile at a time


class SearchError(RuntimeError):
    """A message the user can read (Burmese)."""


def _num(value) -> int:
    try:
        return int(float(str(value).replace(",", "")))
    except (TypeError, ValueError):
        text = str(value or "").strip().lower()
        for suffix, factor in (("万", 10_000), ("w", 10_000), ("k", 1_000), ("m", 1_000_000)):
            if text.endswith(suffix):
                try:
                    return int(float(text[:-1]) * factor)
                except ValueError:
                    return 0
        return 0


def _clock(text) -> int:
    """'1:02:03' / '12:34' / seconds → seconds."""
    if isinstance(text, (int, float)):
        return int(text)
    parts = [p for p in str(text or "").split(":") if p.strip().isdigit()]
    seconds = 0
    for part in parts:
        seconds = seconds * 60 + int(part)
    return seconds


def _https(url: str) -> str:
    url = str(url or "")
    return "https:" + url if url.startswith("//") else url


def _item(source, vid, title, url, thumb, duration, channel, views, embed="") -> dict[str, Any]:
    return {"source": source, "id": str(vid), "title": html.unescape(re.sub(r"<[^>]+>", "", str(title or ""))).strip(),
            "url": url, "thumb": _https(thumb), "duration": int(duration or 0), "channel": str(channel or ""),
            "views": int(views or 0), "embed": embed}


# ---------------------------------------------------------------------------------------------- open sources
def search_youtube(query: str, page: int = 1, per_page: int = 20) -> list[dict]:
    import yt_dlp
    count = per_page * page
    with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "extract_flat": "in_playlist", "skip_download": True}) as ydl:
        info = ydl.extract_info(f"ytsearch{count}:{query}", download=False)
    out = []
    for e in (info.get("entries") or [])[count - per_page:]:
        if not e or not e.get("id"):
            continue
        thumbs = e.get("thumbnails") or []
        thumb = thumbs[-1]["url"] if thumbs else f"https://i.ytimg.com/vi/{e['id']}/hqdefault.jpg"
        out.append(_item("youtube", e["id"], e.get("title"), f"https://www.youtube.com/watch?v={e['id']}", thumb,
                         e.get("duration"), e.get("channel") or e.get("uploader"), e.get("view_count"),
                         f"https://www.youtube.com/embed/{e['id']}?autoplay=1"))
    return out


def search_dailymotion(query: str, page: int = 1, per_page: int = 20) -> list[dict]:
    response = requests.get("https://api.dailymotion.com/videos", timeout=20, params={
        "search": query, "page": page, "limit": per_page, "sort": "relevance",
        "fields": "id,title,thumbnail_480_url,duration,owner.screenname,views_total,url"})
    if response.status_code != 200:
        raise SearchError(f"Dailymotion {response.status_code}")
    return [_item("dailymotion", v["id"], v.get("title"), v.get("url") or f"https://www.dailymotion.com/video/{v['id']}",
                  v.get("thumbnail_480_url"), v.get("duration"), v.get("owner.screenname"), v.get("views_total"),
                  f"https://www.dailymotion.com/embed/video/{v['id']}?autoplay=1")
            for v in response.json().get("list") or []]


def search_bilibili(query: str, page: int = 1, per_page: int = 20) -> list[dict]:
    session = requests.Session()
    session.headers.update({"User-Agent": UA, "Referer": "https://www.bilibili.com/"})
    session.get("https://www.bilibili.com/", timeout=20)                  # buvid3 etc. (else -412)
    response = session.get("https://api.bilibili.com/x/web-interface/search/type", timeout=20, params={
        "search_type": "video", "keyword": query, "page": page, "page_size": per_page})
    data = response.json() if response.status_code == 200 else {}
    if data.get("code") not in (0, None):
        raise SearchError(f"Bilibili: {data.get('message') or data.get('code')}")
    out = []
    for v in (data.get("data") or {}).get("result") or []:
        bvid = v.get("bvid")
        if not bvid:
            continue
        out.append(_item("bilibili", bvid, v.get("title"), f"https://www.bilibili.com/video/{bvid}", v.get("pic"),
                         _clock(v.get("duration")), v.get("author"), _num(v.get("play")),
                         f"https://player.bilibili.com/player.html?bvid={bvid}&autoplay=1"))
    return out


# ---------------------------------------------------------------------------------------------- logged-in sources
def logged_in(source: str) -> bool:
    """Local cookie preflight; the website can still require login/verification again."""
    import sqlite3
    cookies = BROWSER_PROFILE / "Default" / "Network" / "Cookies"
    host, name = {"douyin": ("douyin.com", "sessionid"), "rednote": ("xiaohongshu.com", "web_session")}[source]
    if not cookies.is_file():
        return False
    try:
        with closing(sqlite3.connect(f"file:{cookies}?mode=ro&immutable=1", uri=True)) as db:
            columns = {row[1] for row in db.execute("pragma table_info(cookies)")}
            stored = "length(value)>0"
            if "encrypted_value" in columns:
                stored = "(" + stored + " or length(encrypted_value)>0)"
            valid = ""
            params = [host, f"%.{host}", name]
            if "expires_utc" in columns:
                valid = " and (expires_utc=0 or expires_utc>?)"
                params.append(int((time.time() + 11644473600) * 1000000))
            return bool(db.execute("select 1 from cookies where (host_key=? or host_key like ?) "
                                   "and name=? and " + stored + valid + " limit 1", params).fetchone())
    except Exception:  # noqa: BLE001
        return False


def open_login(source: str) -> None:
    """A visible window of the app's browser on the site; the user logs in there and closes it."""
    from playwright.sync_api import sync_playwright
    with _browser_lock, sync_playwright() as p:
        browser = p.chromium.launch_persistent_context(str(BROWSER_PROFILE), headless=False, no_viewport=True)
        page = browser.pages[0] if browser.pages else browser.new_page()
        page.goto(LOGIN_URLS[source], wait_until="domcontentloaded", timeout=60000)
        try:
            page.wait_for_event("close", timeout=0)
        except Exception:  # noqa: BLE001
            pass
        try:
            browser.close()
        except Exception:  # noqa: BLE001
            pass


def _browser_json(url: str, marker: str | tuple[str, ...], wait_seconds: float = 15, scrolls: int = 0) -> list[dict]:
    """Open `url` in the app's (logged-in) browser and collect the JSON answers whose URL contains `marker`."""
    from playwright.sync_api import sync_playwright
    answers: list[dict] = []
    markers = (marker,) if isinstance(marker, str) else marker

    def on_response(response) -> None:
        if any(part in response.url for part in markers):
            try:
                answers.append(response.json())
            except Exception:  # noqa: BLE001
                pass

    with _browser_lock, sync_playwright() as p:
        browser = p.chromium.launch_persistent_context(str(BROWSER_PROFILE), headless=True,
                                                       viewport={"width": 1280, "height": 1600}, user_agent=UA)
        try:
            page = browser.new_page()
            page.on("response", on_response)
            page.goto(url, wait_until="domcontentloaded", timeout=60000)
            end = time.time() + wait_seconds
            while time.time() < end and not answers:
                page.wait_for_timeout(400)
            for _ in range(scrolls):
                page.mouse.wheel(0, 4000)
                page.wait_for_timeout(1200)
        finally:
            browser.close()
    return answers


def search_douyin(query: str, page: int = 1, per_page: int = 20) -> list[dict]:
    if not logged_in("douyin"):
        raise SearchError("Douyin (抖音) ရှာဖို့ 'Login' နှိပ်ပြီး ပွင့်လာတဲ့ douyin.com မှာ login ဝင်ပါ")
    answers = _browser_json(f"https://www.douyin.com/search/{urllib.parse.quote(query, safe='')}?type=video",
                            ("/aweme/v1/web/search/item/", "/aweme/v1/web/general/search/"),
                            scrolls=max(0, page - 1))
    if not answers:
        raise SearchError("Douyin က search ရလဒ် မပို့သေးပါ — Login ကို ပြန်ဖွင့်ပြီး login / verification လိုမလို စစ်ပါ")
    out, seen = [], set()
    for answer in answers:
        if not isinstance(answer, dict):
            continue
        if answer.get("status_code") not in (None, 0):
            raise SearchError(f"Douyin: {answer.get('status_msg') or answer.get('status_code')}")
        rows = answer.get("data") or answer.get("aweme_list") or []
        if isinstance(rows, dict):
            rows = rows.get("items") or rows.get("aweme_list") or []
        for row in rows:
            if not isinstance(row, dict):
                continue
            item = row.get("aweme_info") or row.get("aweme_detail") or row
            if not isinstance(item, dict):
                continue
            video_id = str(item.get("aweme_id") or "")
            video = item.get("video") or {}
            if not video_id.isdigit() or video_id in seen or not video or item.get("aweme_type") == 68:
                continue
            seen.add(video_id)
            cover = video.get("cover") or video.get("origin_cover") or {}
            urls = cover.get("url_list") or []
            stats = item.get("statistics") or {}
            out.append(_item("douyin", video_id, item.get("desc"), f"https://www.douyin.com/video/{video_id}",
                             urls[0] if urls else "", _num(video.get("duration")) // 1000,
                             (item.get("author") or {}).get("nickname"),
                             _num(stats.get("play_count") or stats.get("digg_count"))))
    return out[(page - 1) * per_page:page * per_page]


def search_rednote(query: str, page: int = 1, per_page: int = 20) -> list[dict]:
    if not logged_in("rednote"):
        raise SearchError("RedNote ရှာဖို့ 'Login' နှိပ်ပြီး ပွင့်လာတဲ့ browser မှာ 小红书 ကို တစ်ခါ login ဝင်ပါ")
    answers = _browser_json(f"https://www.xiaohongshu.com/search_result?keyword={urllib.parse.quote(query)}&type=51",
                            "/api/sns/web/v1/search/notes", scrolls=max(0, page - 1))
    out, seen = [], set()
    for answer in answers:
        for row in (answer.get("data") or {}).get("items") or []:
            card = row.get("note_card") or {}
            note_id, token = row.get("id"), row.get("xsec_token") or ""
            if not note_id or note_id in seen or card.get("type") not in ("video", None):
                continue
            seen.add(note_id)
            url = (f"https://www.xiaohongshu.com/explore/{note_id}?xsec_token={urllib.parse.quote(token)}"
                   "&xsec_source=pc_search")
            out.append(_item("rednote", note_id, card.get("display_title"), url,
                             (card.get("cover") or {}).get("url_default") or (card.get("cover") or {}).get("url"),
                             0, (card.get("user") or {}).get("nickname"),
                             _num((card.get("interact_info") or {}).get("liked_count"))))
    return out[(page - 1) * per_page:page * per_page] or out[-per_page:]


SEARCHERS = {"youtube": search_youtube, "dailymotion": search_dailymotion, "bilibili": search_bilibili,
             "douyin": search_douyin, "rednote": search_rednote}


def search(source: str, query: str, page: int = 1) -> list[dict]:
    query = query.strip()
    if not query:
        return []
    if source not in SEARCHERS:
        raise SearchError(f"Unknown source: {source}")
    try:
        return SEARCHERS[source](query, page)
    except SearchError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise SearchError(f"{source} ရှာလို့ မရပါ: {str(exc)[:160]}") from exc


# ---------------------------------------------------------------------------------------------- download
def _write_cookies(name: str, rows: list[tuple]) -> str:
    """rows: (domain, path, secure, expires, name, value) → a Netscape cookies.txt for yt-dlp."""
    lines = ["# Netscape HTTP Cookie File"]
    for domain, path, secure, expires, key, value in rows:
        lines.append("\t".join([domain, "TRUE" if domain.startswith(".") else "FALSE", path or "/",
                                "TRUE" if secure else "FALSE", str(int(expires or 0)), key, value]))
    from token_store import APP_DIR
    out = (APP_DIR / "tmp" if os.environ.get("STUDIO99_WEB_MODE") == "colab" else Path(tempfile.gettempdir())) \
        / f"studio99_{name}_cookies.txt"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(out)


def _bilibili_cookie_file() -> str:
    """Bilibili answers 412 without the visitor cookies its home page sets (2026-10-18)."""
    session = requests.Session()
    session.headers.update({"User-Agent": UA})
    session.get("https://www.bilibili.com/", timeout=20)
    rows = [(c.domain if c.domain.startswith(".") else "." + c.domain.lstrip("."), c.path, c.secure,
             c.expires or 0, c.name, c.value) for c in session.cookies]
    return _write_cookies("bilibili", rows) if rows else ""


def _cookie_file(source: str) -> str:
    """The cookies yt-dlp needs for the site as a cookies.txt ("" when none are needed)."""
    if source == "bilibili":
        return _bilibili_cookie_file()
    if source not in ("douyin", "rednote") or not logged_in(source):
        return ""
    from playwright.sync_api import sync_playwright
    host = {"douyin": "douyin.com", "rednote": "xiaohongshu.com"}[source]
    with _browser_lock, sync_playwright() as p:
        browser = p.chromium.launch_persistent_context(str(BROWSER_PROFILE), headless=True)
        try:
            cookies = [c for c in browser.cookies() if c.get("domain", "").lstrip(".").lower() == host
                       or c.get("domain", "").lower().endswith("." + host)]
        finally:
            browser.close()
    return _write_cookies(source, [(c["domain"], c.get("path", "/"), bool(c.get("secure")),
                                    int(c["expires"]) if (c.get("expires") or -1) > 0 else 0, c["name"], c["value"])
                                   for c in cookies])


def _network_tries(source: str) -> list[dict]:
    """How yt-dlp reaches the site, in order. 2026-10-18 on the user's PC (all traffic through v2rayN, a Japanese
    datacenter exit): YouTube asked "Sign in to confirm you're not a bot" and Bilibili answered 412 through the VPN
    but both worked DIRECT (proxy ""); Dailymotion's video servers answer 403 unless the client looks like a browser
    (impersonate chrome). Douyin/RedNote go through the system's VPN first (they may be blocked direct)."""
    from yt_dlp.networking.impersonate import ImpersonateTarget
    chrome = {"impersonate": ImpersonateTarget.from_str("chrome")}
    direct = {"proxy": ""}
    if source == "dailymotion":
        return [{**chrome, **direct}, chrome]
    if source in ("youtube", "bilibili"):
        return [direct, {**direct, **chrome}, {}, chrome]
    return [{}, direct, chrome]


def preview(item: dict) -> dict:
    """What the page can play: {"kind": "video", "url"} (a direct progressive MP4 fetched without the VPN, so the
    page — whose window also reaches these sites directly, see webapp.py — gets the same address) or
    {"kind": "embed", "url"} or {"kind": "link", "url"}."""
    import yt_dlp
    if item.get("source") == "youtube":
        for extra in _network_tries("youtube")[:2]:
            try:
                with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "skip_download": True, **extra,
                                       "format": "18/best[ext=mp4][acodec!=none][vcodec!=none]"}) as ydl:
                    info = ydl.extract_info(item["url"], download=False)
                if info.get("url"):
                    return {"kind": "video", "url": info["url"]}
            except Exception:  # noqa: BLE001
                continue
    if item.get("embed"):
        return {"kind": "embed", "url": item["embed"]}
    return {"kind": "link", "url": item.get("url", "")}


# hosts the app window reaches without the VPN (previews), see webapp.py
DIRECT_HOSTS = ("*.youtube.com", "*.googlevideo.com", "*.ytimg.com", "*.youtube-nocookie.com", "*.dailymotion.com",
                "*.dmcdn.net", "*.bilibili.com", "*.hdslb.com", "*.bilivideo.com")


def download(item: dict, out_dir: str | Path, quality: int = 1080,
             progress: Callable[[dict], None] | None = None, stop: Callable[[], bool] | None = None) -> Path:
    """Download one result; progress gets {percent, speed, eta, status}. Returns the file."""
    import yt_dlp
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    cookie = _cookie_file(item.get("source", ""))

    def hook(d: dict) -> None:
        if stop and stop():
            raise yt_dlp.utils.DownloadCancelled("stopped")
        if item.get("source") == "bilibili" and str(d.get("filename") or "").endswith(".tmp"):
            return                                      # a CDN availability probe is not the user's download
        if progress and d.get("status") in ("downloading", "finished"):
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            done = d.get("downloaded_bytes") or 0
            progress({"status": d["status"], "percent": round(done * 100 / total, 1) if total else 0,
                      "speed": d.get("speed") or 0, "eta": d.get("eta") or 0})

    opts = {"quiet": True, "no_warnings": True, "noprogress": True, "noplaylist": True, "merge_output_format": "mp4",
            "format": f"bv*[height<={quality}][ext=mp4]+ba[ext=m4a]/bv*[height<={quality}]+ba/b[height<={quality}]/b",
            "outtmpl": str(out / "%(title).80B [%(id)s].%(ext)s"), "progress_hooks": [hook],
            "windowsfilenames": True, "http_headers": {"Referer": _REFERERS.get(item.get("source"), "")}}
    bundled_ffmpeg = Path(__file__).resolve().parents[1] / "recap_tool_src" / "ffmpeg" / "ffmpeg.exe"
    if bundled_ffmpeg.is_file():
        opts["ffmpeg_location"] = str(bundled_ffmpeg.parent)
    if cookie:
        opts["cookiefile"] = cookie
    if item.get("source") == "bilibili":
        # Move on to the next network route instead of retrying an unreachable CDN ten times.
        opts.update(socket_timeout=12, retries=1, fragment_retries=1, check_formats="selected",
                    http_chunk_size=10 * 1024 * 1024)    # Bilibili CDNs can reject an unbounded GET with HTTP 567
    tries = _network_tries(item.get("source", ""))
    for n, extra in enumerate(tries):
        try:
            with yt_dlp.YoutubeDL({**opts, **extra}) as ydl:
                if item.get("source") == "bilibili":
                    from bilibili_download import extract
                    info = extract(ydl, item["url"])
                else:
                    info = ydl.extract_info(item["url"], download=True)
                path = Path(ydl.prepare_filename(info)).with_suffix(".mp4")
            break
        except yt_dlp.utils.DownloadCancelled:
            raise SearchError("ရပ်လိုက်ပါပြီ") from None
        except Exception as exc:  # noqa: BLE001
            if n == len(tries) - 1:
                if "412" in str(exc) and item.get("source") == "bilibili":
                    # 2026-10-18: Bilibili answered 412 to every video page from this network (yt-dlp, its APIs
                    # and a real Chromium alike) while search worked — its risk control blocks the address
                    raise SearchError("Bilibili က ဒီ internet လိုင်း (IP) ကို download ခွင့်မပေးပါ — VPN server "
                                      "ပြောင်းပြီး ပြန်စမ်းပါ") from exc
                raise SearchError(f"Download မရပါ: {str(exc).replace('ERROR: ', '')[:200]}") from exc
    if not path.is_file():
        found = sorted(out.glob(f"*[[]{info.get('id')}[]].*"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not found:
            raise SearchError("Download ပြီးပေမဲ့ ဖိုင် မတွေ့ပါ")
        path = found[0]
    import history
    history.add("download", path, item.get("title", ""))
    return path
