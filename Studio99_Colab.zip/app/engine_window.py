"""The Auto Posting dashboard (the TT master's web UI from the engine) in WebView2.

    pythonw engine_window.py <url>                   its own window
    pythonw engine_window.py <url> --parent <hwnd>   INSIDE Studio99: the window is made a child of the Auto Posting
                                                     card's frame (Win32 SetParent), fills it, follows its size, and
                                                     closes itself when that frame is gone (user 2026-10-18: show it
                                                     in the app, not as a separate web page).

pywebview needs the main thread of its own process, and Tk owns the app's, so this always runs in its own process
(engine_runner.open_window). Closing it never stops posting — the engine is another process."""
from __future__ import annotations

import ctypes
import os
import sys
import time
from ctypes import wintypes

import webview

user32 = ctypes.windll.user32
user32.FindWindowW.restype = wintypes.HWND
user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
user32.SetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
user32.SetParent.argtypes = [wintypes.HWND, wintypes.HWND]
user32.MoveWindow.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.BOOL]
user32.IsWindow.argtypes = [wintypes.HWND]
user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
GWL_STYLE, GWL_EXSTYLE = -16, -20
WS_CHILD, WS_VISIBLE, WS_CLIPSIBLINGS = 0x40000000, 0x10000000, 0x04000000
WS_POPUP, WS_CAPTION, WS_THICKFRAME, WS_SYSMENU = 0x80000000, 0x00C00000, 0x00040000, 0x00080000
WS_MINIMIZEBOX, WS_MAXIMIZEBOX = 0x00020000, 0x00010000
WS_EX_APPWINDOW, WS_EX_TOOLWINDOW = 0x00040000, 0x00000080


def _client_size(parent: int) -> tuple[int, int]:
    rect = wintypes.RECT()
    user32.GetClientRect(parent, ctypes.byref(rect))
    return rect.right - rect.left, rect.bottom - rect.top


def _find(title: str, timeout: float = 30) -> int:
    end = time.time() + timeout
    while time.time() < end:
        hwnd = user32.FindWindowW(None, title)
        if hwnd:
            return hwnd
        time.sleep(0.05)
    return 0


def embed(window, title: str, parent: int) -> None:
    """Make the pywebview window a borderless child of `parent` and keep it the parent's size."""
    hwnd = _find(title)
    if not hwnd:
        window.show()
        return
    style = user32.GetWindowLongPtrW(hwnd, GWL_STYLE)
    style &= ~(WS_POPUP | WS_CAPTION | WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX)
    user32.SetWindowLongPtrW(hwnd, GWL_STYLE, style | WS_CHILD | WS_CLIPSIBLINGS)
    ex = user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE)
    user32.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, (ex & ~WS_EX_APPWINDOW) | WS_EX_TOOLWINDOW)   # no taskbar button
    user32.SetParent(hwnd, parent)
    size = _client_size(parent)
    user32.MoveWindow(hwnd, 0, 0, size[0], size[1], True)
    window.show()
    while user32.IsWindow(parent):
        now = _client_size(parent)
        if now != size and now[0] > 0 and now[1] > 0:
            size = now
            user32.MoveWindow(hwnd, 0, 0, size[0], size[1], True)
        time.sleep(0.15)
    # the card was closed: Windows already destroyed the child window with its parent, so pywebview's loop may
    # never end by itself — leave the process (2026-10-18: it stayed alive after the card closed)
    try:
        window.destroy()
    except Exception:  # noqa: BLE001
        pass
    time.sleep(1.0)
    os._exit(0)


def main() -> None:
    url = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8799/"
    parent = int(sys.argv[sys.argv.index("--parent") + 1]) if "--parent" in sys.argv else 0
    if not parent:
        webview.create_window("Studio99 — Auto Posting", url, width=1360, height=880, min_size=(980, 640),
                              background_color="#0b0d12")
        webview.start(private_mode=False)
        return
    title = f"Studio99AutoPosting-{os.getpid()}"               # unique, to find this window's handle
    window = webview.create_window(title, url, width=1200, height=800, frameless=True, easy_drag=False,
                                   hidden=True, shadow=False, background_color="#0b0d12")
    webview.start(embed, (window, title, parent), private_mode=False)   # embed runs in its own thread


if __name__ == "__main__":
    main()
