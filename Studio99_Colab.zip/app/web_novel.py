"""Novel (free) for the web UI: the user's novel_standalone tool (copy in tool_apps/novel) — a four-part Burmese
novel (~5,000 letters a part) with numbered covers (FAL when the Profile has a key, else made on this PC) and
optional 9:16 story-page pictures. Runs `run_novel.py` in its own process."""
from __future__ import annotations

import json
import threading
from pathlib import Path

import history
import keys_file
import token_store
from web_story import image_data_url
from web_tool_job import ToolJob

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "tool_apps" / "novel"
_job: ToolJob | None = None
_job_lock = threading.RLock()


def _config() -> dict:
    return json.loads((TOOL / "config" / "novel.json").read_text(encoding="utf-8"))


def series_list() -> list[dict]:
    out = []
    root = TOOL / (_config().get("output_root") or "outputs")
    for folder in sorted(root.glob("*"), reverse=True) if root.is_dir() else []:
        manifest = folder / "manifest.json"
        if not manifest.is_file():
            continue
        try:
            m = json.loads(manifest.read_text(encoding="utf-8"))
        except ValueError:
            continue
        parts = []
        for n in range(1, 5):
            text, cover = folder / "parts" / f"part_{n:02d}_post.txt", folder / "covers" / f"part_{n:02d}_cover.jpg"
            if text.is_file():
                parts.append({"n": n, "text": str(text), "cover": str(cover) if cover.is_file() else "",
                              "chars": len(text.read_text(encoding="utf-8"))})
        out.append({"folder": str(folder), "title": m.get("title") or folder.name, "date": folder.name[:8],
                    "parts": parts, "pages": bool(m.get("story_pages"))})
    return out


def call(api, action: str, payload: dict):
    with _job_lock:
        return _call(api, action, payload)


def _call(api, action: str, payload: dict):
    global _job
    if action == "options":
        cfg = _config()
        return {"genres": cfg.get("genres") or [], "fal": bool((token_store.load_keys().get("fal") or "").strip()),
                "saved": api._cfg.get("novel") or {}, "series": series_list(), "running": bool(_job and _job.running)}
    if action == "series":
        return series_list()
    if action == "text":
        return Path(payload["path"]).read_text(encoding="utf-8")
    if action == "cover":
        return image_data_url(Path(payload["path"]), 420) if Path(payload.get("path", "")).is_file() else ""
    if action == "stop":
        if _job:
            _job.stop()
        return True
    if action == "start":
        api._need_session()
        if _job is not None and _job.running:
            return False
        keys = keys_file.write()
        if not keys:
            raise RuntimeError("Profile မှာ Gemini API key အရင်ထည့်ပါ")
        cfg_path = TOOL / "config" / "novel.json"
        cfg = _config()
        cfg["env_fallback_path"] = str(keys)                    # the Profile's keys (+ FAL key when set)
        cfg["screenshot_pages_enabled"] = bool(payload.get("pages"))
        cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        api._cfg["novel"] = {k: payload.get(k) for k in ("genre", "pages")}
        from app_config import save_config
        save_config(api._cfg)
        args = ["run_novel.py", "--genre", str(payload.get("genre") or ""), "--synopsis", str(payload.get("synopsis") or "")]
        if payload.get("start_date"):
            args += ["--start-date", str(payload["start_date"])]
        if payload.get("pages"):
            args.append("--screenshot-pages")
        _job = ToolJob("novel", api._emit)

        def done(code: int, lines: list[str]) -> None:
            if code != 0:
                api._emit("novel_error", message="ရပ်လိုက်ပါပြီ" if code == -1 else f"မပြီးပါ (exit {code}) — log ကိုကြည့်ပါ")
                return
            series = series_list()
            if series:
                history.add("novel", series[0]["folder"], series[0]["title"])
            api._emit("novel_done", series=series)
        from daily_limits import free_job
        return _job.start(args, TOOL, {}, done, usage=free_job("novel", session=api._need_session()))
    raise RuntimeError(f"Unknown action {action}")
