"""Auto Posting as cards (user, 2026-10-23): the same cards as Home — Recap, Splitter, Dubbing, Subtitle,
Original→Recap, Story Motion, Long to Short, Novel, Movie Review — each one a posting category of the engine with its
own routes
(Facebook Page / TikTok / group share / daily count / times) and its own waiting list. Every tool outside has
"📮 Auto Posting ပို့မယ်": its finished videos go to its card, which posts them when its routes' times come.

candidates(tool) = what a tool has made lately: the app's history for the tools that report there (Recap, Splitter,
Story Motion, Long to Short) and the output folders of the copied tools that do not (Dubbing, Subtitle,
Original→Recap). Novel and Movie Review are not single videos: a novel part is one Facebook photo post (its cover
+ the part's text), a review is a Facebook photo post (thumbnail + review text) followed by its Reel (Facebook Reel
+ TikTok)."""
from __future__ import annotations

import json
import time
from pathlib import Path

import engine_runner
import history
import posting_queue

ROOT = Path(__file__).resolve().parents[1]
APPS = ROOT / "tool_apps"

# Home tool id → (origin on the list, history kind)
TOOLS = {
    "recap": ("recap", "recap"),
    "splitter": ("splitter", "splitter"),
    "dubbing": ("dubbing", ""),
    "subtitle": ("subtitle", ""),
    "storytelling": ("storytelling", ""),
    "story_motion": ("story_motion", "story_motion"),
    "long_to_short": ("lts", "long_to_short"),
    "novel": ("novel", ""),
    "movie_review": ("movie_review", ""),
}
CARD_TOOL = {posting_queue.category_for_origin(origin): tool for tool, (origin, _k) in TOOLS.items()}
SKIP_DIRS = {"work", "_work", "tmp", "temp", "cache", "_cache", "segments", "tts", "chunks", "parts_cache",
             "tts_parts", "tts_parts_short", "preview", "_previews"}
MAX_AGE_DAYS = 45


def origin_of(tool: str) -> str:
    if tool not in TOOLS:
        raise ValueError(f"No Auto Posting card for: {tool}")
    return TOOLS[tool][0]


def category_of(tool: str) -> str:
    return posting_queue.category_for_origin(origin_of(tool))


# ---------------------------------------------------------------------------------------------- cards
def cards() -> list[dict]:
    counts = posting_queue.summary()
    routes = engine_runner.destinations(enabled_only=False)
    out = []
    for key, (label, _origins) in posting_queue.CATEGORIES.items():
        mine = [r for r in routes if r["category"] == key]
        c = counts.get(key, {})
        out.append({"category": key, "label": label, "tool": CARD_TOOL.get(key, ""), **c,
                    "routes": len(mine), "routes_on": sum(1 for r in mine if r.get("enabled")),
                    "pages": [r["where"] for r in mine if r.get("enabled")]})
    return out


def card(category: str) -> dict:
    if category not in posting_queue.CATEGORIES:
        raise ValueError(f"Unknown card: {category}")
    info = next((c for c in cards() if c["category"] == category),
                {"category": category, "label": posting_queue.CATEGORIES[category][0]})
    names = {r["id"]: r["label"] for r in engine_runner.destinations(category, enabled_only=False)}
    items = []
    for item in posting_queue.load():
        if item.get("category") != category:
            continue
        items.append({**item, "name": Path(item.get("video", "")).name,
                      "target_names": [names.get(t, t) for t in item.get("targets") or []],
                      "exists": Path(item.get("video", "")).is_file()})
    order = {"posting": 0, "queued": 1, "posted": 2}
    items.sort(key=lambda x: (order.get(x.get("status"), 3), x.get("added", "")))
    return {**info, "routes_list": engine_runner.destinations(category, enabled_only=False), "items": items}


# ---------------------------------------------------------------------------------------------- what a tool made
def _json(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _folders(tool: str) -> list[Path]:
    """Output folders of the copied tools (their own settings files)."""
    if tool == "dubbing":
        out = str(_json(APPS / "dubbing" / "last_config.json").get("output") or "outputs")
        return [Path(out) if Path(out).is_absolute() else APPS / "dubbing" / out]
    if tool == "subtitle":
        out = str(_json(APPS / "subtitle" / "ui_settings.json").get("output_dir") or "")
        return [Path(out) if out else APPS / "subtitle" / "outputs"]
    if tool == "storytelling":
        out = str(_json(APPS / "storytelling" / "config.json").get("output_root") or "")
        return [Path(out)] if out else []
    return []


def _scan(folder: Path, limit: int, since: float) -> list[Path]:
    found: list[Path] = []
    if not folder.is_dir():
        return found
    stack = [(folder, 0)]
    while stack:
        here, depth = stack.pop()
        try:
            entries = list(here.iterdir())
        except OSError:
            continue
        for entry in entries:
            if entry.is_dir():
                if depth < 4 and entry.name.lower() not in SKIP_DIRS:
                    stack.append((entry, depth + 1))
            elif entry.suffix.lower() == ".mp4":
                try:
                    st = entry.stat()
                except OSError:
                    continue
                if st.st_mtime >= since and st.st_size > 500_000:
                    found.append(entry)
    found.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return found[:limit]


def _state(category: str, key_path: str, waiting: set[str], posted: dict) -> str:
    key = posting_queue.item_key({"video": key_path})
    done = posted.get(key)
    if done and done.get("category") == category and done.get("routes"):
        return "posted"
    return "waiting" if key in waiting else ""


def _novel_parts() -> list[dict]:
    """Every part of every novel (newest novel first, its parts 4 → 1 so the list sends Part 1 first)."""
    import web_novel
    rows = []
    for series in web_novel.series_list():
        for part in sorted(series["parts"], key=lambda x: -x["n"]):
            if not part.get("cover"):
                continue
            rows.append({"video": part["cover"], "caption": f"{series['title']} — Part {part['n']}",
                         "at": series["date"], "fixed": True, "label": f"ပုံ + စာ {part['chars']:,} လုံး",
                         "text_file": part["text"], "image": part["cover"]})
    return rows


def _reviews() -> list[dict]:
    """Every finished Movie Review that has its Facebook post (thumbnail + text); its Reel goes after it."""
    import web_review
    rows = []
    for r in web_review.results(limit=60):
        try:
            m = json.loads((Path(r["folder"]) / "manifest.json").read_text(encoding="utf-8-sig"))
        except (OSError, ValueError):
            continue
        dest = m.get("destinations") or {}
        post, reel = dest.get("facebook_post") or {}, dest.get("facebook_reel") or {}
        if not (post.get("image") and Path(post["image"]).is_file() and post.get("text")):
            continue
        has_reel = bool(reel.get("video") and Path(reel["video"]).is_file())
        rows.append({"video": post["image"], "caption": r["title"], "fixed": True, "image": post["image"],
                     "at": time.strftime("%Y-%m-%d %H:%M", time.localtime(r["at"])), "manifest": str(Path(r["folder"]) / "manifest.json"),
                     "label": "Post (ပုံ + စာ)" + (" + Reel" if has_reel else "")})
    return rows


def candidates(tool: str, limit: int = 60) -> list[dict]:
    """Finished videos of a tool, newest first: [{video, caption, at, state}] — state: "" / "waiting" / "posted".
    Novel / Movie Review rows are posts (fixed=True: their text comes from the tool's files)."""
    origin, kind = TOOLS[tool]
    category = posting_queue.category_for_origin(origin)
    waiting = {posting_queue.item_key(x) for x in posting_queue.load()
               if x.get("category") == category and x.get("status") in ("queued", "posting")}
    posted = posting_queue.ledger()
    if tool in ("novel", "movie_review"):
        rows = (_novel_parts() if tool == "novel" else _reviews())[:limit]
        for row in rows:
            row["state"] = _state(category, row["video"], waiting, posted)
        return rows
    since = time.time() - MAX_AGE_DAYS * 86400
    rows: dict[str, dict] = {}
    if kind:
        for h in reversed(history.load()):
            path = Path(str(h.get("path") or ""))
            if h.get("kind") == kind and path.suffix.lower() == ".mp4" and path.is_file():
                rows.setdefault(str(path), {"video": str(path), "caption": h.get("title") or path.stem,
                                            "at": h.get("at", "")})
    for folder in _folders(tool):
        for path in _scan(folder, limit, since):
            rows.setdefault(str(path), {"video": str(path), "caption": _caption_for(tool, path),
                                        "at": time.strftime("%Y-%m-%d %H:%M", time.localtime(path.stat().st_mtime))})
    out = []
    for row in sorted(rows.values(), key=lambda r: r["at"], reverse=True)[:limit]:
        row["state"] = _state(category, row["video"], waiting, posted)
        out.append(row)
    return out


def _caption_for(tool: str, path: Path) -> str:
    """A file name like Burmese.mp4 / final.mp4 says nothing: use its folder's name then."""
    stem = path.stem
    if stem.lower() in {"final", "output", "burmese", "myanmar", "english", "video"} or len(stem) <= 3:
        return f"{path.parent.name} {stem}".strip()
    return stem


def _read(path: str) -> str:
    return Path(path).read_text(encoding="utf-8-sig").strip()


def _post_entries(tool: str, picked: list[dict]) -> list[dict]:
    """Novel part / Movie Review row → the posts on the list (photo post; a review's Reel after its post)."""
    rows = {r["video"]: r for r in (_novel_parts() if tool == "novel" else _reviews())}
    entries = []
    for v in picked:
        row = rows.get(str(v.get("video") or ""))
        if row is None:
            raise FileNotFoundError(f"မတွေ့တော့ပါ: {Path(str(v.get('video'))).name}")
        if tool == "novel":
            entries.append({"video": row["image"], "caption": row["caption"], "kind": "photo",
                            "images": [row["image"]], "text": _read(row["text_file"])})
            continue
        m = json.loads(Path(row["manifest"]).read_text(encoding="utf-8-sig"))
        dest = m.get("destinations") or {}
        post, reel = dest.get("facebook_post") or {}, dest.get("facebook_reel") or {}
        entries.append({"video": post["image"], "caption": row["caption"], "kind": "photo", "images": [post["image"]],
                        "text": _read(post["text"])})
        if reel.get("video") and Path(reel["video"]).is_file():
            caption = _read(reel["caption"]) if reel.get("caption") and Path(reel["caption"]).is_file() else row["caption"]
            entries.append({"video": reel["video"], "caption": caption})
    return entries


def send(tool: str, videos: list[dict], *, targets: list[str] | None = None, post_at: str = "",
         delete_after: bool = False) -> dict:
    """videos: [{video, caption}] in posting order → that tool's card. {"added": n, "skipped": [...]}"""
    if tool in ("novel", "movie_review"):
        entries = _post_entries(tool, videos)
    else:
        entries = [{"video": v["video"], "caption": v.get("caption") or Path(v["video"]).stem} for v in videos
                   if str(v.get("video") or "").strip()]
    missing = [e["video"] for e in entries if not Path(e["video"]).is_file()]
    if missing:
        raise FileNotFoundError("Video ဖိုင် မတွေ့ပါ: " + ", ".join(Path(m).name for m in missing[:3]))
    out = posting_queue.add_many(entries, origin=origin_of(tool), targets=list(targets or []), post_at=post_at,
                                 delete_after_post=delete_after)
    return {"added": len(out["added"]), "skipped": out["skipped"], "card": category_of(tool)}
