"""Studio99 Desktop — the web UI (design/*.dc.html, approved 2026-10-18) in a pywebview/WebView2 window.

The page (app/web/index.html + app.js + app.css) calls `window.pywebview.api.<method>` on `Api` below; long jobs run
in threads and report back with `S99.onEvent({...})` (Api._emit). Python logic is the same as before:
pb_client (login/VIP), token_store/keys_file (keys), story_motion/*, lts_runner, movie_search, posting_queue +
engine_runner (Auto Posting). Recap/Splitter (tk_tool.py) and Dubbing/Subtitle/Original→Recap (tool_apps.py) keep
their own windows/processes.

Run:  pythonw -X utf8 app\\webapp.py   (RUN.bat)"""
from __future__ import annotations

import base64
import io
import json
import os
import queue
import socket
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from pathlib import Path

try:
    import webview
except ImportError:  # Colab serves the same page over HTTP instead of opening a native window.
    webview = None
from ui_health import UIHealth, configure_rendering

APP = Path(__file__).resolve().parent
sys.path.insert(0, str(APP))

import ai_extras  # noqa: E402
import auto_posting  # noqa: E402
import engine_runner  # noqa: E402
import history  # noqa: E402
import keys_file  # noqa: E402
import local_mode  # noqa: E402
import posting_queue  # noqa: E402
import token_store  # noqa: E402
import tool_apps  # noqa: E402
from tool_busy import BusyWatch  # noqa: E402
from pb_client import AuthError, PocketBase, ServerUnreachable, Session, UpdateRequired  # noqa: E402
from tools import TOOLS  # noqa: E402
from app_config import load_config, save_config  # noqa: E402
from notification_inbox import NotificationInbox  # noqa: E402
from desktop_storage import Storage  # noqa: E402

ROOT = APP.parent
LOGS = ROOT / "logs"
WEB = APP / "web"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
WEB_PAGES = {"story_motion", "long_to_short", "movie_search", "novel", "movie_review", "auto_posting"}
TK_TOOLS = {"recap", "splitter"}
# VIP tools in their own window/process: when VIP ends they close once their job is done (_enforce_vip_tools)
FRESH_SECONDS = 120          # VIP work that starts asks the server again when the last answer is older than this
VIP_WINDOW_TOOLS = {t.id for t in TOOLS if t.vip} & (TK_TOOLS | set(tool_apps.WINDOW_TOOLS))
HELP_LINKS = {"vip": "https://t.me/Studio99x_bot", "support": "https://t.me/Jinn260"}


def pythonw() -> str:
    exe = Path(sys.executable)
    candidate = exe.with_name("pythonw.exe")
    return str(candidate if candidate.exists() else exe)


def folder_size(path: Path) -> int:
    total = 0
    for base, _dirs, files in os.walk(path):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(base, name))
            except OSError:
                pass
    return total


class Api:
    """Every public method is callable from the page; state lives in _attributes (pywebview exposes only
    public members)."""

    def __init__(self) -> None:
        self._window = None
        self._colab = os.environ.get("STUDIO99_WEB_MODE") == "colab"
        self._web_clients: set[str] = set()
        self._web_clients_lock = threading.Lock()
        self._web_events: list[dict] = []
        self._web_event_id = 0
        self._colab_recap = None
        self._cfg = load_config()
        self._colab_splitter = None
        self._colab_auto = None
        self._colab_dubbing = None
        self._colab_subtitle = None
        self._colab_storytelling = None
        if self._colab:
            from colab_runtime import ColabRecapJobs
            from colab_splitter import ColabSplitterJobs
            from colab_auto import ColabRecapAuto
            from colab_dubbing import ColabDubbingJobs
            from colab_subtitle import ColabSubtitleJobs
            from colab_storytelling import ColabStorytellingJobs
            self._colab_recap = ColabRecapJobs(self._emit)
            self._colab_splitter = ColabSplitterJobs(self._emit)
            self._colab_auto = ColabRecapAuto(self._colab_recap, self._emit)
            self._colab_dubbing = ColabDubbingJobs(self._emit)
            self._colab_subtitle = ColabSubtitleJobs(self._emit)
            self._colab_storytelling = ColabStorytellingJobs(self._emit)
        self._pb = PocketBase(self._cfg.get("server") or "https://api.recapboxx.com")
        self._session: Session | None = None
        self._account_lock = threading.RLock()
        self._closing_event = threading.Event()
        self._notification_inbox: NotificationInbox | None = None
        self._notification_lock = threading.Lock()
        self._tk: dict[str, subprocess.Popen] = {}
        self._stats_cache: tuple[float, dict] = (0.0, {})
        self._posting_started = False
        self._storage = Storage()
        self._storage_lock = threading.Lock()
        from web_story import StoryJobs
        self._story = StoryJobs(self._emit)
        self._lts = None
        self._downloads: dict[str, dict] = {}
        self._embedded: dict[str, int] = {}            # tool id → its window handle shown inside this window
        self._detached: set[str] = set()
        self._active_tool = ""
        self._embed_lock = threading.Lock()
        self._ai = ai_extras.Installer(self._emit)
        self._busy = BusyWatch()
        self._vip_end_told = False
        self._fresh_at = 0.0                     # when VIP was last read from the server (_fresh_session)
        self._ui_health = None
        self._local = local_mode.enabled()       # offline developer mode (local_mode.py)
        if self._local:
            self._session = local_mode.session()  # already signed in as a local VIP+ account

    def web_events_since(self, after: int = 0) -> dict:
        if not self._colab:
            return {"events": [], "last_id": 0}
        with self._web_clients_lock:
            events = [item for item in self._web_events if item["id"] > int(after)]
            last_id = self._web_event_id
        return {"events": events, "last_id": last_id}

    def recap_options(self) -> dict:
        if not self._colab_recap:
            raise RuntimeError("Recap web mode မဖွင့်ထားပါ။")
        from colab_runtime import OUTPUTS
        import colab_recap_ui
        OUTPUTS.mkdir(parents=True, exist_ok=True)
        result = colab_recap_ui.options(self._colab_recap)
        result["recent_sources"] = self._recap_recent_sources()
        result["recent_outputs"] = [{"name": p.name, "path": str(p)} for p in sorted(OUTPUTS.rglob("*.mp4"), key=lambda x: x.stat().st_mtime, reverse=True)[:30]]
        result["recent_jobs"] = colab_recap_ui.list_jobs()
        result["auto"] = self._colab_auto.status()
        return result

    def recap_status(self) -> dict:
        self._need_session()
        if not self._colab_recap:
            raise RuntimeError("Recap web mode မဖွင့်ထားပါ။")
        return self._colab_recap.status()

    def recap_save_config(self, settings: dict) -> dict:
        self._need_session()
        if not self._colab:
            raise RuntimeError("Colab-only API")
        import colab_recap_ui
        return colab_recap_ui.save_config(settings)

    def recap_editor_load(self, source: str) -> dict:
        self._need_session()
        import colab_recap_ui
        return colab_recap_ui.load_editor(source)

    def recap_editor_save(self, source: str, settings: dict) -> dict:
        self._need_session()
        import colab_recap_ui
        return colab_recap_ui.save_editor(source, settings)

    def recap_jobs_list(self) -> list[dict]:
        self._need_session()
        import colab_recap_ui
        return colab_recap_ui.list_jobs()

    def recap_jobs_delete(self, paths: list[str]) -> dict:
        self._need_session()
        import colab_recap_ui
        current = self._colab_recap.status()
        return colab_recap_ui.delete_jobs(paths, current.get("job_dir") if current.get("status") in {"running", "starting", "stopping"} else "")

    def recap_script_status(self, source: str) -> dict:
        self._need_session()
        import colab_recap_ui
        return colab_recap_ui.script_status(source)

    def recap_script_save(self, source: str, segment_id: int, text: str) -> dict:
        self._need_session()
        import colab_recap_ui
        return colab_recap_ui.save_script_line(source, segment_id, text)

    def recap_script_export(self, source: str, output_folder: str = "") -> list[dict]:
        self._need_session()
        import colab_recap_ui
        return colab_recap_ui.export_script(source, output_folder)

    def recap_style_preview(self, source: str, style: dict) -> list[dict]:
        self._need_session()
        import colab_recap_ui
        return colab_recap_ui.narration_style_preview(source, style)

    def recap_jobs_save_work_folder(self, path: str) -> dict:
        self._need_session()
        if not self._colab:
            raise RuntimeError("Colab-only API")
        import colab_runtime
        import colab_recap_ui
        destination = Path(path).expanduser().resolve()
        if not self._within_colab_path(destination):
            raise ValueError("Work folder ကို /content အောက်မှာသာ ရွေးပါ။")
        destination.mkdir(parents=True, exist_ok=True)
        config_path = ROOT / "recap_config.json"
        try:
            cfg = json.loads(config_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            cfg = {}
        old = Path(colab_runtime.JOBS).resolve()
        if old != destination.resolve() and old.exists():
            for item in list(old.iterdir()):
                target = destination / item.name
                if target.exists():
                    raise FileExistsError(f"Destination already contains {item.name}")
            import shutil
            for item in list(old.iterdir()):
                shutil.move(str(item), str(destination / item.name))
        colab_runtime.JOBS = destination
        colab_recap_ui.JOBS = destination
        cfg["work_folder"] = str(destination)
        colab_recap_ui._atomic_json(config_path, cfg)
        return {"path": str(destination), "moved": old != destination.resolve()}

    @staticmethod
    def _within_colab_path(path: Path) -> bool:
        from colab_runtime import _within_colab
        return _within_colab(path)

    def recap_auto_status(self) -> dict:
        self._need_session()
        return self._colab_auto.status()

    def recap_auto_channel_add(self, url: str, kind: str = "videos") -> dict:
        self._need_session()
        return self._colab_auto.add_channel(url, kind)

    def recap_auto_channel_remove(self, url: str, kind: str) -> dict:
        self._need_session()
        return self._colab_auto.remove_channel(url, kind)

    def recap_auto_check(self) -> dict:
        self._need_session()
        return self._colab_auto.check_now()

    def recap_auto_start(self, interval: int = 30) -> dict:
        self._need_session()
        return self._colab_auto.start(interval)

    def recap_auto_stop(self) -> dict:
        self._need_session()
        return self._colab_auto.stop()

    def recap_auto_job_complete(self, outputs: list[str], sources: list[str]) -> bool:
        self._need_session()
        self._colab_auto.job_completed(list(outputs or []), list(sources or []))
        return True

    def recap_auto_job_failed(self, sources: list[str], message: str) -> bool:
        self._need_session()
        self._colab_auto._job_failed(list(sources or []), str(message or ""))
        return True

    def recap_auto_tiktok_login(self) -> dict:
        raise RuntimeError("Colab cloud browser မှာ local browser session မရှိပါ။ TikTok Auto mode login ကို Colab မပံ့ပိုးပါ — Manual mode သုံးပါ။")

    def _recap_recent_sources(self) -> list[dict]:
        return []  # Source paths are presented only for the active session; never reconstruct an unsafe host path.

    def recap_preview(self, source_path: str, seconds: float = 1.0, settings: dict | None = None) -> dict:
        if not self._colab_recap:
            raise RuntimeError("Recap web mode မဖွင့်ထားပါ။")
        from colab_runtime import TMP, _validate_source
        from pathlib import Path as _Path
        from shutil import which
        from uuid import uuid4
        import sys as _sys
        recap_app = ROOT / "recap_tool_src" / "app"
        if str(recap_app) not in _sys.path:
            _sys.path.insert(0, str(recap_app))
        from preview_tools import probe_duration, extract_preview_frame
        from core import probe_video_size, output_canvas
        source = _validate_source(str(_Path(source_path).expanduser().resolve()))
        settings = settings or {}
        ffmpeg, ffprobe = which("ffmpeg") or "ffmpeg", which("ffprobe") or "ffprobe"
        duration = probe_duration(ffprobe, str(source))
        size = probe_video_size(ffprobe, source)
        t = max(0.0, min(float(seconds), max(0.0, duration - .05)))
        from colab_recap_ui import load_editor
        overlay = load_editor(str(source))
        overlays = settings.get("overlays") or overlay
        ratio = str(settings.get("output_ratio") or "Original")
        fill = str(settings.get("frame_fill") or "blur")
        quality = str(settings.get("quality") or settings.get("video_quality") or "1080").removesuffix("p")
        zoom = float(settings.get("zoom_factor", 1.05))
        mirror = bool(settings.get("mirror_video", True))
        out_w, out_h = output_canvas(ratio, size[0], size[1], quality)
        req_canvas = settings.get("canvas")
        if isinstance(req_canvas, (list, tuple)) and len(req_canvas) == 2 and int(req_canvas[0]) > 0 and int(req_canvas[1]) > 0:
            pw, ph = int(req_canvas[0]), int(req_canvas[1])
        else:
            max_side = int(settings.get("preview_max_side") or 960)
            scale = min(1.0, max_side / max(1, out_w, out_h))
            pw = max(2, int(round(out_w * scale)) // 2 * 2)
            ph = max(2, int(round(out_h * scale)) // 2 * 2)
        TMP.mkdir(parents=True, exist_ok=True)
        output = TMP / f"recap_preview_{uuid4().hex}.jpg"
        extract_preview_frame(ffmpeg, str(source), t, zoom, mirror, str(output), pw, ph,
                             ratio=ratio, fill=fill, source_size=size)
        return {"path": str(output), "url": f"/api/file?path={str(output)}", "duration": duration,
                "width": size[0], "height": size[1], "output_width": out_w, "output_height": out_h,
                "preview_width": pw, "preview_height": ph, "seconds": t, "overlays": overlays}

    def recap_subtitle_sample(self, source_path: str, ratio: str, settings: dict) -> dict:
        self._need_session()
        from colab_runtime import _validate_source, TMP
        source = _validate_source(source_path)
        import sys
        recap_app = ROOT / "recap_tool_src" / "app"
        if str(recap_app) not in sys.path:
            sys.path.insert(0, str(recap_app))
        from core import output_canvas, probe_video_size
        from subtitle_png import geometry, style, sample
        from shutil import which
        ffprobe = which("ffprobe") or "ffprobe"
        source_size = probe_video_size(ffprobe, source)
        frame = output_canvas(str(ratio or "Original"), *source_size)
        values = style(settings or {})
        out = sample(values, frame, TMP / "subtitle_preview")
        return {"path": str(out), "url": f"/api/file?path={out}", "frame": list(frame),
                "geometry": list(geometry(values, frame)), "position": values["position"]}

    def recap_logo_preview(self, source_path: str, width_fraction: float = .16) -> dict:
        self._need_session()
        from colab_runtime import TMP, _validate_source
        from colab_recap_ui import load_editor
        from colab_runtime import OUTPUTS
        from pathlib import Path as _Path
        from uuid import uuid4
        import sys as _sys
        if str(ROOT / "recap_tool_src" / "app") not in _sys.path:
            _sys.path.insert(0, str(ROOT / "recap_tool_src" / "app"))
        from preview_tools import scale_logo_preview
        from core import probe_video_size
        from shutil import which
        from colab_runtime import _read_config
        from pathlib import Path
        source = _validate_source(source_path)
        overlay=load_editor(str(source))
        path = Path(str(overlay.get("logo_path") or ""))
        if not overlay.get("logo_enabled") or not path.is_file():
            return {"enabled":False,"url":""}
        TMP.mkdir(parents=True,exist_ok=True)
        image=TMP/f"logo_{uuid4().hex}.png"
        size=probe_video_size(which("ffprobe") or "ffprobe", source)
        width=max(24,int(size[0]*max(.05,min(.8,float(width_fraction)))))
        scale_logo_preview(which("ffmpeg") or "ffmpeg",str(path),width,str(image))
        return {"enabled":True,"url":f"/api/file?path={image}","width_fraction":width_fraction,
                "opacity":overlay.get("logo_opacity",.65),"position":overlay.get("logo_position",[.8,.06])}

    def recap_start(self, request: dict) -> dict:
        session = self._need_session()
        if not self._colab_recap:
            raise RuntimeError("Recap web mode မဖွင့်ထားပါ။")
        from colab_recap_ui import save_config, save_editor
        from daily_limits import free_job
        request = dict(request or {})
        state = self._colab_recap.status()
        if state.get("status") in {"starting", "running", "stopping"}:
            raise RuntimeError("Recap job တစ်ခု လုပ်နေဆဲပါ။")
        voice = str(request.get("voice") or request.get("narrator_voice") or "gemini:Charon")
        settings = {**request,
                    "narrator_voice": voice,
                    "edge_tts_rate": request.get("edge_tts_rate", "+0%"),
                    "subtitles": request.get("overlays", {}).get("subtitles", request.get("subtitles_style", {})),
                    "run_mode": "review" if request.get("review_first") else "auto"}
        save_config(settings)
        source = request.get("source_path")
        if source and not request.get("source_paths"):
            try:
                save_editor(str(source), request.get("overlays") or {})
            except Exception:
                pass
        quota_ctx = free_job("recap", session=session)
        return self._colab_recap.start(request, quota_ctx=quota_ctx)

    def recap_stop(self) -> dict:
        self._need_session()
        if not self._colab_recap:
            raise RuntimeError("Recap web mode မဖွင့်ထားပါ။")
        return self._colab_recap.stop()

    def recap_download(self, job_id: str) -> str:
        self._need_session()
        if not self._colab_recap:
            raise RuntimeError("Recap web mode မဖွင့်ထားပါ။")
        return str(self._colab_recap.download_path(job_id))

    def splitter_options(self) -> dict:
        if not self._colab_splitter:
            raise RuntimeError("Splitter web mode မဖွင့်ထားပါ။")
        return self._colab_splitter.options()

    def splitter_status(self) -> dict:
        if not self._colab_splitter:
            raise RuntimeError("Splitter web mode မဖွင့်ထားပါ။")
        return self._colab_splitter.status()

    def splitter_preview(self, source_path: str, seconds: float = 1.0, ratio: str = "Original", fill: str = "blur") -> dict:
        if not self._colab_splitter:
            raise RuntimeError("Splitter web mode မဖွင့်ထားပါ။")
        result = self._colab_splitter.preview(source_path, seconds, ratio, fill)
        return {**result, "url": f"/api/file?path={result['path']}"}

    def splitter_check(self, source_path: str, settings: dict) -> dict:
        if not self._colab_splitter:
            raise RuntimeError("Splitter web mode မဖွင့်ထားပါ။")
        return self._colab_splitter.check(source_path, settings)

    def splitter_start(self, sources: list[str], settings: dict) -> dict:
        self._need_session()
        if not self._colab_splitter:
            raise RuntimeError("Splitter web mode မဖွင့်ထားပါ။")
        return self._colab_splitter.start(sources, settings)

    def splitter_stop(self) -> dict:
        self._need_session()
        if not self._colab_splitter:
            raise RuntimeError("Splitter web mode မဖွင့်ထားပါ။")
        return self._colab_splitter.stop()

    def splitter_save_settings(self, settings: dict) -> bool:
        if not self._colab_splitter:
            raise RuntimeError("Splitter web mode မဖွင့်ထားပါ။")
        self._colab_splitter.save_settings(settings)
        return True

    def dubbing_options(self) -> dict:
        if not self._colab_dubbing:
            raise RuntimeError("Dubbing web mode မဖွင့်ထားပါ။")
        return self._colab_dubbing.options()

    def dubbing_status(self) -> dict:
        if not self._colab_dubbing:
            raise RuntimeError("Dubbing web mode မဖွင့်ထားပါ။")
        return self._colab_dubbing.status()

    def dubbing_start(self, request: dict) -> dict:
        self._need_session()
        if not self._colab_dubbing:
            raise RuntimeError("Dubbing web mode မဖွင့်ထားပါ။")
        return self._colab_dubbing.start(request)

    def dubbing_stop(self) -> dict:
        self._need_session()
        if not self._colab_dubbing:
            raise RuntimeError("Dubbing web mode မဖွင့်ထားပါ။")
        return self._colab_dubbing.stop()

    def subtitle_options(self) -> dict:
        if not self._colab_subtitle:
            raise RuntimeError("Subtitle web mode မဖွင့်ထားပါ။")
        return self._colab_subtitle.options()

    def subtitle_status(self) -> dict:
        if not self._colab_subtitle:
            raise RuntimeError("Subtitle web mode မဖွင့်ထားပါ။")
        return self._colab_subtitle.status()

    def subtitle_start(self, request: dict) -> dict:
        self._need_session()
        if not self._colab_subtitle:
            raise RuntimeError("Subtitle web mode မဖွင့်ထားပါ။")
        return self._colab_subtitle.start(request)

    def subtitle_stop(self) -> dict:
        self._need_session()
        if not self._colab_subtitle:
            raise RuntimeError("Subtitle web mode မဖွင့်ထားပါ။")
        return self._colab_subtitle.stop()

    def storytelling_options(self) -> dict:
        if not self._colab_storytelling:
            raise RuntimeError("Original → Recap web mode မဖွင့်ထားပါ။")
        return self._colab_storytelling.options()

    def storytelling_status(self) -> dict:
        if not self._colab_storytelling:
            raise RuntimeError("Original → Recap web mode မဖွင့်ထားပါ။")
        return self._colab_storytelling.status()

    def storytelling_start(self, request: dict) -> dict:
        self._need_session()
        if not self._colab_storytelling:
            raise RuntimeError("Original → Recap web mode မဖွင့်ထားပါ။")
        return self._colab_storytelling.start(request)

    def storytelling_stop(self) -> dict:
        self._need_session()
        if not self._colab_storytelling:
            raise RuntimeError("Original → Recap web mode မဖွင့်ထားပါ။")
        return self._colab_storytelling.stop()

    def colab_list_videos(self, folder: str) -> dict:
        if not self._colab:
            raise RuntimeError("Colab-only API")
        from colab_runtime import _within_colab
        path = Path(folder).expanduser().resolve()
        content = Path("/content").resolve()
        if not path.is_dir() or not _within_colab(path):
            raise ValueError("/content အောက်က video folder ကိုသာ ဖွင့်ပါ။")
        extensions = {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v"}
        found = sorted((p for p in path.iterdir() if p.is_file() and p.suffix.lower() in extensions),
                       key=lambda p: p.name.casefold())
        return {"files": [{"path": str(p.resolve()), "name": p.name} for p in found]}

    def ui_error(self, details: dict) -> bool:

        if self._ui_health:
            self._ui_health.record("javascript_error", details=details)
        return True

    # ------------------------------------------------------------------ plumbing
    def _emit(self, kind: str, **data) -> None:
        payload = {"kind": kind, **data}
        if self._colab:
            with self._web_clients_lock:
                self._web_event_id += 1
                self._web_events.append({"id": self._web_event_id, "event": payload})
                self._web_events = self._web_events[-2000:]
            return
        if self._window is None:
            return
        encoded = json.dumps(payload, ensure_ascii=False, default=str)
        try:
            self._window.evaluate_js(f"window.S99 && S99.onEvent({encoded})")
        except Exception:  # noqa: BLE001  (window closing)
            pass

    def _user(self) -> dict:
        s = self._session
        if s is None:
            return {}
        until = s.vip_until()
        return {"email": s.email, "vip": s.is_vip, "days_left": s.vip_days_left,
                "membership_tier": s.membership_tier, "vip_plus": s.is_vip_plus, "vip_label": s.vip_label,
                "vip_until": until.strftime("%Y-%m-%d") if until else "", "was_vip": s.user.get("is_vip") is True,
                "vip_until_at": s.vip_until_at, "vip_left": s.vip_left}

    def _need_session(self) -> Session:
        if self._closing_event.is_set():
            raise RuntimeError("Studio99 ပိတ်နေပါတယ်။")
        if self._session is None:
            raise RuntimeError("Login ပြန်ဝင်ပါ")
        return self._session

    def _accept_account(self, expected: Session, current: Session) -> Session:
        with self._account_lock:
            if self._session is not expected:
                raise RuntimeError("Account ပြောင်းသွားပါပြီ။ ပြန်စစ်ပါ။")
            self._session, self._fresh_at = current, time.monotonic()
        self._enforce_posting_access()
        return current

    def _refused_account(self, expected: Session, error: AuthError) -> None:
        with self._account_lock:
            if self._session is not expected:
                return
            if not isinstance(error, UpdateRequired):
                token_store.clear()
            self._session, self._fresh_at = None, 0.0
            self._notification_inbox = None
            self._enforce_posting_access()
            self._stop_jobs()
            self._emit("logged_out", message=str(error))

    def _fresh_session(self, force: bool = False) -> Session:
        """The account as the server has it NOW (at most FRESH_SECONDS old) before something VIP starts: the
        6-hourly refresh let an ended VIP / a ban / a stopped build start new work for hours (2026-10-31).
        No answer keeps the last state (as offline always did); a refusal logs out with its reason."""
        session = self._need_session()
        if self._local:                          # no server to ask: the local session is always current
            return session
        if not force and time.monotonic() - self._fresh_at < FRESH_SECONDS:
            return session
        try:
            current = self._pb.notification_account(session)
            self._pb.check_build(current.token)
        except ServerUnreachable:
            if self._session is not session:
                raise RuntimeError("Account ပြောင်းသွားပါပြီ။ ပြန်စစ်ပါ။")
            return session
        except AuthError as exc:
            self._refused_account(session, exc)
            raise
        return self._accept_account(session, current)

    def _need_vip(self, fresh: bool = False) -> None:
        if not (self._fresh_session() if fresh else self._need_session()).is_vip:
            raise RuntimeError("ဒီ tool က VIP member တွေအတွက်ပါ — Profile မှာ VIP သက်တမ်း ကြည့်ပါ")

    def _need_vip_plus(self, fresh: bool = False) -> None:
        if (self._fresh_session() if fresh else self._need_session()).is_vip_plus is not True:
            self._enforce_posting_access()
            raise RuntimeError("ဒီ feature က VIP+ member တွေအတွက်ပါ — Profile မှာ သက်တမ်း / tier စစ်ပါ။")

    def _enforce_posting_access(self) -> None:
        if self._posting_started and not (self._session and self._session.is_vip_plus):
            engine_runner.stop()
            self._posting_started = False
        self._enforce_vip_tools()

    def _enforce_vip_tools(self) -> None:
        """VIP ended while VIP tool windows were open (2026-10-30, user: the job in hand finishes, then they close):
        nothing new opens (open_tool / tool_show), a busy tool keeps running, an idle one (tool_busy, ~3 min quiet)
        is closed. Runs every 30 s and after every account poll; a renewal stops it."""
        s = self._session
        if s is None or s.is_vip:
            self._vip_end_told = False
            return
        if not self._vip_end_told:
            self._vip_end_told = True
            self._emit("vip_ended", user=self._user(),
                       message="VIP သက်တမ်း ကုန်သွားပါပြီ — လုပ်နေတဲ့ job ပြီးရင် VIP tool တွေကို ပိတ်ပါမယ်။")
        for tool_id in VIP_WINDOW_TOOLS:
            proc = self._tool_proc(tool_id)
            if proc is None or proc.poll() is not None:
                continue
            if self._busy.idle(proc.pid):
                self._busy.forget(proc.pid)
                self.tool_close(tool_id)
                title = next((t.title for t in TOOLS if t.id == tool_id), tool_id)
                self._emit("vip_tool_closed", tool=tool_id,
                           message=f"{title} ကို ပိတ်လိုက်ပါပြီ — VIP သက်တမ်း ကုန်ပြီး job မရှိတော့လို့ပါ။")

    # ------------------------------------------------------------------ account
    def init(self) -> dict:
        if self._local:                          # no login screen, no server round-trip
            self._watch_session()                # returns immediately in local mode
            self._resume_auto()
            return {"logged_in": True, "last_email": self._session.email, "user": self._user(),
                    "local_mode": True}
        saved = token_store.load()
        out = {"logged_in": False, "last_email": self._cfg.get("last_email", "")}
        if saved:
            try:
                self._session = self._pb.refresh(saved["token"])
                token_store.save(self._session.token, self._session.email)
                out.update(logged_in=True, user=self._user())
                self._resume_auto()
            except ServerUnreachable as exc:              # offline: keep the saved login, offer "try again"
                out.update(offline=True, message=str(exc))
            except UpdateRequired as exc:                 # this build was stopped: the login stays for the new one
                out.update(message=str(exc))
            except AuthError as exc:                      # refused (banned, another PC has the account …)
                token_store.clear()
                out.update(message=str(exc))
            except Exception:  # noqa: BLE001  (expired → login page)
                token_store.clear()
        self._watch_session()
        return out

    def _watch_session(self) -> None:
        """Every 6 hours the login is checked again (VIP end, a ban, the admin moving the account to another
        PC); a refused one goes back to the login page with the reason. No answer keeps the session."""
        if self._local or getattr(self, "_watching", False):
            return                               # local mode: nothing to poll, nothing can refuse the account
        self._watching = True

        def run() -> None:
            checked = time.monotonic()
            while not self._closing_event.wait(30):
                self._enforce_posting_access()
                if self._session is not None:
                    try:
                        self._fresh_session()  # build/ban checks also run when the UI is minimized
                    except (RuntimeError, ServerUnreachable):
                        continue
                if time.monotonic() - checked < 6 * 3600:
                    continue
                checked = time.monotonic()
                if self._session is None:
                    continue
                try:
                    expected = self._need_session()
                    current = self._pb.refresh(expected.token)
                    with self._account_lock:
                        self._accept_account(expected, current)
                        if token_store.load():
                            token_store.save(current.token, current.email)
                except ServerUnreachable:
                    continue
                except AuthError as exc:
                    self._refused_account(expected, exc)
                except Exception:  # noqa: BLE001
                    continue
        threading.Thread(target=run, daemon=True).start()

    def login(self, email: str, password: str, remember: bool = True) -> dict:
        if "@" not in str(email) or len(str(password)) < 8:
            raise AuthError("Email နဲ့ Password (အနည်းဆုံး ၈ လုံး) ဖြည့်ပါ။")
        current = self._pb.login(email, password)
        with self._account_lock:
            self._session, self._fresh_at = current, 0.0
            self._notification_inbox = None
        self._cfg["last_email"] = self._session.email
        save_config(self._cfg)
        if remember:
            token_store.save(self._session.token, self._session.email)
        else:
            token_store.clear()
        self._resume_auto()
        return self._user()

    def _resume_auto(self) -> None:
        """Desktop resumes configured jobs; Colab explicitly disables this for ephemeral public sessions."""
        if self._colab:
            return  # Colab notebooks are ephemeral; never resume posting/schedulers automatically.
        if not (self._session and self._session.is_vip):
            return
        try:
            cfg = json.loads((ROOT / "recap_config.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            cfg = {}

        def run() -> None:
            try:
                if cfg.get("recap_mode") == "auto" and cfg.get("auto_running"):
                    self._open_tk("recap")
                if self._session and self._session.is_vip_plus and any(r.get("enabled") for r in engine_runner.destinations(enabled_only=False)) \
                        and not engine_runner.running():
                    engine_runner.start()
                    self._posting_started = True
            except Exception:  # noqa: BLE001 - the user can still start both by hand
                LOGS.mkdir(exist_ok=True)
                (LOGS / "app.log").open("a", encoding="utf-8").write(traceback.format_exc())
        threading.Thread(target=run, daemon=True).start()

    def register(self, email: str, password: str) -> str:
        if "@" not in str(email) or len(str(password)) < 8:
            raise AuthError("Email နဲ့ Password (အနည်းဆုံး ၈ လုံး) ဖြည့်ပါ။")
        self._pb.register(email, password)
        return "အကောင့် ဖွင့်ပြီးပါပြီ။ Email ထဲက link ကို နှိပ်ပြီး အတည်ပြုပါ၊ ပြီးမှ Login ဝင်ပါ။"

    def forgot(self, email: str) -> str:
        if "@" not in str(email):
            raise AuthError("Email ကို အရင် ဖြည့်ပါ။")
        self._pb.request_password_reset(email)
        return "Password ပြန်သတ်မှတ်ဖို့ link ကို email ထဲ ပို့ပြီးပါပြီ။"

    def logout(self) -> bool:
        if self._local:
            return False                         # local mode has no account to sign out of
        with self._account_lock:
            token_store.clear()
            self._session, self._fresh_at = None, 0.0
            self._enforce_posting_access()
            self._notification_inbox = None
            self._stop_jobs()
        return True

    def refresh(self) -> dict:
        if self._local:
            return self._user()
        expected = self._need_session()
        try:
            self._accept_account(expected, self._pb.refresh(expected.token))
        except AuthError as exc:
            self._refused_account(expected, exc)
            raise
        return self._user()

    # ------------------------------------------------------------------ in-app notifications (no OS push)
    def _inbox(self, session: Session) -> NotificationInbox:
        identity = (self._pb.base.rstrip("/"), str(session.user.get("id") or ""))
        with self._notification_lock:
            if self._notification_inbox is None or self._notification_inbox.identity != identity:
                self._notification_inbox = NotificationInbox(*identity)
            return self._notification_inbox

    def notifications(self, refresh: bool = False) -> dict:
        session = self._need_session()
        if self._local:                          # announcements live on the server: none offline
            return {"items": [], "unread": 0, "checked_at": "", "error": "", "user": self._user()}
        inbox = self._inbox(session)
        try:
            result, current = inbox.sync(self._pb, session, force=bool(refresh))
        except AuthError as exc:
            self._refused_account(session, exc)
            raise
        # A request from a signed-out account must not update a new account's UI or membership.
        with self._account_lock:
            if self._session is not session or self._notification_inbox is not inbox:
                raise RuntimeError("Account ပြောင်းသွားပါပြီ။ နိုတီ ပြန်စစ်ပါ။")
            if current is not None:
                session.user.update(current.user)
                session.server_offset = current.server_offset
                self._enforce_posting_access()
        return {**result, "user": self._user()}

    def notifications_read(self, ids: list[str]) -> dict:
        return self._inbox(self._need_session()).mark_read(ids)

    def open_url(self, url: str) -> bool:
        if str(url).startswith(("https://", "http://")):
            webbrowser.open(url)
        return True

    # ------------------------------------------------------------------ home
    def tools(self) -> list[dict]:
        return [{"id": t.id, "title": t.title, "sub": t.subtitle, "color": t.color, "vip": t.vip,
                 "vip_plus": t.vip_plus, "tier_label": t.tier_label,
                 "soon": t.status != "ready",
                 "locked": False if self._colab and local_mode.enabled() else not t.allowed(self._session)}
                for t in TOOLS]

    def stats(self) -> dict:
        at, cached = self._stats_cache
        if time.time() - at < 60 and cached:
            data = dict(cached)
        else:
            with self._storage_lock:
                # A separate scanner keeps the user's Storage confirmation valid.
                size = Storage().scan(self._storage_roots())["bytes"]
            data = {"storage_gb": round(size / 1024 ** 3, 1)}
            self._stats_cache = (time.time(), data)
        data["made"] = history.this_month()
        data["next_post"] = self._next_post()
        data["posting"] = engine_runner.running()
        if self._session:
            from daily_limits import status
            data["daily_usage"] = {"unlimited": True, "used": 0, "remaining": None} if self._colab and self._local else status(self._session)
        return data

    def _recap_jobs_dir(self) -> Path:
        if self._colab:
            from colab_runtime import JOBS
            return JOBS
        try:
            cfg = json.loads((ROOT / "recap_config.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            cfg = {}
        return Path(cfg.get("work_folder") or ROOT / "recap_tool_src" / "jobs")

    def _story_root(self) -> Path:
        from story_motion.project import DEFAULT_ROOT
        if self._colab:
            from colab_runtime import DATA
            return DATA / "story_motion"
        return Path(self._cfg.get("story_motion_folder") or DEFAULT_ROOT)

    def _next_post(self) -> str:
        if not engine_runner.running():
            return ""
        try:
            import urllib.request
            with urllib.request.urlopen(engine_runner.URL + "api/live-schedule", timeout=3) as r:
                data = json.loads(r.read().decode("utf-8"))
        except Exception:  # noqa: BLE001
            return ""
        times = []

        def walk(value, key=""):
            if isinstance(value, dict):
                for k, v in value.items():
                    walk(v, k)
            elif isinstance(value, list):
                for v in value:
                    walk(v, key)
            elif isinstance(value, str) and key in ("next_at", "next_start", "eta", "estimated_start", "start_at"):
                times.append(value)
        walk(data)
        future = sorted(t for t in times if t[:16] >= time.strftime("%Y-%m-%dT%H:%M"))
        return future[0][11:16] if future else ""

    def open_tool(self, tool_id: str) -> dict:
        tool = next((t for t in TOOLS if t.id == tool_id), None)
        if tool is None:
            raise RuntimeError("Unknown tool")
        self._need_session()
        if not (self._colab and local_mode.enabled()):
            if tool.vip_plus:
                self._need_vip_plus(fresh=True)
            elif tool.vip:
                self._need_vip(fresh=True)
        if self._colab and tool_id in {"recap", "splitter", "dubbing", "subtitle", "storytelling"}:
            return {"kind": "page", "page": f"{tool_id}_web"}
        if self._colab and tool_id in WEB_PAGES:
            return {"kind": "page", "page": tool_id}
        if tool.status != "ready":
            return {"kind": "soon"}
        if tool_id in WEB_PAGES:
            return {"kind": "page", "page": tool_id}
        if tool_id in TK_TOOLS or tool_id in tool_apps.WINDOW_TOOLS:
            if self._colab:
                if tool_id in {"recap", "splitter"}:
                    return {"kind": "page", "page": f"{tool_id}_web"}
                raise RuntimeError("ဒီ native-window tool ကို Colab မှာ မပံ့ပိုးသေးပါ။")
            if tool_id in tool_apps.WINDOW_TOOLS and not tool_apps.available(tool_id):
                raise RuntimeError("Tool ဖိုင်တွေ မတွေ့ပါ — tools/sync_tools.py ကို run ပါ")
            self._launch_window_tool(tool_id)
            ai = tool_id in ai_extras.TOOLS and not ai_extras.installed() and self._ai.start()   # first use
            return {"kind": "embed", "tool": tool_id, "title": tool.title, "no_keys": not keys_file.gemini_keys(),
                    "ai_download": bool(ai)}
        return {"kind": "soon"}

    # ------------------------------------------------------------------ AI extras (torch) for the exe — ai_extras.py
    def ai_status(self) -> dict:
        return self._ai.status()

    def ai_install(self) -> dict:
        self._ai.start()
        return self._ai.status()

    def _check_ffmpeg(self) -> None:
        """FFmpeg ships in the installer; when it is missing it is downloaded once (ai_extras.ensure_ffmpeg)."""
        time.sleep(3)                                        # let the page load first (it shows the progress)
        try:
            if ai_extras.ensure_ffmpeg(lambda p, m: self._emit("ffmpeg", percent=round(p), message=m)):
                self._emit("ffmpeg", percent=100, message="FFmpeg ရပါပြီ", done=True)
        except Exception as exc:  # noqa: BLE001
            self._emit("ffmpeg", error=f"FFmpeg ဒေါင်းလို့ မရပါ — internet / VPN စစ်ပြီး app ကို ပြန်ဖွင့်ပါ ({exc})")

    def ai_stop(self) -> bool:
        self._ai.stop()
        return True

    # ------------------------------------------------------------------ encode speed of the copied tools
    def tool_speed(self, tool_id: str) -> dict:
        import ffmpeg_speed
        return {"level": ffmpeg_speed.level(tool_id), "labels": ffmpeg_speed.LABELS}

    def tool_speed_set(self, tool_id: str, level: str) -> dict:
        import ffmpeg_speed
        ffmpeg_speed.save(tool_id, level)
        return self.tool_speed(tool_id)

    # ------------------------------------------------------------------ tools shown inside this window (embed.py)
    def _launch_window_tool(self, tool_id: str) -> None:
        if tool_id in TK_TOOLS:
            self._open_tk(tool_id)
        elif tool_apps.launch(tool_id, token=self._need_session().token, server=self._pb.base):
            self._embed_soon(tool_id)

    def _embed_soon(self, tool_id: str) -> None:
        """Take the new tool window into this window as soon as it shows (hidden until its page asks for it)."""
        threading.Thread(target=self._ensure_embedded, args=(tool_id,), daemon=True).start()

    def _ensure_embedded(self, tool_id: str) -> int:
        import embed
        with self._embed_lock:
            hwnd = self._embedded.get(tool_id, 0)
            proc = self._tool_proc(tool_id)
            if embed.alive(hwnd) or tool_id in self._detached or proc is None or proc.poll() is not None:
                return hwnd
            hwnd = embed.wait_for_window(proc.pid, timeout=120)
            parent = embed.own_main_window()
            if not hwnd or not parent:
                return 0
            embed.attach(hwnd, parent)
            if self._active_tool != tool_id:
                embed.hide(hwnd)
            self._embedded[tool_id] = hwnd
            return hwnd

    def _tool_proc(self, tool_id: str):
        return self._tk.get(tool_id) if tool_id in TK_TOOLS else tool_apps._running.get(tool_id)

    def tool_show(self, tool_id: str, rect: dict) -> dict:
        """Put the tool's window over the page's tool area (starting the tool when it is not running)."""
        import embed
        self._need_session()
        if tool_id in VIP_WINDOW_TOOLS:
            self._need_vip(fresh=True)
        proc = self._tool_proc(tool_id)
        if proc is None or proc.poll() is not None:
            if tool_id in VIP_WINDOW_TOOLS:              # starting it again is a new open: VIP first
                self._need_vip(fresh=True)
            self._embedded.pop(tool_id, None)
            self._detached.discard(tool_id)
            self._launch_window_tool(tool_id)
            proc = self._tool_proc(tool_id)
        if tool_id in self._detached:
            return {"ok": True, "detached": True}
        self._active_tool = tool_id
        hwnd = self._ensure_embedded(tool_id)
        if not hwnd:
            return {"ok": False, "message": "Tool window မပေါ်လာပါ — logs ကို ကြည့်ပါ"}
        if self._active_tool != tool_id:                 # the user went to another page meanwhile
            embed.hide(hwnd)
            return {"ok": True}
        for other, h in self._embedded.items():          # only one tool over the page at a time
            if other != tool_id and other not in self._detached:
                embed.hide(h)
        embed.place(hwnd, rect["x"], rect["y"], rect["w"], rect["h"])
        return {"ok": True}

    def tool_rect(self, tool_id: str, rect: dict) -> bool:
        import embed
        hwnd = self._embedded.get(tool_id)
        if hwnd and tool_id not in self._detached and self._active_tool == tool_id and embed.alive(hwnd):
            embed.place(hwnd, rect["x"], rect["y"], rect["w"], rect["h"])
        return True

    def tools_hide(self) -> bool:
        import embed
        for tool_id, hwnd in self._embedded.items():
            if tool_id not in self._detached and embed.alive(hwnd):
                embed.hide(hwnd)
        self._active_tool = ""
        return True

    def tool_detach(self, tool_id: str) -> bool:
        """The tool as its own window again (title bar, taskbar)."""
        import embed
        hwnd = self._embedded.get(tool_id)
        if hwnd and embed.alive(hwnd):
            embed.detach(hwnd)
            self._detached.add(tool_id)
        return True

    def tool_attach(self, tool_id: str, rect: dict) -> dict:
        self._detached.discard(tool_id)
        self._embedded.pop(tool_id, None)
        return self.tool_show(tool_id, rect)

    def tool_close(self, tool_id: str) -> bool:
        proc = self._tool_proc(tool_id)
        if proc is not None and proc.poll() is None:
            from web_tool_job import stop_process
            stop_process(proc)
        self._embedded.pop(tool_id, None)
        self._detached.discard(tool_id)
        if self._active_tool == tool_id:
            self._active_tool = ""
        return True

    def tool_running(self, tool_id: str) -> bool:
        proc = self._tool_proc(tool_id)
        return proc is not None and proc.poll() is None

    def _open_tk(self, tool_id: str, source: str = "") -> None:
        proc = self._tk.get(tool_id)
        if proc is not None and proc.poll() is None:
            if source:                                    # the open Recap window picks it up (tk_tool.py inbox)
                (token_store.APP_DIR / f"{tool_id}_inbox.txt").write_text(source, encoding="utf-8")
            return
        keys_file.write()
        (token_store.APP_DIR / f"{tool_id}_inbox.txt").unlink(missing_ok=True)     # not an old one from last time
        env = dict(os.environ, PYTHONUTF8="1", STUDIO99_TOKEN=self._need_session().token, STUDIO99_EMBED="1")
        if self._local:
            env["STUDIO99_LOCAL"] = "1"           # the tool skips its own server check
        args = [pythonw(), "-X", "utf8", str(APP / "tk_tool.py"), tool_id] + (["--source", source] if source else [])
        LOGS.mkdir(exist_ok=True)
        with open(LOGS / f"{tool_id}.log", "ab") as log:
            self._tk[tool_id] = subprocess.Popen(args, cwd=str(APP), env=env, stdout=log, stderr=subprocess.STDOUT,
                                                 creationflags=NO_WINDOW)
        self._embedded.pop(tool_id, None)
        self._embed_soon(tool_id)

    def running_windows(self) -> list[str]:
        names = {t.id: t.title for t in TOOLS}
        out = [names.get(k, k) for k, p in self._tk.items() if p.poll() is None]
        out += [names.get(k, k) for k in tool_apps.running_titles()]
        return out

    # ------------------------------------------------------------------ profile
    def open_help(self, destination: str) -> bool:
        """Public help is available before login, including an unreachable server."""
        if destination not in HELP_LINKS:
            raise ValueError("Unknown help link")
        return bool(webbrowser.open(HELP_LINKS[destination]))

    def _storage_roots(self) -> list[dict]:
        roots = [("recap", "Recap work files", self._recap_jobs_dir()),
                 ("story", "Story Motion projects", self._story_root()),
                 ("downloads", "Movie Search downloads", self._download_dir()),
                 ("channel", "Recap channel downloads", token_store.APP_DIR / "downloads"),
                 ("lts", "Long to Short", ROOT / "tool_apps" / "long_to_short" / "outputs"),
                 ("review", "Movie Review", ROOT / "tool_apps" / "movie_review" / "output")]
        # These copied tools can save outside the installation folder.
        for kind, title, setting, fallback in (
                ("storytelling", "Original → Recap", "config.json", "outputs"),
                ("dubbing", "Dubbing", "last_config.json", "outputs"),
                ("subtitle", "Subtitle", "ui_settings.json", "outputs"),
                ("novel", "Novel", "config/novel.json", "outputs")):
            base = ROOT / "tool_apps" / kind
            try:
                cfg = json.loads((base / setting).read_text(encoding="utf-8"))
            except (OSError, ValueError):
                cfg = {}
            raw = cfg.get("output_root") or cfg.get("output_dir") or cfg.get("output") or fallback
            roots.append((kind, title, base / raw))
        return [{"id": kind, "title": title, "path": Path(path)} for kind, title, path in roots]

    def _storage_protected(self) -> list[str]:
        paths = [x.get("path", "") for x in history.load()]
        for item in posting_queue.load():
            paths.append(item.get("video", ""))
            paths.extend(item.get("images") or [])
        return paths

    def _storage_busy(self) -> bool:
        import web_novel
        import web_review
        return bool(self.running_windows() or self._story.busy or engine_runner.running()
                    or (self._lts and self._lts.proc and self._lts.proc.poll() is None)
                    or any(job and job.running for job in (web_novel._job, web_review._job))
                    or any(d.get("status") in {"queued", "starting", "downloading"} for d in self._downloads.values()))

    def storage_info(self) -> dict:
        with self._storage_lock:
            data = self._storage.scan(self._storage_roots(), self._storage_protected())
        data["busy"] = self._storage_busy()
        return data

    def storage_clear(self, token: str, selected: list[str]) -> dict:
        with self._storage_lock:
            if self._storage_busy():
                raise RuntimeError("ဖွင့်ထားတဲ့ tool တွေ၊ download နဲ့ Auto Posting ကို အရင်ရပ်/ပိတ်ပြီးမှ cache ရှင်းပါ။")
            result = self._storage.clear(token, selected, self._storage_roots(), self._storage_protected())
            self._stats_cache = (0.0, {})
            return result

    def keys(self) -> dict:
        return keys_file.status()

    def save_keys(self, gemini_text, fal, tmdb=None, custom_api=None) -> dict:
        """None keeps what is saved; text replaces it."""
        return keys_file.save(gemini_text, fal, tmdb, custom_api=custom_api)

    def test_custom_api(self, mode: str, base_url: str, api_key: str, model: str) -> dict:
        self._need_session()
        import custom_llm_client
        saved = token_store.load_keys()
        eff_key = str(api_key or "").strip() or str(saved.get("api_key") or "").strip() or (keys_file.gemini_keys()[0] if keys_file.gemini_keys() else "")
        eff_model = str(model or "").strip()
        if not eff_model:
            raw_m = str(saved.get("api_models") or "").strip()
            eff_model = next((m.strip() for m in raw_m.replace("\n", ",").split(",") if m.strip()), "")
        return custom_llm_client.test_connection(mode, base_url, eff_key, eff_model)

    def connection(self) -> dict:
        gpu = ""
        try:
            out = subprocess.run(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"], capture_output=True,
                                 text=True, timeout=5, creationflags=NO_WINDOW)
            gpu = out.stdout.strip().splitlines()[0] if out.returncode == 0 and out.stdout.strip() else ""
        except Exception:  # noqa: BLE001
            pass
        return {"network": "System / External VPN", "gpu": gpu, "keys": len(keys_file.gemini_keys())}

    def folders(self) -> dict:
        return {"recap_work": str(self._recap_jobs_dir()), "story": str(self._story_root()),
                "downloads": str(self._download_dir())}

    def choose_folder(self, title: str = "") -> str:
        result = self._window.create_file_dialog(webview.FOLDER_DIALOG)
        return str(result[0]) if result else ""

    def choose_file(self, kind: str = "video") -> str:
        types = {"video": ("Video (*.mp4;*.mkv;*.mov;*.webm;*.m4v)", "All files (*.*)"),
                 "audio": ("Audio (*.mp3;*.wav;*.m4a;*.aac;*.ogg)", "All files (*.*)"),
                 "image": ("Images (*.png;*.jpg;*.jpeg;*.webp;*.bmp)", "All files (*.*)")}.get(kind, ("All files (*.*)",))
        result = self._window.create_file_dialog(webview.OPEN_DIALOG, file_types=types)
        return str(result[0]) if result else ""

    def choose_files(self, kind: str = "video") -> list[str]:
        """Several videos at once (Send to Auto Posting → own files); they keep the order the dialog gives."""
        types = ("Video (*.mp4;*.mkv;*.mov;*.webm;*.m4v)", "All files (*.*)")
        result = self._window.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=True, file_types=types)
        return sorted(str(x) for x in result) if result else []

    def set_folder(self, kind: str, path: str) -> dict:
        if self._colab:
            raise RuntimeError("Colab တွင် Studio99Data ဖိုင်တွဲကို အလိုအလျောက်သုံးထားပါတယ်။")
        if kind == "story":
            self._cfg["story_motion_folder"] = path
            save_config(self._cfg)
        elif kind == "downloads":
            self._cfg["download_folder"] = path
            save_config(self._cfg)
        return self.folders()

    def open_folder(self, path: str) -> bool:
        if self._colab or os.name != "nt":
            return True
        p = Path(path)
        if p.is_file():
            subprocess.run(["explorer", "/select,", str(p)], creationflags=NO_WINDOW)
        elif p.is_dir():
            os.startfile(p)
        return True

    # ------------------------------------------------------------------ story motion (web_story.StoryJobs)
    def sm_options(self) -> dict:
        self._need_vip()
        return self._story.options(self._cfg)

    def sm_projects(self) -> list[dict]:
        self._need_vip()
        return self._story.projects(self._story_root())

    def sm_load(self, folder: str) -> dict:
        self._need_vip()
        return self._story.load(folder)

    def sm_numbers(self, settings: dict) -> dict:
        self._need_vip()
        return self._story.numbers(settings)

    def sm_write(self, settings: dict, folder: str = "") -> bool:
        self._need_vip(fresh=True)
        self._cfg["story_motion_last"] = {k: v for k, v in settings.items() if k != "idea"}
        save_config(self._cfg)
        return self._story.write(settings, folder, self._story_root())

    def sm_save_scene(self, folder: str, index: int, narration: str, prompt: str) -> dict:
        self._need_vip()
        return self._story.save_scene(folder, index, narration, prompt)

    def sm_save_title(self, folder: str, title: str) -> bool:
        self._need_vip()
        return self._story.save_title(folder, title)

    def sm_image(self, folder: str, index: int) -> str:
        self._need_vip()
        return self._story.image(folder, index)

    def sm_paste_image(self, folder: str, index: int, data_url: str) -> str:
        self._need_vip()
        return self._story.set_image_data(folder, index, data_url)

    def sm_choose_image(self, folder: str, index: int) -> str:
        self._need_vip()
        path = self.choose_file("image")
        return self._story.set_image_file(folder, index, path) if path else ""

    def sm_load_folder(self, folder: str) -> int:
        self._need_vip()
        source = self.choose_folder()
        return self._story.load_folder(folder, source) if source else 0

    def sm_load_folder_path(self, folder: str, source: str) -> int:
        self._need_vip()
        if self._colab and source and not self._within_colab_path(Path(source)):
            raise ValueError("/content အောက်က folder ကိုသာ ရွေးပါ။")
        return self._story.load_folder(folder, source) if source else 0

    def sm_fal(self, folder: str) -> bool:
        self._need_vip(fresh=True)
        return self._story.fal_missing(folder)

    def sm_open_site(self, name: str) -> bool:
        self._need_vip()
        from story_motion import images
        images.open_site(name)
        return True

    def sm_voice_test(self, folder: str) -> bool:
        self._need_vip(fresh=True)
        return self._story.voice_test(folder)

    def sm_own_voice(self, folder: str) -> bool:
        self._need_vip(fresh=True)
        return self._story.own_voice(folder, auth_env={"STUDIO99": "1", "STUDIO99_TOKEN": self._session.token,
                                                     "STUDIO99_SERVER": self._pb.base,
                                                     **({"STUDIO99_LOCAL": "1"} if self._local else {})})

    def sm_make(self, folder: str, opts: dict) -> bool:
        self._need_vip(fresh=True)
        from own_voice import VoiceStore
        if VoiceStore(Path(folder)).read().get("enabled"):
            self._need_vip()
        self._cfg["story_motion_video"] = opts
        save_config(self._cfg)
        return self._story.make_video(folder, opts)

    def sm_stop(self) -> bool:
        self._story.stop = True
        return True

    # ------------------------------------------------------------------ long to short
    def lts_options(self) -> dict:
        import lts_runner
        saved = self._cfg.get("long_to_short") or {}
        return {"profiles": lts_runner.PROFILES, "modes": [(k, label) for k, label, _t in lts_runner.MODES],
                "saved": saved}

    def lts_start(self, opts: dict) -> bool:
        self._need_session()
        import lts_runner
        if self._lts is not None:
            return False
        opts = dict(opts)
        opts.update(lts_runner.normalize_export_options(
            opts.get("subtitles_enabled", True), opts.get("output_ratio", "9:16"), opts.get("clip_minutes")))
        self._cfg["long_to_short"] = opts
        save_config(self._cfg)
        job = self._lts = lts_runner.LtsJob()

        def run():
            try:
                clips = job.run(opts.get("source", ""), modes=list(opts.get("modes") or []),
                                profile=opts.get("profile", "generic"), count=int(opts.get("count") or 3),
                                out_folder=opts.get("out_folder", ""), delete_work=bool(opts.get("delete_work", True)),
                                subtitles_enabled=opts["subtitles_enabled"], output_ratio=opts["output_ratio"],
                                clip_minutes=opts["clip_minutes"],
                                log=lambda line: self._emit("lts_log", line=line))
                self._emit("lts_done", clips=[str(c) for c in clips])
            except Exception as exc:  # noqa: BLE001
                self._emit("lts_error", message=str(exc))
            finally:
                self._lts = None
        threading.Thread(target=run, daemon=True).start()
        return True

    def lts_stop(self) -> bool:
        if self._lts is not None:
            self._lts.stop()
        return True

    # ------------------------------------------------------------------ movie search
    def _download_dir(self) -> Path:
        if self._colab:
            from colab_runtime import DATA
            path = DATA / "downloads"
        else:
            path = Path(self._cfg.get("download_folder") or Path.home() / "Videos" / "Studio99 Downloads")
        path.mkdir(parents=True, exist_ok=True)
        return path

    def ms_search(self, source: str, query: str, page: int = 1) -> list[dict]:
        import movie_search
        return movie_search.search(source, query, int(page or 1))

    def ms_preview(self, item: dict) -> dict:
        import movie_search
        return movie_search.preview(item)

    def ms_logged_in(self) -> dict:
        import movie_search
        return {s: movie_search.logged_in(s) for s in ("douyin", "rednote")}

    def ms_login(self, source: str) -> bool:
        import movie_search
        movie_search.open_login(source)          # returns when the user closes the window
        return movie_search.logged_in(source)

    def ms_download(self, item: dict, quality: int = 1080, after: str = "folder") -> str:
        import movie_search
        session = self._need_session()
        job_id = f"d{int(time.time() * 1000)}"
        state = {"id": job_id, "title": item.get("title", ""), "source": item.get("source"), "percent": 0,
                 "status": "queued", "path": "", "stop": False}
        self._downloads[job_id] = state
        self._emit("dl", job=self._public_job(state))

        def run():
            last = [0.0]

            def progress(p):
                state.update(status="downloading", percent=p.get("percent", 0), speed=p.get("speed", 0))
                if time.time() - last[0] > 0.5 or p.get("status") == "finished":
                    last[0] = time.time()
                    self._emit("dl", job=self._public_job(state))
            try:
                from daily_limits import free_job
                with free_job("download", session=session):
                    path = movie_search.download(item, self._download_dir(), int(quality or 1080), progress,
                                                 stop=lambda: state["stop"])
                state.update(status="done", percent=100, path=str(path))
                if after == "recap":
                    if self._colab:
                        self._emit("recap_open_source", path=str(path))
                    else:
                        self._open_tk("recap", str(path))
                    state["status"] = "recap"
            except Exception as exc:  # noqa: BLE001
                state.update(status="error", error=str(exc))
            self._emit("dl", job=self._public_job(state))
        threading.Thread(target=run, daemon=True).start()
        return job_id

    @staticmethod
    def _public_job(state: dict) -> dict:
        return {k: v for k, v in state.items() if k != "stop"}

    def ms_downloads(self) -> list[dict]:
        return [self._public_job(s) for s in reversed(list(self._downloads.values()))]

    def ms_stop(self, job_id: str) -> bool:
        if job_id in self._downloads:
            self._downloads[job_id]["stop"] = True
        return True

    def ms_send_recap(self, path: str) -> dict:
        if self._colab:
            return {"kind": "page", "page": "recap_web", "source": path}
        self._open_tk("recap", path)
        return {"kind": "embed", "tool": "recap", "title": "Recap"}

    # ------------------------------------------------------------------ auto posting
    def ap_status(self) -> dict:
        self._need_vip_plus()
        running = engine_runner.running()
        return {"running": running, "armed": running and engine_runner.armed(), "url": engine_runner.URL}

    def ap_start(self, arm: bool = False) -> dict:
        """Opening the page only starts the engine (dashboard); ▶ စမယ် (arm=True) also arms today's posting."""
        self._need_vip_plus(fresh=True)
        engine_runner.start()
        self._posting_started = True
        ok = engine_runner.wait_ready()
        armed = ok and bool(arm) and engine_runner.arm_today()
        return {"running": ok, "armed": armed or (ok and engine_runner.armed()), "url": engine_runner.URL,
                "log": "" if ok else engine_runner.last_log_lines()}

    def ap_stop(self) -> bool:
        self._need_session()
        engine_runner.stop()
        self._posting_started = False
        return True

    def ap_list(self) -> list[dict]:
        self._need_vip_plus()
        routes = {(d["category"], d["id"]): d["label"] for d in engine_runner.destinations(enabled_only=False)}
        out = []
        for item in posting_queue.load():
            cat = item.get("category") or "post_other"
            out.append({**item, "kind": posting_queue.CATEGORIES.get(cat, ("",))[0],
                        "target_names": [routes.get((cat, t), t) for t in item.get("targets") or []],
                        "name": Path(item.get("video", "")).name})
        return out

    def ap_remove(self, ids: list) -> bool:
        self._need_vip_plus()
        posting_queue.remove(list(ids))
        return True

    def ap_destinations(self, origin: str) -> dict:
        self._need_vip_plus()
        category = posting_queue.category_for_origin(origin)
        return {"category": category, "label": posting_queue.CATEGORIES[category][0],
                "routes": engine_runner.destinations(category)}

    def ap_add(self, video: str, caption: str, targets: list, post_at: str, origin: str, delete_after: bool) -> dict:
        self._need_vip_plus()
        item = posting_queue.add(video, caption=caption, targets=list(targets or []), post_at=post_at or "",
                                 origin=origin, delete_after_post=bool(delete_after))
        return {"added": item is not None}

    # cards (auto_posting.py): one per tool, each with its own routes and waiting list
    def ap_cards(self) -> list[dict]:
        self._need_vip_plus()
        return auto_posting.cards()

    def ap_card(self, category: str) -> dict:
        self._need_vip_plus()
        return auto_posting.card(category)

    def ap_tool_card(self, tool: str) -> dict:
        """The card a tool sends to, with its routes (for the Send dialog)."""
        self._need_vip_plus()
        category = auto_posting.category_of(tool)
        return {"category": category, "label": posting_queue.CATEGORIES[category][0],
                "routes": engine_runner.destinations(category, enabled_only=False)}

    def ap_candidates(self, tool: str) -> list[dict]:
        self._need_vip_plus()
        return auto_posting.candidates(tool)

    def ap_send(self, tool: str, videos: list, targets: list, post_at: str, delete_after: bool) -> dict:
        self._need_vip_plus()
        return auto_posting.send(tool, list(videos or []), targets=list(targets or []), post_at=post_at or "",
                                 delete_after=bool(delete_after))

    def ap_dashboard_url(self, open_category: str = "", tab: str = "") -> str:
        """The engine dashboard, optionally opening a category's routes or an account tab."""
        self._need_vip_plus()
        from urllib.parse import urlencode
        query = {k: v for k, v in (("open", open_category), ("tab", tab)) if v}
        return engine_runner.URL + ("?" + urlencode(query) if query else "")

    # ------------------------------------------------------------------ novel / movie review
    def novel_api(self, action: str, payload: dict | None = None):
        import web_novel
        return web_novel.call(self, action, payload or {})

    def review_api(self, action: str, payload: dict | None = None):
        if action == "stop":
            self._need_session()
        else:
            self._need_vip_plus(fresh=action == "start")
        import web_review
        return web_review.call(self, action, payload or {})

    # ------------------------------------------------------------------ closing
    def _closing(self) -> bool:
        import web_novel, web_review
        busy = self.running_windows()
        busy.extend(label for label, module in (("Novel", web_novel), ("Movie Review", web_review))
                    if module._job and module._job.running)
        if engine_runner.running():
            busy.append("Auto Posting")
        if self._story.busy:
            busy.append("Story Motion")
        if self._lts is not None:
            busy.append("Long to Short")
        if busy and not self._window.create_confirmation_dialog(
                "Studio99", f"{', '.join(busy)} ဖွင့်ထား/run နေဆဲပါ။ Studio99 ပိတ်ရင် အဲ့ဒါတွေပါ ရပ်သွားပါမယ်။ ပိတ်မလား?"):
            return False
        return True

    def _closed(self) -> None:
        self._closing_event.set()
        self._stop_jobs()
        keys_file.remove()

    def _stop_jobs(self) -> None:
        import web_novel, web_review
        from web_tool_job import stop_process
        for module in (web_novel, web_review):
            with module._job_lock:
                if module._job:
                    module._job.stop()
        for proc in self._tk.values():
            if proc.poll() is None:
                stop_process(proc)
        tool_apps.stop_all()
        engine_runner.stop()
        if self._lts is not None:
            self._lts.stop()
        self._story.stop = True
        for job in self._downloads.values():
            job["stop"] = True


def direct_media_hosts() -> None:
    """The window goes through the PC's proxy (v2rayN) like everything else, except the video sites: through the
    Japanese VPN exit YouTube asked "confirm you're not a bot" in the preview player (2026-10-18), direct it plays.
    WebView2 reads these Chromium switches from the environment."""
    import urllib.request
    import movie_search
    proxy = urllib.request.getproxies().get("https") or urllib.request.getproxies().get("http")
    if not proxy or os.environ.get("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"):
        return
    bypass = ";".join(movie_search.DIRECT_HOSTS + ("<local>",))
    os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = f'--proxy-server="{proxy}" --proxy-bypass-list="{bypass}"'


def main() -> None:
    direct_media_hosts()
    configure_rendering()
    api = Api()
    health = UIHealth(LOGS)
    api._ui_health = health
    from membership_access import bind_session
    bind_session(lambda: api._session)
    window = webview.create_window("Studio99", str(WEB / "index.html"), js_api=api, width=1440, height=900,
                                   min_size=(1100, 700), background_color="#0B0D12", text_select=True,
                                   maximized=True)
    api._window = window
    health.attach(window)
    threading.Thread(target=api._check_ffmpeg, daemon=True).start()
    window.events.closing += api._closing
    window.events.closed += api._closed
    try:
        # private: no disk cache, so a changed app.css / app.js is always the one shown (a cached old stylesheet
        # hid two fixes on 2026-10-18)
        webview.start(debug=bool(os.environ.get("STUDIO99_DEBUG")), private_mode=True)
    except Exception:  # noqa: BLE001
        LOGS.mkdir(exist_ok=True)
        (LOGS / "app.log").open("a", encoding="utf-8").write(traceback.format_exc())
        raise
    finally:
        health.close()


if __name__ == "__main__":
    main()
