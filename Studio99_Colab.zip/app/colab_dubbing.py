"""Headless Colab runner for Studio99 Dubbing (wraps tool_apps/dubbing/run_dubber.py).

Supports Edge TTS, Gemini TTS, and local GPU VoxCPM2 (48kHz Voice Design & Voice Cloning),
plus Auto Male/Female voice splitting.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import threading
import uuid
from pathlib import Path
from typing import Any

APP = Path(__file__).resolve().parent
ROOT = APP.parent
TOOL = ROOT / "tool_apps" / "dubbing"
DATA = Path(os.environ.get("STUDIO99_COLAB_DATA", "/content/Studio99Data")).resolve()
OUTPUTS = DATA / "dubbing_outputs"
CONFIG_FILE = DATA / "dubbing_colab.json"
VIDEO_EXTS = {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v"}

SOURCE_LANGUAGES = [
    ["auto", "Auto-detect"], ["zh", "Chinese"], ["en", "English"], ["ko", "Korean"],
    ["ja", "Japanese"], ["th", "Thai"], ["vi", "Vietnamese"], ["hi", "Hindi"],
    ["es", "Spanish"], ["fr", "French"], ["de", "German"], ["id", "Indonesian"],
    ["ms", "Malay"], ["ru", "Russian"],
]
MY_VOICES = [
    ["my-MM-ThihaNeural", "Thiha (Edge Male)"],
    ["my-MM-NilarNeural", "Nilar (Edge Female)"],
    ["Charon", "Charon (Gemini Male)"],
    ["Puck", "Puck (Gemini Male)"],
    ["Fenrir", "Fenrir (Gemini Male)"],
    ["Kore", "Kore (Gemini Female)"],
    ["Aoede", "Aoede (Gemini Female)"],
    ["voxcpm2:male_narrator", "VoxCPM2 Male Narrator (48kHz)"],
    ["voxcpm2:female_narrator", "VoxCPM2 Female Narrator (48kHz)"],
    ["voxcpm2:male_dramatic", "VoxCPM2 Male Dramatic (48kHz)"],
    ["voxcpm2:female_warm", "VoxCPM2 Female Warm (48kHz)"],
    ["voxcpm2:clone", "VoxCPM2 Voice Clone (Ref Audio)"],
    ["voxcpm2:design", "VoxCPM2 Custom Design"],
    ["voxcpm2:auto", "VoxCPM2 Auto Voice"],
]
EN_VOICES = [
    ["en-US-GuyNeural", "Guy (Edge Male)"],
    ["en-US-JennyNeural", "Jenny (Edge Female)"],
    ["en-US-AriaNeural", "Aria (Edge Female)"],
    ["Charon", "Charon (Gemini Male)"],
    ["Kore", "Kore (Gemini Female)"],
    ["voxcpm2:male_narrator", "VoxCPM2 Male Narrator (48kHz)"],
    ["voxcpm2:female_narrator", "VoxCPM2 Female Narrator (48kHz)"],
    ["voxcpm2:clone", "VoxCPM2 Voice Clone (Ref Audio)"],
    ["voxcpm2:auto", "VoxCPM2 Auto Voice"],
]
DEFAULTS: dict[str, Any] = {
    "source_language": "zh",
    "my_provider": "edge",
    "my_voice": "my-MM-ThihaNeural",
    "my_gender_split": True,
    "my_female_voice": "my-MM-NilarNeural",
    "my_rate_percent": 35,
    "my_style": "Natural, clear narration; steady pace; consistent voice.",
    "my_ref_audio": "",
    "en_provider": "edge",
    "en_voice": "en-US-GuyNeural",
    "en_gender_split": True,
    "en_female_voice": "en-US-JennyNeural",
    "en_rate_percent": 0,
    "en_ref_audio": "",
    "quality": "balanced",
    "whisper_model": "medium",
    "mirror_video": False,
    "blur_original_subtitles": False,
    "burn_custom_subtitles": True,
    "subtitle_font_size": 64,
    "subtitles": False,
    "resume": True,
    "output_dir": "",
}


def _within_colab(path: Path) -> bool:
    from colab_runtime import _within_colab as _ok
    return _ok(path)


def _validate_video(raw: str) -> Path:
    if not raw or len(raw) > 4096:
        raise ValueError("Video path ထည့်ပါ။")
    p = Path(raw).expanduser().resolve()
    if not _within_colab(p) or not p.is_file() or p.suffix.lower() not in VIDEO_EXTS:
        raise ValueError("/content အောက်က ဖတ်လို့ရတဲ့ video ဖိုင်ကို ရွေးပါ။")
    return p


def _load_saved() -> dict[str, Any]:
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {**DEFAULTS, **data}
    except (OSError, ValueError):
        pass
    return dict(DEFAULTS)


def _save_settings(s: dict[str, Any]) -> None:
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")


def _cuda_ready() -> bool:
    try:
        import ctranslate2
        return ctranslate2.get_cuda_device_count() > 0
    except Exception:
        return False


class ColabDubbingJobs:
    def __init__(self, emit):
        self.emit = emit
        self.lock = threading.RLock()
        self.current: dict[str, Any] | None = None
        self.proc: subprocess.Popen | None = None
        self.stop_file: Path | None = None
        self.logs: list[str] = []

    def options(self) -> dict:
        OUTPUTS.mkdir(parents=True, exist_ok=True)
        recent = [
            {"name": p.name, "path": str(p)}
            for p in sorted(OUTPUTS.rglob("*.mp4"), key=lambda x: x.stat().st_mtime, reverse=True)[:25]
        ]
        return {
            "languages": SOURCE_LANGUAGES,
            "my_voices": MY_VOICES,
            "en_voices": EN_VOICES,
            "providers": [
                ["edge", "Edge TTS (Fast, Free)"],
                ["gemini", "Gemini TTS"],
                ["voxcpm", "VoxCPM2 (Colab GPU · 48kHz / Clone)"],
            ],
            "qualities": [["fast", "Fast"], ["balanced", "Balanced"], ["best", "Best"]],
            "whisper_models": [["small", "small"], ["medium", "medium"], ["large-v3", "large-v3"]],
            "defaults": _load_saved(),
            "recent_outputs": recent,
            "cuda": _cuda_ready(),
        }

    def status(self) -> dict:
        with self.lock:
            base = dict(self.current) if self.current else {
                "status": "idle", "progress": 0, "stage": "Ready", "job_id": "", "outputs": [], "error": "",
            }
            base["logs"] = self.logs[-250:]
            return base

    def start(self, request: dict) -> dict:
        if not isinstance(request, dict):
            raise ValueError("Dubbing settings မမှန်ပါ။")
        source = _validate_video(str(request.get("source_path") or ""))
        merged = {**_load_saved(), **{k: request[k] for k in DEFAULTS if k in request}}
        _save_settings(merged)
        out_raw = str(merged.get("output_dir") or "").strip()
        out_dir = Path(out_raw).expanduser().resolve() if out_raw else OUTPUTS
        if out_raw and not _within_colab(out_dir):
            raise ValueError("Output folder ကို /content အောက်မှာသာ ထားပါ။")
        out_dir.mkdir(parents=True, exist_ok=True)

        with self.lock:
            if self.current and self.current.get("status") in {"starting", "running", "stopping"}:
                raise RuntimeError("Dubbing job တစ်ခု လုပ်နေဆဲပါ။")
            jid = uuid.uuid4().hex
            self.logs = []
            self.stop_file = DATA / "tmp" / f"dubbing_stop_{jid}.flag"
            self.stop_file.parent.mkdir(parents=True, exist_ok=True)
            self.stop_file.unlink(missing_ok=True)
            self.current = {
                "job_id": jid, "status": "starting", "progress": 0, "stage": "Preparing Dubbing",
                "source": source.name, "output_dir": str(out_dir), "outputs": [], "error": "",
            }
            threading.Thread(target=self._run, args=(jid, source, out_dir, merged), daemon=True).start()
            return {"job_id": jid, "status": "starting"}

    def stop(self) -> dict:
        with self.lock:
            if self.current and self.current.get("status") in {"starting", "running"}:
                self.current.update(status="stopping", stage="Stopping Dubbing")
            if self.stop_file:
                self.stop_file.write_text("stop", encoding="utf-8")
            proc = self.proc
        if proc and proc.poll() is None:
            try:
                from web_tool_job import stop_process
                stop_process(proc)
            except Exception:
                try:
                    proc.terminate()
                except Exception:
                    pass
        return self.status()

    def _log(self, jid: str, line: str) -> None:
        text = str(line).rstrip()
        if not text:
            return
        with self.lock:
            if self.current and self.current.get("job_id") == jid:
                self.logs.append(text)
                self.logs = self.logs[-500:]
        self.emit("dubbing_log", job_id=jid, line=text)

    def _progress(self, jid: str, pct: int, stage: str) -> None:
        pct = max(0, min(100, int(pct)))
        with self.lock:
            if self.current and self.current.get("job_id") == jid:
                self.current.update(status="running", progress=pct, stage=stage)
        self.emit("dubbing_progress", job_id=jid, progress=pct, stage=stage)

    def _run(self, jid: str, source: Path, out_dir: Path, s: dict[str, Any]) -> None:
        try:
            import keys_file
            env_file = keys_file.write()
            if not env_file or not keys_file.gemini_keys():
                raise RuntimeError("Profile မှာ Gemini API key အရင်ထည့်ပါ။")
            use_cuda = _cuda_ready()
            my_prov = str(s.get("my_provider") or "edge")
            en_prov = str(s.get("en_provider") or "edge")
            my_ref = str(s.get("my_ref_audio") or "").strip()
            en_ref = str(s.get("en_ref_audio") or "").strip()
            cfg = {
                "input": str(source),
                "output": str(out_dir),
                "source_language": str(s.get("source_language") or "zh"),
                "my": {
                    "provider": my_prov,
                    "voice": str(s.get("my_voice") or "my-MM-ThihaNeural"),
                    "api_url": (f"local://voxcpm2|{my_ref}" if my_ref else "local://voxcpm2") if my_prov == "voxcpm" else "",
                    "api_name": "/generate",
                    "voices_api": "/voices",
                    "model": "gemini-3.1-flash-tts-preview",
                    "engine_id": "voxcpm-default",
                    "style": str(s.get("my_style") or DEFAULTS["my_style"]),
                    "rate_percent": int(s.get("my_rate_percent", 35)),
                    "gender_split": bool(s.get("my_gender_split", True)),
                    "female_voice": str(s.get("my_female_voice") or "my-MM-NilarNeural"),
                },
                "en": {
                    "provider": en_prov,
                    "voice": str(s.get("en_voice") or "en-US-GuyNeural"),
                    "api_url": (f"local://voxcpm2|{en_ref}" if en_ref else "local://voxcpm2") if en_prov == "voxcpm" else "",
                    "api_name": "/generate",
                    "voices_api": "/voices",
                    "model": "gemini-3.1-flash-tts-preview",
                    "engine_id": "voxcpm-default",
                    "style": str(s.get("my_style") or DEFAULTS["my_style"]),
                    "rate_percent": int(s.get("en_rate_percent", 0)),
                    "gender_split": bool(s.get("en_gender_split", True)),
                    "female_voice": str(s.get("en_female_voice") or "en-US-JennyNeural"),
                },
                "env_file": str(env_file),
                "env_key": "",
                "quality": str(s.get("quality") or "balanced"),
                "device": "cuda" if use_cuda else "cpu",
                "whisper_model": str(s.get("whisper_model") or "medium"),
                "whisper_compute_type": "float16" if use_cuda else "int8",
                "mirror_video": bool(s.get("mirror_video", False)),
                "blur_original_subtitles": bool(s.get("blur_original_subtitles", False)),
                "burn_custom_subtitles": bool(s.get("burn_custom_subtitles", True)),
                "subtitle_font_size": int(s.get("subtitle_font_size", 64)),
                "subtitles": bool(s.get("subtitles", False)),
                "resume": bool(s.get("resume", True)),
                "dry_run": False,
                "telegram_auto_send": False,
            }
            cfg_path = DATA / "tmp" / f"dubbing_cfg_{jid}.json"
            cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")

            before = {p.resolve() for p in out_dir.rglob("*.mp4")}
            cmd = [
                sys.executable, "-u", "-X", "utf8", str(TOOL / "run_dubber.py"),
                "run", "--config", str(cfg_path), "--stop-file", str(self.stop_file),
            ]
            if not cfg["resume"]:
                cmd.append("--no-resume")
            env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", STUDIO99="1", STUDIO99_LOCAL="1")
            self._progress(jid, 5, "Starting Dubbing pipeline")
            proc = subprocess.Popen(
                cmd, cwd=str(TOOL), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace", bufsize=1,
            )
            with self.lock:
                self.proc = proc
            assert proc.stdout is not None
            pct = 5
            for raw in proc.stdout:
                line = raw.rstrip("\r\n")
                self._log(jid, line)
                low = line.lower()
                m = re.search(r"(\d{1,3})\s*%", line)
                if m:
                    pct = max(pct, min(98, int(m.group(1))))
                    self._progress(jid, pct, line[:90])
                elif "transcrib" in low or "whisper" in low:
                    pct = max(pct, 20)
                    self._progress(jid, pct, "Transcribing audio")
                elif "translat" in low:
                    pct = max(pct, 45)
                    self._progress(jid, pct, "Translating dialogue")
                elif "tts" in low or "synth" in low or "dub" in low or "voxcpm" in low:
                    pct = max(pct, 70)
                    self._progress(jid, pct, "Synthesizing dubbed voice")
                elif "mux" in low or "render" in low or "ffmpeg" in low:
                    pct = max(pct, 88)
                    self._progress(jid, pct, "Rendering final video")
            rc = proc.wait()
            with self.lock:
                self.proc = None
            if rc == 130 or (self.stop_file and self.stop_file.exists()):
                with self.lock:
                    self.current.update(status="stopped", stage="Stopped")
                self.emit("dubbing_stopped", job_id=jid)
                return
            if rc != 0:
                raise RuntimeError(f"Dubbing exited with code {rc} — check logs above.")

            after = sorted(
                (p.resolve() for p in out_dir.rglob("*.mp4") if p.resolve() not in before),
                key=lambda x: x.stat().st_mtime, reverse=True,
            )
            if not after:
                after = sorted(out_dir.rglob("*.mp4"), key=lambda x: x.stat().st_mtime, reverse=True)[:5]
            outputs = [str(p) for p in after]
            with self.lock:
                self.current.update(status="done", progress=100, stage="Completed", outputs=outputs, error="")
            self.emit("dubbing_done", job_id=jid, outputs=outputs)
        except Exception as exc:
            self._log(jid, f"❌ {exc}")
            with self.lock:
                if self.current and self.current.get("job_id") == jid:
                    self.current.update(status="error", stage="Error", error=str(exc))
            self.emit("dubbing_error", job_id=jid, message=str(exc))
