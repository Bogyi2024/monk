"""Browser server for the Colab runtime. Bind only to loopback; expose it via Cloudflare Tunnel."""
from __future__ import annotations

import json
import mimetypes
import os
import re
import secrets
import threading
import tempfile
import zipfile
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

APP = Path(__file__).resolve().parent
ROOT = APP.parent
WEB = APP / "web"
MAX_REQUEST = int(os.environ.get("STUDIO99_MAX_UPLOAD_BYTES", str(8 * 1024 ** 3)))
API = None
SERVER_NONCE = secrets.token_urlsafe(32)
ACCESS_CODE = os.environ.get("STUDIO99_COLAB_ACCESS_CODE") or secrets.token_urlsafe(18)
_SESSIONS: set[str] = set()
_SESSION_LOCK = threading.Lock()
_AUTH_CLAIMED = False
_UPLOADS: dict[str, dict] = {}
LOGIN_HTML = """<!doctype html><html lang='my'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Studio99 access</title><body style='margin:0;background:#0b0d12;color:#eef1f7;font:16px sans-serif;display:grid;place-items:center;height:100vh'><form id='f' style='background:#141821;padding:28px;border-radius:16px;display:grid;gap:14px;width:min(360px,80vw)'><h2>Studio99 · Colab</h2><label>Access code<input id='c' type='password' required style='display:block;width:95%;margin-top:8px;padding:10px'></label><button style='padding:12px'>Continue</button><div id='m'></div></form><script>f.onsubmit=async e=>{e.preventDefault();m.textContent='Checking…';let r=await fetch('/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:c.value})});if(r.ok)location.href='/';else m.textContent='Invalid code or access already claimed.'}</script></body></html>""".encode("utf-8")
_UPLOAD_LOCK = threading.Lock()


def _json_bytes(data) -> bytes:
    return json.dumps(data, ensure_ascii=False, default=str).encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "Studio99Colab/1"

    def log_message(self, fmt, *args):
        print("[studio99-web] " + (fmt % args), flush=True)

    def _send(self, status: int, body: bytes, content_type="application/json; charset=utf-8", session_id: str = ""):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Content-Security-Policy", "default-src 'self' data: blob:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; media-src 'self' data: blob:; connect-src 'self'; frame-src 'self' https:")
        if session_id:
            self.send_header("Set-Cookie", f"studio99_colab={session_id}; HttpOnly; SameSite=Strict; Path=/")
        self.end_headers()
        if body:
            self.wfile.write(body)

    def _cookie_ok(self) -> bool:
        origin = self.headers.get("Origin")
        if origin and urlparse(origin).netloc != self.headers.get("Host", ""):
            self._send(403, _json_bytes({"error": "Origin မကိုက်ပါ။"}))
            return False
        cookie = self.headers.get("Cookie", "")
        supplied = next((part.split("=", 1)[1] for part in cookie.split(";") if part.strip().startswith("studio99_colab=")), "")
        with _SESSION_LOCK:
            valid = bool(supplied) and supplied in _SESSIONS
        if not valid:
            self._send(403, _json_bytes({"error": "Access code စာမျက်နှာကို ပြန်ဖွင့်ပါ။"}))
            return False
        return True

    def _send_file(self, path: Path, attachment=False):
        path = Path(path)
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(path.stat().st_size))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if attachment:
            safe = re.sub(r"[^A-Za-z0-9._-]+", "_", path.name)
            self.send_header("Content-Disposition", f'attachment; filename="{safe}"')
        self.end_headers()
        with path.open("rb") as source:
            while chunk := source.read(1024 * 1024):
                self.wfile.write(chunk)

    def do_GET(self):
        url = urlparse(self.path)
        if url.path in {"/", "/index.html"}:
            cookie = self.headers.get("Cookie", "")
            supplied = next((part.split("=", 1)[1] for part in cookie.split(";") if part.strip().startswith("studio99_colab=")), "")
            with _SESSION_LOCK:
                authenticated = bool(supplied) and supplied in _SESSIONS
            if not authenticated:
                self._send(200, LOGIN_HTML, "text/html; charset=utf-8")
                return
        if url.path == "/api/events":
            if not self._cookie_ok():
                return
            qs = parse_qs(url.query)
            try:
                after = int((qs.get("after") or ["0"])[0])
            except ValueError:
                after = 0
            self._send(200, _json_bytes(API.web_events_since(after)))
            return
        if url.path == "/api/css/fonts/NotoSansMyanmar.ttf":
            if not self._cookie_ok():
                return
            font_path = APP / "web" / "fonts" / "NotoSansMyanmar.ttf"
            if not font_path.is_file():
                self._send(404, b"not found", "text/plain; charset=utf-8")
            else:
                self._send_file(font_path)
            return
        if url.path == "/api/media":
            if not self._cookie_ok():
                return
            try:
                raw = (parse_qs(url.query).get("path") or [""])[0]
                from colab_runtime import _validate_source
                path = _validate_source(raw)
                if path.suffix.lower() not in {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v", ".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"}:
                    raise FileNotFoundError("Video not available")
                size = path.stat().st_size
                start, end, status = 0, size - 1, 200
                header = self.headers.get("Range", "")
                if header.startswith("bytes="):
                    spec = header[6:].split(",", 1)[0]
                    left, _, right = spec.partition("-")
                    if not left:
                        length = int(right or 0)
                        start = max(0, size - length)
                    else:
                        start = int(left)
                        if right:
                            end = min(size - 1, int(right))
                    if start < 0 or start >= size or end < start:
                        self.send_response(416)
                        self.send_header("Content-Range", f"bytes */{size}")
                        self.send_header("Content-Length", "0")
                        self.end_headers()
                        return
                    status = 206
                length = end - start + 1
                self.send_response(status)
                self.send_header("Content-Type", mimetypes.guess_type(path.name)[0] or "video/mp4")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Length", str(length))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                if status == 206:
                    self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
                self.end_headers()
                with path.open("rb") as source:
                    source.seek(start)
                    remaining = length
                    while remaining:
                        chunk = source.read(min(1024 * 1024, remaining))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        remaining -= len(chunk)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self._send(404, _json_bytes({"error": str(exc)}))
            return
        if url.path in {"/api/download", "/api/file", "/api/archive"}:
            if not self._cookie_ok():
                return
            try:
                if url.path == "/api/download":
                    job_id = (parse_qs(url.query).get("job_id") or [""])[0]
                    path = Path(API.recap_download(job_id))
                else:
                    raw = (parse_qs(url.query).get("path") or [""])[0]
                    from colab_runtime import _within_colab
                    path = Path(raw).resolve()
                    if not _within_colab(path):
                        raise FileNotFoundError("Path not available")
                    if url.path == "/api/file" and not path.is_file():
                        raise FileNotFoundError("File not available")
                    if url.path == "/api/archive" and not path.is_dir():
                        raise FileNotFoundError("Folder not available")
            except Exception as exc:
                self._send(404, _json_bytes({"error": str(exc)}))
                return
            if url.path == "/api/archive":
                if not self._cookie_ok():
                    return
                data_root = Path(os.environ.get("STUDIO99_COLAB_DATA", "/content/Studio99Data"))
                temp_root = data_root / "tmp"
                temp_root.mkdir(parents=True, exist_ok=True)
                folder_name = re.sub(r"[^A-Za-z0-9._-]+", "_", path.name or "colab-folder")
                with tempfile.TemporaryDirectory(dir=temp_root) as temp_dir:
                    archive_path = Path(temp_dir) / f"{folder_name}.zip"
                    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                        for item in path.rglob("*"):
                            if item.is_file() and not item.is_symlink():
                                resolved = item.resolve()
                                if not _within_colab(resolved):
                                    continue
                                archive.write(resolved, item.relative_to(path).as_posix())
                    self._send_file(archive_path, attachment=True)
                return
            self._send_file(path, attachment=True)
            return
        if url.path == "/health":
            self._send(200, b'{"ok":true}')
            return
        rel = unquote(url.path.lstrip("/")) or "index.html"
        candidate = (WEB / rel).resolve()
        if WEB.resolve() not in candidate.parents and candidate != WEB.resolve():
            self._send(404, b"not found", "text/plain; charset=utf-8")
            return
        if not candidate.is_file():
            self._send(404, b"not found", "text/plain; charset=utf-8")
            return
        try:
            if candidate == (WEB / "index.html").resolve():
                content = candidate.read_text(encoding="utf-8")
                content = content.replace(
                    '<script src="app.js"></script>',
                    '<script>window.STUDIO99_COLAB_MODE=true;</script>\n<script src="app.js"></script>\n<script src="colab_bridge.js"></script>\n<script src="recap_page.js"></script>\n<script src="splitter_page.js"></script>\n<script src="dubbing_page.js"></script>\n<script src="subtitle_page.js"></script>\n<script src="storytelling_page.js"></script>',
                )
                self._send(200, content.encode("utf-8"), "text/html; charset=utf-8")
            else:
                self._send_file(candidate)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_POST(self):
        url = urlparse(self.path)
        if url.path == "/auth":
            try:
                request_size = int(self.headers.get("Content-Length", "0") or 0)
                if request_size < 0 or request_size > 8192: raise ValueError("Invalid request")
                body = json.loads(self.rfile.read(request_size) or b"{}")
                code = str(body.get("code") or "")
            except Exception:
                self._send(400, _json_bytes({"error": "Invalid request"})); return
            global _AUTH_CLAIMED
            with _SESSION_LOCK:
                if _AUTH_CLAIMED or not hmac.compare_digest(code, ACCESS_CODE):
                    self._send(403, _json_bytes({"error": "Invalid code or access already claimed"})); return
                _AUTH_CLAIMED = True
                session_id = secrets.token_urlsafe(32)
                _SESSIONS.add(session_id)
            self._send(200, b'{"ok":true}', session_id=session_id); return
        if not self._cookie_ok():
            return
        try:
            length = int(self.headers.get("Content-Length", "0") or 0)
        except ValueError:
            self._send(400, _json_bytes({"error": "Invalid content length"})); return
        if length < 0 or length > MAX_REQUEST:
            self._send(413, _json_bytes({"error": f"Request limit is {MAX_REQUEST // (1024 ** 2)} MB."})); return

        if url.path == "/api/upload/image":
            qs = parse_qs(url.query)
            filename = Path(unquote((qs.get("filename") or ["logo.png"])[0])).name
            ext = Path(filename).suffix.lower()
            if ext not in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
                self._send(400, _json_bytes({"error": "PNG/JPG/WEBP/BMP image ရွေးပါ။"})); return
            if length > 20 * 1024 * 1024:
                self._send(413, _json_bytes({"error": "Logo image အများဆုံး 20 MB ဖြစ်ရပါမယ်။"})); return
            from colab_runtime import DATA
            folder = DATA / "assets" / "logos"; folder.mkdir(parents=True, exist_ok=True)
            target = folder / f"{secrets.token_hex(6)}_{re.sub(r'[^\\w.-]+','_',filename)}"
            remaining = length
            try:
                with target.open("wb") as out:
                    while remaining:
                        chunk = self.rfile.read(min(1024 * 1024, remaining))
                        if not chunk: raise ConnectionError("Logo upload interrupted")
                        out.write(chunk); remaining -= len(chunk)
            except Exception as exc:
                target.unlink(missing_ok=True); self._send(400, _json_bytes({"error": str(exc)})); return
            self._send(200, _json_bytes({"path": str(target), "name": target.name})); return

        if url.path in {"/api/upload/audio", "/api/upload/srt"}:
            qs = parse_qs(url.query)
            is_srt = url.path == "/api/upload/srt"
            default_name = "subtitles.srt" if is_srt else "audio.mp3"
            filename = Path(unquote((qs.get("filename") or [default_name])[0])).name
            ext = Path(filename).suffix.lower()
            allowed_ext = {".srt", ".vtt", ".ass"} if is_srt else {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"}
            if ext not in allowed_ext:
                self._send(400, _json_bytes({"error": "File extension မမှန်ပါ။"})); return
            limit = 20 * 1024 * 1024 if is_srt else 150 * 1024 * 1024
            if length > limit:
                self._send(413, _json_bytes({"error": f"File အများဆုံး {limit // (1024 ** 2)} MB ဖြစ်ရပါမယ်။"})); return
            from colab_runtime import UPLOADS
            folder = UPLOADS / ("subtitles" if is_srt else "audio"); folder.mkdir(parents=True, exist_ok=True)
            target = folder / f"{secrets.token_hex(6)}_{re.sub(r'[^\w.-]+', '_', filename)}"
            remaining = length
            try:
                with target.open("wb") as out:
                    while remaining:
                        chunk = self.rfile.read(min(1024 * 1024, remaining))
                        if not chunk: raise ConnectionError("Upload interrupted")
                        out.write(chunk); remaining -= len(chunk)
            except Exception as exc:
                target.unlink(missing_ok=True); self._send(400, _json_bytes({"error": str(exc)})); return
            self._send(200, _json_bytes({"path": str(target), "name": target.name})); return

        if url.path == "/api/upload/chunk":
            qs = parse_qs(url.query)
            upload_id = str((qs.get("upload_id") or [""])[0])
            name = Path(unquote((qs.get("filename") or ["video.mp4"])[0])).name
            name = re.sub(r"[^\w.() -]+", "_", name, flags=re.UNICODE)[:180] or "video.mp4"
            try:
                part = int((qs.get("part") or ["0"])[0]); parts = int((qs.get("parts") or ["1"])[0])
                if not re.fullmatch(r"[A-Fa-f0-9]{32}", upload_id) or parts < 1 or parts > 1024 or part < 0 or part >= parts:
                    raise ValueError("Upload metadata မမှန်ပါ။")
            except ValueError as exc:
                self._send(400, _json_bytes({"error": str(exc)})); return
            if Path(name).suffix.lower() not in {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v"}:
                self._send(400, _json_bytes({"error": "Video extension မမှန်ပါ။"})); return
            if length > 9 * 1024 * 1024:
                self._send(413, _json_bytes({"error": "Chunk exceeds 9 MB."})); return
            from colab_runtime import UPLOADS
            UPLOADS.mkdir(parents=True, exist_ok=True)
            chunk_path = UPLOADS / f".{upload_id}.{part}.part"
            target = UPLOADS / f"{upload_id}_{name}"
            remaining = length
            try:
                with chunk_path.open("wb") as out:
                    while remaining:
                        chunk = self.rfile.read(min(1024 * 1024, remaining))
                        if not chunk: raise ConnectionError("Upload အလယ်မှာ connection ပြတ်သွားပါတယ်။")
                        out.write(chunk); remaining -= len(chunk)
                with _UPLOAD_LOCK:
                    state = _UPLOADS.setdefault(upload_id, {"name": name, "parts": parts, "received": set()})
                    if state["name"] != name or state["parts"] != parts: raise ValueError("Upload session mismatch")
                    state["received"].add(part)
                    if len(state["received"]) != parts:
                        result = {"ok": True, "part": part}
                    else:
                        with target.open("wb") as out:
                            for index in range(parts):
                                piece = UPLOADS / f".{upload_id}.{index}.part"
                                with piece.open("rb") as src:
                                    while block := src.read(1024 * 1024): out.write(block)
                                piece.unlink(missing_ok=True)
                        _UPLOADS.pop(upload_id, None)
                        result = {"path": str(target), "name": name}
            except Exception as exc:
                chunk_path.unlink(missing_ok=True)
                self._send(400, _json_bytes({"error": str(exc)})); return
            self._send(200, _json_bytes(result)); return

        if url.path != "/api/call":
            self._send(404, _json_bytes({"error": "Not found"})); return
        if length > 2 * 1024 * 1024:
            self._send(413, _json_bytes({"error": "Request too large"})); return
        try:
            data = json.loads(self.rfile.read(length) or b"{}")
            method = str(data.get("method") or "")
            args = data.get("args") or []
            if not isinstance(args, list) or len(args) > 24:
                raise ValueError("Invalid arguments")
            if not method or method.startswith("_"):
                raise ValueError("Unknown API method")
            if method in {"choose_file", "choose_files", "choose_folder"}:
                result = "" if method != "choose_files" else []
            elif method in {"tool_show", "tool_rect", "tool_attach", "tool_detach", "tools_hide", "tool_close"}:
                raise RuntimeError("ဒီ native-window tool ကို Colab မှာ မပံ့ပိုးသေးပါ။")
            elif method == "open_tool":
                result = API.open_tool(*args)
            else:
                fn = getattr(API, method, None)
                if not callable(fn):
                    raise ValueError("Unknown API method")
                result = fn(*args)
            self._send(200, _json_bytes({"result": result}))
        except Exception as exc:
            self._send(400, _json_bytes({"error": str(exc) or type(exc).__name__}))


def create_server(host="127.0.0.1", port=8765):
    import sys
    os.environ["STUDIO99_WEB_MODE"] = "colab"
    os.environ["STUDIO99_LOCAL"] = "1"  # existing Studio99 local VIP+ developer mode; Colab-only process
    data_root = Path(os.environ.get("STUDIO99_COLAB_DATA", "/content/Studio99Data")).resolve()
    for name in ("TMPDIR", "TMP", "TEMP"):
        os.environ[name] = str(data_root / "tmp")
    tempfile.tempdir = str(data_root / "tmp")
    os.environ["XDG_CACHE_HOME"] = str(data_root / "cache")
    os.environ["HF_HOME"] = str(data_root / "cache" / "huggingface")
    os.environ["HF_HUB_CACHE"] = str(data_root / "cache" / "huggingface" / "hub")
    os.environ["HUGGINGFACE_HUB_CACHE"] = os.environ["HF_HUB_CACHE"]
    os.environ["TORCH_HOME"] = str(data_root / "cache" / "torch")
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(data_root / "cache" / "ms-playwright")
    for directory in ("tmp", "cache", "downloads", "uploads", "recap_jobs", "outputs", "Studio99Desktop"):
        (data_root / directory).mkdir(parents=True, exist_ok=True)
    if str(APP) not in sys.path:
        sys.path.insert(0, str(APP))
    from webapp import Api
    global API
    API = Api()
    from membership_access import bind_session
    bind_session(lambda: API._session)
    return ThreadingHTTPServer((host, int(port)), Handler)


def serve(host="127.0.0.1", port=8765):
    server = create_server(host, port)
    print(f"Studio99 Colab web server listening on http://{host}:{port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    serve(args.host, args.port)
