"""Is a tool window still doing a job? (2026-10-30, user: when VIP ends, a job in progress finishes first, then the
VIP tool closes.) The copied tools do not report their state, so this looks at the process from outside:
child processes (FFmpeg, Whisper / engine workers) or CPU / I/O since the last look (a translation waiting on
Gemini only moves network bytes). A tool counts as idle only after IDLE_LOOKS quiet looks in a row."""
from __future__ import annotations

IDLE_LOOKS = 6            # with the 30 s watcher: ~3 minutes without children, CPU or I/O
CPU_SECONDS = 1.0         # CPU time used between two looks that counts as work
IO_BYTES = 16 * 1024      # read + write + other (network) bytes between two looks that count as work


def _sample(pid: int) -> tuple[bool, float, int] | None:
    """(has children, CPU seconds so far, I/O bytes so far); None = the process is gone."""
    import psutil
    try:
        proc = psutil.Process(pid)
        children = [c for c in proc.children(recursive=True) if c.is_running()]
        cpu = sum(proc.cpu_times()[:2])
        io = proc.io_counters()
        total = io.read_bytes + io.write_bytes + getattr(io, "other_bytes", 0)
        return bool(children), cpu, total
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return None


class BusyWatch:
    def __init__(self) -> None:
        self._last: dict[int, tuple[float, int]] = {}
        self._quiet: dict[int, int] = {}

    def idle(self, pid: int) -> bool:
        """True once the process has been quiet for IDLE_LOOKS looks in a row (or is gone)."""
        sample = _sample(pid)
        if sample is None:
            return True
        children, cpu, io = sample
        before = self._last.get(pid)
        self._last[pid] = (cpu, io)
        working = children or before is None or cpu - before[0] >= CPU_SECONDS or io - before[1] >= IO_BYTES
        self._quiet[pid] = 0 if working else self._quiet.get(pid, 0) + 1
        return self._quiet[pid] >= IDLE_LOOKS

    def forget(self, pid: int) -> None:
        self._last.pop(pid, None)
        self._quiet.pop(pid, None)
