"""Unified drop-in LLM client for Studio99 supporting:
- Gemini Native (Google GenAI SDK, with optional custom base_url)
- OpenAI-compatible (/v1/chat/completions — e.g. gemini-web2api-go, OpenRouter, LiteLLM, OpenAI, Ollama)
- Anthropic-compatible (/v1/messages — Claude API or Anthropic-compatible proxy)

Exposes the same `.models.generate_content(model=..., contents=..., config=...) -> SimpleNamespace(text=...)`
interface as `google.genai.Client` so Recap, Story Motion, Speaker Gender, and Caption tools work seamlessly.
"""
from __future__ import annotations

import base64
import json
import os
import time
import urllib.error
import urllib.request
from pathlib import Path
from types import SimpleNamespace
from typing import Any

VALID_MODES = ("gemini", "openai", "anthropic")


def _read_env_file(env_file: str | Path | None) -> dict[str, str]:
    if not env_file:
        return {}
    p = Path(env_file)
    if not p.is_file():
        return {}
    try:
        from dotenv import dotenv_values
        return {str(k): str(v) for k, v in dotenv_values(p).items() if v is not None}
    except Exception:
        out: dict[str, str] = {}
        try:
            for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip().strip('"\'')
        except Exception:
            pass
        return out


def load_config(env_file: str | Path | None = None) -> dict[str, Any]:
    """Read custom API settings from environment + optional .env file."""
    file_vals = _read_env_file(env_file)

    def get(name: str, default: str = "") -> str:
        if file_vals and name in file_vals and str(file_vals[name]).strip():
            return str(file_vals[name]).strip()
        val = os.environ.get(name)
        if val is not None and str(val).strip():
            return str(val).strip()
        return str(file_vals.get(name) or default).strip()

    mode = get("STUDIO99_API_MODE", "gemini").lower()
    if mode not in VALID_MODES:
        mode = "gemini"
    base_url = get("STUDIO99_API_BASE_URL", "")
    api_key = get("STUDIO99_API_KEY", "")
    raw_models = get("STUDIO99_API_MODELS", "")
    models = [m.strip() for m in raw_models.replace("\n", ",").split(",") if m.strip()]
    return {
        "mode": mode,
        "base_url": base_url,
        "api_key": api_key,
        "models": models,
    }


def custom_models(env_file: str | Path | None = None) -> list[str]:
    return load_config(env_file).get("models") or []


def _extract_system_and_parts(contents: Any, config: Any = None) -> tuple[str, list[dict[str, Any]]]:
    """Normalize google-genai `contents` (str or list of str/Part) into (system_text, parts)."""
    system_text = ""
    if config is not None:
        sys_inst = getattr(config, "system_instruction", None)
        if sys_inst is None and isinstance(config, dict):
            sys_inst = config.get("system_instruction")
        if sys_inst:
            system_text = str(sys_inst)

    raw_items = list(contents) if isinstance(contents, (list, tuple)) else [contents]
    # Flatten google.genai.types.Content objects that wrap `.parts`
    flat_items: list[Any] = []
    for it in raw_items:
        it_parts = getattr(it, "parts", None)
        if isinstance(it_parts, (list, tuple)):
            flat_items.extend(it_parts)
        else:
            flat_items.append(it)

    parts: list[dict[str, Any]] = []
    for item in flat_items:
        if item is None:
            continue
        if isinstance(item, str):
            parts.append({"type": "text", "text": item})
            continue
        # PIL.Image.Image support
        if hasattr(item, "save") and hasattr(item, "size") and hasattr(item, "mode"):
            import io as _io
            buf = _io.BytesIO()
            item.save(buf, format="PNG")
            parts.append({"type": "binary", "mime_type": "image/png", "b64": base64.b64encode(buf.getvalue()).decode("ascii")})
            continue
        # google.genai.types.Part with inline_data or text
        inline = getattr(item, "inline_data", None)
        if inline is not None and getattr(inline, "data", None):
            mime = str(getattr(inline, "mime_type", "application/octet-stream") or "application/octet-stream")
            data_bytes = inline.data
            if isinstance(data_bytes, str):
                b64 = data_bytes
            else:
                b64 = base64.b64encode(bytes(data_bytes)).decode("ascii")
            parts.append({"type": "binary", "mime_type": mime, "b64": b64})
            continue
        txt = getattr(item, "text", None)
        if txt:
            parts.append({"type": "text", "text": str(txt)})
            continue
        parts.append({"type": "text", "text": str(item)})
    return system_text, parts


def _wants_json(config: Any) -> bool:
    if config is None:
        return False
    mime = getattr(config, "response_mime_type", None)
    if mime is None and isinstance(config, dict):
        mime = config.get("response_mime_type")
    return "json" in str(mime or "").lower()


def _extract_temperature(config: Any) -> float | None:
    if config is None:
        return None
    t = getattr(config, "temperature", None)
    if t is None and isinstance(config, dict):
        t = config.get("temperature")
    return float(t) if t is not None else None


def _http_post_json(url: str, headers: dict[str, str], payload: dict[str, Any], timeout: float) -> dict[str, Any]:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw)
    except urllib.error.HTTPError as exc:
        body = ""
        try:
            body = exc.read().decode("utf-8", errors="replace")[:800]
        except Exception:
            pass
        raise RuntimeError(f"HTTP {exc.code} from {url}: {body or exc.reason}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Cannot connect to {url}: {exc.reason}") from exc


class _OpenAICompatModels:
    def __init__(self, base_url: str, api_key: str, timeout: float = 180.0):
        base = (base_url or "https://api.openai.com/v1").strip().rstrip("/")
        if base.endswith("/chat/completions"):
            self.endpoint = base
        elif base.endswith("/v1") or base.endswith("/v1beta") or base.endswith("/openai"):
            self.endpoint = base + "/chat/completions"
        else:
            self.endpoint = base + "/v1/chat/completions"
        self.api_key = api_key
        self.timeout = float(timeout)

    def generate_content(self, *, model: str, contents: Any, config: Any = None, **_kw) -> SimpleNamespace:
        system_text, parts = _extract_system_and_parts(contents, config)
        messages: list[dict[str, Any]] = []
        if system_text:
            messages.append({"role": "system", "content": system_text})

        has_binary = any(p["type"] == "binary" for p in parts)
        if not has_binary:
            user_content: Any = "\n\n".join(p["text"] for p in parts if p.get("text"))
        else:
            user_content = []
            for p in parts:
                if p["type"] == "text":
                    user_content.append({"type": "text", "text": p["text"]})
                elif p["type"] == "binary":
                    mime = p["mime_type"]
                    if mime.startswith("image/"):
                        user_content.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{p['b64']}"}})
                    elif mime.startswith("audio/"):
                        fmt = mime.split("/", 1)[-1].replace("mpeg", "mp3")
                        user_content.append({"type": "input_audio", "input_audio": {"data": p["b64"], "format": fmt}})
                    else:
                        user_content.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{p['b64']}"}})
        messages.append({"role": "user", "content": user_content})

        payload: dict[str, Any] = {"model": str(model), "messages": messages}
        temp = _extract_temperature(config)
        if temp is not None:
            payload["temperature"] = temp
        wants_json = _wants_json(config)
        if wants_json:
            payload["response_format"] = {"type": "json_object"}

        headers = {
            "Content-Type": "application/json",
            "User-Agent": "Studio99/1.0",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        try:
            res = _http_post_json(self.endpoint, headers, payload, self.timeout)
        except RuntimeError as exc:
            err_s = str(exc)
            # Some OpenAI-compatible proxies (e.g. web2api) reject response_format; retry once without it.
            if wants_json and "response_format" in payload and ("400" in err_s or "422" in err_s):
                payload.pop("response_format", None)
                res = _http_post_json(self.endpoint, headers, payload, self.timeout)
            elif "HTTP 502" in err_s or "inner[31]" in err_s:
                # Brief cooldown before retrying transient upstream 502/inner[31] so web2api isn't hammered.
                time.sleep(5.0)
                res = _http_post_json(self.endpoint, headers, payload, self.timeout)
            else:
                raise

        choices = res.get("choices") or []
        if not choices:
            raise RuntimeError(f"OpenAI-compatible API returned no choices: {str(res)[:400]}")
        msg = choices[0].get("message") or {}
        content = msg.get("content")
        if isinstance(content, list):
            text = "".join(str(part.get("text") or "") for part in content if isinstance(part, dict))
        else:
            text = str(content or "")
        return SimpleNamespace(text=text, candidates=[SimpleNamespace(content=SimpleNamespace(parts=[SimpleNamespace(text=text)]))], raw=res)


class _AnthropicCompatModels:
    def __init__(self, base_url: str, api_key: str, timeout: float = 180.0):
        base = (base_url or "https://api.anthropic.com").strip().rstrip("/")
        if base.endswith("/messages"):
            self.endpoint = base
        elif base.endswith("/v1"):
            self.endpoint = base + "/messages"
        else:
            self.endpoint = base + "/v1/messages"
        self.api_key = api_key
        self.timeout = float(timeout)

    def generate_content(self, *, model: str, contents: Any, config: Any = None, **_kw) -> SimpleNamespace:
        system_text, parts = _extract_system_and_parts(contents, config)
        blocks: list[dict[str, Any]] = []
        for p in parts:
            if p["type"] == "text":
                blocks.append({"type": "text", "text": p["text"]})
            elif p["type"] == "binary" and p["mime_type"].startswith("image/"):
                blocks.append({
                    "type": "image",
                    "source": {"type": "base64", "media_type": p["mime_type"], "data": p["b64"]},
                })
        payload: dict[str, Any] = {
            "model": str(model),
            "max_tokens": 8192,
            "messages": [{"role": "user", "content": blocks or [{"type": "text", "text": ""}]}],
        }
        if system_text:
            payload["system"] = system_text
        temp = _extract_temperature(config)
        if temp is not None:
            payload["temperature"] = temp

        headers = {
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01",
            "User-Agent": "Studio99/1.0",
        }
        if self.api_key:
            headers["x-api-key"] = self.api_key
            headers["Authorization"] = f"Bearer {self.api_key}"

        res = _http_post_json(self.endpoint, headers, payload, self.timeout)
        content_blocks = res.get("content") or []
        text = "".join(str(b.get("text") or "") for b in content_blocks if isinstance(b, dict) and b.get("type") == "text")
        if not text and isinstance(res.get("completion"), str):
            text = res["completion"]
        return SimpleNamespace(text=text, candidates=[SimpleNamespace(content=SimpleNamespace(parts=[SimpleNamespace(text=text)]))], raw=res)


class CompatClient:
    """Drop-in replacement for google.genai.Client."""

    def __init__(self, models_adapter: Any):
        self.models = models_adapter

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def close(self):
        pass


def make_client(
    *,
    api_key: str = "",
    http_options: Any = None,
    env_file: str | Path | None = None,
    timeout_seconds: float = 180.0,
) -> Any:
    """Return either a CompatClient (OpenAI/Anthropic) or native google.genai.Client (with optional base_url)."""
    cfg = load_config(env_file)
    mode = cfg["mode"]
    base_url = cfg["base_url"]
    effective_key = cfg["api_key"] or str(api_key or "").strip()

    if isinstance(http_options, dict) and http_options.get("timeout"):
        try:
            t_ms = float(http_options["timeout"])
            timeout_seconds = t_ms / 1000.0 if t_ms > 1000 else t_ms
        except Exception:
            pass

    if mode == "openai":
        return CompatClient(_OpenAICompatModels(base_url, effective_key, timeout=timeout_seconds))
    if mode == "anthropic":
        return CompatClient(_AnthropicCompatModels(base_url, effective_key, timeout=timeout_seconds))

    # Native Gemini mode (supports optional custom base_url for Gemini-compatible proxies!)
    from google import genai
    opts: Any = http_options
    if base_url:
        if isinstance(http_options, dict):
            opts = {**http_options, "base_url": base_url}
        elif http_options is None:
            opts = {"base_url": base_url}
        else:
            try:
                from google.genai import types
                opts = types.HttpOptions(base_url=base_url, timeout=getattr(http_options, "timeout", None))
            except Exception:
                opts = {"base_url": base_url}
    if opts is not None:
        return genai.Client(api_key=effective_key, http_options=opts)
    return genai.Client(api_key=effective_key)


def test_connection(mode: str, base_url: str, api_key: str, model: str) -> dict[str, Any]:
    """Quick connectivity test from Profile -> Keys UI."""
    mode = str(mode or "gemini").strip().lower()
    if mode not in VALID_MODES:
        raise ValueError("API mode ကို gemini / openai / anthropic ထဲက ရွေးပါ။")
    model = str(model or "").strip() or ("gemini-2.5-flash" if mode != "anthropic" else "claude-sonnet-4-5")
    t0 = time.monotonic()
    if mode == "openai":
        client = CompatClient(_OpenAICompatModels(base_url, api_key, timeout=60.0))
    elif mode == "anthropic":
        client = CompatClient(_AnthropicCompatModels(base_url, api_key, timeout=60.0))
    else:
        from google import genai
        opts = {"base_url": base_url.strip()} if str(base_url or "").strip() else None
        client = genai.Client(api_key=api_key, http_options=opts) if opts else genai.Client(api_key=api_key)
    resp = client.models.generate_content(model=model, contents="Reply with OK only.")
    ms = int((time.monotonic() - t0) * 1000)
    reply = str(getattr(resp, "text", "") or "").strip()[:120]
    return {"ok": True, "mode": mode, "model": model, "latency_ms": ms, "reply": reply or "OK"}
