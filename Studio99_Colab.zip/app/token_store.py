"""The login token, encrypted with Windows DPAPI for this Windows user (copying the file to another PC or user does
not log anyone in). Never the password."""
from __future__ import annotations

import ctypes
import json
import os
import tempfile
from ctypes import wintypes
from pathlib import Path

_COLAB_WEB = os.environ.get("STUDIO99_WEB_MODE") == "colab"
APP_DIR = (Path(os.environ.get("STUDIO99_COLAB_DATA", "/content/Studio99Data")) / "Studio99Desktop"
           if _COLAB_WEB else Path(os.environ.get("APPDATA") or Path.home()) / "Studio99Desktop")
SESSION_FILE = APP_DIR / "session.bin"
_ENTROPY = b"studio99-desktop-session-v1"
if _COLAB_WEB:
    os.environ.setdefault("STUDIO99_COLAB_DATA", "/content/Studio99Data")
    _COLAB_DATA = Path(os.environ["STUDIO99_COLAB_DATA"])
    _COLAB_TMP = _COLAB_DATA / "tmp"
    _COLAB_TMP.mkdir(parents=True, exist_ok=True)
    for _tmp_name in ("TMPDIR", "TMP", "TEMP"):
        os.environ[_tmp_name] = str(_COLAB_TMP)
    tempfile.tempdir = str(_COLAB_TMP)
_WEB_SESSION: dict | None = None
_WEB_KEYS: dict = {}


class _Blob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _blob(data: bytes) -> _Blob:
    buf = ctypes.create_string_buffer(data, len(data))
    return _Blob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))


def _crypt(data: bytes, protect: bool) -> bytes:
    if _COLAB_WEB:
        raise OSError("DPAPI is unavailable in Colab mode")
    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
    src, entropy, out = _blob(data), _blob(_ENTROPY), _Blob()
    fn = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    ok = fn(ctypes.byref(src), None, ctypes.byref(entropy), None, None, 0x1, ctypes.byref(out))
    if not ok:
        raise OSError("DPAPI failed")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)


def save(token: str, email: str) -> None:
    global _WEB_SESSION
    if _COLAB_WEB:
        _WEB_SESSION = {"token": token, "email": email}
        return
    APP_DIR.mkdir(parents=True, exist_ok=True)
    SESSION_FILE.write_bytes(_crypt(json.dumps({"token": token, "email": email}).encode("utf-8"), True))


def load() -> dict | None:
    if _COLAB_WEB:
        return dict(_WEB_SESSION) if _WEB_SESSION else None
    try:
        return json.loads(_crypt(SESSION_FILE.read_bytes(), False).decode("utf-8"))
    except Exception:
        return None


def clear() -> None:
    global _WEB_SESSION
    if _COLAB_WEB:
        _WEB_SESSION = None
        return
    SESSION_FILE.unlink(missing_ok=True)


# The user's own API keys (BYOK, like the Studio99 phone app): Gemini keys (one or more) and an optional FAL key.
# Encrypted for this Windows user; sent only to Google / FAL by the tools.
KEYS_FILE = APP_DIR / "keys.bin"


def save_keys(keys: dict) -> None:
    global _WEB_KEYS
    if _COLAB_WEB:
        _WEB_KEYS = dict(keys)
        return
    encrypted = _crypt(json.dumps(keys).encode("utf-8"), True)
    _atomic_write(KEYS_FILE, encrypted)
    if load_keys(strict=True) != keys:
        raise OSError("Profile key တွေကို ပြန်ဖတ်စစ်လို့ မရပါ။ Save ပြန်လုပ်ပေးပါ။")


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix=path.name + ".", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def load_keys(*, strict: bool = False) -> dict:
    if _COLAB_WEB:
        if _WEB_KEYS:
            return dict(_WEB_KEYS)
        env_path = APP_DIR / "run_keys" / ".env"
        try:
            from dotenv import dotenv_values
            values = dotenv_values(env_path)
            gemini = []
            for name, value in values.items():
                if name.startswith("GEMINI_IMAGE_PROJECT_") and name.endswith("_KEY") and value:
                    idx_str = name[len("GEMINI_IMAGE_PROJECT_"):-len("_KEY")]
                    if idx_str.isdigit():
                        val_str = str(value).strip()
                        if val_str and val_str != "custom-local-key":
                            gemini.append((int(idx_str), val_str))
            gemini.sort(key=lambda item: item[0])
            return {
                "gemini": [value for _index, value in gemini],
                "fal": str(values.get("FAL_KEY") or ""),
                "tmdb": str(values.get("TMDB_BEARER_TOKEN") or ""),
                "api_mode": str(values.get("STUDIO99_API_MODE") or "gemini"),
                "api_base_url": str(values.get("STUDIO99_API_BASE_URL") or ""),
                "api_key": str(values.get("STUDIO99_API_KEY") or ""),
                "api_models": str(values.get("STUDIO99_API_MODELS") or ""),
            }
        except Exception:
            return {}
    try:
        data = json.loads(_crypt(KEYS_FILE.read_bytes(), False).decode("utf-8"))
        if not isinstance(data, dict):
            raise ValueError("Invalid key store")
        return data
    except FileNotFoundError:
        return {}
    except Exception:
        if strict:
            raise OSError("Profile key ဖိုင်ကို ဖတ်မရပါ။ Profile မှာ key ပြန်ထည့်ပြီး Save လုပ်ပေးပါ။") from None
        return {}
