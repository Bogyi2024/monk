"""Colab Recap Auto mode: poll YouTube/Videos channels and serially recap new downloads.

TikTok authenticated profiles and Auto Posting remain unavailable in an ephemeral Colab browser.
"""
from __future__ import annotations

import os
import sys
import threading
import time
from pathlib import Path

APP = Path(__file__).resolve().parent
ROOT = APP.parent
if str(APP) not in sys.path:
    sys.path.insert(0, str(APP))


class ColabRecapAuto:
    def __init__(self, recap, emit):
        self.recap = recap
        self.emit = emit
        self.lock = threading.RLock()
        self.running = False
        self.stop_requested = False
        self.checking = False
        self.interval = 30
        self.thread = None
        self.running_item = None
        self.queue = []
        self.error = ""
        self._wake = threading.Event()

    def _module(self):
        import channel_source
        return channel_source

    def status(self):
        channel_source = self._module()
        data = channel_source.load()
        with self.lock:
            running = self.running
            queued = list(self.queue)
            active = dict(self.running_item) if self.running_item else None
            checking = self.checking
            error = self.error
        return {
            "running": running, "checking": checking, "stop_requested": self.stop_requested,
            "interval": self.interval, "active": active,
            "pending": [{"id":x.get("id"),"title":x.get("title"),"url":x.get("url"),"path":x.get("path")} for x in queued],
            "channels": data.get("channels", []),
            "registry": channel_source.recent(30), "error": error,
            "tiktok_supported": False,
            "note": "TikTok account sign-in and Auto Posting require the local desktop/profile; Colab supports polling public YouTube channels and recapping to the local output queue only.",
        }

    def add_channel(self, url: str, kind: str = "videos") -> dict:
        url = str(url or "").strip()
        kind = str(kind or "videos").lower()
        if kind not in {"videos", "shorts"}:
            raise ValueError("YouTube channel type must be videos or shorts")
        platform = self._module().platform(url)
        if platform == "tiktok":
            raise RuntimeError("Colab cloud browser မှာ TikTok login/session မရှိပါ။ TikTok Auto mode ကို Studio99 Desktop မှာသာသုံးပါ။")
        if platform != "youtube":
            raise ValueError("YouTube channel link ကိုထည့်ပါ။")
        channel = self._module().add_channel(url, kind=kind, auto_post=False, log=self._log)
        self.emit("recap_auto", action="channel_added", channel=channel)
        return self.status()

    def remove_channel(self, url: str, kind: str) -> dict:
        platform = self._module().platform(str(url or ""))
        if platform == "tiktok":
            raise RuntimeError("TikTok channel ကို Colab Auto မပံ့ပိုးပါ။")
        self._module().remove_channel(str(url), str(kind))
        return self.status()

    def _log(self, line: str):
        self.emit("recap_log", line=str(line), job_id="auto")

    def check_now(self) -> dict:
        with self.lock:
            if self.checking:
                return {"started": False, "status": self.status()}
            self.checking = True
            self.error = ""
        thread = threading.Thread(target=self._check_worker, daemon=True)
        thread.start()
        return {"started": True, "status": "checking"}

    def _check_worker(self):
        try:
            channel_source = self._module()
            if not channel_source.load().get("channels"):
                return
            found = channel_source.check_new(per_check=2, log=self._log)
            added = []
            for item in found:
                if self.stop_requested:
                    break
                channel_source.register_found(item)
                try:
                    path = channel_source.download(item["url"], log=self._log)
                    channel_source.mark(item["id"], "downloaded", path=str(path))
                    saved = {**item, "path": str(path)}
                    with self.lock:
                        if not any(x.get("id") == saved["id"] for x in self.queue) and not (
                            self.running_item and self.running_item.get("id") == saved["id"]):
                            self.queue.append(saved)
                            added.append(saved)
                except Exception as exc:
                    channel_source.mark(item["id"], "download_failed", error=str(exc)[:240])
                    self._log(f"Download failed: {item.get('title') or item.get('url')} — {exc}")
            self.emit("recap_auto", action="check_done", count=len(added), status=self.status())
            self._start_next()
        except Exception as exc:
            with self.lock:
                self.error = str(exc)
            self._log(f"Auto check error: {exc}")
            self.emit("recap_auto", action="check_error", message=str(exc))
        finally:
            with self.lock:
                self.checking = False
            self._wake.set()

    def start(self, interval: int = 30) -> dict:
        try:
            minutes = max(10, min(720, int(interval)))
        except (TypeError, ValueError):
            minutes = 30
        if not self._module().load().get("channels"):
            raise RuntimeError("Auto mode အတွက် YouTube channel ကို အရင်ထည့်ပါ။")
        with self.lock:
            self.interval = minutes
            self.running = True
            self.stop_requested = False
            self.error = ""
            if self.thread is None or not self.thread.is_alive():
                self.thread = threading.Thread(target=self._scheduler, daemon=True)
                self.thread.start()
        self.check_now()
        self.emit("recap_auto", action="started", interval=minutes)
        return self.status()

    def stop(self) -> dict:
        with self.lock:
            self.running = False
            self.stop_requested = True
            self._wake.set()
        self.emit("recap_auto", action="stopped")
        return self.status()

    def _scheduler(self):
        while True:
            with self.lock:
                if not self.running:
                    return
                interval = self.interval
            self._wake.wait(interval * 60)
            self._wake.clear()
            with self.lock:
                if not self.running:
                    return
            self.check_now()

    def _start_next(self):
        with self.lock:
            if self.running_item or self.recap.status().get("status") in {"starting", "running", "stopping", "script_ready"}:
                return
            if not self.queue:
                return
            item = self.queue.pop(0)
            self.running_item = item
        try:
            self._module().mark(item["id"], "recapping")
            cfg = __import__("colab_recap_ui")._defaults()
            request = {"source_path": item["path"], "source_title": item.get("title") or Path(item["path"]).stem,
                       "source_language": cfg.get("source_language", "auto"),
                       "voice": cfg.get("narrator_voice", "gemini:Charon"),
                       "output_ratio": "Original", "quality": str(cfg.get("video_quality", "1080")).removesuffix("p"),
                       "review_first": False, "narration_style": cfg.get("narration_style") or {"mode": "original"},
                       "final_output_folder": cfg.get("final_output_folder") or ""}
            self._log(f"Auto Recap: {item.get('title') or item.get('url')}")
            self.recap.start(request, quota_ctx=None)
        except Exception as exc:
            self._module().mark(item["id"], "recap_failed", error=str(exc)[:240])
            with self.lock:
                self.running_item = None
            self._log(f"Auto Recap start failed: {exc}")

    def job_completed(self, outputs: list[str], sources: list[str]) -> None:
        with self.lock:
            item = self.running_item
        if not item:
            return
        src = os.path.normcase(os.path.realpath(item.get("path") or ""))
        matches = any(os.path.normcase(os.path.realpath(path)) == src for path in sources)
        if not matches:
            return
        try:
            if outputs:
                self._module().mark(item["id"], "done", final=outputs[0])
            else:
                self._module().mark(item["id"], "recap_failed", error="No output")
        finally:
            with self.lock:
                self.running_item = None
            self.emit("recap_auto", action="video_done", outputs=outputs, video_id=item.get("id"))
            self._start_next()

    def _job_failed(self, sources: list[str], message: str) -> None:
        with self.lock:
            item = self.running_item
        if not item:
            return
        src = os.path.normcase(os.path.realpath(item.get("path") or ""))
        if not any(os.path.normcase(os.path.realpath(path)) == src for path in sources):
            return
        self._module().mark(item["id"], "recap_failed", error=message[:240])
        with self.lock:
            self.running_item = None
        self._start_next()
