"""Story Motion (VIP): idea → story at the chosen length → pictures (made by the user on an image site, or FAL) →
narration + moving pictures → video. Three tabs: ① Story, ② ပုံ, ③ Video. Work lives in a project folder
(story_motion/project.py) so a story can be finished later."""
from __future__ import annotations

import json
import os
import shutil
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import keys_file
import posting_queue
import token_store
import ui_thread
from story_motion import images, planner, render, voice
from story_motion.project import DEFAULT_ROOT, Project, list_projects

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "story_motion_config.json"
BG, SURFACE, SURFACE_2, FIELD, BORDER = "#0b0d12", "#141821", "#1b2030", "#0a0c10", "#2a3142"
FG, MUTED, ACCENT, GOLD, OK, BAD = "#eef1f7", "#98a2b3", "#5b8cff", "#f5c451", "#55d187", "#ff8a8a"
MM_FONT = ("Myanmar Text", 11)
LANGS = {"my": "မြန်မာ", "en": "English"}
RATIOS = ["9:16", "16:9", "1:1"]
EFFECT_LABELS = {"mix": "Zoom + Pan အလှည့်ကျ", "zoom": "Zoom in / out", "pan": "ဘေးတိုက် / အပေါ်အောက် ရွေ့", "still": "မရွေ့ (ငြိမ်)"}


def ffmpeg_path() -> str:
    for candidate in (ROOT / "recap_tool_src" / "ffmpeg" / "ffmpeg.exe", shutil.which("ffmpeg")):
        if candidate and Path(candidate).is_file():
            return str(candidate)
    return "ffmpeg"


def load_cfg() -> dict:
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _label(parent, text, **kw) -> tk.Label:
    return tk.Label(parent, text=text, bg=kw.pop("bg", SURFACE), fg=kw.pop("fg", FG),
                    font=kw.pop("font", ("Myanmar Text", 10)), **kw)


class StoryMotionView(tk.Frame):
    def __init__(self, master: tk.Misc, *, app) -> None:
        super().__init__(master, bg=BG)
        self.app = app
        self.cfg = load_cfg()
        self.root_dir = Path(self.cfg.get("projects_folder") or DEFAULT_ROOT)
        self.project: Project | None = None
        self.busy = False
        self._stop = False
        self._thumbs: list = []
        self._scene_index: int | None = None

        top = tk.Frame(self, bg=SURFACE)
        top.pack(fill="x")
        _label(top, "Project").pack(side="left", padx=(16, 6), pady=8)
        self.project_var = tk.StringVar()
        self.project_box = ttk.Combobox(top, textvariable=self.project_var, state="readonly", width=46)
        self.project_box.pack(side="left")
        self.project_box.bind("<<ComboboxSelected>>", lambda _e: self._open_selected())
        ttk.Button(top, text="＋ အသစ်", style="Compact.TButton", command=self._new_project).pack(side="left", padx=6)
        ttk.Button(top, text="Folder", style="Compact.TButton", command=self._open_folder).pack(side="left")
        self.status = tk.StringVar(value="")
        _label(top, "", textvariable=self.status, fg=MUTED, font=("Myanmar Text", 9)).pack(side="right", padx=16)

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=12, pady=10)
        self.story_tab, self.image_tab, self.video_tab = (tk.Frame(self.tabs, bg=BG) for _ in range(3))
        self.tabs.add(self.story_tab, text="  ① Story  ")
        self.tabs.add(self.image_tab, text="  ② ပုံ  ")
        self.tabs.add(self.video_tab, text="  ③ Video  ")
        self.tabs.bind("<<NotebookTabChanged>>", self._tab_changed)
        self._build_story()
        self._build_images()
        self._build_video()
        self._refresh_projects()

    # ================================================================== projects
    def _refresh_projects(self, select: Project | None = None) -> None:
        self.projects = list_projects(self.root_dir)
        self.project_box.configure(values=[f"{p.title()}   ·   {p.folder.name[:13]}" for p in self.projects])
        target = select or (self.projects[0] if self.projects and self.project is None else self.project)
        if target is not None:
            for i, p in enumerate(self.projects):
                if p.folder == target.folder:
                    self.project_box.current(i)
                    self._load_project(p)
                    break

    def _open_selected(self) -> None:
        i = self.project_box.current()
        if 0 <= i < len(self.projects):
            self._load_project(self.projects[i])

    def _new_project(self) -> None:
        self.project = None
        self.idea.delete("1.0", "end")
        self.title_var.set("")
        self.scene_list.delete(0, "end")
        self._show_scene(None)
        self.project_box.set("")
        self.tabs.select(self.story_tab)
        self.status.set("Idea ရေးပြီး 'Story ရေးမယ်' နှိပ်ပါ (Idea မရေးလည်း AI က စဉ်းစားပေးမယ်)")

    def _open_folder(self) -> None:
        folder = self.project.folder if self.project else self.root_dir
        folder.mkdir(parents=True, exist_ok=True)
        os.startfile(folder)

    def _load_project(self, project: Project) -> None:
        self.project = project
        s = project.data.get("settings") or {}
        if s:
            self._apply_settings(s)
        self.title_var.set(project.title())
        self._fill_scene_list()
        self.status.set(f"Scene {len(project.scenes)} ခု · ပုံ {len(project.scenes) - len(project.missing_images())} ပုံ")

    # ================================================================== ① story
    def _build_story(self) -> None:
        tab = self.story_tab
        left = tk.Frame(tab, bg=SURFACE, padx=18, pady=14)
        left.pack(side="left", fill="y")
        right = tk.Frame(tab, bg=BG)
        right.pack(side="left", fill="both", expand=True, padx=(12, 0))
        c = self.cfg

        _label(left, "Idea (ဇာတ်လမ်း အကြောင်း — မရေးလည်းရ)").pack(anchor="w")
        self.idea = tk.Text(left, height=4, width=46, bg=FIELD, fg=FG, insertbackground=FG, relief="flat",
                            font=MM_FONT, wrap="word", highlightthickness=1, highlightbackground=BORDER)
        self.idea.pack(fill="x", pady=(2, 8))
        grid = tk.Frame(left, bg=SURFACE)
        grid.pack(fill="x")
        self.genre = tk.StringVar(value=planner.GENRES.get(c.get("genre", "horror")))
        self.style = tk.StringVar(value=c.get("style", "narrator"))
        self.gender = tk.StringVar(value=c.get("narrator_gender", "male"))
        self.language = tk.StringVar(value=LANGS.get(c.get("language", "my")))
        self.voice = tk.StringVar()
        self.rate = tk.StringVar(value=str(c.get("rate_percent", 0)))
        self.minutes = tk.StringVar(value=str(c.get("minutes", 3)))
        self.scene_count = tk.StringVar(value=str(c.get("scene_count", 12)))
        self.image_style = tk.StringVar(value=c.get("image_style", "cartoon_2d"))
        self.ratio = tk.StringVar(value=c.get("ratio", "9:16"))
        self._scenes_edited = bool(c.get("scenes_edited", False))

        def row(r, text, widget):
            _label(grid, text).grid(row=r, column=0, sticky="w", pady=3, padx=(0, 10))
            widget.grid(row=r, column=1, sticky="w", pady=3)

        row(0, "အမျိုးအစား", ttk.Combobox(grid, textvariable=self.genre, values=list(planner.GENRES.values()),
                                           state="readonly", width=26))
        style_box = tk.Frame(grid, bg=SURFACE)
        for value, text in (("narrator", "ဇာတ်လမ်းပြောသူ"), ("first_person", "ကိုယ်တိုင်ပြော (ကျွန်တော်/ကျွန်မ)")):
            tk.Radiobutton(style_box, text=text, value=value, variable=self.style, command=self._style_changed,
                           bg=SURFACE, fg=FG, selectcolor=FIELD, activebackground=SURFACE, activeforeground=FG,
                           font=("Myanmar Text", 10)).pack(anchor="w")
        row(1, "ပြောပုံ", style_box)
        self.gender_box = tk.Frame(grid, bg=SURFACE)
        for value, text in (("male", "ကျား (ကျွန်တော်)"), ("female", "မ (ကျွန်မ)")):
            tk.Radiobutton(self.gender_box, text=text, value=value, variable=self.gender, command=self._voice_for_gender,
                           bg=SURFACE, fg=FG, selectcolor=FIELD, activebackground=SURFACE, activeforeground=FG,
                           font=("Myanmar Text", 10)).pack(side="left", padx=(0, 10))
        row(2, "ပြောသူ", self.gender_box)
        lang = ttk.Combobox(grid, textvariable=self.language, values=list(LANGS.values()), state="readonly", width=12)
        lang.bind("<<ComboboxSelected>>", lambda _e: self._language_changed())
        row(3, "ဘာသာ", lang)
        self.voice_box = ttk.Combobox(grid, textvariable=self.voice, state="readonly", width=30)
        self.voice_box.bind("<<ComboboxSelected>>", lambda _e: self._voice_changed())
        row(4, "အသံ", self.voice_box)
        self.direction = tk.StringVar(value=c.get("voice_direction", ""))
        self.direction_entry = ttk.Entry(grid, textvariable=self.direction, width=32)
        row(9, "Gemini အသံ ပုံစံ", self.direction_entry)
        self.direction_hint = _label(grid, "ဗလာ = နွေးထွေးပြီး ရှင်းတဲ့ ဇာတ်လမ်းပြောသံ (English နဲ့ ရေးပါ — ဥပမာ deep, slow, "
                                           "suspenseful horror storyteller)", fg=MUTED, font=("Myanmar Text", 8),
                                     wraplength=330, justify="left")
        self.direction_hint.grid(row=10, column=1, sticky="w")
        speed = ttk.Spinbox(grid, from_=-30, to=40, increment=5, textvariable=self.rate, width=6,
                            command=self._update_numbers)
        row(5, "အမြန်နှုန်း %", speed)
        mins = ttk.Spinbox(grid, from_=1, to=30, increment=0.5, textvariable=self.minutes, width=6,
                           command=self._minutes_changed)
        mins.bind("<KeyRelease>", lambda _e: self._minutes_changed())
        row(6, "ကြာချိန် (မိနစ်)", mins)
        scenes = ttk.Spinbox(grid, from_=3, to=200, increment=1, textvariable=self.scene_count, width=6,
                             command=self._scenes_changed)
        scenes.bind("<KeyRelease>", lambda _e: self._scenes_changed())
        row(7, "Scene အရေအတွက်", scenes)
        self.numbers = _label(left, "", fg=GOLD, font=("Myanmar Text", 9), justify="left", wraplength=360)
        self.numbers.pack(anchor="w", pady=(4, 8))
        grid2 = tk.Frame(left, bg=SURFACE)
        grid2.pack(fill="x")
        _label(grid2, "ပုံ style").grid(row=0, column=0, sticky="w", padx=(0, 10), pady=3)
        ttk.Combobox(grid2, textvariable=self.image_style, values=list(planner.IMAGE_STYLES), state="readonly",
                     width=16).grid(row=0, column=1, sticky="w")
        _label(grid2, "Ratio").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=3)
        ttk.Combobox(grid2, textvariable=self.ratio, values=RATIOS, state="readonly", width=8).grid(row=1, column=1,
                                                                                               sticky="w")
        self.write_btn = ttk.Button(left, text="✍️  Story ရေးမယ်", style="Accent.TButton", command=self._write_story)
        self.write_btn.pack(anchor="w", pady=(14, 0))

        head = tk.Frame(right, bg=BG)
        head.pack(fill="x")
        _label(head, "ခေါင်းစဉ်", bg=BG).pack(side="left")
        self.title_var = tk.StringVar()
        ttk.Entry(head, textvariable=self.title_var, font=MM_FONT).pack(side="left", fill="x", expand=True, padx=8)
        body = tk.Frame(right, bg=BG)
        body.pack(fill="both", expand=True, pady=(8, 0))
        self.scene_list = tk.Listbox(body, width=34, bg=FIELD, fg=FG, selectbackground="#274d8b", relief="flat",
                                     font=("Myanmar Text", 10), highlightthickness=1, highlightbackground=BORDER,
                                     exportselection=False)
        self.scene_list.pack(side="left", fill="y")
        self.scene_list.bind("<<ListboxSelect>>", lambda _e: self._select_scene())
        editor = tk.Frame(body, bg=BG)
        editor.pack(side="left", fill="both", expand=True, padx=(10, 0))
        self.scene_head = _label(editor, "Scene", bg=BG, font=("Segoe UI Semibold", 11))
        self.scene_head.pack(anchor="w")
        _label(editor, "Narration (အသံထွက်မယ့်စာ)", bg=BG, fg=MUTED, font=("Myanmar Text", 9)).pack(anchor="w")
        self.narration = tk.Text(editor, height=9, bg=FIELD, fg=FG, insertbackground=FG, relief="flat", font=MM_FONT,
                                 wrap="word", highlightthickness=1, highlightbackground=BORDER, undo=True)
        self.narration.pack(fill="both", expand=True)
        self.narration.bind("<KeyRelease>", lambda _e: self._count_now())
        self.count_label = _label(editor, "", bg=BG, fg=MUTED, font=("Myanmar Text", 9))
        self.count_label.pack(anchor="w")
        _label(editor, "ပုံအတွက် prompt (English)", bg=BG, fg=MUTED, font=("Myanmar Text", 9)).pack(anchor="w", pady=(6, 0))
        self.prompt = tk.Text(editor, height=6, bg=FIELD, fg=FG, insertbackground=FG, relief="flat",
                              font=("Segoe UI", 10), wrap="word", highlightthickness=1, highlightbackground=BORDER)
        self.prompt.pack(fill="x")
        buttons = tk.Frame(editor, bg=BG)
        buttons.pack(fill="x", pady=6)
        ttk.Button(buttons, text="Save", style="Compact.TButton", command=self._save_scene).pack(side="left")
        ttk.Button(buttons, text="Prompt copy", style="Compact.TButton",
                   command=lambda: self._copy(self.prompt.get("1.0", "end").strip())).pack(side="left", padx=6)
        self.log_line = _label(editor, "", bg=BG, fg=MUTED, font=("Myanmar Text", 9), justify="left", wraplength=700)
        self.log_line.pack(anchor="w")
        self._language_changed(initial=True)
        self._style_changed()

    def _settings(self) -> planner.StorySettings:
        lang = next((k for k, v in LANGS.items() if v == self.language.get()), "my")
        genre = next((k for k, v in planner.GENRES.items() if v == self.genre.get()), "horror")
        voice_id = next((v for v, label in voice.VOICES[lang] if label == self.voice.get()), voice.VOICES[lang][0][0])
        minutes, rate = self._float(self.minutes, 3.0), int(self._float(self.rate, 0))
        scenes = int(self._float(self.scene_count, 12))
        _n, per_scene, _total = planner.plan_numbers(minutes, lang, voice_id, rate, scenes)
        return planner.StorySettings(idea=self.idea.get("1.0", "end").strip(), genre=genre, style=self.style.get(),
                                     narrator_gender=self.gender.get(), language=lang, minutes=minutes,
                                     scene_count=scenes, units_per_scene=per_scene, image_style=self.image_style.get(),
                                     ratio=self.ratio.get(), voice=voice_id, rate_percent=rate,
                                     voice_direction=self.direction.get().strip() if voice.is_gemini(voice_id) else "")

    def _apply_settings(self, s: dict) -> None:
        self.genre.set(planner.GENRES.get(s.get("genre", "horror"), self.genre.get()))
        self.style.set(s.get("style", "narrator"))
        self.gender.set(s.get("narrator_gender", "male"))
        self.language.set(LANGS.get(s.get("language", "my")))
        self._language_changed(initial=True)
        label = dict(voice.VOICES.get(s.get("language", "my"), [])).get(s.get("voice", ""))
        if label:
            self.voice.set(label)
        self.rate.set(str(s.get("rate_percent", 0)))
        self.direction.set(s.get("voice_direction", ""))
        self.minutes.set(str(s.get("minutes", 3)))
        self.scene_count.set(str(s.get("scene_count", 12)))
        self.image_style.set(s.get("image_style", "cartoon_2d"))
        self.ratio.set(s.get("ratio", "9:16"))
        self.idea.delete("1.0", "end")
        self.idea.insert("1.0", s.get("idea", ""))
        self._style_changed()
        self._update_numbers()

    @staticmethod
    def _float(var: tk.StringVar, default: float) -> float:
        try:
            return float(var.get())
        except ValueError:
            return default

    def _style_changed(self) -> None:
        state = "normal" if self.style.get() == "first_person" else "disabled"
        for child in self.gender_box.winfo_children():
            child.configure(state=state)
        self._voice_for_gender()

    def _voice_changed(self) -> None:
        gemini = self.voice.get().startswith("Gemini")
        self.direction_entry.state(["!disabled"] if gemini else ["disabled"])
        self._update_numbers()

    def _voice_for_gender(self) -> None:
        """First person: the narrator's voice matches the teller's gender (same family: Edge or Gemini)."""
        if self.style.get() == "first_person":
            lang = next((k for k, v in LANGS.items() if v == self.language.get()), "my")
            gemini = self.voice.get().startswith("Gemini")
            current = next((v for v, label in voice.VOICES[lang] if label == self.voice.get()), "")
            if voice.voice_gender(current) != self.gender.get():
                for v, label in voice.VOICES[lang]:
                    if voice.is_gemini(v) == gemini and voice.voice_gender(v) == self.gender.get():
                        self.voice.set(label)
                        break
        self._voice_changed()

    def _language_changed(self, initial: bool = False) -> None:
        lang = next((k for k, v in LANGS.items() if v == self.language.get()), "my")
        labels = [label for _v, label in voice.VOICES[lang]]
        self.voice_box.configure(values=labels)
        if self.voice.get() not in labels:
            saved = dict(voice.VOICES[lang]).get(self.cfg.get("voice", ""))
            default = dict(voice.VOICES[lang]).get(voice.DEFAULT_VOICE.get(lang, ""), labels[0])
            self.voice.set(saved if initial and saved else default)
        self._voice_for_gender()
        self._update_numbers()

    def _minutes_changed(self) -> None:
        if not self._scenes_edited:
            s = self._settings()
            n, _per, _total = planner.plan_numbers(s.minutes, s.language, s.voice, s.rate_percent)
            self.scene_count.set(str(n))
        self._update_numbers()

    def _scenes_changed(self) -> None:
        self._scenes_edited = True
        self._update_numbers()

    def _update_numbers(self) -> None:
        try:
            s = self._settings()
        except Exception:  # noqa: BLE001  (while typing)
            return
        unit = "လုံး" if s.language == "my" else "words"
        seconds = s.minutes * 60 / max(1, s.scene_count)
        total = s.units_per_scene * s.scene_count
        self.numbers.configure(text=f"Scene တစ်ခု ~{s.units_per_scene} {unit} · ~{seconds:.0f} စက္ကန့် တစ်ပုံ\n"
                                    f"စုစုပေါင်း ~{total} {unit} · ပုံ {s.scene_count} ပုံ လိုမယ်")

    def _write_story(self) -> None:
        if self.busy:
            return
        keys = keys_file.gemini_keys()
        if not keys:
            messagebox.showwarning("Gemini key", "Profile မှာ Gemini API key အရင်ထည့်ပါ။", parent=self)
            return
        s = self._settings()
        self.cfg.update({k: v for k, v in s.__dict__.items() if k not in ("idea", "extra")},
                        scenes_edited=self._scenes_edited)
        CONFIG.write_text(json.dumps(self.cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        if self.project and self.project.scenes and not messagebox.askyesno(
                "Story", "ဒီ project ရဲ့ story ကို အသစ်ပြန်ရေးမလား? (ပုံတွေ ပြန်ထည့်ရမယ်)\n"
                "မဟုတ်ရင် '＋ အသစ်' နဲ့ project အသစ်ဖွင့်ပါ။", parent=self):
            return
        self._set_busy(True, "Story ရေးနေပါတယ်…")

        def work():
            story = planner.write_story(s, keys, log=lambda m: ui_thread.post(lambda m=m: self.log_line.configure(text=m)))
            project = self.project or Project.create(self.root_dir, story.get("title") or "story")
            project.data.update(settings=story["settings"], story=story, images={}, video="")
            project.save()
            return project

        def done(project):
            self._set_busy(False, f"Story ရပြီ — scene {len(project.scenes)} ခု။ စာကို ပြင်ချင်ရင် ပြင်ပြီး ② ပုံ ကို သွားပါ")
            self.project = project
            self._refresh_projects(select=project)

        self._run(work, done)

    def _fill_scene_list(self) -> None:
        self.scene_list.delete(0, "end")
        if not self.project:
            return
        for i, scene in enumerate(self.project.scenes):
            mark = "🖼 " if self.project.image(i) else "    "
            self.scene_list.insert("end", f"{mark}{i + 1:02d}  {scene['narration'][:28]}…")
        if self.project.scenes:
            self.scene_list.selection_set(0)
            self._select_scene()

    def _select_scene(self) -> None:
        self._save_scene(quiet=True)
        sel = self.scene_list.curselection()
        self._show_scene(sel[0] if sel else None)

    def _show_scene(self, index: int | None) -> None:
        self._scene_index = index
        self.narration.delete("1.0", "end")
        self.prompt.delete("1.0", "end")
        if index is None or not self.project or index >= len(self.project.scenes):
            self.scene_head.configure(text="Scene")
            self.count_label.configure(text="")
            return
        scene = self.project.scenes[index]
        self.scene_head.configure(text=f"Scene {index + 1} / {len(self.project.scenes)}")
        self.narration.insert("1.0", scene["narration"])
        self.prompt.insert("1.0", scene.get("image_prompt", ""))
        self._count_now()

    def _count_now(self) -> None:
        if not self.project:
            return
        s = self.project.data.get("settings") or {}
        lang = s.get("language", "my")
        n = planner.count_units(self.narration.get("1.0", "end"), lang)
        unit = "လုံး" if lang == "my" else "words"
        seconds = n / planner.speech_rate(lang, s.get("voice", ""), int(s.get("rate_percent", 0)))
        self.count_label.configure(text=f"{n} {unit} (ထားချင်တာ ~{s.get('units_per_scene', '?')}) · အသံ ~{seconds:.0f} စက္ကန့်")

    def _save_scene(self, quiet: bool = False) -> None:
        i = self._scene_index
        if self.project is None or i is None or i >= len(self.project.scenes):
            return
        scene = self.project.scenes[i]
        text, prompt = self.narration.get("1.0", "end").strip(), self.prompt.get("1.0", "end").strip()
        title = self.title_var.get().strip()
        if text != scene["narration"] or prompt != scene.get("image_prompt", "") or (title and title != self.project.title()):
            scene["narration"], scene["image_prompt"] = text, prompt
            if title:
                self.project.data["story"]["title"] = title
            self.project.save()
            if not quiet:
                self.status.set(f"Scene {i + 1} သိမ်းပြီး")

    # ================================================================== ② images
    def _build_images(self) -> None:
        tab = self.image_tab
        bar = tk.Frame(tab, bg=SURFACE, padx=12, pady=8)
        bar.pack(fill="x")
        self.site = tk.StringVar(value=self.cfg.get("image_site", "Gemini"))
        ttk.Combobox(bar, textvariable=self.site, values=list(images.SITES), state="readonly", width=18).pack(side="left")
        ttk.Button(bar, text="🌐 Site ဖွင့်", style="Compact.TButton",
                   command=lambda: images.open_site(self.site.get())).pack(side="left", padx=6)
        ttk.Button(bar, text="📋 Prompt အားလုံး copy", style="Compact.TButton", command=self._copy_all).pack(side="left")
        ttk.Button(bar, text="📁 Folder ကနေ ထည့်", style="Compact.TButton", command=self._load_folder).pack(side="left", padx=6)
        self.fal_btn = ttk.Button(bar, text="✨ FAL နဲ့ ကျန်တာ ထုတ်", style="Compact.TButton", command=self._fal_missing)
        self.fal_btn.pack(side="left")
        self.image_count = _label(bar, "", fg=GOLD)
        self.image_count.pack(side="right")
        _label(tab, "ပုံထုတ်နည်း — Scene ရဲ့ 'Prompt' နှိပ် (copy ဖြစ်) → Site မှာ paste ပြီး ပုံထုတ် → ပုံကို copy (Copy image) → "
               "ဒီက 'Paste' နှိပ်။ ဒါမှမဟုတ် ပုံတွေ download ပြီး Folder ကနေ တစ်ခါတည်း ထည့် (01, 02… အစဉ်လိုက်)။",
               bg=BG, fg=MUTED, font=("Myanmar Text", 9), wraplength=1100, justify="left").pack(anchor="w", padx=14, pady=6)
        holder = tk.Frame(tab, bg=BG)
        holder.pack(fill="both", expand=True)
        self.grid_canvas = tk.Canvas(holder, bg=BG, highlightthickness=0)
        scroll = ttk.Scrollbar(holder, orient="vertical", command=self.grid_canvas.yview)
        self.grid_canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.grid_canvas.pack(side="left", fill="both", expand=True)
        self.grid_frame = tk.Frame(self.grid_canvas, bg=BG)
        self.grid_canvas.create_window((0, 0), window=self.grid_frame, anchor="nw")
        self.grid_frame.bind("<Configure>", lambda _e: self.grid_canvas.configure(scrollregion=self.grid_canvas.bbox("all")))
        self.grid_canvas.bind_all("<MouseWheel>", self._wheel, add="+")

    def _wheel(self, event) -> None:
        if self.tabs.select() == str(self.image_tab) and self.winfo_ismapped():
            self.grid_canvas.yview_scroll(-1 * (event.delta // 120), "units")

    def _build_cards(self) -> None:
        from PIL import Image, ImageTk
        for child in self.grid_frame.winfo_children():
            child.destroy()
        self._thumbs = []
        if not self.project or not self.project.scenes:
            _label(self.grid_frame, "① Story မှာ story အရင်ရေးပါ", bg=BG, fg=MUTED).pack(padx=20, pady=20)
            self.image_count.configure(text="")
            return
        ratio = (self.project.data.get("settings") or {}).get("ratio", "9:16")
        tw, th = {"9:16": (120, 213), "16:9": (213, 120), "1:1": (160, 160)}.get(ratio, (120, 213))
        cards = []
        for i, scene in enumerate(self.project.scenes):
            card = tk.Frame(self.grid_frame, bg=SURFACE, padx=8, pady=8)
            cards.append(card)
            path = self.project.image(i)
            if path:
                img = Image.open(path)
                img.thumbnail((tw, th))
                photo = ImageTk.PhotoImage(img)
                self._thumbs.append(photo)
                tk.Label(card, image=photo, bg=SURFACE, width=tw, height=th).pack()
            else:
                tk.Label(card, text="ပုံ မရှိသေး", bg=FIELD, fg=MUTED, width=tw // 8, height=th // 18,
                         font=("Myanmar Text", 9)).pack()
            tk.Label(card, text=f"Scene {i + 1}", bg=SURFACE, fg=FG, font=("Segoe UI Semibold", 9)).pack(pady=(4, 2))
            row = tk.Frame(card, bg=SURFACE)
            row.pack()
            for text, cmd in (("Prompt", lambda i=i: self._copy_prompt(i)), ("Paste", lambda i=i: self._paste(i)),
                              ("File", lambda i=i: self._choose_file(i))):
                ttk.Button(row, text=text, style="Compact.TButton", width=6, command=cmd).pack(side="left", padx=1)
        self.grid_frame.update_idletasks()
        card_w = max(c.winfo_reqwidth() for c in cards) + 12
        per_row = max(1, (self.grid_canvas.winfo_width() or 1100) // card_w)
        for i, card in enumerate(cards):
            card.grid(row=i // per_row, column=i % per_row, padx=6, pady=6, sticky="n")
        have = len(self.project.scenes) - len(self.project.missing_images())
        self.image_count.configure(text=f"ပုံ {have} / {len(self.project.scenes)}")
        fal = bool((token_store.load_keys().get("fal") or "").strip())
        self.fal_btn.state(["!disabled"] if fal else ["disabled"])

    def _copy(self, text: str) -> None:
        self.clipboard_clear()
        self.clipboard_append(text)
        self.status.set("Copy ပြီးပါပြီ")

    def _copy_prompt(self, i: int) -> None:
        self._copy(self.project.scenes[i].get("image_prompt", ""))
        self.status.set(f"Scene {i + 1} prompt copy ပြီး — site မှာ paste ပါ")

    def _copy_all(self) -> None:
        if self.project:
            self._copy("\n\n".join(f"{i + 1:02d}. {s.get('image_prompt', '')}" for i, s in enumerate(self.project.scenes)))

    def _set_image(self, i: int, source) -> None:
        path = images.save_image(source, self.project.images_dir, i)
        self.project.set_image(i, path)
        self._build_cards()
        self._fill_scene_list()

    def _paste(self, i: int) -> None:
        image = images.clipboard_image()
        if image is None:
            self.status.set("Clipboard မှာ ပုံ မရှိပါ — ပုံပေါ်မှာ right-click → Copy image လုပ်ပြီးမှ Paste နှိပ်ပါ")
            return
        self._set_image(i, image)
        self.status.set(f"Scene {i + 1} ပုံ ထည့်ပြီး")

    def _choose_file(self, i: int) -> None:
        path = filedialog.askopenfilename(filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp")], parent=self)
        if path:
            self._set_image(i, path)

    def _load_folder(self) -> None:
        if not self.project:
            return
        folder = filedialog.askdirectory(title="ပုံတွေ (နာမည် အစဉ်လိုက် 01, 02…)", parent=self)
        if not folder:
            return
        found = images.folder_images(Path(folder))
        targets = self.project.missing_images() or list(range(len(self.project.scenes)))
        for i, path in zip(targets, found):
            self.project.set_image(i, images.save_image(path, self.project.images_dir, i))
        self._build_cards()
        self._fill_scene_list()
        self.status.set(f"ပုံ {min(len(found), len(targets))} ပုံ ထည့်ပြီး")

    def _fal_missing(self) -> None:
        key = (token_store.load_keys().get("fal") or "").strip()
        if not self.project or not key or self.busy:
            return
        missing = self.project.missing_images()
        if not missing:
            self.status.set("ပုံ အကုန်ရှိပြီးပါပြီ")
            return
        ratio = (self.project.data.get("settings") or {}).get("ratio", "9:16")
        self._set_busy(True, f"FAL နဲ့ ပုံ {len(missing)} ပုံ ထုတ်နေပါတယ်…")
        project = self.project

        def work():
            for n, i in enumerate(missing, 1):
                if self._stop:
                    break
                path = images.fal_generate(project.scenes[i].get("image_prompt", ""), key, ratio, project.images_dir, i)
                project.set_image(i, path)
                ui_thread.post(lambda n=n: self.status.set(f"FAL ပုံ {n}/{len(missing)}"))
            return len(missing)

        self._run(work, lambda n: (self._set_busy(False, "FAL ပုံတွေ ရပါပြီ"), self._build_cards(), self._fill_scene_list()))

    # ================================================================== ③ video
    def _build_video(self) -> None:
        tab = self.video_tab
        box = tk.Frame(tab, bg=SURFACE, padx=20, pady=16)
        box.pack(fill="x", padx=4, pady=4)
        c = self.cfg
        self.effect = tk.StringVar(value=EFFECT_LABELS.get(c.get("effect", "mix")))
        self.crossfade = tk.BooleanVar(value=c.get("crossfade", True))
        self.pause = tk.StringVar(value=str(c.get("pause", 0.35)))
        self.subtitles = tk.BooleanVar(value=c.get("subtitles", True))
        self.font_size = tk.StringVar(value=str(c.get("font_size", 0)))
        self.bgm = tk.StringVar(value=c.get("bgm", ""))
        self.bgm_volume = tk.StringVar(value=str(c.get("bgm_volume", 18)))
        self.out_folder = tk.StringVar(value=c.get("out_folder", ""))
        grid = tk.Frame(box, bg=SURFACE)
        grid.pack(fill="x")

        def row(r, text, *widgets):
            _label(grid, text).grid(row=r, column=0, sticky="w", pady=4, padx=(0, 12))
            for k, widget in enumerate(widgets, 1):
                widget.grid(row=r, column=k, sticky="w", pady=4, padx=(0, 8))

        row(0, "ပုံ ရွေ့ပုံ", ttk.Combobox(grid, textvariable=self.effect, values=list(EFFECT_LABELS.values()),
                                           state="readonly", width=24),
            tk.Checkbutton(grid, text="Scene ကူးရင် ဖြည်းဖြည်း ပြောင်း (crossfade)", variable=self.crossfade, bg=SURFACE,
                           fg=FG, selectcolor=FIELD, activebackground=SURFACE, activeforeground=FG,
                           font=("Myanmar Text", 10)))
        row(1, "Scene ကြား အနား (စက္ကန့်)", ttk.Spinbox(grid, from_=0.1, to=1.5, increment=0.05, textvariable=self.pause,
                                                         width=6))
        row(2, "စာတန်း", tk.Checkbutton(grid, text="ထည့်မယ်", variable=self.subtitles, bg=SURFACE, fg=FG,
                                         selectcolor=FIELD, activebackground=SURFACE, activeforeground=FG,
                                         font=("Myanmar Text", 10)),
            _label(grid, "အရွယ် (0 = အလိုလို)"), ttk.Spinbox(grid, from_=0, to=140, increment=2,
                                                            textvariable=self.font_size, width=6))
        row(3, "နောက်ခံ သီချင်း", ttk.Entry(grid, textvariable=self.bgm, width=46),
            ttk.Button(grid, text="Browse", style="Compact.TButton", command=self._browse_bgm),
            _label(grid, "အသံ %"), ttk.Spinbox(grid, from_=0, to=100, increment=2, textvariable=self.bgm_volume, width=5))
        row(4, "Output folder", ttk.Entry(grid, textvariable=self.out_folder, width=46),
            ttk.Button(grid, text="Browse", style="Compact.TButton", command=self._browse_out))
        buttons = tk.Frame(box, bg=SURFACE)
        buttons.pack(fill="x", pady=(12, 0))
        ttk.Button(buttons, text="🔊 အသံ နမူနာ (scene 1)", style="Compact.TButton", command=self._voice_test).pack(side="left")
        self.make_btn = ttk.Button(buttons, text="🎬  Video ထုတ်မယ်", style="Accent.TButton", command=self._make_video)
        self.make_btn.pack(side="left", padx=10)
        ttk.Button(buttons, text="Stop", style="Danger.TButton", command=self._request_stop).pack(side="left")
        self.progress = ttk.Progressbar(box, mode="determinate", maximum=100)
        self.progress.pack(fill="x", pady=(12, 4))
        self.video_status = _label(box, "", fg=MUTED, font=("Myanmar Text", 9), justify="left", wraplength=1000)
        self.video_status.pack(anchor="w")

    def _browse_bgm(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("Audio", "*.mp3 *.wav *.m4a *.aac *.ogg"), ("All", "*.*")],
                                          parent=self)
        if path:
            self.bgm.set(path)

    def _browse_out(self) -> None:
        folder = filedialog.askdirectory(title="Video ထားမယ့် folder", parent=self)
        if folder:
            self.out_folder.set(folder)

    def _voice_test(self) -> None:
        if not self.project or not self.project.scenes or self.busy:
            return
        s = self.project.data.get("settings") or {}
        text = self.project.scenes[0]["narration"]

        def work():
            return voice.synth(text, s.get("voice", "my-MM-ThihaNeural"), int(s.get("rate_percent", 0)),
                               self.project.voice_dir, "scene_001", ffmpeg_path(), keys=keys_file.gemini_keys(),
                               language=s.get("language", "my"), direction=s.get("voice_direction", ""))
        self._run(work, lambda path: os.startfile(path))

    def _request_stop(self) -> None:
        self._stop = True

    def _make_video(self) -> None:
        if self.busy or not self.project or not self.project.scenes:
            return
        self._save_scene(quiet=True)
        missing = self.project.missing_images()
        if missing:
            messagebox.showwarning("ပုံ", f"ပုံ မထည့်ရသေးတဲ့ scene: {', '.join(str(i + 1) for i in missing[:20])}"
                                   + (" …" if len(missing) > 20 else ""), parent=self)
            self.tabs.select(self.image_tab)
            return
        s = self.project.data.get("settings") or {}
        effect = next((k for k, v in EFFECT_LABELS.items() if v == self.effect.get()), "mix")
        opts = render.RenderOptions(ratio=s.get("ratio", "9:16"), effect=effect,
                                    crossfade=0.5 if self.crossfade.get() else 0.0,
                                    pause=self._float(self.pause, 0.35), subtitles=self.subtitles.get(),
                                    font_size=int(self._float(self.font_size, 0)), bgm=self.bgm.get().strip(),
                                    bgm_volume=self._float(self.bgm_volume, 18) / 100, language=s.get("language", "my"))
        self.cfg.update(effect=effect, crossfade=self.crossfade.get(), pause=opts.pause, subtitles=opts.subtitles,
                        font_size=opts.font_size, bgm=opts.bgm, bgm_volume=int(opts.bgm_volume * 100),
                        out_folder=self.out_folder.get().strip())
        CONFIG.write_text(json.dumps(self.cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        project, ffmpeg, keys = self.project, ffmpeg_path(), keys_file.gemini_keys()
        if voice.is_gemini(s.get("voice", "")) and not keys:
            messagebox.showwarning("Gemini key", "Gemini အသံအတွက် Profile မှာ Gemini API key ထည့်ပါ။", parent=self)
            return
        out_dir = Path(self.out_folder.get().strip() or project.folder)
        out = out_dir / f"{planner_slug(project.title())}.mp4"
        self._set_busy(True, "အသံ ထုတ်နေပါတယ်…")
        self.progress["value"] = 0

        def work():
            scenes = []
            for i, scene in enumerate(project.scenes):
                if self._stop:
                    raise InterruptedError("ရပ်လိုက်ပါပြီ")
                ui_thread.post(lambda i=i: self.video_status.configure(text=f"🔊 အသံ {i + 1}/{len(project.scenes)}"))
                audio = voice.synth(scene["narration"], s.get("voice", "my-MM-ThihaNeural"),
                                    int(s.get("rate_percent", 0)), project.voice_dir, f"scene_{i + 1:03d}", ffmpeg,
                                    keys=keys, language=s.get("language", "my"),
                                    direction=s.get("voice_direction", ""),
                                    log=lambda m: ui_thread.post(lambda m=m: self.video_status.configure(text=m)))
                scenes.append(render.Scene(project.image(i), audio, scene["narration"]))
            ui_thread.post(lambda: self.video_status.configure(text="🎬 Video ထုတ်နေပါတယ်…"))
            render.render(scenes, opts, project.work_dir, out, ffmpeg,
                          progress=lambda p: ui_thread.post(lambda p=p: self.progress.configure(value=p * 100)),
                          stop=lambda: self._stop)
            project.data["video"] = str(out)
            project.save()
            return out

        def done(path):
            self._set_busy(False, "Video ရပါပြီ")
            self.video_status.configure(text=f"✅ {path}")
            if self.app.session.is_vip_plus and messagebox.askyesno("Auto Posting", "ဒီ video ကို Auto Posting list ထဲ ထည့်မလား?",
                                                               parent=self):
                posting_queue.add(path, caption=project.title(), targets=[], origin="story_motion")
            os.startfile(path.parent)

        self._run(work, done)

    # ================================================================== helpers
    def _tab_changed(self, _event=None) -> None:
        self._save_scene(quiet=True)
        if self.tabs.select() == str(self.image_tab):
            self.after(50, self._build_cards)

    def _set_busy(self, busy: bool, text: str = "") -> None:
        self.busy = busy
        self._stop = False if busy else self._stop
        for button in (self.write_btn, self.make_btn):
            button.state(["disabled"] if busy else ["!disabled"])
        if text:
            self.status.set(text)

    def _run(self, work, done) -> None:
        def runner():
            try:
                from membership_access import require_vip
                require_vip("Story Motion")
                result = work()
                ui_thread.post(lambda: done(result) if self.winfo_exists() else None)
            except Exception as exc:  # noqa: BLE001
                ui_thread.post(lambda e=exc: self._failed(e))
        threading.Thread(target=runner, daemon=True).start()

    def _failed(self, exc: Exception) -> None:
        if not self.winfo_exists():
            return
        self._set_busy(False, f"⚠️ {str(exc)[:160]}")
        self.video_status.configure(text=f"⚠️ {exc}")
        self.log_line.configure(text=f"⚠️ {exc}")

    def shutdown(self) -> None:
        self._stop = True
        self._save_scene(quiet=True)


def planner_slug(title: str) -> str:
    from story_motion.project import slug
    return slug(title)
