"""Story Motion for the web UI: the same planner / voice / images / render modules the Tk screen used, as calls
that return plain data and background jobs that report with events (story_log, story_done, video_progress …)."""
from __future__ import annotations
import os

import base64
import io
import shutil
import threading
from dataclasses import asdict
from pathlib import Path
from typing import Callable

import keys_file
import token_store
from story_motion import images, planner, render, voice
from story_motion.project import Project, list_projects, slug

APP = Path(__file__).resolve().parent
ROOT = APP.parent
EFFECTS = {"mix": "Zoom + Pan အလှည့်ကျ", "zoom": "Zoom in / out", "pan": "ဘေးတိုက် / အပေါ်အောက် ရွေ့",
           "still": "မရွေ့ (ငြိမ်)"}


def ffmpeg_path() -> str:
    for candidate in (ROOT / "recap_tool_src" / "ffmpeg" / "ffmpeg.exe", shutil.which("ffmpeg")):
        if candidate and Path(candidate).is_file():
            return str(candidate)
    return "ffmpeg"


def image_data_url(path: Path, size: int = 360) -> str:
    """A small JPEG of a local picture for the page (the page cannot read local files)."""
    from PIL import Image
    image = Image.open(path)
    image.thumbnail((size, size * 2))
    buf = io.BytesIO()
    image.convert("RGB").save(buf, "JPEG", quality=82)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")


def settings_from(data: dict) -> planner.StorySettings:
    s = planner.StorySettings()
    for key in asdict(s):
        if key in data and data[key] not in (None, ""):
            setattr(s, key, type(getattr(s, key))(data[key]) if not isinstance(getattr(s, key), dict) else data[key])
    _n, s.units_per_scene, _t = planner.plan_numbers(s.minutes, s.language, s.voice, s.rate_percent, s.scene_count)
    if not voice.is_gemini(s.voice):
        s.voice_direction = ""
    return s


class StoryJobs:
    def __init__(self, emit: Callable[..., None]) -> None:
        self.emit = emit
        self.busy = False
        self.stop = False

    # ------------------------------------------------------------------ data
    def options(self, cfg: dict) -> dict:
        return {"genres": planner.GENRES, "styles": list(planner.IMAGE_STYLES), "ratios": ["9:16", "16:9", "1:1"],
                "voices": voice.VOICES, "default_voice": voice.DEFAULT_VOICE, "effects": EFFECTS, "qualities": __import__("video_quality").LABELS,
                "sites": list(images.SITES), "last": cfg.get("story_motion_last") or {},
                "video": cfg.get("story_motion_video") or {},
                "fal": bool((token_store.load_keys().get("fal") or "").strip())}

    def projects(self, root: Path) -> list[dict]:
        return [{"folder": str(p.folder), "title": p.title(), "date": p.folder.name[:13],
                 "scenes": len(p.scenes), "images": len(p.scenes) - len(p.missing_images()),
                 "video": p.data.get("video") or ""} for p in list_projects(root)]

    def load(self, folder: str) -> dict:
        p = Project(Path(folder))
        return {"folder": str(p.folder), "title": p.title(), "settings": p.data.get("settings") or {},
                "scenes": p.scenes, "has_image": [p.image(i) is not None for i in range(len(p.scenes))],
                "video": p.data.get("video") or "",
                "characters": (p.data.get("story") or {}).get("characters") or []}

    def numbers(self, data: dict) -> dict:
        s = settings_from(data)
        auto, _per, _t = planner.plan_numbers(s.minutes, s.language, s.voice, s.rate_percent)
        return {"auto_scenes": auto, "scenes": s.scene_count, "per_scene": s.units_per_scene,
                "seconds": round(s.minutes * 60 / max(1, s.scene_count)), "total": s.units_per_scene * s.scene_count,
                "unit": "လုံး" if s.language == "my" else "words"}

    # ------------------------------------------------------------------ story
    def write(self, data: dict, folder: str, root: Path) -> bool:
        if self.busy:
            return False
        keys = keys_file.gemini_keys()
        if not keys:
            raise RuntimeError("Profile မှာ Gemini API key အရင်ထည့်ပါ")
        s = settings_from(data)
        self.busy, self.stop = True, False

        def run():
            try:
                story = planner.write_story(s, keys, log=lambda m: self.emit("story_log", line=m))
                project = Project(Path(folder)) if folder else Project.create(root, story.get("title") or "story")
                project.data.update(settings=story["settings"], story=story, images={}, video="")
                project.save()
                self.emit("story_done", project=self.load(str(project.folder)))
            except Exception as exc:  # noqa: BLE001
                self.emit("story_error", message=str(exc))
            finally:
                self.busy = False
        threading.Thread(target=run, daemon=True).start()
        return True

    def save_scene(self, folder: str, index: int, narration: str, prompt: str) -> dict:
        p = Project(Path(folder))
        scene = p.scenes[int(index)]
        scene["narration"], scene["image_prompt"] = narration.strip(), prompt.strip()
        p.save()
        s = p.data.get("settings") or {}
        lang = s.get("language", "my")
        n = planner.count_units(scene["narration"], lang)
        seconds = n / planner.speech_rate(lang, s.get("voice", ""), int(s.get("rate_percent", 0)))
        return {"count": n, "seconds": round(seconds)}

    def save_title(self, folder: str, title: str) -> bool:
        p = Project(Path(folder))
        if p.data.get("story") is not None and title.strip():
            p.data["story"]["title"] = title.strip()
            p.save()
        return True

    # ------------------------------------------------------------------ images
    def image(self, folder: str, index: int) -> str:
        path = Project(Path(folder)).image(int(index))
        return image_data_url(path) if path else ""

    def set_image_data(self, folder: str, index: int, data_url: str) -> str:
        from PIL import Image
        raw = base64.b64decode(data_url.split(",", 1)[1])
        p = Project(Path(folder))
        path = images.save_image(Image.open(io.BytesIO(raw)), p.images_dir, int(index))
        p.set_image(int(index), path)
        return self.image(folder, index)

    def set_image_file(self, folder: str, index: int, source: str) -> str:
        p = Project(Path(folder))
        p.set_image(int(index), images.save_image(source, p.images_dir, int(index)))
        return self.image(folder, index)

    def load_folder(self, folder: str, source: str) -> int:
        p = Project(Path(folder))
        found = images.folder_images(Path(source))
        targets = p.missing_images() or list(range(len(p.scenes)))
        for i, path in zip(targets, found):
            p.set_image(i, images.save_image(path, p.images_dir, i))
        return min(len(found), len(targets))

    def fal_missing(self, folder: str) -> bool:
        key = (token_store.load_keys().get("fal") or "").strip()
        if not key:
            raise RuntimeError("Profile မှာ FAL key ထည့်ပါ")
        if self.busy:
            return False
        p = Project(Path(folder))
        missing = p.missing_images()
        ratio = (p.data.get("settings") or {}).get("ratio", "9:16")
        self.busy, self.stop = True, False

        def run():
            try:
                for n, i in enumerate(missing, 1):
                    if self.stop:
                        break
                    path = images.fal_generate(p.scenes[i].get("image_prompt", ""), key, ratio, p.images_dir, i)
                    p.set_image(i, path)
                    self.emit("image_ready", index=i, done=n, total=len(missing))
                self.emit("fal_done")
            except Exception as exc:  # noqa: BLE001
                self.emit("story_error", message=str(exc))
            finally:
                self.busy = False
        threading.Thread(target=run, daemon=True).start()
        return True

    # ------------------------------------------------------------------ voice + video
    def _synth(self, p: Project, i: int, keys: list[str]) -> Path:
        from own_voice import VoiceStore
        parts = VoiceStore(p.folder).resolve([{"id": str(i), "text": p.scenes[i]["narration"]}])
        if parts is not None:
            return parts[0]
        s = p.data.get("settings") or {}
        return voice.synth(p.scenes[i]["narration"], s.get("voice", voice.DEFAULT_VOICE["my"]),
                           int(s.get("rate_percent", 0)), p.voice_dir, f"scene_{i + 1:03d}", ffmpeg_path(),
                           keys=keys, language=s.get("language", "my"), direction=s.get("voice_direction", ""),
                           log=lambda m: self.emit("video_log", line=m))

    def voice_test(self, folder: str) -> bool:
        p = Project(Path(folder))
        keys = keys_file.gemini_keys()

        def run():
            try:
                out = self._synth(p, 0, keys)
                if os.environ.get("STUDIO99_WEB_MODE") == "colab" or os.name != "nt":
                    from urllib.parse import quote
                    self.emit("story_voice_ready", path=str(out), url=f"/api/media?path={quote(str(out))}")
                else:
                    os.startfile(out)
            except Exception as exc:  # noqa: BLE001
                self.emit("video_error", message=str(exc))
        threading.Thread(target=run, daemon=True).start()
        return True

    def own_voice(self, folder: str, auth_env=None) -> bool:
        if os.environ.get("STUDIO99_WEB_MODE") == "colab" or os.name != "nt":
            raise RuntimeError("Own Voice recorder window ကို Colab မှာ မပံ့ပိုးပါ — Gemini သို့မဟုတ် Edge TTS voice ကို ရွေးသုံးပါ။")
        if self.busy:
            raise RuntimeError("လက်ရှိလုပ်ဆောင်မှု ပြီးတဲ့အထိ စောင့်ပါ")
        import subprocess
        import sys
        import json
        from own_voice import VoiceStore
        p = Project(Path(folder))
        rows = [{"id": str(i), "text": scene["narration"]} for i, scene in enumerate(p.scenes)]
        if not rows:
            raise RuntimeError("Story အရင်ရေးပါ")
        path = VoiceStore(p.folder).root / "script.json"
        path.write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")
        self.busy = True
        try:
            from own_voice import ChildJob
            proc = subprocess.Popen([sys.executable, "-X", "utf8", str(APP / "own_voice_editor.py"), str(p.folder), str(path)],
                                    env={**os.environ, **(auth_env or {})},
                                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            try:
                job = ChildJob(proc)
            except Exception:
                proc.terminate()
                proc.wait(timeout=5)
                raise
            try:
                if proc.wait():
                    raise RuntimeError("အသံသွင်းခန်းကို ဖွင့်မရပါ")
            finally:
                job.close()
        finally:
            self.busy = False
        return True

    def make_video(self, folder: str, opts: dict) -> bool:
        if self.busy:
            return False
        p = Project(Path(folder))
        missing = p.missing_images()
        if missing:
            raise RuntimeError("ပုံ မထည့်ရသေးတဲ့ scene: " + ", ".join(str(i + 1) for i in missing[:20]))
        s = p.data.get("settings") or {}
        keys = keys_file.gemini_keys()
        from own_voice import VoiceStore
        own_parts = VoiceStore(p.folder).resolve(
            [{"id": str(i), "text": scene["narration"]} for i, scene in enumerate(p.scenes)])
        if own_parts is None and voice.is_gemini(s.get("voice", "")) and not keys:
            raise RuntimeError("Gemini အသံအတွက် Profile မှာ Gemini API key ထည့်ပါ")
        ro = render.RenderOptions(ratio=s.get("ratio", "9:16"), effect=opts.get("effect", "mix"),
                                  crossfade=0.5 if opts.get("crossfade", True) else 0.0,
                                  pause=float(opts.get("pause") or 0.35), subtitles=bool(opts.get("subtitles", True)),
                                  font_size=int(opts.get("font_size") or 0), bgm=str(opts.get("bgm") or ""),
                                  bgm_volume=float(opts.get("bgm_volume") or 18) / 100,
                                  language=s.get("language", "my"), quality=str(opts.get("quality") or "1080"))
        out = Path(opts.get("out_folder") or p.folder) / f"{slug(p.title())}.mp4"
        self.busy, self.stop = True, False

        def run():
            try:
                scenes = []
                for i, scene in enumerate(p.scenes):
                    if self.stop:
                        raise InterruptedError("ရပ်လိုက်ပါပြီ")
                    self.emit("video_progress", stage="voice", done=i, total=len(p.scenes))
                    scenes.append(render.Scene(p.image(i), self._synth(p, i, keys), scene["narration"]))
                self.emit("video_progress", stage="render", percent=0)
                render.render(scenes, ro, p.work_dir, out, ffmpeg_path(),
                              progress=lambda x: self.emit("video_progress", stage="render", percent=round(x * 100)),
                              stop=lambda: self.stop)
                p.data["video"] = str(out)
                p.save()
                import history
                history.add("story_motion", out, p.title())
                self.emit("video_done", path=str(out), title=p.title())
            except Exception as exc:  # noqa: BLE001
                self.emit("video_error", message=str(exc))
            finally:
                self.busy = False
        threading.Thread(target=run, daemon=True).start()
        return True
