"""This Windows build's number. The server can stop older builds: when recap_pro_app_settings has a row
key_name "min_windows_build" with a bigger number, login/refresh says "update" (pb_client.check_build). Raise BUILD
with every installer that must replace the older ones (date-based: YYYYMMDD; the phone app has its own number)."""
BUILD = 20261106
