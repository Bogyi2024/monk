"""One CLI tool run in its own process for the web UI (Novel, Movie Review): output lines → events, stop kills the
whole process tree (FFmpeg/Chromium children too)."""
from __future__ import annotations

import os
import subprocess
import sys
import threading
from pathlib import Path
from typing import Callable

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def python_exe() -> str:
    exe = Path(sys.executable).with_name("python.exe")
    return str(exe if exe.exists() else sys.executable)


def stop_process(proc) -> None:
    """Stop only the process tree owned by this app's job."""
    if proc is None or proc.poll() is not None:
        return
    if os.name == "nt":
        result = subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True,
                                creationflags=NO_WINDOW)
        if result.returncode and proc.poll() is None:
            proc.terminate()
    else:
        proc.terminate()


class ToolJob:
    def __init__(self, name: str, emit: Callable[..., None]) -> None:
        self.name, self.emit = name, emit
        self.proc: subprocess.Popen | None = None
        self.stopped = False

    @property
    def running(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def start(self, args: list[str], cwd: Path, env: dict, done: Callable[[int, list[str]], None], usage=None) -> bool:
        if self.running:
            return False
        self.stopped = False
        full_env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", **env)
        if usage is not None:
            usage.__enter__()
        try:
            self.proc = subprocess.Popen([python_exe(), "-u", "-X", "utf8", *args], cwd=str(cwd), env=full_env,
                                         stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                         text=True, encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
        except BaseException:
            if usage is not None:
                usage.__exit__(*sys.exc_info())
            raise
        proc = self.proc

        def pump():
            lines: list[str] = []
            for line in proc.stdout:
                line = line.rstrip("\n")
                lines.append(line)
                self.emit(f"{self.name}_log", line=line)
            code = proc.wait()
            try:
                if usage is not None:
                    if self.stopped or code:
                        usage.__exit__(InterruptedError, InterruptedError("job did not complete"), None)
                    else:
                        usage.__exit__(None, None, None)
                done(-1 if self.stopped else code, lines)
            except Exception as exc:  # noqa: BLE001
                self.emit(f"{self.name}_error", message=str(exc))
        threading.Thread(target=pump, daemon=True).start()
        return True

    def stop(self) -> None:
        if self.running:
            self.stopped = True
            stop_process(self.proc)
