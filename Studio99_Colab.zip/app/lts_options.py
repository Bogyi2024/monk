"""Per-job Long to Short export choices shared by the UI and copied worker."""
import copy
import math


def normalize_export_options(subtitles_enabled=True, output_ratio="9:16", clip_minutes=None):
    if not isinstance(subtitles_enabled, bool):
        raise ValueError("စာတန်းထိုး ON/OFF ကို ရွေးပါ။")
    ratio = "Original" if str(output_ratio).lower() == "original" else str(output_ratio)
    if ratio not in {"9:16", "Original"}:
        raise ValueError("Video size ကို 9:16 သို့မဟုတ် Original ရွေးပါ။")
    minutes = None
    if clip_minutes not in (None, "", "auto"):
        try:
            minutes = float(clip_minutes)
        except (TypeError, ValueError):
            raise ValueError("Clip အရှည်ကို မိနစ်ဖြင့် ထည့်ပါ။") from None
        if not math.isfinite(minutes) or not .25 <= minutes <= 10:
            raise ValueError("Clip အရှည်ကို 0.25–10 မိနစ်အတွင်း ထည့်ပါ။")
    return {"subtitles_enabled": subtitles_enabled, "output_ratio": ratio, "clip_minutes": minutes}


def export_config(config, options):
    cfg = copy.deepcopy(config)
    cfg["render_subtitles"] = options["subtitles_enabled"]
    cfg["output_ratio"] = options["output_ratio"]
    cfg["requested_clip_minutes"] = options["clip_minutes"]
    if options["clip_minutes"] is not None:
        seconds = options["clip_minutes"] * 60
        cfg.update(clip_min_seconds=seconds * .85, clip_preferred_min_seconds=seconds * .95,
                   clip_preferred_max_seconds=seconds * 1.05, clip_max_seconds=seconds * 1.1)
        commentary = cfg.setdefault("commentary", {})
        commentary.update(target_words_min=max(25, round(seconds * 2.3)),
                          target_words_max=max(35, round(seconds * 2.8)),
                          min_segments=max(3, round(seconds / 9)),
                          max_segments=max(4, round(seconds / 7)), reuse_compatible_cache=False)
        voice = cfg.setdefault("english_voiceover", {})
        voice.update(min_publish_seconds=seconds * .85, target_publish_seconds=seconds * .95)
    return cfg


def apply_source_geometry(config, media):
    if config.get("output_ratio") == "Original":
        video = media.get("video") or {}
        width, height = int(video.get("width") or 0), int(video.get("height") or 0)
        if width <= 0 or height <= 0:
            raise ValueError("မူရင်း video အရွယ်အစားကို ဖတ်မရပါ။")
        config["target_width"], config["target_height"] = max(2, width // 2 * 2), max(2, height // 2 * 2)
        config.setdefault("video_framing", {})["mode"] = "original"
        scale = min(1.0, width / 1080, height / 1080)
        subtitles = config.setdefault("myanmar_subtitle", {})
        subtitles.update(plate_width=max(64, round(width * .96)),
                         plate_height=max(48, round(220 * scale)),
                         font_size=max(14, round(58 * scale)), min_font_size=max(10, round(42 * scale)))
    return config
