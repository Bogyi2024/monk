"""Headless Colab runner for Studio99 Subtitle (wraps tool_apps/subtitle/core.py)."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import uuid
from pathlib import Path
from typing import Any

APP = Path(__file__).resolve().parent
ROOT = APP.parent
TOOL = ROOT / "tool_apps" / "subtitle"
DATA = Path(os.environ.get("STUDIO99_COLAB_DATA", "/content/Studio99Data")).resolve()
OUTPUTS = DATA / "subtitle_outputs"
CONFIG_FILE = DATA / "subtitle_colab.json"
VIDEO_EXTS = {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v"}
_EVENT = "@@S99_SUB@@"

SOURCE_LANGUAGES = [
    ["auto", "Auto-detect"], ["en", "English"], ["zh", "Chinese"], ["ko", "Korean"],
    ["ja", "Japanese"], ["th", "Thai"], ["vi", "Vietnamese"], ["hi", "Hindi"],
    ["es", "Spanish"], ["fr", "French"], ["de", "German"], ["id", "Indonesian"],
]
DEFAULTS: dict[str, Any] = {
    "source_language": "auto",
    "whisper_model": "medium",
    "gemini_model": "gemini-3.5-flash",
    "font_size": 48,
    "bottom_margin": 64,
    "srt_only": False,
    "title": "",
    "part": "",
    "watermark": "",
    "speaker_context": "",
    "audio_crosscheck": False,
    "chunk_minutes": 15,
    "translation_workers": 4,
    "cues_per_request": 10,
    "subtitle_bold": False,
    "subtitle_color": "#FFFFFF",
    "outline_color": "#252525",
    "box_enabled": True,
    "box_color": "#383838",
    "box_opacity": 62,
    "split_minutes": 0,
    "name_memory": True,
    "output_dir": "",
}


def _within_colab(path: Path) -> bool:
    from colab_runtime import _within_colab as _ok
    return _ok(path)


def _validate_video(raw: str) -> Path:
    if not raw or len(raw) > 4096:
        raise ValueError("Video path ထည့်ပါ။")
    p = Path(raw).expanduser().resolve()
    if not _within_colab(p) or not p.is_file() or p.suffix.lower() not in VIDEO_EXTS:
        raise ValueError("/content အောက်က ဖတ်လို့ရတဲ့ video ဖိုင်ကို ရွေးပါ။")
    return p


def _load_saved() -> dict[str, Any]:
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {**DEFAULTS, **data}
    except (OSError, ValueError):
        pass
    return dict(DEFAULTS)


def _save_settings(s: dict[str, Any]) -> None:
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")


class ColabSubtitleJobs:
    def __init__(self, emit):
        self.emit = emit
        self.lock = threading.RLock()
        self.current: dict[str, Any] | None = None
        self.proc: subprocess.Popen | None = None
        self.logs: list[str] = []

    def options(self) -> dict:
        OUTPUTS.mkdir(parents=True, exist_ok=True)
        recent = [
            {"name": p.name, "path": str(p)}
            for p in sorted(
                (p for p in OUTPUTS.rglob("*") if p.is_file() and p.suffix.lower() in {".mp4", ".srt"}),
                key=lambda x: x.stat().st_mtime, reverse=True,
            )[:30]
        ]
        return {
            "languages": SOURCE_LANGUAGES,
            "whisper_models": [["small", "small"], ["medium", "medium"], ["large-v3", "large-v3"]],
            "gemini_models": [
                ["gemini-3.5-flash", "gemini-3.5-flash"],
                ["gemini-3.5-flash-lite", "gemini-3.5-flash-lite"],
                ["gemini-2.5-flash", "gemini-2.5-flash"],
            ],
            "defaults": _load_saved(),
            "recent_outputs": recent,
        }

    def status(self) -> dict:
        with self.lock:
            base = dict(self.current) if self.current else {
                "status": "idle", "progress": 0, "stage": "Ready", "job_id": "", "outputs": [], "error": "",
            }
            base["logs"] = self.logs[-250:]
            return base

    def start(self, request: dict) -> dict:
        if not isinstance(request, dict):
            raise ValueError("Subtitle settings မမှန်ပါ။")
        video = _validate_video(str(request.get("source_path") or ""))
        source_srt_raw = str(request.get("source_srt") or "").strip()
        source_srt = ""
        if source_srt_raw:
            sp = Path(source_srt_raw).expanduser().resolve()
            if not _within_colab(sp) or not sp.is_file():
                raise ValueError("SRT ဖိုင် မတွေ့ပါ။")
            source_srt = str(sp)
        merged = {**_load_saved(), **{k: request[k] for k in DEFAULTS if k in request}}
        _save_settings(merged)
        out_raw = str(merged.get("output_dir") or "").strip()
        out_dir = Path(out_raw).expanduser().resolve() if out_raw else OUTPUTS
        if out_raw and not _within_colab(out_dir):
            raise ValueError("Output folder ကို /content အောက်မှာသာ ထားပါ။")
        out_dir.mkdir(parents=True, exist_ok=True)

        with self.lock:
            if self.current and self.current.get("status") in {"starting", "running", "stopping"}:
                raise RuntimeError("Subtitle job တစ်ခု လုပ်နေဆဲပါ။")
            jid = uuid.uuid4().hex
            self.logs = []
            self.current = {
                "job_id": jid, "status": "starting", "progress": 0, "stage": "Preparing Subtitle",
                "source": video.name, "output_dir": str(out_dir), "outputs": [], "error": "",
            }
            threading.Thread(target=self._run, args=(jid, video, source_srt, out_dir, merged), daemon=True).start()
            return {"job_id": jid, "status": "starting"}

    def stop(self) -> dict:
        with self.lock:
            if self.current and self.current.get("status") in {"starting", "running"}:
                self.current.update(status="stopping", stage="Stopping Subtitle")
            proc = self.proc
        if proc and proc.poll() is None:
            try:
                from web_tool_job import stop_process
                stop_process(proc)
            except Exception:
                try:
                    proc.terminate()
                except Exception:
                    pass
        return self.status()

    def _log(self, jid: str, line: str) -> None:
        text = str(line).rstrip()
        if not text:
            return
        with self.lock:
            if self.current and self.current.get("job_id") == jid:
                self.logs.append(text)
                self.logs = self.logs[-500:]
        self.emit("subtitle_log", job_id=jid, line=text)

    def _progress(self, jid: str, pct: int, stage: str) -> None:
        pct = max(0, min(100, int(pct)))
        with self.lock:
            if self.current and self.current.get("job_id") == jid:
                self.current.update(status="running", progress=pct, stage=stage)
        self.emit("subtitle_progress", job_id=jid, progress=pct, stage=stage)

    def _run(self, jid: str, video: Path, source_srt: str, out_dir: Path, s: dict[str, Any]) -> None:
        try:
            import keys_file
            env_file = keys_file.write()
            if not env_file or not keys_file.gemini_keys():
                raise RuntimeError("Profile မှာ Gemini API key အရင်ထည့်ပါ။")
            payload = {
                **s,
                "video": str(video),
                "source_srt": source_srt,
                "output_dir": str(out_dir),
                "env_file": str(env_file),
            }
            cfg_path = DATA / "tmp" / f"subtitle_cfg_{jid}.json"
            cfg_path.parent.mkdir(parents=True, exist_ok=True)
            cfg_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

            env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", STUDIO99="1", STUDIO99_LOCAL="1")
            proc = subprocess.Popen(
                [sys.executable, "-u", "-X", "utf8", str(Path(__file__).resolve()), str(cfg_path)],
                cwd=str(TOOL), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace", bufsize=1,
            )
            with self.lock:
                self.proc = proc
            result_paths: list[str] = []
            error_msg = ""
            assert proc.stdout is not None
            for raw in proc.stdout:
                line = raw.rstrip("\r\n")
                if line.startswith(_EVENT):
                    try:
                        ev = json.loads(line[len(_EVENT):])
                    except ValueError:
                        self._log(jid, line)
                        continue
                    kind = ev.get("kind")
                    if kind == "progress":
                        self._progress(jid, int(ev.get("percent", 0)), str(ev.get("stage", "")))
                    elif kind == "done":
                        result_paths = [str(x) for x in (ev.get("outputs") or []) if x]
                    elif kind == "error":
                        error_msg = str(ev.get("message") or "")
                else:
                    self._log(jid, line)
            rc = proc.wait()
            with self.lock:
                self.proc = None
                was_stopping = bool(self.current and self.current.get("status") == "stopping")
            if was_stopping:
                with self.lock:
                    self.current.update(status="stopped", stage="Stopped")
                self.emit("subtitle_stopped", job_id=jid)
                return
            if rc != 0:
                raise RuntimeError(error_msg or f"Subtitle worker exited with code {rc}")
            with self.lock:
                self.current.update(status="done", progress=100, stage="Completed", outputs=result_paths, error="")
            self.emit("subtitle_done", job_id=jid, outputs=result_paths)
        except Exception as exc:
            self._log(jid, f"❌ {exc}")
            with self.lock:
                if self.current and self.current.get("job_id") == jid:
                    self.current.update(status="error", stage="Error", error=str(exc))
            self.emit("subtitle_error", job_id=jid, message=str(exc))


def _worker_main(cfg_path: str) -> int:
    """Isolated worker process so Whisper/CUDA never shares memory with the web server."""
    if str(TOOL) not in sys.path:
        sys.path.insert(0, str(TOOL))
    data = json.loads(Path(cfg_path).read_text(encoding="utf-8"))
    import core

    font_name = "Myanmar Text" if os.name == "nt" else "Noto Sans Myanmar"
    opts = core.Options(
        video=Path(data["video"]),
        output_dir=Path(data["output_dir"]),
        source_srt=Path(data["source_srt"]) if data.get("source_srt") else None,
        source_language=str(data.get("source_language") or "auto"),
        whisper_model=str(data.get("whisper_model") or "medium"),
        gemini_model=str(data.get("gemini_model") or "gemini-3.5-flash"),
        env_file=Path(data["env_file"]) if data.get("env_file") else None,
        font_size=int(data.get("font_size", 48)),
        bottom_margin=int(data.get("bottom_margin", 64)),
        srt_only=bool(data.get("srt_only", False)),
        title=str(data.get("title") or ""),
        part=str(data.get("part") or ""),
        watermark=str(data.get("watermark") or ""),
        speaker_context=str(data.get("speaker_context") or ""),
        audio_crosscheck=bool(data.get("audio_crosscheck", False)),
        chunk_minutes=float(data.get("chunk_minutes", 15)),
        translation_workers=int(data.get("translation_workers", 4)),
        cues_per_request=int(data.get("cues_per_request", 10)),
        subtitle_font=font_name,
        subtitle_bold=bool(data.get("subtitle_bold", False)),
        overlay_font=font_name,
        subtitle_color=str(data.get("subtitle_color") or "#FFFFFF"),
        outline_color=str(data.get("outline_color") or "#252525"),
        box_enabled=bool(data.get("box_enabled", True)),
        box_color=str(data.get("box_color") or "#383838"),
        box_opacity=int(data.get("box_opacity", 62)),
        split_minutes=float(data.get("split_minutes", 0)),
        name_memory=bool(data.get("name_memory", True)),
    )

    def on_progress(fraction: float, stage: str = "") -> None:
        pct = max(0, min(99, int(float(fraction) * 100)))
        print(_EVENT + json.dumps({"kind": "progress", "percent": pct, "stage": str(stage)}), flush=True)

    try:
        res = core.run(opts, log=lambda m: print(str(m), flush=True), progress=on_progress)
        outputs: list[str] = []
        if isinstance(res, dict):
            for key in ("video", "output", "srt", "burmese_srt", "parts_dir"):
                val = res.get(key)
                if val and Path(str(val)).exists():
                    outputs.append(str(val))
            for item in (res.get("parts") or []):
                if item and Path(str(item)).exists():
                    outputs.append(str(item))
        print(_EVENT + json.dumps({"kind": "done", "outputs": outputs}), flush=True)
        return 0
    except Exception as exc:
        print(_EVENT + json.dumps({"kind": "error", "message": str(exc)}), flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(_worker_main(sys.argv[1]))
