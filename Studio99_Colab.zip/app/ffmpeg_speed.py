"""Encode speed for the copied tools (Dubbing, Subtitle, Original→Recap, Long to Short) — user, 2026-10-24: low-end
PCs take very long. Their own render code is not changed (it is a copy of the user's tools, kept in step by
tools/sync_tools.py): this module is loaded into every Python process such a tool starts (sitehook/sitecustomize.py,
or the exe launcher) and makes the H.264 settings of its FFmpeg calls faster at the level chosen in Studio99.
Frame size, timing and everything else stay exactly as the tool makes them.

Measured at 1080p, 20 s of a real video, 4 CPU threads: libx264 medium crf18 40.2 s, veryfast crf20 14.5 s,
superfast crf23 8.9 s. "normal" = no change. A setting is only ever made faster, never slower."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

LEVELS = ("normal", "fast", "fastest")
LABELS = {"normal": "ပုံမှန် (အခုအတိုင်း)", "fast": "မြန် (~၃ ဆ)", "fastest": "အမြန်ဆုံး (~၄-၅ ဆ · စက်နိမ့်)"}
X264 = {"fast": ("veryfast", 20), "fastest": ("superfast", 23)}
NVENC = {"fast": ("p4", 21), "fastest": ("p3", 24)}
X264_ORDER = ["placebo", "veryslow", "slower", "slow", "medium", "fast", "faster", "veryfast", "superfast", "ultrafast"]
SPEED_FILE = Path(os.environ.get("APPDATA") or Path.home()) / "Studio99Desktop" / "tool_speed.json"


def load() -> dict[str, str]:
    try:
        data = json.loads(SPEED_FILE.read_text(encoding="utf-8"))
        return {str(k): str(v) for k, v in data.items() if v in LEVELS} if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save(tool: str, level: str) -> dict[str, str]:
    data = load()
    data[tool] = level if level in LEVELS else "normal"
    SPEED_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = SPEED_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=1), encoding="utf-8")
    tmp.replace(SPEED_FILE)
    return data


def level(tool: str | None = None) -> str:
    tool = tool or os.environ.get("STUDIO99_TOOL_ID") or ""
    return load().get(tool, "normal") if tool else "normal"


def _value_after(args: list[str], flags: tuple[str, ...]) -> str:
    for i, a in enumerate(args[:-1]):
        if a in flags:
            return args[i + 1]
    return ""


def _set(args: list[str], flag: str, value: str, after: int) -> None:
    hits = [i for i, a in enumerate(args[:-1]) if a == flag]
    for i in hits:
        args[i + 1] = value
    if not hits:
        args[after + 1:after + 1] = [flag, value]


def faster(args, lvl: str):
    """The same FFmpeg command with faster H.264 settings (args unchanged when it is not such a command)."""
    if lvl not in X264 or not isinstance(args, (list, tuple)) or not args:
        return args
    if not Path(str(args[0])).name.lower().startswith("ffmpeg"):
        return args
    a = [str(x) for x in args]
    flags = ("-c:v", "-vcodec", "-codec:v")
    codec = _value_after(a, flags)
    if codec not in ("libx264", "h264_nvenc"):
        return args
    at = next(i for i, x in enumerate(a[:-1]) if x in flags and a[i + 1] == codec) + 1
    if codec == "libx264":
        preset, crf = X264[lvl]
        now = _value_after(a, ("-preset",)) or "medium"
        if now in X264_ORDER and X264_ORDER.index(now) < X264_ORDER.index(preset):
            _set(a, "-preset", preset, at)
        old = _value_after(a, ("-crf",))
        if old and old.replace(".", "", 1).isdigit() and float(old) < crf:
            _set(a, "-crf", str(crf), at)
    else:
        preset, cq = NVENC[lvl]
        now = _value_after(a, ("-preset",))
        if now.startswith("p") and now[1:].isdigit() and int(now[1:]) > int(preset[1:]):
            _set(a, "-preset", preset, at)
        old = _value_after(a, ("-cq",))
        if old.isdigit() and int(old) < cq:
            _set(a, "-cq", str(cq), at)
    return a


_installed = False


def install() -> None:
    """Every subprocess.Popen in this process (subprocess.run, asyncio …) goes through faster()."""
    global _installed
    if _installed or not os.environ.get("STUDIO99_TOOL_ID"):
        return
    _installed = True
    original = subprocess.Popen.__init__

    def init(self, args, *rest, **kwargs):
        lvl = level()
        if lvl != "normal":
            args = faster(args, lvl)
        original(self, args, *rest, **kwargs)
    subprocess.Popen.__init__ = init


def child_env(env: dict, tool: str) -> dict:
    """The environment for a copied tool's process: its id, and this hook loaded into it and its children."""
    app = Path(__file__).resolve().parent
    hook = str(app / "sitehook")
    env = dict(env)
    env["STUDIO99_TOOL_ID"] = tool
    env["STUDIO99_APP_DIR"] = str(app)
    env["PYTHONPATH"] = hook + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    return env
