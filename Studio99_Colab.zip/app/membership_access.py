"""Current membership for native Desktop editors/workers; developer fixtures stay isolated."""
from __future__ import annotations

import os
import sys
import threading
import time

import local_mode
from pb_client import PocketBase, ServerUnreachable

_provider = None
_cached = None
_cached_key = None
_checked = 0.0
_lock = threading.Lock()
_local = None                      # the one session local mode hands out (stable id for callers)


def bind_session(provider):
    global _provider, _cached, _cached_key, _checked
    with _lock:
        _provider, _cached, _cached_key, _checked = provider, None, None, 0.0


def desktop_context():
    return bool(_provider or getattr(sys, "frozen", False) or os.environ.get("STUDIO99")
                or os.environ.get("STUDIO99_TOKEN") or os.environ.get("STUDIO99_EMBED"))


def current_session(force=False):
    global _cached, _cached_key, _checked, _local
    if local_mode.enabled():                 # offline developer mode: no server, VIP+ locally
        if _local is None:
            _local = local_mode.session()
        return _local
    provider = _provider
    original = provider() if provider is not None else None
    if provider is not None and original is None:
        raise RuntimeError("Studio99 မှာ Login ပြန်ဝင်ပါ။")
    token = original.token if original is not None else os.environ.get("STUDIO99_TOKEN", "")
    if not token:
        raise RuntimeError("Studio99 မှာ Login ဝင်ပြီး tool ကို ပြန်ဖွင့်ပါ။")
    from app_config import load_config
    server = os.environ.get("STUDIO99_SERVER") or load_config().get("server") or "https://api.recapboxx.com"
    with _lock:
        key = (server, token, id(provider), id(original) if provider is not None else None)
        if force or _cached_key != key or time.monotonic() - _checked >= 30:
            client = PocketBase(server)
            try:
                source = original if original is not None else (_cached if _cached_key == key else None)
                current = client.notification_account(source) if source is not None else client.refresh(token)
                client.check_build(current.token)
            except ServerUnreachable:
                current = original if original is not None else (_cached if _cached_key == key else None)
                if current is None:
                    raise
            if provider is not None:
                if _provider is not provider or provider() is not original:
                    raise RuntimeError("Account ပြောင်းသွားပါပြီ။ Tool ကို ပြန်ဖွင့်ပါ။")
                values = dict(current.user)
                original.user = values
                original.server_offset = current.server_offset
                current = original
            _cached, _cached_key, _checked = current, key, time.monotonic()
        return original if original is not None else _cached


def require_vip(feature="ဒီ tool", fresh=True):
    if not desktop_context():
        return None  # source-only media fixtures, outside the installed Desktop
    session = current_session(force=fresh)
    if session is None or not session.is_vip:
        raise RuntimeError(f"{feature} သုံးရန် VIP သို့မဟုတ် VIP+ လိုအပ်ပါသည်။")
    return session


def require_vip_audio():
    return require_vip("ကိုယ်ပိုင်အသံသွင်း / audio ထည့်သုံးရန်", fresh=False)


def require_vip_plus():
    session = current_session()
    if session is None or session.is_vip_plus is not True:
        raise RuntimeError("Auto Posting သုံးရန် VIP+ လိုအပ်ပါသည်။")
