"""Shared, local own-narration audio for Studio99's four video tools.

No CUDA, torch, cloud service or account credential is used by this module.
Parts are bound to both their stable script ID and text. A changed script cannot
silently render an old recording, and changing a recording invalidates video caches.
"""
from __future__ import annotations

import array
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import uuid
import wave
from pathlib import Path

APP = Path(__file__).resolve().parent
ASSETS = APP / "assets" / "deepfilter"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
RATE = 48000


def run(args, *, timeout=600):
    env = dict(os.environ)
    # The frozen app already ships Microsoft's runtime beside its Python DLLs.
    # Put that directory on the child search path; no separate VC/CUDA install.
    dll_dirs = [APP.parent / "_internal", Path(sys.base_prefix)]
    env["PATH"] = os.pathsep.join(str(p) for p in dll_dirs if p.is_dir()) + os.pathsep + env.get("PATH", "")
    result = subprocess.run([str(a) for a in args], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            creationflags=NO_WINDOW, timeout=timeout, env=env)
    if result.returncode:
        error = result.stderr.decode("utf-8", "replace")[-2200:]
        raise RuntimeError(error or f"Audio process failed ({result.returncode})")
    return result


def ffmpeg_path():
    bundled = APP.parent / "recap_tool_src" / "ffmpeg" / "ffmpeg.exe"
    return str(bundled) if bundled.is_file() else (shutil.which("ffmpeg") or "ffmpeg")


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def text_key(text):
    return hashlib.sha256(str(text).strip().encode("utf-8")).hexdigest()


def read_pcm(path):
    with wave.open(str(path), "rb") as wav:
        if (wav.getnchannels(), wav.getsampwidth(), wav.getframerate()) != (1, 2, RATE):
            raise ValueError("အသံကို 48 kHz mono PCM16 WAV ပြောင်းရန်လိုပါတယ်")
        samples = array.array("h", wav.readframes(wav.getnframes()))
    return samples


def write_pcm(path, samples):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(RATE)
        wav.writeframes(array.array("h", samples).tobytes())
    return path


def duration(path):
    with wave.open(str(path), "rb") as wav:
        return wav.getnframes() / wav.getframerate()


def normalize(source, target, ffmpeg=None):
    run([ffmpeg or ffmpeg_path(), "-y", "-hide_banner", "-loglevel", "error", "-i", source,
         "-vn", "-ac", "1", "-ar", str(RATE), "-c:a", "pcm_s16le", target])
    samples = read_pcm(target)
    if len(samples) < RATE // 10 or max(map(abs, samples), default=0) < 16:
        raise ValueError("အသံမရှိပါ သို့မဟုတ် အရမ်းတိုနေပါတယ်")
    return Path(target)


def join_samples(left, right):
    """A 5ms equal-gain crossfade avoids a click at cuts and continued takes."""
    left, right = array.array("h", left), array.array("h", right)
    n = min(240, len(left), len(right))
    if n:
        for i in range(n):
            left[-n + i] = round(left[-n + i] * (1 - i / n) + right[i] * (i / n))
        left.extend(right[n:])
    else:
        left.extend(right)
    return left


def cut(source, target, start, end):
    data = read_pcm(source)
    a, b = sorted(max(0, min(len(data), int(t * RATE))) for t in (start, end))
    if b <= a or len(data) - (b - a) < RATE // 10:
        raise ValueError("အနည်းဆုံး အသံ 0.1 စက္ကန့် ချန်ထားပါ")
    return write_pcm(target, join_samples(data[:a], data[b:]))


def tidy(samples, compact=True):
    """Trim only quiet edges; optionally shorten long quiet pauses, without time stretching speech."""
    block = 480
    rms = [math.sqrt(sum(x * x for x in samples[i:i + block]) / max(1, len(samples[i:i + block])))
           for i in range(0, len(samples), block)]
    threshold = max(32, min(180, max(rms, default=0) * 0.025))
    active = [i for i, value in enumerate(rms) if value > threshold]
    if not active:
        raise ValueError("အသံသန့်စင်ပြီးနောက် စကားသံ မတွေ့ပါ — noise အားကိုလျှော့ကြည့်ပါ")
    first, last = max(0, active[0] - 6), min(len(rms), active[-1] + 12)
    data = array.array("h", samples[first * block:last * block])
    if compact:
        remove = []
        begin = None
        for i in range(first, last + 1):
            quiet = i < last and rms[i] <= threshold
            if quiet and begin is None:
                begin = i
            elif not quiet and begin is not None:
                if i - begin >= 90:
                    remove.append(((begin - first + 14) * block, (i - first - 14) * block))
                begin = None
        for a, b in reversed(remove):
            data = join_samples(data[:a], data[b:])
    n = min(192, len(data) // 2)
    for i in range(n):
        data[i] = round(data[i] * i / n)
        data[-1 - i] = round(data[-1 - i] * i / n)
    return data


def denoise(source, target, noise="medium", ffmpeg=None):
    if noise not in {"light", "medium", "strong"}:
        raise ValueError("Invalid noise strength")
    exe, model = ASSETS / "deep-filter.exe", ASSETS / "DeepFilterNet3_onnx.tar.gz"
    if not exe.is_file() or not model.is_file():
        raise RuntimeError("Noise removal ဖိုင်မစုံပါ — Studio99 ကို ပြန်တင်ပါ သို့မဟုတ် Noise Off ရွေးပါ")
    target = Path(target)
    work = target.parent / ("denoise_" + uuid.uuid4().hex)
    work.mkdir(parents=True)
    try:
        samples = read_pcm(source)
        # The CLI removes 30ms of model latency with -D. Flush its lookahead
        # with a quiet tail first, then keep exactly the original sample count.
        # Otherwise an unpadded recording loses its final consonant.
        padded = array.array("h", samples)
        padded.extend([0] * (RATE // 4))
        input_path = write_pcm(work / "input.wav", padded)
        run([exe, "-m", model, "-D", "--atten-lim-db", {"light": 12, "medium": 24, "strong": 40}[noise],
             "-o", work / "clean", input_path])
        outputs = list((work / "clean").glob("*.wav"))
        if len(outputs) != 1:
            raise RuntimeError("Noise removal output မရပါ")
        pcm = normalize(outputs[0], work / "clean.wav", ffmpeg)
        clean = read_pcm(pcm)
        if len(clean) < len(samples):
            raise RuntimeError("Noise removal output is truncated")
        return write_pcm(target, clean[:len(samples)])
    finally:
        shutil.rmtree(work)


def finish(source, target, *, noise="medium", compact=True, gain=0, pitch=0, tone="natural", ffmpeg=None):
    target, source = Path(target), Path(source)
    ffmpeg = ffmpeg or ffmpeg_path()
    work = target.parent / ("process_" + uuid.uuid4().hex)
    work.mkdir(parents=True)
    try:
        normalized = normalize(source, work / "input.wav", ffmpeg)
        if noise != "off":
            normalized = denoise(normalized, work / "denoised.wav", noise, ffmpeg)
        clean = write_pcm(work / "tidy.wav", tidy(read_pcm(normalized), compact))
        gain, pitch = float(gain), float(pitch)
        if not -12 <= gain <= 12 or not -4 <= pitch <= 4:
            raise ValueError("Gain / pitch range invalid")
        filters = []
        if tone == "warm":
            filters.append("bass=g=3:f=180")
        elif tone == "bright":
            filters.append("treble=g=3:f=3500")
        if abs(pitch) > 0.01:
            filters.append(f"rubberband=tempo=1:pitch={2 ** (pitch / 12):.8f}:formant=preserved")
        filters.extend(["loudnorm=I=-18:TP=-1.5:LRA=11", f"volume={gain}dB", "alimiter=limit=0.95:level=false"])
        normalize_args = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-i", clean,
                          "-af", ",".join(filters), "-ar", RATE, "-ac", 1, "-c:a", "pcm_s16le", target]
        run(normalize_args)
        if duration(target) < 0.1:
            raise ValueError("Processed audio too short")
        return target
    finally:
        # Only the unique, locally-created processing directory is removed.
        shutil.rmtree(work)


class VoiceStore:
    def __init__(self, work):
        self.root = Path(work) / "_own_voice"
        self.root.mkdir(parents=True, exist_ok=True)
        self.manifest = self.root / "manifest.json"

    def read(self):
        try:
            data = json.loads(self.manifest.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or not isinstance(data.get("parts", {}), dict):
                raise ValueError("Invalid own-voice manifest")
            return data
        except FileNotFoundError:
            return {"version": 1, "enabled": False, "parts": {}}

    def write(self, data):
        tmp = self.manifest.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, self.manifest)

    def enable(self, value):
        data = self.read()
        data["enabled"] = bool(value)
        self.write(data)

    def unsend(self, part_id):
        data = self.read()
        if str(part_id) in data.get("parts", {}):
            del data["parts"][str(part_id)]
            self.write(data)

    def temp(self, prefix="take"):
        return self.root / f"{prefix}_{uuid.uuid4().hex}.wav"

    def send(self, row, path, *, source=None, effects=None):
        key = digest(path)
        filename = key + ".wav"
        target = self.root / filename
        if not target.exists():
            shutil.copy2(path, target)
        seconds = duration(target)
        if seconds < 0.1:
            raise ValueError("Audio too short")
        data = self.read()
        item = {"text": text_key(row["text"]), "file": filename, "sha256": key, "seconds": seconds}
        if source is not None:
            raw_hash = digest(source)
            raw = self.root / (raw_hash + "_source.wav")
            if not raw.exists():
                shutil.copy2(source, raw)
            item.update(source_file=raw.name, source_sha256=raw_hash)
        if effects is not None:
            item["effects"] = dict(effects)
        data.setdefault("parts", {})[str(row["id"])] = item
        data["enabled"] = True
        self.write(data)
        return target

    def resolve(self, rows):
        data = self.read()
        if not data.get("enabled"):
            return None
        from membership_access import require_vip_audio
        require_vip_audio()
        paths, missing = [], []
        for row in rows:
            item = data.get("parts", {}).get(str(row["id"]), {})
            path = self.root / str(item.get("file", ""))
            valid = (item.get("text") == text_key(row["text"]) and path.parent == self.root
                     and path.suffix == ".wav" and path.is_file())
            if not valid or digest(path) != item.get("sha256"):
                missing.append(str(row["id"]))
            else:
                paths.append(path)
        if missing:
            raise RuntimeError("ကိုယ်ပိုင်အသံ မပို့ရသေးတဲ့ / စာပြောင်းထားတဲ့ အပိုင်း: " + ", ".join(missing[:16])
                               + "။ ကိုယ်ပိုင်အသံဖွင့်ပြီး Finish → Send to Recap လုပ်ပါ။")
        return paths


def microphone_devices(ffmpeg=None):
    result = subprocess.run([ffmpeg or ffmpeg_path(), "-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy"],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15, creationflags=NO_WINDOW)
    return list(dict.fromkeys(re.findall(r'"([^"\r\n]+)"\s+\(audio\)', result.stderr.decode("utf-8", "replace"))))


class ChildJob:
    """Close a Windows child process tree if its owning Studio99 process exits."""
    def __init__(self, proc):
        self.handle = None
        if os.name != "nt":
            return
        import ctypes as c
        from ctypes import wintypes as w
        class Limits(c.Structure):
            _fields_ = [("process_time", c.c_longlong), ("job_time", c.c_longlong), ("flags", w.DWORD),
                        ("minimum_working_set", c.c_size_t), ("maximum_working_set", c.c_size_t),
                        ("active_processes", w.DWORD), ("affinity", c.c_size_t),
                        ("priority", w.DWORD), ("scheduling", w.DWORD)]
        class Extended(c.Structure):
            _fields_ = [("basic", Limits), ("io", c.c_ulonglong * 6), ("process_memory", c.c_size_t),
                        ("job_memory", c.c_size_t), ("peak_process_memory", c.c_size_t), ("peak_job_memory", c.c_size_t)]
        kernel = c.WinDLL("kernel32", use_last_error=True)
        kernel.CreateJobObjectW.argtypes, kernel.CreateJobObjectW.restype = [w.LPVOID, w.LPCWSTR], w.HANDLE
        kernel.SetInformationJobObject.argtypes = [w.HANDLE, c.c_int, w.LPVOID, w.DWORD]
        kernel.AssignProcessToJobObject.argtypes = [w.HANDLE, w.HANDLE]
        kernel.CloseHandle.argtypes = [w.HANDLE]
        self.kernel = kernel
        self.handle = kernel.CreateJobObjectW(None, None)
        info = Extended()
        info.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not self.handle or not kernel.SetInformationJobObject(self.handle, 9, c.byref(info), c.sizeof(info)):
            self.close()
            raise OSError(c.get_last_error(), "Cannot create audio process job")
        if not kernel.AssignProcessToJobObject(self.handle, w.HANDLE(int(proc._handle))):
            error = c.get_last_error()
            self.close()
            raise OSError(error, "Cannot attach audio process job")

    def close(self):
        if self.handle is not None:
            self.kernel.CloseHandle(self.handle)
            self.handle = None


class Recorder:
    """A user-controlled FFmpeg DirectShow capture; no recording at application startup."""
    def __init__(self, device, target, ffmpeg=None):
        self.target = Path(target)
        self.log = self.target.with_suffix(".log").open("wb")
        self.proc = subprocess.Popen([ffmpeg or ffmpeg_path(), "-y", "-hide_banner", "-loglevel", "error",
                                      "-f", "dshow", "-i", "audio=" + device, "-vn", "-ac", "1", "-ar", str(RATE),
                                      "-c:a", "pcm_s16le", str(self.target)], stdin=subprocess.PIPE,
                                     stdout=subprocess.DEVNULL, stderr=self.log, creationflags=NO_WINDOW)
        try:
            self.job = ChildJob(self.proc)
        except Exception:
            if self.proc.poll() is None:
                self.proc.terminate()
                self.proc.wait(timeout=5)
            self.log.close()
            raise

    def stop(self):
        try:
            if self.proc.poll() is None:
                self.proc.communicate(b"q\n", timeout=15)
            if self.proc.returncode or not self.target.is_file():
                raise RuntimeError("မိုက်အသံသွင်းလို့မရပါ။ Windows Microphone permission နဲ့ မိုက်ချိတ်ဆက်မှုကိုစစ်ပါ။")
            return self.target
        finally:
            if self.proc.poll() is None:
                self.proc.terminate()
                self.proc.wait(timeout=5)
            self.log.close()
            self.job.close()
