"""Local (offline) mode for Studio99 Desktop — a developer switch.

While it is on the app never talks to the account server: no login, no device
check, no build kill-switch, no VIP gate and no 3-per-day free allowance.
Everything runs as a local "VIP+" account.

  * on  → config.json beside Studio99.exe:  {"local_mode": true}
          or the environment variable   STUDIO99_LOCAL=1
  * off → remove the key / variable (a release build keeps the server checks)

The server code path is untouched: with the flag off, login, VIP, the device
limit and every check behave exactly as before.
"""
from __future__ import annotations

import os

LOCAL_TOKEN = "local"
LOCAL_USER = {
    "id": "local",
    "email": "local@studio99",
    "name": "Local",
    "verified": True,
    "status": "active",
    "is_vip": True,
    "membership_tier": "vip_plus",
    "vip_until": "",          # empty = no expiry (pb_client.Session.is_vip)
}

_TRUE = {"1", "true", "yes", "on"}


def enabled() -> bool:
    """True when this process runs in local mode (env wins over config.json)."""
    value = os.environ.get("STUDIO99_LOCAL", "").strip().lower()
    if os.environ.get("STUDIO99_WEB_MODE") == "colab":
        # Never inherit the installed desktop's developer switch into a public web server.
        return value in _TRUE
    if value:
        return value in _TRUE
    try:
        from app_config import load_config
        return bool(load_config().get("local_mode"))
    except Exception:  # noqa: BLE001 - a broken config must never stop the app
        return False


def session():
    """A VIP+ session with no server behind it."""
    from pb_client import Session
    return Session(token=LOCAL_TOKEN, user=dict(LOCAL_USER))
