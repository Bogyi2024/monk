"""Movie Review (VIP) for the web UI: the user's movie_review tool (copy in tool_apps/movie_review) — research,
Burmese review post, thumbnail and a review Reel. TMDB goes through the Studio99 server (STUDIO99_TMDB_PROXY + the
login token; the server's hook adds the TMDB token, server/pb_hooks/studio99_tmdb.pb.js), the web search uses the
free DuckDuckGo fallback, FAL (optional AI pictures) and Gemini keys come from the Profile."""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

import history
import keys_file
import token_store
from web_story import image_data_url
from web_tool_job import ToolJob

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "tool_apps" / "movie_review"
OUTPUT = TOOL / "output"
PROFILES = [("movie_general", "ဇာတ်ကား အားလုံး"), ("movie_horror_thriller", "Horror / Thriller")]
_job: ToolJob | None = None
_job_lock = threading.RLock()


def results(limit: int = 30) -> list[dict]:
    out = []
    folders = sorted((p for p in OUTPUT.glob("*") if (p / "manifest.json").is_file()),
                     key=lambda p: (p / "manifest.json").stat().st_mtime, reverse=True) if OUTPUT.is_dir() else []
    for folder in folders[:limit]:
        try:
            m = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
        except ValueError:
            continue
        video = m.get("video") or ""
        out.append({"folder": str(folder), "title": f"{m.get('title', folder.name)} ({m.get('year') or ''})",
                    "thumbnail": m.get("thumbnail") if m.get("thumbnail") and Path(m["thumbnail"]).is_file() else "",
                    "video": video if video and Path(video).is_file() else "",
                    "post": m.get("facebook_post") or "", "at": (folder / "manifest.json").stat().st_mtime})
    return out


def call(api, action: str, payload: dict):
    with _job_lock:
        return _call(api, action, payload)


def _call(api, action: str, payload: dict):
    global _job
    if action == "options":
        return {"profiles": PROFILES, "fal": bool((token_store.load_keys().get("fal") or "").strip()),
                "saved": api._cfg.get("movie_review") or {}, "results": results(),
                "running": bool(_job and _job.running)}
    if action == "results":
        return results()
    if action == "text":
        return Path(payload["path"]).read_text(encoding="utf-8")
    if action == "image":
        return image_data_url(Path(payload["path"]), 640) if Path(payload.get("path", "")).is_file() else ""
    if action == "stop":
        if _job:
            _job.stop()
        return True
    if action == "start":
        api._need_session()
        if _job is not None and _job.running:
            return False
        gemini = keys_file.gemini_keys()
        if not gemini:
            raise RuntimeError("Profile မှာ Gemini API key အရင်ထည့်ပါ")
        own_tmdb = (token_store.load_keys().get("tmdb") or os.environ.get("STUDIO99_TMDB_TOKEN") or "").strip()
        if getattr(api, "_local", False) and not own_tmdb:
            raise RuntimeError("Movie Review အတွက် TMDB token လိုပါတယ် — Profile → Keys မှာ ထည့်ပါ။ "
                               "(Offline mode မှာ Studio99 server ကနေ TMDB အချက်အလက် မယူနိုင်လို့ပါ)")
        session = api._need_session()
        api._cfg["movie_review"] = {k: payload.get(k) for k in ("profile", "fal", "video", "spoilers", "own_voice")}
        from app_config import save_config
        save_config(api._cfg)
        args = ["main.py"]
        if payload.get("title"):
            args.append(str(payload["title"]))
            if payload.get("year"):
                args += ["--year", str(int(payload["year"]))]
        else:
            args.append("--auto")
        args += ["--profile", payload.get("profile") or "movie_general", "--platform", "facebook"]
        if payload.get("video", True):
            args += ["--video", "--auto-trailer"]
        if payload.get("spoilers"):
            args.append("--spoilers")
        if payload.get("force"):
            args.append("--force")
        env = {f"GEMINI_IMAGE_PROJECT_{i}_KEY": k for i, k in enumerate(gemini, 1)}
        env["STUDIO99_OWN_VOICE"] = "1" if payload.get("own_voice") else "0"
        fal = (token_store.load_keys().get("fal") or "").strip()
        if payload.get("fal") and fal:
            args.append("--fal")
            env["FAL_KEY"] = fal
        env.update(STUDIO99_TMDB_PROXY=api._pb.base + "/api/studio99/tmdb", STUDIO99_TOKEN=session.token, STUDIO99_SERVER=api._pb.base,
                   OUTPUT_DIR=str(OUTPUT), MOVIE_REVIEW_STATE_DIR=str(TOOL / "state"),
                   MOVIE_REVIEW_TTS_VOICE="Charon",                 # the user's choice (2026-10-17)
                   TITLE_FONT_FAMILY="Myanmar Text" if os.name == "nt" else "Noto Sans Myanmar",
                   TITLE_FONT_PATH=(r"C:\Windows\Fonts\mmrtextb.ttf" if os.name == "nt" and Path(r"C:\Windows\Fonts\mmrtextb.ttf").is_file()
                                    else str(next((fp for fp in (
                                        ROOT / "app" / "fonts" / "Studio99Myanmar-Regular.ttf",
                                        Path("/usr/share/fonts/truetype/noto/NotoSansMyanmar-Bold.ttf"),
                                        Path("/usr/share/fonts/truetype/noto/NotoSansMyanmar-Regular.ttf"),
                                    ) if fp.is_file()), ROOT / "app" / "fonts" / "Studio99Myanmar-Regular.ttf"))),
                   BODY_FONT_FAMILY="Myanmar Text")
        if getattr(api, "_local", False):
            # Offline: no server proxy, so TMDB goes straight to api.themoviedb.org with the user's own token.
            env["STUDIO99_LOCAL"] = "1"
            env.pop("STUDIO99_TMDB_PROXY", None)
            env["TMDB_BEARER_TOKEN"] = own_tmdb
        started = time.time()
        _job = ToolJob("review", api._emit)

        def done(code: int, lines: list[str]) -> None:
            if code != 0:
                text = "\n".join(lines[-40:])
                if code == -1:
                    message = "ရပ်လိုက်ပါပြီ"
                elif "studio99/tmdb" in text and "404" in text:
                    message = "Studio99 server မှာ TMDB ချိတ်ဆက်မှု (pb_hooks/studio99_tmdb.pb.js) မတင်ရသေးပါ — Admin ကို ပြောပါ"
                elif "studio99/tmdb" in text and ("401" in text or "403" in text):
                    message = "Movie Review က VIP member တွေအတွက်ပါ — Login / VIP ပြန်စစ်ပါ"
                elif "Duplicate blocked" in text:
                    message = "ဒီဇာတ်ကားကို လုပ်ပြီးသားပါ — 'ပြန်လုပ်မယ်' ကို အမှန်ခြစ်ပြီး ထပ်လုပ်လို့ရပါတယ်"
                else:
                    tail = next((x for x in reversed(lines) if x.strip() and not x.startswith("For more")), "")
                    message = f"မပြီးပါ: {tail[:300]}"
                api._emit("review_error", message=message)
                return
            fresh = [r for r in results(5) if r["at"] >= started - 5]
            if fresh:
                history.add("movie_review", fresh[0]["video"] or fresh[0]["folder"], fresh[0]["title"])
            api._emit("review_done", result=fresh[0] if fresh else None, results=results())
        return _job.start(args, TOOL, env, done)
    raise RuntimeError(f"Unknown action {action}")
