"""Auto Posting tool (VIP) = the TT master's own dashboard and scheduler, run from engine/ (engine_runner.py).

Opening the card starts the engine and shows its dashboard INSIDE this screen (engine_window.py --parent: the
WebView2 window becomes a child of the "Dashboard" tab's frame; user 2026-10-18). FB Pages (many pages per
Facebook login), TikTok, Share Accounts, Categories/routes, Today and Scheduler are the master's own screens.
The "Posting list" tab shows the videos the tools put on the list. Posting runs while Studio99 is open and Today
is armed; leaving the card keeps it running."""
from __future__ import annotations

import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk

import engine_runner
import posting_queue
import ui_thread

BG, SURFACE, SURFACE_2, FIELD, BORDER = "#0b0d12", "#141821", "#1b2030", "#0a0c10", "#2a3142"
FG, MUTED, ACCENT, GOLD, OK, BAD = "#eef1f7", "#98a2b3", "#5b8cff", "#f5c451", "#55d187", "#ff8a8a"
HELP = ("1) FB Pages / TikTok / Share Accounts မှာ account နဲ့ page တွေ ထည့် (login ကိုယ်တိုင်ဝင်)   "
        "2) Categories → Recap videos / Splitter parts / Story Motion videos / Other videos → Route: page + TikTok + "
        "group share + တစ်ရက်ဘယ်နှပုဒ် + အချိန်   3) Today → START")


class PostingView(tk.Frame):
    def __init__(self, master: tk.Misc) -> None:
        super().__init__(master, bg=BG)
        bar = tk.Frame(self, bg=SURFACE, padx=14, pady=8)
        bar.pack(fill="x")
        self.dot = tk.Label(bar, text="●", bg=SURFACE, fg=MUTED, font=("Segoe UI", 12))
        self.dot.pack(side="left")
        self.state = tk.Label(bar, text="စစ်နေပါတယ်…", bg=SURFACE, fg=FG, font=("Myanmar Text", 10))
        self.state.pack(side="left", padx=(6, 16))
        self.start_btn = ttk.Button(bar, text="▶  စမယ်", style="Accent.TButton", command=self._start)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(bar, text="■  Auto Posting ရပ်မယ်", style="Danger.TButton", command=self._stop)
        self.stop_btn.pack(side="left", padx=8)
        ttk.Button(bar, text="↻", style="Compact.TButton", width=3, command=self._reload).pack(side="left")
        tk.Label(bar, text=HELP, bg=SURFACE, fg=MUTED, font=("Myanmar Text", 8), wraplength=760,
                 justify="left").pack(side="left", padx=16)

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True)
        self.host = tk.Frame(self.tabs, bg=BG)                  # the dashboard is put inside this frame
        self.list_tab = tk.Frame(self.tabs, bg=BG)
        self.tabs.add(self.host, text="  Dashboard  ")
        self.tabs.add(self.list_tab, text="  Posting list  ")
        self.placeholder = tk.Label(self.host, text="", bg=BG, fg=MUTED, font=("Myanmar Text", 11), justify="center")
        self.placeholder.place(relx=0.5, rely=0.4, anchor="center")
        self.detail = tk.Label(self.host, text="", bg=BG, fg=MUTED, font=("Consolas", 9), justify="left")
        self.detail.place(relx=0.5, rely=0.55, anchor="n")

        self.queue_view = ttk.Treeview(self.list_tab, columns=("kind", "targets", "when", "status"), height=8)
        self.queue_view.heading("#0", text="Video / Caption")
        for col, text, width in (("kind", "Tool", 130), ("targets", "Post to", 260), ("when", "When", 130),
                                 ("status", "Status", 220)):
            self.queue_view.heading(col, text=text)
            self.queue_view.column(col, width=width, anchor="center", stretch=False)
        self.queue_view.pack(fill="both", expand=True, padx=12, pady=(10, 6))
        bottom = tk.Frame(self.list_tab, bg=BG)
        bottom.pack(fill="x", padx=12, pady=(0, 10))
        ttk.Button(bottom, text="Remove", style="Compact.TButton", command=self._remove).pack(side="left")
        self._refresh_queue()
        self._alive = True
        self._starting = False
        self._poll()
        self.after(300, self._start)                            # opening the card opens the dashboard

    # ------------------------------------------------------------------ engine
    def _poll(self) -> None:
        if not self._alive:
            return

        def check():
            from membership_access import require_vip_plus
            try:
                require_vip_plus()
            except RuntimeError:
                engine_runner.stop()
                ui_thread.post(lambda: self._show_state(False))
                return
            up = engine_runner.running()
            ui_thread.post(lambda: self._show_state(up))
        threading.Thread(target=check, daemon=True).start()
        self.after(4000, self._poll)

    def _show_state(self, up: bool) -> None:
        if not self._alive or not self.winfo_exists():
            return
        self._refresh_queue()                  # the engine marks items as it posts them
        self.dot.configure(fg=OK if up else MUTED)
        if not self._starting:
            self.state.configure(text="Run နေပါတယ်" if up else "ပိတ်ထားပါတယ်", fg=FG)
            self.placeholder.configure(text="" if up else "Auto Posting ပိတ်ထားပါတယ် —  ▶ စမယ်  နှိပ်ပါ")
        self.stop_btn.state(["!disabled"] if up else ["disabled"])
        self.start_btn.state(["disabled"] if up or self._starting else ["!disabled"])

    def _start(self) -> None:
        if self._starting or not self._alive:
            return
        from membership_access import require_vip_plus
        try:
            require_vip_plus()
        except RuntimeError as exc:
            self.state.configure(text=str(exc), fg=BAD)
            return
        self._starting = True
        self.start_btn.state(["disabled"])
        self.state.configure(text="ဖွင့်နေပါတယ်…", fg=FG)
        self.placeholder.configure(text="Dashboard ဖွင့်နေပါတယ် (ပထမဆုံးအကြိမ် နည်းနည်းကြာပါတယ်)…")
        self.detail.configure(text="")
        self.host.update_idletasks()
        parent = self.host.winfo_id()

        def work():
            engine_runner.start()
            ok = engine_runner.wait_ready()
            if ok:
                engine_runner.arm_today()              # ▶ = post today too, not only open the dashboard
                engine_runner.open_window(parent)
            ui_thread.post(lambda: self._started(ok))
        threading.Thread(target=work, daemon=True).start()

    def _started(self, ok: bool) -> None:
        self._starting = False
        if not self._alive or not self.winfo_exists():
            return
        self._show_state(ok)
        if not ok:
            self.state.configure(text="Engine မဖွင့်နိုင်ပါ", fg=BAD)
            self.placeholder.configure(text="Auto Posting engine မဖွင့်နိုင်ပါ")
            self.detail.configure(text=engine_runner.last_log_lines())

    def _reload(self) -> None:
        """Open the dashboard here again (e.g. after it was closed)."""
        engine_runner.close_window()
        self._start()

    def _stop(self) -> None:
        def work():
            engine_runner.stop()
            ui_thread.post(lambda: self._show_state(False))
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------------ queue
    def _refresh_queue(self) -> None:
        routes = {(d["category"], d["id"]): d["label"] for d in engine_runner.destinations(enabled_only=False)}
        view = self.queue_view
        selected = view.selection()
        view.delete(*view.get_children())
        for item in posting_queue.load():
            cat = item.get("category") or "post_other"
            targets = ", ".join(routes.get((cat, t), t) for t in item.get("targets") or []) or "Page အားလုံး"
            done, failed = item.get("done") or {}, item.get("failed") or {}
            status = {"queued": "စောင့်နေ", "posting": "တင်နေဆဲ", "posted": "✓ တင်ပြီး"}.get(item.get("status"), "")
            if done:
                status += f" · {len(done)} page"
            if failed:
                status += f" · ⚠️ {', '.join(sorted(set(failed.values())))}"
            if item.get("deleted"):
                status += " · ဖိုင်ဖျက်ပြီး"
            view.insert("", "end", iid=item["id"], text=f"{item.get('caption') or ''}   ·   {Path(item['video']).name}",
                        values=(posting_queue.CATEGORIES.get(cat, ("",))[0], targets,
                                item.get("post_at") or "next slot", status))
        keep = [i for i in selected if view.exists(i)]
        if keep:
            view.selection_set(keep)

    def _remove(self) -> None:
        sel = self.queue_view.selection()
        if sel:
            posting_queue.remove(sel)
            self._refresh_queue()

    def shutdown(self) -> None:
        """Leaving this screen keeps Auto Posting running (it stops when Studio99 closes); the dashboard inside the
        card closes by itself when its frame goes."""
        self._alive = False
