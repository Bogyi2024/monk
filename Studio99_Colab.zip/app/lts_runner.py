"""Long to Short job (no UI): runs the copied CLI (tool_apps/long_to_short/run_long_to_short_test.py) in its own
process — Whisper/CUDA never in the app — and returns the finished clips. Used by the web screen (webapp.py) and
the old Tk screen (lts_view.py)."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from collections import deque
from pathlib import Path
from typing import Callable

import keys_file
from lts_options import normalize_export_options

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "tool_apps" / "long_to_short"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

PROFILES = [("generic", "အထွေထွေ"), ("motivation", "Motivation"), ("psychology", "Psychology"), ("horror", "Horror"),
            ("crime", "Crime / Mystery"), ("knowledge", "Knowledge"), ("comedy", "Comedy"), ("business", "Business"),
            ("celebrity", "Celebrity"), ("tech_ai", "Tech / AI"), ("sports", "Sports")]
MODES = [("transformative_envo_mm", "English အသံအသစ် + မြန်မာ စာတန်း", "FINAL_ENVO_MM"),
         ("original_audio_mm", "မူရင်းအသံ + မြန်မာ စာတန်း", "ORIGINAL_AUDIO_MM"),
         ("transformative_envo_en", "English အသံအသစ် + English စာတန်း", "FINAL_ENVO_EN"),
         ("original_audio_en", "မူရင်းအသံ + English စာတန်း", "ORIGINAL_AUDIO_EN")]


def cuda_available() -> bool:
    try:
        import ctranslate2
        return ctranslate2.get_cuda_device_count() > 0
    except Exception:  # noqa: BLE001
        return False


def set_whisper_device(cuda: bool) -> None:
    """The tool reads Whisper's device from its own config: GPU when there is one, else CPU (int8)."""
    path = TOOL / "config" / "config.json"
    cfg = json.loads(path.read_text(encoding="utf-8"))
    device, compute = ("cuda", "float16") if cuda else ("cpu", "int8")
    changed = cfg.get("whisper_device") != device
    cfg["whisper_device"], cfg["whisper_compute_type"] = device, compute
    align = cfg.get("voiceover_subtitle_alignment") or {}
    if align:
        changed |= align.get("device") != device
        align["device"], align["compute_type"] = device, compute
    if changed:
        path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def finished_clips(run_dir: Path, modes: list[str]) -> list[Path]:
    tags = [tag for key, _label, tag in MODES if key in modes]
    return sorted(p for p in run_dir.glob("candidate_*_*.mp4")
                  if p.is_file() and p.stat().st_size > 0 and any(p.stem.endswith(tag) for tag in tags))


class LtsJob:
    def __init__(self) -> None:
        self.proc: subprocess.Popen | None = None
        self.stopped = False

    def run(self, source: str, *, modes: list[str], profile: str = "generic", count: int = 3, out_folder: str = "",
            delete_work: bool = True, subtitles_enabled: bool = True, output_ratio: str = "9:16",
            clip_minutes=None, log: Callable[[str], None] = print) -> list[Path]:
        from daily_limits import free_job
        with free_job("long_to_short"):
            return self._run_export(source, modes=modes, profile=profile, count=count, out_folder=out_folder,
                                    delete_work=delete_work, subtitles_enabled=subtitles_enabled,
                                    output_ratio=output_ratio, clip_minutes=clip_minutes, log=log)

    def _run_export(self, source: str, *, modes: list[str], profile: str = "generic", count: int = 3, out_folder: str = "",
                    delete_work: bool = True, subtitles_enabled: bool = True, output_ratio: str = "9:16",
                    clip_minutes=None, log: Callable[[str], None] = print) -> list[Path]:
        """The finished clips (copied to out_folder when given). Raises RuntimeError when the tool fails."""
        self.stopped = False
        export = normalize_export_options(subtitles_enabled, output_ratio, clip_minutes)
        if not modes or any(mode not in {key for key, _label, _tag in MODES} for mode in modes):
            raise ValueError("ထုတ်မယ့်ပုံစံ တစ်ခုခု ရွေးပါ")
        if re.match(r"https?://", source):
            log("⬇️ Video ကို download လုပ်နေပါတယ်…")
            import channel_source
            source = str(channel_source.download(source, log=log))
        if not Path(source).is_file():
            raise RuntimeError("Video ဖိုင် မတွေ့ပါ")
        set_whisper_device(cuda_available())
        keys = keys_file.write()
        if not keys:
            raise RuntimeError("Profile မှာ Gemini API key အရင်ထည့်ပါ")
        env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", LTS_OUTPUT_MODES=",".join(modes),
                   LTS_CONTENT_PROFILE=profile, LTS_CANDIDATE_COUNT=str(max(1, min(8, count))),
                   RECAP_PERSONAL_DIR=str(keys.parent), LTS_EXPORT_OPTIONS=json.dumps(export))
        import ffmpeg_speed                      # the page's encode speed reaches the tool's FFmpeg calls
        env = ffmpeg_speed.child_env(env, "long_to_short")
        python = Path(sys.executable).with_name("python.exe")
        self.proc = subprocess.Popen([str(python if python.exists() else sys.executable), "-u", "-X", "utf8",
                                      "run_long_to_short_test.py", source], cwd=str(TOOL), env=env,
                                     stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     text=True, encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
        run_dir = None
        last_lines = deque(maxlen=8)
        for line in self.proc.stdout:
            log(line.rstrip("\n"))
            if line.strip():
                last_lines.append(line.strip())
            found = re.search(r"DONE → (.+)$", line.strip())
            if found:
                run_dir = Path(found.group(1).strip())
        code = self.proc.wait()
        self.proc = None
        if self.stopped:
            raise RuntimeError("ရပ်လိုက်ပါပြီ")
        if code != 0 or run_dir is None:
            detail = last_lines[-1] if last_lines else "Worker က အကြောင်းရင်း မပို့ခဲ့ပါ။"
            detail = re.sub(r"AIza[\w-]+", "[redacted]", detail)
            raise RuntimeError(f"Long to Short မပြီးပါ (exit {code}) — {detail[-800:]}")
        clips = finished_clips(run_dir, modes)
        if not clips:
            raise RuntimeError(f"ထုတ်ပြီးသား video မတွေ့ပါ။ Work files ကို မဖျက်ထားပါ: {run_dir}")
        if out_folder:
            target = Path(out_folder)
            target.mkdir(parents=True, exist_ok=True)
            copied = []
            for clip in clips:
                dest = target / f"{Path(source).stem[:60]}_{clip.stem.replace('candidate_', 'clip_')}.mp4"
                shutil.copy2(clip, dest)
                copied.append(dest)
            log(f"📤 Clip {len(copied)} ခု → {target}")
            if delete_work:
                shutil.rmtree(run_dir, ignore_errors=True)
                log("🧹 Work files ဖျက်ပြီးပါပြီ")
            clips = copied
        import history
        for clip in clips:
            history.add("long_to_short", clip, clip.stem)
        return clips

    def stop(self) -> None:
        proc = self.proc
        if proc and proc.poll() is None:            # Whisper / FFmpeg children too
            self.stopped = True
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True,
                               creationflags=NO_WINDOW)
            else:
                from web_tool_job import stop_process
                stop_process(proc)
