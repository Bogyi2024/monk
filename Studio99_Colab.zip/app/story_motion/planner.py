"""Story Motion step 1: the story, written by Gemini at the length the user chose.

Length: the user picks the minutes; scenes = minutes*60 / ~15 s (they can change it) and each scene's narration gets
a letter (Burmese) or word (English) budget from the voice's measured speed (Edge TTS 2026-10-17: Thiha 17.1,
Nilar 15.2 Burmese letters/s, Guy 3.1 English words/s at +0%). Up to CHUNK scenes are written in one request;
longer stories first get an outline, then the scenes in chunks with the story so far. Scenes far off their budget
are asked again once.

Styles: "narrator" (a storyteller tells it) or "first_person" (the main character tells it: ကျွန်တော်/ကျွန်မ by
the narrator's gender). Every image prompt repeats the characters' looks and the art style so the pictures match."""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from typing import Callable

from story_motion.gemini_client import ask_json

CHUNK = 24
SCENE_SECONDS = 15
RATE = {"my-MM-ThihaNeural": 17.1, "my-MM-NilarNeural": 15.2}     # Burmese letters per second at +0%
EN_WORDS_PER_SECOND = 2.9
GEMINI_RATE = {"my": 13.0, "en": 2.4}     # Gemini TTS (2026-10-17: Charon 13.7 / Gacrux 12.3 letters/s, Charon 2.4 w/s)
LOW, HIGH = 0.75, 1.15                                              # a scene outside this share of its budget is redone
ASK_SHARE = 0.88     # Gemini writes ~15-20% over the number it is given (2026-10-17: 238 asked → 263-313 written)

GENRES = {
    "horror": "Horror / ghost story", "thriller": "Thriller / mystery", "romance": "Romance", "drama": "Life drama",
    "fantasy": "Fantasy / adventure", "comedy": "Comedy", "kids": "Children's fairy tale", "true_story": "Real-life story",
    "motivation": "Motivation / life lesson", "history": "History / legend",
}
IMAGE_STYLES = {
    "cartoon_2d": "2D cartoon illustration, clean bold outlines, flat cel shading, rich colours",
    "anime": "anime style illustration, detailed backgrounds, cinematic lighting",
    "cinematic": "photorealistic cinematic film still, 35mm, dramatic lighting, shallow depth of field",
    "3d": "3D animated film style, soft global illumination, expressive characters",
    "watercolor": "watercolor storybook illustration, soft textured paper, gentle colours",
    "dark_horror": "dark 2D horror illustration, muted palette, deep shadows, eerie atmosphere, no gore",
}


@dataclass
class StorySettings:
    idea: str = ""
    genre: str = "horror"
    style: str = "narrator"                 # narrator | first_person
    narrator_gender: str = "male"           # first_person: who tells it
    language: str = "my"                    # my | en
    minutes: float = 3.0
    scene_count: int = 12
    units_per_scene: int = 250              # Burmese letters or English words
    image_style: str = "cartoon_2d"
    ratio: str = "9:16"
    voice: str = "gemini:Charon"
    rate_percent: int = 0
    voice_direction: str = ""               # Gemini TTS only: how the narrator should sound
    extra: dict = field(default_factory=dict)


def speech_rate(language: str, voice: str, rate_percent: int = 0) -> float:
    if voice.startswith("gemini:"):
        base = GEMINI_RATE.get(language, GEMINI_RATE["en"])
    else:
        base = RATE.get(voice, 16.0) if language == "my" else EN_WORDS_PER_SECOND
    return base * (1 + rate_percent / 100)


def plan_numbers(minutes: float, language: str, voice: str, rate_percent: int = 0,
                 scene_count: int | None = None) -> tuple[int, int, int]:
    """(scenes, letters-or-words per scene, total) for a story of `minutes`."""
    seconds = max(30.0, float(minutes) * 60)
    scenes = scene_count or max(3, round(seconds / SCENE_SECONDS))
    total = round(seconds * speech_rate(language, voice, rate_percent) * 0.93)   # pauses between scenes
    return scenes, max(10, round(total / scenes)), total


def count_units(text: str, language: str) -> int:
    if language == "my":
        return sum(1 for ch in text if not ch.isspace() and ch not in "။၊.,!?\"'“”‘’()-")
    return len(re.findall(r"[A-Za-z0-9']+", text))


def _unit_name(language: str) -> str:
    return "Burmese letters (Unicode characters, spaces not counted)" if language == "my" else "English words"


def _voice_rules(s: StorySettings) -> str:
    if s.language == "my":
        rules = [
            "Write the narration in natural SPOKEN Burmese (Unicode), like a good storyteller talking — never literary "
            "Burmese (no သည် / ၏ / ၌ / ၍ endings).",
            "Vary sentence endings (တယ်, ခဲ့တယ်, လိုက်တယ်, နေတယ်, ပြီ, …); do not end every sentence with ပါတယ်; never end "
            "narration sentences with ခင်ဗျာ or ရှင်.",
            "Every name is written in Burmese script (no English letters in the narration).",
            "In dialogue, a man says ကျွန်တော် / မင်း and a woman says ကျွန်မ / နင် / ရှင် as fits the speaker.",
        ]
        if s.style == "first_person":
            me = "ကျွန်တော်" if s.narrator_gender == "male" else "ကျွန်မ"
            rules.append(f"FIRST PERSON: the main character tells their own story as {me} ({s.narrator_gender}); tell "
                         "what I saw, heard and felt, in the past tense, like recounting a real experience.")
        else:
            rules.append("STORYTELLER: a narrator tells the story about the characters (third person), drawing the "
                         "listener in; the narrator is not a character.")
    else:
        rules = ["Write natural spoken English narration, vivid and easy to follow."]
        rules.append("FIRST PERSON: the main character tells their own story as 'I' (past tense)."
                     if s.style == "first_person" else
                     "STORYTELLER: a third-person narrator tells the story; the narrator is not a character.")
    return "\n".join(f"- {r}" for r in rules)


def _image_rules(s: StorySettings) -> str:
    orientation = {"9:16": "vertical 9:16", "16:9": "horizontal 16:9", "1:1": "square 1:1"}.get(s.ratio, s.ratio)
    return (f"- image_prompt: ENGLISH, one picture for this scene, {orientation} composition. Start with the art style "
            f"\"{IMAGE_STYLES.get(s.image_style, s.image_style)}\", then the place, time of day, the action and the "
            "mood. Every character who appears is described with their exact 'look' from the characters list (same "
            "face, hair, clothes every time) — never write a character's name in the image prompt, write their look. No "
            "text, letters, captions or watermarks in the picture. No gore.")


def _length_rule(s: StorySettings, scenes: int) -> str:
    return (f"- Exactly {scenes} scenes. Each scene's narration is about {_asked(s)} {_unit_name(s.language)} "
            f"(between {int(_asked(s) * 0.85)} and {int(_asked(s) * 1.1)}; never longer). Each scene is one moment "
            "the picture can show; together they tell a complete story with a beginning, rising tension, a climax and "
            "a satisfying ending.")


def _story_prompt(s: StorySettings) -> str:
    idea = s.idea.strip() or "Invent an original, gripping story idea yourself."
    return f"""You write narrated picture stories for Facebook / TikTok videos.

STORY
- Genre: {GENRES.get(s.genre, s.genre)}
- Idea: {idea}
- Length: about {s.minutes:g} minutes of narration.

NARRATION
{_voice_rules(s)}
{_length_rule(s, s.scene_count)}

PICTURES
{_image_rules(s)}

Return JSON only:
{{"title": "...", "characters": [{{"name": "...", "look": "English visual description: age, face, hair, clothes"}}],
 "scenes": [{{"narration": "...", "image_prompt": "..."}}]}}"""


def _outline_prompt(s: StorySettings) -> str:
    idea = s.idea.strip() or "Invent an original, gripping story idea yourself."
    return f"""Plan a narrated picture story for Facebook / TikTok.
- Genre: {GENRES.get(s.genre, s.genre)}
- Idea: {idea}
- {s.scene_count} scenes, about {s.minutes:g} minutes; a complete story with a beginning, rising tension, a climax and
  a satisfying ending.
Return JSON only: {{"title": "... (in {'Burmese' if s.language == 'my' else 'English'})",
 "characters": [{{"name": "...", "look": "English visual description: age, face, hair, clothes"}}],
 "beats": ["one English sentence per scene: what happens", ... exactly {s.scene_count}]}}"""


def _chunk_prompt(s: StorySettings, outline: dict, start: int, end: int, previous: list[str]) -> str:
    beats = outline["beats"]
    listing = "\n".join(f"{i + 1}. {beats[i]}" for i in range(start, end))
    before = "\n".join(previous[-3:]) or "(this is the start of the story)"
    return f"""Write scenes {start + 1}-{end} of the narrated picture story "{outline.get('title', '')}".
Characters (use these looks in image prompts): {outline.get('characters')}
Whole story plan: {beats}

The narration just before these scenes:
{before}

Scenes to write now:
{listing}

NARRATION
{_voice_rules(s)}
- Exactly {end - start} scenes, one per beat above, continuing smoothly from the narration before. Each scene's
  narration is about {_asked(s)} {_unit_name(s.language)} (between {int(_asked(s) * 0.85)} and
  {int(_asked(s) * 1.1)}; never longer).
PICTURES
{_image_rules(s)}
Return JSON only: {{"scenes": [{{"narration": "...", "image_prompt": "..."}}]}}"""


def _repair_prompt(s: StorySettings, story: dict, bad: list[int]) -> str:
    rows = []
    for i in bad:
        units = count_units(story["scenes"][i]["narration"], s.language)
        rows.append({"index": i + 1, "now": units, "narration": story["scenes"][i]["narration"]})
    return f"""These scenes of the story "{story.get('title', '')}" have the wrong length. Rewrite each one to {s.units_per_scene} {_unit_name(s.language)} — count them; a long one must
end up no longer than {int(s.units_per_scene * 1.05)} — keeping what happens, the names and the voice. Longer: add what is seen,
heard and felt (no filler, no repetition). Shorter: keep the key action and feeling.
{_voice_rules(s)}
Scenes: {rows}
Return JSON only: {{"scenes": [{{"index": 1, "narration": "..."}}]}}"""


def off_budget(story: dict, s: StorySettings) -> list[int]:
    return [i for i, scene in enumerate(story["scenes"])
            if not LOW * s.units_per_scene <= count_units(scene["narration"], s.language) <= HIGH * s.units_per_scene]


def _asked(s: StorySettings) -> int:
    return max(8, round(s.units_per_scene * ASK_SHARE))


_POLITE_END = re.compile(r"\s*(?:ခင်)?ဗျာ(?=\s*[။!?])")


def finish(story: dict, s: StorySettings) -> None:
    """Narration without the ဗျာ / ခင်ဗျာ endings the user does not want; image prompts with every character's look
    in place of the name (an image site does not know who မောင်ထက် is)."""
    looks = [(str(c.get("name") or "").strip(), str(c.get("look") or "").strip())
             for c in story.get("characters") or [] if isinstance(c, dict)]
    looks = sorted([x for x in looks if x[0] and x[1]], key=lambda x: -len(x[0]))
    for scene in story["scenes"]:
        if s.language == "my":
            scene["narration"] = _POLITE_END.sub("", scene["narration"])
        prompt = scene.get("image_prompt", "")
        for name, look in looks:
            if name in prompt:
                prompt = prompt.replace(name, f"({look.rstrip('.')})", 1).replace(name, "the same person")
        scene["image_prompt"] = prompt


def _clean_scenes(raw) -> list[dict]:
    out = []
    for scene in raw or []:
        if isinstance(scene, dict) and str(scene.get("narration") or "").strip():
            out.append({"narration": str(scene["narration"]).strip(),
                        "image_prompt": str(scene.get("image_prompt") or "").strip()})
    return out


def write_story(s: StorySettings, keys: list[str], log: Callable[[str], None] = print) -> dict:
    """{"title", "characters", "scenes": [{"narration", "image_prompt"}], "settings"}"""
    if s.scene_count <= CHUNK:
        log(f"✍️ Story ရေးနေပါတယ် — scene {s.scene_count} ခု")
        story = ask_json(_story_prompt(s), keys, log=log)
        story["scenes"] = _clean_scenes(story.get("scenes"))
        if len(story["scenes"]) < s.scene_count * 0.8:
            log(f"⚠️ Scene {len(story['scenes'])} ခုပဲ ရလို့ ပြန်ရေးခိုင်းပါတယ်")
            story = ask_json(_story_prompt(s), keys, log=log)
            story["scenes"] = _clean_scenes(story.get("scenes"))
    else:
        log(f"🗺️ ဇာတ်လမ်း အကြမ်း ရေးနေပါတယ် — scene {s.scene_count} ခု")
        outline = ask_json(_outline_prompt(s), keys, log=log)
        beats = [str(b) for b in outline.get("beats") or []]
        if len(beats) < s.scene_count:
            beats += ["The story continues toward its ending."] * (s.scene_count - len(beats))
        outline["beats"] = beats[:s.scene_count]
        story = {"title": outline.get("title", ""), "characters": outline.get("characters") or [], "scenes": []}
        for start in range(0, s.scene_count, CHUNK):
            end = min(s.scene_count, start + CHUNK)
            log(f"✍️ Scene {start + 1}-{end} ရေးနေပါတယ်")
            part = ask_json(_chunk_prompt(s, outline, start, end,
                                          [x["narration"] for x in story["scenes"]]), keys, log=log)
            story["scenes"] += _clean_scenes(part.get("scenes"))[:end - start]
    if not story["scenes"]:
        raise RuntimeError("Gemini didn't write any scene")
    finish(story, s)
    bad = off_budget(story, s)
    if bad:
        log(f"📏 Scene {len(bad)} ခု အရှည်မကိုက်လို့ ပြန်ရေးခိုင်းပါတယ်")
        for start in range(0, len(bad), 12):
            try:
                fixed = ask_json(_repair_prompt(s, story, bad[start:start + 12]), keys, log=log)
            except Exception as exc:  # noqa: BLE001  (keep the first version)
                log(f"⚠️ ပြန်ရေးလို့ မရပါ ({str(exc)[:80]}) — ပထမ version ကို ထားပါတယ်")
                continue
            for row in fixed.get("scenes") or []:
                try:
                    i = int(row.get("index")) - 1
                except (TypeError, ValueError):
                    continue
                text = str(row.get("narration") or "").strip()
                if 0 <= i < len(story["scenes"]) and text:
                    old = count_units(story["scenes"][i]["narration"], s.language)
                    if abs(count_units(text, s.language) - s.units_per_scene) < abs(old - s.units_per_scene):
                        story["scenes"][i]["narration"] = text
    total = sum(count_units(x["narration"], s.language) for x in story["scenes"])
    log(f"✅ \"{story.get('title', '')}\" — scene {len(story['scenes'])} ခု, စုစုပေါင်း {total} "
        f"{'လုံး' if s.language == 'my' else 'words'}")
    story["settings"] = asdict(s)
    return story
