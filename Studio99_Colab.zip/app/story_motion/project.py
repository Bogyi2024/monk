"""A Story Motion project = one folder: project.json (settings, story, scene pictures), images/, voice/, work/.
Everything is saved as it changes, so a story can be closed and finished later."""
from __future__ import annotations

import json
import re
import time
from pathlib import Path

DEFAULT_ROOT = Path.home() / "Videos" / "Studio99 Story Motion"


_BAD_NAME_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]+')


def slug(text: str) -> str:
    """A file name from a title. Burmese letters keep their vowel signs (a \\w pattern would drop them)."""
    text = _BAD_NAME_CHARS.sub("", text)
    text = re.sub(r"\s+", "_", text.strip()).strip("._")
    return text[:60] or "story"


class Project:
    def __init__(self, folder: Path) -> None:
        self.folder = Path(folder)
        self.file = self.folder / "project.json"
        self.data: dict = {"settings": {}, "story": None, "images": {}, "video": ""}
        if self.file.is_file():
            self.data.update(json.loads(self.file.read_text(encoding="utf-8")))

    @classmethod
    def create(cls, root: Path, name: str) -> "Project":
        folder = Path(root) / f"{time.strftime('%Y%m%d_%H%M')}_{slug(name)}"
        folder.mkdir(parents=True, exist_ok=True)
        project = cls(folder)
        project.save()
        return project

    @property
    def images_dir(self) -> Path:
        return self.folder / "images"

    @property
    def voice_dir(self) -> Path:
        return self.folder / "voice"

    @property
    def work_dir(self) -> Path:
        return self.folder / "work"

    @property
    def scenes(self) -> list[dict]:
        return (self.data.get("story") or {}).get("scenes") or []

    def image(self, index: int) -> Path | None:
        raw = (self.data.get("images") or {}).get(str(index))
        return Path(raw) if raw and Path(raw).is_file() else None

    def set_image(self, index: int, path: Path) -> None:
        self.data.setdefault("images", {})[str(index)] = str(path)
        self.save()

    def missing_images(self) -> list[int]:
        return [i for i in range(len(self.scenes)) if self.image(i) is None]

    def title(self) -> str:
        return str((self.data.get("story") or {}).get("title") or self.folder.name)

    def save(self) -> None:
        self.folder.mkdir(parents=True, exist_ok=True)
        tmp = self.file.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.file)


def list_projects(root: Path) -> list[Project]:
    if not Path(root).is_dir():
        return []
    found = [Project(p) for p in Path(root).iterdir() if (p / "project.json").is_file()]
    return sorted(found, key=lambda p: p.folder.name, reverse=True)
