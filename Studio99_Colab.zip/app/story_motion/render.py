"""Story Motion step 3: pictures + narration → video.

Each scene's picture moves while its narration plays (zoom in, zoom out, pan left/right/up/down), drawn frame by
frame with OpenCV's sub-pixel warpAffine and an ease-in-out curve — FFmpeg's zoompan steps whole pixels and
shakes. A scene lasts its narration + a short pause; the next one fades in over the previous picture's last frame.
Frames go straight into one FFmpeg encode with the narration (scene clips joined in Python, exact sample counts),
optional background music and optional burned-in subtitles (ASS, libass; FFmpeg runs in the work folder so the
paths need no escaping)."""
from __future__ import annotations

import dataclasses
import math
import re
import subprocess
import wave
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
SIZES = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080)}
EFFECTS = {"mix": ["zoom_in", "pan_right", "zoom_out", "pan_left", "zoom_in", "pan_up", "zoom_out", "pan_down"],
           "zoom": ["zoom_in", "zoom_out"], "pan": ["pan_right", "pan_left", "pan_up", "pan_down"], "still": ["still"]}
MAX_ZOOM = 1.18          # the picture is drawn this much bigger than the frame so it can move
PAN_ZOOM = 1.12


@dataclass
class Scene:
    image: Path
    audio: Path
    text: str


@dataclass
class RenderOptions:
    ratio: str = "9:16"
    fps: int = 30
    effect: str = "mix"
    crossfade: float = 0.5
    pause: float = 0.35
    subtitles: bool = True
    font: str = "Myanmar Text"           # on every Windows 10/11
    font_size: int = 0              # 0 = by the frame size
    bgm: str = ""
    bgm_volume: float = 0.18
    language: str = "my"
    quality: str = "1080"            # 1080 / 720 / 480 (video_quality.py): smaller = faster on low-end PCs


def _ease(p: float) -> float:
    p = min(1.0, max(0.0, p))
    return p * p * (3 - 2 * p)


def _cover(image: np.ndarray, w: int, h: int) -> np.ndarray:
    import cv2
    ih, iw = image.shape[:2]
    scale = max(w / iw, h / ih)
    resized = cv2.resize(image, (max(w, round(iw * scale)), max(h, round(ih * scale))),
                         interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC)
    y0, x0 = (resized.shape[0] - h) // 2, (resized.shape[1] - w) // 2
    return resized[y0:y0 + h, x0:x0 + w]


def load_picture(path: Path, w: int, h: int) -> np.ndarray:
    """The picture filling a (w*MAX_ZOOM, h*MAX_ZOOM) canvas, BGR."""
    import cv2
    data = np.fromfile(str(path), dtype=np.uint8)              # works with Burmese / spaces in the path
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"ပုံကို ဖတ်လို့ မရပါ: {path}")
    return _cover(image, math.ceil(w * MAX_ZOOM), math.ceil(h * MAX_ZOOM))


def frame_at(big: np.ndarray, effect: str, p: float, w: int, h: int) -> np.ndarray:
    """The visible part of the picture at progress p (0..1) of its scene."""
    import cv2
    bh, bw = big.shape[:2]
    e = _ease(p)
    zoom, fx, fy = 1.0, 0.5, 0.5                               # zoom 1 = the whole canvas; centre as a fraction
    if effect == "zoom_in":
        zoom = 1.0 + (MAX_ZOOM - 1.0) * e
    elif effect == "zoom_out":
        zoom = MAX_ZOOM - (MAX_ZOOM - 1.0) * e
    elif effect.startswith("pan_"):
        zoom = PAN_ZOOM
        t = e if effect in ("pan_right", "pan_down") else 1 - e
        if effect in ("pan_right", "pan_left"):
            fx = t
        else:
            fy = t
    win_w, win_h = bw / zoom, bh / zoom
    cx = win_w / 2 + (bw - win_w) * fx
    cy = win_h / 2 + (bh - win_h) * fy
    s = w / win_w
    matrix = np.float32([[s, 0, -(cx - win_w / 2) * s], [0, s, -(cy - win_h / 2) * s]])
    return cv2.warpAffine(big, matrix, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)


# ---------------------------------------------------------------------------------------------- audio
def build_narration(scenes: list[Scene], pause: float, out: Path) -> list[tuple[float, float, float]]:
    """All scene clips in one WAV with `pause` after each. Returns (start, speech_seconds, scene_seconds)."""
    timeline, chunks, cursor, rate = [], [], 0, None
    for scene in scenes:
        with wave.open(str(scene.audio), "rb") as w:
            rate = rate or w.getframerate()
            if w.getframerate() != rate or w.getnchannels() != 1:
                raise ValueError(f"Audio format differs: {scene.audio}")
            data = w.readframes(w.getnframes())
        speech = len(data) // 2
        gap = round(pause * rate)
        chunks += [data, b"\x00\x00" * gap]
        timeline.append((cursor / rate, speech / rate, (speech + gap) / rate))
        cursor += speech + gap
    with wave.open(str(out), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate or 48000)
        w.writeframes(b"".join(chunks))
    return timeline


# ---------------------------------------------------------------------------------------------- subtitles
def mm_syllables(word: str) -> list[str]:
    """Burmese written without spaces, cut into syllables (a consonant starts one unless it is stacked under the
    previous one or killed by ်)."""
    out, cur = [], ""
    for i, ch in enumerate(word):
        nxt = word[i + 1] if i + 1 < len(word) else ""
        prev = word[i - 1] if i else ""
        starts = ("က" <= ch <= "အ" or ch in "ဣဤဥဦဧဩဪဿ") and prev != "္" and nxt not in "်္"
        if starts and cur:
            out.append(cur)
            cur = ""
        cur += ch
    return out + [cur] if cur else out


def _pieces(text: str, language: str, limit: int) -> list[str]:
    """Subtitle lines of at most `limit` characters, cut at sentence ends, spaces, or (Burmese) syllables."""
    ends = r"(?<=[။!?])\s*" if language == "my" else r"(?<=[.!?])\s+"
    out = []
    for sentence in [x.strip() for x in re.split(ends, text) if x.strip()]:
        tokens = []                                           # (text, space before it)
        for n, word in enumerate(sentence.split()):
            parts = mm_syllables(word) if language == "my" and len(word) > limit else [word]
            tokens += [(part, n > 0 and k == 0) for k, part in enumerate(parts)]
        line = ""
        for part, space in tokens:
            joined = f"{line} {part}" if line and space else line + part
            if line and len(joined) > limit:
                out.append(line)
                line = part
            else:
                line = joined
        if line:
            out.append(line)
    return out


def _ass_time(t: float) -> str:
    cs = max(0, round(t * 100))
    return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"


def write_ass(scenes: list[Scene], timeline, opts: RenderOptions, w: int, h: int, out: Path) -> None:
    size = opts.font_size or round(min(w, h) * (0.062 if w < h else 0.052))
    limit = 30 if opts.language == "my" else 38
    if w > h:
        limit = int(limit * 1.6)
    margin = round(h * (0.20 if w < h else 0.08))
    lines = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {w}", f"PlayResY: {h}", "WrapStyle: 0", "",
             "[V4+ Styles]",
             "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, "
             "Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, "
             "MarginL, MarginR, MarginV, Encoding",
             f"Style: Default,{opts.font},{size},&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,1,0,0,0,100,100,0,0,1,"
             f"{max(2, round(size * 0.08))},1,2,60,60,{margin},1", "", "[Events]",
             "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"]
    for scene, (start, speech, _dur) in zip(scenes, timeline):
        pieces = _pieces(scene.text, opts.language, limit)
        total = sum(len(p) for p in pieces) or 1
        t = start
        for piece in pieces:
            span = speech * len(piece) / total
            lines.append(f"Dialogue: 0,{_ass_time(t)},{_ass_time(t + span)},Default,,0,0,0,,{piece}")
            t += span
    out.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")


# ---------------------------------------------------------------------------------------------- video
def encoder(ffmpeg: str, quality: str = "1080") -> list[str]:
    import video_quality
    try:
        probe = subprocess.run([ffmpeg, "-v", "error", "-f", "lavfi", "-i", "color=s=256x256:d=0.1", "-c:v",
                                "h264_nvenc", "-f", "null", "-"], capture_output=True, timeout=30,
                               creationflags=NO_WINDOW)
        if probe.returncode == 0:
            return video_quality.encoder_args(True, quality)
    except Exception:  # noqa: BLE001
        pass
    return video_quality.encoder_args(False, quality)


def render(scenes: list[Scene], opts: RenderOptions, work: Path, out: Path, ffmpeg: str = "ffmpeg",
           progress: Callable[[float], None] | None = None, stop: Callable[[], bool] | None = None) -> Path:
    if not scenes:
        raise ValueError("No scenes")
    import video_quality
    w, h = video_quality.frame(*SIZES.get(opts.ratio, SIZES["9:16"]), opts.quality)
    if opts.font_size:                       # a size set by hand is meant for the 1080 frame
        opts = dataclasses.replace(opts, font_size=max(10, round(opts.font_size * video_quality.scale(opts.quality))))
    work.mkdir(parents=True, exist_ok=True)
    narration = work / "narration.wav"
    timeline = build_narration(scenes, opts.pause, narration)
    total = timeline[-1][0] + timeline[-1][2]
    frames = round(total * opts.fps)
    starts = [round(t[0] * opts.fps) for t in timeline] + [frames]
    effects = EFFECTS.get(opts.effect, EFFECTS["mix"])

    cmd = [ffmpeg, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{w}x{h}", "-r", str(opts.fps),
           "-i", "-", "-i", narration.name]
    filters, audio = [], "[1:a]anull[a]"
    if opts.bgm and Path(opts.bgm).is_file():
        cmd += ["-stream_loop", "-1", "-i", str(Path(opts.bgm).resolve())]
        audio = (f"[2:a]volume={opts.bgm_volume:.2f},aresample=48000[bg];"
                 "[1:a][bg]amix=inputs=2:duration=first:dropout_transition=0:normalize=0,alimiter=limit=0.95[a]")
    video = "[0:v]format=yuv420p[v]"
    if opts.subtitles:
        write_ass(scenes, timeline, opts, w, h, work / "subs.ass")
        video = "[0:v]ass=subs.ass,format=yuv420p[v]"
    filters = f"{video};{audio}"
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd += ["-filter_complex", filters, "-map", "[v]", "-map", "[a]", *encoder(ffmpeg, opts.quality), "-r", str(opts.fps),
            "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-shortest", str(out.resolve())]
    proc = subprocess.Popen(cmd, cwd=str(work), stdin=subprocess.PIPE, stderr=subprocess.PIPE,
                            creationflags=NO_WINDOW)
    fade = max(1, round(opts.crossfade * opts.fps)) if opts.crossfade > 0 else 0
    previous_last = None
    try:
        for i, scene in enumerate(scenes):
            big = load_picture(scene.image, w, h)
            effect = effects[i % len(effects)]
            count = starts[i + 1] - starts[i]
            for f in range(count):
                if stop and stop():
                    raise InterruptedError("ရပ်လိုက်ပါပြီ")
                frame = frame_at(big, effect, f / max(1, count - 1), w, h)
                if previous_last is not None and f < fade:
                    a = (f + 1) / (fade + 1)
                    frame = (frame.astype(np.float32) * a + previous_last.astype(np.float32) * (1 - a)).astype(np.uint8)
                proc.stdin.write(frame.tobytes())
                if progress and (starts[i] + f) % 15 == 0:
                    progress((starts[i] + f) / frames)
            previous_last = frame_at(big, effect, 1.0, w, h)
        proc.stdin.close()
        err = proc.stderr.read().decode("utf-8", "replace")
        if proc.wait() != 0:
            raise RuntimeError(f"FFmpeg failed: {err[-600:]}")
    except BaseException:
        proc.kill()
        raise
    if progress:
        progress(1.0)
    return out
