"""Gemini JSON requests for Story Motion with the Profile's free keys: every key is tried on a model before the next
model; 429 (quota) moves to the next key, 503 (busy) is tried again after a pause. The library's own retry is off
so a used-up quota never sleeps for hours (RECAP 2026-10-10). Keys are never printed (only their number)."""
from __future__ import annotations

import json
import re
import time
from typing import Callable

MODELS = ("gemini-3.5-flash", "gemini-3-flash-preview", "gemini-3.5-flash-lite")
BUSY_ROUNDS = 3
BUSY_WAIT_SECONDS = 20


LOCATION_HELP = ("Gemini က ဒီနိုင်ငံကနေ တိုက်ရိုက် သုံးခွင့်မပေးပါ (User location is not supported)။ VPN ဖွင့်ပြီး "
                 "Gemini သုံးနိုင်တဲ့ VPN server ရွေးပြီး ပြန်စမ်းပါ။")


class GeminiError(RuntimeError):
    pass


def proxy() -> str:
    """Use the OS network and external VPN; no app-selected local proxy."""
    return ""


def _client(key: str):
    from google import genai
    from google.genai import types
    via = proxy()
    import custom_llm_client
    _c = custom_llm_client.load_config()
    if _c["mode"] != "gemini" or _c["base_url"]:
        return custom_llm_client.make_client(api_key=key)
    return genai.Client(api_key=key, http_options=types.HttpOptions(
        timeout=180_000, retry_options=types.HttpRetryOptions(attempts=1),
        client_args={"proxy": via} if via else None, async_client_args={"proxy": via} if via else None))


def _code(exc: Exception) -> int:
    code = getattr(exc, "code", None) or getattr(exc, "status_code", None)
    try:
        return int(code)
    except (TypeError, ValueError):
        found = re.search(r"\b(4\d\d|5\d\d)\b", str(exc))
        return int(found.group(1)) if found else 0


TTS_MODELS = ("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")
_tts_dead: set[tuple[str, int]] = set()      # (model, key number) whose quota ran out in this run
_tts_last_key = 0


def ask_audio(prompt: str, keys: list[str], voice_name: str, *, log: Callable[[str], None] = print) -> bytes:
    """Gemini TTS: 16-bit mono PCM at 24 kHz. A story needs one request per scene, so a key whose quota ran out is
    skipped for the rest of the run and the next scene starts at the key that worked last."""
    global _tts_last_key
    from google.genai import types
    if not keys:
        raise GeminiError("Profile မှာ Gemini API key မထည့်ရသေးပါ။")
    config = types.GenerateContentConfig(response_modalities=["AUDIO"], speech_config=types.SpeechConfig(
        voice_config=types.VoiceConfig(prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name=voice_name))))
    order = list(range(len(keys)))
    order = order[_tts_last_key:] + order[:_tts_last_key]
    last = ""
    for round_no in range(BUSY_ROUNDS):
        busy = False
        for model in TTS_MODELS:
            for i in order:
                if (model, i) in _tts_dead:
                    continue
                try:
                    client = _client(keys[i])
                    response = client.models.generate_content(model=model, contents=prompt, config=config)
                    for part in response.candidates[0].content.parts:
                        data = getattr(getattr(part, "inline_data", None), "data", None)
                        if data:
                            _tts_last_key = i
                            return data
                    last = f"{model}: no audio in the answer"
                except Exception as exc:  # noqa: BLE001
                    code = _code(exc)
                    last = f"{model} key {i + 1}: {code or ''} {str(exc)[:160]}"
                    if "location is not supported" in str(exc).lower():
                        raise GeminiError(LOCATION_HELP) from exc
                    if code == 429:
                        _tts_dead.add((model, i))
                        continue
                    if code in (500, 502, 503, 504):
                        busy = True
                        log(f"⏳ Gemini TTS {model} is busy ({code}) — next key/model")
                        break
                    if code in (400, 401, 403):
                        _tts_dead.add((model, i))
                    log(f"⚠️ Gemini TTS key {i + 1}: {str(exc)[:100]}")
        if not busy:
            break
        log(f"⏳ Gemini TTS busy — waiting {BUSY_WAIT_SECONDS} s")
        time.sleep(BUSY_WAIT_SECONDS)
    raise GeminiError("Gemini TTS: key အားလုံးရဲ့ ဒီနေ့ quota ကုန်သွားပါပြီ (သို့) မရပါ — ပြီးသား scene တွေ သိမ်းထားပါတယ်၊ "
                      f"မနက် quota ပြန်ရမှ ဆက်ထုတ်ပါ (သို့) Edge အသံ ပြောင်းပါ။ ({last})")


def parse_json(text: str):
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    try:
        return json.loads(text)
    except ValueError:
        start = min([i for i in (text.find("{"), text.find("[")) if i >= 0], default=-1)
        if start < 0:
            raise
        return json.loads(text[start:max(text.rfind("}"), text.rfind("]")) + 1])


def ask_json(prompt: str, keys: list[str], *, temperature: float = 0.8, models: tuple[str, ...] = MODELS,
             log: Callable[[str], None] = print, max_output_tokens: int = 60000):
    """The answer as parsed JSON. Raises GeminiError when every key and model failed."""
    from google.genai import types
    if not keys:
        raise GeminiError("Profile မှာ Gemini API key မထည့်ရသေးပါ။")
    config = types.GenerateContentConfig(response_mime_type="application/json", temperature=temperature,
                                         max_output_tokens=max_output_tokens)
    last = ""
    for round_no in range(BUSY_ROUNDS):
        busy = False
        for model in models:
            for n, key in enumerate(keys, 1):
                try:
                    client = _client(key)              # keep a reference: a dropped Client closes itself
                    response = client.models.generate_content(model=model, contents=prompt, config=config)
                    text = response.text or ""
                    if not text.strip():
                        last = f"{model}: empty answer"
                        continue
                    return parse_json(text)
                except ValueError as exc:
                    last = f"{model}: answer was not JSON ({exc})"
                    log(f"⚠️ Gemini {model} key {n}: answer was not JSON — trying again")
                except Exception as exc:  # noqa: BLE001
                    code = _code(exc)
                    last = f"{model} key {n}: {code or ''} {str(exc)[:160]}"
                    if "location is not supported" in str(exc).lower():
                        raise GeminiError(LOCATION_HELP) from exc     # every key and model gets the same answer
                    if code == 429:
                        continue                       # this key's quota: next key
                    if code in (500, 502, 503, 504):
                        busy = True
                        log(f"⏳ Gemini {model} is busy ({code}) — next key/model")
                        break                          # the model is busy: next model
                    if code in (400, 401, 403):
                        log(f"⚠️ Gemini key {n}: {code} — skipped")
                        continue
                    log(f"⚠️ Gemini {model} key {n}: {str(exc)[:120]}")
        if not busy:
            break
        log(f"⏳ Gemini busy — waiting {BUSY_WAIT_SECONDS} s (round {round_no + 1}/{BUSY_ROUNDS})")
        time.sleep(BUSY_WAIT_SECONDS)
    raise GeminiError(f"Gemini didn't answer: {last}")
