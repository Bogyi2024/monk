"""Story Motion step 2: the pictures. The user makes them on an image site (the prompt is copied, the site opens in
the browser) and brings them back by Paste (clipboard), Choose file, or a whole folder (in name order); with a FAL
key the missing ones can be made automatically (flux/schnell, the TT master's Story Motion model)."""
from __future__ import annotations

import re
import webbrowser
from pathlib import Path

import requests

SITES = {
    "Gemini": "https://gemini.google.com/app",
    "ChatGPT": "https://chatgpt.com/",
    "Bing Image Creator": "https://www.bing.com/images/create",
    "Meta AI": "https://www.meta.ai/",
    "Ideogram": "https://ideogram.ai/",
    "Leonardo": "https://app.leonardo.ai/",
}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
FAL_URL = "https://fal.run/fal-ai/flux/schnell"
FAL_SIZES = {"9:16": (720, 1280), "16:9": (1280, 720), "1:1": (1024, 1024)}


def open_site(name: str) -> None:
    webbrowser.open(SITES.get(name, name))


def _natural(path: Path):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", path.name)]


def folder_images(folder: Path) -> list[Path]:
    return sorted((p for p in folder.iterdir() if p.suffix.lower() in IMAGE_EXTS), key=_natural)


def save_image(source, dest_dir: Path, index: int) -> Path:
    """A picture (file path or PIL image) saved as the project's scene_NN.jpg."""
    from PIL import Image
    image = source if isinstance(source, Image.Image) else Image.open(source)
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / f"scene_{index + 1:03d}.jpg"
    image.convert("RGB").save(dest, quality=95)
    return dest


def clipboard_image():
    """The picture on the clipboard (copied image, or a copied image file), else None."""
    from PIL import Image, ImageGrab
    grabbed = ImageGrab.grabclipboard()
    if isinstance(grabbed, Image.Image):
        return grabbed
    if isinstance(grabbed, list):
        for item in grabbed:
            if Path(item).suffix.lower() in IMAGE_EXTS:
                return Image.open(item)
    return None


def fal_generate(prompt: str, key: str, ratio: str, dest_dir: Path, index: int) -> Path:
    width, height = FAL_SIZES.get(ratio, FAL_SIZES["9:16"])
    response = requests.post(FAL_URL, headers={"Authorization": f"Key {key}"}, timeout=180, json={
        "prompt": prompt, "image_size": {"width": width, "height": height}, "num_inference_steps": 4,
        "num_images": 1, "enable_safety_checker": True, "output_format": "jpeg"})
    if response.status_code != 200:
        raise RuntimeError(f"FAL {response.status_code}: {response.text[:200]}")
    url = response.json()["images"][0]["url"]
    data = requests.get(url, timeout=120).content
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / f"scene_{index + 1:03d}.jpg"
    dest.write_bytes(data)
    return dest
