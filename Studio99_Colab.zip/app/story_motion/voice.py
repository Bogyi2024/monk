"""Story Motion narration: one clip per scene, cached by text+voice+speed(+direction).

Two voice families: Edge TTS (free, no key, "my-MM-ThihaNeural") and Gemini TTS ("gemini:Charon" — the Profile's
keys, one request per scene, the TT master's Story Motion way: one narrator, the same director prompt every scene so
the voice does not change). Gemini has no speed setting, so its speed % is FFmpeg atempo (pitch kept).

Edge TTS pads every clip with ~0.2 s of silence before and ~0.8 s after (RECAP 2026-10-06); that padding is cut
here and the video adds its own pause between scenes. English glosses in brackets after Burmese words are not
read out. A 403 from Microsoft usually means the VPN server is refused (RECAP 2026-10-12)."""
from __future__ import annotations

import asyncio
import hashlib
import re
import subprocess
import wave
from pathlib import Path
from gemini_narrator import narrator_prompt, PROFILE_VERSION

VOICES = {
    "my": [("my-MM-ThihaNeural", "Thiha (ကျား)"), ("my-MM-NilarNeural", "Nilar (မ)")],
    "en": [("en-US-GuyNeural", "Guy (male)"), ("en-US-AndrewNeural", "Andrew (male)"),
           ("en-US-JennyNeural", "Jenny (female)"), ("en-US-AriaNeural", "Aria (female)")],
}
# Gemini prebuilt voices (multilingual); the TT master used Gacrux / Sulafat for Burmese, Algenib for English.
GEMINI_VOICES = [("Charon", "male"), ("Algenib", "male"), ("Orus", "male"), ("Iapetus", "male"), ("Puck", "male"),
                 ("Gacrux", "female"), ("Sulafat", "female"), ("Kore", "female"), ("Achernar", "female"),
                 ("Leda", "female")]
for _lang, _word in (("my", {"male": "ကျား", "female": "မ"}), ("en", {"male": "male", "female": "female"})):
    VOICES[_lang] += [(f"gemini:{name}", f"Gemini · {name} ({_word[g]})") for name, g in GEMINI_VOICES]
# The user's choice after the samples (2026-10-17): Gemini Charon (male) sounds best for Burmese.
DEFAULT_VOICE = {"my": "gemini:Charon", "en": "gemini:Charon"}
DEFAULT_DIRECTION = {
    "my": "Warm, clear Burmese storyteller at a medium natural pace; crisp diction, controlled emotion, intimate "
          "rather than announcer-like.",
    "en": "Warm, clear storyteller at a medium natural pace; controlled emotion, intimate rather than "
          "announcer-like.",
}
SAMPLE_RATE = 48000
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
EDGE_403 = ("Edge TTS 403: Microsoft က ချိတ်ဆက်မှုကို ငြင်းပါတယ် — VPN ပိတ်ပါ (သို့) server ပြောင်းပါ၊ "
            "ကွန်ပျူတာ နာရီ မှန်လား စစ်ပါ။")


def spoken_text(text: str) -> str:
    """Burmese with an English gloss in brackets: the gloss is for reading, not for the voice."""
    if re.search(r"[က-႟]", text):
        text = re.sub(r"\s*\([A-Za-z0-9 ,.'\-]+\)", "", text)
    return re.sub(r"\s+", " ", text).strip()


def is_gemini(voice: str) -> bool:
    return voice.startswith("gemini:")


def voice_gender(voice: str) -> str:
    name = voice.split(":", 1)[-1]
    found = dict(GEMINI_VOICES).get(name)
    if found:
        return found
    return "female" if any(x in voice for x in ("Nilar", "Jenny", "Aria")) else "male"


def _key(text: str, voice: str, rate: int, direction: str = "", language: str = "my") -> str:
    extra = f"|{PROFILE_VERSION}|{language}|{direction}" if is_gemini(voice) else ""
    return hashlib.sha1(f"{voice}|{rate}|{spoken_text(text)}{extra}".encode("utf-8")).hexdigest()[:12]


def gemini_prompt(text: str, voice: str, language: str, direction: str) -> str:
    return narrator_prompt(spoken_text(text), voice, language,
                           direction or DEFAULT_DIRECTION.get(language, DEFAULT_DIRECTION["en"]))


async def _edge(text: str, voice: str, rate: int, out: Path) -> None:
    import edge_tts
    await edge_tts.Communicate(text, voice, rate=f"{rate:+d}%").save(str(out))


def wav_seconds(path: Path) -> float:
    with wave.open(str(path), "rb") as w:
        return w.getnframes() / float(w.getframerate())


def synth(text: str, voice: str, rate: int, folder: Path, name: str, ffmpeg: str = "ffmpeg", *,
          keys: list[str] | None = None, language: str = "my", direction: str = "", log=print) -> Path:
    """The scene's narration as 48 kHz mono WAV, silence at both ends trimmed (cached)."""
    folder.mkdir(parents=True, exist_ok=True)
    out = folder / f"{name}_{_key(text, voice, rate, direction, language)}.wav"
    if out.is_file() and out.stat().st_size > 1000:
        return out
    trim = ("silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.05,areverse,"
            "silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.12,areverse")
    if is_gemini(voice):
        from story_motion.gemini_client import ask_audio
        pcm = ask_audio(gemini_prompt(text, voice, language, direction), keys or [], voice.split(":", 1)[1], log=log)
        raw = out.with_suffix(".24k.wav")
        with wave.open(str(raw), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(24000)
            w.writeframes(pcm)
        tempo = f",atempo={1 + rate / 100:.3f}" if rate else ""
        subprocess.run([ffmpeg, "-y", "-v", "error", "-i", str(raw), "-af", trim + tempo, "-ar", str(SAMPLE_RATE),
                        "-ac", "1", "-c:a", "pcm_s16le", str(out)], check=True, creationflags=NO_WINDOW)
        raw.unlink(missing_ok=True)
        return out
    mp3 = out.with_suffix(".mp3")
    last = None
    for _attempt in range(3):
        try:
            asyncio.run(_edge(spoken_text(text), voice, rate, mp3))
            if mp3.is_file() and mp3.stat().st_size > 500:
                break
        except Exception as exc:  # noqa: BLE001
            last = exc
            if "403" in str(exc):
                raise RuntimeError(EDGE_403) from exc
    else:
        raise RuntimeError(f"Edge TTS failed: {last}")
    subprocess.run([ffmpeg, "-y", "-v", "error", "-i", str(mp3), "-af", trim, "-ar", str(SAMPLE_RATE), "-ac", "1",
                    "-c:a", "pcm_s16le", str(out)], check=True, creationflags=NO_WINDOW)
    mp3.unlink(missing_ok=True)
    return out
