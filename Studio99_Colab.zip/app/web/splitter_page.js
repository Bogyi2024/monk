/* Browser-native implementation of the Studio99 Splitter tab. */
(() => {
  const q = (s, root=document) => root.querySelector(s);
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const api = () => window.pywebview.api;
  let opts, files=[], cuts=[], currentPath='', previewUrl='', timer=0, pollTimer=0, drag='';
  let conf;
  const safeBatchFiles = paths => [...new Set(paths)];
  const minuteClock = n => {n=Math.max(0,Math.round(Number(n)||0));const h=Math.floor(n/3600),m=Math.floor(n%3600/60),s=n%60;return h?`${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`:`${m}:${String(s).padStart(2,'0')}`;};
  function settings(){return {
    minutes:Number(q('#spMinutes').value)||3, smart_cut:q('#spSmart').checked, max_extra:Number(q('#spExtra').value)||20,
    ratio:q('#spRatio').value, fill:q('#spFill').value, quality:q('#spQuality').value,
    text:q('#spText').value, text_size:Number(q('#spTextSize').value)||46, text_pos:conf.text_pos, text_opacity:Number(q('#spTextOpacity').value), text_box:q('#spTextBox').checked,
    label_on:q('#spLabelOn').checked, label_template:q('#spLabelTemplate').value||'Part {n}', label_size:Number(q('#spLabelSize').value)||56,
    label_pos:conf.label_pos, label_opacity:Number(q('#spLabelOpacity').value), label_box:q('#spLabelBox').checked,
    output_root:q('#spOutput').value.trim()
  };}
  function select(label,id,items,value){return `<label class="field">${label}<select class="input" id="${id}">${items.map(([v,l])=>`<option value="${esc(v)}" ${String(v)===String(value)?'selected':''}>${esc(l)}</option>`).join('')}</select></label>`;}
  function mount(root){
    const d=opts.defaults; conf={text_pos:[...(d.text_pos||[.5,.86])],label_pos:[...(d.label_pos||[.5,.10])],duration:0,previewTime:1};
    root.innerHTML=`<div class="page-head"><div class="crumb"><button data-go="home">‹ Home</button><h1>Splitter · Colab</h1></div></div>
      <div class="profile-grid" style="grid-template-columns:minmax(290px,.88fr) minmax(0,1.12fr);max-width:none">
       <section class="card" style="display:flex;flex-direction:column;gap:11px">
        <div class="row" style="justify-content:space-between"><b>Videos / Settings</b><div class="row"><button class="btn sm" id="spAdd">+ Videos</button><button class="btn ghost sm" id="spFolder">+ Folder</button></div></div>
        <div id="spFiles" style="display:flex;flex-direction:column;gap:5px;max-height:130px;overflow:auto"></div><div class="dim" id="spFileCount"></div>
        <div class="row"><button class="btn ghost sm" id="spRemove">Remove selected</button><button class="btn ghost sm" id="spClear">Clear</button></div>
        <label class="field">Save to folder <input class="input" id="spOutput" placeholder="ဗလာထားရင် /content/Studio99Data/split_outputs"></label>
        <div class="profile-grid" style="grid-template-columns:1fr 1fr;gap:10px">
          <label class="field">Each part (minutes)<input class="input" id="spMinutes" type="number" min="0.25" max="600" step="0.5" value="${Number(d.minutes)||3}"></label>
          <div class="field">Smart cut<label class="check"><input id="spSmart" type="checkbox" ${d.smart_cut?'checked':''}> wait for pause</label></div>
          <label class="field">Wait up to (seconds)<input class="input" id="spExtra" type="number" min="1" max="120" value="${Number(d.max_extra)||20}"></label>
          ${select('Ratio','spRatio',opts.ratios.map(x=>[x,x]),d.ratio)}
          ${select('Fill','spFill',opts.fills,d.fill)}
          ${select('Quality','spQuality',opts.qualities,d.quality)}
        </div>
        <label class="field">Text on video <input class="input" id="spText" value="${esc(d.text)}"></label>
        <div class="profile-grid" style="grid-template-columns:1fr 1fr;gap:10px">
          <label class="field">Text size<input class="input" id="spTextSize" type="number" min="20" max="110" value="${Number(d.text_size)||46}"></label>
          <label class="field">Text opacity<input class="input" id="spTextOpacity" type="range" min="0.2" max="1" step="0.05" value="${Number(d.text_opacity)||1}"></label>
        </div>
        <label class="check"><input id="spTextBox" type="checkbox" ${d.text_box?'checked':''}> Dark box behind text</label>
        <label class="check"><input id="spLabelOn" type="checkbox" ${d.label_on?'checked':''}> Show part number</label>
        <label class="field">Part label template (use {n}, {mm}, {total})<input class="input" id="spLabelTemplate" value="${esc(d.label_template||'Part {n}')}"></label>
        <div class="profile-grid" style="grid-template-columns:1fr 1fr;gap:10px">
          <label class="field">Label size<input class="input" id="spLabelSize" type="number" min="20" max="120" value="${Number(d.label_size)||56}"></label>
          <label class="field">Label opacity<input class="input" id="spLabelOpacity" type="range" min="0.2" max="1" step="0.05" value="${Number(d.label_opacity)||1}"></label>
        </div>
        <label class="check"><input id="spLabelBox" type="checkbox" ${d.label_box?'checked':''}> Dark box behind label</label>
        <div class="msg" id="spMsg"></div>
        <div class="row"><button class="btn ghost" id="spCheck">Check cuts</button><button class="btn" id="spStart">START SPLIT</button><button class="btn danger" id="spStop" disabled>STOP</button></div>
       </section>
       <section class="card" style="display:flex;flex-direction:column;gap:12px;min-width:0">
        <div class="row" style="justify-content:space-between"><b>Preview — drag text / part label</b><span class="dim" id="spTime">00:00 / 00:00</span></div>
        <div style="position:relative;background:#05070a;border-radius:10px;overflow:hidden;min-height:250px;display:grid;place-items:center">
          <img id="spPreview" style="max-width:100%;max-height:54vh;display:block" alt="Video frame preview">
          <div id="spOverlay" style="position:absolute;inset:0;pointer-events:none"></div>
          <div id="spEmpty" class="dim" style="position:absolute">Add a video to preview</div>
        </div>
        <div class="row"><button class="btn ghost sm" id="spBack">◀ 5s</button><input id="spSeek" type="range" min="0" max="1" step="0.1" value="1" style="flex:1"><button class="btn ghost sm" id="spForward">5s ▶</button><button class="btn ghost sm" id="spRefresh">Refresh frame</button></div>
        <div class="row" style="justify-content:space-between"><b>Planned parts</b><span class="dim" id="spPartCount">Check cuts to preview the part plan</span></div>
        <div style="max-height:180px;overflow:auto"><table style="width:100%;text-align:left"><thead><tr><th>Part</th><th>Start</th><th>End</th><th>Length</th><th>Cut</th></tr></thead><tbody id="spParts"></tbody></table></div>
        <div class="kv"><span>Status</span><span id="spStatus">Ready</span></div><progress id="spProgress" max="100" value="0" style="width:100%"></progress>
        <div class="dim" id="spStage"></div><div class="row" id="spOutputs"></div>
        <pre id="spLog" style="max-height:24vh;overflow:auto;white-space:pre-wrap;background:#0a0c10;padding:12px;border-radius:8px"></pre>
       </section>
      </div>`;
    bind(); renderFiles(); refreshStatus();
  }
  function bind(){
    q('#spAdd').onclick=()=>pickVideos(true);
    q('#spFolder').onclick=async()=>{const path=window.prompt('Colab video folder path (/content/...):');if(!path)return;try{const data=await api().colab_list_videos(path);files.push(...data.files.filter(x=>!files.some(f=>f.path===x.path)));renderFiles();if(files.length)selectFile(files[0].path);else showMsg('Folder ထဲမှာ video ဖိုင်မတွေ့ပါ။');}catch(e){showMsg(e.message);}};
    q('#spRemove').onclick=()=>{const idx=Number(q('#spFiles').querySelector('input:checked')?.value);if(Number.isInteger(idx)){const removed=files.splice(idx,1)[0];if(removed?.path===currentPath)selectFile(files[0]?.path||'');renderFiles();}};
    q('#spClear').onclick=()=>{files=[];currentPath='';cuts=[];conf.duration=0;conf.previewTime=0;q('#spPreview').removeAttribute('src');q('#spEmpty').style.display='block';renderFiles();drawParts();setTime();};
    q('#spCheck').onclick=checkCuts;
    q('#spStart').onclick=start;
    q('#spStop').onclick=async()=>{try{await api().splitter_stop();}catch(e){showMsg(e.message);}};
    q('#spRatio').onchange=()=>{q('#spFill').disabled=q('#spRatio').value==='Original';updatePreview();};
    q('#spRefresh').onclick=updatePreview;
    q('#spPreview').onerror=()=>showMsg('Preview frame မဖွင့်နိုင်ပါ။ FFmpeg setup စစ်ပါ။');
    q('#spSeek').oninput=()=>{conf.previewTime=Number(q('#spSeek').value);setTime();};
    q('#spSeek').onchange=updatePreview;
    q('#spBack').onclick=()=>seekBy(-5);q('#spForward').onclick=()=>seekBy(5);
    q('#spPreview').onload=drawOverlay;
    q('#spOverlay').onpointerdown=beginDrag;
    q('#spOverlay').onpointermove=moveDrag;
    q('#spOverlay').onpointerup=()=>{drag='';persist();};
    rootInputs().forEach(el=>el.addEventListener('input',()=>{if(el.id!=='spSeek'){drawOverlay();persist();}}));
    q('#spLabelOn').onchange=drawOverlay;q('#spTextBox').onchange=drawOverlay;q('#spLabelBox').onchange=drawOverlay;
  }
  function rootInputs(){return ['spMinutes','spSmart','spExtra','spRatio','spFill','spQuality','spText','spTextSize','spTextOpacity','spTextBox','spLabelOn','spLabelTemplate','spLabelSize','spLabelOpacity','spLabelBox','spOutput'].map(id=>q('#'+id));}
  async function persist(){try{await api().splitter_save_settings(settings());}catch(_){}}
  async function pickVideos(multiple){const input=document.createElement('input');input.type='file';input.accept='video/*';input.multiple=multiple;input.onchange=async()=>{for(const file of Array.from(input.files||[])){q('#spMsg').textContent=`Uploading ${file.name}…`;try{const path=await window.S99Colab.upload(file);files.push({path,name:file.name});}catch(e){showMsg(e.message);}}renderFiles();if(files.length)selectFile(files[files.length-1].path);showMsg('');};input.click();}
  function renderFiles(){q('#spFiles').innerHTML=files.map((f,i)=>`<label class="row dim" style="gap:8px"><input type="radio" name="spSelected" value="${i}" ${f.path===currentPath?'checked':''}><span>${esc(f.name)}</span></label>`).join('')||'<div class="dim">No videos selected.</div>';q('#spFiles').querySelectorAll('input').forEach(el=>el.onchange=()=>selectFile(files[Number(el.value)].path));q('#spFileCount').textContent=`${files.length} video(s)`;}
  async function selectFile(path){currentPath=path;cuts=[];drawParts();renderFiles();const f=files.find(x=>x.path===path);if(f){q('#spEmpty').style.display='none';q('#spMsg').textContent=`Selected: ${f.name}`;}await updatePreview();}
  async function updatePreview(){if(!currentPath)return;try{const result=await api().splitter_preview(currentPath,conf.previewTime,q('#spRatio').value,q('#spFill').value);conf.duration=result.duration;q('#spSeek').max=Math.max(.1,result.duration);conf.previewTime=Math.min(conf.previewTime,result.duration);q('#spPreview').src=result.url+`&v=${Date.now()}`;q('#spEmpty').style.display='none';setTime();drawOverlay();}catch(e){showMsg(e.message);}}
  function setTime(){q('#spTime').textContent=`${minuteClock(conf.previewTime)} / ${minuteClock(conf.duration)}`;}
  function seekBy(n){conf.previewTime=Math.max(0,Math.min(conf.duration,conf.previewTime+n));q('#spSeek').value=conf.previewTime;setTime();updatePreview();}
  function drawOverlay(){const host=q('#spOverlay');if(!host)return;const frame=q('#spPreview'), rect=frame.getBoundingClientRect(), h=host.getBoundingClientRect();if(!frame.src||!rect.width){host.innerHTML='';return;}const x=(p)=>rect.left-h.left+p[0]*rect.width,y=(p)=>rect.top-h.top+p[1]*rect.height;let html='';const s=settings();if(s.text.trim())html+=`<div data-kind="text" style="position:absolute;left:${x(s.text_pos)}px;top:${y(s.text_pos)}px;transform:translate(-50%,-50%);font-size:${Math.max(12,s.text_size*rect.width/960)}px;color:white;font-weight:bold;max-width:86%;text-align:center;white-space:pre-wrap;background:${s.text_box?'#0009':'transparent'};padding:4px 10px;border-radius:5px;pointer-events:auto;touch-action:none;cursor:move">${esc(s.text)}</div>`;if(s.label_on){const total=cuts.length||1;const label=s.label_template.replaceAll('{n}','1').replaceAll('{mm}','1').replaceAll('{total}',String(total));html+=`<div data-kind="label" style="position:absolute;left:${x(s.label_pos)}px;top:${y(s.label_pos)}px;transform:translate(-50%,-50%);font-size:${Math.max(12,s.label_size*rect.width/960)}px;color:white;font-weight:bold;white-space:nowrap;background:${s.label_box?'#0009':'transparent'};padding:4px 10px;border-radius:5px;pointer-events:auto;touch-action:none;cursor:move">${esc(label)}</div>`;}host.innerHTML=html;}
  function beginDrag(e){const target=e.target.closest('[data-kind]');if(!target)return;drag=target.dataset.kind;target.setPointerCapture(e.pointerId);}
  function moveDrag(e){if(!drag)return;const frame=q('#spPreview'),fr=frame.getBoundingClientRect(),host=q('#spOverlay').getBoundingClientRect();const pos=[Math.max(.02,Math.min(.98,(e.clientX-fr.left)/fr.width)),Math.max(.02,Math.min(.98,(e.clientY-fr.top)/fr.height))];if(drag==='text')conf.text_pos=pos;else conf.label_pos=pos;drawOverlay();}
  async function checkCuts(){if(!currentPath){showMsg('အရင် video ရွေးပါ။');return;}q('#spCheck').disabled=true;try{const plan=await api().splitter_check(currentPath,settings());cuts=plan.parts||[];drawParts();}catch(e){showMsg(e.message);}finally{q('#spCheck').disabled=false;}}
  const cutLabels={pause:'pause',breath:'short pause',quietest:'quietest',exact:'exact',end:'end'};
  function drawParts(){q('#spPartCount').textContent=cuts.length?`${cuts.length} parts`:'Check cuts to preview the part plan';q('#spParts').innerHTML=cuts.map(p=>`<tr><td>${p.n}</td><td>${minuteClock(p.start)}</td><td>${minuteClock(p.end)}</td><td>${((p.end-p.start)/60).toFixed(2)} min</td><td>${cutLabels[p.cut]||esc(p.cut)}</td></tr>`).join('');drawOverlay();}
  async function start(){if(!files.length){showMsg('Video တစ်ခု အရင်ထည့်ပါ။');return;}q('#spStart').disabled=true;showMsg('Splitter စတင်နေပါတယ်…');try{await api().splitter_start(files.map(f=>f.path),settings());showMsg('');await refreshStatus();}catch(e){showMsg(e.message);q('#spStart').disabled=false;}}
  async function refreshStatus(){try{const s=await api().splitter_status();if(!q('#spStatus'))return;q('#spStatus').textContent=s.status;q('#spProgress').value=s.progress||0;q('#spStage').textContent=s.stage||'';q('#spStop').disabled=!['starting','running','stopping'].includes(s.status);q('#spStart').disabled=['starting','running','stopping'].includes(s.status);if(s.error)showMsg(s.error);if(s.logs)q('#spLog').textContent=s.logs.join('\n');const dirs=[...new Set((s.outputs||[]).map(p=>p.replace(/\\[^\\]+$/,'').replace(/\/[^/]+$/,'')))];q('#spOutputs').innerHTML=dirs.map(d=>`<button class="btn ghost sm" data-output="${esc(d)}">Download ${esc(d.split(/[\\/]/).pop())}</button>`).join('');q('#spOutputs').querySelectorAll('[data-output]').forEach(b=>b.onclick=()=>window.S99Colab.downloadFolder(b.dataset.output));}catch(_){}}
  function showMsg(text){if(q('#spMsg'))q('#spMsg').textContent=text||'';}
  PAGES.splitter_web=async root=>{opts=await api().splitter_options();mount(root);if(!pollTimer)pollTimer=setInterval(refreshStatus,2500);};
  window.S99Events=window.S99Events||{};
  window.S99Events.splitter_log=e=>{if(q('#spLog')){q('#spLog').textContent+=(e.line||'')+'\n';q('#spLog').scrollTop=q('#spLog').scrollHeight;}};
  window.S99Events.splitter_progress=e=>{if(q('#spProgress')){q('#spProgress').value=e.progress||0;q('#spStage').textContent=e.stage||'';}};
  window.S99Events.splitter_parts=e=>{if(e.source===currentPath){cuts=e.parts||[];drawParts();}};
  window.S99Events.splitter_done=()=>{refreshStatus();q('#spStart')&&(q('#spStart').disabled=false);};
  window.S99Events.splitter_stopped=()=>refreshStatus();
  window.S99Events.splitter_error=e=>{showMsg(e.message);refreshStatus();};
  const previous=window.S99.onEvent;window.S99.onEvent=e=>{previous(e);const fn=window.S99Events[e.kind];if(fn)fn(e);};
})();
