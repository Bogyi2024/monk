/* Studio99 Desktop web UI. Python side: app/webapp.py (window.pywebview.api.*), events arrive in S99.onEvent. */
"use strict";

const ICONS = {
  home: "M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z",
  search: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4",
  projects: "M3 4h18v16H3zM3 9h18",
  download: "M12 4v11M7 10l5 5 5-5M5 20h14",
  storage: "M4 4h16v6H4zM4 14h16v6H4zM7 7h1M7 17h1",
  crown: "M3 6l4 4 5-7 5 7 4-4-2 13H5z",
  support: "M4 14v-3a8 8 0 0 1 16 0v3M4 11H2v7h4v-7zM20 11h2v7h-4v-7zM18 18v3h-6",
  bell: "M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4",
  back: "M15 5l-7 7 7 7",
  play: "M8 5v14l11-7z",
  folder: "M3 6h6l2 2h10v11H3z",
  profile: "M20 21v-2a7 7 0 0 0-14 0v2M16 7a4 4 0 1 0-8 0 4 4 0 0 0 8 0",
  copy: "M8 8h11v13H8zM5 16V3h11",
  paste: "M9 3h6v4H9zM5 5h4M15 5h4v16H5V5",
  image: "M4 5h16v14H4zM8 10a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM20 16l-5-5-9 8",
  check: "M5 12l5 5L20 7",
  x: "M6 6l12 12M18 6L6 18",
  recap: "M4 5h16v14H4zM10 9l5 3-5 3z",
  splitter: "M6 4v16M18 4v16M6 12h12",
  dubbing: "M12 3a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V6a3 3 0 0 1 3-3zM5 11a7 7 0 0 0 14 0M12 18v3",
  long_to_short: "M8 3h8v18H8zM3 8h2M3 16h2M19 8h2M19 16h2",
  novel: "M5 4h10a4 4 0 0 1 4 4v12H9a4 4 0 0 1-4-4z",
  subtitle: "M3 6h18v12H3zM7 14h4M13 14h4",
  storytelling: "M4 4h16v16H4zM9 8v8l7-4z",
  story_motion: "M4 17l5-5 4 4 7-7M14 9h6v6",
  movie_review: "M12 3l2.6 5.6 6 .7-4.5 4.1 1.2 6L12 16.6 6.7 19.4l1.2-6L3.4 9.3l6-.7z",
  football_news: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7l3 2-1 4h-4l-1-4z",
  auto_posting: "M4 20l16-8L4 4v6l10 2-10 2z",
};
const SOURCES = [["youtube", "YouTube"], ["dailymotion", "Dailymotion"], ["bilibili", "Bilibili"], ["douyin", "Douyin (抖音)"], ["rednote", "RedNote"]];

const S = { user: null, page: "home", tools: [], ms: { source: "youtube", query: "", page: 1, results: [], sel: null }, downloads: {},
  sm: null, smOpt: null, lts: { running: false, log: [] }, register: false, pasteTarget: null, local: false };

/* ---------------------------------------------------------------- helpers */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const api = () => window.pywebview.api;
function esc(v) { return String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
function icon(name, color = "currentColor", size = 18) {
  return `<svg class="icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${ICONS[name] || ICONS.home}"/></svg>`;
}
function toolIcon(id, color) {
  return `<div class="ic" style="background:${color}22;color:${color}">${icon(id, "currentColor", 22)}</div>`;
}
function fillIcons(root = document) {
  $$("[data-icon]", root).forEach(el => {
    const color = el.dataset.color;
    el.innerHTML = color ? `<span style="width:30px;height:30px;border-radius:9px;background:${color}22;color:${color};display:inline-flex;align-items:center;justify-content:center">${icon(el.dataset.icon, "currentColor", 16)}</span>` : icon(el.dataset.icon);
    el.removeAttribute("data-icon");
  });
}
function toast(text, err = false, ms = 4200) {
  const el = document.createElement("div");
  el.className = "toast" + (err ? " err" : "");
  el.textContent = text;
  $("#toast").appendChild(el);
  setTimeout(() => el.remove(), ms);
}
function errText(e) { return String((e && (e.message || e)) || "Error").replace(/^Error:\s*/, ""); }
async function call(name, ...args) {
  try { return await api()[name](...args); }
  catch (e) { toast(errText(e), true); throw e; }
}
function modal(html) { $("#modalBox").innerHTML = html; $("#modal").classList.remove("hidden"); fillIcons($("#modalBox")); return $("#modalBox"); }
function closeModal() { $("#modal").classList.add("hidden"); $("#modalBox").innerHTML = ""; }
function fmtDur(s) { s = Math.round(s || 0); if (!s) return ""; const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
  return (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(x).padStart(2, "0"); }
function fmtViews(n) { n = +n || 0; if (!n) return ""; return n >= 1e6 ? (n / 1e6).toFixed(1) + "M" : n >= 1e3 ? (n / 1e3).toFixed(1) + "K" : String(n); }
function head(title, extra = "", back = true) {
  return `<div class="page-head"><div class="crumb">${back ? `<button data-go="home">${icon("back")}Home</button>` : ""}<h1>${esc(title)}</h1>${extra}</div></div>`;
}
function bindGo(root = document) { $$("[data-go]", root).forEach(b => b.onclick = () => go(b.dataset.go)); }
document.addEventListener("click", async e => {
  const button = e.target.closest("[data-help]");
  if (!button) return;
  e.preventDefault();
  try { if (!await api().open_help(button.dataset.help)) toast("Telegram link ကို ဖွင့်မရပါ။", true); }
  catch (error) { toast(errText(error), true); }
});
function fmtBytes(bytes) {
  const n = Math.max(0, Number(bytes) || 0);
  if (n < 1024) return n + " B";
  if (n < 1024 ** 2) return (n / 1024).toFixed(1) + " KB";
  if (n < 1024 ** 3) return (n / 1024 ** 2).toFixed(1) + " MB";
  return (n / 1024 ** 3).toFixed(2) + " GB";
}

/* ---------------------------------------------------------------- boot + login */
window.addEventListener("pywebviewready", async () => {
  try { fillIcons(); await boot(); }
  catch (error) { window.Studio99Startup.fail(error); }
});
async function boot() {
  const r = await api().init();
  $("#boot").classList.add("hidden");
  S.local = !!r.local_mode;
  if (r.logged_in) { S.user = r.user; enterApp(); return; }
  if (window.STUDIO99_COLAB_MODE) {
    S.user = { email: "local@studio99", vip: true, vip_plus: true, membership_tier: "vip_plus", vip_label: "VIP+" };
    enterApp(); return;
  }
  $("#email").value = r.last_email || ""; showLogin();
  if (r.offline) {                 // the saved login is kept: only the server could not be reached
    const m = $("#loginMsg"); m.className = "msg err";
    m.innerHTML = `${esc(r.message)} <a href="#" id="retryBoot">ပြန်ကြိုးစားမယ်</a>`;
    $("#retryBoot").onclick = e => { e.preventDefault(); m.innerHTML = `<span class="spin"></span>`; boot(); };
  } else if (r.message) {          // the saved login was refused (another PC has the account, banned …)
    const m = $("#loginMsg"); m.className = "msg err"; m.textContent = r.message;
  }
}

function showLogin() {
  stopNotifications();
  $("#shell").classList.add("hidden"); $("#login").classList.remove("hidden");
  setLoginMode(false);
}
function setLoginMode(register) {
  S.register = register;
  $("#loginTitle").textContent = register ? "အကောင့်သစ် ဖွင့်မယ်" : "Login ဝင်ပါ";
  $("#loginBtn").textContent = register ? "Create account" : "Login";
  $("#loginExtras").classList.toggle("hidden", register);
  $("#loginSwitch").innerHTML = register ? `အကောင့်ရှိပြီးသားလား? <a href="#" id="sw">Login ဝင်မယ်</a>` : `အကောင့် မရှိသေးရင် <a href="#" id="sw">အသစ်ဖွင့်မယ်</a>`;
  $("#sw").onclick = e => { e.preventDefault(); setLoginMode(!S.register); $("#loginMsg").textContent = ""; };
  $("#loginMsg").textContent = "";
}
$("#forgotLink").onclick = async e => {
  e.preventDefault();
  const m = $("#loginMsg");
  try { m.className = "msg ok"; m.textContent = await api().forgot($("#email").value); }
  catch (x) { m.className = "msg err"; m.textContent = errText(x); }
};
$("#loginForm").onsubmit = async e => {
  e.preventDefault();
  const m = $("#loginMsg"), b = $("#loginBtn");
  b.disabled = true; m.className = "msg"; m.innerHTML = `<span class="spin"></span>`;
  try {
    if (S.register) { m.className = "msg ok"; m.textContent = await api().register($("#email").value, $("#password").value); setLoginMode(false); }
    else { S.user = await api().login($("#email").value, $("#password").value, $("#remember").checked); $("#password").value = ""; enterApp(); }
  } catch (x) { m.className = "msg err"; m.textContent = errText(x); }
  b.disabled = false;
};

function enterApp() {
  $("#login").classList.add("hidden"); $("#shell").classList.remove("hidden");
  bindGo($("nav.side"));
  renderMe();
  go("home");
  startNotifications();
}
function renderMe() {
  const u = S.user || {};
  $("#meEmail").textContent = u.email || "";
  $("#meAv").textContent = (u.email || "S")[0].toUpperCase();
  $("#meVip").innerHTML = u.vip ? `<span class="badge" style="background:var(--gold);color:var(--gold-ink)">${membershipLabel(u)}</span>${u.vip_left || (u.days_left != null ? u.days_left + " ရက် ကျန်" : "သက်တမ်း မကန့်သတ်")}`
    : `<span class="badge soon">Free</span>`;
}
function membershipLabel(user) { return user && user.vip ? (user.membership_tier === "vip_plus" ? "VIP+" : "VIP") : "Free"; }

/* ---------------------------------------------------------------- router */
const PAGES = {};
async function go(page, arg) {
  if (S.page === "toolwin" && page !== "toolwin") { toolwinStop(); api().tools_hide().catch(() => {}); }
  S.page = page;
  $("#notificationsBell").classList.toggle("on", page === "notifications");
  const content = $("#content");
  content.dataset.page = page;
  content.classList.toggle("inner-ui", page !== "home" && page !== "toolwin");
  content.classList.toggle("toolmode", page === "toolwin");
  $$("nav.side .nav-item").forEach(b => b.classList.toggle("on", b.dataset.go === page || (page === "story_motion" && b.dataset.go === "projects") || (page === "ap_card" && b.dataset.go === "auto_posting")));
  content.innerHTML = "";
  await (PAGES[page] || PAGES.home)(content, arg);
  if (S.page !== page) return;
  fillIcons(content);
  bindGo(content);
  content.scrollTop = 0; window.scrollTo(0, 0);
}
window.S99 = { onEvent(e) { const h = EVENTS[e.kind]; if (h) h(e); } };
const EVENTS = window.S99Events = {};
EVENTS.vip_ended = e => {         // VIP ran out while the app was open: VIP tools close once their job is done
  if (e.user && S.user) { S.user = e.user; renderMe(); if (S.page === "profile") renderVip(); }
  toast(e.message, true, 12000);
};
EVENTS.vip_tool_closed = e => {
  toast(e.message, true, 9000);
  if (S.page === "toolwin" && TW.id === e.tool) go("home");
};
EVENTS.logged_out = e => {         // the 6-hourly check refused the login
  S.user = null; showLogin();
  const m = $("#loginMsg"); m.className = "msg err"; m.textContent = e.message;
};

/* ---------------------------------------------------------------- in-app notification inbox */
const NOTICES = { items: [], unread: 0, checked_at: "", error: "", openId: "", timer: 0,
  generation: 0, sequence: 0, pending: null };

function notificationBadge() {
  const badge = $("#notificationCount"), bell = $("#notificationsBell");
  badge.textContent = NOTICES.unread > 99 ? "99+" : String(NOTICES.unread);
  badge.classList.toggle("hidden", !NOTICES.unread);
  const label = `အသိပေးချက်များ${NOTICES.unread ? ` — မဖတ်ရသေး ${NOTICES.unread} ခု` : ""}`;
  bell.setAttribute("aria-label", label); bell.title = label;
}
function stopNotifications() {
  clearInterval(NOTICES.timer);
  NOTICES.generation++; NOTICES.sequence++;
  Object.assign(NOTICES, { items: [], unread: 0, checked_at: "", error: "", openId: "", timer: 0, pending: null });
  notificationBadge();
}
function startNotifications() {
  stopNotifications();
  refreshNotifications();
  NOTICES.timer = setInterval(() => { if (!document.hidden) refreshNotifications(); }, 60000);
}
function applyNotifications(data) {
  NOTICES.items = data.items || []; NOTICES.unread = data.unread || 0;
  NOTICES.checked_at = data.checked_at || ""; NOTICES.error = data.error || "";
  if (data.user && S.user) { S.user = data.user; renderMe(); if (S.page === "profile") renderVip(); }
  notificationBadge(); renderNotifications();
}
async function refreshNotifications(force = false) {
  if (!S.user) return;
  if (NOTICES.pending) return NOTICES.pending.promise;
  const request = { generation: NOTICES.generation, sequence: ++NOTICES.sequence };
  NOTICES.pending = request;
  renderNotifications();
  request.promise = (async () => {
    try {
      const data = await api().notifications(force);
      if (S.user && request.generation === NOTICES.generation && request.sequence === NOTICES.sequence) applyNotifications(data);
    } catch (error) {
      if (S.user && request.generation === NOTICES.generation && request.sequence === NOTICES.sequence) {
        NOTICES.error = "နိုတီအသစ်တွေ စစ်လို့မရသေးပါ။ " + errText(error);
      }
    } finally {
      if (NOTICES.pending === request) { NOTICES.pending = null; renderNotifications(); }
    }
  })();
  return request.promise;
}
async function readNotifications(ids) {
  const generation = NOTICES.generation, sequence = ++NOTICES.sequence;
  try {
    const data = await api().notifications_read(ids);
    if (S.user && generation === NOTICES.generation && sequence === NOTICES.sequence) applyNotifications(data);
  } catch (error) {
    if (S.user && generation === NOTICES.generation) toast(errText(error), true);
  }
}
function notificationDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "" : date.toLocaleString([], { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
function renderNotifications() {
  if (S.page !== "notifications" || !$("#noticeList")) return;
  const loading = !!NOTICES.pending;
  $("#noticeRefresh").disabled = loading;
  $("#noticeReadAll").disabled = !NOTICES.unread;
  $("#noticeSummary").textContent = NOTICES.unread ? `မဖတ်ရသေးတဲ့ အသိပေးချက် ${NOTICES.unread} ခု` : "ဖတ်စရာ အသိပေးချက်အသစ် မရှိသေးပါ";
  const status = $("#noticeStatus");
  status.classList.toggle("notice-error", !!NOTICES.error);
  status.textContent = NOTICES.error || (loading ? "အသိပေးချက်တွေ စစ်နေပါတယ်…" : NOTICES.checked_at ? "နောက်ဆုံးစစ်ချိန် · " + notificationDate(NOTICES.checked_at) : "");
  $("#noticeList").innerHTML = NOTICES.items.length ? NOTICES.items.map(item => {
    const open = NOTICES.openId === item.id;
    return `<article class="notice ${item.read ? "is-read" : "is-unread"}">
      <button class="notice-toggle" data-notice="${esc(item.id)}" aria-expanded="${open}">
        <span class="notice-icon ${item.kind === "vip" ? "vip" : ""}">${icon(item.kind === "vip" ? "profile" : "bell")}</span>
        <span class="notice-copy"><span class="notice-meta">${item.kind === "vip" ? esc(item.membership_label || "VIP") + " သက်တမ်း" : "Studio99 Admin"} <span>· ${esc(notificationDate(item.created))}</span></span>
          <b>${esc(item.title)}</b><span class="notice-preview">${esc(item.message)}</span></span>
        <span class="notice-dot" title="${item.read ? "ဖတ်ပြီး" : "မဖတ်ရသေး"}"></span>
      </button>
      ${open ? `<div class="notice-detail"><div>${esc(item.message)}</div>${item.vip_until ? `<div class="dim notice-expiry">${esc(item.membership_label || "VIP")} ကုန်ရက် · ${esc(notificationDate(item.vip_until))}</div><button class="btn gold sm" data-go="profile">Profile ကြည့်မယ်</button>` : ""}</div>` : ""}
    </article>`;
  }).join("") : `<div class="notice-empty card">${icon("bell", "var(--muted)", 32)}<b>${loading ? "အသိပေးချက်တွေ စစ်နေပါတယ်…" : NOTICES.error ? "အသိပေးချက်တွေ ပြန်စစ်ပါ" : "အသိပေးချက် မရှိသေးပါ"}</b>
    <span class="dim">Admin အသိပေးချက်နဲ့ VIP သက်တမ်းအသိပေးချက်တွေကို ဒီနေရာမှာ ကြည့်နိုင်ပါတယ်။</span></div>`;
  $$("[data-notice]", $("#noticeList")).forEach(button => button.onclick = () => {
    const item = NOTICES.items.find(x => x.id === button.dataset.notice);
    NOTICES.openId = NOTICES.openId === item.id ? "" : item.id;
    renderNotifications();
    if (NOTICES.openId && !item.read) readNotifications([item.id]);
  });
  bindGo($("#noticeList"));
}
PAGES.notifications = async root => {
  root.innerHTML = head("အသိပေးချက်များ", `<div class="row"><button class="btn ghost sm" id="noticeReadAll">အားလုံး ဖတ်ပြီး မှတ်မယ်</button><button class="btn ghost sm" id="noticeRefresh">↻ ပြန်စစ်မယ်</button></div>`) +
    `<div class="notice-heading"><b id="noticeSummary"></b><div class="dim" id="noticeStatus" role="status"></div></div><div id="noticeList" class="notice-list"></div>`;
  $("#noticeRefresh").onclick = () => refreshNotifications(true);
  $("#noticeReadAll").onclick = () => readNotifications(NOTICES.items.filter(x => !x.read).map(x => x.id));
  renderNotifications();
  await refreshNotifications();
};
document.addEventListener("visibilitychange", () => { if (!document.hidden && S.user) refreshNotifications(); });
window.addEventListener("focus", () => { if (S.user) refreshNotifications(); });

/* ---------------------------------------------------------------- home */
PAGES.home = async (root) => {
  root.innerHTML = `
  <div class="page-head">
    <div style="display:flex;flex-direction:column;gap:6px"><div class="muted">မင်္ဂလာပါ</div><h1>ဒီနေ့ ဘာလုပ်ကြမလဲ?</h1></div>
    <form class="search-box" id="homeSearch">${icon("search", "#7E879B")}<input id="homeQ" placeholder="ဇာတ်ကား ရှာမယ် — YouTube, Dailymotion, RedNote…" aria-label="Search movies"></form>
  </div>
  <section class="stats">
    <div class="stat"><div class="k">ဒီလ ထုတ်ပြီး video</div><div class="v" id="stMade">–</div></div>
    <div class="stat"><div class="k">Auto Posting — နောက်တင်မယ့်အချိန်</div><div class="v" id="stNext">–</div></div>
    <div class="stat"><div class="k">Storage သုံးထားတာ</div><div class="row" style="justify-content:space-between"><div class="v" id="stDisk">–</div><button class="btn ghost sm" data-go="storage">ရှင်းမယ်</button></div></div>
  </section>
  <section style="display:flex;flex-direction:column;gap:14px">
    <div class="row" style="justify-content:space-between"><h2 style="font-size:18px">Tools</h2><div class="dim" style="font-size:13px">Free · VIP · VIP+</div></div>
    <div class="dim" id="freeAllowance">${S.user && S.user.vip ? "Free နဲ့ VIP tools တွေ အကန့်အသတ်မရှိ သုံးနိုင်ပါတယ်။" : "Free tools အားလုံးပေါင်း တစ်ရက် ၃ ပုဒ် · VIP tools သုံးရန် VIP ဝယ်ယူပါ။"}</div>
    <div class="tools" id="tools"></div>
  </section>`;
  $("#homeSearch").onsubmit = e => { e.preventDefault(); S.ms.query = $("#homeQ").value.trim(); go("movie_search", { search: true }); };
  S.tools = await api().tools();
  $("#tools").innerHTML = S.tools.map(t => `
    <button class="tool ${t.locked ? "locked" : ""}" data-tool="${t.id}">
      <div class="row" style="justify-content:space-between;align-items:flex-start">${toolIcon(t.id, t.color)}
        <span class="badge ${t.soon ? "soon" : t.vip ? "vip" : "free"}">${t.soon ? (t.vip_plus ? "VIP+ · Soon" : "Soon") : esc(t.tier_label || (t.vip ? "VIP" : "Free"))}</span></div>
      <div style="display:flex;flex-direction:column;gap:6px"><div class="t">${esc(t.title)}</div><div class="s">${esc(t.sub)}</div></div>
    </button>`).join("");
  $$("#tools .tool").forEach(b => b.onclick = () => openTool(b.dataset.tool));
  api().stats().then(s => {
    if (S.page !== "home") return;
    $("#stMade").textContent = s.made;
    $("#stNext").textContent = s.next_post || (s.posting ? "—" : "ပိတ်ထား");
    $("#stDisk").textContent = s.storage_gb + " GB";
    if (s.daily_usage && !s.daily_usage.unlimited) $("#freeAllowance").textContent = `Free tools ဒီနေ့ ${s.daily_usage.used}/3 ပုဒ် သုံးထားပြီး · ${s.daily_usage.remaining} ပုဒ် ကျန် · မြန်မာစံတော်ချိန် မနက် ၆:၃၀ မှ ပြန်စပါမယ်။`;
  }).catch(() => {});
};
async function openTool(id) {
  const t = S.tools.find(x => x.id === id) || { title: id };
  if (t.soon) return toast(`${t.title} — မကြာခင် ထွက်ပါမယ်`);
  if (t.locked) return toast(`${t.title} က ${t.tier_label || "VIP"} member တွေအတွက်ပါ — Profile မှာ ကြည့်ပါ`, true);
  try {
    const r = await api().open_tool(id);
    if (r.kind === "page") go(r.page);
    else if (r.kind === "embed") {
      go("toolwin", r);
      if (r.no_keys) toast("⚠️ Profile မှာ Gemini key မထည့်ရသေးပါ", true);
      if (r.ai_download) toast("AI extras (torch) ကို ဒီတစ်ခါပဲ ဒေါင်းနေပါတယ် — ဘယ်ဘက်အောက်မှာ ကြည့်ပါ။ မပြီးခင်လည်း tool ကို သုံးလို့ရပါတယ်။", false, 9000);
    }
    else if (r.kind === "window") toast(r.already ? `${t.title} ပွင့်ပြီးသားပါ — taskbar မှာ ကြည့်ပါ` : `${t.title} ကို window သီးသန့်နဲ့ ဖွင့်လိုက်ပါပြီ` + (r.no_keys ? " · ⚠️ Profile မှာ Gemini key မထည့်ရသေး" : ""));
    else toast(`${t.title} — မကြာခင် ထွက်ပါမယ်`);
  } catch (e) { toast(errText(e), true); }
}

/* ---------------------------------------------------------------- profile */
PAGES.storage = async root => {
  root.innerHTML = head("Storage", `<button class="btn ghost sm" id="storageRefresh">↻ ပြန်စစ်မယ်</button>`) +
    `<section class="card storage-summary"><div><div class="dim">Project / work files / downloads သုံးထားတာ</div><h2 id="storageTotal">တွက်နေပါတယ်…</h2></div>
      <div><div class="dim">ရှင်းလို့ရတဲ့ cache</div><h2 id="storageCache">–</h2></div>
      <button class="btn" id="storageClear" disabled>ရွေးထားတဲ့ cache ရှင်းမယ်</button></section>
    <p class="dim storage-note">ပြီးသား video၊ script၊ ကိုယ်ပိုင်အသံ၊ AI အသံနဲ့ Downloads တွေကို သိမ်းထားပါမယ်။ ရွေးထားတဲ့ video render အပိုင်းတွေ၊ preview နဲ့ Story Motion ယာယီအသံ/စာတန်းကိုပဲ ရှင်းပါမယ်။ ပြန် render လုပ်တဲ့အခါ cache ပြန်ထုတ်ပါမယ်။</p>
    <div class="msg" id="storageStatus" role="status"></div><div id="storageRows" class="storage-list"></div>`;
  const list = $("#storageRows", root);
  const current = () => S.page === "storage" && list.isConnected;
  let info;
  const selected = () => $$("[data-storage]:checked", root).map(x => x.dataset.storage);
  const update = () => {
    const ids = selected(), rows = info.rows.filter(x => ids.includes(x.id));
    $("#storageClear").disabled = info.busy || !rows.length;
    $("#storageClear").textContent = `ရွေးထားတဲ့ cache ရှင်းမယ် (${fmtBytes(rows.reduce((n, x) => n + x.cache_bytes, 0))})`;
  };
  const refresh = async () => {
    $("#storageRefresh").disabled = true; $("#storageClear").disabled = true;
    $("#storageStatus").textContent = "Storage တွက်နေပါတယ်…";
    try {
      info = await api().storage_info();
      if (!current()) return;
      $("#storageTotal").textContent = fmtBytes(info.bytes);
      $("#storageCache").textContent = `${fmtBytes(info.cache_bytes)} · ဖိုင် ${info.cache_files} ခု`;
      $("#storageStatus").textContent = info.busy ? "Tool / download / Auto Posting ဖွင့်ထားလို့ cache မရှင်းနိုင်သေးပါ။ အရင်ရပ်/ပိတ်ပြီး ↻ ပြန်စစ်ပါ။" : "";
      $("#storageRows").innerHTML = info.rows.map(r => `<section class="card storage-row">
        <label class="check"><input type="checkbox" data-storage="${esc(r.id)}" ${r.cache_files && !info.busy ? "checked" : "disabled"}><b>${esc(r.title)}</b></label>
        <div class="storage-path dim">${esc(r.path)}</div>
        <div class="row"><b>${fmtBytes(r.bytes)}</b><span class="dim">${r.cache_files ? `ရှင်းလို့ရ ${fmtBytes(r.cache_bytes)} · ဖိုင် ${r.cache_files} ခု` : "သိမ်းထားမယ် · ရှင်းစရာ cache မရှိပါ"}${r.unreadable ? " · အချို့ဖိုင်တွေ ဖတ်မရပါ" : ""}</span></div>
        ${r.examples.length ? `<details><summary class="dim">ရှင်းမယ့်ဖိုင် နမူနာ</summary><div class="storage-path dim">${r.examples.map(esc).join("<br>")}</div></details>` : ""}
        <button class="btn ghost sm" data-storage-folder="${esc(r.id)}">${icon("folder")}Folder ဖွင့်မယ်</button></section>`).join("");
      $$("[data-storage]", root).forEach(x => x.onchange = update);
      $$("[data-storage-folder]", root).forEach(b => b.onclick = () => api().open_folder(info.rows.find(x => x.id === b.dataset.storageFolder).path));
      update();
    } catch (error) { if (current()) $("#storageStatus").textContent = errText(error); }
    finally { if (current()) $("#storageRefresh").disabled = false; }
  };
  $("#storageRefresh").onclick = refresh;
  $("#storageClear").onclick = () => {
    const ids = selected(), rows = info.rows.filter(x => ids.includes(x.id));
    const bytes = rows.reduce((n, x) => n + x.cache_bytes, 0), files = rows.reduce((n, x) => n + x.cache_files, 0);
    const token = info.token;
    const box = modal(`<h2>Cache ရှင်းမလား?</h2><p>ဖိုင် ${files} ခု (${fmtBytes(bytes)}) ကို ဖျက်ပါမယ်။</p><p>${rows.map(x => esc(x.title)).join(" · ")}</p>
      <p class="dim">Video render အပိုင်းနဲ့ preview တွေကို ပြန်ထုတ်လို့ရပါတယ်။ ပြီးသား video၊ script နဲ့ ကိုယ်ပိုင်အသံတွေ ကျန်ပါမယ်။</p>
      <div class="msg" id="storageConfirmStatus" role="status"></div><div class="row"><button class="btn danger" id="storageConfirm">ဖျက်ပြီး နေရာလွတ်ယူမယ်</button><button class="btn ghost" id="storageCancel">မရှင်းတော့ဘူး</button></div>`);
    $("#storageCancel", box).onclick = closeModal;
    $("#storageConfirm", box).onclick = async () => {
      $("#storageConfirm", box).disabled = true; $("#storageCancel", box).disabled = true;
      $("#storageConfirmStatus", box).textContent = "Cache ရှင်းနေပါတယ်…";
      try {
        const result = await api().storage_clear(token, ids);
        closeModal();
        toast(`ဖိုင် ${result.files} ခု ရှင်းပြီး ${fmtBytes(result.bytes)} နေရာလွတ်ရပါပြီ။${result.skipped ? ` ပြောင်းထား/ဖွင့်ထားတဲ့ဖိုင် ${result.skipped} ခု ချန်ထားပါတယ်။` : ""}`, false, 7500);
      } catch (error) { closeModal(); toast(errText(error), true); }
      if (current()) await refresh();
    };
  };
  await refresh();
};
PAGES.profile = async (root) => {
  const u = S.user || {};
  root.innerHTML = head("Profile") + `
  <div class="profile-grid">
    <section class="card" style="display:flex;flex-direction:column;gap:18px">
      <div class="row"><div class="av" style="width:56px;height:56px;border-radius:50%;background:#2A3042;display:flex;align-items:center;justify-content:center;font-family:var(--display);font-weight:700;font-size:22px">${esc((u.email || "S")[0].toUpperCase())}</div>
        <div style="display:flex;flex-direction:column;gap:4px"><b style="font-size:17px">${esc(u.email)}</b><span class="dim" style="font-size:13px">Studio99 အကောင့်</span></div></div>
      <div id="vipBox"></div>
      <div class="row help-actions"><button class="btn gold sm" data-help="vip">VIP ဝယ်မယ် / သက်တမ်းတိုးမယ်</button><button class="btn ghost sm" data-help="support">Support ဆက်သွယ်မယ်</button></div>
      <p class="dim" style="margin:0;font-size:12px">VIP · @Studio99x_bot &nbsp; Support · @Jinn260</p>
      <div class="row" style="gap:16px;font-size:13px"><a href="#" id="refreshVip">↻ ပြန်စစ်မယ်</a>${S.local ? '<span class="dim" style="font-size:12px">Local mode — server မချိတ်ထားပါ</span>' : '<a href="#" id="logout" style="color:var(--muted)">Logout</a>'}</div>
    </section>
    <section class="card" style="display:flex;flex-direction:column;gap:14px">
      <h2 style="font-size:17px">Keys</h2>
      <p class="dim" style="margin:0;font-size:13px;line-height:1.8">ကိုယ်ပိုင် key တွေကို ဒီစက်ထဲမှာ encrypt လုပ်ပြီး သိမ်းပါတယ်။ ဇာတ်ကားအချက်အလက် (TMDB) က ပုံမှန်အားဖြင့် Studio99 server ကနေ လာပါတယ် — Server မချိတ်တဲ့ Local mode မှာတော့ ကိုယ်ပိုင် TMDB token ထည့်မှ Movie Review အလုပ်လုပ်ပါမယ်။</p>
      <div class="field">Gemini API keys (တစ်ကြောင်း တစ်ခု)<div id="keyList" class="dim" style="font-family:Consolas,monospace;font-size:12px;line-height:1.8"></div>
        <textarea class="input" id="geminiKeys" rows="3" placeholder="အသစ်ထည့်/အစားထိုးချင်မှ ဒီမှာ ရေးပါ — ဗလာထားရင် အဟောင်းအတိုင်း"></textarea></div>
      <label class="field">FAL API key (Movie Review / AI ပုံ) <input class="input" id="falKey" type="password" placeholder="ဗလာထားရင် အဟောင်းအတိုင်း"></label>
      <label class="field">TMDB API Read Access Token <span class="dim" style="font-size:12px">(Local mode မှာ Movie Review အတွက် — မလိုအပ်ရင် ဗလာထားပါ)</span>
        <input class="input" id="tmdbKey" type="password" placeholder="ဗလာထားရင် အဟောင်းအတိုင်း">
      </label>
      <div style="padding:12px;border:1px solid #2b3344;border-radius:10px;display:flex;flex-direction:column;gap:10px">
        <b style="font-size:14px">Custom API Compatibility (Gemini / OpenAI / Anthropic)</b>
        <span class="dim" style="font-size:12px">gemini-web2api-go, OpenRouter, LiteLLM, OpenAI, Anthropic စတာတွေ ချိတ်သုံးနိုင်ပါတယ်။</span>
        <label class="field">API Mode (Compatibility)
          <select class="input" id="apiMode">
            <option value="gemini">Gemini Native (Google / Gemini-compatible)</option>
            <option value="openai">OpenAI Compatible (/v1/chat/completions)</option>
            <option value="anthropic">Anthropic Compatible (/v1/messages)</option>
          </select>
        </label>
        <label class="field">Base URL <span class="dim" style="font-size:12px">(ဥပမာ http://127.0.0.1:8080/v1 — Google default ဆို ဗလာထားပါ)</span>
          <input class="input" id="apiBaseUrl" placeholder="http://127.0.0.1:8080/v1">
        </label>
        <label class="field">Custom API Key <span class="dim" style="font-size:12px">(ဗလာထားရင် အဟောင်းအတိုင်း / Gemini key ကိုသုံးမယ်)</span>
          <input class="input" id="apiKey" type="password" placeholder="sk-... (optional)">
        </label>
        <label class="field">Models (comma-separated, e.g. gemini-2.5-flash, gemini-2.5-pro)
          <input class="input" id="apiModels" placeholder="gemini-2.5-flash, gemini-2.5-pro">
        </label>
        <div class="row"><button type="button" class="btn ghost sm" id="testApiBtn">🔌 Connection စမ်းမယ်</button><span class="dim" id="testApiMsg" style="font-size:12px"></span></div>
      </div>
      <div class="row"><button class="btn" id="saveKeys">သိမ်းမယ်</button><a href="#" id="getKey" style="font-size:13px">Gemini key ယူရန်</a><a href="#" id="getTmdb" style="font-size:13px">TMDB token ယူရန်</a><span class="msg ok" id="keyMsg"></span></div>
      <div id="keyFileStatus" class="dim" style="font-size:12px;line-height:1.8;overflow-wrap:anywhere"></div>
    </section>
    <section class="card" style="display:flex;flex-direction:column;gap:14px">
      <h2 style="font-size:17px">Folders</h2>
      <div class="kv"><span>Recap work folder</span><span id="fRecap"></span></div>
      <div class="kv"><span>Story Motion projects</span><span id="fStory"></span></div>
      <div class="kv"><span>Downloads</span><span id="fDl"></span></div>
      <div class="row"><button class="btn ghost sm" id="chStory">Story folder ပြောင်း</button><button class="btn ghost sm" id="chDl">Download folder ပြောင်း</button></div>
      <div><button class="btn ghost sm" data-go="storage">Storage ကြည့် / cache ရှင်းမယ်</button></div>
    </section>
    <section class="card" style="display:flex;flex-direction:column;gap:14px">
      <h2 style="font-size:17px">ချိတ်ဆက်မှု</h2>
      <div class="kv"><span>Internet / VPN</span><span id="cVpn">…</span></div>
      <div class="kv"><span>Gemini keys</span><span id="cKeys">…</span></div>
      <div class="kv"><span>NVIDIA GPU</span><span id="cGpu">…</span></div>
      <div class="kv"><span>AI extras (Dubbing နောက်ခံသံ / smooth motion)</span><span id="cAi">…</span></div>
      <div class="row" id="aiRow"></div>
    </section>
  </div>`;
  renderVip();
  $("#refreshVip").onclick = async e => { e.preventDefault(); S.user = await call("refresh"); renderMe(); renderVip(); toast("VIP ပြန်စစ်ပြီးပါပြီ"); };
  const logoutLink = $("#logout");
  if (logoutLink) logoutLink.onclick = async e => { e.preventDefault(); await api().logout(); S.user = null; showLogin(); };
  $("#getKey").onclick = e => { e.preventDefault(); api().open_url("https://aistudio.google.com/apikey"); };
  $("#getTmdb").onclick = e => { e.preventDefault(); api().open_url("https://www.themoviedb.org/settings/api"); };
  const showKeys = k => {
    $("#keyList").innerHTML = k.gemini.length ? k.gemini.map(esc).join("<br>") : "Key မထည့်ရသေးပါ";
    $("#falKey").placeholder = k.fal ? "FAL key ထည့်ပြီးသား — ဗလာထားရင် အဟောင်းအတိုင်း" : "FAL key";
    $("#tmdbKey").placeholder = k.tmdb ? "TMDB token ထည့်ပြီးသား — ဗလာထားရင် အဟောင်းအတိုင်း" : "TMDB Read Access Token";
    if ($("#apiMode")) $("#apiMode").value = k.api_mode || "gemini";
    if ($("#apiBaseUrl")) $("#apiBaseUrl").value = k.api_base_url || "";
    if ($("#apiModels")) $("#apiModels").value = k.api_models || "";
    if ($("#apiKey")) $("#apiKey").placeholder = k.api_key_set ? `သိမ်းပြီးသား (${k.api_key_masked}) — ဗလာထားရင် အဟောင်းအတိုင်း` : "sk-... (optional)";
    $("#keyFileStatus").textContent = k.error || (k.env_ready
      ? `Tool အားလုံးအတွက် key ဖိုင် အဆင်သင့်ပါ — ${k.env_file}`
      : "Profile မှာ Gemini key ထည့်ပြီး သိမ်းမယ် နှိပ်ပေးပါ။");
  };
  showKeys(await api().keys());
  $("#saveKeys").onclick = async () => {
    const g = $("#geminiKeys").value.trim(), f = $("#falKey").value.trim(), t = $("#tmdbKey").value.trim();
    $("#saveKeys").disabled = true;
    $("#keyMsg").textContent = "";
    try {
      const customApi = {
        api_mode: $("#apiMode") ? $("#apiMode").value : "gemini",
        api_base_url: $("#apiBaseUrl") ? $("#apiBaseUrl").value.trim() : "",
        api_key: ($("#apiKey") && $("#apiKey").value.trim()) ? $("#apiKey").value.trim() : null,
        api_models: $("#apiModels") ? $("#apiModels").value.trim() : "",
      };
      const k = await call("save_keys", g ? g : null, f ? f : null, t ? t : null, customApi);
      $("#geminiKeys").value = ""; $("#falKey").value = ""; $("#tmdbKey").value = ""; if ($("#apiKey")) $("#apiKey").value = ""; showKeys(k);
      $("#keyMsg").className = "msg ok";
      const customTag = (k.api_mode && k.api_mode !== "gemini") || k.api_base_url ? ` · Custom API (${k.api_mode}) ✓` : "";
      $("#keyMsg").textContent = `သိမ်းပြီးပါပြီ — Gemini key ${k.gemini.length} ခု${k.tmdb ? " · TMDB ✓" : ""}${customTag}`;
      $("#cKeys").textContent = k.gemini.length + " ခု";
    } catch (error) {
      $("#keyMsg").className = "msg";
      $("#keyMsg").textContent = "သိမ်းမရသေးပါ — " + errText(error);
    } finally {
      $("#saveKeys").disabled = false;
    }
  };
  if ($("#testApiBtn")) {
    $("#testApiBtn").onclick = async () => {
      const btn = $("#testApiBtn"), msg = $("#testApiMsg");
      btn.disabled = true;
      msg.style.color = "";
      msg.textContent = "စမ်းနေပါတယ်…";
      try {
        const mode = $("#apiMode") ? $("#apiMode").value : "gemini";
        const baseUrl = $("#apiBaseUrl") ? $("#apiBaseUrl").value.trim() : "";
        const apiKey = $("#apiKey") ? $("#apiKey").value.trim() : "";
        const rawModels = $("#apiModels") ? $("#apiModels").value.trim() : "";
        const firstModel = rawModels.split(/[,\n]/).map(s => s.trim()).find(Boolean) || "";
        const r = await call("test_custom_api", mode, baseUrl, apiKey, firstModel);
        msg.style.color = "var(--ok, #22c55e)";
        msg.textContent = `✓ ${r.mode} / ${r.model} (${r.latency_ms}ms): ${r.reply}`;
      } catch (error) {
        msg.tyle.color = "var(--danger, #ef4444)";
        msg.textContent = "✔ " + errText(error);
      } finally {
        btn.disabled = false;
      }
    };
  }
  const showFolders = f => { $("#fRecap").textContent = f.recap_work; $("#fStory").textContent = f.story; $("#fDl").textContent = f.downloads; };
  showFolders(await api().folders());
  $("#chStory").onclick = async () => { const p = await api().choose_folder(); if (p) showFolders(await api().set_folder("story", p)); };
  $("#chDl").onclick = async () => { const p = await api().choose_folder(); if (p) showFolders(await api().set_folder("downloads", p)); };
  aiProfile(await api().ai_status());
  api().connection().then(c => {
    $("#cVpn").textContent = c.network || "System / External VPN";
    $("#cKeys").textContent = c.keys + " ခု"; $("#cGpu").textContent = c.gpu || "မရှိ (CPU)";
  });
};
function renderVip() {
  const u = S.user || {}, box = $("#vipBox");
  if (!box) return;
  box.innerHTML = u.vip ? `<div class="vipcard"><div class="row" style="justify-content:space-between"><span class="badge" style="background:var(--gold);color:var(--gold-ink)">${membershipLabel(u)}</span>
      <span style="color:var(--gold);font-size:13px;font-weight:600">${u.vip_until ? esc(u.vip_until_at || u.vip_until) + " အထိ" : "သက်တမ်း မကန့်သတ်"}</span></div>
      <div class="days">${u.vip_left ? esc(u.vip_left) : u.days_left != null ? u.days_left + " ရက် ကျန်" : membershipLabel(u)}</div></div>`
    : `<div class="vipcard" style="border-color:var(--line);background:var(--surface-2)"><span class="badge soon" style="align-self:flex-start">Free</span>
      <div style="line-height:1.8">${u.was_vip ? "VIP သက်တမ်း ကုန်သွားပါပြီ။ " : ""}VIP ဝယ် / သက်တမ်းတိုးခလုတ်ကနေ Telegram bot ကို ဖွင့်နိုင်ပါတယ်။</div></div>`;
}

/* ---------------------------------------------------------------- movie search */
PAGES.movie_search = (root, arg) => {
  root.innerHTML = head("Movie Search", "", true) + `
  <form class="row" id="msForm"><div class="search-box" style="flex:1 1 380px;width:auto">${icon("search", "#7E879B")}<input id="msQ" placeholder="ဇာတ်ကားနာမည် / keyword" value="${esc(S.ms.query)}"></div>
    <button class="btn" type="submit">ရှာမယ်</button></form>
  <div class="row" id="msSources"></div>
  <div class="split"><section class="main"><div class="results" id="msResults"></div>
      <div class="row" style="justify-content:center;margin-top:16px"><button class="btn ghost hidden" id="msMore">နောက်ထပ်</button></div></section>
    <aside class="side card" id="msSide" style="display:flex;flex-direction:column;gap:16px"></aside></div>`;
  const srcRow = $("#msSources");
  srcRow.innerHTML = SOURCES.map(([k, n]) => `<button class="pill ${k === S.ms.source ? "on" : ""}" data-src="${k}">${n}</button>`).join("") + `<span class="dim" id="msLogin" style="font-size:12px"></span>`;
  $$("[data-src]", srcRow).forEach(b => b.onclick = () => { S.ms.source = b.dataset.src; $$("[data-src]").forEach(x => x.classList.toggle("on", x === b)); loginHint(); if (S.ms.query) runSearch(true); });
  $("#msForm").onsubmit = e => { e.preventDefault(); S.ms.query = $("#msQ").value.trim(); runSearch(true); };
  $("#msMore").onclick = () => runSearch(false);
  loginHint();
  renderResults(); renderSide();
  if (arg && arg.search && S.ms.query) runSearch(true);
};
async function loginHint() {
  const el = $("#msLogin"); if (!el) return;
  const s = S.ms.source;
  if (s !== "douyin" && s !== "rednote") { el.innerHTML = ""; return; }
  const li = await api().ms_logged_in();
  const name = s === "douyin" ? "Douyin (抖音)" : "RedNote";
  el.innerHTML = `${li[s] ? `✓ ${name} login အချက်အလက် ရှိ` : `${name} ရှာဖို့ login တစ်ခါ ဝင်ရပါမယ်`} — <a href="#" id="msDoLogin">${li[s] ? "Login ပြန်ဝင်" : "Login"}</a>`;
  const a = $("#msDoLogin");
  if (a) a.onclick = async e => { e.preventDefault(); toast("ပွင့်လာတဲ့ browser မှာ login ဝင်ပြီး window ကို ပိတ်ပါ"); await call("ms_login", s); loginHint(); };
}
async function runSearch(fresh) {
  if (!S.ms.query) return;
  if (fresh) { S.ms.page = 1; S.ms.results = []; S.ms.sel = null; }
  else S.ms.page += 1;
  $("#msResults").innerHTML = fresh ? `<div class="dim row"><span class="spin"></span> ရှာနေပါတယ်…</div>` : $("#msResults").innerHTML;
  try {
    const r = await api().ms_search(S.ms.source, S.ms.query, S.ms.page);
    S.ms.results = fresh ? r : S.ms.results.concat(r);
    if (fresh && r.length) S.ms.sel = r[0];
  } catch (e) { $("#msResults").innerHTML = `<div class="msg err">${esc(errText(e))}</div>`; return; }
  if (S.page !== "movie_search") return;
  renderResults(); renderSide();
  $("#msMore").classList.toggle("hidden", !S.ms.results.length);
}
function renderResults() {
  const box = $("#msResults"); if (!box) return;
  if (!S.ms.results.length) { box.innerHTML = `<div class="dim">${S.ms.query ? "ရလဒ် မရှိပါ" : "ဇာတ်ကားနာမည် ရိုက်ပြီး ရှာပါ"}</div>`; return; }
  box.innerHTML = S.ms.results.map((r, i) => `
    <button class="vcard ${S.ms.sel && S.ms.sel.id === r.id ? "on" : ""}" data-i="${i}">
      <div class="thumb" style="background-image:url('${esc(r.thumb)}')">${r.duration ? `<span class="dur">${fmtDur(r.duration)}</span>` : ""}</div>
      <div class="tt">${esc(r.title)}</div>
      <div class="meta"><span>${esc(r.channel)}</span><span>${fmtViews(r.views)}</span></div></button>`).join("");
  $$(".vcard", box).forEach(b => b.onclick = () => { S.ms.sel = S.ms.results[+b.dataset.i]; $$(".vcard", box).forEach(x => x.classList.toggle("on", x === b)); renderSide(); });
}
function renderSide() {
  const side = $("#msSide"); if (!side) return;
  const r = S.ms.sel;
  if (!r) { side.innerHTML = `<div class="dim">ဗီဒီယိုတစ်ခု ရွေးရင် ဒီမှာ preview ပြပါမယ်</div>` + downloadsHtml(); return; }
  side.innerHTML = `
    <div class="player" id="msPlayer" style="background-image:url('${esc(r.thumb)}')">
      <button class="btn ghost" id="msPlay" style="position:absolute;inset:auto auto 12px 12px">${icon("play")}${r.embed ? "Preview" : "Browser မှာ ကြည့်မယ်"}</button></div>
    <div style="display:flex;flex-direction:column;gap:6px"><b style="font-size:16px;line-height:1.5">${esc(r.title)}</b>
      <div class="dim" style="font-size:13px">${esc(r.channel)} · ${fmtDur(r.duration)} · ${fmtViews(r.views)} · ${esc(r.source)}</div></div>
    <div class="grid2">
      <label class="field">Quality<select class="input" id="msQuality"><option value="1080">1080p</option><option value="720">720p</option><option value="480">480p</option></select></label>
      <label class="field">ဒေါင်းပြီးရင်<select class="input" id="msAfter"><option value="recap">Recap ထဲ ထည့်</option><option value="folder">Folder ထဲပဲ</option></select></label>
    </div>
    <button class="btn" id="msDl">${icon("download")}Download</button>` + downloadsHtml();
  $("#msPlay").onclick = async () => {
    $("#msPlay").innerHTML = `<span class="spin"></span>`;
    let p;
    try { p = await api().ms_preview(r); } catch (e) { p = { kind: "link", url: r.url }; }
    if (p.kind === "video") $("#msPlayer").innerHTML = `<video src="${esc(p.url)}" controls autoplay style="width:100%;height:100%;background:#000"></video>`;
    else if (p.kind === "embed") $("#msPlayer").innerHTML = `<iframe src="${esc(p.url)}" allow="autoplay; fullscreen; encrypted-media" allowfullscreen></iframe>`;
    else { api().open_url(p.url); $("#msPlay").innerHTML = `${icon("play")}Browser မှာ ကြည့်မယ်`; }
  };
  $("#msDl").onclick = async () => {
    await call("ms_download", r, +$("#msQuality").value, $("#msAfter").value);
    toast("Download စပါပြီ");
  };
  bindDownloads(side);
}
function downloadsHtml() {
  const jobs = Object.values(S.downloads).sort((a, b) => b.id.localeCompare(a.id)).slice(0, 6);
  if (!jobs.length) return "";
  return `<div style="display:flex;flex-direction:column;gap:12px;border-top:1px solid var(--line);padding-top:14px">
    <b class="muted" style="font-size:13px">Downloads</b>${jobs.map(dlRow).join("")}</div>`;
}
function dlRow(j) {
  const status = { queued: "စောင့်နေ", downloading: Math.round(j.percent || 0) + "%", done: "✓ ပြီးပြီ", recap: "✓ Recap ထဲ ရောက်ပြီ", error: "⚠️ မရပါ" }[j.status] || j.status;
  return `<div class="dl-row"><div class="row" style="justify-content:space-between;flex-wrap:nowrap"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(j.title)}</span>
    <span style="color:${j.status === "error" ? "var(--bad)" : j.status === "done" || j.status === "recap" ? "var(--ok)" : "var(--dim)"};white-space:nowrap">${status}</span></div>
    ${j.status === "downloading" || j.status === "queued" ? `<div class="bar"><i style="width:${j.percent || 0}%"></i></div><div><button class="btn ghost sm" data-stop="${j.id}">ရပ်မယ်</button></div>` : ""}
    ${j.status === "error" ? `<div class="msg err">${esc(j.error || "")}</div>` : ""}
    ${j.status === "done" || j.status === "recap" ? `<div class="row"><button class="btn ghost sm" data-open="${esc(j.path)}">${icon("folder")}Folder</button><button class="btn ghost sm" data-recap="${esc(j.path)}">Recap ထဲ ထည့်</button></div>` : ""}</div>`;
}
function bindDownloads(root) {
  $$("[data-stop]", root).forEach(b => b.onclick = () => api().ms_stop(b.dataset.stop));
  $$("[data-open]", root).forEach(b => b.onclick = () => api().open_folder(b.dataset.open));
  $$("[data-recap]", root).forEach(b => b.onclick = async () => { const r = await call("ms_send_recap", b.dataset.recap); if (r) go(r.kind === "page" ? r.page : "toolwin", r); });
}
EVENTS.dl = e => {
  S.downloads[e.job.id] = e.job;
  if (e.job.status === "done") toast("Download ပြီးပါပြီ: " + e.job.title);
  if (e.job.status === "recap") {
    if (S.page === "toolwin" && TW.id === "recap") toast("Recap ထဲ ထည့်လိုက်ပါပြီ: " + e.job.title);
    else toast(`Download ပြီးပါပြီ — Recap ထဲ ထည့်ထားပါတယ် (Home → Recap)`);
  }
  if (e.job.status === "error") toast(e.job.error || "Download မရပါ", true);
  if (S.page === "movie_search") renderSide();
  if (S.page === "downloads") PAGES.downloads($("#content"));
};
PAGES.downloads = async (root) => {
  const jobs = await api().ms_downloads();
  jobs.forEach(j => S.downloads[j.id] = j);
  root.innerHTML = head("Downloads") + `<section class="card" style="display:flex;flex-direction:column;gap:14px;max-width:820px">
    ${jobs.length ? jobs.map(dlRow).join("") : `<div class="dim">ဒီတစ်ခါ download မလုပ်ရသေးပါ — Movie Search ကနေ ဒေါင်းပါ</div>`}</section>`;
  fillIcons(root); bindGo(root); bindDownloads(root);
};

/* ---------------------------------------------------------------- story motion */
PAGES.projects = async (root) => {
  if (!S.user || !S.user.vip) { root.innerHTML = head("Story Motion") + `<div class="card">Story Motion က VIP / VIP+ member တွေအတွက်ပါ။</div>`; return; }
  if (!S.smOpt) S.smOpt = await api().sm_options();
  const list = await api().sm_projects();
  root.innerHTML = head("My Projects", `<span class="badge vip">Story Motion</span>`) + `
    <div class="row"><button class="btn" id="newStory">＋ Story အသစ်</button></div>
    <div class="project-list">${list.map(p => `<button class="project" data-folder="${esc(p.folder)}"><b style="font-size:15px;line-height:1.5">${esc(p.title)}</b>
      <span class="dim" style="font-size:12px">${esc(p.date)} · scene ${p.scenes} · ပုံ ${p.images}/${p.scenes}${p.video ? " · ✓ video" : ""}</span></button>`).join("") || `<div class="dim">Project မရှိသေးပါ</div>`}</div>`;
  $("#newStory").onclick = () => openTool("story_motion");
  $$("[data-folder]", root).forEach(b => b.onclick = async () => { await openStory(b.dataset.folder); });
};
async function openStory(folder) {
  const r = await call("open_tool", "story_motion");
  if (r.kind !== "page") return;
  S.sm = folder ? await api().sm_load(folder) : null;
  go("story_motion", { keep: true });
}
PAGES.story_motion = async (root, arg) => {
  if (!S.user || !S.user.vip) { root.innerHTML = head("Story Motion") + `<div class="card">Story Motion က VIP / VIP+ member တွေအတွက်ပါ။</div>`; return; }
  if (!S.smOpt) S.smOpt = await api().sm_options();
  if (!arg || !arg.keep) S.sm = null;
  const o = S.smOpt, st = S.sm ? S.sm.settings : Object.assign({ genre: "horror", style: "narrator", narrator_gender: "male", language: "my",
    voice: o.default_voice.my, rate_percent: 0, minutes: 3, image_style: "cartoon_2d", ratio: "9:16", voice_direction: "" }, o.last || {});
  S.smStep = S.sm ? (S.smStep || "story") : "story";
  S.smSt = st;
  root.innerHTML = `<div class="page-head"><div class="crumb"><button data-go="projects">${icon("back")}Projects</button><h1>Story Motion</h1><span class="badge vip">VIP</span></div>
    <ol class="steps" id="smSteps"><li data-step="story"><i>1</i>Story</li><li data-step="images"><i>2</i>ပုံ</li><li data-step="video"><i>3</i>Video</li></ol></div>
    <div id="smBody"></div>`;
  $$("#smSteps li").forEach(li => li.onclick = () => { if (li.dataset.step !== "story" && !S.sm) return toast("Story အရင်ရေးပါ", true); S.smStep = li.dataset.step; smRender(st); });
  smRender(st);
};
function smRender(st) {
  st = st || (S.sm ? S.sm.settings : S.smSt);
  $$("#smSteps li").forEach(li => li.classList.toggle("on", li.dataset.step === S.smStep));
  const body = $("#smBody");
  if (S.smStep === "images") return smImages(body);
  if (S.smStep === "video") return smVideo(body);
  smStory(body, st);
}
function smSettingsHtml(st) {
  const o = S.smOpt, lang = st.language || "my";
  const voices = o.voices[lang] || [];
  return `<form class="card" id="smForm" style="flex:1 1 360px;max-width:420px;display:flex;flex-direction:column;gap:16px;align-self:flex-start">
    <label class="field">Idea (မရေးလည်းရ — AI က စဉ်းစားပေးမယ်)<textarea class="input" id="smIdea" rows="3">${esc(S.sm ? S.sm.settings.idea : "")}</textarea></label>
    <div class="field">ပြောပုံ<div class="choice" id="smStyle"><button type="button" data-v="narrator">ဇာတ်လမ်းပြောသူ</button><button type="button" data-v="first_person">ကိုယ်တိုင်ပြော</button></div></div>
    <div class="field" id="smGenderWrap">ပြောသူ<div class="choice" id="smGender"><button type="button" data-v="male">ကျား (ကျွန်တော်)</button><button type="button" data-v="female">မ (ကျွန်မ)</button></div></div>
    <div class="grid2"><label class="field">အမျိုးအစား<select class="input" id="smGenre">${Object.entries(o.genres).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join("")}</select></label>
      <label class="field">ဘာသာ<select class="input" id="smLang"><option value="my">မြန်မာ</option><option value="en">English</option></select></label></div>
    <label class="field">အသံ<select class="input" id="smVoice">${voices.map(([v, l]) => `<option value="${esc(v)}">${esc(l)}</option>`).join("")}</select></label>
    <label class="field" id="smDirWrap">Gemini အသံ ပုံစံ (English နဲ့ — ဗလာ = နွေးထွေးပြီး ရှင်းတဲ့ ဇာတ်လမ်းပြောသံ)<input class="input" id="smDir" placeholder="deep, slow, suspenseful horror storyteller"></label>
    <div class="grid2"><label class="field">အမြန်နှုန်း %<input class="input" id="smRate" type="number" min="-30" max="40" step="5"></label>
      <label class="field">ကြာချိန် (မိနစ်)<input class="input" id="smMin" type="number" min="1" max="30" step="0.5"></label></div>
    <div class="grid3"><div class="num"><span>Scene</span><input class="input" id="smScenes" type="number" min="3" max="200" style="height:34px;padding:0 8px"></div>
      <div class="num"><span>Scene တစ်ခု</span><b id="smPer">–</b></div><div class="num"><span>ပုံ</span><b id="smPics">–</b></div></div>
    <div class="dim" id="smNumHint" style="font-size:12px"></div>
    <div class="grid2"><label class="field">ပုံ style<select class="input" id="smImgStyle">${o.styles.map(s => `<option>${esc(s)}</option>`).join("")}</select></label>
      <label class="field">Ratio<select class="input" id="smRatio">${o.ratios.map(s => `<option>${esc(s)}</option>`).join("")}</select></label></div>
    <button class="btn" type="submit" id="smWrite">✍️ Story ${S.sm ? "ပြန်ရေးမယ်" : "ရေးမယ်"}</button>
    <div class="log hidden" id="smLog" style="max-height:120px"></div>
  </form>`;
}
function smForm() {
  return { idea: $("#smIdea").value, style: $("#smStyle .on").dataset.v, narrator_gender: $("#smGender .on").dataset.v, genre: $("#smGenre").value,
    language: $("#smLang").value, voice: $("#smVoice").value, voice_direction: $("#smDir").value, rate_percent: +$("#smRate").value || 0,
    minutes: +$("#smMin").value || 3, scene_count: +$("#smScenes").value || 12, image_style: $("#smImgStyle").value, ratio: $("#smRatio").value };
}
function smStory(body, st) {
  body.innerHTML = `<div class="split">${smSettingsHtml(st)}<section class="main" id="smScenesBox" style="display:flex;flex-direction:column;gap:14px"></section></div>`;
  const set = (id, v) => { const el = $(id); if (el && v != null) el.value = v; };
  const choose = (box, v) => $$(`${box} button`).forEach(b => b.classList.toggle("on", b.dataset.v === v));
  choose("#smStyle", st.style || "narrator"); choose("#smGender", st.narrator_gender || "male");
  set("#smGenre", st.genre); set("#smLang", st.language || "my"); set("#smRate", st.rate_percent || 0); set("#smMin", st.minutes || 3);
  set("#smImgStyle", st.image_style); set("#smRatio", st.ratio); set("#smDir", st.voice_direction || "");
  const voices = () => { const lang = $("#smLang").value; $("#smVoice").innerHTML = (S.smOpt.voices[lang] || []).map(([v, l]) => `<option value="${esc(v)}">${esc(l)}</option>`).join(""); };
  voices(); set("#smVoice", st.voice || S.smOpt.default_voice[st.language || "my"]);
  let scenesEdited = !!(S.sm && st.scene_count);
  set("#smScenes", st.scene_count || "");
  const gemini = () => $("#smVoice").value.startsWith("gemini:");
  const pickVoiceForGender = () => {
    if ($("#smStyle .on").dataset.v !== "first_person") return;
    const want = $("#smGender .on").dataset.v, fam = gemini(), lang = $("#smLang").value;
    const isFemale = l => /\((မ|female)\)/.test(l);
    const cur = (S.smOpt.voices[lang] || []).find(([v]) => v === $("#smVoice").value);
    if (cur && isFemale(cur[1]) === (want === "female")) return;
    const hit = (S.smOpt.voices[lang] || []).find(([v, l]) => v.startsWith("gemini:") === fam && isFemale(l) === (want === "female"));
    if (hit) $("#smVoice").value = hit[0];
  };
  const refresh = async () => {
    $("#smGenderWrap").style.opacity = $("#smStyle .on").dataset.v === "first_person" ? 1 : .4;
    $("#smDirWrap").classList.toggle("hidden", !gemini());
    const auto = await api().sm_numbers(Object.assign(smForm(), { scene_count: 0 }));
    if (!scenesEdited) $("#smScenes").value = auto.auto_scenes;
    const scenes = +$("#smScenes").value || auto.auto_scenes;
    const n2 = await api().sm_numbers(Object.assign(smForm(), { scene_count: scenes }));
    $("#smPer").textContent = "~" + n2.per_scene + " " + n2.unit; $("#smPics").textContent = scenes;
    $("#smNumHint").textContent = `တစ်ပုံ ~${n2.seconds} စက္ကန့် · စုစုပေါင်း ~${n2.total} ${n2.unit}`;
  };
  $$("#smStyle button, #smGender button").forEach(b => b.onclick = () => { choose("#" + b.parentElement.id, b.dataset.v); pickVoiceForGender(); refresh(); });
  $("#smLang").onchange = () => { voices(); $("#smVoice").value = S.smOpt.default_voice[$("#smLang").value]; pickVoiceForGender(); refresh(); };
  ["#smVoice", "#smRate", "#smMin"].forEach(id => $(id).oninput = () => refresh());
  $("#smScenes").oninput = () => { scenesEdited = true; refresh(); };
  $("#smForm").onsubmit = async e => {
    e.preventDefault();
    if (S.sm && S.sm.scenes.length && !confirm("ဒီ project ရဲ့ story ကို အသစ်ပြန်ရေးမလား? (ပုံတွေ ပြန်ထည့်ရမယ်)")) return;
    $("#smWrite").disabled = true; $("#smLog").classList.remove("hidden"); $("#smLog").textContent = "";
    try { await api().sm_write(Object.assign(smForm(), { scene_count: +$("#smScenes").value }), S.sm ? S.sm.folder : ""); }
    catch (x) { toast(errText(x), true); $("#smWrite").disabled = false; }
  };
  refresh();
  smScenes();
}
function smScenes() {
  const box = $("#smScenesBox"); if (!box) return;
  if (!S.sm) { box.innerHTML = `<div class="card dim" style="line-height:1.9">ဘယ်ဘက်မှာ ပြောပုံ၊ ကြာချိန် ရွေးပြီး <b>Story ရေးမယ်</b> နှိပ်ပါ။ Scene တစ်ခုချင်းရဲ့ စာနဲ့ ပုံ prompt ကို ဒီမှာ ပြင်လို့ရပါမယ်။</div>`; return; }
  const ratio = { "9:16": "r916", "16:9": "r169", "1:1": "r11" }[S.sm.settings.ratio] || "r916";
  box.innerHTML = `<div class="row" style="justify-content:space-between"><input class="input" id="smTitle" value="${esc(S.sm.title)}" style="flex:1;font-family:var(--display);font-size:16px;font-weight:600;height:42px">
      <span class="dim" style="font-size:13px">${S.sm.scenes.length} scene</span></div>` +
    S.sm.scenes.map((s, i) => `<article class="scene" data-i="${i}"><div class="pic ${ratio}" data-pic="${i}">${S.sm.has_image[i] ? "" : "ပုံ မရှိသေး"}</div>
      <div class="body"><div class="row dim" style="justify-content:space-between;font-size:12px"><b class="muted">Scene ${i + 1}</b><span data-count="${i}"></span></div>
        <textarea data-text="${i}" rows="3">${esc(s.narration)}</textarea>
        <details><summary class="dim" style="font-size:12px;cursor:pointer">ပုံ prompt</summary><textarea data-prompt="${i}" class="prompt" rows="2">${esc(s.image_prompt)}</textarea></details></div></article>`).join("");
  $("#smTitle").onchange = () => api().sm_save_title(S.sm.folder, $("#smTitle").value);
  const save = async i => {
    const r = await api().sm_save_scene(S.sm.folder, i, $(`[data-text="${i}"]`).value, $(`[data-prompt="${i}"]`).value);
    S.sm.scenes[i].narration = $(`[data-text="${i}"]`).value; S.sm.scenes[i].image_prompt = $(`[data-prompt="${i}"]`).value;
    $(`[data-count="${i}"]`).textContent = `${r.count} ${S.sm.settings.language === "en" ? "words" : "လုံး"} · ~${r.seconds} စက္ကန့် (ထားချင်တာ ~${S.sm.settings.units_per_scene})`;
  };
  $$("[data-text], [data-prompt]", box).forEach(t => t.onchange = () => save(+(t.dataset.text ?? t.dataset.prompt)));
  S.sm.scenes.forEach((_s, i) => save(i).catch(() => {}));
  $$("[data-pic]", box).forEach(el => el.onclick = () => { S.smStep = "images"; smRender(); });
  loadThumbs(box);
}
async function loadThumbs(root) {
  for (const el of $$("[data-pic]", root)) {
    const i = +el.dataset.pic;
    if (!S.sm.has_image[i]) continue;
    const url = await api().sm_image(S.sm.folder, i);
    if (url) { el.style.backgroundImage = `url('${url}')`; el.textContent = ""; }
  }
}
EVENTS.story_log = e => { const l = $("#smLog"); if (l) { l.textContent += e.line + "\n"; l.scrollTop = 1e9; } };
EVENTS.story_done = e => { S.sm = e.project; toast(`Story ရပါပြီ — scene ${e.project.scenes.length} ခု`); if (S.page === "story_motion") { S.smStep = "story"; smRender(S.sm.settings); } };
EVENTS.story_error = e => { toast(e.message, true); const b = $("#smWrite"); if (b) b.disabled = false; EVENTS.story_log({ line: "⚠️ " + e.message }); const f = $("#smFal"); if (f) f.disabled = false; };

function smImages(body) {
  if (!S.sm) { S.smStep = "story"; return smRender(); }
  const ratio = { "9:16": "r916", "16:9": "r169", "1:1": "r11" }[S.sm.settings.ratio] || "r916";
  body.innerHTML = `<div class="card" style="display:flex;flex-direction:column;gap:12px;padding:16px">
      <div class="row"><select class="input" id="smSite" style="width:200px">${S.smOpt.sites.map(s => `<option>${esc(s)}</option>`).join("")}</select>
        <button class="btn ghost sm" id="smOpenSite">🌐 Site ဖွင့်</button><button class="btn ghost sm" id="smCopyAll">${icon("copy")}Prompt အားလုံး copy</button>
        <button class="btn ghost sm" id="smFolder">${icon("folder")}Folder ကနေ ထည့်</button><button class="btn ghost sm" id="smFal" ${S.smOpt.fal ? "" : "disabled"}>✨ FAL နဲ့ ကျန်တာ ထုတ်</button>
        <span class="spacer"></span><b id="smImgCount" style="color:var(--gold)"></b></div>
      <div class="dim" style="font-size:12.5px;line-height:1.8">Scene ရဲ့ <b>Prompt</b> နှိပ် (copy ဖြစ်) → Site မှာ paste ပြီး ပုံထုတ် → ပုံပေါ် right-click → <b>Copy image</b> → ဒီက ကတ်ကိုနှိပ်ပြီး <b>Ctrl+V</b> (ဒါမှမဟုတ် Paste ခလုတ်)။ ပုံတွေ download ထားရင် Folder ကနေ တစ်ခါတည်း ထည့် (01, 02… အစဉ်)။</div></div>
    <div class="results" id="smGrid" style="grid-template-columns:repeat(auto-fill,minmax(${ratio === "r169" ? 220 : 150}px,1fr))"></div>`;
  const grid = $("#smGrid");
  grid.innerHTML = S.sm.scenes.map((s, i) => `<div class="vcard" data-card="${i}" tabindex="0">
      <div class="pic ${ratio}" data-pic="${i}" style="border-radius:10px;background:#1B2030 center/cover no-repeat;display:flex;align-items:center;justify-content:center;color:var(--dim);font-size:11px;font-weight:700">${S.sm.has_image[i] ? "" : "ပုံ မရှိသေး"}</div>
      <b style="font-size:13px">Scene ${i + 1}</b>
      <div class="row" style="gap:6px"><button class="btn ghost sm" data-cp="${i}">Prompt</button><button class="btn ghost sm" data-ps="${i}">Paste</button><button class="btn ghost sm" data-fl="${i}">File</button></div></div>`).join("");
  const count = () => $("#smImgCount").textContent = `ပုံ ${S.sm.has_image.filter(Boolean).length} / ${S.sm.scenes.length}`;
  count();
  const setPic = (i, url) => { S.sm.has_image[i] = true; const el = $(`#smGrid [data-pic="${i}"]`); if (el) { el.style.backgroundImage = `url('${url}')`; el.textContent = ""; } count(); };
  $$("[data-cp]", grid).forEach(b => b.onclick = async () => { await navigator.clipboard.writeText(S.sm.scenes[+b.dataset.cp].image_prompt); S.pasteTarget = +b.dataset.cp; markTarget(); toast(`Scene ${+b.dataset.cp + 1} prompt copy ပြီး — site မှာ paste ပါ`); });
  $$("[data-fl]", grid).forEach(b => b.onclick = async () => { const url = await call("sm_choose_image", S.sm.folder, +b.dataset.fl); if (url) setPic(+b.dataset.fl, url); });
  $$("[data-ps]", grid).forEach(b => b.onclick = async () => {
    const i = +b.dataset.ps; S.pasteTarget = i; markTarget();
    try {
      const items = await navigator.clipboard.read();
      for (const it of items) { const type = it.types.find(t => t.startsWith("image/")); if (type) { await pasteBlob(i, await it.getType(type), setPic); return; } }
      toast("Clipboard မှာ ပုံ မရှိပါ — ပုံပေါ် right-click → Copy image လုပ်ပါ", true);
    } catch (e) { toast("Ctrl+V နှိပ်ပြီး paste လုပ်ပါ"); }
  });
  $$("[data-card]", grid).forEach(c => c.onclick = e => { if (e.target.tagName !== "BUTTON") { S.pasteTarget = +c.dataset.card; markTarget(); } });
  S.onPaste = (i, blob) => pasteBlob(i, blob, setPic);
  $("#smOpenSite").onclick = () => api().sm_open_site($("#smSite").value);
  $("#smCopyAll").onclick = async () => { await navigator.clipboard.writeText(S.sm.scenes.map((s, i) => `${String(i + 1).padStart(2, "0")}. ${s.image_prompt}`).join("\n\n")); toast("Prompt အားလုံး copy ပြီးပါပြီ"); };
  $("#smFolder").onclick = async () => { const n = await call("sm_load_folder", S.sm.folder); if (n) { S.sm = await api().sm_load(S.sm.folder); smImages(body); toast(`ပုံ ${n} ပုံ ထည့်ပြီး`); } };
  $("#smFal").onclick = async () => { $("#smFal").disabled = true; await call("sm_fal", S.sm.folder); toast("FAL နဲ့ ပုံ ထုတ်နေပါတယ်…"); };
  loadThumbs(grid);
}
function markTarget() { $$("#smGrid [data-card]").forEach(c => c.style.borderColor = +c.dataset.card === S.pasteTarget ? "var(--accent)" : ""); }
async function pasteBlob(i, blob, setPic) {
  const url = await new Promise(res => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(blob); });
  const thumb = await call("sm_paste_image", S.sm.folder, i, url);
  setPic(i, thumb); toast(`Scene ${i + 1} ပုံ ထည့်ပြီး`);
  if (i + 1 < S.sm.scenes.length) { S.pasteTarget = i + 1; markTarget(); }
}
document.addEventListener("paste", e => {
  if (S.page !== "story_motion" || S.smStep !== "images" || S.pasteTarget == null || !S.onPaste) return;
  const item = Array.from(e.clipboardData.items || []).find(x => x.type.startsWith("image/"));
  if (item) { e.preventDefault(); S.onPaste(S.pasteTarget, item.getAsFile()); }
});
EVENTS.image_ready = e => { if (S.sm) S.sm.has_image[e.index] = true; if (S.page === "story_motion" && S.smStep === "images") smImages($("#smBody")); };
EVENTS.fal_done = () => toast("FAL ပုံတွေ ရပါပြီ");

function smVideo(body) {
  if (!S.sm) { S.smStep = "story"; return smRender(); }
  const v = Object.assign({ effect: "mix", crossfade: true, pause: 0.35, subtitles: true, font_size: 0, bgm: "", bgm_volume: 18, out_folder: "", quality: "1080" }, S.smOpt.video || {});
  body.innerHTML = `<div class="split"><section class="card main" style="display:flex;flex-direction:column;gap:16px;max-width:760px">
      <div class="grid2"><label class="field">ပုံ ရွေ့ပုံ<select class="input" id="vEffect">${Object.entries(S.smOpt.effects).map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join("")}</select></label>
        <label class="field">Scene ကြား အနား (စက္ကန့်)<input class="input" id="vPause" type="number" min="0.1" max="1.5" step="0.05"></label></div>
      <label class="check"><input type="checkbox" id="vFade">Scene ကူးရင် ဖြည်းဖြည်း ပြောင်း (crossfade)</label>
      <div class="row"><button type="button" class="btn ghost" id="vOwnVoice">🎙 ကိုယ်ပိုင်အသံသွင်းမယ်</button><span class="dim">Scene တစ်ပိုဒ်ချင်း · noise removal · offline</span></div>
      <label class="field">Video quality — စက်နိမ့်ရင် 720p / 480p က အများကြီး ပိုမြန်ပါတယ်<select class="input" id="vQuality">${Object.entries(S.smOpt.qualities || { "1080": "1080p", "720": "720p", "480": "480p" }).map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join("")}</select></label>
      <div class="grid2"><label class="check"><input type="checkbox" id="vSubs">စာတန်း ထည့်မယ်</label><label class="field">စာတန်း အရွယ် (0 = အလိုလို)<input class="input" id="vFont" type="number" min="0" max="140" step="2"></label></div>
      <div class="field">နောက်ခံ သီချင်း<div class="row" style="flex-wrap:nowrap"><input class="input" id="vBgm" placeholder="mp3 / wav (မထည့်လည်းရ)"><button class="btn ghost sm" id="vBgmBtn">Browse</button>
        <input class="input" id="vVol" type="number" min="0" max="100" style="width:90px" title="အသံ %"></div></div>
      <div class="field">Output folder<div class="row" style="flex-wrap:nowrap"><input class="input" id="vOut" placeholder="ဗလာ = project folder ထဲ"><button class="btn ghost sm" id="vOutBtn">Browse</button></div></div>
      <div class="row"><button class="btn ghost" id="vTest">🔊 အသံ နမူနာ</button><button class="btn" id="vMake">🎬 Video ထုတ်မယ်</button><button class="btn danger" id="vStop">ရပ်မယ်</button></div>
      <div class="bar"><i id="vBar"></i></div><div class="msg" id="vMsg"></div>
      <div id="vDone"></div></section></div>`;
  $("#vEffect").value = v.effect; $("#vPause").value = v.pause; $("#vFade").checked = !!v.crossfade; $("#vSubs").checked = !!v.subtitles;
  $("#vQuality").value = v.quality || "1080";
  $("#vFont").value = v.font_size; $("#vBgm").value = v.bgm; $("#vVol").value = v.bgm_volume; $("#vOut").value = v.out_folder;
  $("#vBgmBtn").onclick = async () => { const p = await api().choose_file("audio"); if (p) $("#vBgm").value = p; };
  $("#vOutBtn").onclick = async () => { const p = await api().choose_folder(); if (p) $("#vOut").value = p; };
  $("#vTest").onclick = () => { call("sm_voice_test", S.sm.folder); toast("အသံ နမူနာ ထုတ်နေပါတယ်…"); };
  $("#vOwnVoice").onclick = async () => {
    const b = $("#vOwnVoice"); b.disabled = true;
    $("#vMake").disabled = true;
    try { await api().sm_own_voice(S.sm.folder); toast("ကိုယ်ပိုင်အသံ ရွေးချယ်မှု သိမ်းပြီးပါပြီ"); }
    catch (x) { toast(errText(x), true); }
    finally { b.disabled = false; const m = $("#vMake"); if (m) m.disabled = false; }
  };
  $("#vStop").onclick = () => api().sm_stop();
  $("#vMake").onclick = async () => {
    const opts = { effect: $("#vEffect").value, pause: +$("#vPause").value, crossfade: $("#vFade").checked, subtitles: $("#vSubs").checked,
      font_size: +$("#vFont").value || 0, bgm: $("#vBgm").value.trim(), bgm_volume: +$("#vVol").value || 0, out_folder: $("#vOut").value.trim(),
      quality: $("#vQuality").value };
    S.smOpt.video = opts;
    try { await api().sm_make(S.sm.folder, opts); $("#vMake").disabled = true; $("#vMsg").className = "msg"; $("#vMsg").textContent = "စနေပါတယ်…"; }
    catch (x) { toast(errText(x), true); if (/ပုံ မထည့်ရသေး/.test(errText(x))) { S.smStep = "images"; smRender(); } }
  };
  if (S.sm.video) $("#vDone").innerHTML = `<div class="row"><span class="dim">ထုတ်ပြီးသား: ${esc(S.sm.video)}</span><button class="btn ghost sm" data-open="${esc(S.sm.video)}">${icon("folder")}Folder</button></div>`;
  bindDownloads(body);
}
EVENTS.video_progress = e => {
  const bar = $("#vBar"), msg = $("#vMsg"); if (!bar) return;
  if (e.stage === "voice") { bar.style.width = Math.round(e.done * 30 / Math.max(1, e.total)) + "%"; msg.textContent = `🔊 အသံ ${e.done + 1}/${e.total}`; }
  else { bar.style.width = (30 + e.percent * 0.7) + "%"; msg.textContent = `🎬 Video ${e.percent}%`; }
};
EVENTS.video_log = e => { const msg = $("#vMsg"); if (msg) msg.textContent = e.line; };
EVENTS.video_error = e => { toast(e.message, true); const b = $("#vMake"); if (b) b.disabled = false; const m = $("#vMsg"); if (m) { m.className = "msg err"; m.textContent = e.message; } };
EVENTS.video_done = e => {
  if (S.sm) S.sm.video = e.path;
  toast("Video ရပါပြီ 🎬");
  if (S.page === "story_motion" && S.smStep === "video") { smVideo($("#smBody")); $("#vBar").style.width = "100%"; }
  if (S.user && S.user.vip_plus) openSend("story_motion", { preselect: [e.path] });
};

/* ---------------------------------------------------------------- long to short */
PAGES.long_to_short = async (root) => {
  const o = await api().lts_options(), s = o.saved || {};
  root.innerHTML = head("Long to Short", `<span class="badge free">Free</span>`) + `
  <div class="split"><form class="card main" id="ltsForm" style="display:flex;flex-direction:column;gap:16px;max-width:760px">
    <div class="field">Video (ဖိုင် ဒါမှမဟုတ် YouTube link) — English video ရှည် (interview / podcast / talk)
      <div class="row" style="flex-wrap:nowrap"><input class="input" id="ltsSrc" value="${esc(s.source || "")}"><button type="button" class="btn ghost sm" id="ltsBrowse">Browse</button></div></div>
    <div class="grid2"><label class="field">အကြောင်းအရာ<select class="input" id="ltsProfile">${o.profiles.map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join("")}</select></label>
      <label class="field">Clip အရေအတွက်<input class="input" id="ltsCount" type="number" min="1" max="8" value="${s.count || 3}"></label></div>
    <div class="grid2"><label class="field">Video size<select class="input" id="ltsRatio"><option value="9:16">9:16 — ဒေါင်လိုက်</option><option value="Original">Original — မူရင်းအရွယ်အစား၊ ပုံအပြည့်</option></select></label>
      <label class="field">Clip အရှည် (ခန့်မှန်း မိနစ်)<input class="input" id="ltsMinutes" type="number" min="0.25" max="10" step="0.25" placeholder="Auto (70–150 စက္ကန့်)" value="${s.clip_minutes ?? ""}"></label></div>
    <label class="check"><input type="checkbox" id="ltsSubtitles" ${s.subtitles_enabled === false ? "" : "checked"}>စာတန်းထိုး ထည့်မယ်</label>
    <div class="hint">CapCut မှာ ဆက်ပြင်ဖို့ Original size + မူရင်းအသံ + စာတန်း OFF ရွေးနိုင်ပါတယ်။ Clip က သဘာဝကျတဲ့ စကားအဆုံးမှာ ဖြတ်လို့ ရွေးထားတဲ့မိနစ်နဲ့ အနည်းငယ်ကွာနိုင်ပါတယ်။</div>
    <div class="field">ထုတ်မယ့်ပုံစံ<div class="grid2" id="ltsModes">${o.modes.map(([k, l]) => `<label class="check"><input type="checkbox" value="${k}">${esc(l)}</label>`).join("")}</div></div>
    <div class="field">Output folder<div class="row" style="flex-wrap:nowrap"><input class="input" id="ltsOut" value="${esc(s.out_folder || "")}"><button type="button" class="btn ghost sm" id="ltsOutBtn">Browse</button></div></div>
    <label class="check"><input type="checkbox" id="ltsDel" ${s.delete_work === false ? "" : "checked"}>ပြီးရင် work files ဖျက် (output folder ထဲက clip တွေပဲ ချန်)</label>
    <label class="field">⚡ Video encode အမြန်နှုန်း (စက်နိမ့်ရင် မြန် / အမြန်ဆုံး)<select class="input" id="ltsSpeed"></select></label>
    <div class="row"><button class="btn" type="submit" id="ltsStart">▶ Start</button><button class="btn danger" type="button" id="ltsStop">Stop</button><span class="msg" id="ltsMsg"></span></div>
  </form><aside class="side"><div class="log" id="ltsLog" style="height:520px"></div></aside></div>`;
  $("#ltsProfile").value = s.profile || "generic";
  $("#ltsRatio").value = s.output_ratio || "9:16";
  const modes = s.modes || ["transformative_envo_mm"];
  $$("#ltsModes input").forEach(i => i.checked = modes.includes(i.value));
  $("#ltsLog").textContent = S.lts.log.join("\n");
  speedSelect($("#ltsSpeed"), "long_to_short");
  $("#ltsBrowse").onclick = async () => { const p = await api().choose_file("video"); if (p) $("#ltsSrc").value = p; };
  $("#ltsOutBtn").onclick = async () => { const p = await api().choose_folder(); if (p) $("#ltsOut").value = p; };
  $("#ltsStop").onclick = () => api().lts_stop();
  $("#ltsStart").disabled = S.lts.running;
  $("#ltsForm").onsubmit = async e => {
    e.preventDefault();
    const opts = { source: $("#ltsSrc").value.trim(), profile: $("#ltsProfile").value, count: +$("#ltsCount").value || 3,
      modes: $$("#ltsModes input:checked").map(i => i.value), out_folder: $("#ltsOut").value.trim(), delete_work: $("#ltsDel").checked,
      subtitles_enabled: $("#ltsSubtitles").checked, output_ratio: $("#ltsRatio").value,
      clip_minutes: $("#ltsMinutes").value === "" ? null : Number($("#ltsMinutes").value) };
    if (!opts.source) return toast("Video ရွေးပါ", true);
    if (!opts.modes.length) return toast("ထုတ်မယ့်ပုံစံ တစ်ခုခု ရွေးပါ", true);
    S.lts.log = []; $("#ltsLog").textContent = "";
    if (await call("lts_start", opts)) { S.lts.running = true; $("#ltsStart").disabled = true; $("#ltsMsg").textContent = "Run နေပါတယ်…"; }
  };
};
EVENTS.lts_log = e => { S.lts.log.push(e.line); if (S.lts.log.length > 800) S.lts.log.shift(); const l = $("#ltsLog"); if (l) { l.textContent += e.line + "\n"; l.scrollTop = 1e9; } };
EVENTS.lts_error = e => { S.lts.running = false; toast(e.message, true); const b = $("#ltsStart"); if (b) b.disabled = false; const m = $("#ltsMsg"); if (m) { m.className = "msg err"; m.textContent = e.message; } };
EVENTS.lts_done = async e => {
  S.lts.running = false; const b = $("#ltsStart"); if (b) b.disabled = false;
  const m = $("#ltsMsg"); if (m) { m.className = "msg ok"; m.textContent = `ပြီးပါပြီ — clip ${e.clips.length} ခု`; }
  toast(`Long to Short ပြီးပါပြီ — clip ${e.clips.length} ခု`);
  if (S.user && S.user.vip_plus && e.clips.length) openSend("long_to_short", { preselect: e.clips });
};

/* ---------------------------------------------------------------- auto posting
   Open the engine dashboard directly. Tools send their finished videos to its category routes (openSend). */
async function apEngine(root) {
  const show = st => {
    const dot = $("#apDot", root); if (!dot) return;
    // running = the engine/dashboard is up; armed = it will also post today (▶ စမယ်)
    dot.style.color = st.armed ? "var(--ok)" : st.running ? "var(--gold)" : "var(--dim)";
    $("#apState", root).textContent = st.armed ? "တင်ပေးနေပါတယ် (run နေ)"
      : st.running ? "Dashboard ဖွင့်ထားပါတယ် — မတင်သေးပါ၊ ▶ စမယ် နှိပ်ပါ" : "ပိတ်ထားပါတယ် — အချိန်ကျလည်း မတင်ပါ";
    $("#apStart", root).disabled = !!st.armed; $("#apStop", root).disabled = !st.running;
  };
  $("#apStart", root).onclick = async () => { $("#apStart", root).disabled = true; $("#apState", root).textContent = "ဖွင့်နေပါတယ်…"; const st = await call("ap_start", true); show(st); if (st.log) toast(st.log, true, 9000); else if (st.running && !st.armed) toast("Engine ဖွင့်ပြီးပေမဲ့ ဒီနေ့အတွက် စမရပါ — Dashboard → Today မှာ ARM နှိပ်ကြည့်ပါ", true, 9000); };
  $("#apStop", root).onclick = async () => { await api().ap_stop(); show({ running: false }); };
  const st = await api().ap_status(); show(st);
  return st;
}
const AP_BAR = `<div class="row ap-bar"><span id="apDot" style="color:var(--dim)">●</span><b id="apState">စစ်နေပါတယ်…</b>
  <button class="btn sm" id="apStart">▶ စမယ်</button><button class="btn danger sm" id="apStop">■ ရပ်မယ်</button></div>`;

PAGES.auto_posting = async (root, arg) => {
  if (!S.user || !S.user.vip_plus) { root.innerHTML = head("Auto Posting") + `<div class="card">Auto Posting က VIP+ member တွေအတွက်ပါ</div>`; return; }
  const tab = arg && arg.tab;
  const list = tab === "all";
  root.innerHTML = head("Auto Posting", `<span class="badge vip">VIP+</span>`) + `
    <div class="row" style="justify-content:space-between">${AP_BAR}
      <button class="pill" id="apView">${list ? "Dashboard" : "List အားလုံး"}</button></div>
    <div id="apBody"></div>`;
  $("#apView", root).onclick = () => go("auto_posting", list ? {} : { tab: "all" });
  const st = await apEngine(root);
  if (S.page !== "auto_posting") return;
  const body = $("#apBody", root);
  if (list) { body.innerHTML = `<div id="apList"></div>`; await apList(); return; }
  body.innerHTML = `<div id="apFrameBox" class="card dim">Auto Posting ကို ဖွင့်နေပါတယ်…</div>`;
  try {
    const ready = st.running ? st : await call("ap_start");
    if (S.page !== "auto_posting") return;
    if (!ready.running) { $("#apFrameBox", root).innerHTML = `<div class="log">${esc(ready.log || "မဖွင့်နိုင်ပါ")}</div>`; return; }
    const url = await api().ap_dashboard_url((arg && arg.category) || "", tab === "accounts" ? "fb" : "");
    if (S.page !== "auto_posting") return;
    $("#apFrameBox", root).outerHTML = `<iframe class="ap-frame" title="Studio99 Auto Posting Dashboard" src="${esc(url)}"></iframe>`;
    await apEngine(root);
  } catch (e) {
    const box = $("#apFrameBox", root);
    if (box) box.innerHTML = `<div class="msg err">${esc(errText(e))}</div>`;
  }
};

PAGES.ap_card = async (root, arg) => {
  if (!S.user || !S.user.vip_plus) { root.innerHTML = head("Auto Posting") + `<div class="card">Auto Posting က VIP+ member တွေအတွက်ပါ</div>`; return; }
  const category = (arg && arg.category) || S.apCard; S.apCard = category;
  const tab = (arg && arg.tab) || "list";
  if (tab === "routes") { await go("auto_posting", { category }); return; }
  const c = await api().ap_card(category);
  root.innerHTML = `<div class="page-head"><div class="crumb"><button data-go="auto_posting">${icon("back")}Auto Posting</button><h1>${esc(c.label)}</h1></div>
      <div class="row">${c.tool ? `<button class="btn sm" id="cSend">📮 Video ထည့်မယ်</button>` : ""}</div></div>
    <div class="row" style="justify-content:space-between">${AP_BAR}
      <div class="tabs"><button class="pill ${tab === "list" ? "on" : ""}" data-ctab="list">စောင့်နေတဲ့ video (${c.items.filter(i => i.status !== "posted").length})</button>
        <button class="pill ${tab === "routes" ? "on" : ""}" data-ctab="routes">Page / အချိန် (${c.routes_on || 0})</button></div></div>
    <div id="cBody"></div>`;
  $$("[data-ctab]", root).forEach(b => b.onclick = () => go("ap_card", { category, tab: b.dataset.ctab }));
  if ($("#cSend")) $("#cSend").onclick = () => openSend(c.tool, { after: () => go("ap_card", { category }) });
  const st = await apEngine(root);
  const body = $("#cBody");
  const status = it => ({ queued: "စောင့်နေ", posting: "တင်နေဆဲ", posted: "✓ တင်ပြီး" }[it.status] || it.status || "")
    + (Object.keys(it.done || {}).length && it.status !== "posted" ? ` · ${Object.keys(it.done).length} page ပြီး` : "")
    + (Object.keys(it.failed || {}).length ? " · ⚠️ " + Object.values(it.failed).join(", ") : "") + (it.deleted ? " · ဖိုင်ဖျက်ပြီး" : "")
    + (!it.exists && !it.deleted ? " · ⚠️ ဖိုင် မရှိတော့" : "");
  body.innerHTML = `${c.routes_on ? "" : `<div class="card" style="color:var(--gold);line-height:1.8">ဒီကတ်မှာ Page မရွေးရသေးပါ — <a href="#" id="toRoutes">Page / အချိန်</a> မှာ Route ထည့်ပြီး ဖွင့်ပါ။ အခု ထည့်ထားတဲ့ video တွေက ဖွင့်ပြီးတာနဲ့ တင်ပါမယ်။</div>`}
    <div class="card"><table class="list"><thead><tr><th></th><th>Video / Caption</th><th>Post to</th><th>When</th><th>Status</th></tr></thead><tbody>
    ${c.items.map(it => `<tr><td><input type="checkbox" data-id="${esc(it.id)}"></td><td><b>${esc(it.caption)}</b><div class="dim">${it.kind === "photo" ? "📷 ပုံ + စာ post (Facebook) · " : "🎬 "}${esc(it.name)}</div></td>
      <td>${esc(it.target_names.join(", ") || "Page အားလုံး")}</td><td>${esc(it.post_at || (it.posted ? it.posted : "နောက်အချိန်"))}</td><td>${esc(status(it))}</td></tr>`).join("")
      || `<tr><td colspan="5" class="dim">ဘာမှ မရှိသေးပါ — ${c.tool ? "အပေါ်က 📮 Video ထည့်မယ် (ဒါမှမဟုတ် tool ထဲက 📮 Auto Posting ပို့မယ်)" : "Tool တွေကနေ ပို့ပါ"}</td></tr>`}
    </tbody></table><div class="row" style="margin-top:12px"><button class="btn ghost sm" id="apRemove">ရွေးထားတာ ဖယ်မယ်</button></div></div>`;
  if ($("#toRoutes")) $("#toRoutes").onclick = e => { e.preventDefault(); go("ap_card", { category, tab: "routes" }); };
  $("#apRemove").onclick = async () => { const ids = $$("#cBody [data-id]:checked").map(x => x.dataset.id); if (ids.length) { await api().ap_remove(ids); go("ap_card", { category }); } };
};

async function apList() {
  const items = await api().ap_list();
  const status = it => ({ queued: "စောင့်နေ", posting: "တင်နေဆဲ", posted: "✓ တင်ပြီး" }[it.status] || "") + (Object.keys(it.done || {}).length ? ` · ${Object.keys(it.done).length} page` : "")
    + (Object.keys(it.failed || {}).length ? " · ⚠️ " + Object.values(it.failed).join(", ") : "") + (it.deleted ? " · ဖိုင်ဖျက်ပြီး" : "");
  $("#apList").innerHTML = `<div class="card"><table class="list"><thead><tr><th></th><th>Video / Caption</th><th>ကတ်</th><th>Post to</th><th>When</th><th>Status</th></tr></thead><tbody>
    ${items.map(it => `<tr><td><input type="checkbox" data-id="${esc(it.id)}"></td><td><b>${esc(it.caption)}</b><div class="dim">${esc(it.name)}</div></td><td>${esc(it.kind)}</td>
      <td>${esc(it.target_names.join(", ") || "Page အားလုံး")}</td><td>${esc(it.post_at || "next slot")}</td><td>${esc(status(it))}</td></tr>`).join("") || `<tr><td colspan="6" class="dim">List ထဲ ဘာမှ မရှိသေးပါ</td></tr>`}
    </tbody></table><div class="row" style="margin-top:12px"><button class="btn ghost sm" id="apRemove">ရွေးထားတာ ဖယ်မယ်</button></div></div>`;
  $("#apRemove").onclick = async () => { const ids = $$("#apList [data-id]:checked").map(x => x.dataset.id); if (ids.length) { await api().ap_remove(ids); apList(); } };
}

/* "📮 Auto Posting ပို့မယ်": a tool's finished videos → its card. opts.preselect = videos ticked first (just made);
   opts.where = row => true for rows ticked first (a novel's parts, one review);
   opts.after = called once sent; opts.onClose = called when the dialog closes (toolwin shows its tool again). */
async function openSend(tool, opts = {}) {
  if (!S.user || !S.user.vip_plus) return toast("Auto Posting က VIP+ member တွေအတွက်ပါ — Profile မှာ ကြည့်ပါ", true);
  const [card, found] = await Promise.all([api().ap_tool_card(tool), api().ap_candidates(tool)]);
  const posts = tool === "novel" || tool === "movie_review";      // posts made from the tool's own files
  const pre = new Set(opts.preselect || []), where = opts.where || (() => false);
  const rows = found.slice();
  for (const v of pre) if (!rows.some(r => r.video === v)) rows.unshift({ video: v, caption: v.split(/[\\/]/).pop().replace(/\.[^.]+$/, ""), at: "", state: "" });
  const stateText = { waiting: "ကတ်ထဲ ရှိပြီး", posted: "✓ တင်ပြီးသား" };
  const rowHtml = r => `<label class="send-row ${r.state ? "off" : ""}"><input type="checkbox" data-v="${esc(r.video)}" ${r.state ? "disabled" : pre.has(r.video) || where(r) ? "checked" : ""}>
      <span class="grow"><input class="input sm" data-cap="${esc(r.video)}" value="${esc(r.caption)}" ${r.state || r.fixed ? "disabled" : ""}><span class="dim">${r.fixed ? esc(r.label || "") : esc(r.video.split(/[\\/]/).pop())}${r.at ? " · " + esc(r.at) : ""}</span></span>
      ${r.state ? `<span class="badge soon">${stateText[r.state]}</span>` : ""}</label>`;
  const box = modal(`<h2>📮 Auto Posting — ${esc(card.label)} ကတ်</h2>
    <div class="dim" style="font-size:12.5px">${posts ? `ရွေးထားတာတွေကို ${esc(card.label)} ကတ်ထဲ ထည့်ပါမယ် — ${tool === "novel" ? "အပိုင်းတိုင်း Facebook Page မှာ cover ပုံ + အဲ့အပိုင်းရဲ့ စာနဲ့ post တစ်ခု (Part 1 ကစပြီး)" : "Facebook Page မှာ thumbnail + review စာ post၊ ပြီးရင် Reel (Facebook Reel + TikTok)"}။ ပုံ+စာ post က Facebook Page မှာပဲ တက်ပါတယ်။`
      : `ရွေးထားတဲ့ video တွေကို ${esc(card.label)} ကတ်ထဲ ထည့်ပါမယ် (အောက်ကနေ အစဉ်လိုက် — အဟောင်းဆုံး အရင် — တင်ပါတယ်)။ Caption ကို ပြင်လို့ရပါတယ်။`}</div>
    <div class="row"><button class="btn ghost sm" id="sAll">အသစ်တွေ အကုန်ရွေး</button>${posts ? "" : `<button class="btn ghost sm" id="sFiles">${icon("folder")}ဖိုင် ကိုယ်တိုင်ရွေး</button>`}<span class="spacer"></span><b id="sCount" style="color:var(--gold)"></b></div>
    <div class="send-list" id="sList">${rows.map(rowHtml).join("") || `<div class="dim">ဒီ tool က video မထုတ်ရသေးပါ (သို့) မတွေ့ပါ — "ဖိုင် ကိုယ်တိုင်ရွေး" နဲ့ ထည့်ပါ</div>`}</div>
    <div class="field">ဘယ် Page တွေကို တင်မလဲ${card.routes.length ? card.routes.map(r => `<label class="check"><input type="checkbox" data-route="${esc(r.id)}" ${r.enabled ? "checked" : ""}>${esc(r.label)} <span class="dim">${esc(r.where)} · ${r.daily}/ရက်${r.enabled ? "" : " · ပိတ်ထား"}</span></label>`).join("")
      : `<div style="color:var(--gold);line-height:1.8">ဒီကတ်မှာ Page မရွေးရသေးပါ — Auto Posting dashboard → ${esc(card.label)} → Edit Routes မှာ ထည့်ပါ။ အခု ထည့်ထားရင် ဖွင့်ပြီးတာနဲ့ တင်ပါမယ်။</div>`}</div>
    <label class="field">ဒီအချိန်နောက်မှ (မထည့်ရင် Page ရဲ့ နောက်အချိန်)<input class="input" id="sAt" placeholder="2026-10-25 20:30"></label>
    <label class="check"><input type="checkbox" id="sDel">Page အားလုံး တင်ပြီးရင် video ဖိုင်ကို ဖျက်မယ် (storage)</label>
    <div class="row"><button class="btn" id="sGo">📮 ပို့မယ်</button><button class="btn ghost" id="sNo">မပို့တော့ဘူး</button></div>`);
  box.classList.add("wide");
  const count = () => { $("#sCount", box).textContent = `${$$("[data-v]:checked", box).length} ခု ရွေးထား`; };
  const bindRows = () => $$("[data-v]", box).forEach(x => x.onchange = count);
  bindRows(); count();
  const done = () => { box.classList.remove("wide"); closeModal(); if (opts.onClose) opts.onClose(); };
  $("#sNo", box).onclick = done;
  $("#sAll", box).onclick = () => { $$("[data-v]:not(:disabled)", box).forEach(x => x.checked = true); count(); };
  if ($("#sFiles", box)) $("#sFiles", box).onclick = async () => {
    const files = await api().choose_files("video"); if (!files.length) return;
    const list = $("#sList", box); if (!list.querySelector("[data-v]")) list.innerHTML = "";
    for (const f of files) {
      if (list.querySelector(`[data-v="${CSS.escape(f)}"]`)) { list.querySelector(`[data-v="${CSS.escape(f)}"]`).checked = true; continue; }
      list.insertAdjacentHTML("afterbegin", rowHtml({ video: f, caption: f.split(/[\\/]/).pop().replace(/\.[^.]+$/, ""), at: "", state: "" }));
      list.querySelector(`[data-v="${CSS.escape(f)}"]`).checked = true;
    }
    bindRows(); count();
  };
  $("#sGo", box).onclick = async () => {
    const picked = $$("[data-v]:checked", box).map(x => x.dataset.v);
    if (!picked.length) return toast("Video တစ်ခုခု ရွေးပါ", true);
    const caps = Object.fromEntries($$("[data-cap]", box).map(x => [x.dataset.cap, x.value.trim()]));
    // the list shows newest first; posting goes oldest first (Splitter: part 1 before part 2)
    const ordered = picked.slice().reverse().map(v => ({ video: v, caption: caps[v] || "" }));
    const all = $$("[data-route]", box), on = all.filter(x => x.checked).map(x => x.dataset.route);
    // none ticked while no route is on yet = every route of the card (the ones switched on later too)
    if (card.routes.some(r => r.enabled) && !on.length) return toast("Page တစ်ခုခု ရွေးပါ", true);
    const at = $("#sAt", box).value.trim();
    if (at && !/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(at)) return toast("အချိန်ကို 2026-10-25 20:30 ပုံစံနဲ့ ရေးပါ", true);
    try {
      const enabled = card.routes.filter(r => r.enabled).map(r => r.id);
      const asCard = !on.length || on.length === all.length || (on.length === enabled.length && on.every(x => enabled.includes(x)));
      const targets = asCard ? [] : on;          // [] = the card's routes, also ones switched on later
      const r = await api().ap_send(tool, ordered, targets, at, $("#sDel", box).checked);
      done();
      toast(`${card.label} ကတ်ထဲ ${r.added} ခု ထည့်ပြီးပါပြီ` + (r.skipped.length ? ` · ${r.skipped.length} ခု ရှိပြီး/တင်ပြီးသားမို့ ကျော်ခဲ့` : ""));
      if (opts.after) opts.after(r);
    } catch (x) { toast(errText(x), true); }
  };
}

async function askPost(video, title, origin) {
  const d = await api().ap_destinations(origin);
  const box = modal(`<h2>Auto Posting list ထဲ ထည့်မလား?</h2><div class="dim">${esc(video.split(/[\\/]/).pop())}</div>
    <label class="field">Caption<input class="input" id="pCap" value="${esc(title)}"></label>
    <div class="field">ဘယ် Page တွေကို တင်မလဲ (${esc(d.label)})${d.routes.length ? d.routes.map(r => `<label class="check"><input type="checkbox" data-route="${esc(r.id)}" checked>${esc(r.label)} <span class="dim">${esc(r.where)} · ${r.daily}/ရက်</span></label>`).join("")
      : `<div style="color:var(--gold);line-height:1.8">တင်မယ့် Page မရှိသေးပါ — Auto Posting dashboard → ${esc(d.label)} → Edit Routes မှာ ထည့်ပါ။ အခု ထည့်ထားရင် ဖွင့်ပြီးတာနဲ့ တင်ပါမယ်။</div>`}</div>
    <label class="field">ဒီအချိန်နောက်မှ (မထည့်ရင် Page ရဲ့ နောက်အချိန်) <input class="input" id="pAt" placeholder="2026-10-20 20:30"></label>
    <label class="check"><input type="checkbox" id="pDel">Page အားလုံး တင်ပြီးရင် ဒီ video ဖိုင်ကို ဖျက်မယ် (storage)</label>
    <div class="row"><button class="btn" id="pAdd">ထည့်မယ်</button><button class="btn ghost" id="pNo">မထည့်ဘူး</button></div>`);
  $("#pNo", box).onclick = closeModal;
  $("#pAdd", box).onclick = async () => {
    const all = $$("[data-route]", box), on = all.filter(x => x.checked).map(x => x.dataset.route);
    if (all.length && !on.length) return toast("Page တစ်ခုခု ရွေးပါ", true);
    const at = $("#pAt", box).value.trim();
    if (at && !/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(at)) return toast("အချိန်ကို 2026-10-20 20:30 ပုံစံနဲ့ ရေးပါ", true);
    await call("ap_add", video, $("#pCap", box).value, on.length === all.length ? [] : on, at, origin, $("#pDel", box).checked);
    closeModal(); toast("Posting list ထဲ ထည့်ပြီးပါပြီ");
  };
}

/* ---------------------------------------------------------------- novel (web_novel.py) */
const NV = { log: [] };
PAGES.novel = async (root) => {
  const o = await api().novel_api("options", {}), s = o.saved || {};
  root.innerHTML = head("Novel", `<span class="badge free">Free</span>`) + `
  <div class="split"><form class="card" id="nvForm" style="flex:1 1 360px;max-width:440px;display:flex;flex-direction:column;gap:16px;align-self:flex-start">
    <div class="dim" style="font-size:13px;line-height:1.8">မြန်မာဝတ္ထု ၄ ပိုင်း (တစ်ပိုင်း ~၅,၀၀၀ လုံး) + အပိုင်းတိုင်း cover ပုံ။ ${o.fal ? "Cover ကို FAL နဲ့ ထုတ်ပါမယ်။" : "FAL key မရှိလို့ cover ကို ကိုယ့်စက်မှာ ထုတ်ပါမယ်။"}</div>
    <label class="field">အမျိုးအစား<select class="input" id="nvGenre">${o.genres.map(g => `<option>${esc(g)}</option>`).join("")}</select></label>
    <label class="field">ဇာတ်လမ်း အကျဉ်း (မရေးလည်းရ)<textarea class="input" id="nvSyn" rows="4"></textarea></label>
    <label class="field">Part 1 တင်မယ့်ရက် (မထည့်ရင် ဒီနေ့)<input class="input" id="nvDate" type="date"></label>
    <label class="check"><input type="checkbox" id="nvPages" ${s.pages ? "checked" : ""}>9:16 စာမျက်နှာ ပုံတွေပါ ထုတ်မယ် (Story / Reel အတွက်)</label>
    <div class="row"><button class="btn" type="submit" id="nvStart">✍️ ဝတ္ထု ရေးမယ်</button><button class="btn danger" type="button" id="nvStop">ရပ်မယ်</button></div>
    <div class="log" id="nvLog" style="max-height:260px;min-height:120px"></div>
  </form><section class="main" id="nvList" style="display:flex;flex-direction:column;gap:14px"></section></div>`;
  if (s.genre) $("#nvGenre").value = s.genre;
  $("#nvLog").textContent = NV.log.join("\n");
  $("#nvStart").disabled = o.running;
  $("#nvStop").onclick = () => api().novel_api("stop", {});
  $("#nvForm").onsubmit = async e => {
    e.preventDefault();
    NV.log = []; $("#nvLog").textContent = "";
    $("#nvStart").disabled = true;
    try { if (await api().novel_api("start", { genre: $("#nvGenre").value, synopsis: $("#nvSyn").value.trim(), start_date: $("#nvDate").value, pages: $("#nvPages").checked })) $("#nvStart").disabled = true; }
    catch (x) { $("#nvStart").disabled = false; toast(errText(x), true); }
  };
  nvRender(o.series);
};
function nvRender(series) {
  const box = $("#nvList"); if (!box) return;
  box.innerHTML = series.length ? series.map(s => `<article class="card" style="display:flex;flex-direction:column;gap:12px">
      <div class="row" style="justify-content:space-between"><b style="font-size:17px">${esc(s.title)}</b><div class="row">${S.user && S.user.vip_plus ? `<button class="btn sm" data-nvpost="${esc(s.folder)}">📮 Auto Posting ပို့မယ်</button>` : ""}<button class="btn ghost sm" data-open="${esc(s.folder)}">${icon("folder")}Folder</button></div></div>
      <div class="grid3" style="grid-template-columns:repeat(4,minmax(0,1fr))">${s.parts.map(p => `<div style="display:flex;flex-direction:column;gap:8px">
        <div class="thumb" data-cover="${esc(p.cover)}" style="aspect-ratio:4/5"></div>
        <div class="dim" style="font-size:12px">Part ${p.n} · ${p.chars} လုံး</div>
        <button class="btn ghost sm" data-copytext="${esc(p.text)}">${icon("copy")}စာ copy</button></div>`).join("")}</div></article>`).join("")
    : `<div class="card dim">ဝတ္ထု မရှိသေးပါ — ဘယ်ဘက်က ရွေးပြီး ရေးခိုင်းပါ</div>`;
  bindDownloads(box);
  $$("[data-nvpost]", box).forEach(b => b.onclick = () => openSend("novel", { where: r => (r.text_file || "").startsWith(b.dataset.nvpost) }));
  $$("[data-copytext]", box).forEach(b => b.onclick = async () => { await navigator.clipboard.writeText(await api().novel_api("text", { path: b.dataset.copytext })); toast("Post စာ copy ပြီးပါပြီ"); });
  $$("[data-cover]", box).forEach(async el => { if (el.dataset.cover) { const u = await api().novel_api("cover", { path: el.dataset.cover }); if (u) el.style.backgroundImage = `url('${u}')`; } });
}
EVENTS.novel_log = e => { NV.log.push(e.line); if (NV.log.length > 600) NV.log.shift(); const l = $("#nvLog"); if (l) { l.textContent += e.line + "\n"; l.scrollTop = 1e9; } };
EVENTS.novel_error = e => { toast(e.message, true); const b = $("#nvStart"); if (b) b.disabled = false; };
EVENTS.novel_done = e => { toast("ဝတ္ထု ၄ ပိုင်း ရပါပြီ"); const b = $("#nvStart"); if (b) b.disabled = false; if (S.page === "novel") nvRender(e.series); };

/* ---------------------------------------------------------------- movie review (web_review.py) */
const RV = { log: [] };
PAGES.movie_review = async (root) => {
  if (!S.user || !S.user.vip_plus) { root.innerHTML = head("Movie Review") + `<div class="card">Movie Review က VIP+ member တွေအတွက်ပါ</div>`; return; }
  const o = await api().review_api("options", {}), s = o.saved || {};
  root.innerHTML = head("Movie Review", `<span class="badge vip">VIP+</span>`) + `
  <div class="split"><form class="card" id="rvForm" style="flex:1 1 360px;max-width:440px;display:flex;flex-direction:column;gap:16px;align-self:flex-start">
    <div class="dim" style="font-size:13px;line-height:1.8">ဇာတ်ကား review post (မြန်မာ) + thumbnail + trailer နဲ့ review Reel။ ဇာတ်ကားနာမည် မထည့်ရင် လောလောဆယ် ခေတ်စားနေတဲ့ ဇာတ်ကားကို အလိုလို ရွေးပါမယ်။</div>
    <div class="grid2" style="grid-template-columns:2fr 1fr"><label class="field">ဇာတ်ကားနာမည် (English)<input class="input" id="rvTitle" placeholder="The Matrix"></label>
      <label class="field">ခုနှစ်<input class="input" id="rvYear" type="number" placeholder="1999"></label></div>
    <label class="field">အမျိုးအစား<select class="input" id="rvProfile">${o.profiles.map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join("")}</select></label>
    <label class="check"><input type="checkbox" id="rvVideo" checked>Review Reel (video) ပါ ထုတ်မယ်</label>
    <label class="check"><input type="checkbox" id="rvOwnVoice" ${s.own_voice ? "checked" : ""}>ကိုယ်ပိုင်အသံသွင်းမယ် — script ရပြီးရင် အသံသွင်းခန်း ဖွင့်ပေးမယ်</label>
    <label class="check"><input type="checkbox" id="rvFal" ${o.fal ? (s.fal ? "checked" : "") : "disabled"}>FAL နဲ့ ပုံလှလှ ထုတ်မယ် ${o.fal ? "" : "(Profile မှာ FAL key ထည့်မှ)"}</label>
    <label class="check"><input type="checkbox" id="rvSpoil" ${s.spoilers ? "checked" : ""}>ဇာတ်ဆုံးပိုင်း (spoilers) ပါ ပြောမယ်</label>
    <label class="check"><input type="checkbox" id="rvForce">လုပ်ပြီးသား ဇာတ်ကားဖြစ်ရင်လည်း ပြန်လုပ်မယ်</label>
    <div class="row"><button class="btn" type="submit" id="rvStart">🎬 Review ထုတ်မယ်</button><button class="btn danger" type="button" id="rvStop">ရပ်မယ်</button></div>
    <div class="log" id="rvLog" style="max-height:260px;min-height:120px"></div>
  </form><section class="main" id="rvList" style="display:flex;flex-direction:column;gap:14px"></section></div>`;
  if (s.profile) $("#rvProfile").value = s.profile;
  $("#rvLog").textContent = RV.log.join("\n");
  $("#rvStart").disabled = o.running;
  $("#rvStop").onclick = () => api().review_api("stop", {});
  $("#rvForm").onsubmit = async e => {
    e.preventDefault();
    RV.log = []; $("#rvLog").textContent = "";
    const p = { title: $("#rvTitle").value.trim(), year: +$("#rvYear").value || 0, profile: $("#rvProfile").value, video: $("#rvVideo").checked,
      fal: $("#rvFal").checked, spoilers: $("#rvSpoil").checked, force: $("#rvForce").checked, own_voice: $("#rvOwnVoice").checked };
    $("#rvStart").disabled = true;
    try { await api().review_api("start", p); } catch (x) { $("#rvStart").disabled = false; toast(errText(x), true); }
  };
  rvRender(o.results);
};
function rvRender(list) {
  const box = $("#rvList"); if (!box) return;
  box.innerHTML = list.length ? list.map(r => `<article class="card" style="display:flex;gap:16px;flex-wrap:wrap;padding:16px">
      <div class="thumb" data-img="${esc(r.thumbnail)}" style="flex:0 0 260px"></div>
      <div style="flex:1 1 260px;display:flex;flex-direction:column;gap:10px"><b style="font-size:16px">${esc(r.title)}</b>
        <div class="row">${r.post ? `<button class="btn ghost sm" data-copypost="${esc(r.post)}">${icon("copy")}Post စာ copy</button>` : ""}
          <button class="btn ghost sm" data-open="${esc(r.video || r.folder)}">${icon("folder")}Folder</button>
          ${r.post && S.user && S.user.vip_plus ? `<button class="btn ghost sm" data-post="${esc(r.folder)}">📮 Auto Posting</button>` : ""}</div></div></article>`).join("")
    : `<div class="card dim">Review မရှိသေးပါ</div>`;
  bindDownloads(box);
  $$("[data-copypost]", box).forEach(b => b.onclick = async () => { await navigator.clipboard.writeText(await api().review_api("text", { path: b.dataset.copypost })); toast("Post စာ copy ပြီးပါပြီ"); });
  $$("[data-post]", box).forEach(b => b.onclick = () => openSend("movie_review", { where: r => (r.manifest || "").startsWith(b.dataset.post) }));
  $$("[data-img]", box).forEach(async el => { if (el.dataset.img) { const u = await api().review_api("image", { path: el.dataset.img }); if (u) el.style.backgroundImage = `url('${u}')`; } });
}
EVENTS.review_log = e => { RV.log.push(e.line); if (RV.log.length > 600) RV.log.shift(); const l = $("#rvLog"); if (l) { l.textContent += e.line + "\n"; l.scrollTop = 1e9; } };
EVENTS.review_error = e => { toast(e.message, true); const b = $("#rvStart"); if (b) b.disabled = false; };
EVENTS.review_done = e => { toast("Movie Review ရပါပြီ"); const b = $("#rvStart"); if (b) b.disabled = false; if (S.page === "movie_review") rvRender(e.results); };

/* ---------------------------------------------------------------- a tool window inside this window
   Recap / Splitter (tk_tool.py) and Dubbing / Subtitle / Original→Recap (tool_apps.py) keep their own process; the
   backend lays their window over #toolHost (physical pixels) and hides it while another page is shown. */
const TW = { id: "", obs: null, timer: 0 };
function toolRect() {
  const h = $("#toolHost"); if (!h) return null;
  const r = h.getBoundingClientRect(), k = window.devicePixelRatio || 1;
  return { x: Math.round((r.left + 1) * k), y: Math.round((r.top + 1) * k), w: Math.round((r.width - 2) * k), h: Math.round((r.height - 2) * k) };
}
function toolwinStop() {
  if (TW.obs) TW.obs.disconnect();
  window.removeEventListener("resize", toolwinResize);
  TW.obs = null;
}
function toolwinResize() {
  clearTimeout(TW.timer);
  TW.timer = setTimeout(() => { const r = toolRect(); if (r && S.page === "toolwin") api().tool_rect(TW.id, r).catch(() => {}); }, 60);
}
PAGES.toolwin = async (root, arg) => {
  arg = arg || { tool: TW.id, title: TW.title };
  TW.id = arg.tool; TW.title = arg.title;
  root.innerHTML = `<div class="page-head"><div class="crumb"><button data-go="home">${icon("back")}Home</button><h1>${esc(arg.title)}</h1></div>
    <div class="row">${SPEED_TOOLS.includes(arg.tool) ? `<label class="dim" style="font-size:12px;display:flex;gap:6px;align-items:center" title="Video encode အမြန်နှုန်း — စက်နိမ့်ရင် မြန် / အမြန်ဆုံး ရွေးပါ (အရွယ်အစား မပြောင်းပါ)">⚡<select class="input sm" id="twSpeed" style="width:auto"></select></label>` : ""}
      <button class="btn sm" id="twSend" title="ဒီ tool က ပြီးတဲ့ video တွေကို Auto Posting ကတ်ထဲ ပို့မယ်">📮 Auto Posting ပို့မယ်</button>
      <button class="btn ghost sm" id="twOut" title="ကိုယ်ပိုင် window နဲ့ ခွဲဖွင့်မယ်">↗ သီးသန့် window</button>
      <button class="btn ghost sm" id="twClose">■ ပိတ်မယ်</button></div></div>` +
    `<div class="toolhost" id="toolHost"><span class="spin"></span><div id="twMsg">${esc(arg.title)} ကို ဖွင့်နေပါတယ်…</div></div>`;
  fillIcons(root); bindGo(root);
  const show = async () => {
    const r = toolRect(); if (!r) return;
    try {
      const res = await api().tool_show(TW.id, r);
      if (S.page !== "toolwin" || TW.id !== arg.tool) return;
      if (res.detached) {
        $("#twOut").classList.add("hidden");
        $("#toolHost").innerHTML = `<div>${esc(arg.title)} ကို သီးသန့် window နဲ့ ဖွင့်ထားပါတယ် (taskbar)</div>
          <button class="btn sm" id="twIn">↙ ဒီထဲ ပြန်ထည့်မယ်</button>`;
        $("#twIn").onclick = async () => { await api().tool_attach(TW.id, toolRect()); go("toolwin", arg); };
      } else if (!res.ok) { $("#twMsg").textContent = res.message; $(".toolhost .spin")?.remove(); }
    } catch (e) { toast(errText(e), true); }
  };
  $("#twOut").onclick = async () => { await api().tool_detach(TW.id); go("toolwin", arg); };
  if ($("#twSend") && $("#twSpeed")) speedSelect($("#twSpeed"), arg.tool);
  $("#twSend").onclick = async () => {          // an HTML dialog would sit under the tool window: hide it meanwhile
    if (!S.user || !S.user.vip_plus) return toast("Auto Posting က VIP+ member တွေအတွက်ပါ — Profile မှာ ကြည့်ပါ", true);
    await api().tools_hide();
    const back = () => { if (S.page === "toolwin" && TW.id === arg.tool) { const r = toolRect(); if (r) api().tool_show(TW.id, r); } };
    try { await openSend(arg.tool, { onClose: back }); } catch (x) { toast(errText(x), true); back(); }
  };
  $("#twClose").onclick = async () => {      // a native confirm: an HTML modal would sit under the tool window
    if (!confirm(`${arg.title} ကို ပိတ်မလား?
အလုပ် လုပ်နေတာ ရှိရင် ရပ်သွားပါမယ်။`)) return;
    await api().tool_close(TW.id); go("home");
  };
  toolwinStop();
  TW.obs = new ResizeObserver(toolwinResize); TW.obs.observe($("#toolHost"));
  window.addEventListener("resize", toolwinResize);
  setTimeout(show, 30);
};

/* ---------------------------------------------------------------- downloads the app does by itself (ai_extras.py)
   AI extras (torch) on the first Dubbing / Original→Recap; FFmpeg only when the installed copy is missing. */
function chip(text, percent, err) {
  const c = $("#dlChip"); if (!c) return;
  c.classList.toggle("hidden", text == null); c.classList.toggle("err", !!err);
  $("#dlChipT").textContent = text || ""; $("#dlChipBar").style.width = (percent || 0) + "%";
}
function aiProfile(s) {
  const v = $("#cAi"); if (!v) return;
  v.innerHTML = s.installed ? `<b style="color:var(--ok)">● ရှိပြီး</b>` : s.running ? `${s.percent}% — ${esc(s.message)}`
    : s.error ? `<b style="color:var(--bad)">${esc(s.error)}</b>` : `မရှိသေး (${s.size_gb} GB${s.gpu ? ", GPU" : ", CPU"})`;
  const row = $("#aiRow"); if (!row) return;
  row.innerHTML = s.installed ? "" : s.running ? `<button class="btn ghost sm" id="aiStop">ရပ်မယ်</button>`
    : `<button class="btn ghost sm" id="aiGo">ဒေါင်းမယ်</button>`;
  const go_ = $("#aiGo"); if (go_) go_.onclick = async () => aiProfile(await api().ai_install());
  const st = $("#aiStop"); if (st) st.onclick = () => api().ai_stop();
}
EVENTS.ai = s => {
  aiProfile(s);
  if (s.running) chip(`AI extras ${s.percent}% · ${s.message}`, s.percent);
  else if (s.installed) { chip(null); toast("AI extras ရပါပြီ — နောက် video ကစပြီး နောက်ခံသံ / smooth motion သုံးပါမယ်"); }
  else if (s.error) { chip("AI extras မရပါ — Profile မှာ ပြန်ဒေါင်းပါ", 0, true); toast(s.error, true, 9000); }
};
EVENTS.ffmpeg = e => {
  if (e.error) { chip("FFmpeg မရှိပါ", 0, true); toast(e.error, true, 12000); }
  else if (e.done) { chip(null); toast(e.message); }
  else chip(`${e.message} ${e.percent}%`, e.percent);
};

/* Encode speed of the copied tools (ffmpeg_speed.py): their own frame size and timing stay; only H.264 gets faster.
   Applies to the next FFmpeg call, no restart needed. */
const SPEED_TOOLS = ["dubbing", "subtitle", "storytelling"];
async function speedSelect(select, tool) {
  const s = await api().tool_speed(tool);
  select.innerHTML = Object.entries(s.labels).map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join("");
  select.value = s.level;
  select.onchange = async () => { await api().tool_speed_set(tool, select.value); toast(`Encode အမြန်နှုန်း: ${s.labels[select.value]}`); };
}
