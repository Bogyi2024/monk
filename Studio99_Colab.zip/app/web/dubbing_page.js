/* Browser-native Colab UI for Studio99 Dubbing (Edge / Gemini / VoxCPM2 48kHz + Auto Male/Female). */
(() => {
  const q = (s, root = document) => root.querySelector(s);
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const api = () => window.pywebview.api;
  let opts = null;
  let sourcePath = '';
  let pollTimer = 0;

  const sel = (label, id, items, val) =>
    `<label class="field">${label}<select class="input" id="${id}">${items.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(val) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`;

  function payload() {
    return {
      source_path: (q('#dbPath')?.value || sourcePath || '').trim(),
      source_language: q('#dbLang').value,
      my_provider: q('#dbMyProv').value,
      my_voice: q('#dbMyVoice').value,
      my_gender_split: q('#dbMySplit').checked,
      my_female_voice: q('#dbMyFemale').value,
      my_rate_percent: Number(q('#dbMyRate').value) || 0,
      my_style: q('#dbStyle').value.trim(),
      my_ref_audio: q('#dbMyRef').value.trim(),
      en_provider: q('#dbEnProv').value,
      en_voice: q('#dbEnVoice').value,
      en_gender_split: q('#dbEnSplit').checked,
      en_female_voice: q('#dbEnFemale').value,
      en_rate_percent: Number(q('#dbEnRate').value) || 0,
      en_ref_audio: q('#dbEnRef').value.trim(),
      quality: q('#dbQuality').value,
      whisper_model: q('#dbWhisper').value,
      mirror_video: q('#dbMirror').checked,
      blur_original_subtitles: q('#dbBlur').checked,
      burn_custom_subtitles: q('#dbBurn').checked,
      subtitle_font_size: Number(q('#dbFontSize').value) || 64,
      subtitles: q('#dbSoftSub').checked,
      resume: q('#dbResume').checked,
      output_dir: q('#dbOutDir').value.trim(),
    };
  }

  function mount(root) {
    const d = opts.defaults || {};
    root.innerHTML = `<div class="page-head"><div class="crumb"><button data-go="home">‹ Home</button><h1>Dubbing · Colab</h1></div><span class="badge vip">VIP</span></div>
      <div class="profile-grid" style="grid-template-columns:minmax(310px,.95fr) minmax(0,1.05fr);max-width:none">
        <section class="card" style="display:flex;flex-direction:column;gap:11px">
          <div class="row" style="justify-content:space-between"><b>Video & Dubbing Settings</b><span class="dim">${opts.cuda ? 'CUDA GPU ready' : 'CPU mode'}</span></div>
          <div class="row">
            <button class="btn sm" id="dbUpload">Upload Video</button>
            <input class="input" id="dbPath" style="flex:1" placeholder="/content/drive/MyDrive/video.mp4" value="${esc(sourcePath)}">
          </div>
          <div class="dim" id="dbUploadState"></div>
          <div class="profile-grid" style="grid-template-columns:1fr 1fr;gap:10px">
            ${sel('Source Language', 'dbLang', opts.languages, d.source_language)}
            ${sel('Quality', 'dbQuality', opts.qualities, d.quality)}
            ${sel('Whisper Model', 'dbWhisper', opts.whisper_models, d.whisper_model)}
            <label class="field">Subtitle Font Size<input class="input" id="dbFontSize" type="number" min="24" max="120" value="${Number(d.subtitle_font_size) || 64}"></label>
          </div>
          <div class="profile-grid" style="grid-template-columns:1fr 1fr;gap:10px">
            ${sel('Myanmar Provider', 'dbMyProv', opts.providers, d.my_provider)}
            ${sel('Myanmar Main/Male Voice', 'dbMyVoice', opts.my_voices, d.my_voice)}
            <div class="field">Auto Male/Female (MY)<label class="check"><input id="dbMySplit" type="checkbox" ${d.my_gender_split !== false ? 'checked' : ''}> ကျား/မ အသံခွဲမယ်</label></div>
            ${sel('Myanmar Female Voice', 'dbMyFemale', opts.my_voices, d.my_female_voice || 'my-MM-NilarNeural')}
            <label class="field">Myanmar Speed (%)<input class="input" id="dbMyRate" type="number" min="-50" max="100" value="${Number(d.my_rate_percent ?? 35)}"></label>
            <label class="field">VoxCPM2 MY Ref Audio (Clone)<div class="row"><input class="input" id="dbMyRef" style="flex:1" placeholder="Optional 3-10s WAV/MP3" value="${esc(d.my_ref_audio || '')}"><button class="btn ghost sm" type="button" id="dbMyRefUp">Upload</button></div></label>
          </div>
          <div class="profile-grid" style="grid-template-columns:1fr 1fr;gap:10px">
            ${sel('English Provider', 'dbEnProv', opts.providers, d.en_provider)}
            ${sel('English Main/Male Voice', 'dbEnVoice', opts.en_voices, d.en_voice)}
            <div class="field">Auto Male/Female (EN)<label class="check"><input id="dbEnSplit" type="checkbox" ${d.en_gender_split !== false ? 'checked' : ''}> Split Male/Female</label></div>
            ${sel('English Female Voice', 'dbEnFemale', opts.en_voices, d.en_female_voice || 'en-US-JennyNeural')}
            <label class="field">English Speed (%)<input class="input" id="dbEnRate" type="number" min="-50" max="100" value="${Number(d.en_rate_percent ?? 0)}"></label>
            <label class="field">VoxCPM2 EN Ref Audio (Clone)<div class="row"><input class="input" id="dbEnRef" style="flex:1" placeholder="Optional 3-10s WAV/MP3" value="${esc(d.en_ref_audio || '')}"><button class="btn ghost sm" type="button" id="dbEnRefUp">Upload</button></div></label>
          </div>
          <label class="field">Voice Style Direction (Gemini / VoxCPM2 Design)<input class="input" id="dbStyle" value="${esc(d.my_style || '')}"></label>
          <div class="row" style="gap:14px;flex-wrap:wrap">
            <label class="check"><input id="dbBurn" type="checkbox" ${d.burn_custom_subtitles ? 'checked' : ''}> Burn Myanmar subtitles</label>
            <label class="check"><input id="dbBlur" type="checkbox" ${d.blur_original_subtitles ? 'checked' : ''}> Blur original subs</label>
            <label class="check"><input id="dbMirror" type="checkbox" ${d.mirror_video ? 'checked' : ''}> Mirror video</label>
            <label class="check"><input id="dbSoftSub" type="checkbox" ${d.subtitles ? 'checked' : ''}> Export SRT</label>
            <label class="check"><input id="dbResume" type="checkbox" ${d.resume !== false ? 'checked' : ''}> Resume cache</label>
          </div>
          <label class="field">Output Folder (optional)<input class="input" id="dbOutDir" placeholder="/content/Studio99Data/dubbing_outputs" value="${esc(d.output_dir || '')}"></label>
          <div class="msg" id="dbMsg"></div>
          <div class="row"><button class="btn" id="dbStart">START DUBBING</button><button class="btn danger" id="dbStop" disabled>STOP</button></div>
        </section>
        <section class="card" style="display:flex;flex-direction:column;gap:12px;min-width:0">
          <div class="kv"><span>Status</span><span id="dbStatus">Ready</span></div>
          <progress id="dbProgress" max="100" value="0" style="width:100%"></progress>
          <div class="dim" id="dbStage"></div>
          <div class="row" id="dbOutputs" style="flex-wrap:wrap"></div>
          <video id="dbVideo" controls style="width:100%;max-height:36vh;background:#05070a;border-radius:10px;display:none"></video>
          <b>Live Logs</b>
          <pre id="dbLog" style="max-height:42vh;overflow:auto;white-space:pre-wrap;background:#0a0c10;padding:12px;border-radius:8px"></pre>
        </section>
      </div>`;

    const bindRefUpload = (btnId, inputId) => {
      q(btnId).onclick = () => {
        const inp = document.createElement('input');
        inp.type = 'file'; inp.accept = 'audio/*,.wav,.mp3,.m4a';
        inp.onchange = async () => {
          const f = inp.files && inp.files[0];
          if (!f) return;
          try { q(inputId).value = await window.S99Colab.uploadAudio(f); }
          catch (e) { showMsg(e.message); }
        };
        inp.click();
      };
    };
    bindRefUpload('#dbMyRefUp', '#dbMyRef');
    bindRefUpload('#dbEnRefUp', '#dbEnRef');

    q('#dbUpload').onclick = () => {
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = 'video/*';
      inp.onchange = async () => {
        const f = inp.files && inp.files[0];
        if (!f) return;
        try {
          const p = await window.S99Colab.upload(f, 'video', q('#dbUploadState'));
          sourcePath = p; q('#dbPath').value = p; q('#dbUploadState').textContent = `Ready: ${f.name}`;
        } catch (e) { showMsg(e.message); }
      };
      inp.click();
    };
    q('#dbStart').onclick = async () => {
      showMsg(''); q('#dbStart').disabled = true;
      try { await api().dubbing_start(payload()); await refresh(); }
      catch (e) { showMsg(e.message); q('#dbStart').disabled = false; }
    };
    q('#dbStop').onclick = async () => {
      try { await api().dubbing_stop(); await refresh(); } catch (e) { showMsg(e.message); }
    };
    refresh();
  }

  function showMsg(t) { if (q('#dbMsg')) q('#dbMsg').textContent = t || ''; }

  async function refresh() {
    if (!q('#dbStatus')) return;
    try {
      const s = await api().dubbing_status();
      if (!q('#dbStatus')) return;
      q('#dbStatus').textContent = `${(s.status || 'idle').toUpperCase()}`;
      q('#dbProgress').value = s.progress || 0;
      q('#dbStage').textContent = s.stage || '';
      const busy = ['starting', 'running', 'stopping'].includes(s.status);
      q('#dbStart').disabled = busy;
      q('#dbStop').disabled = !busy;
      if (s.error) showMsg(s.error);
      if (s.logs) { q('#dbLog').textContent = s.logs.join('\n'); q('#dbLog').scrollTop = q('#dbLog').scrollHeight; }
      const outs = s.outputs || [];
      q('#dbOutputs').innerHTML = outs.map(p => `<button class="btn ghost sm" data-dl="${esc(p)}">Download ${esc(p.split(/[\\/]/).pop())}</button>`).join('');
      q('#dbOutputs').querySelectorAll('[data-dl]').forEach(b => b.onclick = () => window.S99Colab.downloadFile(b.dataset.dl));
      if (outs.length && outs[0].endsWith('.mp4')) {
        const v = q('#dbVideo'); v.style.display = 'block';
        if (!v.dataset.srcPath || v.dataset.srcPath !== outs[0]) { v.dataset.srcPath = outs[0]; v.src = `/api/media?path=${encodeURIComponent(outs[0])}`; }
      }
    } catch (_) {}
  }

  PAGES.dubbing_web = async root => {
    opts = await api().dubbing_options();
    mount(root);
    if (!pollTimer) pollTimer = setInterval(refresh, 2500);
  };
  window.S99Events = window.S99Events || {};
  window.S99Events.dubbing_log = e => { if (q('#dbLog')) { q('#dbLog').textContent += (e.line || '') + '\n'; q('#dbLog').scrollTop = q('#dbLog').scrollHeight; } };
  window.S99Events.dubbing_progress = e => { if (q('#dbProgress')) { q('#dbProgress').value = e.progress || 0; q('#dbStage').textContent = e.stage || ''; } };
  window.S99Events.dubbing_done = () => refresh();
  window.S99Events.dubbing_stopped = () => refresh();
  window.S99Events.dubbing_error = e => { showMsg(e.message); refresh(); };
  const prev = window.S99.onEvent;
  window.S99.onEvent = e => { prev(e); const fn = window.S99Events[e.kind]; if (fn) fn(e); };
})();
