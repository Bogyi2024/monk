/* Runs before app.js, so bridge/bootstrap errors cannot leave an unexplained empty window. */
(() => {
  let showing = false;
  const queued = [];
  function report(error) {
    const payload = {message: String(error?.message || error || 'Unknown UI error').slice(0,1500),
      stack: String(error?.stack || '').slice(0,4000)};
    const api = window.pywebview?.api;
    if (api?.ui_error) Promise.resolve(api.ui_error(payload)).catch(() => {});
    else if (queued.length < 8) queued.push(payload);
  }
  function show(error) {
    report(error);
    const panel = document.getElementById('uiRecovery');
    if (!panel || showing) return;
    showing = true;
    panel.classList.remove('hidden');
    document.getElementById('uiRecoveryMessage').textContent =
      'မျက်နှာပြင် ဖွင့်မရပါ။ ပြန်ဖွင့်မယ်ကို နှိပ်ပါ။ ပြီးထားတဲ့ project တွေ သိမ်းထားပါတယ်။';
  }
  window.addEventListener('error', event => show(event.error || event.message));
  window.addEventListener('unhandledrejection', event => show(event.reason));
  window.addEventListener('pywebviewready', () => {
    for (const payload of queued.splice(0)) report(payload);
  });
  document.getElementById('uiRecoveryRetry').onclick = () => location.reload();
  window.Studio99Startup = {fail: show};
})();
