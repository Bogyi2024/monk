/* Browser-native Colab UI for Studio99 Subtitle. */
(() => {
  const q = (s, root = document) => root.querySelector(s);
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const api = () => window.pywebview.api;
  let opts = null;
  let sourcePath = '';
  let srtPath = '';
  let pollTimer = 0;

  const sel = (label, id, items, val) =>
    `<label class="field">${label}<select class="input" id="${id}">${items.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(val) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`;

  function payload() {
    return {
      source_path: (q('#sbPath')?.value || sourcePath || '').trim(),
      source_srt: (q('#sbSrtPath')?.value || srtPath || '').trim(),
      source_language: q('#sbLang').value,
      whisper_model: q('#sbWhisper').value,
      gemini_model: q('#sbGemini').value,
      font_size: Number(q('#sbFontSize').value) || 48,
      bottom_margin: Number(q('#sbMargin').value) || 64,
      srt_only: q('#sbSrtOnly').checked,
      title: q('#sbTitle').value.trim(),
      part: q('#sbPart').value.trim(),
      watermark: q('#sbWatermark').value.trim(),
      speaker_context: q('#sbSpeaker').value.trim(),
      audio_crosscheck: q('#sbCrosscheck').checked,
      chunk_minutes: Number(q('#sbChunk').value) || 15,
      cues_per_request: Number(q('#sbCues').value) || 10,
      split_minutes: Number(q('#sbSplit').value) || 0,
      subtitle_bold: q('#sbBold').checked,
      box_enabled: q('#sbBox').checked,
      box_opacity: Number(q('#sbBoxOpacity').value) || 62,
      name_memory: q('#sbNames').checked,
      output_dir: q('#sbOutDir').value.trim(),
    };
  }

  function mount(root) {
    const d = opts.defaults || {};
    root.innerHTML = `<div class="page-head"><div class="crumb"><button data-go="home">‹ Home</button><h1>Subtitle · Colab</h1></div><span class="badge vip">VIP</span></div>
      <div class="profile-grid" style="grid-template-columns:minmax(310px,.95fr) minmax(0,1.05fr);max-width:none">
        <section class="card" style="display:flex;flex-direction:column;gap:11px">
          <b>Video & Subtitle Settings</b>
          <div class="row">
            <button class="btn sm" id="sbUpload">Upload Video</button>
            <input class="input" id="sbPath" style="flex:1" placeholder="/content/drive/MyDrive/video.mp4" value="${esc(sourcePath)}">
          </div>
          <div class="row">
            <button class="btn ghost sm" id="sbUploadSrt">Optional SRT</button>
            <input class="input" id="sbSrtPath" style="flex:1" placeholder="Optional existing .srt path" value="${esc(srtPath)}">
          </div>
          <div class="dim" id="sbUploadState"></div>
          <div class="profile-grid" style="grid-template-columns:1fr 1fr;gap:10px">
            ${sel('Source Language', 'sbLang', opts.languages, d.source_language)}
            ${sel('Whisper Model', 'sbWhisper', opts.whisper_models, d.whisper_model)}
            ${sel('Gemini Model', 'sbGemini', opts.gemini_models, d.gemini_model)}
            <label class="field">Font Size<input class="input" id="sbFontSize" type="number" min="20" max="120" value="${Number(d.font_size) || 48}"></label>
            <label class="field">Bottom Margin (px)<input class="input" id="sbMargin" type="number" min="0" max="400" value="${Number(d.bottom_margin) || 64}"></label>
            <label class="field">Split Minutes (0 = full)<input class="input" id="sbSplit" type="number" min="0" max="120" step="1" value="${Number(d.split_minutes) || 0}"></label>
            <label class="field">Chunk Minutes<input class="input" id="sbChunk" type="number" min="1" max="60" value="${Number(d.chunk_minutes) || 15}"></label>
            <label class="field">Cues per Gemini Request<input class="input" id="sbCues" type="number" min="1" max="40" value="${Number(d.cues_per_request) || 10}"></label>
          </div>
          <div class="profile-grid" style="grid-template-columns:1fr 1fr;gap:10px">
            <label class="field">Title Overlay<input class="input" id="sbTitle" value="${esc(d.title || '')}"></label>
            <label class="field">Part Label (e.g. Part {n})<input class="input" id="sbPart" value="${esc(d.part || '')}"></label>
            <label class="field">Watermark<input class="input" id="sbWatermark" value="${esc(d.watermark || '')}"></label>
            <label class="field">Box Opacity (%)<input class="input" id="sbBoxOpacity" type="number" min="0" max="100" value="${Number(d.box_opacity ?? 62)}"></label>
          </div>
          <label class="field">Speaker / Story Context (optional)<textarea class="input" id="sbSpeaker" rows="2">${esc(d.speaker_context || '')}</textarea></label>
          <div class="row" style="gap:14px;flex-wrap:wrap">
            <label class="check"><input id="sbSrtOnly" type="checkbox" ${d.srt_only ? 'checked' : ''}> SRT only (no render)</label>
            <label class="check"><input id="sbBox" type="checkbox" ${d.box_enabled !== false ? 'checked' : ''}> Background box</label>
            <label class="check"><input id="sbBold" type="checkbox" ${d.subtitle_bold ? 'checked' : ''}> Bold text</label>
            <label class="check"><input id="sbNames" type="checkbox" ${d.name_memory !== false ? 'checked' : ''}> Consistent Name Memory</label>
            <label class="check"><input id="sbCrosscheck" type="checkbox" ${d.audio_crosscheck ? 'checked' : ''}> Audio crosscheck</label>
          </div>
          <label class="field">Output Folder (optional)<input class="input" id="sbOutDir" placeholder="/content/Studio99Data/subtitle_outputs" value="${esc(d.output_dir || '')}"></label>
          <div class="msg" id="sbMsg"></div>
          <div class="row"><button class="btn" id="sbStart">START SUBTITLE</button><button class="btn danger" id="sbStop" disabled>STOP</button></div>
        </section>
        <section class="card" style="display:flex;flex-direction:column;gap:12px;min-width:0">
          <div class="kv"><span>Status</span><span id="sbStatus">Ready</span></div>
          <progress id="sbProgress" max="100" value="0" style="width:100%"></progress>
          <div class="dim" id="sbStage"></div>
          <div class="row" id="sbOutputs" style="flex-wrap:wrap"></div>
          <b>Live Logs</b>
          <pre id="sbLog" style="max-height:48vh;overflow:auto;white-space:pre-wrap;background:#0a0c10;padding:12px;border-radius:8px"></pre>
        </section>
      </div>`;

    q('#sbUpload').onclick = () => {
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = 'video/*';
      inp.onchange = async () => {
        const f = inp.files && inp.files[0];
        if (!f) return;
        try {
          const p = await window.S99Colab.upload(f, 'video', q('#sbUploadState'));
          sourcePath = p; q('#sbPath').value = p; q('#sbUploadState').textContent = `Ready: ${f.name}`;
        } catch (e) { showMsg(e.message); }
      };
      inp.click();
    };
    q('#sbUploadSrt').onclick = () => {
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = '.srt,.vtt,.ass';
      inp.onchange = async () => {
        const f = inp.files && inp.files[0];
        if (!f) return;
        try {
          const p = await window.S99Colab.uploadSrt(f);
          srtPath = p; q('#sbSrtPath').value = p;
        } catch (e) { showMsg(e.message); }
      };
      inp.click();
    };
    q('#sbStart').onclick = async () => {
      showMsg(''); q('#sbStart').disabled = true;
      try { await api().subtitle_start(payload()); await refresh(); }
      catch (e) { showMsg(e.message); q('#sbStart').disabled = false; }
    };
    q('#sbStop').onclick = async () => {
      try { await api().subtitle_stop(); await refresh(); } catch (e) { showMsg(e.message); }
    };
    refresh();
  }

  function showMsg(t) { if (q('#sbMsg')) q('#sbMsg').textContent = t || ''; }

  async function refresh() {
    if (!q('#sbStatus')) return;
    try {
      const s = await api().subtitle_status();
      if (!q('#sbStatus')) return;
      q('#sbStatus').textContent = `${(s.status || 'idle').toUpperCase()}`;
      q('#sbProgress').value = s.progress || 0;
      q('#sbStage').textContent = s.stage || '';
      const busy = ['starting', 'running', 'stopping'].includes(s.status);
      q('#sbStart').disabled = busy;
      q('#sbStop').disabled = !busy;
      if (s.error) showMsg(s.error);
      if (s.logs) { q('#sbLog').textContent = s.logs.join('\n'); q('#sbLog').scrollTop = q('#sbLog').scrollHeight; }
      const outs = s.outputs || [];
      q('#sbOutputs').innerHTML = outs.map(p => {
        const isDir = !/\.[A-Za-z0-9]{2,5}$/.test(p);
        return `<button class="btn ghost sm" data-dl="${esc(p)}" data-dir="${isDir ? '1' : '0'}">Download ${esc(p.split(/[\\/]/).pop())}</button>`;
      }).join('');
      q('#sbOutputs').querySelectorAll('[data-dl]').forEach(b => b.onclick = () =>
        b.dataset.dir === '1' ? window.S99Colab.downloadFolder(b.dataset.dl) : window.S99Colab.downloadFile(b.dataset.dl));
    } catch (_) {}
  }

  PAGES.subtitle_web = async root => {
    opts = await api().subtitle_options();
    mount(root);
    if (!pollTimer) pollTimer = setInterval(refresh, 2500);
  };
  window.S99Events = window.S99Events || {};
  window.S99Events.subtitle_log = e => { if (q('#sbLog')) { q('#sbLog').textContent += (e.line || '') + '\n'; q('#sbLog').scrollTop = q('#sbLog').scrollHeight; } };
  window.S99Events.subtitle_progress = e => { if (q('#sbProgress')) { q('#sbProgress').value = e.progress || 0; q('#sbStage').textContent = e.stage || ''; } };
  window.S99Events.subtitle_done = () => refresh();
  window.S99Events.subtitle_stopped = () => refresh();
  window.S99Events.subtitle_error = e => { showMsg(e.message); refresh(); };
  const prev = window.S99.onEvent;
  window.S99.onEvent = e => { prev(e); const fn = window.S99Events[e.kind]; if (fn) fn(e); };
})();
