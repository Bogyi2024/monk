/* Browser-native Colab UI for Studio99 Original -> Recap (Storytelling). */
(() => {
  const q = (s, root = document) => root.querySelector(s);
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const api = () => window.pywebview.api;
  let opts = null;
  let files = [];
  let pollTimer = 0;

  const sel = (label, id, items, val) =>
    `<label class="field">${label}<select class="input" id="${id}">${items.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(val) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`;

  function payload() {
    const manual = (q('#stPath')?.value || '').trim();
    const list = files.length ? files.map(f => f.path) : (manual ? [manual] : []);
    return {
      source_paths: list,
      source_path: list[0] || '',
      output_mode: q('#stMode').value,
      language: q('#stLang').value,
      story_length: q('#stLength').value,
      recap_minutes: Number(q('#stRecapLen').value) || 12,
      recap_unit: q('#stRecapUnit').value,
      telling_style: q('#stStyle').value,
      style_notes: q('#stNotes').value.trim(),
      narration_style: q('#stNarStyle').value,
      tts_voice: q('#stVoice').value,
      tts_rate_percent: Number(q('#stRate').value) || 25,
      analysis_speed: Number(q('#stSpeed').value) || 1,
      whisper_check: q('#stWhisper').checked,
      smooth_motion: q('#stSmooth').checked,
      share_registry: q('#stSeries').checked,
      output_dir: q('#stOutDir').value.trim(),
    };
  }

  function renderFiles() {
    if (!q('#stFiles')) return;
    q('#stFiles').innerHTML = files.map((f, i) => `<div class="row dim" style="justify-content:space-between"><span>${i + 1}. ${esc(f.name)}</span><button class="btn ghost sm" data-rm="${i}">×</button></div>`).join('') || '<div class="dim">No queued videos yet — upload or enter a /content/... path below.</div>';
    q('#stFiles').querySelectorAll('[data-rm]').forEach(b => b.onclick = () => { files.splice(Number(b.dataset.rm), 1); renderFiles(); });
  }

  function mount(root) {
    const d = opts.defaults || {};
    root.innerHTML = `<div class="page-head"><div class="crumb"><button data-go="home">‹ Home</button><h1>Original → Recap · Colab</h1></div><span class="badge vip">VIP</span></div>
      <div class="profile-grid" style="grid-template-columns:minmax(310px,.95fr) minmax(0,1.05fr);max-width:none">
        <section class="card" style="display:flex;flex-direction:column;gap:11px">
          <div class="row" style="justify-content:space-between"><b>Movie / Episode Queue</b><div class="row"><button class="btn sm" id="stUpload">+ Upload</button><button class="btn ghost sm" id="stFolder">+ Folder</button></div></div>
          <div id="stFiles" style="display:flex;flex-direction:column;gap:5px;max-height:110px;overflow:auto"></div>
          <input class="input" id="stPath" placeholder="Or enter /content/drive/MyDrive/movie.mp4">
          <div class="dim" id="stUploadState"></div>
          <div class="profile-grid" style="grid-template-columns:1fr 1fr;gap:10px">
            ${sel('Output Mode', 'stMode', opts.output_modes, d.output_mode)}
            ${sel('Narration Language', 'stLang', opts.languages, d.language)}
            ${sel('Story Length', 'stLength', opts.story_lengths, d.story_length)}
            ${sel('Telling Style', 'stStyle', opts.telling_styles, d.telling_style)}
            <label class="field">Recap Target (when Recap length)<input class="input" id="stRecapLen" type="number" min="1" max="120" value="${Number(d.recap_minutes) || 12}"></label>
            ${sel('Recap Unit', 'stRecapUnit', [['min', 'Minutes'], ['percent', '% of video']], d.recap_unit)}
            ${sel('Voice', 'stVoice', opts.voices, d.tts_voice)}
            <label class="field">Voice Speed (%)<input class="input" id="stRate" type="number" min="-30" max="80" value="${Number(d.tts_rate_percent ?? 25)}"></label>
            ${sel('Narration Style', 'stNarStyle', opts.narration_styles, d.narration_style)}
            <label class="field">Analysis Speed (1=normal, 2=2x)<input class="input" id="stSpeed" type="number" min="1" max="4" value="${Number(d.analysis_speed) || 1}"></label>
          </div>
          <label class="field">Custom Style Notes (optional)<textarea class="input" id="stNotes" rows="2">${esc(d.style_notes || '')}</textarea></label>
          <div class="row" style="gap:14px;flex-wrap:wrap">
            <label class="check"><input id="stWhisper" type="checkbox" ${d.whisper_check !== false ? 'checked' : ''}> Whisper dialogue check</label>
            <label class="check"><input id="stSmooth" type="checkbox" ${d.smooth_motion ? 'checked' : ''}> Smooth slow motion</label>
            <label class="check"><input id="stSeries" type="checkbox" ${d.share_registry !== false ? 'checked' : ''}> Same series memory</label>
          </div>
          <label class="field">Output Folder (optional)<input class="input" id="stOutDir" placeholder="/content/Studio99Data/storytelling_outputs" value="${esc(d.output_dir || '')}"></label>
          <div class="msg" id="stMsg"></div>
          <div class="row"><button class="btn" id="stStart">START ORIGINAL → RECAP</button><button class="btn danger" id="stStop" disabled>STOP</button></div>
        </section>
        <section class="card" style="display:flex;flex-direction:column;gap:12px;min-width:0">
          <div class="kv"><span>Status</span><span id="stStatus">Ready</span></div>
          <progress id="stProgress" max="100" value="0" style="width:100%"></progress>
          <div class="dim" id="stStage"></div>
          <div class="row" id="stOutputs" style="flex-wrap:wrap"></div>
          <video id="stVideo" controls style="width:100%;max-height:36vh;background:#05070a;border-radius:10px;display:none"></video>
          <b>Live Logs</b>
          <pre id="stLog" style="max-height:42vh;overflow:auto;white-space:pre-wrap;background:#0a0c10;padding:12px;border-radius:8px"></pre>
        </section>
      </div>`;

    renderFiles();
    q('#stUpload').onclick = () => {
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = 'video/*'; inp.multiple = true;
      inp.onchange = async () => {
        for (const f of Array.from(inp.files || [])) {
          try {
            const p = await window.S99Colab.upload(f, 'video', q('#stUploadState'));
            files.push({ path: p, name: f.name }); renderFiles();
          } catch (e) { showMsg(e.message); }
        }
        q('#stUploadState').textContent = '';
      };
      inp.click();
    };
    q('#stFolder').onclick = async () => {
      const folder = window.prompt('Colab video folder path (/content/...):');
      if (!folder) return;
      try {
        const res = await api().colab_list_videos(folder);
        for (const f of (res.files || [])) {
          if (!files.some(x => x.path === f.path)) files.push(f);
        }
        renderFiles();
      } catch (e) { showMsg(e.message); }
    };
    q('#stStart').onclick = async () => {
      showMsg(''); q('#stStart').disabled = true;
      try { await api().storytelling_start(payload()); await refresh(); }
      catch (e) { showMsg(e.message); q('#stStart').disabled = false; }
    };
    q('#stStop').onclick = async () => {
      try { await api().storytelling_stop(); await refresh(); } catch (e) { showMsg(e.message); }
    };
    refresh();
  }

  function showMsg(t) { if (q('#stMsg')) q('#stMsg').textContent = t || ''; }

  async function refresh() {
    if (!q('#stStatus')) return;
    try {
      const s = await api().storytelling_status();
      if (!q('#stStatus')) return;
      q('#stStatus').textContent = `${(s.status || 'idle').toUpperCase()}`;
      q('#stProgress').value = s.progress || 0;
      q('#stStage').textContent = s.stage || '';
      const busy = ['starting', 'running', 'stopping'].includes(s.status);
      q('#stStart').disabled = busy;
      q('#stStop').disabled = !busy;
      if (s.error) showMsg(s.error);
      if (s.logs) { q('#stLog').textContent = s.logs.join('\n'); q('#stLog').scrollTop = q('#stLog').scrollHeight; }
      const outs = s.outputs || [];
      q('#stOutputs').innerHTML = outs.map(p => `<button class="btn ghost sm" data-dl="${esc(p)}">Download ${esc(p.split(/[\\/]/).pop())}</button>`).join('');
      q('#stOutputs').querySelectorAll('[data-dl]').forEach(b => b.onclick = () => window.S99Colab.downloadFile(b.dataset.dl));
      const mp4 = outs.find(p => p.endsWith('.mp4'));
      if (mp4) {
        const v = q('#stVideo'); v.style.display = 'block';
        if (v.dataset.srcPath !== mp4) { v.dataset.srcPath = mp4; v.src = `/api/media?path=${encodeURIComponent(mp4)}`; }
      }
    } catch (_) {}
  }

  PAGES.storytelling_web = async root => {
    opts = await api().storytelling_options();
    mount(root);
    if (!pollTimer) pollTimer = setInterval(refresh, 2500);
  };
  window.S99Events = window.S99Events || {};
  window.S99Events.storytelling_log = e => { if (q('#stLog')) { q('#stLog').textContent += (e.line || '') + '\n'; q('#stLog').scrollTop = q('#stLog').scrollHeight; } };
  window.S99Events.storytelling_progress = e => { if (q('#stProgress')) { q('#stProgress').value = e.progress || 0; q('#stStage').textContent = e.stage || ''; } };
  window.S99Events.storytelling_done = () => refresh();
  window.S99Events.storytelling_stopped = () => refresh();
  window.S99Events.storytelling_error = e => { showMsg(e.message); refresh(); };
  const prev = window.S99.onEvent;
  window.S99.onEvent = e => { prev(e); const fn = window.S99Events[e.kind]; if (fn) fn(e); };
})();
