/* Browser implementation of the Studio99 desktop Recap screen. Retains the Recap engine/data contract. */
(() => {
  'use strict';
  const q=(s,r=document)=>r.querySelector(s), qa=(s,r=document)=>[...r.querySelectorAll(s)];
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const api=()=>window.pywebview.api;
  let options=null,poll=0,files=[],activeSource='',activeSettings={},previewTimer=0,autoTimer=0;
  let editor={blur_boxes:[],blur_box_scope:'per_movie',title_text:'',title_position:[.5,.12],title_font_size:54,logo_enabled:false,logo_path:'',logo_position:[.8,.06],logo_width_fraction:.16,logo_opacity:.65,extra_text:'',extra_text_position:[.5,.84],extra_text_font_size:42,extra_text_opacity:.65,blur_strength:18};
  let previewMeta={output_width:1920,output_height:1080,preview_width:960,preview_height:540,duration:1,seconds:0,frameImg:null};
  let activeModal=null;

  const parseRate=x=>{const m=String(x||'+0%').match(/([+-]?\d{1,3})%/);return Math.max(-50,Math.min(100,Number(m?.[1]||0)));};
  const select=(label,id,items,value,cls='field')=>`<label class="${cls}">${label}<select class="input" id="${id}">${items.map(x=>{const [v,t]=Array.isArray(x)?x:[x,x];return `<option value="${esc(v)}" ${String(v)===String(value)?'selected':''}>${esc(t)}</option>`}).join('')}</select></label>`;
  const field=(label,id,value,type='text',extra='')=>`<label class="field">${label}<input class="input" id="${id}" type="${type}" value="${esc(value)}" ${extra}></label>`;
  const check=(id,label,on)=>`<label class="check"><input id="${id}" type="checkbox" ${on?'checked':''}>${label}</label>`;
  const presets=()=>Object.entries(options.style_presets||{}).map(([k,v])=>[k,v]);
  const fmt=t=>`${Math.floor(Math.max(0,t)/60)}:${String(Math.floor(Math.max(0,t)%60)).padStart(2,'0')}`;
  const isLocalVoice=v=>{const s=String(v||'');return s.startsWith('voxcpm2:')||s.startsWith('f5mm:')||s.startsWith('voxcpm2_gguf:');};

  async function uploadVideos(multiple=true){const input=document.createElement('input');input.type='file';input.accept='video/*';input.multiple=multiple;input.onchange=async()=>{for(const f of [...(input.files||[])]){msg(`Uploading ${f.name}…`);try{files.push({path:await window.S99Colab.upload(f),name:f.name});}catch(e){msg(e.message,true);}}renderFiles();msg('');if(files[0])selectSource(files[0].path);};input.click();}
  async function uploadLogo(){const input=document.createElement('input');input.type='file';input.accept='image/*';input.onchange=async()=>{const f=input.files?.[0];if(!f)return;try{editor.logo_path=await window.S99Colab.uploadImage(f);editor.logo_enabled=true;loadLogoImage();renderEditorControls();await saveEditor();await drawPreview();}catch(e){msg(e.message,true);}};input.click();}
  function loadLogoImage(){if(editor.logo_path){const im=new Image();im.onload=()=>redrawAllCanvases();im.src=`/api/file?path=${encodeURIComponent(editor.logo_path)}&v=${Date.now()}`;window._logoImage=im;}else{window._logoImage=null;}}
  function uploadAudioTo(targetSel){const i=document.createElement('input');i.type='file';i.accept='audio/*,.wav,.mp3,.m4a';i.onchange=async()=>{const f=i.files?.[0];if(!f)return;try{msg(`Uploading ${f.name}…`);const rp=await window.S99Colab.uploadAudio(f);const el=q(targetSel);if(el)el.value=rp;msg('');saveConfig();}catch(e){msg(e.message,true);}};i.click();}
  function msg(text,error=false){const el=q('#rcMsg');if(el){el.textContent=text||'';el.classList.toggle('err',!!error);}}

  function renderFiles(){const box=q('#rcFiles');if(!box)return;box.innerHTML=files.map((f,i)=>`<div class="rc-file"><input type="checkbox" data-rc-index="${i}" checked><button class="rc-file-name" data-source="${i}">${esc(f.name||f.path)}</button><button class="btn ghost sm" data-remove="${i}">Remove</button></div>`).join('')||'<span class="dim">Source video မရွေးရသေးပါ</span>';box.querySelectorAll('[data-source]').forEach(b=>b.onclick=()=>selectSource(files[Number(b.dataset.source)].path));box.querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{files.splice(Number(b.dataset.remove),1);renderFiles();});box.querySelectorAll('[data-rc-index]').forEach(x=>x.onchange=()=>{q('#rcBatchCount').textContent=`${files.filter((_,i)=>q(`[data-rc-index="${i}"]`)?.checked).length} selected`;});q('#rcBatchCount').textContent=`${files.length} video(s)`;}
  async function selectSource(path){activeSource=path;q('#rcSourcePath').value=path;q('#rcSourceTitle').value=files.find(x=>x.path===path)?.name?.replace(/\.[^.]+$/,'')||path.split(/[\\/]/).pop().replace(/\.[^.]+$/,'');const r=await api().recap_editor_load(path).catch(()=>({}));editor={...editor,...r,blur_boxes:Array.isArray(r.blur_boxes)?r.blur_boxes:(editor.blur_box_scope==='global'?editor.blur_boxes:[])};if(editor.blur_boxes.length&&window._rcBlurSelected==null)window._rcBlurSelected=0;if(!editor.blur_boxes.length)window._rcBlurSelected=null;loadLogoImage();activeSettings={output_ratio:q('#rcRatio').value,frame_fill:q('#rcFill').value,zoom_factor:Number(q('#rcZoom').value),mirror_video:q('#rcMirror').checked};renderEditorControls();await drawPreview();}
  async function selectFolder(){const path=window.prompt('Colab video folder path (/content/drive/MyDrive/...):');if(!path)return;try{const r=await api().colab_list_videos(path);files=r.files||[];renderFiles();if(files[0])selectSource(files[0].path);if(!files.length)msg('Folder ထဲမှာ video မတွေ့ပါ',true);}catch(e){msg(e.message,true);}}
  const editorSummary=()=>{const b=editor.blur_boxes?.length||0;const sc=editor.blur_box_scope==='global'?'All Movies':'Per Movie';return `${b} blur box (${sc}) · ${previewMeta.output_width}×${previewMeta.output_height}${editor.title_text?' · Title':''}${editor.logo_enabled?' · Logo':''}${editor.extra_text?' · Text box':''}`;};

  async function render(root){options=await api().recap_options();const d=options.defaults,sub={...(options.subtitle_defaults||{}),...(d.subtitles_style||d.subtitles||{})};files=[];const initEd=await api().recap_editor_load('').catch(()=>({}));editor={...editor,...initEd,blur_box_scope:initEd.blur_box_scope||d.blur_box_scope||'per_movie'};if(editor.blur_boxes?.length)window._rcBlurSelected=0;loadLogoImage();
    const voiceOpts=options.voices.map(x=>[x,x]);
    root.innerHTML=`<div class="rc-page">
      <div class="rc-head"><div class="crumb"><button data-go="home">‹ Home</button><h1>Recap</h1><span class="rc-tag">Any language → Myanmar · Whisper + Gemini · VoxCPM2 / GGUF / F5-Myanmar · Smart Sync</span></div><button class="btn ghost sm" id="rcJobs">🗂 Jobs / Storage</button></div>
      <div class="rc-modebar"><span class="dim">Mode</span><button class="pill on" id="rcManual">▶ Manual</button><button class="pill" id="rcAuto">⚡ Auto mode <span class="badge vip">VIP</span></button><label class="check rc-delete">${check('rcDeleteAfter','',d.delete_work_after)}<span>ပြီးရင် work files ဖျက်မယ်</span></label><button class="btn ghost sm" id="rcPost" title="Auto Posting requires a local posting engine">📤 Auto Posting</button><button class="btn ghost sm" id="rcToolWindow">⛶ မျက်နှာပြင်အပြည့် window</button></div>
      <section class="card rc-auto hidden" id="rcAutoPanel"><div class="row"><label class="field grow">YouTube channel link<input class="input" id="rcChannelUrl" placeholder="https://www.youtube.com/@channel"></label>${select('Type','rcChannelKind',[['videos','Videos'],['shorts','Shorts']],'videos')}<button class="btn sm" id="rcChannelAdd">+ Add</button><button class="btn ghost sm" id="rcTiktok">TikTok login</button></div><div class="dim rc-note" id="rcAutoNote"></div><div class="profile-grid rc-autotables"><div><h3>Channels / Accounts</h3><div id="rcChannels"></div></div><div><h3>Video registry</h3><div id="rcRegistry"></div></div></div><div class="row"><span>Check every</span><input class="input narrow" id="rcInterval" type="number" min="10" max="720" step="10" value="${Number(d.auto_interval_minutes)||30}"><span>min</span><button class="btn" id="rcAutoToggle">▶ Auto စတင်</button><button class="btn ghost" id="rcCheckNow">Check now</button><span id="rcAutoState" class="dim"></span></div></section>
      <div class="rc-sourcebar"><div><label class="field">Source Video<div class="row"><input class="input grow" id="rcSourcePath" placeholder="Upload a video or enter /content/... path"><button class="btn ghost sm" id="rcBrowse">Browse / Upload</button><button class="btn ghost sm" id="rcFolder">Folder</button></div></label><div id="rcFiles" class="rc-files"></div><div id="rcBatchCount" class="dim"></div></div><div><label class="field">Gemini .env<input class="input" value="Colab notebook secret · configured privately" disabled></label><span class="dim">Secret is not shown in the browser.</span></div><div><label class="field">Save final to<input class="input" id="rcOutputDir" placeholder="/content/drive/MyDrive/Studio99Outputs" value="${esc(d.final_output_folder||'')}"></label><span class="dim">Blank = Studio99 output folder in Colab data.</span></div></div>
      <div class="rc-main">
       <section class="card rc-settings"><h2>Translation / Voice Settings</h2><div class="rc-scroll"><div class="rc-fields">
        ${select('Source language','rcLang',Object.entries(options.languages),d.source_language)}
        ${select('Narration Voice Mode','rcVoiceMode',[['single','Single Narrator (တစ်သံတည်း · Default)'],['dual','Dual Voices (ယောက်ျားသံ + မိန်းကလေးသံ)']],d.narration_voice_mode||'single')}
        <div id="rcSingleVoiceWrap" style="display:contents">
          ${select('Narrator Voice','rcVoice',voiceOpts,d.voice)}
        </div>
        <label class="field">Narrator Speed<div class="row"><input class="input" id="rcRate" type="range" min="-50" max="100" value="${parseRate(d.edge_tts_rate)}"><span id="rcRateLabel">${parseRate(d.edge_tts_rate)}%</span></div></label>
        ${field('Gemini အသံလေသံ','rcDirection',d.gemini_direction||'storyteller')}
        <div id="rcVoxBox" style="grid-column:1/-1;padding:10px;border:1px solid #2b3344;border-radius:10px;display:flex;flex-direction:column;gap:8px">
          <div class="row" style="justify-content:space-between"><b>Local GPU TTS (VoxCPM2 Official / VoxCPM2-GGUF / F5-Myanmar · Clone & Design)</b><button class="btn ghost sm" type="button" id="rcVoxUpload">Upload Ref Audio</button></div>
          <input class="input" id="rcVoxRef" placeholder="Reference audio path (3-10s WAV/MP3 for voxcpm2:clone / voxcpm2_gguf:clone / f5mm:clone)" value="${esc(d.voxcpm_ref_audio||'')}">
          <input class="input" id="rcVoxDesign" placeholder="Optional Voice Design prompt (e.g. calm warm male storyteller)" value="${esc(d.voxcpm_design||'')}">
          <input class="input" id="rcVoxPrompt" placeholder="Optional reference transcript (for Ultimate Cloning)" value="${esc(d.voxcpm_prompt_text||'')}">
          ${select('VoxCPM2 Speed (Steps)','rcVoxSteps',[['0','Auto (Detect GPU/RAM)'],['6','Fast (6 steps · ~40% faster)'],['8','Balanced (8 steps)'],['10','High Quality (10 steps)']],String(d.voxcpm_steps??0))}
        </div>
        <div id="rcDualBox" style="grid-column:1/-1;padding:10px;border:1px solid #2b3344;border-radius:10px;display:none;flex-direction:column;gap:8px">
          <div class="row" style="justify-content:space-between"><b>🎭 Dual-Gender Narration (ယောက်ျားသံ + မိန်းကလေးသံ ကျား/မ ခွဲပြော)</b></div>
          ${select('Default Narrator Gender (ဇာတ်ကြောင်းပြော မူလအသံ)','rcDualDefault',[['female','Female (မိန်းကလေး)'],['male','Male (ယောက်ျားလေး)']],d.dual_default_gender||'female')}
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
            <div style="padding:8px;border:1px solid #263042;border-radius:8px;display:flex;flex-direction:column;gap:6px">
              <div class="row" style="justify-content:space-between"><b>👨 Male Voice (ယောက်ျားသံ)</b><button class="btn ghost sm" type="button" id="rcMaleUpload">Upload Male Audio</button></div>
              ${select('Male Voice','rcMaleVoice',voiceOpts,d.male_voice||'voxcpm2:male_narrator')}
              <input class="input" id="rcMaleRef" placeholder="Male Reference Audio path (for clone)" value="${esc(d.male_ref_audio||'')}">
              <input class="input" id="rcMalePrompt" placeholder="Male Reference Transcript (optional)" value="${esc(d.male_prompt_text||'')}">
            </div>
            <div style="padding:8px;border:1px solid #263042;border-radius:8px;display:flex;flex-direction:column;gap:6px">
              <div class="row" style="justify-content:space-between"><b>👩 Female Voice (မိန်းကလေးသံ)</b><button class="btn ghost sm" type="button" id="rcFemaleUpload">Upload Female Audio</button></div>
              ${select('Female Voice','rcFemaleVoice',voiceOpts,d.female_voice||'voxcpm2:female_narrator')}
              <input class="input" id="rcFemaleRef" placeholder="Female Reference Audio path (for clone)" value="${esc(d.female_ref_audio||'')}">
              <input class="input" id="rcFemalePrompt" placeholder="Female Reference Transcript (optional)" value="${esc(d.female_prompt_text||'')}">
            </div>
          </div>
          ${select('Local GPU Speed (Steps)','rcDualSteps',[['0','Auto (Detect GPU/RAM)'],['6','Fast (6 steps)'],['8','Balanced (8 steps)'],['10','High Quality (10 steps)']],String(d.voxcpm_steps??0))}
        </div>
        <label class="field">Narration style<div class="row">${select('','rcStyleMode',[['original','Original'],['test','Test mode'] ],d.narration_style?.mode||'original','rc-inline-select')}${select('','rcStylePreset',presets(),d.narration_style?.preset||Object.keys(options.style_presets||{})[0]||'light','rc-inline-select')}<button class="btn ghost sm" id="rcStyleOpen">🎨 Style / နမူနာ</button></div></label>
        <label class="field">Narration direction / notes<textarea class="input" id="rcDirectionNotes" rows="2">${esc(d.narration_style?.instructions||'')}</textarea></label><label class="field">Narration sample paragraph<textarea class="input" id="rcStyleSample" rows="2">${esc(d.narration_style?.sample||'')}</textarea></label>
        <label class="field">Whisper model (other languages)<input class="input" id="rcWhisper" value="${esc(d.whisper_model_other||'medium')}"></label>
        ${select('Run mode','rcRunMode',Object.entries(options.run_modes||{auto:'Auto',review:'Script Review'}),d.run_mode||'auto')}
        ${select('Ratio','rcRatio',options.ratios.map(x=>[x,x]),d.output_ratio)}
        ${select('Fill','rcFill',[['blur','Blur background'],['black','Black bars'],['crop','Crop to fill']],d.frame_fill||'blur')}
        ${select('Quality','rcQuality',options.qualities.map(x=>[x,`${x}p`]),d.quality)}
        ${check('rcMirror','Flip / mirror',d.mirror_video)}
        ${check('rcShort','Short pauses (~0.25s)',d.short_pauses)}
        ${check('rcAutoBlur','Auto blur original subtitles',d.auto_blur_original_subtitles)}
        ${check('rcReuse','Reuse transcript and plan on resume',d.reuse_transcript_and_plan!==false)}
        ${check('rcRenderFinal','Render final video',d.render_final_video!==false)}
        ${field('Max video speed','rcMaxSpeed',d.max_video_speed||1.25,'number','min="1" max="3" step="0.05"')}
        ${field('Max video slow','rcMaxSlow',d.max_video_slow||1.35,'number','min="1" max="2" step="0.05"')}
        ${check('rcSmoothFreeze','Smooth freeze fallback',d.smooth_freeze_fallback)}
        ${field('Max freeze hold (s)','rcFreezeHold',d.max_freeze_hold||.75,'number','min="0.15" max="1.5" step="0.05"')}
        ${field('Zoom (1.00–1.25)','rcZoom',d.zoom_factor||1.05,'number','min="1" max="1.25" step="0.01"')}
        ${field('Narrator volume %','rcVolume',d.voice_volume_percent||100,'number','min="50" max="300" step="5"')}
        ${field('Source title','rcSourceTitle','','text')}
        ${field('Edge voice pitch','rcPitch',d.edge_tts_pitch||'+0Hz')}
        ${field('Subtitle width %','rcSubWidth',Math.round((sub.width||.86)*100),'number','min="20" max="100"')}
       </div>
       <details class="rc-sub-settings" open><summary>Narration Subtitle · Preview ပေါ်မှာ ဆွဲရွှေ့နိုင်ပါတယ်</summary><div class="rc-fields">
        ${check('rcSubOn','Subtitle ထည့်မယ်',sub.enabled!==false)}
        ${select('Font','rcSubFont',(options.subtitle_fonts||[]).map(x=>[x,x]),sub.font||'Noto Sans Myanmar')}
        ${field('Size (px)','rcSubSize',sub.size||48,'number','min="12" max="144"')}${check('rcSubBold','Bold',sub.bold)}
        ${colorField('Text colour','rcSubColor',sub.color||'#FFFFFF')}${colorField('Outline colour','rcSubOutlineColor',sub.outline_color||'#252525')}
        ${select('Outline','rcSubOutline',[['-1','Auto'],...Array.from({length:13},(_,i)=>[String(i),String(i)])],String(sub.outline_width??-1))}
        ${field('Shadow (px)','rcSubShadow',sub.shadow||0,'number','min="0" max="12"')}${check('rcSubBox','Background box',sub.box_enabled!==false)}
        ${colorField('Box colour','rcSubBoxColor',sub.box_color||'#383838')}${field('Box opacity %','rcSubBoxOpacity',sub.box_opacity??62,'number','min="0" max="100"')}
        ${field('Subtitle vertical position %','rcSubY',Math.round((sub.position?.[1]??.92)*100),'number','min="0" max="100"')}
       </div></details>
       <details class="rc-sub-settings" open><summary>Production Tools — drag Title / Logo / Subtitle / Blur box</summary>
        <div class="row" style="margin:6px 0 8px;justify-content:space-between;flex-wrap:wrap;gap:6px">
          <span class="dim" id="rcAspectBadge">Preview matches selected Aspect Ratio</span>
          <button class="btn sm" type="button" id="rcOpenEditorModal">⛶ Fine Editor Modal (အသေးစိတ်ပြင်ရန်)</button>
        </div>
        <div class="rc-overlaybar"><div class="rc-preview-wrap" style="display:flex;flex-direction:column;align-items:center;gap:6px"><canvas id="rcCanvas" width="960" height="540" style="width:auto;max-width:100%;max-height:420px;border-radius:8px;background:#090c12;display:block"></canvas><div class="row" style="width:100%"><button class="btn ghost sm" id="rcBack5">‹ 5s</button><input id="rcSeek" type="range" min="0" max="1" step="0.1" value="1" class="grow"><button class="btn ghost sm" id="rcForward5">5s ›</button><span id="rcTime" class="dim">00:00 / 00:00</span><button class="btn ghost sm" id="rcRefresh">Refresh Frame</button></div><span class="dim" id="rcEditorSummary"></span></div>
        <div class="rc-overlaytools"><div class="row"><strong>Video</strong><span class="spacer"></span><span>Zoom</span><input id="rcZoomSlider" type="range" min="1" max="1.25" step=".01" value="${Number(d.zoom_factor)||1.05}"><span id="rcZoomLabel"></span></div><hr><h3>Blur</h3>
        ${select('Blur Box Scope','rcBlurScope',[['per_movie','Per Movie (တစ်ကားချင်းစီ သီးသန့်)'],['global','All Movies (ကားအားလုံး တစ်သမတ်တည်း)']],editor.blur_box_scope||'per_movie')}
        ${check('rcBlurAuto','Auto blur မူရင်းစာတန်း',d.auto_blur_original_subtitles)}
        <div class="row" style="flex-wrap:wrap;gap:4px"><button class="btn ghost sm" type="button" id="rcDrawBlur">+ Draw Blur Box</button><button class="btn ghost sm" type="button" id="rcAddBlurPx">+ Add Box</button><button class="btn ghost sm" type="button" id="rcDeleteBlur">Delete Selected</button><span id="rcBlurCount" class="dim"></span></div>
        <div id="rcBlurPxPanel" style="margin-top:6px;padding:8px;border:1px solid #2b3344;border-radius:8px;display:flex;flex-direction:column;gap:6px">
          <div class="row" style="justify-content:space-between"><span class="dim">Selected Box (px from edges)</span><select class="input" id="rcBlurSelect" style="width:auto;padding:2px 6px"></select></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
            <label class="field">Left (px)<input class="input" id="rcBlurLeft" type="number" min="0" step="2" value="0"></label>
            <label class="field">Right (px)<input class="input" id="rcBlurRight" type="number" min="0" step="2" value="0"></label>
            <label class="field">Top (px)<input class="input" id="rcBlurTop" type="number" min="0" step="2" value="0"></label>
            <label class="field">Bottom (px)<input class="input" id="rcBlurBottom" type="number" min="0" step="2" value="0"></label>
          </div>
        </div>
        <label class="field">Blur strength<input class="input" id="rcBlurStrength" type="number" min="4" max="40" value="${Number(d.overlay_blur_strength)||18}"></label><hr><h3>Title</h3>${field('Title text','rcTitle',editor.title_text||d.title_text||'')}<label class="field">Title size<input type="range" id="rcTitleSize" min="24" max="96" value="${editor.title_font_size||d.title_font_size||54}"></label><hr><h3>Logo</h3>${check('rcLogoOn','Enable Logo',editor.logo_enabled||d.logo_enabled)}<div class="row"><button class="btn ghost sm" id="rcLogoBrowse">Browse logo image</button><button class="btn ghost sm" id="rcLogoRemove">Remove</button></div><span class="dim" id="rcLogoName">${esc((editor.logo_path||d.logo_path||'').split(/[\\/]/).pop())}</span><label class="field">Logo path (Colab / Drive)<input class="input" id="rcLogoPath" placeholder="/content/drive/MyDrive/logo.png" value="${esc(editor.logo_path||d.logo_path||'')}"></label><label class="field">Logo size<input type="range" id="rcLogoWidth" min=".06" max=".35" step=".01" value="${editor.logo_width_fraction||d.logo_width_fraction||.16}"></label><label class="field">Logo opacity<input type="range" id="rcLogoOpacity" min=".1" max="1" step=".05" value="${editor.logo_opacity||d.logo_opacity||.65}"></label><hr><h3>Extra Text Box</h3>${field('Text','rcExtraText',editor.extra_text||d.extra_text||'')}<label class="field">Size<input type="range" id="rcExtraSize" min="18" max="84" value="${editor.extra_text_font_size||d.extra_text_font_size||42}"></label><label class="field">Opacity<input type="range" id="rcExtraOpacity" min=".1" max="1" step=".05" value="${editor.extra_text_opacity||d.extra_text_opacity||.65}"></label></div></div>
       </details>
       <div class="row rc-editor-buttons"><button class="btn ghost sm" id="rcEditText">Edit Text</button><button class="btn ghost sm" id="rcScript">📝 Script</button><span class="dim" id="rcSaveMsg">Settings autosave.</span></div>
       </div><div class="rc-log-panel"><h3>Run Logs</h3><pre id="rcLog" class="log"></pre></div></section>
       <section class="card rc-side"><h2>Preview & Job</h2><div class="rc-player"><video id="rcVideo" controls playsinline></video><div id="rcOverlayLayer"></div></div><div class="row rc-player-controls"><button class="btn ghost sm" id="rcVBack">‹ 5s</button><input id="rcPlayerSeek" type="range" min="0" max="1" step=".1" value="0" class="grow"><button class="btn ghost sm" id="rcVForward">5s ›</button><span id="rcDuration" class="dim">00:00 / 00:00</span></div><div class="kv"><span>GPU</span><span id="rcGpu">${esc(options.gpu.name||'Not detected')} · ${esc(options.gpu.message)}</span></div><div class="kv"><span>Status</span><span id="rcStatus">READY · Idle</span></div><div class="kv"><span>Progress</span><span id="rcPct">0.0%</span></div><progress id="rcProgress" max="100" value="0" style="width:100%"></progress><div id="rcStage" class="dim"></div><div class="msg" id="rcMsg"></div><div class="row"><button class="btn" id="rcStart">START / RESUME</button><button class="btn danger" id="rcStop" disabled>STOP SAFELY</button><button class="btn ghost sm" id="rcOpenJob">Open Job Folder</button></div><div id="rcOutput" class="row"></div><h3>Recent outputs</h3><div id="rcRecent" class="rc-recent"></div><div id="rcScriptPanel" class="rc-script hidden"></div><p class="dim">Colab session files are temporary unless the output folder is mounted to Google Drive.</p></section>
      </div></div>`;
    bind();renderFiles();renderEditorControls();renderRecent(options.recent_outputs||[]);await hydrateAuto(options.auto||{});await refresh();poll=setInterval(refresh,1200);autoTimer=setInterval(refreshAuto,5000);}
  function colorField(label,id,value){return `<label class="field">${label}<input class="input" id="${id}" type="color" value="${esc(value)}"></label>`;}

  function syncVoicePanels(){
    const mode=q('#rcVoiceMode')?.value||'single';
    const isDual=(mode==='dual');
    if(q('#rcSingleVoiceWrap'))q('#rcSingleVoiceWrap').style.display=isDual?'none':'contents';
    if(q('#rcDualBox'))q('#rcDualBox').style.display=isDual?'flex':'none';
    if(q('#rcVoxBox'))q('#rcVoxBox').style.display=(!isDual && isLocalVoice(q('#rcVoice')?.value))?'flex':'none';
  }

  function bind(){
    q('#rcManual').onclick=()=>setMode(false);q('#rcAuto').onclick=()=>setMode(true);q('#rcBrowse').onclick=()=>uploadVideos(false);
    q('#rcPost').onclick=()=>msg('Auto Posting သည် logged-in platform profile များကို Colab cloud runtime တွင် မသုံးနိုင်ပါ။ Output ကို download ဆွဲပြီး local Studio99 Desktop မှ Auto Posting သုံးပါ။',true);
    q('#rcToolWindow').onclick=()=>{document.body.requestFullscreen?.();};q('#rcFolder').onclick=selectFolder;
    q('#rcSourcePath').onchange=()=>{const p=q('#rcSourcePath').value.trim();if(p){if(!files.some(x=>x.path===p))files.push({path:p,name:p.split(/[\\/]/).pop()});renderFiles();selectSource(p);}};
    q('#rcStart').onclick=start;q('#rcStop').onclick=stop;q('#rcJobs').onclick=jobsDialog;q('#rcOpenJob').onclick=()=>window.S99Colab.downloadFolder(activeJob());
    q('#rcScript').onclick=scriptPanel;q('#rcEditText').onclick=scriptPanel;q('#rcRefresh').onclick=drawPreview;
    q('#rcSeek').oninput=()=>seekSource(Number(q('#rcSeek').value));q('#rcBack5').onclick=()=>seekSource(-5,true);q('#rcForward5').onclick=()=>seekSource(5,true);
    q('#rcVBack').onclick=()=>{q('#rcVideo').currentTime=Math.max(0,q('#rcVideo').currentTime-5)};q('#rcVForward').onclick=()=>{q('#rcVideo').currentTime=Math.min(q('#rcVideo').duration||1,q('#rcVideo').currentTime+5)};
    q('#rcVideo').ontimeupdate=updatePlayerTime;q('#rcVideo').onloadedmetadata=()=>{q('#rcPlayerSeek').max=q('#rcVideo').duration||1;updatePlayerTime()};q('#rcPlayerSeek').oninput=()=>{q('#rcVideo').currentTime=Number(q('#rcPlayerSeek').value)};
    q('#rcRate').oninput=()=>q('#rcRateLabel').textContent=`${q('#rcRate').value}%`;
    syncVoicePanels();
    q('#rcVoiceMode')?.addEventListener('change',()=>{syncVoicePanels();saveConfig();});
    q('#rcVoice')?.addEventListener('change',syncVoicePanels);
    q('#rcVoxUpload')?.addEventListener('click',()=>uploadAudioTo('#rcVoxRef'));
    q('#rcMaleUpload')?.addEventListener('click',()=>uploadAudioTo('#rcMaleRef'));
    q('#rcFemaleUpload')?.addEventListener('click',()=>uploadAudioTo('#rcFemaleRef'));
    q('#rcDualSteps')?.addEventListener('change',()=>{if(q('#rcVoxSteps'))q('#rcVoxSteps').value=q('#rcDualSteps').value;saveConfig();});
    q('#rcVoxSteps')?.addEventListener('change',()=>{if(q('#rcDualSteps'))q('#rcDualSteps').value=q('#rcVoxSteps').value;});
    q('#rcZoomSlider').oninput=()=>{q('#rcZoom').value=q('#rcZoomSlider').value;q('#rcZoomLabel').textContent=`${Number(q('#rcZoom').value).toFixed(2)}x`;drawPreview();};
    q('#rcZoom').oninput=()=>{q('#rcZoomSlider').value=q('#rcZoom').value;q('#rcZoomLabel').textContent=`${Number(q('#rcZoom').value).toFixed(2)}x`;drawPreview();};
    q('#rcZoomLabel').textContent=`${Number(q('#rcZoom').value).toFixed(2)}x`;
    ['rcRatio','rcFill','rcQuality','rcMirror','rcTitle','rcTitleSize','rcExtraText','rcExtraSize','rcExtraOpacity','rcLogoOn','rcLogoWidth','rcLogoOpacity','rcSubOn','rcSubFont','rcSubSize','rcSubBold','rcSubColor','rcSubOutlineColor','rcSubOutline','rcSubShadow','rcSubBox','rcSubBoxColor','rcSubBoxOpacity','rcSubWidth','rcSubY','rcBlurStrength','rcMaxSpeed','rcMaxSlow','rcSmoothFreeze','rcFreezeHold','rcRenderFinal'].forEach(id=>{const el=q('#'+id);if(el)el.addEventListener('input',()=>{readEditorFromForm();if(['rcRatio','rcFill','rcQuality','rcMirror'].includes(id))drawPreview();else redrawAllCanvases();saveEditorDebounced();});});
    q('#rcBlurAuto')?.addEventListener('change',()=>{if(q('#rcAutoBlur'))q('#rcAutoBlur').checked=q('#rcBlurAuto').checked;saveConfig();});
    q('#rcAutoBlur')?.addEventListener('change',()=>{if(q('#rcBlurAuto'))q('#rcBlurAuto').checked=q('#rcAutoBlur').checked;});
    q('#rcBlurScope')?.addEventListener('change',async()=>{editor.blur_box_scope=q('#rcBlurScope').value;await saveEditor();await saveConfig();if(activeSource){const r=await api().recap_editor_load(activeSource).catch(()=>({}));if(Array.isArray(r.blur_boxes))editor.blur_boxes=r.blur_boxes;window._rcBlurSelected=editor.blur_boxes.length?0:null;renderEditorControls();redrawAllCanvases();}});
    q('#rcDrawBlur').onclick=()=>{window._rcDraw=true;if(q('#rcCanvas'))q('#rcCanvas').style.cursor='crosshair';};
    q('#rcAddBlurPx').onclick=addDefaultBlurBox;
    q('#rcDeleteBlur').onclick=deleteSelectedBlur;
    q('#rcBlurSelect')?.addEventListener('change',()=>{const idx=Number(q('#rcBlurSelect').value);window._rcBlurSelected=Number.isFinite(idx)?idx:null;syncBlurPxInputs();redrawAllCanvases();});
    ['rcBlurLeft','rcBlurRight','rcBlurTop','rcBlurBottom'].forEach(id=>{q('#'+id)?.addEventListener('input',()=>applyBlurPxFromInputs(document));});
    q('#rcOpenEditorModal')?.addEventListener('click',openFineEditorModal);
    q('#rcLogoBrowse').onclick=uploadLogo;q('#rcLogoRemove').onclick=()=>{editor.logo_enabled=false;editor.logo_path='';loadLogoImage();renderEditorControls();saveEditor();redrawAllCanvases();};q('#rcLogoPath')?.addEventListener('change',async()=>{const v=q('#rcLogoPath').value.trim();editor.logo_path=v;editor.logo_enabled=!!v;loadLogoImage();renderEditorControls();await saveEditor();await saveConfig();redrawAllCanvases();});
    q('#rcStyleOpen').onclick=styleDialog;q('#rcAutoToggle').onclick=toggleAuto;q('#rcCheckNow').onclick=()=>api().recap_auto_check().then(refreshAuto).catch(e=>msg(e.message,true));q('#rcChannelAdd').onclick=addChannel;
    q('#rcTiktok').onclick=()=>msg('TikTok login/session ကို Colab cloud browser မှ မသုံးနိုင်ပါ။ TikTok Auto ကို local Studio99 Desktop တွင် သုံးပါ။',true);
    attachCanvasHandlers(q('#rcCanvas'));
    q('#rcInterval').onchange=()=>saveConfig();
    qa('.rc-settings input,.rc-settings select,.rc-settings textarea').forEach(el=>el.addEventListener('change',()=>{readEditorFromForm();saveConfig().catch(e=>msg(e.message,true));saveEditorDebounced();}));
    bindGo();
  }

  function addDefaultBlurBox(){editor.blur_boxes.push({x:0.08,y:0.78,w:0.84,h:0.10});window._rcBlurSelected=editor.blur_boxes.length-1;renderEditorControls();redrawAllCanvases();saveEditorDebounced();}
  function boxToEdgesPx(b){const W=Math.max(2,Number(previewMeta.output_width)||1920),H=Math.max(2,Number(previewMeta.output_height)||1080);return {left:Math.round((b.x||0)*W),top:Math.round((b.y||0)*H),right:Math.max(0,Math.round(W-((b.x||0)+(b.w||0.1))*W)),bottom:Math.max(0,Math.round(H-((b.y||0)+(b.h||0.1))*H))};}
  function edgesPxToBox(left,right,top,bottom){const W=Math.max(2,Number(previewMeta.output_width)||1920),H=Math.max(2,Number(previewMeta.output_height)||1080),l=Math.max(0,Math.min(W-10,Number(left)||0)),r=Math.max(0,Math.min(W-l-10,Number(right)||0)),t=Math.max(0,Math.min(H-10,Number(top)||0)),bm=Math.max(0,Math.min(H-t-10,Number(bottom)||0));return {x:l/W,y:t/H,w:Math.max(0.01,(W-l-r)/W),h:Math.max(0.01,(H-t-bm)/H)};}

  function syncBlurPxInputs(scopeRoot=null){
    const roots=scopeRoot?[scopeRoot]:[document,...(activeModal?[activeModal]:[])];
    const boxes=editor.blur_boxes||[];
    if(boxes.length&&(window._rcBlurSelected==null||window._rcBlurSelected>=boxes.length))window._rcBlurSelected=boxes.length-1;
    if(!boxes.length)window._rcBlurSelected=null;
    const selBox=(window._rcBlurSelected!=null)?boxes[window._rcBlurSelected]:null;
    const px=selBox?boxToEdgesPx(selBox):{left:0,right:0,top:0,bottom:0};
    for(const r of roots){
      const sel=q('#rcBlurSelect',r)||q('#rcMBlurSelect',r);
      if(sel)sel.innerHTML=boxes.length?boxes.map((_,i)=>`<option value="${i}" ${i===window._rcBlurSelected?'selected':''}>Box #${i+1}</option>`).join(''):'<option value="">No box</option>';
      for(const [a,b,val] of [['#rcBlurLeft','#rcMBlurLeft',px.left],['#rcBlurRight','#rcMBlurRight',px.right],['#rcBlurTop','#rcMBlurTop',px.top],['#rcBlurBottom','#rcMBlurBottom',px.bottom]]){
        const el=q(a,r)||q(b,r);
        if(el){el.disabled=!selBox;if(document.activeElement!==el)el.value=selBox?val:0;}
      }
    }
  }

  function applyBlurPxFromInputs(rootEl){
    if(window._rcBlurSelected==null||!editor.blur_boxes[window._rcBlurSelected])return;
    const g=(a,b)=>Number((q(a,rootEl)||q(b,rootEl))?.value||0);
    editor.blur_boxes[window._rcBlurSelected]=edgesPxToBox(g('#rcBlurLeft','#rcMBlurLeft'),g('#rcBlurRight','#rcMBlurRight'),g('#rcBlurTop','#rcMBlurTop'),g('#rcBlurBottom','#rcMBlurBottom'));
    syncBlurPxInputs();redrawAllCanvases();saveEditorDebounced();
  }

  function setMode(auto){q('#rcManual').classList.toggle('on',!auto);q('#rcAuto').classList.toggle('on',auto);q('#rcAutoPanel').classList.toggle('hidden',!auto);if(auto){refreshAuto();}}

  function payload(sourcePath,sourcePaths){
    readEditorFromForm();
    const chosenStyle=q('#rcStyleMode').value==='test'?{mode:'test',preset:q('#rcStylePreset').value,instructions:q('#rcDirectionNotes').value,sample:q('#rcStyleSample').value}:{mode:'original'};
    const rate=Number(q('#rcRate').value)||0, subtitle=readSubtitle();
    const stepsVal=Number((q('#rcVoiceMode')?.value==='dual'?q('#rcDualSteps')?.value:q('#rcVoxSteps')?.value)||0);
    return {
      source_path:sourcePath,source_paths:sourcePaths,source_title:q('#rcSourceTitle').value.trim()||sourcePath.split(/[\\/]/).pop().replace(/\.[^.]+$/,''),
      source_language:q('#rcLang').value,voice:q('#rcVoice').value,narration_voice_mode:q('#rcVoiceMode')?.value||'single',
      male_voice:q('#rcMaleVoice')?.value||'voxcpm2:male_narrator',male_ref_audio:q('#rcMaleRef')?.value.trim()||'',male_prompt_text:q('#rcMalePrompt')?.value.trim()||'',
      female_voice:q('#rcFemaleVoice')?.value||'voxcpm2:female_narrator',female_ref_audio:q('#rcFemaleRef')?.value.trim()||'',female_prompt_text:q('#rcFemalePrompt')?.value.trim()||'',
      dual_default_gender:q('#rcDualDefault')?.value||'female',output_ratio:q('#rcRatio').value,frame_fill:q('#rcFill').value,quality:q('#rcQuality').value,
      subtitles:subtitle.enabled,subtitles_style:subtitle,overlays:{...editor,subtitles:subtitle},editor_overlays:editor,
      blur_box_scope:editor.blur_box_scope||'per_movie',blur_boxes:editor.blur_boxes,mirror_video:q('#rcMirror').checked,
      zoom_factor:Number(q('#rcZoom').value)||1.05,voice_volume_percent:Number(q('#rcVolume').value)||100,
      edge_tts_rate:`${rate>=0?'+':''}${rate}%`,edge_tts_pitch:q('#rcPitch').value,gemini_direction:q('#rcDirection').value,
      voxcpm_ref_audio:q('#rcVoxRef')?.value.trim()||'',voxcpm_design:q('#rcVoxDesign')?.value.trim()||'',voxcpm_prompt_text:q('#rcVoxPrompt')?.value.trim()||'',voxcpm_steps:stepsVal,
      auto_blur_original_subtitles:q('#rcAutoBlur').checked,short_pauses:q('#rcShort').checked,reuse_transcript_and_plan:q('#rcReuse').checked,
      narration_style:chosenStyle,run_mode:q('#rcRunMode').value,review_first:q('#rcRunMode').value==='review',
      max_video_speed:Number(q('#rcMaxSpeed').value)||1.25,max_video_slow:Number(q('#rcMaxSlow').value)||1.35,
      smooth_freeze_fallback:q('#rcSmoothFreeze').checked,max_freeze_hold:Number(q('#rcFreezeHold').value)||.75,
      render_final_video:q('#rcRenderFinal').checked,subtitle_width:subtitle.width,subtitle_position:subtitle.position,
      final_output_folder:q('#rcOutputDir').value.trim(),logo_enabled:editor.logo_enabled,logo_path:editor.logo_path,
      logo_width_fraction:editor.logo_width_fraction,logo_opacity:editor.logo_opacity,logo_position:editor.logo_position,
      title_text:editor.title_text,title_enabled:!!editor.title_text,title_font_size:editor.title_font_size,title_position:editor.title_position,
      extra_text:editor.extra_text,extra_text_enabled:!!editor.extra_text,extra_text_position:editor.extra_text_position,
      extra_text_font_size:editor.extra_text_font_size,extra_text_opacity:editor.extra_text_opacity,
      overlay_blur_strength:editor.blur_strength,whisper_model_other:q('#rcWhisper').value.trim()||'medium'
    };
  }

  async function start(){const chosen=files.filter((_,i)=>q(`[data-rc-index="${i}"]`)?.checked);const typed=q('#rcSourcePath').value.trim();if(!chosen.length&&typed)chosen.push({path:typed});if(!chosen.length){msg('Source video ရွေးပေးပါ။',true);return;}const req=payload(chosen[0].path,chosen.map(x=>x.path));try{await api().recap_start(req);msg('');await refresh();}catch(e){msg(e.message,true);}}
  async function refresh(){if(!q('#rcStatus'))return;try{const s=await api().recap_status();q('#rcStatus').textContent=`${(s.status||'idle').toUpperCase()} · ${s.stage||'Idle'}${s.source_index&&s.sources?.length?` · ${s.source_index}/${s.sources.length}`:''}`;q('#rcPct').textContent=`${Number(s.progress||0).toFixed(1)}%`;q('#rcProgress').value=s.progress||0;q('#rcStage').textContent=s.stage||'';q('#rcGpu').textContent=`${s.gpu?.name||'Not detected'} · ${s.gpu?.message||''}`;q('#rcStop').disabled=!['starting','running','stopping'].includes(s.status);q('#rcStart').disabled=['starting','running','stopping'].includes(s.status);if(s.error)msg(s.error,true);if(s.logs)q('#rcLog').textContent=s.logs.join('\n');if(s.status==='script_ready'){activeSource=s.source||activeSource;scriptPanel();}q('#rcOutput').innerHTML=(s.outputs||[]).map(p=>`<button class="btn ghost sm" data-dl="${esc(p)}">Download ${esc(p.split(/[\\/]/).pop())}</button>`).join('');qa('[data-dl]').forEach(b=>b.onclick=()=>window.S99Colab.downloadFile(b.dataset.dl));if(s.outputs?.length){q('#rcVideo').src=`/api/file?path=${encodeURIComponent(s.outputs[0])}`;}}catch(_){}await refreshAuto();}
  async function stop(){try{await api().recap_stop();}catch(e){msg(e.message,true);}}

  async function saveConfig(){
    const stepsVal=Number((q('#rcVoiceMode')?.value==='dual'?q('#rcDualSteps')?.value:q('#rcVoxSteps')?.value)||0);
    const settings={
      source_language:q('#rcLang').value,narrator_voice:q('#rcVoice').value,narration_voice_mode:q('#rcVoiceMode')?.value||'single',
      male_voice:q('#rcMaleVoice')?.value||'voxcpm2:male_narrator',male_ref_audio:q('#rcMaleRef')?.value.trim()||'',male_prompt_text:q('#rcMalePrompt')?.value.trim()||'',
      female_voice:q('#rcFemaleVoice')?.value||'voxcpm2:female_narrator',female_ref_audio:q('#rcFemaleRef')?.value.trim()||'',female_prompt_text:q('#rcFemalePrompt')?.value.trim()||'',
      dual_default_gender:q('#rcDualDefault')?.value||'female',edge_tts_rate:`${Number(q('#rcRate').value)>=0?'+':''}${Number(q('#rcRate').value)}%`,
      edge_tts_pitch:q('#rcPitch').value,gemini_direction:q('#rcDirection').value,voxcpm_ref_audio:q('#rcVoxRef')?.value.trim()||'',
      voxcpm_design:q('#rcVoxDesign')?.value.trim()||'',voxcpm_prompt_text:q('#rcVoxPrompt')?.value.trim()||'',voxcpm_steps:stepsVal,
      blur_box_scope:editor.blur_box_scope||'per_movie',run_mode:q('#rcRunMode').value,output_ratio:q('#rcRatio').value,frame_fill:q('#rcFill').value,
      video_quality:q('#rcQuality').value,zoom_factor:q('#rcZoom').value,mirror_video:q('#rcMirror').checked,voice_volume_percent:q('#rcVolume').value,
      short_pauses:q('#rcShort').checked,reuse_transcript_and_plan:q('#rcReuse').checked,auto_blur_original_subtitles:q('#rcAutoBlur').checked,
      whisper_model_other:q('#rcWhisper').value,final_output_folder:q('#rcOutputDir').value,subtitles:readSubtitle(),
      logo_enabled:editor.logo_enabled,logo_path:editor.logo_path,logo_width_fraction:editor.logo_width_fraction,logo_opacity:editor.logo_opacity,
      title_text:editor.title_text,title_font_size:editor.title_font_size,extra_text:editor.extra_text,extra_text_font_size:editor.extra_text_font_size,
      extra_text_opacity:editor.extra_text_opacity,overlay_blur_strength:editor.blur_strength,delete_work_after:q('#rcDeleteAfter').checked
    };
    await api().recap_save_config(settings);
    if(q('#rcSaveMsg'))q('#rcSaveMsg').textContent='Saved';
  }

  function readSubtitle(){return {enabled:q('#rcSubOn').checked,font:q('#rcSubFont').value,size:Number(q('#rcSubSize').value),bold:q('#rcSubBold').checked,color:q('#rcSubColor').value,outline_color:q('#rcSubOutlineColor').value,outline_width:q('#rcSubOutline').value,shadow:Number(q('#rcSubShadow').value),box_enabled:q('#rcSubBox').checked,box_color:q('#rcSubBoxColor').value,box_opacity:Number(q('#rcSubBoxOpacity').value),width:Number(q('#rcSubWidth').value)/100,position:[.5,Number(q('#rcSubY').value)/100]};}
  function readEditorFromForm(){if(!q('#rcTitle'))return;editor.title_text=q('#rcTitle').value;editor.title_font_size=Number(q('#rcTitleSize').value);editor.logo_enabled=q('#rcLogoOn').checked;editor.logo_path=q('#rcLogoPath').value.trim();editor.logo_width_fraction=Number(q('#rcLogoWidth').value);editor.logo_opacity=Number(q('#rcLogoOpacity').value);editor.extra_text=q('#rcExtraText').value;editor.extra_text_font_size=Number(q('#rcExtraSize').value);editor.extra_text_opacity=Number(q('#rcExtraOpacity').value);editor.blur_strength=Number(q('#rcBlurStrength').value);if(q('#rcBlurScope'))editor.blur_box_scope=q('#rcBlurScope').value;}
  let saveTimer=0;function saveEditorDebounced(){clearTimeout(saveTimer);saveTimer=setTimeout(saveEditor,350);}
  async function saveEditor(){if(!activeSource&&editor.blur_box_scope!=='global')return;readEditorFromForm();try{await api().recap_editor_save(activeSource||'',editor);if(q('#rcEditorSummary'))q('#rcEditorSummary').textContent=editorSummary();}catch(e){msg(e.message,true);}}
  function renderEditorControls(){if(q('#rcLogoOn'))q('#rcLogoOn').checked=editor.logo_enabled;if(q('#rcLogoPath')&&document.activeElement!==q('#rcLogoPath'))q('#rcLogoPath').value=editor.logo_path||'';if(q('#rcLogoName'))q('#rcLogoName').textContent=(editor.logo_path||'').split(/[\\/]/).pop();if(q('#rcBlurScope'))q('#rcBlurScope').value=editor.blur_box_scope||'per_movie';if(q('#rcBlurCount'))q('#rcBlurCount').textContent=`${editor.blur_boxes.length} box(es)`;if(q('#rcEditorSummary'))q('#rcEditorSummary').textContent=editorSummary();if(q('#rcAspectBadge'))q('#rcAspectBadge').textContent=`Ratio: ${q('#rcRatio')?.value||'Original'} · Output: ${previewMeta.output_width}×${previewMeta.output_height}`;syncBlurPxInputs();}
  function updatePlayerTime(){const v=q('#rcVideo');if(!v)return;q('#rcDuration').textContent=`${fmt(v.currentTime||0)} / ${fmt(v.duration||0)}`;if(document.activeElement!==q('#rcPlayerSeek'))q('#rcPlayerSeek').value=v.currentTime||0;}
  function seekSource(value,delta=false){const s=q('#rcSeek');if(delta)value=Number(s.value)+value;value=Math.max(0,Math.min(Number(s.max)||1,value));s.value=value;if(activeModal&&q('#rcMSeek',activeModal))q('#rcMSeek',activeModal).value=value;drawPreview();}

  function applyCanvasDimensions(c,pw,ph,maxH){if(!c)return;c.width=pw;c.height=ph;c.style.aspectRatio=`${pw} / ${ph}`;c.style.maxHeight=maxH;c.style.width='auto';c.style.maxWidth='100%';}
  function redrawCanvas(c){
    if(!c)return;
    const ctx=c.getContext('2d'),w=c.width,h=c.height;
    ctx.clearRect(0,0,w,h);
    if(previewMeta.frameImg&&previewMeta.frameImg.complete)ctx.drawImage(previewMeta.frameImg,0,0,w,h);
    else{ctx.fillStyle='#111520';ctx.fillRect(0,0,w,h);}
    ctx.save();
    const scaleY=h/Math.max(1,previewMeta.output_height||1080);
    (editor.blur_boxes||[]).forEach((b,i)=>{
      const bx=b.x*w,by=b.y*h,bw=b.w*w,bh=b.h*h;
      ctx.fillStyle=i===window._rcBlurSelected?'rgba(255,209,102,0.22)':'rgba(72,215,255,0.16)';ctx.fillRect(bx,by,bw,bh);
      ctx.strokeStyle=i===window._rcBlurSelected?'#ffd166':'#48d7ff';ctx.lineWidth=Math.max(2,Math.round(w/320));ctx.setLineDash([8,5]);ctx.strokeRect(bx,by,bw,bh);ctx.setLineDash([]);
      ctx.fillStyle=i===window._rcBlurSelected?'#ffd166':'#48d7ff';ctx.font='bold 12px sans-serif';ctx.fillText(`#${i+1}`,bx+4,Math.max(14,by+14));
    });
    if(editor.title_text){ctx.font=`bold ${Math.max(14,Math.round(editor.title_font_size*scaleY))}px "Noto Sans Myanmar",sans-serif`;ctx.textAlign='center';ctx.fillStyle='white';ctx.strokeStyle='#111';ctx.lineWidth=4;ctx.strokeText(editor.title_text,editor.title_position[0]*w,editor.title_position[1]*h);ctx.fillText(editor.title_text,editor.title_position[0]*w,editor.title_position[1]*h);}
    if(editor.extra_text){ctx.font=`${Math.max(12,Math.round(editor.extra_text_font_size*scaleY))}px "Noto Sans Myanmar",sans-serif`;ctx.textAlign='center';ctx.fillStyle=`rgba(255,255,255,${editor.extra_text_opacity})`;ctx.fillText(editor.extra_text,editor.extra_text_position[0]*w,editor.extra_text_position[1]*h);}
    if(editor.logo_enabled&&window._logoImage?.complete&&window._logoImage.naturalWidth){const iw=w*editor.logo_width_fraction,ih=iw*window._logoImage.naturalHeight/window._logoImage.naturalWidth;ctx.globalAlpha=editor.logo_opacity;ctx.drawImage(window._logoImage,editor.logo_position[0]*w,editor.logo_position[1]*h,iw,ih);ctx.globalAlpha=1;}
    if(q('#rcSubOn')?.checked){
      const text='မြန်မာစာတန်း နမူနာ',subPx=Math.max(12,Math.round(Number(q('#rcSubSize').value)*scaleY));
      ctx.font=`${q('#rcSubBold').checked?'bold ':''}${subPx}px "Noto Sans Myanmar",sans-serif`;ctx.textAlign='center';
      const x=w/2,y=(Number(q('#rcSubY').value)/100)*h,ww=w*Number(q('#rcSubWidth').value)/100,bh=Math.round(subPx*1.7);
      if(q('#rcSubBox').checked){ctx.fillStyle=hexRgba(q('#rcSubBoxColor').value,Number(q('#rcSubBoxOpacity').value)/100);ctx.fillRect((w-ww)/2,y-bh*0.72,ww,bh);}
      ctx.lineWidth=Math.max(1,Math.round(subPx/14));ctx.strokeStyle=q('#rcSubOutlineColor').value;ctx.strokeText(text,x,y);ctx.fillStyle=q('#rcSubColor').value;ctx.fillText(text,x,y);
    }
    ctx.restore();
  }
  function redrawAllCanvases(){redrawCanvas(q('#rcCanvas'));if(activeModal)redrawCanvas(q('#rcModalCanvas',activeModal));}
  function hexRgba(hex,a){const n=parseInt(String(hex||'#383838').slice(1),16);return `rgba(${n>>16},${(n>>8)&255},${n&255},${a})`;}

  async function drawPreview(){
    if(!activeSource)return;
    clearTimeout(previewTimer);
    previewTimer=setTimeout(async()=>{
      try{
        readEditorFromForm();
        const p=await api().recap_preview(activeSource,Number(q('#rcSeek').value)||0,{...activeSettings,output_ratio:q('#rcRatio').value,frame_fill:q('#rcFill').value,quality:q('#rcQuality').value,zoom_factor:Number(q('#rcZoom').value)||1.05,mirror_video:q('#rcMirror').checked,preview_max_side:960,overlays:editor});
        const im=new Image();
        im.onload=()=>{
          const pw=p.preview_width||im.naturalWidth||960,ph=p.preview_height||im.naturalHeight||540;
          previewMeta={output_width:p.output_width||p.width||1920,output_height:p.output_height||p.height||1080,preview_width:pw,preview_height:ph,duration:p.duration||1,seconds:p.seconds||0,frameImg:im};
          applyCanvasDimensions(q('#rcCanvas'),pw,ph,'420px');
          if(activeModal){
            applyCanvasDimensions(q('#rcModalCanvas',activeModal),pw,ph,'74vh');
            if(q('#rcMSeek',activeModal)){q('#rcMSeek',activeModal).max=p.duration||1;q('#rcMSeek',activeModal).value=p.seconds||0;}
            if(q('#rcMTime',activeModal))q('#rcMTime',activeModal).textContent=`${fmt(p.seconds)} / ${fmt(p.duration)}`;
            if(q('#rcMRes',activeModal))q('#rcMRes',activeModal).textContent=`${q('#rcRatio').value} · Output ${previewMeta.output_width}×${previewMeta.output_height}`;
          }
          q('#rcSeek').max=p.duration||1;q('#rcSeek').value=p.seconds||0;q('#rcTime').textContent=`${fmt(p.seconds)} / ${fmt(p.duration)}`;
          redrawAllCanvases();renderEditorControls();
          if(!q('#rcVideo').src.includes(encodeURIComponent(activeSource)))q('#rcVideo').src=`/api/media?path=${encodeURIComponent(activeSource)}`;
        };
        im.src=p.url+`&v=${Date.now()}`;
      }catch(e){msg(e.message,true);}
    },160);
  }

  function attachCanvasHandlers(cvs){
    if(!cvs)return;
    cvs.onpointerdown=e=>{
      cvs.setPointerCapture?.(e.pointerId);
      const r=cvs.getBoundingClientRect(),x=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),y=Math.max(0,Math.min(1,(e.clientY-r.top)/r.height));
      window._rcPointer={x,y};
      if(window._rcDraw){window._rcDrawStart={x,y};editor.blur_boxes.push({x,y,w:0.01,h:0.01});window._rcBlurSelected=editor.blur_boxes.length-1;window._rcDrag='draw_blur';return;}
      for(let i=editor.blur_boxes.length-1;i>=0;i--){
        const b=editor.blur_boxes[i];
        if(x>=b.x&&x<=b.x+b.w&&y>=b.y&&y<=b.y+b.h){window._rcBlurSelected=i;window._rcDrag='move_blur';window._rcDragOffset={dx:x-b.x,dy:y-b.y};syncBlurPxInputs();redrawAllCanvases();return;}
      }
      if(q('#rcSubOn')?.checked&&Math.abs(y-(Number(q('#rcSubY').value)/100))<.06){window._rcDrag='sub';return;}
      if(editor.title_text&&Math.abs(x-editor.title_position[0])<.22&&Math.abs(y-editor.title_position[1])<.08){window._rcDrag='title';return;}
      if(editor.logo_enabled&&Math.abs(x-editor.logo_position[0])<.22&&Math.abs(y-editor.logo_position[1])<.18){window._rcDrag='logo';return;}
      if(editor.extra_text&&Math.abs(x-editor.extra_text_position[0])<.25&&Math.abs(y-editor.extra_text_position[1])<.08){window._rcDrag='extra';return;}
      window._rcDrawStart={x,y};editor.blur_boxes.push({x,y,w:0.01,h:0.01});window._rcBlurSelected=editor.blur_boxes.length-1;window._rcDrag='draw_blur';
    };
    cvs.onpointermove=e=>{
      if(!window._rcPointer||!window._rcDrag)return;
      const r=cvs.getBoundingClientRect(),p={x:Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),y:Math.max(0,Math.min(1,(e.clientY-r.top)/r.height))};
      window._rcPointer=p;
      if(window._rcDrag==='title')editor.title_position=[p.x,p.y];
      else if(window._rcDrag==='logo')editor.logo_position=[p.x,p.y];
      else if(window._rcDrag==='extra')editor.extra_text_position=[p.x,p.y];
      else if(window._rcDrag==='sub'){const pct=Math.max(5,Math.min(98,Math.round(p.y*100)));q('#rcSubY').value=pct;if(activeModal&&q('#rcMSubY',activeModal))q('#rcMSubY',activeModal).value=pct;}
      else if(window._rcDrag==='move_blur'&&window._rcBlurSelected!=null){const b=editor.blur_boxes[window._rcBlurSelected];b.x=Math.max(0,Math.min(1-b.w,p.x-window._rcDragOffset.dx));b.y=Math.max(0,Math.min(1-b.h,p.y-window._rcDragOffset.dy));syncBlurPxInputs();}
      else if(window._rcDrag==='draw_blur'&&window._rcDrawStart&&window._rcBlurSelected!=null){const a=window._rcDrawStart;editor.blur_boxes[window._rcBlurSelected]={x:Math.min(a.x,p.x),y:Math.min(a.y,p.y),w:Math.max(0.01,Math.abs(p.x-a.x)),h:Math.max(0.01,Math.abs(p.y-a.y))};syncBlurPxInputs();}
      redrawAllCanvases();
    };
    cvs.onpointerup=()=>{
      if(window._rcDrag==='draw_blur'&&window._rcBlurSelected!=null){const b=editor.blur_boxes[window._rcBlurSelected];if(b&&b.w<0.015&&b.h<0.015){editor.blur_boxes.splice(window._rcBlurSelected,1);window._rcBlurSelected=editor.blur_boxes.length?editor.blur_boxes.length-1:null;}}
      window._rcDraw=false;window._rcDrawStart=null;window._rcPointer=null;window._rcDrag='';cvs.style.cursor='default';
      renderEditorControls();redrawAllCanvases();saveEditor();
    };
  }

  function deleteSelectedBlur(){if(editor.blur_boxes.length){editor.blur_boxes.splice(window._rcBlurSelected??editor.blur_boxes.length-1,1);window._rcBlurSelected=editor.blur_boxes.length?editor.blur_boxes.length-1:null;renderEditorControls();redrawAllCanvases();saveEditor();}}

  function openFineEditorModal(){
    if(activeModal){activeModal.remove();activeModal=null;}
    const box=document.createElement('div');
    box.className='rc-modal';
    box.style.cssText='position:fixed;inset:0;z-index:9999;background:rgba(6,9,15,0.82);display:flex;align-items:center;justify-content:center;padding:16px';
    box.innerHTML=`<div class="rc-modal-box" style="width:min(1320px,96vw);max-height:94vh;overflow:auto;background:#121722;border:1px solid #2b3344;border-radius:14px;padding:14px;display:flex;flex-direction:column;gap:10px">
      <div class="row" style="justify-content:space-between;align-items:center">
        <div><h2 style="margin:0">🎛 Production Tools — Fine Editor</h2><span class="dim" id="rcMRes">${esc(q('#rcRatio').value)} · Output ${previewMeta.output_width}×${previewMeta.output_height}</span></div>
        <div class="row" style="gap:8px"><button class="btn sm" type="button" id="rcMSaveClose">✓ Save & Close</button><button class="btn ghost sm" type="button" id="rcMClose">✕</button></div>
      </div>
      <div style="display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:14px;align-items:start">
        <div style="display:flex;flex-direction:column;align-items:center;gap:8px;background:#0a0d14;padding:12px;border-radius:10px;border:1px solid #222a3a">
          <canvas id="rcModalCanvas" width="${previewMeta.preview_width}" height="${previewMeta.preview_height}" style="width:auto;max-width:100%;max-height:74vh;border-radius:8px;background:#090c12;display:block"></canvas>
          <div class="row" style="width:100%"><button class="btn ghost sm" type="button" id="rcMBack5">‹ 5s</button><input id="rcMSeek" type="range" min="0" max="${previewMeta.duration||1}" step="0.1" value="${previewMeta.seconds||0}" class="grow"><button class="btn ghost sm" type="button" id="rcMFwd5">5s ›</button><span id="rcMTime" class="dim">${fmt(previewMeta.seconds)} / ${fmt(previewMeta.duration)}</span><button class="btn ghost sm" type="button" id="rcMRefresh">Refresh</button></div>
          <span class="dim">Drag Blur Box / Title / Logo / Subtitle directly on the preview, or fine-adjust pixel edges on the right.</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;max-height:78vh;overflow:auto;padding-right:4px">
          ${select('Blur Box Scope','rcMBlurScope',[['per_movie','Per Movie (တစ်ကားချင်းစီ သီးသန့်)'],['global','All Movies (ကားအားလုံး တစ်သမတ်တည်း)']],editor.blur_box_scope||'per_movie')}
          <div class="row" style="flex-wrap:wrap;gap:6px"><button class="btn sm" type="button" id="rcMDrawBlur">+ Draw Blur Box</button><button class="btn ghost sm" type="button" id="rcMAddBlur">+ Add Box</button><button class="btn danger sm" type="button" id="rcMDelBlur">Delete</button></div>
          <div style="padding:8px;border:1px solid #2b3344;border-radius:8px;display:flex;flex-direction:column;gap:6px">
            <div class="row" style="justify-content:space-between"><b>Blur Box Position (px)</b><select class="input" id="rcMBlurSelect" style="width:auto;padding:2px 6px"></select></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
              <label class="field">Left (px)<input class="input" id="rcMBlurLeft" type="number" min="0" step="2" value="0"></label>
              <label class="field">Right (px)<input class="input" id="rcMBlurRight" type="number" min="0" step="2" value="0"></label>
              <label class="field">Top (px)<input class="input" id="rcMBlurTop" type="number" min="0" step="2" value="0"></label>
              <label class="field">Bottom (px)<input class="input" id="rcMBlurBottom" type="number" min="0" step="2" value="0"></label>
            </div>
            <label class="field">Blur Strength<input class="input" id="rcMBlurStrength" type="number" min="4" max="40" value="${editor.blur_strength||18}"></label>
          </div>
          <div style="padding:8px;border:1px solid #2b3344;border-radius:8px;display:flex;flex-direction:column;gap:6px">
            <b>Subtitle & Overlays</b>
            <label class="field">Subtitle Y (%)<input class="input" id="rcMSubY" type="number" min="5" max="98" value="${Number(q('#rcSubY').value)||92}"></label>
            <label class="field">Title Text<input class="input" id="rcMTitle" value="${esc(editor.title_text||'')}"></label>
            <label class="field">Title Size<input type="range" id="rcMTitleSize" min="24" max="96" value="${editor.title_font_size||54}"></label>
            <label class="field">Extra Text<input class="input" id="rcMExtra" value="${esc(editor.extra_text||'')}"></label>
            <label class="field">Logo Path (Colab / Drive)<input class="input" id="rcMLogoPath" placeholder="/content/drive/MyDrive/logo.png" value="${esc(editor.logo_path||'')}"></label>
          </div>
        </div>
      </div>
    </div>`;
    document.body.append(box);activeModal=box;
    const mc=q('#rcModalCanvas',box);
    applyCanvasDimensions(mc,previewMeta.preview_width,previewMeta.preview_height,'74vh');
    attachCanvasHandlers(mc);syncBlurPxInputs(box);redrawCanvas(mc);

    const close=()=>{box.remove();activeModal=null;renderEditorControls();redrawAllCanvases();};
    q('#rcMClose',box).onclick=close;
    q('#rcMSaveClose',box).onclick=async()=>{await saveEditor();await saveConfig();close();};
    q('#rcMBack5',box).onclick=()=>seekSource(-5,true);q('#rcMFwd5',box).onclick=()=>seekSource(5,true);
    q('#rcMSeek',box).oninput=()=>seekSource(Number(q('#rcMSeek',box).value));q('#rcMRefresh',box).onclick=drawPreview;
    q('#rcMDrawBlur',box).onclick=()=>{window._rcDraw=true;mc.style.cursor='crosshair';};
    q('#rcMAddBlur',box).onclick=addDefaultBlurBox;q('#rcMDelBlur',box).onclick=deleteSelectedBlur;
    q('#rcMBlurSelect',box).onchange=()=>{const idx=Number(q('#rcMBlurSelect',box).value);window._rcBlurSelected=Number.isFinite(idx)?idx:null;syncBlurPxInputs();redrawAllCanvases();};
    ['rcMBlurLeft','rcMBlurRight','rcMBlurTop','rcMBlurBottom'].forEach(id=>q('#'+id,box).addEventListener('input',()=>applyBlurPxFromInputs(box)));
    q('#rcMBlurScope',box).onchange=async()=>{editor.blur_box_scope=q('#rcMBlurScope',box).value;if(q('#rcBlurScope'))q('#rcBlurScope').value=editor.blur_box_scope;await saveEditor();await saveConfig();renderEditorControls();redrawAllCanvases();};
    q('#rcMBlurStrength',box).oninput=()=>{editor.blur_strength=Number(q('#rcMBlurStrength',box).value)||18;q('#rcBlurStrength').value=editor.blur_strength;saveEditorDebounced();};
    q('#rcMSubY',box).oninput=()=>{q('#rcSubY').value=q('#rcMSubY',box).value;redrawAllCanvases();saveEditorDebounced();};
    q('#rcMTitle',box).oninput=()=>{editor.title_text=q('#rcMTitle',box).value;q('#rcTitle').value=editor.title_text;redrawAllCanvases();saveEditorDebounced();};
    q('#rcMTitleSize',box).oninput=()=>{editor.title_font_size=Number(q('#rcMTitleSize',box).value)||54;q('#rcTitleSize').value=editor.title_font_size;redrawAllCanvases();saveEditorDebounced();};
    q('#rcMExtra',box).oninput=()=>{editor.extra_text=q('#rcMExtra',box).value;q('#rcExtraText').value=editor.extra_text;redrawAllCanvases();saveEditorDebounced();};
    q('#rcMLogoPath',box).onchange=async()=>{const v=q('#rcMLogoPath',box).value.trim();editor.logo_path=v;editor.logo_enabled=!!v;if(q('#rcLogoPath'))q('#rcLogoPath').value=v;if(q('#rcLogoOn'))q('#rcLogoOn').checked=editor.logo_enabled;loadLogoImage();renderEditorControls();await saveEditor();await saveConfig();redrawAllCanvases();};
    if(activeSource&&!previewMeta.frameImg)drawPreview();
  }

  async function styleDialog(){const box=document.createElement('div');box.className='rc-modal';box.innerHTML=`<div class="rc-modal-box"><h2>Narration style</h2>${select('Mode','rcStyleModeModal',[['original','Original'],['test','Test mode']],q('#rcStyleMode').value)}${select('Preset','rcStylePresetModal',presets(),q('#rcStylePreset').value)}<label class="field">Instructions<textarea class="input" id="rcStyleNotesModal" rows="4">${esc(q('#rcDirectionNotes').value)}</textarea></label><label class="field">Sample paragraph<textarea class="input" id="rcStyleSampleModal" rows="4">${esc(q('#rcStyleSample').value)}</textarea></label><div class="row"><button class="btn" id="rcStylePreview">▶ နမူနာ စမ်းကြည့်မယ်</button><button class="btn ghost" id="rcStyleSave">Save</button><button class="btn ghost" id="rcStyleClose">Close</button></div><div id="rcStyleResult"></div></div>`;document.body.append(box);q('#rcStyleClose',box).onclick=()=>box.remove();q('#rcStyleSave',box).onclick=()=>{q('#rcStyleMode').value=q('#rcStyleModeModal').value;q('#rcStylePreset').value=q('#rcStylePresetModal').value;q('#rcDirectionNotes').value=q('#rcStyleNotesModal').value;q('#rcStyleSample').value=q('#rcStyleSampleModal').value;box.remove();saveConfig();};q('#rcStylePreview',box).onclick=async()=>{if(!activeSource){q('#rcStyleResult',box).textContent='Source video ရွေးပြီး START အရင်လုပ်ပေးပါ။';return;}q('#rcStyleResult',box).textContent='Generating sample…';try{const r=await api().recap_style_preview(activeSource,{mode:'test',preset:q('#rcStylePresetModal').value,instructions:q('#rcStyleNotesModal').value,sample:q('#rcStyleSampleModal').value});q('#rcStyleResult',box).innerHTML=r.map(x=>`<div class="card"><b>[${esc(x.timestamp)}]</b><p>${esc(x.source)}</p><p>Original: ${esc(x.original)}</p><p>Style: ${esc(x.styled)}</p></div>`).join('');}catch(e){q('#rcStyleResult',box).textContent=e.message;}};}
  async function scriptPanel(){if(!activeSource){msg('Source video ရွေးပေးပါ။',true);return;}const panel=q('#rcScriptPanel');panel.classList.remove('hidden');panel.innerHTML='<div class="dim">Loading script…</div>';try{const data=await api().recap_script_status(activeSource);if(!data.available){panel.innerHTML='<p>Script မရှိသေးပါ။ START နှိပ်ပြီး translation စတင်ပြီးမှ Script Review ကြည့်နိုင်ပါမယ်။</p>';return;}panel.innerHTML=`<div class="row"><h2>📝 Script Review</h2><span class="dim">${data.lines.length}/${data.total} · ${data.ready?'Ready':'Translating'}</span><label class="check"><input id="rcWithSource" type="checkbox">မူရင်းစာသား ပြမယ်</label><button class="btn ghost sm" id="rcExportScript">💾 Script သိမ်းမယ် (TXT)</button><button class="btn ghost sm" id="rcCloseScript">Close</button></div><div class="rc-script-layout"><div class="rc-script-lines">${data.lines.map((line,i)=>`<div class="rc-script-line"><span class="dim">${i+1}. [${esc(line.time)}]</span><div>${esc(line.text)}</div><div class="dim rc-source-line hidden">${esc(line.source)}</div><button class="btn ghost sm" data-edit-line="${line.segment_id}">Edit Text</button></div>`).join('')}</div><div><video id="rcScriptClip" controls></video><button class="btn ghost sm" id="rcPlayLine">▶ Clip ဖွင့်ကြည့်မယ်</button></div></div>${data.ready?'<button class="btn" id="rcContinue">▶ အသံ + Video ဆက်ထုတ်မယ်</button>':'<div class="dim">Translation လုပ်နေဆဲပါ။ Ready ဖြစ်အောင် ခဏစောင့်/refresh လုပ်ပါ။</div>'}`;q('#rcWithSource').onchange=()=>qa('.rc-source-line',panel).forEach(x=>x.classList.toggle('hidden',!q('#rcWithSource').checked));q('#rcCloseScript').onclick=()=>panel.classList.add('hidden');q('#rcExportScript').onclick=async()=>{const p=await api().recap_script_export(activeSource,q('#rcOutputDir').value);p.forEach(x=>window.S99Colab.downloadFile(x.path));};qa('[data-edit-line]',panel).forEach(b=>b.onclick=()=>editLine(Number(b.dataset.editLine)));q('#rcContinue')?.addEventListener('click',continueAfterReview);q('#rcPlayLine').onclick=()=>{const row=panel.querySelector('.rc-script-line');const line=data.lines[Math.max(0,[...qa('.rc-script-line',panel)].indexOf(row))];const video=q('#rcVideo');video.currentTime=line.start;video.play();setTimeout(()=>video.pause(),Math.max(500,(line.end-line.start)*1000));};}catch(e){panel.textContent=e.message;}}
  async function editLine(id){const data=await api().recap_script_status(activeSource),line=data.lines.find(x=>x.segment_id!=null&&Number(x.segment_id)===id);if(!line)return;if(!line.segment_id){msg('ခဏစောင့်ပါ — Review mode ready ဖြစ်မှ စာသားပြင်နိုင်ပါမယ်။');return;}const text=window.prompt(`Original:\n${line.source}\n\nMyanmar narration:`,line.text);if(text==null)return;await api().recap_script_save(activeSource,id,text);scriptPanel();}
  async function continueAfterReview(){const d=payload(activeSource,[activeSource]);d.run_mode='auto';d.review_first=false;d.reuse_transcript_and_plan=true;await api().recap_start(d);}
  function activeJob(){return q('#rcJobPath')?.value||`${options.jobs_path}/${activeSource.split(/[\\/]/).pop()}`;}
  async function jobsDialog(){const modal=document.createElement('div');modal.className='rc-modal';modal.innerHTML=`<div class="rc-modal-box rc-jobs"><div class="row"><h2>Jobs / Storage</h2><span class="spacer"></span><button class="btn ghost sm" id="rcWorkFolder">Work folder ပြောင်းမယ်</button><button class="btn ghost sm" id="rcJobClose">Close</button></div><p class="dim">Recap job files, size, finished output. Deleting a job also deletes resume data.</p><div id="rcJobsList">Loading…</div><div class="row"><button class="btn danger" id="rcDeleteJobs">🗑 ရွေးထားတာ ဖျက်မယ်</button><span id="rcJobsTotal" class="dim"></span></div></div>`;document.body.append(modal);q('#rcJobClose',modal).onclick=()=>modal.remove();q('#rcWorkFolder',modal).onclick=async()=>{const path=window.prompt('New work folder path under /content:');if(path){try{await api().recap_jobs_save_work_folder(path);await loadJobs();}catch(e){alert(e.message);}}};q('#rcDeleteJobs',modal).onclick=async()=>{const paths=qa('[data-job-check]:checked',modal).map(x=>x.value);if(!paths.length)return;if(!window.confirm(`${paths.length} job နှင့် resume data အားလုံး ဖျက်မလား?`))return;try{await api().recap_jobs_delete(paths);await loadJobs();}catch(e){alert(e.message);}};async function loadJobs(){const jobs=await api().recap_jobs_list();q('#rcJobsList',modal).innerHTML=`<div class="rc-jobs-table"><div class="rc-job-row rc-job-head"><span></span><b>Job</b><b>Size</b><b>Date</b><b>Final video</b></div>${jobs.map(j=>`<div class="rc-job-row"><input type="checkbox" data-job-check value="${esc(j.path)}"><b>${esc(j.name)}</b><span>${fmtBytes(j.size)}</span><span>${esc(j.date)}</span><span>${j.final_saved?'✓ output folder':j.final_in_job?'In job folder':'Resume data'}</span></div>`).join('')}</div>`;q('#rcJobsTotal',modal).textContent=`Jobs ${jobs.length} · ${fmtBytes(jobs.reduce((a,x)=>a+x.size,0))}`;}loadJobs();}
  function fmtBytes(n){const u=['B','KB','MB','GB'];let x=Number(n)||0,i=0;while(x>=1024&&i<u.length-1){x/=1024;i++;}return `${x.toFixed(i>1?1:0)} ${u[i]}`;}
  function renderRecent(items){q('#rcRecent').innerHTML=items.map(x=>`<button class="btn ghost sm" data-recent="${esc(x.path)}">${esc(x.name)}</button>`).join('')||'<span class="dim">No recent output.</span>';qa('[data-recent]').forEach(b=>b.onclick=()=>window.S99Colab.downloadFile(b.dataset.recent));}
  function hydrateAuto(s){q('#rcAutoNote').textContent=s.note||'';renderAuto(s);}
  async function refreshAuto(){if(!q('#rcChannels'))return;try{const s=await api().recap_auto_status();renderAuto(s);}catch(_){}}
  function renderAuto(s){if(!q('#rcChannels'))return;q('#rcChannels').innerHTML=(s.channels||[]).map(c=>`<div class="rc-auto-row"><span>${esc(c.url)}</span><span>${esc(c.kind)}</span><button class="btn ghost sm" data-remove-channel="${esc(c.url)}|${esc(c.kind)}">Remove</button></div>`).join('')||'<span class="dim">Channel မထည့်ရသေးပါ</span>';qa('[data-remove-channel]').forEach(b=>b.onclick=async()=>{const [url,kind]=b.dataset.removeChannel.split('|');await api().recap_auto_channel_remove(url,kind);refreshAuto();});q('#rcRegistry').innerHTML=(s.registry||[]).map(v=>`<div class="rc-auto-row"><span>${esc(v.title||v.url||v.video_id)}</span><span>${esc(v.status)}</span><span>${esc(v.status_at||'')}</span></div>`).join('')||'<span class="dim">No videos yet.</span>';q('#rcAutoToggle').textContent=s.running?'⏹ Auto ရပ်မယ်':'▶ Auto စတင်';q('#rcAutoState').textContent=s.running?`● every ${s.interval} min${s.checking?' · checking':''}${s.active?' · recapping':''}`:'Auto ရပ်ထားပါတယ်';if(s.error)msg(s.error,true);}
  async function addChannel(){const url=q('#rcChannelUrl').value.trim();if(!url)return;try{await api().recap_auto_channel_add(url,q('#rcChannelKind').value);q('#rcChannelUrl').value='';await refreshAuto();}catch(e){msg(e.message,true);}}
  async function toggleAuto(){try{if(q('#rcAutoToggle').textContent.includes('ရပ်မယ်'))await api().recap_auto_stop();else await api().recap_auto_start(Number(q('#rcInterval').value)||30);await refreshAuto();}catch(e){msg(e.message,true);}}
  function msgEvent(e){if(e?.line&&q('#rcLog')){q('#rcLog').textContent+=`${e.line}\n`;q('#rcLog').scrollTop=q('#rcLog').scrollHeight;}}
  function onEvent(e){if(e?.kind==='recap_log')msgEvent(e);if(e?.kind==='recap_done'&&options?.auto?.running){api().recap_auto_job_complete(e.outputs||[],e.sources||[]).then(refreshAuto).catch(()=>{});}if(e?.kind==='recap_error'&&options?.auto?.running){api().recap_auto_job_failed(e.sources||[],e.message||'Recap error').then(refreshAuto).catch(()=>{});}if(e?.kind?.startsWith('recap_')){if(e.kind==='recap_script_ready'){activeSource=e.source||activeSource;msg('Script ready — Review it, then continue.');scriptPanel();}if(e.kind==='recap_error')msg(e.message,true);if(e.kind==='recap_done'){msg('Recap job ပြီးဆုံးပါပြီ။');refresh();}if(e.kind==='recap_progress'){q('#rcProgress').value=e.progress||0;q('#rcPct').textContent=`${Number(e.progress||0).toFixed(1)}%`;q('#rcStage').textContent=e.label||'';}}}
  PAGES.recap_web=async root=>{clearInterval(poll);clearInterval(autoTimer);await render(root);};window.S99RecapPage={};window.S99RecapPage.onEvent=onEvent;
})();
