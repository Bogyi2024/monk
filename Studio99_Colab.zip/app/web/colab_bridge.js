/* Colab browser bridge: preserves the existing window.pywebview.api call seam. */
(() => {
  const api = new Proxy({}, { get: (_target, method) => (...args) => call(String(method), ...args) });
  let cursor = -1;
  let polling = false;
  let stopped = false;

  async function post(method, args) {
    const response = await fetch('/api/call', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ method, args })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
    return data.result;
  }

  function pickFiles(kind, multiple) {
    return new Promise(resolve => {
      const input = document.createElement('input');
      input.type = 'file'; input.multiple = !!multiple;
      input.accept = kind === 'audio' ? 'audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac'
        : kind === 'image' ? 'image/*'
        : kind === 'srt' ? '.srt,.vtt,.ass'
        : 'video/*,.mp4,.mkv,.mov,.webm,.avi,.m4v';
      input.onchange = async () => {
        try {
          const paths = [];
          for (const file of Array.from(input.files || [])) paths.push(await upload(file, kind));
          resolve(multiple ? paths : (paths[0] || ''));
        } catch (error) { window.alert(`Upload မအောင်မြင်ပါ: ${error.message}`); resolve(multiple ? [] : ''); }
      };
      input.click();
    });
  }

  function pickImageDataUrl() {
    return new Promise(resolve => {
      const input = document.createElement('input');
      input.type = 'file'; input.accept = 'image/*';
      input.onchange = () => {
        const file = input.files && input.files[0];
        if (!file) { resolve(''); return; }
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => resolve('');
        reader.readAsDataURL(file);
      };
      input.click();
    });
  }

  async function uploadSimple(file, endpoint) {
    const body = await file.arrayBuffer();
    const response = await fetch(`${endpoint}?filename=${encodeURIComponent(file.name)}`, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': file.type || 'application/octet-stream' },
      body
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
    return data.path;
  }

  async function upload(file, kind = 'video', progressEl = null) {
    if (kind === 'image') return uploadSimple(file, '/api/upload/image');
    if (kind === 'audio') return uploadSimple(file, '/api/upload/audio');
    if (kind === 'srt') return uploadSimple(file, '/api/upload/srt');
    const id = crypto.randomUUID().replaceAll('-', '');
    const chunkSize = 8 * 1024 * 1024;
    const parts = Math.max(1, Math.ceil(file.size / chunkSize));
    if (parts > 1024) throw new Error('ဒီဖိုင်က Colab upload limit ထက်ကြီးပါတယ်။ Google Drive ကို mount လုပ်ပြီး path ပေးပါ။');
    const progress = progressEl || document.getElementById('rcSource');
    for (let part = 0; part < parts; part++) {
      const blob = file.slice(part * chunkSize, Math.min(file.size, (part + 1) * chunkSize));
      const params = new URLSearchParams({ upload_id: id, part: String(part), parts: String(parts), filename: file.name });
      const response = await fetch(`/api/upload/chunk?${params}`, {
        method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream' }, body: blob
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
      if (progress) progress.textContent = `${file.name} · ${Math.round((part + 1) * 100 / parts)}% uploaded`;
      if (data.path) return data.path;
    }
    throw new Error('Upload incomplete');
  }

  async function call(method, ...args) {
    if (method === 'choose_file') return pickFiles(args[0] || 'video', false);
    if (method === 'choose_files') return pickFiles(args[0] || 'video', true);
    if (method === 'choose_folder') return window.prompt('Colab folder path ရိုက်ပါ (ဥပမာ /content/drive/MyDrive/Videos):') || '';
    if (method === 'sm_choose_image') {
      const dataUrl = await pickImageDataUrl();
      if (!dataUrl) return '';
      return post('sm_paste_image', [args[0], args[1], dataUrl]);
    }
    if (method === 'sm_load_folder') {
      const folder = window.prompt('ပုံတွေရှိတဲ့ Colab folder path ရိုက်ပါ (ဥပမာ /content/drive/MyDrive/Images):') || '';
      if (!folder) return 0;
      return post('sm_load_folder_path', [args[0], folder]);
    }
    if (method === 'open_url' || method === 'open_help') {
      const url = method === 'open_help' ? (args[0] === 'vip' ? 'https://t.me/Studio99x_bot' : 'https://t.me/Jinn260') : args[0];
      if (typeof url === 'string' && /^https?:\/\//i.test(url)) window.open(url, '_blank', 'noopener');
      return true;
    }
    if (method === 'open_folder') {
      const path = String(args[0] || '');
      if (path.startsWith('/content/')) {
        const isFile = /\.[A-Za-z0-9]{2,5}$/.test(path);
        const link = document.createElement('a');
        link.href = `${isFile ? '/api/file' : '/api/archive'}?path=${encodeURIComponent(path)}`;
        link.download = path.replace(/\/+$/, '').split('/').pop() + (isFile ? '' : '.zip');
        link.click();
      }
      return true;
    }
    if (method === 'tool_speed') return { level: 'normal', labels: { normal: 'Normal' } };
    if (method === 'tool_speed_set' || method === 'tools_hide' || method === 'tool_rect') return true;
    if (method === 'tools') return post('tools', ...args);
    if (method === 'ap_status') return { running: false, armed: false, url: '' };
    if (method === 'ap_start') return { running: false, armed: false, url: '', log: 'Auto Posting ကို Google Colab မှာ မပံ့ပိုးပါ — Facebook/TikTok logged-in browser profile လိုအပ်လို့ Studio99 Desktop (.exe) မှာသာ သုံးပါ။' };
    if (method === 'ap_list') return [];
    if (method.startsWith('ap_')) throw new Error('Auto Posting ကို Google Colab မှ မပံ့ပိုးပါ။ Local logged-in browser session လိုအပ်ပါတယ်။');
    return post(method, args);
  }

  async function pollEvents() {
    if (polling || stopped) return;
    polling = true;
    try {
      const response = await fetch(`/api/events?after=${cursor}`, { credentials: 'same-origin', cache: 'no-store' });
      if (response.ok) {
        const data = await response.json();
        for (const item of (data.events || [])) {
          cursor = Math.max(cursor, Number(item.id) || 0);
          const ev = item.event;
          if (ev && ev.kind === 'story_voice_ready' && ev.url) {
            try { new Audio(ev.url + '&v=' + Date.now()).play(); } catch (_) {}
          }
          if (window.S99?.onEvent) window.S99.onEvent(ev);
        }
        cursor = Math.max(cursor, Number(data.last_id) || 0);
      }
    } catch (_) { /* transient tunnel disconnect; the next poll retries */ }
    finally { polling = false; }
  }

  window.pywebview = { api };
  window.S99Colab = {
    upload,
    download: jobId => window.open(`/api/download?job_id=${encodeURIComponent(jobId)}`, '_blank', 'noopener'),
    downloadFile: path => window.open(`/api/file?path=${encodeURIComponent(path)}`, '_blank', 'noopener'),
    downloadFolder: path => window.open(`/api/archive?path=${encodeURIComponent(path)}`, '_blank', 'noopener'),
    openMenu: () => true,
    uploadImage: file => uploadSimple(file, '/api/upload/image'),
    uploadAudio: file => uploadSimple(file, '/api/upload/audio'),
    uploadSrt: file => uploadSimple(file, '/api/upload/srt'),
  };
  document.addEventListener('DOMContentLoaded', async () => {
    await pollEvents();
    window.dispatchEvent(new Event('pywebviewready'));
    setInterval(pollEvents, 900);
  }, { once: true });
  window.addEventListener('beforeunload', () => { stopped = true; });
})();
