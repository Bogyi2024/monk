"""Preview and remove only reproducible Desktop render/preview files.

No whole-job deletion: scripts, AI voice caches, own recordings, downloads and
finished videos stay. A short-lived server-side preview authorizes exact files;
changed files, links/junctions and registered outputs are skipped at deletion.
"""
from __future__ import annotations

import os
import stat
import time
import uuid
from pathlib import Path


def _key(path: Path) -> str:
    return os.path.normcase(os.path.abspath(path))


def _linked(path: Path) -> bool:
    info = path.lstat()
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, "st_file_attributes", 0) & 0x400)


def _plain(path: Path) -> bool:
    """Never follow a Windows junction/symlink, including a replaced ancestor."""
    try:
        return not any(_linked(p) for p in (path, *path.parents))
    except OSError:
        return False


def _stamp(info) -> tuple:
    return info.st_size, info.st_mtime_ns, info.st_dev, info.st_ino


def _cache(kind: str, rel: Path) -> bool:
    parts = rel.parts
    if "_own_voice" in parts:
        return False
    if kind == "recap":
        return ((len(parts) == 4 and parts[1:3] == ("edge_tts_smart_sync", "video_parts")
                 and rel.suffix.lower() == ".mp4")
                or (len(parts) == 3 and parts[1] == "script_preview"
                    and rel.suffix.lower() in {".png", ".jpg", ".mp4"}))
    if kind == "story":
        return len(parts) == 3 and parts[1] == "work" and parts[2] in {"narration.wav", "subs.ass"}
    return False


class Storage:
    def __init__(self) -> None:
        self._plan = None

    def scan(self, roots: list[dict], protected=()) -> dict:
        protected = {_key(Path(p)) for p in protected if p}
        seen, files, rows = set(), [], []
        for spec in roots:
            root = Path(os.path.abspath(spec["path"]))
            row = {"id": spec["id"], "title": spec["title"], "path": str(root),
                   "bytes": 0, "cache_bytes": 0, "cache_files": 0, "examples": [], "unreadable": 0}
            rows.append(row)
            if not root.is_dir() or not _plain(root):
                continue

            def failed(_error):
                row["unreadable"] += 1

            for base, dirs, names in os.walk(root, followlinks=False, onerror=failed):
                dirs[:] = [d for d in dirs if _plain(Path(base) / d)]
                for name in names:
                    path = Path(base) / name
                    try:
                        if not _plain(path) or not path.is_file():
                            continue
                        info = path.stat()
                    except OSError:
                        row["unreadable"] += 1
                        continue
                    key = _key(path)
                    if key in seen:
                        continue
                    seen.add(key)
                    row["bytes"] += info.st_size
                    rel = path.relative_to(root)
                    if key in protected or not _cache(spec["id"], rel):
                        continue
                    row["cache_bytes"] += info.st_size
                    row["cache_files"] += 1
                    if len(row["examples"]) < 5:
                        row["examples"].append(str(rel))
                    files.append((spec["id"], root, path, _stamp(info)))
        token = uuid.uuid4().hex
        self._plan = (token, time.monotonic(), files)
        return {"token": token, "rows": rows, "bytes": sum(r["bytes"] for r in rows),
                "cache_bytes": sum(r["cache_bytes"] for r in rows),
                "cache_files": sum(r["cache_files"] for r in rows)}

    def clear(self, token: str, selected: list[str], roots: list[dict], protected=()) -> dict:
        plan, self._plan = self._plan, None  # one use, including a failed attempt
        if not plan or token != plan[0] or time.monotonic() - plan[1] > 300:
            raise ValueError("Storage စာရင်းကို ပြန်စစ်ပြီးမှ ရှင်းပါ (preview သက်တမ်း ၅ မိနစ်)။")
        if not isinstance(selected, list) or not selected or not all(isinstance(x, str) for x in selected):
            raise ValueError("ရှင်းမယ့် cache အမျိုးအစားကို ရွေးပါ။")
        allowed = {(s["id"], _key(Path(s["path"]))) for s in roots}
        protected = {_key(Path(p)) for p in protected if p}
        removed = freed = skipped = 0
        for kind, root, path, before in plan[2]:
            if kind not in selected:
                continue
            try:
                valid = ((kind, _key(root)) in allowed and _plain(path)
                         and path.resolve().is_relative_to(root.resolve())
                         and _cache(kind, path.relative_to(root)) and _key(path) not in protected
                         and path.is_file() and _stamp(path.stat()) == before)
                if not valid:
                    skipped += 1
                    continue
                path.unlink()  # exact previewed files only; no recursive delete
                removed += 1
                freed += before[0]
            except OSError:
                skipped += 1
        return {"files": removed, "bytes": freed, "skipped": skipped}
