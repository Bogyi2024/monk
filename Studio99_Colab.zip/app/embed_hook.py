"""Run a Tk tool so it can live INSIDE the Studio99 window (embed.py):

    pythonw -X utf8 <app>/embed_hook.py <script.py> [args…]      (cwd = the tool's folder)

A window made a child of another process's window is never "activated", so Tk believes it does not have the
keyboard and its usual click-to-focus is refused — clicks worked but typing went nowhere (2026-10-18). Every Tk()
here gets a click binding that forces the keyboard focus onto the clicked widget while Tk thinks it has none. The
tool's own code is not changed; the script then runs exactly as `python script.py args` would."""
from __future__ import annotations

import os
import runpy
import subprocess
import sys
import tkinter
from pathlib import Path


def install(root: tkinter.Misc) -> None:
    def take_focus(event) -> None:
        widget = event.widget
        if isinstance(widget, str):
            return
        try:
            if root.focus_get() is None:
                widget.focus_force()
        except (KeyError, tkinter.TclError):           # focus_get() fails on some menus / combobox pop-downs
            try:
                widget.focus_force()
            except tkinter.TclError:
                pass
    root.bind_all("<ButtonPress>", take_focus, add="+")


try:                                                   # Studio99's own Myanmar font, whatever the PC has
    import ui_fonts
    ui_fonts.install()
except Exception:  # noqa: BLE001 - the tool still opens with the PC's fonts
    pass

_tk_init = tkinter.Tk.__init__


def _patched_init(self, *args, **kwargs) -> None:
    _tk_init(self, *args, **kwargs)
    install(self)


tkinter.Tk.__init__ = _patched_init

# A console program (ffprobe, ffmpeg …) started from a process without a console gets a new console window; while
# the tool's window is a child of Studio99 that set-up never finished — ffprobe hung at start, the Recap window
# waited for it and froze (2026-10-18, loading a video). Children started without their own console choice get
# none (CREATE_NO_WINDOW), as the tools' worker calls already do.
if os.name == "nt":
    _popen_init = subprocess.Popen.__init__
    _CONSOLE_CHOICES = (subprocess.CREATE_NEW_CONSOLE | subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS)

    def _quiet_popen_init(self, *args, **kwargs) -> None:
        flags = kwargs.get("creationflags", 0) or 0
        if not flags & _CONSOLE_CHOICES:
            kwargs["creationflags"] = flags | subprocess.CREATE_NO_WINDOW
        _popen_init(self, *args, **kwargs)

    subprocess.Popen.__init__ = _quiet_popen_init


def main() -> None:
    script = Path(sys.argv[1]).resolve()
    sys.argv = [str(script)] + sys.argv[2:]
    sys.path[0] = str(script.parent)                   # as `python script.py` would (not this file's folder)
    runpy.run_path(str(script), run_name="__main__")


if __name__ == "__main__":
    main()
