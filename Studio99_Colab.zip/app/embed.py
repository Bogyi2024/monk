"""Show another process's window INSIDE the Studio99 window (user, 2026-10-18: Recap / Splitter / Dubbing / Subtitle /
Original→Recap should not open as separate windows).

The tool keeps running in its own process (their Whisper/torch CUDA libraries crash each other in one process);
only its top-level window is turned into a borderless child of the Studio99 window (Win32 SetParent across
processes, as engine_window.py does for the Auto Posting dashboard) and laid over the page's tool area, whose
rectangle the page reports in physical pixels. Hidden while another page is shown, so its job keeps running."""
from __future__ import annotations

import ctypes
import os
import time
from ctypes import wintypes

user32 = ctypes.windll.user32
EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
user32.EnumWindows.argtypes = [EnumWindowsProc, wintypes.LPARAM]
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.IsWindowVisible.argtypes = [wintypes.HWND]
user32.IsWindow.argtypes = [wintypes.HWND]
user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
user32.SetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
user32.SetParent.argtypes = [wintypes.HWND, wintypes.HWND]
user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                wintypes.UINT]
user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
GWL_STYLE, GWL_EXSTYLE = -16, -20
WS_CHILD, WS_CLIPSIBLINGS, WS_CLIPCHILDREN = 0x40000000, 0x04000000, 0x02000000
WS_POPUP, WS_CAPTION, WS_THICKFRAME, WS_SYSMENU = 0x80000000, 0x00C00000, 0x00040000, 0x00080000
WS_MINIMIZEBOX, WS_MAXIMIZEBOX, WS_MAXIMIZE = 0x00020000, 0x00010000, 0x01000000
WS_OVERLAPPEDWINDOW = 0x00CF0000
WS_EX_APPWINDOW, WS_EX_TOOLWINDOW = 0x00040000, 0x00000080
HWND_TOP = 0
SWP_SHOWWINDOW, SWP_FRAMECHANGED, SWP_NOACTIVATE = 0x0040, 0x0020, 0x0010
SW_HIDE, SW_SHOW, SW_RESTORE = 0, 5, 9


def _title(hwnd: int) -> str:
    n = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def windows_of(pid: int, visible_only: bool = True) -> list[tuple[int, str, int]]:
    """Top-level windows of a process: (hwnd, title, area), biggest first."""
    found = []

    def callback(hwnd, _lparam):
        owner = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
        if owner.value == pid and (user32.IsWindowVisible(hwnd) or not visible_only):
            r = wintypes.RECT()
            user32.GetWindowRect(hwnd, ctypes.byref(r))
            found.append((hwnd, _title(hwnd), (r.right - r.left) * (r.bottom - r.top)))
        return True
    user32.EnumWindows(EnumWindowsProc(callback), 0)
    return sorted(found, key=lambda x: -x[2])


def own_main_window(title: str = "Studio99") -> int:
    for hwnd, text, _area in windows_of(os.getpid()):
        if text == title:
            return hwnd
    return 0


def wait_for_window(pid: int, timeout: float = 60.0, skip_titles: tuple[str, ...] = ("tk",)) -> int:
    """The tool's main window once it shows (its biggest titled visible window)."""
    end = time.time() + timeout
    while time.time() < end:
        for hwnd, text, area in windows_of(pid):
            if text and text not in skip_titles and area > 200 * 200:
                return hwnd
        time.sleep(0.3)
    return 0


def attach(child: int, parent: int) -> None:
    style = user32.GetWindowLongPtrW(child, GWL_STYLE)
    style &= ~(WS_POPUP | WS_CAPTION | WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_MAXIMIZE)
    user32.ShowWindow(child, SW_RESTORE)
    user32.SetWindowLongPtrW(child, GWL_STYLE, style | WS_CHILD | WS_CLIPSIBLINGS | WS_CLIPCHILDREN)
    ex = user32.GetWindowLongPtrW(child, GWL_EXSTYLE)
    user32.SetWindowLongPtrW(child, GWL_EXSTYLE, (ex & ~WS_EX_APPWINDOW) | WS_EX_TOOLWINDOW)   # no taskbar button
    user32.SetParent(child, parent)


def detach(child: int) -> None:
    """Back to a normal window of its own (title bar, taskbar button)."""
    style = user32.GetWindowLongPtrW(child, GWL_STYLE)
    style = (style & ~WS_CHILD) | WS_OVERLAPPEDWINDOW
    user32.SetParent(child, 0)
    user32.SetWindowLongPtrW(child, GWL_STYLE, style)
    ex = user32.GetWindowLongPtrW(child, GWL_EXSTYLE)
    user32.SetWindowLongPtrW(child, GWL_EXSTYLE, (ex & ~WS_EX_TOOLWINDOW) | WS_EX_APPWINDOW)
    user32.SetWindowPos(child, HWND_TOP, 80, 60, 1360, 860, SWP_SHOWWINDOW | SWP_FRAMECHANGED)


def place(child: int, x: int, y: int, w: int, h: int) -> None:
    user32.SetWindowPos(child, HWND_TOP, int(x), int(y), max(50, int(w)), max(50, int(h)),
                        SWP_SHOWWINDOW | SWP_FRAMECHANGED)


def hide(child: int) -> None:
    user32.ShowWindow(child, SW_HIDE)


def alive(hwnd: int) -> bool:
    return bool(hwnd) and bool(user32.IsWindow(hwnd))
