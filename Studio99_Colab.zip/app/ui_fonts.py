"""Studio99's own Myanmar font in every Tk window, whatever fonts the PC has (2026-10-31).

Customers saw broken Burmese in the Recap window (a photo of it): its labels are "Segoe UI", which has no Burmese
letters, so Tk looked through the PC's fonts for one that has them and on PCs with Zawgyi fonts installed it took
a Zawgyi one; "Myanmar Text" itself can be replaced by a Zawgyi copy too. Entries and comboboxes also came out very
big there, because Tk's named fonts (TkTextFont …) follow the PC's own system font and size.

Now every Tk process the app starts (embed_hook.py imports this) loads fonts/Studio99Myanmar-*.ttf for itself only
(AddFontResourceExW FR_PRIVATE — nothing is installed on the PC) and the UI families the tools use are drawn with
it: Burmese and Latin letters both come from that one font, so Tk never has to look for another. A font a user
picked for a preview (e.g. "Burma-020 Thin") is left alone. The font = Noto Sans Myanmar (SIL OFL 1.1), renamed and
with smaller line metrics (tools/make_ui_fonts.py)."""
from __future__ import annotations

import os
import tkinter
from pathlib import Path
from tkinter import font as tkfont
from tkinter import ttk

FAMILY = "Studio99 Myanmar"
FONT_DIR = Path(__file__).with_name("fonts")
FILES = ("Studio99Myanmar-Regular.ttf", "Studio99Myanmar-Bold.ttf")
# the families Studio99's tools use for their own text (not fonts chosen for a subtitle / title preview)
UI_FAMILIES = {"segoe ui", "segoe ui semibold", "segoe ui semilight", "segoe ui light", "segoe ui black",
               "myanmar text", "consolas", "courier new", "tahoma", "arial", "calibri", "helvetica", "courier",
               "times", "fixed", "tkdefaultfont", "tktextfont", "tkfixedfont", "tkheadingfont", "tkmenufont"}
BOLD_FAMILIES = {"segoe ui semibold", "segoe ui black"}
NAMED = {"TkDefaultFont": 9, "TkTextFont": 9, "TkFixedFont": 9, "TkMenuFont": 9, "TkHeadingFont": 9,
         "TkCaptionFont": 10, "TkSmallCaptionFont": 8, "TkIconFont": 9, "TkTooltipFont": 8}

_loaded: bool | None = None


def load() -> bool:
    """Make the font usable in this process only. False = not on Windows / files missing (old fonts are kept)."""
    global _loaded
    if _loaded is None:
        _loaded = False
        if os.name == "nt" and all((FONT_DIR / name).is_file() for name in FILES):
            import ctypes
            add = ctypes.windll.gdi32.AddFontResourceExW
            add.argtypes = [ctypes.c_wchar_p, ctypes.c_uint, ctypes.c_void_p]
            _loaded = all(add(str(FONT_DIR / name), 0x10, None) > 0 for name in FILES)   # 0x10 = FR_PRIVATE
    return _loaded


def face(family: str) -> str:
    """The face to use instead of `family` (a Windows control's font name, e.g. a RichEdit box)."""
    return FAMILY if load() and str(family).strip().lower() in UI_FAMILIES else family


def fix(spec):
    """("Segoe UI Semibold", 10) → ("Studio99 Myanmar", 10, "bold"); anything else is returned unchanged."""
    if not isinstance(spec, (tuple, list)) or not spec or not isinstance(spec[0], str):
        return spec
    family = spec[0].strip().lower()
    if family not in UI_FAMILIES:
        return spec
    rest = list(spec[1:])
    if family in BOLD_FAMILIES and not any(str(x).lower() == "bold" for x in rest[1:]):
        rest = (rest or [9])[:1] + ["bold"] + rest[1:]
    return (FAMILY, *rest)


def _fixed_options(options: dict) -> dict:
    if isinstance(options, dict) and "font" in options:
        new = fix(options["font"])
        if new is not options["font"]:
            options = dict(options, font=new)
    return options


def set_named_fonts(root: tkinter.Misc) -> None:
    """Tk's own fonts (entries, comboboxes, lists, plain Text) = our font at Studio99's size, not the PC's."""
    for name, size in NAMED.items():
        try:
            tkfont.nametofont(name, root=root).configure(family=FAMILY, size=size)
        except (tkinter.TclError, TypeError):
            pass


def install() -> None:
    """Patch tkinter once: widget/canvas/tag options, ttk styles, Font objects and every new Tk root."""
    if getattr(tkinter, "_studio99_fonts", False) or not load():
        return
    tkinter._studio99_fonts = True

    options = tkinter.Misc._options

    def _options(self, cnf, kw=None):
        cnf = tkinter._cnfmerge((cnf, kw)) if kw else tkinter._cnfmerge(cnf)
        return options(self, _fixed_options(cnf))
    tkinter.Misc._options = _options

    style_configure = ttk.Style.configure

    def _style_configure(self, style, query_opt=None, **kw):
        if "font" in kw:
            kw["font"] = fix(kw["font"])
        return style_configure(self, style, query_opt, **kw)
    ttk.Style.configure = _style_configure

    font_init = tkfont.Font.__init__

    def _font_init(self, root=None, font=None, name=None, exists=False, **options):
        if font is not None:
            font = fix(font)
        if str(options.get("family", "")).strip().lower() in UI_FAMILIES:
            options["family"] = FAMILY
        font_init(self, root, font, name, exists, **options)
    tkfont.Font.__init__ = _font_init

    font_configure = tkfont.Font.configure

    def _font_configure(self, **options):
        if str(options.get("family", "")).strip().lower() in UI_FAMILIES:
            options["family"] = FAMILY
        return font_configure(self, **options)
    tkfont.Font.configure = tkfont.Font.config = _font_configure

    tk_init = tkinter.Tk.__init__

    def _tk_init(self, *args, **kwargs):
        tk_init(self, *args, **kwargs)
        set_named_fonts(self)
    tkinter.Tk.__init__ = _tk_init
