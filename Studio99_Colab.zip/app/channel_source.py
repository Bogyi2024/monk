"""VIP Recap source: YouTube channels and TikTok accounts. New videos are found with yt-dlp (flat playlist, like the
TT master's recap_source_service), downloaded, and handed to Recap one by one.

Kept on this PC: %APPDATA%\\Studio99Desktop\\channels.json = {"channels": [...], "videos": {video_id: entry}} — the
registry of every video a channel ever showed, like the TT master's recap_source_registry.json (user, 2026-10-23:
"remember what was done so nothing is posted twice"): entry = {video_id, title, url, channel_url, platform, status,
status_at, first_seen_at, attempts, path, final}. status: old (there before the channel was added) → downloading →
downloaded → recapping → done → queued (on the Auto Posting list); download_failed / recap_failed are tried again
up to MAX_ATTEMPTS times; anything else is never taken again. What was posted where is the engine's ledger
(posting_queue.ledger(), keyed by the video link).
A channel added later does not recap its whole back catalogue: its current videos are marked old first, only
videos published after that are taken (newest first, at most `per_check` per check). The {"seen": {id: status}}
of earlier versions is read into "videos"."""
from __future__ import annotations

import json
import re
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from token_store import APP_DIR

CHANNELS_FILE = APP_DIR / "channels.json"
DOWNLOADS = APP_DIR / "downloads"
_lock = threading.Lock()


def platform(url: str) -> str:
    low = str(url or "").lower()
    if "tiktok.com" in low:
        return "tiktok"
    if "youtube.com" in low or "youtu.be" in low:
        return "youtube"
    return "other"


def scan_url(url: str, kind: str = "videos") -> str:
    """A YouTube channel root gets /videos (long recaps) or /shorts; other URLs stay as they are."""
    clean = str(url or "").strip().rstrip("/")
    low = clean.lower()
    if platform(clean) != "youtube" or any(x in low for x in ("/videos", "/shorts", "watch?", "youtu.be/", "playlist?")):
        return clean
    return clean + ("/shorts" if kind == "shorts" else "/videos")


MAX_ATTEMPTS = 3
RETRY = ("download_failed", "recap_failed")


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def load() -> dict[str, Any]:
    try:
        data = json.loads(CHANNELS_FILE.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    data.setdefault("channels", [])
    videos = data.setdefault("videos", {})
    for vid, status in (data.pop("seen", None) or {}).items():           # earlier versions
        videos.setdefault(str(vid), {"video_id": str(vid), "status": str(status), "status_at": "", "attempts": 0})
    return data


def eligible(entry: dict[str, Any] | None) -> bool:
    """A video the auto mode may take: never seen, or failed fewer than MAX_ATTEMPTS times."""
    if not entry:
        return True
    return entry.get("status") in RETRY and int(entry.get("attempts") or 0) < MAX_ATTEMPTS


def save(data: dict[str, Any]) -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    tmp = CHANNELS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(CHANNELS_FILE)


def list_videos(url: str, kind: str = "videos", limit: int = 15) -> list[dict[str, Any]]:
    """Newest first: [{id, title, url}]."""
    import yt_dlp

    opts: dict[str, Any] = {"quiet": True, "no_warnings": True, "ignoreerrors": True, "extract_flat": "in_playlist",
                            "skip_download": True, "playlistend": int(limit)}
    target = scan_url(url, kind)
    if platform(url) == "tiktok":
        return tiktok_videos(url, limit)
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(target, download=False) or {}
    out = []
    handle = re.search(r"tiktok\.com/@([^/?#]+)", str(url), re.IGNORECASE)
    for entry in info.get("entries") or []:
        if not entry or not entry.get("id"):
            continue
        vid = str(entry["id"])
        link = entry.get("webpage_url") or entry.get("url") or ""
        if not str(link).startswith("http"):
            link = (f"https://www.tiktok.com/@{handle.group(1)}/video/{vid}" if handle
                    else f"https://www.youtube.com/watch?v={vid}")
        out.append({"id": vid, "title": str(entry.get("title") or "").strip(), "url": str(link)})
    return out


def tiktok_videos(url: str, limit: int = 15) -> list[dict[str, Any]]:
    """A TikTok account's videos, newest first. yt-dlp can no longer read a profile ("Unable to extract secondary
    user ID", 2026-10-17, also with browser impersonation), a plain request gets a 1.4 KB shell, and TikTok answers
    the profile's /api/post/item_list/ with an empty body unless the browser is logged in. So the app's own browser
    profile (BROWSER_PROFILE, logged in once by the user with open_tiktok_login) opens the page and that answer is
    read — the TT master likewise uses the user's TikTok cookies."""
    from playwright.sync_api import sync_playwright

    handle = re.search(r"tiktok\.com/@([^/?#]+)", str(url), re.IGNORECASE)
    if not handle:
        raise ValueError("TikTok account link (https://www.tiktok.com/@name) ထည့်ပါ")
    items: list[dict[str, Any]] = []

    def on_response(response) -> None:
        if "/api/post/item_list/" in response.url:
            try:
                items.extend(response.json().get("itemList") or [])
            except Exception:
                pass

    with sync_playwright() as p:
        browser = p.chromium.launch_persistent_context(str(BROWSER_PROFILE), headless=True,
                                                       viewport={"width": 1280, "height": 1600})
        try:
            page = browser.new_page()
            page.on("response", on_response)
            page.goto(f"https://www.tiktok.com/@{handle.group(1)}", wait_until="domcontentloaded", timeout=60000)
            for _ in range(20):
                if items:
                    break
                page.wait_for_timeout(500)
        finally:
            browser.close()
    if not items and not tiktok_logged_in():
        raise RuntimeError("TikTok login လိုပါတယ် — 'TikTok login' ကို နှိပ်ပြီး ပွင့်လာတဲ့ browser မှာ တစ်ခါ login ဝင်ပါ")
    items = [x for x in items if x.get("id") and not x.get("isPinnedItem")]
    items.sort(key=lambda x: int(x.get("createTime") or 0), reverse=True)
    return [{"id": str(x["id"]), "title": str(x.get("desc") or "").strip(),
             "url": f"https://www.tiktok.com/@{handle.group(1)}/video/{x['id']}"} for x in items[:limit]]


BROWSER_PROFILE = APP_DIR / "browser_profile"


def tiktok_logged_in() -> bool:
    """A TikTok session cookie in the app's browser profile (checked without opening a window)."""
    import sqlite3
    cookies = BROWSER_PROFILE / "Default" / "Network" / "Cookies"
    if not cookies.is_file():
        return False
    try:
        with sqlite3.connect(f"file:{cookies}?mode=ro&immutable=1", uri=True) as db:
            return bool(db.execute("select 1 from cookies where host_key like '%tiktok.com' and name='sessionid' "
                                   "limit 1").fetchone())
    except Exception:
        return False


def open_tiktok_login() -> None:
    """A visible window of the app's browser on TikTok's login page; the user logs in there and closes it."""
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        browser = p.chromium.launch_persistent_context(str(BROWSER_PROFILE), headless=False, no_viewport=True)
        page = browser.pages[0] if browser.pages else browser.new_page()
        page.goto("https://www.tiktok.com/login", wait_until="domcontentloaded", timeout=60000)
        try:
            page.wait_for_event("close", timeout=0)
        except Exception:
            pass
        try:
            browser.close()
        except Exception:
            pass


def download(url: str, log: Callable[[str], None] = print) -> Path:
    """One channel video (Recap Auto mode, Long to Short links). Network routes as Movie Search's: through the
    VPN YouTube answers "Sign in to confirm you're not a bot" (2026-10-30, the installed app's channel videos all
    failed so), direct it works — so YouTube goes direct first, then the VPN."""
    import yt_dlp
    from movie_search import _network_tries

    DOWNLOADS.mkdir(parents=True, exist_ok=True)
    opts = {"quiet": True, "no_warnings": True, "noplaylist": True, "merge_output_format": "mp4",
            "format": "bv*[height<=1080][ext=mp4]+ba[ext=m4a]/b[height<=1080]/b",
            "outtmpl": str(DOWNLOADS / "%(title).80B [%(id)s].%(ext)s")}
    bundled_ffmpeg = Path(__file__).resolve().parents[1] / "recap_tool_src" / "ffmpeg" / "ffmpeg.exe"
    if bundled_ffmpeg.is_file():
        opts["ffmpeg_location"] = str(bundled_ffmpeg.parent)
    tries = _network_tries(platform(url))
    for n, extra in enumerate(tries):
        try:
            with yt_dlp.YoutubeDL({**opts, **extra}) as ydl:
                info = ydl.extract_info(url, download=True)
                path = Path(ydl.prepare_filename(info)).with_suffix(".mp4")
            break
        except Exception as exc:  # noqa: BLE001
            if n == len(tries) - 1:
                raise RuntimeError(f"Download မရပါ: {str(exc).replace('ERROR: ', '')[:200]}") from exc
    if not path.is_file():
        found = sorted(DOWNLOADS.glob(f"*[[]{info.get('id')}[]].*"))
        if not found:
            raise RuntimeError(f"Download failed: {url}")
        path = found[0]
    log(f"⬇️ {path.name}")
    return path


def add_channel(url: str, kind: str = "videos", auto_post: bool = False, log: Callable[[str], None] = print) -> dict:
    """Adds a channel and marks what it already has as old (only new videos are recapped)."""
    url = str(url).strip()
    if platform(url) not in ("youtube", "tiktok"):
        raise ValueError("YouTube channel (သို့) TikTok account link ထည့်ပါ")
    current = list_videos(url, kind, limit=30)
    with _lock:
        data = load()
        if any(c["url"] == url and c.get("kind") == kind for c in data["channels"]):
            raise ValueError("ဒီ channel ထည့်ပြီးသားပါ")
        for v in current:
            data["videos"].setdefault(v["id"], {"video_id": v["id"], "title": v.get("title", ""), "url": v["url"],
                                                "channel_url": url, "platform": platform(url), "status": "old",
                                                "status_at": _now(), "first_seen_at": _now(), "attempts": 0})
        channel = {"url": url, "platform": platform(url), "kind": kind, "auto_post": bool(auto_post),
                   "enabled": True, "added": datetime.now().strftime("%Y-%m-%d %H:%M"), "last_checked": ""}
        data["channels"].append(channel)
        save(data)
    log(f"➕ {url} — video {len(current)} ခုကို အဟောင်းအဖြစ် မှတ်ထားပြီး အသစ်တွေကိုပဲ recap လုပ်မယ်")
    return channel


def remove_channel(url: str, kind: str) -> None:
    with _lock:
        data = load()
        data["channels"] = [c for c in data["channels"] if not (c["url"] == url and c.get("kind") == kind)]
        save(data)


def check_new(per_check: int = 2, log: Callable[[str], None] = print) -> list[dict[str, Any]]:
    """New videos of every enabled channel (newest first, at most per_check each): [{id, title, url, channel}]."""
    data = load()
    found = []
    for channel in data["channels"]:
        if not channel.get("enabled", True):
            continue
        try:
            videos = list_videos(channel["url"], channel.get("kind", "videos"), limit=15)
        except Exception as exc:  # noqa: BLE001 - one bad channel must not stop the others
            log(f"⚠️ {channel['url']}: {str(exc)[:160]}")
            continue
        new = [v for v in videos if eligible(data["videos"].get(v["id"]))][:per_check]
        if not new:
            # The master's old_unposted rule (2026-10-30, user): with nothing new, the newest video the channel
            # already had when it was added and that was never taken ("old") goes next, one per check.
            new = [v for v in videos if (data["videos"].get(v["id"]) or {}).get("status") == "old"][:1]
        for v in new:
            found.append({**v, "channel": channel})
        channel["last_checked"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    with _lock:
        fresh = load()
        for c in fresh["channels"]:
            match = next((x for x in data["channels"] if x["url"] == c["url"] and x.get("kind") == c.get("kind")), None)
            if match:
                c["last_checked"] = match["last_checked"]
        save(fresh)
    return found


def mark(video_id: str, status: str, **info: Any) -> dict[str, Any]:
    """Note a video's new state in the registry (info: title, url, channel_url, path, final …).
    Every download try counts as an attempt."""
    with _lock:
        data = load()
        entry = data["videos"].setdefault(str(video_id), {"video_id": str(video_id), "first_seen_at": _now(),
                                                          "attempts": 0})
        entry.update({k: v for k, v in info.items() if v is not None})
        entry.update(status=status, status_at=_now())
        if status == "downloading":
            entry["attempts"] = int(entry.get("attempts") or 0) + 1
        save(data)
        return dict(entry)


def register_found(item: dict[str, Any]) -> None:
    """A new video the auto mode takes now."""
    channel = item.get("channel") or {}
    mark(item["id"], "downloading", title=item.get("title", ""), url=item.get("url", ""),
         channel_url=channel.get("url", ""), platform=channel.get("platform") or platform(item.get("url", "")))


def resumable() -> list[dict[str, Any]]:
    """Videos downloaded (or being recapped) when the app last closed whose files are still there: the auto mode
    goes on with them instead of downloading again. [{id, title, url, path, channel}] oldest first."""
    data = load()
    channels = {c["url"]: c for c in data["channels"]}
    out = []
    for vid, entry in data["videos"].items():
        path = str(entry.get("path") or "")
        if entry.get("status") in ("downloaded", "recapping") and path and Path(path).is_file():
            out.append({"id": vid, "title": entry.get("title", ""), "url": entry.get("url", ""), "path": path,
                        "channel": channels.get(entry.get("channel_url", ""), {"url": entry.get("channel_url", "")}),
                        "at": entry.get("status_at", "")})
    return sorted(out, key=lambda x: x["at"])


def recent(limit: int = 40) -> list[dict[str, Any]]:
    """The newest registry entries that are not 'old' (shown in the Recap auto mode)."""
    rows = [dict(e, video_id=k) for k, e in load()["videos"].items() if e.get("status") != "old"]
    rows.sort(key=lambda e: str(e.get("status_at") or ""), reverse=True)
    return rows[:limit]
