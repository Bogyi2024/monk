"""Recap work folders (jobs): list them with their size and delete a whole job to free disk space.

A job folder holds everything one recap made (transcript, translations, voice parts, picture parts, the final in
edge_tts_smart_sync/) — often several GB. When the final was saved to the user's output folder ("Save final to"),
the job can go; a small `<job>.done.json` is kept so a batch run of the same folder still knows it is done."""
from __future__ import annotations

import json
import os
import shutil
import stat
import time
from pathlib import Path

FINAL_IN_JOB = Path("edge_tts_smart_sync") / "final_edge_tts_smart_sync.mp4"


def folder_size(path: Path) -> int:
    total = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(root, name))
            except OSError:
                pass
    return total


def human(size: float) -> str:
    for unit in ("B", "KB", "MB"):
        if size < 1024:
            return f"{size:.0f} {unit}"
        size /= 1024
    return f"{size:.1f} GB"


def done_marker(job_dir: Path) -> Path:
    return job_dir.parent / f"{job_dir.name}.done.json"


def saved_final(job_dir: Path) -> str:
    """The final saved outside the job (output folder), from the marker; "" when unknown or gone."""
    try:
        final = json.loads(done_marker(job_dir).read_text(encoding="utf-8")).get("final") or ""
    except (OSError, ValueError):
        return ""
    return final if final and Path(final).is_file() else ""


def mark_done(job_dir: Path, final: str, source: str = "") -> None:
    done_marker(job_dir).write_text(json.dumps({"final": final, "source": source,
                                                "at": time.strftime("%Y-%m-%d %H:%M")}, ensure_ascii=False),
                                    encoding="utf-8")


def list_jobs(jobs_dir: Path) -> list[dict]:
    jobs = []
    if not jobs_dir.is_dir():
        return jobs
    for job in jobs_dir.iterdir():
        if not job.is_dir():
            continue
        in_job = job / FINAL_IN_JOB
        jobs.append({
            "path": job,
            "name": job.name,
            "size": folder_size(job),
            "modified": job.stat().st_mtime,
            "final_in_job": str(in_job) if in_job.is_file() and in_job.stat().st_size > 10000 else "",
            "final_saved": saved_final(job),
        })
    return sorted(jobs, key=lambda j: j["modified"], reverse=True)


def _writable(func, path, _exc) -> None:
    os.chmod(path, stat.S_IWRITE)
    func(path)


def delete_job(jobs_dir: Path, job_dir: Path) -> None:
    """Delete one whole job folder. Only a folder directly inside jobs_dir is accepted."""
    jobs_dir, job_dir = jobs_dir.resolve(), job_dir.resolve()
    if job_dir.parent != jobs_dir or not job_dir.is_dir():
        raise ValueError(f"Not a job folder: {job_dir}")
    shutil.rmtree(job_dir, onerror=_writable)


def delete_download(downloads_dir: Path, source: str) -> bool:
    """A channel video downloaded by the app is deleted with its job (a user's own file never is)."""
    try:
        path = Path(source).resolve()
    except OSError:
        return False
    if path.parent == downloads_dir.resolve() and path.is_file():
        path.unlink()
        return True
    return False
