"""Long to Short (free): the user's long_to_short tool (copy in ../tool_apps/long_to_short) with a Studio99 screen.

The tool itself is a command line (run_long_to_short_test.py <video>): Whisper → Gemini picks the best standalone
moments of an ENGLISH long video → 9:16 clips in up to four versions. This screen picks the video (file or a
YouTube link), the content type, how many clips and which versions, runs it in its own process (Whisper/CUDA never
in the app), shows the log, copies the finished clips to the output folder and can put them on the Posting list."""
from __future__ import annotations

import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import keys_file
import posting_queue
import ui_thread
from lts_options import normalize_export_options

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "tool_apps" / "long_to_short"
CONFIG = ROOT / "lts_config.json"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

BG, SURFACE, SURFACE_2, FIELD, BORDER = "#0b0d12", "#141821", "#1b2030", "#0a0c10", "#2a3142"
FG, MUTED, ACCENT, GOLD = "#eef1f7", "#98a2b3", "#5b8cff", "#f5c451"

PROFILES = [("generic", "အထွေထွေ"), ("motivation", "Motivation"), ("psychology", "Psychology"), ("horror", "Horror"),
            ("crime", "Crime / Mystery"), ("knowledge", "Knowledge"), ("comedy", "Comedy"), ("business", "Business"),
            ("celebrity", "Celebrity"), ("tech_ai", "Tech / AI"), ("sports", "Sports")]
MODES = [("transformative_envo_mm", "English အသံအသစ် + မြန်မာ စာတန်း", "FINAL_ENVO_MM"),
         ("original_audio_mm", "မူရင်းအသံ + မြန်မာ စာတန်း", "ORIGINAL_AUDIO_MM"),
         ("transformative_envo_en", "English အသံအသစ် + English စာတန်း", "FINAL_ENVO_EN"),
         ("original_audio_en", "မူရင်းအသံ + English စာတန်း", "ORIGINAL_AUDIO_EN")]


def load_cfg() -> dict:
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def cuda_available() -> bool:
    try:
        import ctranslate2
        return ctranslate2.get_cuda_device_count() > 0
    except Exception:
        return False


def set_whisper_device(cuda: bool) -> None:
    """The tool reads Whisper's device from its own config: GPU when there is one, else CPU (int8)."""
    path = TOOL / "config" / "config.json"
    cfg = json.loads(path.read_text(encoding="utf-8"))
    device, compute = ("cuda", "float16") if cuda else ("cpu", "int8")
    changed = cfg.get("whisper_device") != device
    cfg["whisper_device"], cfg["whisper_compute_type"] = device, compute
    align = cfg.get("voiceover_subtitle_alignment") or {}
    if align:
        changed |= align.get("device") != device
        align["device"], align["compute_type"] = device, compute
    if changed:
        path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def finished_clips(run_dir: Path, modes: list[str]) -> list[Path]:
    tags = [tag for key, _label, tag in MODES if key in modes]
    return sorted(p for p in run_dir.glob("candidate_*_*.mp4") if any(p.stem.endswith(tag) for tag in tags))


class LongToShortView(tk.Frame):
    def __init__(self, master: tk.Misc, *, app) -> None:
        super().__init__(master, bg=BG)
        self.app = app
        self.cfg = load_cfg()
        self.proc: subprocess.Popen | None = None
        self.lines: queue.Queue[str] = queue.Queue()
        self.source = tk.StringVar(value=self.cfg.get("source", ""))
        self.profile = tk.StringVar(value=dict(PROFILES).get(self.cfg.get("profile", "generic"), "အထွေထွေ"))
        self.count = tk.StringVar(value=str(self.cfg.get("count", 3)))
        self.modes = {key: tk.BooleanVar(value=key in self.cfg.get("modes", ["transformative_envo_mm"]))
                      for key, _l, _t in MODES}
        self.out_folder = tk.StringVar(value=self.cfg.get("out_folder", ""))
        self.delete_work = tk.BooleanVar(value=bool(self.cfg.get("delete_work", True)))
        self.subtitles_enabled = tk.BooleanVar(value=self.cfg.get("subtitles_enabled", True))
        self.output_ratio = tk.StringVar(value=self.cfg.get("output_ratio", "9:16"))
        self.clip_minutes = tk.StringVar(value=str(self.cfg.get("clip_minutes") or ""))
        self.status = tk.StringVar(value="English video ရှည် (interview / podcast / talk) တစ်ခု ရွေးပါ")

        form = tk.Frame(self, bg=SURFACE, padx=22, pady=16)
        form.pack(fill="x", padx=24, pady=(18, 0))
        form.columnconfigure(1, weight=1)
        self._label(form, 0, "Video")
        ttk.Entry(form, textvariable=self.source).grid(row=0, column=1, sticky="ew", pady=4)
        ttk.Button(form, text="Browse", style="Compact.TButton", command=self._browse).grid(row=0, column=2, padx=(6, 0))
        tk.Label(form, text="ဖိုင် (သို့) YouTube link ထည့်လို့ရပါတယ်", bg=SURFACE, fg=MUTED,
                 font=("Myanmar Text", 8)).grid(row=1, column=1, sticky="w")
        self._label(form, 2, "အကြောင်းအရာ")
        row = tk.Frame(form, bg=SURFACE)
        row.grid(row=2, column=1, sticky="w", pady=4)
        ttk.Combobox(row, textvariable=self.profile, values=[label for _k, label in PROFILES], state="readonly",
                     width=22).pack(side="left")
        tk.Label(row, text="   Clip အရေအတွက်", bg=SURFACE, fg=FG, font=("Myanmar Text", 10)).pack(side="left")
        ttk.Spinbox(row, from_=1, to=8, textvariable=self.count, width=5).pack(side="left", padx=6)
        self._label(form, 3, "ထုတ်မယ့်ပုံစံ")
        modes = tk.Frame(form, bg=SURFACE)
        modes.grid(row=3, column=1, sticky="w", pady=4)
        for i, (key, label, _tag) in enumerate(MODES):
            tk.Checkbutton(modes, text=label, variable=self.modes[key], bg=SURFACE, fg=FG, selectcolor=FIELD,
                           activebackground=SURFACE, activeforeground=FG, font=("Myanmar Text", 10)).grid(
                row=i // 2, column=i % 2, sticky="w", padx=(0, 22))
        self._label(form, 4, "Video / စာတန်း")
        output = tk.Frame(form, bg=SURFACE)
        output.grid(row=4, column=1, sticky="w", pady=4)
        ttk.Combobox(output, textvariable=self.output_ratio, values=("9:16", "Original"), state="readonly", width=12).pack(side="left")
        tk.Checkbutton(output, text="စာတန်းထိုး ထည့်မယ်", variable=self.subtitles_enabled, bg=SURFACE, fg=FG,
                       selectcolor=FIELD, activebackground=SURFACE, font=("Myanmar Text", 9)).pack(side="left", padx=12)
        tk.Label(output, text="မိနစ် (လွတ်ထား = Auto)", bg=SURFACE, fg=FG, font=("Myanmar Text", 9)).pack(side="left")
        ttk.Spinbox(output, from_=.25, to=10, increment=.25, textvariable=self.clip_minutes, width=6).pack(side="left", padx=6)
        self._label(form, 5, "Output folder")
        ttk.Entry(form, textvariable=self.out_folder).grid(row=5, column=1, sticky="ew", pady=4)
        ttk.Button(form, text="Browse", style="Compact.TButton", command=self._browse_out).grid(row=5, column=2, padx=(6, 0))
        tk.Checkbutton(form, text="ပြီးရင် work files ဖျက် (output folder ထဲက clip တွေပဲ ချန်)", variable=self.delete_work,
                       bg=SURFACE, fg=FG, selectcolor=FIELD, activebackground=SURFACE, activeforeground=FG,
                       font=("Myanmar Text", 9)).grid(row=6, column=1, sticky="w")
        buttons = tk.Frame(form, bg=SURFACE)
        buttons.grid(row=7, column=1, sticky="w", pady=(10, 0))
        self.start_btn = ttk.Button(buttons, text="▶  Start", style="Accent.TButton", command=self._start)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(buttons, text="Stop", style="Danger.TButton", command=self._stop)
        self.stop_btn.pack(side="left", padx=8)
        self.stop_btn.state(["disabled"])
        tk.Label(buttons, textvariable=self.status, bg=SURFACE, fg=MUTED, font=("Myanmar Text", 9)).pack(side="left", padx=10)

        self.log = tk.Text(self, bg=FIELD, fg="#cfd6e4", insertbackground=FG, relief="flat", font=("Consolas", 9),
                           highlightthickness=1, highlightbackground=BORDER, wrap="word")
        self.log.pack(fill="both", expand=True, padx=24, pady=14)
        self._alive = True
        self.after(200, self._pump)

    @staticmethod
    def _label(form, row, text) -> None:
        tk.Label(form, text=text, bg=SURFACE, fg=FG, font=("Myanmar Text", 10)).grid(row=row, column=0, sticky="w",
                                                                                   padx=(0, 14))

    def _browse(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("Video", "*.mp4 *.mkv *.mov *.webm *.m4v"), ("All", "*.*")])
        if path:
            self.source.set(path)

    def _browse_out(self) -> None:
        folder = filedialog.askdirectory(title="Clip တွေ ထားမယ့် folder")
        if folder:
            self.out_folder.set(folder)

    def _write(self, text: str) -> None:
        self.log.insert("end", text if text.endswith("\n") else text + "\n")
        self.log.see("end")

    def _pump(self) -> None:
        if not self._alive:
            return
        try:
            while True:
                self._write(self.lines.get_nowait())
        except queue.Empty:
            pass
        self.after(200, self._pump)

    def _save_cfg(self, modes: list[str], profile: str, export: dict) -> None:
        self.cfg.update(source=self.source.get().strip(), profile=profile, count=int(self.count.get() or 3),
                        modes=modes, out_folder=self.out_folder.get().strip(), delete_work=self.delete_work.get())
        self.cfg.update(export)
        CONFIG.write_text(json.dumps(self.cfg, ensure_ascii=False, indent=2), encoding="utf-8")

    # ------------------------------------------------------------------ run
    def _start(self) -> None:
        source = self.source.get().strip().strip('"')
        modes = [k for k, v in self.modes.items() if v.get()]
        profile = next((k for k, label in PROFILES if label == self.profile.get()), "generic")
        if not source:
            self.status.set("Video ရွေးပါ")
            return
        if not modes:
            self.status.set("ထုတ်မယ့်ပုံစံ တစ်ခုခု ရွေးပါ")
            return
        try:
            export = normalize_export_options(self.subtitles_enabled.get(), self.output_ratio.get(), self.clip_minutes.get())
        except ValueError as exc:
            self.status.set(str(exc))
            return
        if not keys_file.gemini_keys():
            messagebox.showwarning("Gemini key", "Profile မှာ Gemini API key အရင်ထည့်ပါ။", parent=self)
            return
        is_link = bool(re.match(r"https?://", source))
        if not is_link and not Path(source).is_file():
            self.status.set("Video ဖိုင် မတွေ့ပါ")
            return
        try:
            count = max(1, min(8, int(self.count.get())))
        except ValueError:
            count = 3
        self.count.set(str(count))
        self._save_cfg(modes, profile, export)
        self.log.delete("1.0", "end")
        self.start_btn.state(["disabled"])
        self.stop_btn.state(["!disabled"])
        self.status.set("Run နေပါတယ်…")
        threading.Thread(target=self._run, args=(source, is_link, modes, profile, count,
                                                 self.out_folder.get().strip(), self.delete_work.get(), export),
                         daemon=True).start()

    def _run(self, source: str, is_link: bool, modes: list[str], profile: str, count: int, out_folder: str,
             delete_work: bool, export: dict | None = None) -> None:
        try:
            if is_link:
                self.lines.put("⬇️ YouTube video ကို download လုပ်နေပါတယ်…")
                import channel_source
                source = str(channel_source.download(source, log=self.lines.put))
            set_whisper_device(cuda_available())
            keys = keys_file.write()
            env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", LTS_OUTPUT_MODES=",".join(modes),
                       LTS_CONTENT_PROFILE=profile, LTS_CANDIDATE_COUNT=str(count),
                       RECAP_PERSONAL_DIR=str(keys.parent if keys else ""),
                       LTS_EXPORT_OPTIONS=json.dumps(export or normalize_export_options()))
            python = Path(sys.executable).with_name("python.exe")
            self.proc = subprocess.Popen([str(python if python.exists() else sys.executable), "-u", "-X", "utf8",
                                          "run_long_to_short_test.py", source], cwd=str(TOOL), env=env,
                                         stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                         text=True, encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
            run_dir = None
            for line in self.proc.stdout:
                self.lines.put(line.rstrip("\n"))
                found = re.search(r"DONE → (.+)$", line.strip())
                if found:
                    run_dir = Path(found.group(1).strip())
            code = self.proc.wait()
            if code != 0 or run_dir is None:
                ui_thread.post(lambda: self._done([], f"မပြီးပါ (exit {code}) — log ကိုကြည့်ပါ"))
                return
            clips = finished_clips(run_dir, modes)
            if out_folder:
                target = Path(out_folder)
                target.mkdir(parents=True, exist_ok=True)
                copied = []
                for clip in clips:
                    dest = target / f"{Path(source).stem[:60]}_{clip.stem.replace('candidate_', 'clip_')}.mp4"
                    shutil.copy2(clip, dest)
                    copied.append(dest)
                self.lines.put(f"📤 Clip {len(copied)} ခု → {target}")
                if delete_work:
                    shutil.rmtree(run_dir, ignore_errors=True)
                    self.lines.put("🧹 Work files ဖျက်ပြီးပါပြီ")
                clips = copied
            ui_thread.post(lambda: self._done(clips, f"ပြီးပါပြီ — clip {len(clips)} ခု"))
        except Exception as exc:  # noqa: BLE001
            self.lines.put(f"❌ {exc}")
            ui_thread.post(lambda e=exc: self._done([], f"❌ {str(e)[:120]}"))
        finally:
            self.proc = None

    def _done(self, clips: list[Path], text: str) -> None:
        if not self.winfo_exists():
            return
        self.start_btn.state(["!disabled"])
        self.stop_btn.state(["disabled"])
        self.status.set(text)
        if clips and self.app.session.is_vip_plus and messagebox.askyesno(
                "Auto Posting", f"Clip {len(clips)} ခုကို Auto Posting list ထဲ ထည့်မလား?\n"
                "(Auto Posting → Long to Short ကတ်ရဲ့ Page တွေက တင်ပါမယ်)", parent=self):
            for clip in clips:
                posting_queue.add(clip, caption=clip.stem, targets=[], origin="lts")
            self.status.set(text + " · Posting list ထဲ ထည့်ပြီး")

    def _stop(self) -> None:
        proc = self.proc
        if proc and proc.poll() is None:     # Whisper / FFmpeg children too
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True,
                           creationflags=NO_WINDOW)
            self.lines.put("⏹️ ရပ်လိုက်ပါပြီ")

    def shutdown(self) -> None:
        self._alive = False
        self._stop()
