"""Studio99.exe — the frozen entry point (build/build_exe.py, PyInstaller).

The exe is a Python runtime with every library the tools need; all Studio99 code stays as files beside it
(app/, engine/, tool_apps/, recap_tool_src/) because the tools start each other as separate processes with
`sys.executable script.py …` / `sys.executable -m module …`. So the exe answers like python.exe:

    Studio99.exe                         → the app (app/webapp.py)
    Studio99.exe [-X utf8] [-u] script.py args…   → run that script (its folder first on sys.path, as python does)
    Studio99.exe [-X utf8] [-u] -m module args…   → run that module (the current folder on sys.path)
    Studio99.exe -c "code"               → run code

Nothing else is needed in the tools: their `sys.executable` is this exe, and `python.exe` / `pythonw.exe` next to
it don't exist, so every launcher in the code falls back to sys.executable."""
from __future__ import annotations

import os
import runpy
import sys
from pathlib import Path


def base_dir() -> Path:
    """The installed folder (the exe's folder; the repository root when run from source)."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


def quiet_children() -> None:
    """The exe is windowed, so its processes (the posting engine, Recap's workers …) have no console, and every
    console program they start — FFmpeg, ffprobe, Playwright's node.exe, yt-dlp — opened its own black window: the
    user saw terminals pop up again and again (2026-10-31). A child that chose no console option gets none.
    The app window and the Tk tools already did this (embed_hook.py); this covers every process of the exe."""
    if os.name != "nt":
        return
    import subprocess
    if getattr(subprocess.Popen.__init__, "_studio99_quiet", False):
        return
    choices = subprocess.CREATE_NEW_CONSOLE | subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS
    popen_init = subprocess.Popen.__init__

    def quiet_init(self, *args, **kwargs):
        flags = kwargs.get("creationflags", 0) or 0
        if not flags & choices:
            kwargs["creationflags"] = flags | subprocess.CREATE_NO_WINDOW
        popen_init(self, *args, **kwargs)
    quiet_init._studio99_quiet = True
    subprocess.Popen.__init__ = quiet_init


def _setup_env(base: Path) -> None:
    quiet_children()
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    if os.environ.get("STUDIO99_TOOL_ID"):     # a copied tool or one of its workers: Studio99's encode speed
        try:                                    # (the frozen runtime does not run sitecustomize itself)
            sys.path.append(str(base / "app"))
            import ffmpeg_speed
            ffmpeg_speed.install()
        except Exception:  # noqa: BLE001 - never stops the tool
            pass
    ffmpeg = base / "recap_tool_src" / "ffmpeg"
    if ffmpeg.is_dir() and str(ffmpeg) not in os.environ.get("PATH", ""):
        os.environ["PATH"] = str(ffmpeg) + os.pathsep + os.environ.get("PATH", "")
    extras = base / "ai_extras" / "site"                    # torch + torchaudio, downloaded on first use (ai_extras.py)
    if extras.is_dir() and str(extras) not in sys.path:
        sys.path.append(str(extras))                        # after the exe's own libraries: those always win
    browsers = base / "ms-playwright"
    if browsers.is_dir():
        os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", str(browsers))
    for stream in ("stdout", "stderr"):                     # a windowed exe has no console: keep print() working
        if getattr(sys, stream) is None:
            setattr(sys, stream, open(os.devnull, "w", encoding="utf-8"))
        else:
            # The frozen runtime ignores PYTHONUTF8 / PYTHONIOENCODING, so a worker's stdout to a pipe or log file was
            # cp1252 and the first emoji print killed it (2026-10-30: Recap's planner_worker died on "🌐", every
            # Recap in the exe failed). UTF-8 here, for this process and every child (each one starts here too).
            try:
                getattr(sys, stream).reconfigure(encoding="utf-8", errors="replace")
            except (AttributeError, ValueError, OSError):
                pass


def _python_like(argv: list[str]) -> bool:
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-X", "-W"):
            i += 2
            continue
        if a in ("-u", "-B", "-E", "-s", "-I", "-O", "-OO"):
            i += 1
            continue
        return a in ("-m", "-c") or a.lower().endswith((".py", ".pyc", ".pyw"))
    return False


def run_python_like(argv: list[str]) -> None:
    i = 0
    while i < len(argv) and argv[i].startswith("-") and argv[i] not in ("-m", "-c"):
        i += 2 if argv[i] in ("-X", "-W") else 1
    rest = argv[i:]
    if rest[0] == "-c":
        sys.argv = ["-c", *rest[2:]]
        exec(compile(rest[1], "<string>", "exec"), {"__name__": "__main__"})
        return
    if rest[0] == "-m":
        sys.argv = [rest[1], *rest[2:]]
        sys.path.insert(0, os.getcwd())
        runpy.run_module(rest[1], run_name="__main__", alter_sys=True)
        return
    script = Path(rest[0]).resolve()
    sys.argv = [str(script), *rest[1:]]
    sys.path.insert(0, str(script.parent))
    runpy.run_path(str(script), run_name="__main__")


def main() -> None:
    base = base_dir()
    _setup_env(base)
    argv = sys.argv[1:]
    if argv and _python_like(argv):
        try:
            run_python_like(argv)
        except SystemExit:
            raise
        except BaseException:                             # like python: traceback on stderr, exit 1 — a windowed
            import traceback                              # exe would otherwise pop a message box per failed worker
            traceback.print_exc()
            sys.exit(1)
        return
    sys.argv = [str(base / "app" / "webapp.py"), *argv]
    sys.path.insert(0, str(base / "app"))
    os.chdir(base / "app")
    runpy.run_path(str(base / "app" / "webapp.py"), run_name="__main__")


if __name__ == "__main__":
    main()
