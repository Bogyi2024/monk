Burma020-Thin.ttf is the original Burma- 020 Thin font supplied by the user
for inclusion in Studio99's installer. It is copied without modification.
Copyright (c) 2022 by Moezed. All rights reserved.

The embedded font family is "Burma- 020 Thin" (including the space after the hyphen).
Dubbing loads this file directly for video export and privately in its own
process for the preview. It does not require a separate Windows font installation.
The neighboring OFL.txt applies to the Noto/Studio99 Myanmar fonts, not this font.
File identity and provenance are recorded in dubbing_font.json.
