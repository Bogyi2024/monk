"""Post captions the TT master's way (recap_auto_scheduler.build_caption / ensure_plan_title; 2026-10-30, user: take
its logic — the first test post went out with the English YouTube title as its whole caption).

Gemini writes a Burmese title, a short caption and hashtags from the finished narration. The caption is
title + caption + at most five hashtags; the uploader adds the platform's own tag (#viralreel / #fyp) within the
same five. When Gemini cannot be reached the master's title chain is used: source title → first narration line →
a generic line, so a post is never blocked by its caption."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Callable

GENERIC_TITLE = "ဒီဇာတ်လမ်းမှာ ဘာတွေဖြစ်သွားတာလဲ"
MAX_TAGS = 5
MAX_CHARS = 2200
_TAG_RE = re.compile(r"(?<![\w#])#[^\s#]+", re.UNICODE)


def narration(job: Path, limit: int = 80) -> list[str]:
    """The finished video's narration lines (smart_sync_plan.json), first `limit` of them."""
    try:
        plan = json.loads((Path(job) / "smart_sync_plan.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    lines = [str(s.get("narration") or s.get("translation") or "").strip() for s in plan.get("segments") or []]
    return [x for x in lines if x][:limit]


def clean_source_title(title: str) -> str:
    """A YouTube title without its hashtags and the "[video id]" a download adds."""
    title = _TAG_RE.sub("", str(title or ""))
    title = re.sub(r"\[[A-Za-z0-9_-]{6,}\]", "", title)
    return re.sub(r"\s{2,}", " ", title).strip(" -|·")


def prompt(lines: list[str], source_title: str) -> str:
    story = "\n".join(lines)
    return (
        "You write the Facebook Reel / TikTok post for a Burmese recap video.\n"
        f"Original video title: {clean_source_title(source_title) or '(none)'}\n"
        f"Burmese narration of the video:\n{story}\n\n"
        "Return JSON only: {\"title\": \"...\", \"caption\": \"...\", \"hashtags\": [\"#...\"]}\n"
        "- title: a short Burmese hook title (at most 60 letters), natural spoken Burmese, no hashtags, "
        "no quotation marks, no emoji wall.\n"
        "- caption: 1-2 Burmese sentences that make people want to watch, without giving away the ending. "
        "No hashtags inside it.\n"
        "- hashtags: 3-4 relevant tags without spaces (Burmese or English), e.g. #recap #movie. "
        "Do not include #viralreel or #fyp (added later).\n"
        "Write names in Burmese script. Do not use the polite endings ခင်ဗျာ / ရှင်."
    )


def build(plan: dict, source_title: str, lines: list[str]) -> str:
    """title + caption + hashtags (unique, at most MAX_TAGS), like the master's build_caption."""
    title = str(plan.get("title") or "").strip()
    if not title:                                         # the master's ensure_plan_title chain
        title = clean_source_title(source_title) or (lines[0] if lines else "") or GENERIC_TITLE
    body = _TAG_RE.sub("", str(plan.get("caption") or "")).strip()
    tags, seen = [], set()
    for raw in plan.get("hashtags") or []:
        for token in str(raw).split():
            tag = token if token.startswith("#") else f"#{token}"
            if len(tag) > 1 and tag.casefold() not in seen:
                seen.add(tag.casefold())
                tags.append(tag)
    parts = [title] + ([body] if body and body != title else []) + ([" ".join(tags[:MAX_TAGS])] if tags else [])
    caption = "\n\n".join(parts).strip()
    return caption if len(caption) <= MAX_CHARS else caption[:MAX_CHARS - 1].rstrip() + "…"


def make(lines: list[str], source_title: str, keys: list[str], log: Callable[[str], None] = print) -> str:
    """The post caption; Gemini when it answers, else the fallback title alone."""
    plan: dict = {}
    if lines and keys:
        try:
            from story_motion.gemini_client import ask_json
            answer = ask_json(prompt(lines, source_title), keys, temperature=0.7, log=log, max_output_tokens=2000)
            plan = answer if isinstance(answer, dict) else {}
        except Exception as exc:  # noqa: BLE001 - a caption never stops a post
            log(f"⚠️ Caption ကို Gemini နဲ့ မရေးနိုင်ပါ — title ပဲ သုံးပါမယ် ({str(exc)[:120]})")
    return build(plan, source_title, lines)
