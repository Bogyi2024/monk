"""Free accounts share three successful exports per UTC day across all free tools.

Reservations prevent simultaneous windows exceeding the allowance. Failed/cancelled
jobs release their slot; reservations left by an exited process are recovered.
This is local Desktop enforcement, not a cross-device PocketBase quota service.
"""
from __future__ import annotations

from contextlib import closing, contextmanager
import hashlib
import os
from pathlib import Path
import sqlite3
import uuid

import local_mode
import psutil
from token_store import APP_DIR

FILE = APP_DIR / "usage" / "daily.sqlite3"
LIMIT = 3
FREE_TOOLS = {"recap", "splitter", "long_to_short", "novel", "download"}


@contextmanager
def free_job(tool, session=None):
    if tool not in FREE_TOOLS:
        raise ValueError("Daily allowance is only for free tools")
    if local_mode.enabled():                   # offline developer mode: no daily allowance
        yield
        return
    if session is None:
        from membership_access import desktop_context, current_session
        if not desktop_context():
            yield  # standalone source media fixtures, outside Studio99
            return
        session = current_session()
    if session is None:
        raise RuntimeError("Login ပြန်ဝင်ပါ။")
    if session.is_vip:
        yield  # paid members retain unlimited base-tool benefits
        return
    with reserve(session):
        yield


def _identity(session):
    from app_config import load_config
    user = str(session.user.get("id") or "")
    if not user:
        raise RuntimeError("Login ပြန်ဝင်ပါ။")
    server = os.environ.get("STUDIO99_SERVER") or load_config().get("server") or "https://api.recapboxx.com"
    return hashlib.sha256((server.rstrip("/") + "/" + user).encode()).hexdigest()


def _connect():
    FILE.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(FILE, timeout=15, isolation_level=None)
    db.execute("""create table if not exists usage (
        account text not null, day text not null, job text primary key,
        status text not null, pid integer not null, born real not null)""")
    return db


def _live(pid, born):
    try:
        return abs(psutil.Process(pid).create_time() - born) < 1
    except psutil.NoSuchProcess:
        return False
    except psutil.AccessDenied:
        return True


@contextmanager
def reserve(session):
    """Commit one successful export job; a batch operation's selected outputs share its slot."""
    account, day = _identity(session), session.server_now().strftime("%Y-%m-%d")
    job = uuid.uuid4().hex
    db = _connect()
    try:
        db.execute("begin immediate")
        for old, pid, born in db.execute("select job,pid,born from usage where status='reserved'").fetchall():
            if not _live(pid, born):
                db.execute("delete from usage where job=? and status='reserved'", (old,))
        used = db.execute("select count(*) from usage where account=? and day=?", (account, day)).fetchone()[0]
        if used >= LIMIT:
            raise RuntimeError("Free tools ဒီနေ့အတွက် စုစုပေါင်း ၃ ပုဒ် ပြည့်ပါပြီ။ နောက်နေ့ UTC 00:00 (မြန်မာ 06:30) မှ ပြန်သုံးနိုင်ပါမယ်။ VIP ဝယ်ထားရင် အကန့်အသတ်မရှိ သုံးနိုင်ပါတယ်။")
        db.execute("insert into usage values(?,?,?,?,?,?)", (account, day, job, "reserved", os.getpid(),
                                                            psutil.Process().create_time()))
        db.commit()
    except BaseException:
        db.rollback()
        raise
    finally:
        db.close()
    try:
        yield
    except BaseException:
        with closing(_connect()) as db:
            db.execute("delete from usage where job=? and status='reserved'", (job,))
        raise
    else:
        with closing(_connect()) as db:
            db.execute("update usage set status='complete' where job=?", (job,))


def status(session):
    if local_mode.enabled():
        return {"unlimited": True, "limit": None, "used": 0, "remaining": None, "reset": ""}
    if session.is_vip:
        return {"unlimited": True, "limit": None, "used": 0, "remaining": None, "reset": ""}
    account, day = _identity(session), session.server_now().strftime("%Y-%m-%d")
    with closing(_connect()) as db:
        used = db.execute("select count(*) from usage where account=? and day=?", (account, day)).fetchone()[0]
    return {"unlimited": False, "limit": LIMIT, "used": used, "remaining": max(0, LIMIT - used), "day": day, "reset": "00:00 UTC"}
