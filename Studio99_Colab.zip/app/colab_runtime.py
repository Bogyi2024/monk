"""Headless Recap job runner used only by Studio99's Colab web mode.

The existing planner_worker.py and render_worker.py remain the processing engine;
this module replaces only the Tkinter controller shell.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import uuid
from pathlib import Path
from typing import Any

APP = Path(__file__).resolve().parent
ROOT = APP.parent
RECAP = ROOT / "recap_tool_src"
RECAP_APP = RECAP / "app"
RUNTIME = RECAP / "recap_runtime"
DATA = Path(os.environ.get("STUDIO99_COLAB_DATA", "/content/Studio99Data")).resolve()
UPLOADS = DATA / "uploads"
JOBS = DATA / "recap_jobs"
OUTPUTS = DATA / "outputs"
TMP = DATA / "tmp" / "recap"
CONFIG = ROOT / "recap_config.json"
_EVENT = "@@VRS_EVENT@@"
_LANGUAGES = {
    "auto": "Auto-detect", "en": "English", "zh": "Chinese", "hi": "Hindi", "ko": "Korean",
    "ja": "Japanese", "th": "Thai", "vi": "Vietnamese", "id": "Indonesian", "ms": "Malay",
    "tl": "Filipino (Tagalog)", "es": "Spanish", "pt": "Portuguese", "fr": "French", "de": "German",
    "it": "Italian", "ru": "Russian", "tr": "Turkish", "ar": "Arabic", "bn": "Bengali",
    "ta": "Tamil", "te": "Telugu", "ur": "Urdu",
}


def _read_config() -> dict:
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _binary(name: str) -> str:
    found = shutil.which(name)
    if found:
        return found
    bundled = RECAP / "ffmpeg" / name
    return str(bundled) if bundled.is_file() else name


def _within_colab(path: Path) -> bool:
    resolved = path.expanduser().resolve()
    data_root = Path(os.environ.get("STUDIO99_COLAB_DATA", "/content/Studio99Data")).expanduser().resolve()
    allowed = [Path("/content").resolve(), Path("/kaggle/working").resolve(), Path("/kaggle/input").resolve(), Path("/kaggle/temp").resolve(), data_root, ROOT.resolve()]
    return any(resolved == base or base in resolved.parents for base in allowed)


def _validate_source(path_value: str) -> Path:
    if not path_value or len(path_value) > 4096:
        raise ValueError("Video path ကို ထည့်ပါ။")
    path = Path(path_value).expanduser().resolve()
    if not _within_colab(path):
        raise ValueError("Colab ထဲက /content သို့မဟုတ် Google Drive path ကိုသာ သုံးနိုင်ပါတယ်။")
    if not path.is_file() or path.suffix.lower() not in {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v"}:
        raise ValueError("ဖတ်လို့ရတဲ့ video file (mp4/mkv/mov/webm/avi/m4v) ကို ရွေးပါ။")
    return path


def _config_values() -> dict:
    cfg = _read_config()
    return {
            "translation_batch_max_items": int(cfg.get("translation_batch_max_items", 20)),
            "story_context_batch_max_items": int(cfg.get("story_context_batch_max_items", 80)),
            "context_overlap": int(cfg.get("context_overlap", 6)),
            "lookahead": int(cfg.get("lookahead", 6)),
            "translation_audit": bool(cfg.get("translation_audit", True)),
            "atomic_max_duration": float(cfg.get("atomic_max_duration", 5.6)),
            "atomic_target_duration": float(cfg.get("atomic_target_duration", 4.2)),
            "gemini_request_timeout_seconds": int(cfg.get("gemini_request_timeout_seconds", 180)),
            "gemini_text_model": str(cfg.get("gemini_text_model", "gemini-3.5-flash-lite")),
            "whisper_model_other": str(cfg.get("whisper_model_other", "medium")),
            "edge_tts_rate": str(cfg.get("edge_tts_rate", "+0%")),
            "gemini_direction": str(cfg.get("gemini_direction", "storyteller")),
            "short_pauses": bool(cfg.get("short_pauses", True)),
            "auto_blur_original_subtitles": bool(cfg.get("auto_blur_original_subtitles", True)),
        }



class ColabRecapJobs:
    def __init__(self, emit):
        self.emit = emit
        self.lock = threading.RLock()
        self.current: dict[str, Any] | None = None
        self.process: subprocess.Popen | None = None
        self.stop_file: Path | None = None
        self.thread: threading.Thread | None = None
        self._logs: list[str] = []

    def options(self) -> dict:
        if str(RECAP_APP) not in sys.path:
            sys.path.insert(0, str(RECAP_APP))
        cfg = _read_config()
        try:
            from gemini_narrator import VOICES
            gemini_voices = [f"gemini:{name}" for name, _gender in VOICES]
        except Exception:
            gemini_voices = ["gemini:Charon"]
        try:
            from recap_planner import SOURCE_LANGUAGES, STYLE_PRESETS
            languages = {"auto": "Auto-detect", **SOURCE_LANGUAGES}
            style_presets = {key: value[0] for key, value in STYLE_PRESETS.items()}
        except Exception:
            languages, style_presets = _LANGUAGES, {}
        return {
            "languages": languages,
            "style_presets": style_presets,
            "voices": [
                "my-MM-ThihaNeural", "my-MM-NilarNeural", *gemini_voices,
                "voxcpm2:male_narrator", "voxcpm2:female_narrator",
                "voxcpm2:male_dramatic", "voxcpm2:female_warm",
                "voxcpm2:clone", "voxcpm2:design", "voxcpm2:auto",
            ],
            "ratios": ["Original", "16:9", "9:16", "1:1"],
            "qualities": ["1080", "720", "480"],
            "defaults": {
                "source_language": cfg.get("source_language", "auto"),
                "voice": cfg.get("narrator_voice", cfg.get("edge_tts_voice_mm", "gemini:Charon")),
                "output_ratio": cfg.get("output_ratio", "Original"),
                "quality": str(cfg.get("video_quality", "1080")).removesuffix("p"),
                "subtitles": bool((cfg.get("subtitles") or {}).get("enabled", True)),
                "frame_fill": cfg.get("frame_fill", "blur"),
                "reuse_transcript_and_plan": bool(cfg.get("reuse_transcript_and_plan", True)),
                "narration_style": cfg.get("narration_style") or {"mode": "original"},
                "mirror_video": bool(cfg.get("mirror_video", True)),
                "zoom_factor": float(cfg.get("zoom_factor", 1.05)),
                "voice_volume_percent": int(cfg.get("voice_volume_percent", 100)),
                "short_pauses": bool(cfg.get("short_pauses", True)),
                "auto_blur_original_subtitles": bool(cfg.get("auto_blur_original_subtitles", True)),
                "gemini_direction": str(cfg.get("gemini_direction", "storyteller")),
                "subtitles_style": cfg.get("subtitles") or {},
                "subtitle_width": float((cfg.get("subtitles") or {}).get("width", .86)),
                "subtitle_position": (cfg.get("subtitles") or {}).get("position", [.5, .92]),
                "style_presets": style_presets,
                "edge_tts_rate": str(cfg.get("edge_tts_rate", "+0%")),
                "edge_tts_pitch": str(cfg.get("edge_tts_pitch", "+0Hz")),
                "max_video_speed": float(cfg.get("max_video_speed", 1.25)),
                "max_video_slow": float(cfg.get("max_video_slow", 1.35)),
                "smooth_freeze_fallback": bool(cfg.get("smooth_freeze_fallback", False)),
                "max_freeze_hold": float(cfg.get("max_freeze_hold", .75)),
                "final_output_folder": str(cfg.get("final_output_folder", "")),
                "logo_enabled": bool(cfg.get("logo_enabled", False)), "logo_path": str(cfg.get("logo_path", "")),
                "logo_width_fraction": float(cfg.get("logo_width_fraction", .16)), "logo_opacity": float(cfg.get("logo_opacity", .65)),
                "logo_position": cfg.get("logo_position", [.8, .06]),
                "title_text": str(cfg.get("title_text", "")), "title_font_size": int(cfg.get("title_font_size", 54)),
                "title_position": cfg.get("title_position", [.5, .12]),
                "extra_text": str(cfg.get("extra_text", "")), "extra_text_font_size": int(cfg.get("extra_text_font_size", 42)),
                "extra_text_position": cfg.get("extra_text_position", [.5, .84]),
                "extra_text_opacity": float(cfg.get("extra_text_opacity", .65)),
                "overlay_blur_strength": int(cfg.get("overlay_blur_strength", 18)),
                "run_mode": str(cfg.get("run_mode", "auto")),
                "delete_work_after": bool(cfg.get("delete_work_after", True)),
                "voxcpm_ref_audio": str(cfg.get("voxcpm_ref_audio", "")),
                "voxcpm_prompt_text": str(cfg.get("voxcpm_prompt_text", "")),
                "voxcpm_design": str(cfg.get("voxcpm_design", "")),
                "voxcpm_steps": int(cfg.get("voxcpm_steps", 0)),
            },
            "gpu": self.gpu_status(),
        }

    _GPU_CACHE: dict | None = None

    @classmethod
    def gpu_status(cls) -> dict:
        if cls._GPU_CACHE is not None:
            return dict(cls._GPU_CACHE)
        try:
            out = subprocess.run(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                                 capture_output=True, text=True, timeout=5)
            gpus = [ln.strip() for ln in out.stdout.splitlines() if ln.strip()] if out.returncode == 0 else []
            name = f"{gpus[0]} x{len(gpus)}" if len(gpus) > 1 else (gpus[0] if gpus else "")
        except Exception:
            gpus, name = [], ""
        cuda = bool(gpus)
        cls._GPU_CACHE = {"name": name, "cuda": cuda, "ctranslate2": "cuda" if cuda else "",
                          "message": "faster-whisper GPU (CUDA) အဆင်သင့်" if cuda else "GPU မတွေ့/ CUDA library မတင်ရသေး — Whisper CPU fallback သုံးနိုင်ပါတယ်"}
        return dict(cls._GPU_CACHE)

    def status(self) -> dict:
        with self.lock:
            out = dict(self.current) if self.current else {
                "status": "idle", "progress": 0, "stage": "", "job_id": "", "output": "", "error": ""}
            out["logs"] = self._logs[-180:]
            out["gpu"] = self.gpu_status()
            return out

    def start(self, request: dict, quota_ctx=None) -> dict:
        if not isinstance(request, dict):
            raise ValueError("Settings မမှန်ပါ။")
        sources_value = request.get("source_paths")
        if isinstance(sources_value, list) and sources_value:
            if len(sources_value) > 100:
                raise ValueError("Folder batch ကို 100 video ထက်မပိုစေပါနှင့်။")
            sources = [_validate_source(str(x)) for x in sources_value]
        else:
            sources = [_validate_source(str(request.get("source_path") or ""))]
        source = sources[0]
        cfg = _read_config()
        voice = str(request.get("voice") or cfg.get("narrator_voice") or "gemini:Charon")
        language = str(request.get("source_language") or "auto").lower()
        ratio = str(request.get("output_ratio") or "Original")
        quality = str(request.get("quality") or "1080")
        if language not in _LANGUAGES:
            raise ValueError("Source language မမှန်ပါ။")
        if voice not in self.options()["voices"]:
            raise ValueError("Narrator voice မမှန်ပါ။")
        if ratio not in {"Original", "16:9", "9:16", "1:1"} or quality not in {"1080", "720", "480"}:
            raise ValueError("Output settings မမှန်ပါ။")
        final_output_folder = str(request.get("final_output_folder") or "").strip()
        safe_batch = isinstance(request.get("source_paths"), list) and len(request.get("source_paths") or []) > 1
        if safe_batch:
            final_output_folder = str(Path(final_output_folder) if final_output_folder else OUTPUTS)
        if final_output_folder:
            dest = Path(final_output_folder).expanduser().resolve()
            if not _within_colab(dest):
                raise ValueError("Final output folder ကို /content အောက်မှာထားပါ။")
            dest.mkdir(parents=True, exist_ok=True)
        title_text = str(request.get("title_text", cfg.get("title_text", "")) or "").strip()
        extra_text = str(request.get("extra_text", cfg.get("extra_text", "")) or "").strip()
        logo_path = str(request.get("logo_path", cfg.get("logo_path", "")) or "").strip()
        logo_enabled = bool(request.get("logo_enabled", cfg.get("logo_enabled", False)))
        if logo_enabled and not logo_path:
            raise ValueError("Logo ကိုရွေးပါ သို့မဟုတ် logo option ကို ပိတ်ပါ။")
        for path_text in (logo_path,):
            if path_text:
                p = Path(path_text).expanduser().resolve()
                if not _within_colab(p) or not p.is_file():
                    raise ValueError("Logo path must point to an uploaded image under /content.")
        with self.lock:
            if self.current and self.current.get("status") in {"starting", "running", "stopping"}:
                raise RuntimeError("Recap job တစ်ခု လုပ်နေဆဲပါ။")
            job_id = uuid.uuid4().hex
            import colab_recap_ui
            job_dir = colab_recap_ui.job_dir(source)
            job_dir.mkdir(parents=True, exist_ok=True)
            self.stop_file = job_dir / ".stop_requested"
            self.stop_file.unlink(missing_ok=True)
            self._logs = []
            self.current = {"status": "starting", "progress": 0, "stage": "Preparing", "job_id": job_id,
                            "source": source.name, "sources": [str(x) for x in sources], "source_index": 0,
                            "job_dir": str(job_dir), "output": "", "outputs": [], "error": ""}
            self.thread = threading.Thread(target=self._run, args=(job_id, sources, job_dir, dict(request),
                                                                  voice, language, ratio, quality, quota_ctx), daemon=True)
            self.thread.start()
            return {"job_id": job_id, "status": "starting"}

    def stop(self) -> dict:
        with self.lock:
            if self.current and self.current.get("status") in {"starting", "running"}:
                self.current["status"] = "stopping"
                self.current["stage"] = "Stopping at a safe checkpoint"
                if self.stop_file:
                    self.stop_file.write_text("stop", encoding="utf-8")
            return dict(self.current or {"status": "idle"})

    def download_path(self, job_id: str) -> Path:
        with self.lock:
            cur = self.current
            if not cur or cur.get("job_id") != job_id or cur.get("status") != "done":
                raise FileNotFoundError("ဒီ Recap output ကို ရှာမတွေ့ပါ။")
            path = Path(cur["output"]).resolve()
        if not _within_colab(path) or not path.is_file():
            raise FileNotFoundError("Output ဖိုင် မတွေ့ပါ။")
        return path

    def _say(self, job_id: str, text: str) -> None:
        text = str(text).rstrip()
        if not text:
            return
        with self.lock:
            if self.current and self.current.get("job_id") == job_id:
                self._logs.append(text)
                self._logs = self._logs[-500:]
        self.emit("recap_log", job_id=job_id, line=text)

    def _progress(self, job_id: str, stage: str, current: int, total: int, label: str) -> None:
        pct = max(0, min(100, int(current * 100 / total))) if total > 0 else 0
        with self.lock:
            if not self.current or self.current.get("job_id") != job_id:
                return
            self.current.update(status="running", stage=f"{stage}: {label}", progress=pct)
        self.emit("recap_progress", job_id=job_id, stage=stage, progress=pct, label=label)

    def _copy_srt(self, rendered: dict, current_job: Path, final_video: Path, job_id: str) -> None:
        raw_result = rendered.get("result") or {}
        srt_value = str(raw_result.get("srt") or "")
        if not srt_value:
            try:
                plan_value = json.loads((current_job / "smart_sync_plan.json").read_text(encoding="utf-8"))
                srt_value = str(plan_value.get("subtitle_srt") or "")
            except (OSError, ValueError):
                srt_value = ""
        if srt_value and Path(srt_value).is_file():
            target = final_video.parent / "SRT_for_upload" / f"{final_video.stem}.srt"
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(srt_value, target)
            self._say(job_id, f"📝 SRT saved: {target}")

    def _worker(self, job_id: str, script: str, data: dict, stage: str, worker_dir: Path) -> dict:
        safe_stage = re.sub(r"[^A-Za-z0-9_-]+", "_", stage)
        cfg_path = worker_dir / f"_{safe_stage}.json"
        cfg_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        env = dict(
            os.environ,
            PYTHONUTF8="1",
            PYTHONIOENCODING="utf-8",
            MALLOC_ARENA_MAX="2",
            PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True",
            TOKENIZERS_PARALLELISM="false",
        )
        proc = subprocess.Popen([sys.executable, "-u", str(RECAP_APP / script), str(cfg_path)], cwd=str(RECAP),
                                env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, encoding="utf-8", errors="replace", bufsize=1)
        with self.lock:
            if self.current and self.current.get("job_id") == job_id:
                self.process = proc
        result, error, stop_message = {}, "", ""
        try:
            assert proc.stdout is not None
            for raw in proc.stdout:
                line = raw.rstrip("\r\n")
                if line.startswith(_EVENT):
                    try:
                        event = json.loads(line[len(_EVENT):])
                    except ValueError:
                        self._say(job_id, line); continue
                    kind = event.get("kind")
                    if kind == "log":
                        self._say(job_id, event.get("text", ""))
                    elif kind == "progress":
                        self._progress(job_id, stage, int(event.get("current", 0)), int(event.get("total", 0)),
                                       str(event.get("label", stage)))
                    elif kind == "result":
                        result = event
                    elif kind == "error":
                        error = str(event.get("message", ""))
                    elif kind == "stopped":
                        stop_message = str(event.get("message", "Stopped"))
                else:
                    self._say(job_id, line)
            code = proc.wait()
        finally:
            with self.lock:
                if self.process is proc:
                    self.process = None
        if code == 10 or stop_message:
            raise InterruptedError(stop_message or "Stopped safely")
        if code != 0:
            raise RuntimeError(error or f"{stage} worker exited with code {code}")
        return result

    def _run(self, job_id: str, sources: list[Path], job_dir: Path, request: dict,
             voice: str, language: str, ratio: str, quality: str, quota_ctx=None) -> None:
        quota_entered = False
        current_source = sources[0]
        final_output_folder = str(request.get("final_output_folder") or "").strip()
        safe_batch = len(sources) > 1
        reuse_plan = bool(request.get("reuse_transcript_and_plan", True))
        title_text = str(request.get("title_text") or "").strip()
        extra_text = str(request.get("extra_text") or "").strip()
        logo_path = str(request.get("logo_path") or "").strip()
        try:
            if quota_ctx is not None:
                quota_ctx.__enter__()
                quota_entered = True
            import keys_file
            env_file = keys_file.write()
            if not env_file or not keys_file.gemini_keys():
                raise RuntimeError("Profile ထဲမှာ Gemini API key ထည့်ပြီး Save လုပ်ပါ။")
            ffmpeg, ffprobe = _binary("ffmpeg"), _binary("ffprobe")
            for binary in (ffmpeg, ffprobe):
                if not shutil.which(binary) and not Path(binary).is_file():
                    raise FileNotFoundError(f"{binary} မတွေ့ပါ — Colab setup cell ကို ပြန် run ပါ။")
            runtime_cfg = RUNTIME / "config" / "whisper.json"
            runtime_cfg.parent.mkdir(parents=True, exist_ok=True)
            runtime_cfg.write_text(json.dumps({"whisper_backend": "faster-whisper", "whisper_device": "cuda",
                                               "whisper_compute_type": "float16"}, indent=2), encoding="utf-8")
            defaults = _read_config()
            if safe_batch and len(sources) > 1:
                common_folder = Path(final_output_folder) if final_output_folder else OUTPUTS
                final_output_folder = str(common_folder / f"Recap_Batch_{job_id[:8]}")
                Path(final_output_folder).mkdir(parents=True, exist_ok=True)
            requested_subtitles = request.get("subtitles_style") or (request.get("overlays") or {}).get("subtitles") or defaults.get("subtitles") or {}
            subtitle_style = dict(requested_subtitles)
            subtitle_style["enabled"] = bool(request.get("subtitles", subtitle_style.get("enabled", True)))
            subtitle_style["width"] = min(1.0, max(.2, float(request.get("subtitle_width", subtitle_style.get("width", .86)))))
            subtitle_style["position"] = request.get("subtitle_position", subtitle_style.get("position", [.5, .92]))
            import colab_recap_ui
            editor = colab_recap_ui.load_editor(str(current_source)) if current_source else {}
            editor.update(request.get("overlays") or {})
            editor.update(request.get("editor_overlays") or {})
            overlays = {
                "subtitles": subtitle_style,
                "blur_boxes": editor.get("blur_boxes", request.get("blur_boxes", [])),
                "blur_strength": int(request.get("overlay_blur_strength", editor.get("blur_strength", defaults.get("overlay_blur_strength", 18)))),
                "title_text": title_text or str(editor.get("title_text") or ""),
                "title_position": request.get("title_position", editor.get("title_position", defaults.get("title_position", [0.5, 0.12]))),
                "title_font_size": int(request.get("title_font_size", editor.get("title_font_size", defaults.get("title_font_size", 54)))),
                "title_font_path": str((APP / "fonts" / "Studio99Myanmar-Regular.ttf").resolve()),
                "logo_enabled": bool(request.get("logo_enabled", editor.get("logo_enabled", defaults.get("logo_enabled", False)))),
                "logo_path": logo_path or str(editor.get("logo_path") or ""),
                "logo_position": request.get("logo_position", editor.get("logo_position", defaults.get("logo_position", [0.8, 0.06]))),
                "logo_width_fraction": float(request.get("logo_width_fraction", editor.get("logo_width_fraction", defaults.get("logo_width_fraction", 0.16)))),
                "logo_opacity": float(request.get("logo_opacity", editor.get("logo_opacity", defaults.get("logo_opacity", 0.65)))),
                "extra_text": extra_text or str(editor.get("extra_text") or ""),
                "extra_text_position": request.get("extra_text_position", editor.get("extra_text_position", defaults.get("extra_text_position", [0.5, 0.84]))),
                "extra_text_font_size": int(request.get("extra_text_font_size", editor.get("extra_text_font_size", defaults.get("extra_text_font_size", 42)))),
                "extra_text_opacity": float(request.get("extra_text_opacity", editor.get("extra_text_opacity", defaults.get("extra_text_opacity", 0.65)))),
            }
            if len(sources) == 1:
                from colab_recap_ui import job_dir as _editor_job_dir, _atomic_json as _atomic_json
                _atomic_json(_editor_job_dir(str(current_source)) / "editor_overlays.json", overlays)
            values = _config_values()
            values["whisper_model_other"] = str(request.get("whisper_model_other") or values["whisper_model_other"])
            generated_outputs: list[str] = []
            plan = {}
            for source_index, source in enumerate(sources, 1):
                current_source = source
                if self.stop_file and self.stop_file.exists():
                    raise InterruptedError("Stopped between batch videos")
                current_job = job_dir if len(sources) == 1 else JOBS / f"{source.stem[:60]}_{job_id[:6]}_{source_index:03d}"
                current_job.mkdir(parents=True, exist_ok=True)
                with self.lock:
                    if self.current and self.current.get("job_id") == job_id:
                        self.current.update(source_index=source_index, job_dir=str(current_job), source=source.name,
                                            status="running", stage=f"Video {source_index}/{len(sources)}: Whisper / planning")
                editor_overlays = colab_recap_ui.load_editor(str(source))
                planner = {
                    "source_path": str(source),
                    "source_title": str(source.stem if safe_batch else (request.get("source_title") or source.stem)),
                    "job_dir": str(current_job), "runtime_root": str(RUNTIME), "gemini_env_path": str(env_file),
                    "run_mode": str(request.get("run_mode") or defaults.get("run_mode") or "auto"),
                    "ffprobe_path": ffprobe, "reuse": reuse_plan, "stop_file": str(self.stop_file),
                    "source_language": language, "whisper_model_other": values["whisper_model_other"],
                    "narration_style": request.get("narration_style") or defaults.get("narration_style") or {}, **values,
                }

                self._worker(job_id, "planner_worker.py", planner, f"planner {source_index}/{len(sources)}", current_job)
                plan_path = current_job / "smart_sync_plan.json"
                plan = json.loads(plan_path.read_text(encoding="utf-8"))
                run_mode = str(request.get("run_mode") or defaults.get("run_mode") or ("review" if request.get("review_first") else "auto"))
                if run_mode == "review" and not safe_batch:
                    with self.lock:
                        self.current.update(status="script_ready", stage="Script Review", progress=60,
                                            job_dir=str(current_job), source=str(source),
                                            segments=len(plan.get("segments") or []), output="", outputs=[])
                    self.emit("recap_script_ready", job_id=job_id, source=str(source), source_title=source.stem,
                              job_dir=str(current_job), segments=len(plan.get("segments") or []))
                    if quota_ctx is not None and quota_entered:
                        quota_ctx.__exit__(None, None, None)
                        quota_ctx = None
                    return
                render_data = {
                    "job_dir": str(current_job), "source_path": str(source), "plan_path": str(plan_path), "voice": voice,
                    "edge_tts_rate": str(request.get("edge_tts_rate", defaults.get("edge_tts_rate", "+0%"))),
                    "edge_tts_pitch": str(request.get("edge_tts_pitch", defaults.get("edge_tts_pitch", "+0Hz"))),
                    "ffmpeg_path": ffmpeg, "ffprobe_path": ffprobe,
                "max_video_speed": float(request.get("max_video_speed", defaults.get("max_video_speed", 1.25))),
                "max_video_slow": float(request.get("max_video_slow", defaults.get("max_video_slow", 1.35))),
                "smooth_freeze_fallback": bool(request.get("smooth_freeze_fallback", defaults.get("smooth_freeze_fallback", False))),
                "max_freeze_hold": float(request.get("max_freeze_hold", defaults.get("max_freeze_hold", 0.75))),

                    "mirror_video": bool(request.get("mirror_video", defaults.get("mirror_video", True))),
                    "zoom_factor": float(request.get("zoom_factor", defaults.get("zoom_factor", 1.05))),
                    "render_final_video": True, "overlays": overlays,
                    "voice_volume_percent": int(request.get("voice_volume_percent", defaults.get("voice_volume_percent", 100))),
                    "short_pauses": bool(request.get("short_pauses", defaults.get("short_pauses", True))),
                    "output_ratio": ratio,
                    "auto_blur_original_subtitles": bool(request.get("auto_blur_original_subtitles", defaults.get("auto_blur_original_subtitles", True))),
                    "video_quality": quality, "frame_fill": str(request.get("frame_fill", defaults.get("frame_fill", "blur"))),
                    "gemini_env_path": str(env_file), "gemini_direction": str(request.get("gemini_direction", defaults.get("gemini_direction", ""))),
                    "voxcpm_ref_audio": str(request.get("voxcpm_ref_audio", defaults.get("voxcpm_ref_audio", "")) or ""),
                    "voxcpm_prompt_text": str(request.get("voxcpm_prompt_text", defaults.get("voxcpm_prompt_text", "")) or ""),
                    "voxcpm_design": str(request.get("voxcpm_design", defaults.get("voxcpm_design", "")) or ""),
                    "voxcpm_steps": int(request.get("voxcpm_steps", defaults.get("voxcpm_steps", 0)) or 0),
                    "stop_file": str(self.stop_file),
                }
                rendered = self._worker(job_id, "render_worker.py", render_data, f"render {source_index}/{len(sources)}", current_job)
                raw_final = Path(str((rendered.get("result") or {}).get("final") or "")).resolve()
                if not raw_final.is_file():
                    raise FileNotFoundError(f"{source.name}: Recap worker final video မတွေ့ပါ။")
                target_folder = Path(final_output_folder) if final_output_folder else OUTPUTS
                target_folder.mkdir(parents=True, exist_ok=True)
                final_path = target_folder / f"{source.stem[:90]}_Myanmar_{job_id[:6]}_{source_index:03d}.mp4"
                shutil.copy2(raw_final, final_path)
                self._copy_srt(rendered, current_job, final_path, job_id)
                generated_outputs.append(str(final_path))
                extras_files = []
                try:
                    import recap_post_extras
                    dur = float((rendered.get("result") or {}).get("duration") or 0.0)
                    extras_files = recap_post_extras.generate_extras(
                        final_path, plan, ffmpeg=ffmpeg, duration=dur,
                        title=str(request.get("source_title") or source.stem),
                        gemini_keys=keys_file.gemini_keys(),
                        log=lambda m: self._say(job_id, m),
                    )
                    for ef in extras_files:
                        generated_outputs.append(str(ef))
                    srt_cand = final_path.parent / "SRT_for_upload" / f"{final_path.stem}.srt"
                    drive_batch = [final_path, *extras_files] + ([srt_cand] if srt_cand.is_file() else [])
                    recap_post_extras.auto_save_to_drive(drive_batch, log=lambda m: self._say(job_id, m))
                except Exception as ex:
                    self._say(job_id, f"⚠️ Post extras / Drive save skipped: {ex}")
                with self.lock:
                    if self.current and self.current.get("job_id") == job_id:
                        self.current.update(progress=int(source_index * 100 / len(sources)), output=str(final_path),
                                            outputs=list(generated_outputs), segments=len(plan.get("segments") or []))
                self._say(job_id, f"✅ Final video: {final_path}")
                self.emit("recap_file_done", job_id=job_id, output=str(final_path), filename=final_path.name,
                          source_index=source_index)
            with self.lock:
                if self.current and self.current.get("job_id") == job_id:
                    self.current.update(status="done", progress=100, stage="Completed",
                                        output=generated_outputs[-1] if generated_outputs else "",
                                        outputs=list(generated_outputs), error="")
            if quota_ctx is not None and quota_entered:
                quota_ctx.__exit__(None, None, None)
                quota_ctx = None
            self.emit("recap_done", job_id=job_id, output=generated_outputs[-1] if generated_outputs else "",
                      outputs=generated_outputs, sources=[str(x) for x in sources],
                      filename=Path(generated_outputs[-1]).name if generated_outputs else "",
                      segments=len(plan.get("segments") or []))
        except InterruptedError as exc:
            if quota_ctx is not None and quota_entered:
                quota_ctx.__exit__(type(exc), exc, exc.__traceback__)
            with self.lock:
                if self.current and self.current.get("job_id") == job_id:
                    self.current.update(status="stopped", stage="Stopped safely", error=str(exc))
            self.emit("recap_stopped", job_id=job_id, message=str(exc))
        except Exception as exc:
            if quota_ctx is not None and quota_entered:
                quota_ctx.__exit__(type(exc), exc, exc.__traceback__)
            with self.lock:
                if self.current and self.current.get("job_id") == job_id:
                    self.current.update(status="error", stage="Error", error=str(exc))
            self._say(job_id, f"❌ {exc}")
            self.emit("recap_error", job_id=job_id, message=str(exc), sources=[str(x) for x in sources])
