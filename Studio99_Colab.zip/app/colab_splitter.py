"""Browser jobs for the native Splitter engine; Tk widgets are not imported in Colab."""
from __future__ import annotations
import json, os, shutil, sys, threading, uuid
from pathlib import Path
from typing import Any
APP=Path(__file__).resolve().parent; ROOT=APP.parent; RECAP_APP=ROOT/"recap_tool_src"/"app"
DATA=Path(os.environ.get("STUDIO99_COLAB_DATA","/content/Studio99Data")).resolve(); TMP=DATA/"tmp"/"splitter"; CONFIG=DATA/"splitter.json"
VIDEO_EXTS={".mp4",".mkv",".mov",".webm",".avi",".m4v"}
DEFAULTS={"minutes":3.0,"smart_cut":True,"max_extra":20.0,"ratio":"Original","fill":"blur","text":"","text_size":46,"text_pos":[.5,.86],"text_opacity":1.0,"text_box":True,"label_on":True,"label_template":"Part {n}","label_size":56,"label_pos":[.5,.1],"label_opacity":1.0,"label_box":True,"output_root":"","quality":"1080"}
def _ensure_engine():
 p=str(RECAP_APP)
 if p not in sys.path:sys.path.insert(0,p)
 import splitter,core,preview_tools
 return splitter,core,preview_tools
def _read_settings():
 try:
  value=json.loads(CONFIG.read_text(encoding="utf-8"));return {**DEFAULTS,**(value if isinstance(value,dict) else {})}
 except (OSError,ValueError):return dict(DEFAULTS)
def _within_content(path):
 path=Path(path).expanduser().resolve();root=Path("/content").resolve();return path==root or root in path.parents
def _video(value):
 if not value or len(value)>4096:raise ValueError("Video path မထည့်ထားပါ။")
 path=Path(value).expanduser().resolve()
 if not _within_content(path) or not path.is_file() or path.suffix.lower() not in VIDEO_EXTS:raise ValueError("/content ထဲက ဖတ်လို့ရတဲ့ video ဖိုင်ကို ရွေးပါ။")
 return path
def _clean(incoming=None):
 s={**DEFAULTS,**(incoming or {})};s["minutes"]=max(.25,min(600,float(s["minutes"])));s["max_extra"]=max(1,min(120,float(s["max_extra"])))
 s["smart_cut"]=bool(s["smart_cut"]);s["ratio"]=str(s["ratio"]);s["fill"]=str(s["fill"]);s["quality"]=str(s["quality"])
 if s["ratio"] not in {"Original","16:9","9:16","1:1"}:raise ValueError("Ratio မမှန်ပါ။")
 if s["fill"] not in {"blur","black","crop"}:raise ValueError("Frame fill မမှန်ပါ။")
 if s["quality"] not in {"1080","720","480"}:raise ValueError("Quality မမှန်ပါ။")
 for k,d,lo,hi in (("text_size",46,20,110),("label_size",56,20,120)):s[k]=max(lo,min(hi,int(s.get(k,d))))
 for k in ("text_opacity","label_opacity"):s[k]=max(.2,min(1,float(s.get(k,1))))
 for k,d in (("text_pos",[.5,.86]),("label_pos",[.5,.1])):
  v=s.get(k,d);v=v if isinstance(v,list) and len(v)==2 else d;s[k]=[max(.02,min(.98,float(x))) for x in v]
 s["text"]=str(s.get("text") or "")[:500];s["label_template"]=str(s.get("label_template") or "Part {n}")[:160]
 output=str(s.get("output_root") or "").strip(); out=Path(output).expanduser().resolve() if output else DATA/"split_outputs"
 if output and not _within_content(out):raise ValueError("Output folder /content အောက်မှာသာ သိမ်းနိုင်ပါတယ်။")

 out.mkdir(parents=True,exist_ok=True);s["output_root"]=str(out);return s
class ColabSplitterJobs:
 def __init__(self,emit):self.emit=emit;self.lock=threading.RLock();self.stop_event=threading.Event();self.procs=[];self.thread=None;self.current=None;self.logs=[]
 def options(self):return {"defaults":_read_settings(),"ratios":["Original","16:9","9:16","1:1"],"fills":[["blur","Blur background"],["black","Black bars"],["crop","Crop to fill"]],"qualities":[["1080","1080p"],["720","720p"],["480","480p"]]}
 def save_settings(self,settings):
  s=_clean(settings);CONFIG.parent.mkdir(parents=True,exist_ok=True);CONFIG.write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding="utf-8")
 def status(self):
  with self.lock:return {**(self.current or {"status":"idle","progress":0,"stage":"Ready","job_id":"","outputs":[]}),"logs":self.logs[-250:]}
 def _log(self,jid,text):
  text=str(text).rstrip()
  if not text:return
  with self.lock:
   if self.current and self.current.get("job_id")==jid:self.logs.append(text);self.logs=self.logs[-500:]
  self.emit("splitter_log",job_id=jid,line=text)
 def preview(self,source_path,seconds,ratio,fill):
  source=_video(source_path);sp,core,preview=_ensure_engine();ffmpeg=shutil.which("ffmpeg") or "ffmpeg";ffprobe=shutil.which("ffprobe") or "ffprobe"
  duration=preview.probe_duration(ffprobe,str(source));size=core.probe_video_size(ffprobe,source);s=_clean({"ratio":ratio,"fill":fill});t=max(0,min(float(seconds),max(0,duration-.05)))
  TMP.mkdir(parents=True,exist_ok=True);out=TMP/f"preview_{uuid.uuid4().hex}.jpg"
  preview.extract_preview_frame(ffmpeg,str(source),t,1,False,str(out),960,540,ratio=s["ratio"],fill=s["fill"],source_size=size)
  return {"path":str(out),"url":f"/api/file?path={out}","duration":duration,"width":size[0],"height":size[1],"seconds":t}
 def check(self,source_path,settings_data):
  source=_video(source_path);s=_clean(settings_data);sp,_core,_preview=_ensure_engine();ffmpeg=shutil.which("ffmpeg") or "ffmpeg";ffprobe=shutil.which("ffprobe") or "ffprobe"
  duration=sp.probe_duration(ffprobe,source);levels=sp.audio_levels(ffmpeg,source) if s["smart_cut"] else None
  parts=sp.plan_parts(duration,s["minutes"]*60,smart=s["smart_cut"],max_extra=s["max_extra"],levels=levels)
  return {"duration":duration,"parts":parts,"count":len(parts)}
 def start(self,sources_data,settings_data):
  if not isinstance(sources_data,list) or not sources_data or len(sources_data)>100:raise ValueError("1-100 хүртသည့် video ဖိုင်ထည့်ပါ။")
  sources=[_video(str(p)) for p in sources_data];s=_clean(settings_data)
  self.save_settings(s)
  with self.lock:
   if self.current and self.current.get("status") in {"starting","running","stopping"}:raise RuntimeError("Splitter job လုပ်နေဆဲပါ။")
   self.stop_event.clear();self.procs=[];self.logs=[];jid=uuid.uuid4().hex
   self.current={"job_id":jid,"status":"starting","progress":0,"stage":"Preparing","sources":[str(x) for x in sources],"outputs":[],"error":""}
   self.thread=threading.Thread(target=self._run,args=(jid,sources,s),daemon=True);self.thread.start()
  return {"job_id":jid,"status":"starting","sources":len(sources)}

 def stop(self):
  self.stop_event.set()
  with self.lock:
   if self.current:self.current.update(status="stopping",stage="Stopping")
   procs=list(self.procs)
  for p in procs:
   try:p.kill()
   except Exception:pass
  return self.status()
 def _run(self,jid,sources,s):
  sp,_core,_preview=_ensure_engine();ffmpeg=shutil.which("ffmpeg") or "ffmpeg";ffprobe=shutil.which("ffprobe") or "ffprobe";made=[];quota_ctx=None;quota_entered=False
  try:
   for i,source in enumerate(sources):
    if self.stop_event.is_set():raise InterruptedError("Stopped")
    with self.lock:
     if self.current and self.current.get("job_id")==jid:self.current.update(status="running",stage=f"Video {i+1}/{len(sources)}: {source.name}")
    self._log(jid,f"▶ [{i+1}/{len(sources)}] {source.name}")
    if quota_ctx is None:
     from daily_limits import free_job
     quota_ctx=free_job("splitter")
     quota_ctx.__enter__();quota_entered=True
    paths=sp.split_video(source,s,ffmpeg=ffmpeg,ffprobe=ffprobe,log=lambda text:self._log(jid,text),
     progress=lambda value,label,index=i:self._progress(jid,(index+value)/len(sources),label),stop=self.stop_event,procs=self.procs,
     on_plan=lambda parts,src=source:self.emit("splitter_parts",job_id=jid,source=str(src),parts=parts))
    made.extend(str(p) for p in paths);self.emit("splitter_file_done",job_id=jid,source=str(source),outputs=[str(p) for p in paths])
   if quota_ctx is not None and quota_entered:quota_ctx.__exit__(None,None,None);quota_ctx=None
   with self.lock:
    if self.current and self.current.get("job_id")==jid:self.current.update(status="done",progress=100,stage="Completed",outputs=made,error="")
   self.emit("splitter_done",job_id=jid,outputs=made)
  except InterruptedError as exc:
   if quota_ctx is not None and quota_entered:quota_ctx.__exit__(type(exc),exc,exc.__traceback__)
   with self.lock:
    if self.current and self.current.get("job_id")==jid:self.current.update(status="stopped",stage="Stopped",outputs=made,error=str(exc))
   self.emit("splitter_stopped",job_id=jid,outputs=made)
  except Exception as exc:
   if quota_ctx is not None and quota_entered:quota_ctx.__exit__(type(exc),exc,exc.__traceback__)
   self._log(jid,f"❌ {exc}")
   with self.lock:
    if self.current and self.current.get("job_id")==jid:self.current.update(status="error",stage="Error",outputs=made,error=str(exc))
   self.emit("splitter_error",job_id=jid,message=str(exc))
 def _progress(self,jid,fraction,label):
  pct=max(0,min(100,int(fraction*100)))
  with self.lock:
   if not self.current or self.current.get("job_id")!=jid:return
   self.current.update(status="running",progress=pct,stage=str(label))
  self.emit("splitter_progress",job_id=jid,progress=pct,stage=str(label))
