"""Studio99 Desktop — login, then every tool as a box on the home screen; a box opens its tool.

Accounts are the Studio99 phone app's (PocketBase recap_users). Tools come from the user's own tools in
"auto posting": the Splitter frame is embedded, Recap opens its own window for now.
"""
from __future__ import annotations

import json
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

import token_store
import ui_thread
from pb_client import AuthError, PocketBase, ServerUnreachable, Session
from tools import TOOLS, Tool

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
PUBLIC_TOOL = ROOT / "recap_tool_src"   # a copy of the shared tool's Recap + Splitter (the user's own tools stay untouched)
CONFIG = ROOT / "config.json"
LOGS = ROOT / "logs"

BG, SURFACE, SURFACE_2, FIELD, BORDER = "#0b0d12", "#141821", "#1b2030", "#0a0c10", "#2a3142"
FG, MUTED, ACCENT, ACCENT_2, GOLD = "#eef1f7", "#98a2b3", "#5b8cff", "#7aa2ff", "#f5c451"
FONT, FONT_SEMI, ICONS = "Segoe UI", "Segoe UI Semibold", "Segoe MDL2 Assets"


def rounded(canvas: tk.Canvas, x1, y1, x2, y2, r=18, **kw) -> int:
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r,
           x1, y1 + r, x1, y1]
    return canvas.create_polygon(pts, smooth=True, **kw)


def load_config() -> dict:
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_config(cfg: dict) -> None:
    CONFIG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def apply_theme(root: tk.Tk) -> None:
    """ttk look shared with the embedded tools (Recap/Splitter use these style names)."""
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    style.configure(".", background=BG, foreground=FG, font=(FONT, 10))
    style.configure("TFrame", background=BG)
    style.configure("TLabel", background=BG, foreground=FG)
    style.configure("Muted.TLabel", background=BG, foreground=MUTED)
    style.configure("Status.TLabel", background=BG, foreground="#55d187", font=(FONT_SEMI, 10))
    style.configure("TLabelframe", background=BG, foreground=FG, bordercolor=BORDER, relief="solid")
    style.configure("TLabelframe.Label", background=BG, foreground=FG, font=(FONT_SEMI, 10))
    style.configure("TEntry", fieldbackground=FIELD, foreground=FG, insertcolor=FG, bordercolor=BORDER,
                    lightcolor=BORDER, darkcolor=BORDER, padding=6)
    style.configure("TCombobox", fieldbackground=FIELD, foreground=FG, background=SURFACE, arrowcolor=FG,
                    bordercolor=BORDER)
    style.map("TCombobox", fieldbackground=[("readonly", FIELD)], foreground=[("readonly", FG)])
    style.configure("TButton", background="#252b36", foreground=FG, bordercolor=BORDER, padding=(10, 6))
    style.map("TButton", background=[("active", "#333b49"), ("disabled", SURFACE)])
    style.configure("Compact.TButton", background="#252b36", foreground=FG, bordercolor=BORDER, padding=(6, 2))
    style.map("Compact.TButton", background=[("active", "#333b49")])
    style.configure("Accent.TButton", background=ACCENT, foreground="#ffffff", bordercolor=ACCENT, padding=(14, 8),
                    font=(FONT_SEMI, 10))
    style.map("Accent.TButton", background=[("active", ACCENT_2), ("disabled", "#33445f")])
    style.configure("Danger.TButton", background="#4a252a", foreground="#ffd9dc", bordercolor="#6a3038")
    style.configure("TCheckbutton", background=BG, foreground=FG)
    style.map("TCheckbutton", background=[("active", BG)])
    style.configure("Horizontal.TProgressbar", troughcolor=FIELD, background=ACCENT)
    style.configure("TSpinbox", fieldbackground=FIELD, foreground=FG, background=SURFACE, arrowcolor=FG)
    style.configure("Treeview", background=FIELD, fieldbackground=FIELD, foreground=FG, rowheight=24, bordercolor=BORDER)
    style.configure("Treeview.Heading", background=SURFACE, foreground=FG)
    style.configure("TNotebook", background=BG, borderwidth=0)
    style.configure("TNotebook.Tab", background=SURFACE, foreground=MUTED, padding=(16, 6), bordercolor=BORDER,
                    font=(FONT_SEMI, 10))
    style.map("TNotebook.Tab", background=[("selected", SURFACE_2)], foreground=[("selected", FG)])
    style.map("Treeview", background=[("selected", "#274d8b")])
    root.option_add("*TCombobox*Listbox.background", FIELD)
    root.option_add("*TCombobox*Listbox.foreground", FG)


# ---------------------------------------------------------------------------------------------- login
class LoginView(tk.Frame):
    def __init__(self, app: "App") -> None:
        super().__init__(app, bg=BG)
        self.app = app
        self.mode = "login"
        self.email = tk.StringVar(value=str(app.cfg.get("last_email") or ""))
        self.password = tk.StringVar()
        self.remember = tk.BooleanVar(value=True)
        self.message = tk.StringVar()
        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.panel = tk.Frame(self.canvas, bg=SURFACE)
        self._build_panel()
        self.canvas.bind("<Configure>", self._layout)

    def _build_panel(self) -> None:
        p = self.panel
        for w in p.winfo_children():
            w.destroy()
        tk.Label(p, text="Studio", bg=SURFACE, fg=FG, font=(FONT_SEMI, 26)).grid(row=0, column=0, sticky="e")
        tk.Label(p, text="99", bg=SURFACE, fg=ACCENT, font=(FONT_SEMI, 26)).grid(row=0, column=1, sticky="w")
        tk.Label(p, text="Desktop  ·  AI video tools for Myanmar creators", bg=SURFACE, fg=MUTED,
                 font=(FONT, 10)).grid(row=1, column=0, columnspan=2, pady=(0, 22))
        title = "Login" if self.mode == "login" else "အကောင့်သစ် ဖွင့်မယ်"
        tk.Label(p, text=title, bg=SURFACE, fg=FG, font=(FONT_SEMI, 14)).grid(row=2, column=0, columnspan=2,
                                                                              sticky="w", pady=(0, 10))
        for row, (label, var, show) in enumerate((("Email", self.email, ""), ("Password", self.password, "•")), 3):
            tk.Label(p, text=label, bg=SURFACE, fg=MUTED, font=(FONT, 9)).grid(row=row * 2, column=0, columnspan=2,
                                                                               sticky="w")
            entry = ttk.Entry(p, textvariable=var, show=show, width=36, font=(FONT, 11))
            entry.grid(row=row * 2 + 1, column=0, columnspan=2, sticky="ew", pady=(2, 12))
            entry.bind("<Return>", lambda _e: self._submit())
        if self.mode == "login":
            ttk.Checkbutton(p, text="Remember me", variable=self.remember, style="Panel.TCheckbutton").grid(
                row=10, column=0, columnspan=2, sticky="w")
        self.button = ttk.Button(p, text="Login" if self.mode == "login" else "Create account",
                                 style="Accent.TButton", command=self._submit)
        self.button.grid(row=11, column=0, columnspan=2, sticky="ew", pady=(14, 6))
        tk.Label(p, textvariable=self.message, bg=SURFACE, fg="#ff8a8a", font=(FONT, 9), wraplength=320,
                 justify="left").grid(row=12, column=0, columnspan=2, sticky="w")
        links = tk.Frame(p, bg=SURFACE)
        links.grid(row=13, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        if self.mode == "login":
            self._link(links, "အကောင့်သစ် ဖွင့်မယ်", lambda: self._switch("register")).pack(side="left")
            self._link(links, "Password မေ့သွားပြီ", self._forgot).pack(side="right")
        else:
            self._link(links, "← Login ပြန်သွား", lambda: self._switch("login")).pack(side="left")
        ttk.Style(self).configure("Panel.TCheckbutton", background=SURFACE, foreground=MUTED)
        ttk.Style(self).map("Panel.TCheckbutton", background=[("active", SURFACE)])

    @staticmethod
    def _link(parent, text, command) -> tk.Label:
        label = tk.Label(parent, text=text, bg=SURFACE, fg=ACCENT_2, font=(FONT, 9, "underline"), cursor="hand2")
        label.bind("<Button-1>", lambda _e: command())
        return label

    def _layout(self, _e=None) -> None:
        c = self.canvas
        c.delete("all")
        w, h = c.winfo_width(), c.winfo_height()
        for i in range(24):                                    # soft glow behind the card
            shade = 11 + i
            c.create_oval(w * 0.5 - 520 + i * 18, h * 0.5 - 420 + i * 14, w * 0.5 + 520 - i * 18,
                          h * 0.5 + 420 - i * 14, outline="", fill=f"#{shade // 2:02x}{shade // 2 + 2:02x}{shade + 6:02x}")
        self.panel.update_idletasks()
        pw, ph = self.panel.winfo_reqwidth() + 72, self.panel.winfo_reqheight() + 64
        x1, y1 = (w - pw) // 2, (h - ph) // 2
        rounded(c, x1, y1, x1 + pw, y1 + ph, r=26, fill=SURFACE, outline=BORDER)
        c.create_window(w // 2, h // 2, window=self.panel)

    def _switch(self, mode: str) -> None:
        self.mode = mode
        self.message.set("")
        self._build_panel()
        self._layout()

    def _forgot(self) -> None:
        if not self.email.get().strip():
            self.message.set("Email ကို အရင် ဖြည့်ပါ။")
            return
        self._busy(lambda: self.app.pb.request_password_reset(self.email.get()),
                   "Password ပြန်သတ်မှတ်ဖို့ link ကို email ထဲ ပို့ပြီးပါပြီ။")

    def _submit(self) -> None:
        email_address, password = self.email.get().strip(), self.password.get()
        if "@" not in email_address or len(password) < 8:
            self.message.set("Email နဲ့ Password (အနည်းဆုံး ၈ လုံး) ဖြည့်ပါ။")
            return
        if self.mode == "register":
            self._busy(lambda: self.app.pb.register(email_address, password),
                       "အကောင့် ဖွင့်ပြီးပါပြီ။ Email ထဲက link ကို နှိပ်ပြီး အတည်ပြုပါ၊ ပြီးမှ Login ဝင်ပါ။",
                       then=lambda: self._switch("login"))
            return

        def work() -> Session:
            return self.app.pb.login(email_address, password)

        self._busy(work, None, then_session=True)

    def _busy(self, work, ok_message: str | None, then=None, then_session: bool = False) -> None:
        self.button.configure(state="disabled")
        self.message.set("…")

        def run() -> None:
            try:
                result = work()
            except (AuthError, ServerUnreachable) as exc:
                ui_thread.post(lambda e=exc: self._done(str(e)))
                return
            except Exception as exc:  # noqa: BLE001 - shown to the user
                ui_thread.post(lambda e=exc: self._done(f"Error: {e}"))
                return
            if then_session:
                ui_thread.post(lambda: self.app.logged_in(result, remember=self.remember.get()))
            else:
                ui_thread.post(lambda: (self._done(ok_message or "", ok=True), then and then()))

        threading.Thread(target=run, daemon=True).start()

    def _done(self, text: str, ok: bool = False) -> None:
        if self.button.winfo_exists():
            self.button.configure(state="normal")
        self.message.set(text)


# ---------------------------------------------------------------------------------------------- home
class HomeView(tk.Frame):
    CARD_W, CARD_H, GAP = 300, 168, 22

    def __init__(self, app: "App") -> None:
        super().__init__(app, bg=BG)
        self.app = app
        s = app.session
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", padx=36, pady=(26, 6))
        tk.Label(top, text="Studio", bg=BG, fg=FG, font=(FONT_SEMI, 20)).pack(side="left")
        tk.Label(top, text="99", bg=BG, fg=ACCENT, font=(FONT_SEMI, 20)).pack(side="left")
        out = tk.Label(top, text="Logout", bg=BG, fg=MUTED, font=(FONT, 10, "underline"), cursor="hand2")
        out.pack(side="right")
        out.bind("<Button-1>", lambda _e: app.logout())
        badge_text = f"{s.vip_label} · {s.vip_left}" if s.vip_left else s.vip_label
        tk.Label(top, text=f"  {badge_text}  ", bg=GOLD if s.is_vip else SURFACE_2,
                 fg="#1a1300" if s.is_vip else MUTED, font=(FONT_SEMI, 9)).pack(side="right", padx=12)
        prof = tk.Label(top, text=f"  {s.email}", bg=BG, fg=MUTED, font=(FONT, 10), cursor="hand2")
        prof.configure(text=f"👤  {s.email}")
        prof.pack(side="right")
        prof.bind("<Button-1>", lambda _e: app.open_profile())
        if not token_store.load_keys().get("gemini"):
            warn = tk.Label(self, text="⚠  Gemini API key မထည့်ရသေးပါ — Profile မှာ ထည့်ပါ (AI tool တွေ အတွက် လိုပါတယ်)",
                            bg="#3a2a12", fg=GOLD, font=("Myanmar Text", 10), cursor="hand2", padx=12, pady=6)
            warn.pack(fill="x", padx=36, pady=(6, 0))
            warn.bind("<Button-1>", lambda _e: app.open_profile())
        tk.Label(self, text="ဘာလုပ်မလဲ?", bg=BG, fg=FG, font=(FONT_SEMI, 16)).pack(anchor="w", padx=36, pady=(16, 0))
        tk.Label(self, text="Tool တစ်ခုကို နှိပ်ပါ", bg=BG, fg=MUTED, font=(FONT, 10)).pack(anchor="w", padx=36)
        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=26, pady=18)
        self.canvas.bind("<Configure>", lambda _e: self._draw())
        self.canvas.bind("<MouseWheel>", lambda e: self.canvas.yview_scroll(int(-e.delta / 120), "units"))
        self.hover: str | None = None

    def _draw(self) -> None:
        c = self.canvas
        c.delete("all")
        width = max(1, c.winfo_width())
        cols = max(1, (width + self.GAP) // (self.CARD_W + self.GAP))
        x0 = (width - (cols * self.CARD_W + (cols - 1) * self.GAP)) // 2
        for i, tool in enumerate(TOOLS):
            r, k = divmod(i, cols)
            x, y = x0 + k * (self.CARD_W + self.GAP), 10 + r * (self.CARD_H + self.GAP)
            self._card(tool, x, y)
        rows = (len(TOOLS) + cols - 1) // cols
        c.configure(scrollregion=(0, 0, width, 20 + rows * (self.CARD_H + self.GAP)))

    def _card(self, tool: Tool, x: int, y: int) -> None:
        c, tag = self.canvas, f"card_{tool.id}"
        hot = self.hover == tool.id
        soon = tool.status != "ready"
        rounded(c, x, y, x + self.CARD_W, y + self.CARD_H, r=22, fill=SURFACE_2 if hot else SURFACE,
                outline=tool.color if hot else BORDER, width=2 if hot else 1, tags=(tag,))
        rounded(c, x + 20, y + 20, x + 70, y + 70, r=14, fill=tool.color if not soon else "#2d3446", outline="",
                tags=(tag,))
        c.create_text(x + 45, y + 45, text=tool.icon, fill="#ffffff" if not soon else MUTED, font=(ICONS, 20),
                      tags=(tag,))
        c.create_text(x + 20, y + 92, text=tool.title, fill=FG if not soon else MUTED, anchor="w",
                      font=(FONT_SEMI, 14), tags=(tag,))
        c.create_text(x + 20, y + 124, text=tool.subtitle, fill=MUTED, anchor="nw", width=self.CARD_W - 40,
                      font=("Myanmar Text", 9), tags=(tag,))
        chip, chip_bg, chip_fg = (("VIP+ · Soon" if tool.vip_plus else "မကြာခင်"), "#2d3446", MUTED) if soon else ((tool.tier_label, GOLD, "#1a1300") if tool.vip
                                                                            else ("Free", "#1f3b2f", "#7ee2a8"))
        rounded(c, x + self.CARD_W - 86, y + 22, x + self.CARD_W - 20, y + 46, r=10, fill=chip_bg, outline="",
                tags=(tag,))
        c.create_text(x + self.CARD_W - 53, y + 34, text=chip, fill=chip_fg, font=("Myanmar Text", 8, "bold"),
                      tags=(tag,))
        c.tag_bind(tag, "<Enter>", lambda _e: self._hover(tool.id))
        c.tag_bind(tag, "<Leave>", lambda _e: self._hover(None))
        c.tag_bind(tag, "<Button-1>", lambda _e: self.app.open_tool(tool))

    def _hover(self, tool_id: str | None) -> None:
        if tool_id != self.hover:
            self.hover = tool_id
            self.canvas.configure(cursor="hand2" if tool_id else "")
            self._draw()


# ---------------------------------------------------------------------------------------------- one tool
class ToolView(tk.Frame):
    def __init__(self, app: "App", tool: Tool) -> None:
        super().__init__(app, bg=BG)
        self.app, self.tool = app, tool
        self.inner = None
        top = tk.Frame(self, bg=SURFACE)
        top.pack(fill="x")
        back = tk.Label(top, text="  Home", bg=SURFACE, fg=FG, font=(ICONS, 10), cursor="hand2", padx=16, pady=10)
        back.configure(font=(FONT_SEMI, 10), text="←  Home")
        back.pack(side="left")
        back.bind("<Button-1>", lambda _e: app.go_home())
        tk.Label(top, text=tool.icon, bg=SURFACE, fg=tool.color, font=(ICONS, 13)).pack(side="left", padx=(8, 6))
        tk.Label(top, text=tool.title, bg=SURFACE, fg=FG, font=(FONT_SEMI, 12)).pack(side="left")
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True)
        if tool.status != "ready":
            self._message(body, "မကြာခင် ထွက်ပါမယ်", f"{tool.title} — {tool.subtitle}")
        elif not tool.allowed(app.session):
            self._message(body, f"{tool.tier_label} member တွေအတွက်ပါ", "သက်တမ်းတိုးရန် Studio99 app ထဲက Profile ကို ကြည့်ပါ။")
        elif tool.id == "splitter":
            self._splitter(body)
        elif tool.id == "recap":
            self._recap(body)
        elif tool.id == "story_motion":
            from story_motion_view import StoryMotionView
            self.inner = StoryMotionView(body, app=app)
            self.inner.pack(fill="both", expand=True)
        elif tool.id == "long_to_short":
            from lts_view import LongToShortView
            self.inner = LongToShortView(body, app=app)
            self.inner.pack(fill="both", expand=True)
        elif tool.id in __import__("tool_apps").WINDOW_TOOLS:
            self._window_tool(body)
        elif tool.id == "auto_posting":
            from posting_view import PostingView   # the TT master's dashboard + scheduler (engine/)
            self.inner = PostingView(body)
            self.inner.pack(fill="both", expand=True)

    def _message(self, body, title: str, text: str) -> None:
        box = tk.Frame(body, bg=BG)
        box.place(relx=0.5, rely=0.42, anchor="center")
        tk.Label(box, text=self.tool.icon, bg=BG, fg=self.tool.color, font=(ICONS, 40)).pack()
        tk.Label(box, text=title, bg=BG, fg=FG, font=("Myanmar Text", 16, "bold")).pack(pady=(12, 4))
        tk.Label(box, text=text, bg=BG, fg=MUTED, font=("Myanmar Text", 10)).pack()
        return box

    def _window_tool(self, body) -> None:
        """Dubbing / Subtitle / Original→Recap: the tool opens in its own window (own process)."""
        import tool_apps
        import keys_file
        box = self._message(body, f"{self.tool.title} ကို သီးသန့် window နဲ့ ဖွင့်ထားပါတယ်",
                            "Taskbar မှာ ရှာပါ။ ပိတ်လိုက်ရင် အောက်က ခလုတ်နဲ့ ပြန်ဖွင့်ပါ။")
        status = tk.Label(box, text="", bg=BG, fg=MUTED, font=("Myanmar Text", 9))
        status.pack(pady=(10, 0))

        def open_tool() -> None:
            if not tool_apps.available(self.tool.id):
                status.configure(text="Tool ဖိုင်တွေ မတွေ့ပါ — tools/sync_tools.py ကို run ပါ", fg="#ff8a8a")
                return
            opened = tool_apps.launch(self.tool.id, token=self.app.session.token, server=self.app.pb.base)
            text = "ပွင့်လာပါပြီ" if opened else "ပွင့်ပြီးသားပါ (taskbar မှာ ကြည့်ပါ)"
            if not keys_file.gemini_keys():
                text += " · ⚠️ Profile မှာ Gemini key မထည့်ရသေးပါ"
            status.configure(text=text, fg=MUTED)
        ttk.Button(box, text=f"{self.tool.title} ဖွင့်မယ်", style="Accent.TButton", command=open_tool).pack(pady=(14, 0))
        open_tool()

    def _splitter(self, body) -> None:
        sys.path.insert(0, str(PUBLIC_TOOL / "app"))
        from splitter_tab import SplitterTab   # the same Splitter as the shared tool
        import shutil

        cfg = self.app.cfg

        def tool_path(name: str) -> str:
            for candidate in (cfg.get(f"{name}_path"), PUBLIC_TOOL / "ffmpeg" / f"{name}.exe", shutil.which(name)):
                if candidate and Path(candidate).is_file():
                    return str(candidate)
            return name

        LOGS.mkdir(exist_ok=True)
        self.inner = SplitterTab(body, cfg=cfg, save=lambda: save_config(cfg), tool=tool_path, logs_dir=LOGS)
        self.inner.pack(fill="both", expand=True)

    def _recap(self, body) -> None:
        from recap_tool import RecapToolView
        self.inner = RecapToolView(body, app=self.app, public_tool=PUBLIC_TOOL, config_file=ROOT / "recap_config.json")
        self.inner.pack(fill="both", expand=True)

    def close(self) -> None:
        if self.inner is not None and hasattr(self.inner, "shutdown"):
            self.inner.shutdown()


# ---------------------------------------------------------------------------------------------- profile
class ProfileView(tk.Frame):
    """Account, VIP days left and the user's own API keys (BYOK, stored encrypted on this PC only)."""

    def __init__(self, app: "App") -> None:
        super().__init__(app, bg=BG)
        self.app = app
        top = tk.Frame(self, bg=SURFACE)
        top.pack(fill="x")
        back = tk.Label(top, text="←  Home", bg=SURFACE, fg=FG, font=(FONT_SEMI, 10), cursor="hand2", padx=16, pady=10)
        back.pack(side="left")
        back.bind("<Button-1>", lambda _e: app.go_home())
        tk.Label(top, text="Profile", bg=SURFACE, fg=FG, font=(FONT_SEMI, 12)).pack(side="left", padx=8)
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=60, pady=30)
        self.account = tk.Frame(body, bg=SURFACE, padx=28, pady=22)
        self.account.pack(fill="x")
        self._account()

        keys = token_store.load_keys()
        box = tk.Frame(body, bg=SURFACE, padx=28, pady=22)
        box.pack(fill="x", pady=(18, 0))
        tk.Label(box, text="API Keys", bg=SURFACE, fg=FG, font=(FONT_SEMI, 13)).pack(anchor="w")
        tk.Label(box, text="ကိုယ်ပိုင် key တွေကို ဒီစက်ထဲမှာပဲ encrypt လုပ်ပြီး သိမ်းပါတယ်။ Google / FAL ကိုပဲ ပို့ပါတယ်။",
                 bg=SURFACE, fg=MUTED, font=("Myanmar Text", 9)).pack(anchor="w", pady=(2, 12))
        tk.Label(box, text="Gemini API keys (တစ်ကြောင်း တစ်ခု — များရင် quota ပြည့်တဲ့အခါ နောက်တစ်ခု သုံးမယ်)",
                 bg=SURFACE, fg=MUTED, font=("Myanmar Text", 9)).pack(anchor="w")
        self.gemini = tk.Text(box, height=4, bg=FIELD, fg=FG, insertbackground=FG, relief="flat", font=("Consolas", 10),
                              highlightthickness=1, highlightbackground=BORDER, padx=8, pady=6)
        self.gemini.insert("1.0", "\n".join(keys.get("gemini") or []))
        self.gemini.pack(fill="x", pady=(4, 12))
        tk.Label(box, text="FAL API key (မထည့်လည်းရ — Story Motion / Novel မှာ AI ပုံထုတ်ချင်မှ)", bg=SURFACE, fg=MUTED,
                 font=("Myanmar Text", 9)).pack(anchor="w")
        self.fal = tk.StringVar(value=str(keys.get("fal") or ""))
        ttk.Entry(box, textvariable=self.fal, show="•", font=("Consolas", 10)).pack(fill="x", pady=(4, 12))
        row = tk.Frame(box, bg=SURFACE)
        row.pack(fill="x")
        ttk.Button(row, text="Save keys", style="Accent.TButton", command=self._save).pack(side="left")
        self.saved = tk.Label(row, text="", bg=SURFACE, fg="#7ee2a8", font=("Myanmar Text", 9))
        self.saved.pack(side="left", padx=12)
        link = tk.Label(row, text="Gemini key ယူရန် (aistudio.google.com/apikey)", bg=SURFACE, fg=ACCENT_2,
                        font=(FONT, 9, "underline"), cursor="hand2")
        link.pack(side="right")
        link.bind("<Button-1>", lambda _e: __import__("webbrowser").open("https://aistudio.google.com/apikey"))

    def _account(self) -> None:
        for w in self.account.winfo_children():
            w.destroy()
        s = self.app.session
        tk.Label(self.account, text=s.email, bg=SURFACE, fg=FG, font=(FONT_SEMI, 15)).grid(row=0, column=0, sticky="w")
        if s.is_vip:
            until = s.vip_until()
            left = f"{s.vip_left} ({s.vip_until_at} အထိ)" if until else "သက်တမ်း မကန့်သတ်"
            tk.Label(self.account, text=f"  {s.vip_label}  ", bg=GOLD, fg="#1a1300", font=(FONT_SEMI, 10)).grid(
                row=1, column=0, sticky="w", pady=(10, 0))
            tk.Label(self.account, text=left, bg=SURFACE, fg=FG, font=("Myanmar Text", 11)).grid(
                row=1, column=1, sticky="w", padx=10, pady=(10, 0))
        else:
            ended = " (သက်တမ်း ကုန်သွားပါပြီ)" if s.user.get("is_vip") is True else ""
            tk.Label(self.account, text="  Free  ", bg=SURFACE_2, fg=MUTED, font=(FONT_SEMI, 10)).grid(
                row=1, column=0, sticky="w", pady=(10, 0))
            tk.Label(self.account, text="VIP ဝယ်ယူရန် Admin ကို ဆက်သွယ်ပါ" + ended, bg=SURFACE, fg=MUTED,
                     font=("Myanmar Text", 10)).grid(row=1, column=1, sticky="w", padx=10, pady=(10, 0))
        refresh = tk.Label(self.account, text="↻ ပြန်စစ်မယ်", bg=SURFACE, fg=ACCENT_2, font=("Myanmar Text", 9, "underline"),
                           cursor="hand2")
        refresh.grid(row=2, column=0, sticky="w", pady=(12, 0))
        refresh.bind("<Button-1>", lambda _e: self._refresh())
        out = tk.Label(self.account, text="Logout", bg=SURFACE, fg=MUTED, font=(FONT, 9, "underline"), cursor="hand2")
        out.grid(row=2, column=1, sticky="w", padx=10, pady=(12, 0))
        out.bind("<Button-1>", lambda _e: self.app.logout())

    def _refresh(self) -> None:
        def run() -> None:
            try:
                session = self.app.pb.refresh(self.app.session.token)
                ui_thread.post(lambda: (setattr(self.app, "session", session), self._account()))
            except Exception:
                pass
        threading.Thread(target=run, daemon=True).start()

    def _save(self) -> None:
        import keys_file
        try:
            result = keys_file.save(self.gemini.get("1.0", "end").strip() or None, self.fal.get().strip() or None)
        except (OSError, ValueError) as exc:
            self.saved.configure(text="သိမ်းမရသေးပါ")
            messagebox.showerror("Profile keys", str(exc))
            return
        self.saved.configure(text=f"သိမ်းပြီးပါပြီ — Gemini key {len(result['gemini'])} ခု")


# ---------------------------------------------------------------------------------------------- app
class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Studio99 Desktop")
        self.geometry("1280x800")
        self.minsize(980, 640)
        self.configure(bg=BG)
        try:
            self.state("zoomed")
        except tk.TclError:
            pass
        apply_theme(self)
        ui_thread.install(self)
        self.cfg = load_config()
        self.pb = PocketBase(self.cfg.get("server") or "https://api.recapboxx.com")
        self.session: Session | None = None
        from membership_access import bind_session
        bind_session(lambda: self.session)
        self.view: tk.Frame | None = None
        self.protocol("WM_DELETE_WINDOW", self._close)
        self._resume()
        self.after(30_000, self._membership_tick)

    def _membership_tick(self) -> None:
        import engine_runner
        proc = engine_runner._engine
        if proc is not None and proc.poll() is None and not (self.session and self.session.is_vip_plus):
            engine_runner.stop()
        self.after(30_000, self._membership_tick)

    def _show(self, view: tk.Frame) -> None:
        if isinstance(self.view, ToolView):
            self.view.close()
        if self.view is not None:
            self.view.destroy()
        self.view = view
        view.pack(fill="both", expand=True)

    def _resume(self) -> None:
        saved = token_store.load()
        if not saved:
            self._show(LoginView(self))
            return
        splash = tk.Frame(self, bg=BG)
        tk.Label(splash, text="Studio99", bg=BG, fg=FG, font=(FONT_SEMI, 22)).place(relx=0.5, rely=0.45, anchor="center")
        self._show(splash)

        def run() -> None:
            try:
                session = self.pb.refresh(saved["token"])
                ui_thread.post(lambda: self.logged_in(session, remember=True))
            except ServerUnreachable:                      # offline: keep the saved login for next time
                ui_thread.post(lambda: self._show(LoginView(self)))
            except Exception:
                token_store.clear()
                ui_thread.post(lambda: self._show(LoginView(self)))

        threading.Thread(target=run, daemon=True).start()

    def logged_in(self, session: Session, remember: bool) -> None:
        self.session = session
        self.cfg["last_email"] = session.email
        save_config(self.cfg)
        if remember:
            token_store.save(session.token, session.email)
        else:
            token_store.clear()
        self.go_home()

    def go_home(self) -> None:
        self._show(HomeView(self))

    def open_profile(self) -> None:
        self._show(ProfileView(self))

    def open_tool(self, tool: Tool) -> None:
        self._show(ToolView(self, tool))

    def logout(self) -> None:
        token_store.clear()
        self.session = None
        self._show(LoginView(self))

    def report_callback_exception(self, exc, value, tb) -> None:
        """Errors are written to logs/app.log and shown (RUN.bat uses pythonw: nothing would be seen otherwise)."""
        import traceback
        from tkinter import messagebox
        text = "".join(traceback.format_exception(exc, value, tb))
        try:
            LOGS.mkdir(exist_ok=True)
            with (LOGS / "app.log").open("a", encoding="utf-8") as f:
                f.write(text + "\n")
        except Exception:
            pass
        messagebox.showerror("Studio99", f"{value}\n\n(logs/app.log)")

    def _close(self) -> None:
        import engine_runner
        import keys_file
        import tool_apps
        from tkinter import messagebox
        busy = [t.title for t in TOOLS if t.id in tool_apps.running_titles()]
        if engine_runner.running():
            busy.append("Auto Posting")
        if busy and not messagebox.askyesno(
                "Studio99", f"{', '.join(busy)} ဖွင့်ထားဆဲပါ။ Studio99 ပိတ်ရင် အဲ့ဒါတွေပါ ရပ်သွားပါမယ်။ ပိတ်မလား?"):
            return
        if isinstance(self.view, ToolView):
            self.view.close()
        tool_apps.stop_all()
        engine_runner.stop()                  # Auto Posting runs while Studio99 is open
        keys_file.remove()
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
