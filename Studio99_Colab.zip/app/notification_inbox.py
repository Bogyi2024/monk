"""In-app inbox: PocketBase announcements + account-scoped VIP reminders. No push transport.

Only reads the server. Read receipts and the last successful inbox are local to
this Windows user, account and server; membership always comes from PocketBase.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from pb_client import ServerUnreachable, Session
from token_store import APP_DIR

POLL_SECONDS = 60
MAX_ANNOUNCEMENTS = 100


def parse_date(value: str) -> datetime | None:
    try:
        date = datetime.fromisoformat(str(value).replace("Z", "+00:00").replace(" ", "T"))
        return date.replace(tzinfo=timezone.utc) if date.tzinfo is None else date.astimezone(timezone.utc)
    except (ValueError, TypeError):
        return None


def stamp(date: datetime) -> str:
    return date.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def vip_notice(session: Session) -> dict | None:
    until = parse_date(session.user.get("vip_until") or "")
    if until is None:
        return None                              # Free or lifetime VIP
    label = "VIP+" if session.membership_tier == "vip_plus" else "VIP"
    left = (until - session.server_now()).total_seconds()
    if left <= 0:
        stage, title, body, created = (
            "expired", f"{label} သက်တမ်း ကုန်ဆုံးသွားပါပြီ",
            "VIP tool တွေ ဆက်သုံးဖို့ သက်တမ်းတိုးနိုင်ပါတယ်။ အသေးစိတ်ကို Profile မှာ ကြည့်ပါ။", until)
    elif session.user.get("is_vip") is not True or left > 3 * 86400:
        return None
    else:
        stage, days = ("1d", 1) if left <= 86400 else ("3d", 3)
        title = f"{label} သက်တမ်း {'၁' if days == 1 else '၃'} ရက်အတွင်း ကုန်ဆုံးတော့မယ်"
        body = "VIP tool တွေ ဆက်သုံးဖို့ သက်တမ်းတိုးရန် ပြင်ဆင်နိုင်ပါတယ်။ အသေးစိတ်ကို Profile မှာ ကြည့်ပါ။"
        created = until - timedelta(days=days)
    identity = f"vip:{stamp(until)}:{stage}"
    return {"id": identity, "version": identity, "kind": "vip", "title": title,
            "message": body, "created": stamp(created), "vip_until": stamp(until), "stage": stage,
            "membership_label": label}


def announcement(row: dict) -> dict | None:
    if not isinstance(row, dict) or not isinstance(row.get("id"), str) or not row["id"]:
        return None
    title = str(row.get("title") or "Studio99 မှ အသိပေးချက်")[:500]
    message = str(row.get("message") or "")[:20000]
    version = hashlib.sha256(json.dumps([title, message, row.get("updated")],
                                        ensure_ascii=False).encode("utf-8")).hexdigest()
    return {"id": "announcement:" + row["id"], "version": version, "kind": "admin",
            "title": title, "message": message, "created": str(row.get("created") or "")}


class NotificationInbox:
    def __init__(self, server: str, user_id: str, directory: Path | None = None):
        self.identity = (server.rstrip("/"), user_id)
        name = hashlib.sha256(json.dumps(self.identity).encode("utf-8")).hexdigest()
        self.path = (directory or APP_DIR / "notifications") / (name + ".json")
        self._lock = threading.Lock()
        self._items: list[dict] = []
        self._read: dict[str, str] = {}
        self._checked_at = ""
        self._error = ""
        self._attempt: float | None = None
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self._items = [x for x in data.get("items", []) if isinstance(x, dict)
                           and isinstance(x.get("id"), str) and isinstance(x.get("version"), str)
                           and x.get("kind") in ("admin", "vip")][:MAX_ANNOUNCEMENTS + 1]
            self._read = {k: v for k, v in data.get("read", {}).items() if isinstance(v, str)}
            self._checked_at = str(data.get("checked_at") or "")
        except (OSError, ValueError, TypeError, AttributeError):
            pass

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = ""
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=self.path.parent,
                                             prefix=self.path.stem, suffix=".tmp", delete=False) as stream:
                temporary = stream.name
                json.dump({"items": self._items, "read": self._read, "checked_at": self._checked_at},
                          stream, ensure_ascii=False)
            os.replace(temporary, self.path)
        finally:
            if temporary and os.path.exists(temporary):
                os.unlink(temporary)

    def _snapshot(self) -> dict:
        items = [{**item, "read": self._read.get(item["id"]) == item["version"]} for item in self._items]
        items.sort(key=lambda x: parse_date(x.get("created")) or datetime.min.replace(tzinfo=timezone.utc),
                   reverse=True)
        return {"items": items, "unread": sum(not x["read"] for x in items),
                "checked_at": self._checked_at, "error": self._error}

    def sync(self, client, session: Session, force: bool = False) -> tuple[dict, Session | None]:
        if (client.base.rstrip("/"), str(session.user.get("id") or "")) != self.identity:
            raise ValueError("Inbox account mismatch")
        with self._lock:
            if not force and self._attempt is not None and time.monotonic() - self._attempt < POLL_SECONDS:
                return self._snapshot(), None
            self._attempt = time.monotonic()
            self._error = ""
            try:
                current = client.notification_account(session)
            except ServerUnreachable:
                self._error = "နိုတီအသစ်တွေ စစ်လို့မရသေးပါ။ Internet ချိတ်ပြီး ပြန်စစ်ပါ။"
                return self._snapshot(), None
            # Do not keep an obsolete expiry after a renewal or membership change.
            items = [x for x in self._items if x["kind"] == "admin"]
            try:
                rows = client.announcements(session, MAX_ANNOUNCEMENTS)
                items = [item for row in rows if (item := announcement(row)) is not None]
                self._checked_at = stamp(current.server_now())
            except ServerUnreachable:
                self._error = "Admin နိုတီအသစ်တွေ စစ်လို့မရသေးပါ။ ခဏနေ ပြန်စစ်ပါ။"
            notice = vip_notice(current)
            if notice:
                items.append(notice)
            self._items = items
            # Receipts for deleted notices need not accumulate forever.
            present = {x["id"] for x in items}
            self._read = {k: v for k, v in self._read.items() if k in present}
            try:
                self._save()
            except OSError:
                self._error = "ဒီစက်မှာ နိုတီမှတ်တမ်း သိမ်းလို့မရပါ။ Folder ရေးခွင့်ကို စစ်ပါ။"
            return self._snapshot(), current

    def mark_read(self, ids: list[str]) -> dict:
        if not isinstance(ids, list) or len(ids) > MAX_ANNOUNCEMENTS + 1 or any(not isinstance(x, str) for x in ids):
            raise ValueError("Invalid notification IDs")
        with self._lock:
            wanted = set(ids)
            for item in self._items:
                if item["id"] in wanted:
                    self._read[item["id"]] = item["version"]
            self._save()
            return self._snapshot()
