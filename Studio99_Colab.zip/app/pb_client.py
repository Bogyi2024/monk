"""PocketBase login for Studio99 Desktop — the same `recap_users` accounts as the Studio99 phone app
(api.recapboxx.com): email + password, email must be verified, VIP = is_vip and vip_until empty or later than the
SERVER's time (the PC clock is not trusted). The password is never stored; only the session token, encrypted
for this Windows user (token_store.py)."""
from __future__ import annotations

import email.utils
import hashlib
import platform
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import requests

from app_version import BUILD

BASE_URL = "https://api.recapboxx.com"
COLLECTION = "recap_users"
DEVICES = "recap_devices"          # one PC + one phone per account (unique index user+kind; only the admin deletes)
DEVICE_SALT = "studio99-device-v1"
SETTINGS = "recap_pro_app_settings"  # key_name/key_value rows shared with the phone app (its min_app_version …)
WINDOWS_KEYS = ("min_windows_build", "windows_update_link", "windows_block_message")
UPDATE_MESSAGE = "ဒီ Studio99 version ကို ဆက်သုံးလို့ မရတော့ပါ။ Version အသစ်ကို ဒေါင်းပြီး install လုပ်ပါ။"
TIMEOUT = 20
OTHER_PC = ("ဒီ account ကို တခြား PC တစ်လုံးမှာ သုံးထားပါတယ်။ Account တစ်ခုကို PC ၁ လုံး + ဖုန်း ၁ လုံးပဲ "
            "သုံးလို့ရပါတယ်။ PC ပြောင်းချင်ရင် admin ကို ဆက်သွယ်ပါ။")


def this_device() -> str:
    """This PC's id for the device limit: Windows' MachineGuid (stays the same after a reinstall of the app),
    hashed so the real id never leaves the PC."""
    raw = ""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                            winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
            raw = str(winreg.QueryValueEx(key, "MachineGuid")[0])
    except (ImportError, OSError):
        raw = f"mac-{uuid.getnode():012x}"
    return hashlib.sha256((raw.strip().lower() + DEVICE_SALT).encode("utf-8")).hexdigest()


class ServerUnreachable(RuntimeError):
    """No answer from the server (internet, VPN, a 5xx from a proxy) — NOT a refused login: keep the saved session."""


class AuthError(RuntimeError):
    """A message that can be shown to the user as it is (Burmese)."""


class UpdateRequired(AuthError):
    """This build is older than the server's min_windows_build: the admin stopped it (forced update / kill-switch)."""

    def __init__(self, message: str, link: str = ""):
        super().__init__(message)
        self.link = link


@dataclass
class Session:
    token: str
    user: dict[str, Any]
    server_offset: float = 0.0          # server time - PC time, seconds
    extra: dict[str, Any] = field(default_factory=dict)

    @property
    def email(self) -> str:
        return str(self.user.get("email") or "")

    def server_now(self) -> datetime:
        return datetime.fromtimestamp(time.time() + self.server_offset, tz=timezone.utc)

    def vip_until(self) -> datetime | None:
        raw = str(self.user.get("vip_until") or "").strip()
        if not raw:
            return None
        try:
            date = datetime.fromisoformat(raw.replace("Z", "+00:00").replace(" ", "T"))
            return date.replace(tzinfo=timezone.utc) if date.tzinfo is None else date.astimezone(timezone.utc)
        except ValueError:
            return None

    @property
    def is_vip(self) -> bool:
        if self.user.get("is_vip") is not True:
            return False
        until = self.vip_until()
        # Only an actually empty expiry is the legacy no-expiry membership.
        return until > self.server_now() if until else not str(self.user.get("vip_until") or "").strip()

    @property
    def membership_tier(self) -> str:
        """Canonical stored tier; a legacy blank/unknown value never grants VIP+."""
        value = self.user.get("membership_tier")
        return value if value in ("vip", "vip_plus") else ""

    @property
    def is_vip_plus(self) -> bool:
        return self.is_vip and self.membership_tier == "vip_plus"

    @property
    def vip_label(self) -> str:
        if not self.is_vip:
            return "Free"
        return "VIP+" if self.membership_tier == "vip_plus" else "VIP"

    @property
    def vip_days_left(self) -> int | None:
        until = self.vip_until()
        return (until - self.server_now()).days if self.is_vip and until else None

    @property
    def vip_until_at(self) -> str:
        """The end as this PC's local date and time ("2026-10-30 21:00"); "" = no end date."""
        until = self.vip_until()
        return until.astimezone().strftime("%Y-%m-%d %H:%M") if until else ""

    @property
    def vip_left(self) -> str:
        """Time left in days AND hours (2026-10-30: "0 ရက် ကျန်" with 3 h left read as already ended)."""
        until = self.vip_until()
        if not (self.is_vip and until):
            return ""
        minutes = max(0, int((until - self.server_now()).total_seconds() // 60))
        days, rest = divmod(minutes, 1440)
        hours, mins = divmod(rest, 60)
        if days:
            return f"{days} ရက် {hours} နာရီ ကျန်"
        return f"{hours} နာရီ {mins} မိနစ် ကျန်" if hours else f"{mins} မိနစ် ကျန်"


def is_banned(user: dict[str, Any]) -> bool:
    """recap_users.status is a multi-select ("active" / "banned"), so PocketBase sends a list such as ["active"]
    (2026-10-17: comparing it with the text "active" refused every account)."""
    status = user.get("status")
    values = [str(x).lower() for x in (status if isinstance(status, list) else [status]) if x]
    return "banned" in values or str(user.get("is_banned") or "").strip().lower() in ("true", "1", "yes", "banned")


def _offset(response: requests.Response) -> float:
    try:
        server = email.utils.parsedate_to_datetime(response.headers["Date"]).timestamp()
        return server - time.time()
    except Exception:
        return 0.0


# Not a refusal: the request timed out / was rate-limited, or something in front of PocketBase answered.
TRANSIENT_STATUS = {408, 425, 429}


def _no_answer(response: requests.Response) -> bool:
    """True when PocketBase gave no real answer: a server error, a timeout / rate limit, or a page from a proxy / CDN
    (HTML, not PocketBase's JSON error). 2026-11-06: the 2-minute account check treated every 4xx as a refusal, so one
    429 / Cloudflare 403 logged the customer out and stopped every running job. Treat these like being offline."""
    status = response.status_code
    if status >= 500 or status in TRANSIENT_STATUS:
        return True
    if status == 200:
        return False
    try:
        return not isinstance(response.json(), dict)
    except ValueError:
        return True


def _busy_message(response: requests.Response) -> str:
    return f"📡 Server က အခု မဖြေနိုင်ပါ ({response.status_code}) — ခဏနေ ပြန်ကြိုးစားပါ။"


def _message(response: requests.Response) -> str:
    try:
        data = response.json()
    except ValueError:
        data = {}
    if not isinstance(data, dict):
        data = {}
    text = str(data.get("message") or "")
    fields = data.get("data") or {}
    if response.status_code == 400 and "authenticate" in text.lower():
        return "Email သို့မဟုတ် Password မှားနေပါတယ်။"
    if "email" in fields:
        return "ဒီ Email ကို သုံးလို့ မရပါ (အကောင့် ရှိပြီးသား ဖြစ်နိုင်ပါတယ်)။"
    if "password" in fields:
        return "Password က အနည်းဆုံး ၈ လုံး ရှိရပါမယ်။"
    return text or f"Server error {response.status_code}"


class PocketBase:
    def __init__(self, base_url: str = BASE_URL, session: requests.Session | None = None, device: str | None = None):
        self.base = base_url.rstrip("/")
        self.http = session or requests.Session()
        self.device = device or this_device()

    def _get(self, path: str, params: dict[str, Any], token: str) -> requests.Response:
        try:
            return self.http.get(self.base + path, params=params, timeout=TIMEOUT, headers={"Authorization": token})
        except requests.RequestException as exc:
            raise ServerUnreachable("📡 Server နဲ့ ချိတ်လို့ မရပါ။ Internet ကို စစ်ပါ။") from exc

    def _pc_records(self, session: Session) -> list[dict[str, Any]] | None:
        """This account's PC record(s); None = the device list is not set up on the server (yet)."""
        response = self._get(f"/api/collections/{DEVICES}/records",
                             {"filter": "kind='pc'", "perPage": 10}, session.token)
        if response.status_code in (403, 404) and not _no_answer(response):
            return None
        if _no_answer(response):
            raise ServerUnreachable(_busy_message(response))
        if response.status_code != 200:
            raise AuthError(_message(response))
        return list(response.json().get("items") or [])

    def check_device(self, session: Session) -> None:
        """One PC per account: the first PC that logs in takes the account's PC place, any other PC is refused.
        Only the admin frees the place (deletes the record) — the user cannot delete or change it."""
        records = self._pc_records(session)
        if records is None:
            return
        if records:
            if any(str(r.get("device_id")) == self.device for r in records):
                return
            raise AuthError(OTHER_PC)
        response = self._post(f"/api/collections/{DEVICES}/records", {
            "user": session.user.get("id"), "kind": "pc", "device_id": self.device,
            "name": (platform.node() or "PC")[:60]}, token=session.token)
        if response.status_code == 200:
            return
        if _no_answer(response):
            raise ServerUnreachable(_busy_message(response))
        again = self._pc_records(session)          # 400: another PC took the place at the same moment …
        if not again or any(str(r.get("device_id")) == self.device for r in again):
            return                                 # … or still no row: a validation problem, not another PC
        raise AuthError(OTHER_PC)

    def windows_settings(self, token: str) -> dict[str, str]:
        """The Windows rows of recap_pro_app_settings; {} when the server cannot be asked — fail open, so a server
        hiccup never locks customers out (ban and VIP are checked on their own, from the account record)."""
        rows = " || ".join(f"key_name='{key}'" for key in WINDOWS_KEYS)
        try:
            response = self._get(f"/api/collections/{SETTINGS}/records", {"filter": rows, "perPage": 20}, token)
        except ServerUnreachable:
            return {}
        if response.status_code != 200:
            return {}
        try:
            items = response.json().get("items") or []
        except (ValueError, AttributeError):
            return {}
        return {str(r.get("key_name")): str(r.get("key_value") or "").strip() for r in items if isinstance(r, dict)}

    def check_build(self, token: str) -> None:
        """Kill-switch: the admin sets min_windows_build above an old/cracked build's BUILD to stop it."""
        settings = self.windows_settings(token)
        try:
            need = int(float(settings.get("min_windows_build") or 0))
        except ValueError:
            return
        if need > BUILD:
            link = settings.get("windows_update_link", "")
            message = settings.get("windows_block_message") or UPDATE_MESSAGE
            raise UpdateRequired(message + (f"\n\n{link}" if link else ""), link)

    def _post(self, path: str, body: dict[str, Any] | None = None, token: str = "") -> requests.Response:
        try:
            return self.http.post(self.base + path, json=body or {}, timeout=TIMEOUT,
                                  headers={"Authorization": token} if token else {})
        except requests.RequestException as exc:
            raise ServerUnreachable("📡 Server နဲ့ ချိတ်လို့ မရပါ။ Internet ကို စစ်ပါ။") from exc

    def _session(self, response: requests.Response) -> Session:
        if _no_answer(response):
            raise ServerUnreachable(_busy_message(response))
        if response.status_code != 200:
            raise AuthError(_message(response))
        data = response.json()
        session = Session(token=str(data["token"]), user=dict(data.get("record") or {}), server_offset=_offset(response))
        if session.user.get("verified") is not True:
            raise AuthError("Email ကို အတည်မပြုရသေးပါ။ Email ထဲက link ကို နှိပ်ပြီးမှ Login ဝင်ပါ။")
        if is_banned(session.user):
            raise AuthError("ဒီအကောင့်ကို ပိတ်ထားပါတယ်။")
        self.check_build(session.token)             # before the device check: a stopped build takes no PC place
        self.check_device(session)
        return session

    def login(self, email_address: str, password: str) -> Session:
        return self._session(self._post(f"/api/collections/{COLLECTION}/auth-with-password",
                                        {"identity": email_address.strip(), "password": password}))

    def refresh(self, token: str) -> Session:
        """A saved session: a new token and the latest VIP state."""
        return self._session(self._post(f"/api/collections/{COLLECTION}/auth-refresh", token=token))

    def notification_account(self, session: Session) -> Session:
        """Read current membership and the server clock without rotating login/device bindings."""
        response = self._get(f"/api/collections/{COLLECTION}/records/{session.user['id']}",
                             {"fields": "id,email,verified,is_vip,vip_until,membership_tier,status,is_banned"}, session.token)
        if _no_answer(response):
            raise ServerUnreachable("Account server is unavailable")
        if response.status_code != 200:
            raise AuthError(_message(response))
        try:
            user = response.json()
        except ValueError as exc:
            raise ServerUnreachable("Account server returned an invalid response") from exc
        if not isinstance(user, dict):
            raise ServerUnreachable("Account server returned an invalid response")
        if user.get("id") != session.user["id"] or user.get("verified") is not True or is_banned(user):
            raise AuthError("ဒီအကောင့်ကို သုံးလို့မရပါ။ Login ပြန်ဝင်ပါ။")
        return Session(token=session.token, user={**session.user, **user}, server_offset=_offset(response))

    def announcements(self, session: Session, limit: int = 100) -> list[dict[str, Any]]:
        """The same admin announcements collection used by the phone app (read only)."""
        response = self._get("/api/collections/announcements/records", {
            "page": 1, "perPage": limit, "sort": "-created,-id",
            "fields": "id,title,message,type,created,updated"}, session.token)
        if response.status_code != 200:
            raise ServerUnreachable("Announcements are unavailable")
        try:
            data = response.json()
        except ValueError as exc:
            raise ServerUnreachable("Announcements returned an invalid response") from exc
        if not isinstance(data, dict) or not isinstance(data.get("items"), list):
            raise ServerUnreachable("Announcements returned an invalid response")
        return data["items"][:limit]

    def register(self, email_address: str, password: str) -> None:
        email_address = email_address.strip()
        response = self._post(f"/api/collections/{COLLECTION}/records", {
            "email": email_address, "password": password, "passwordConfirm": password,
            "name": email_address.split("@")[0], "status": "active"})
        if response.status_code != 200:
            raise AuthError(_message(response))
        self.request_verification(email_address)

    def request_verification(self, email_address: str) -> None:
        self._post(f"/api/collections/{COLLECTION}/request-verification", {"email": email_address.strip()})

    def request_password_reset(self, email_address: str) -> None:
        response = self._post(f"/api/collections/{COLLECTION}/request-password-reset", {"email": email_address.strip()})
        if response.status_code not in (200, 204):
            raise AuthError(_message(response))
