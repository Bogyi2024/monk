"""Studio99-only compatibility for Bilibili pages with missing initial state.

Bilibili's international pages can omit window.__INITIAL_STATE__. Use the same
signed view/detail API that the upstream extractor already calls for redirects,
then let yt-dlp handle parts, access checks, formats, subtitles and downloads.
Related upstream report/fix: yt-dlp/yt-dlp#17894 and #17898 (October 2026).
No installed package or sibling tool is patched.
"""
from yt_dlp.extractor.bilibili import BiliBiliBangumiIE, BiliBiliIE
from yt_dlp.utils import ExtractorError
from urllib.parse import urlsplit


class _BangumiRedirect(Exception):
    pass


class StudioBilibiliIE(BiliBiliIE):
    _VALID_URL = (r"https?://(?:www\.)?bilibili\.com/(?:[a-z]{2}(?:-Hans)?/)?"
                  r"(?:video/|festival/[^/?#]+\?(?:[^#]*&)?bvid=)(?P<prefix>[aAbB][vV])(?P<id>[^/?#&]+)")

    def _real_extract(self, url):
        match = self._match_valid_url(url)
        prefix, identity = match.group("prefix", "id")
        key = "bvid" if prefix.upper() == "BV" else "aid"
        value = "BV" + identity if key == "bvid" else identity
        self._studio_query = {key: value, "platform": "web"}
        try:
            return super()._real_extract(url)
        except _BangumiRedirect as redirect:
            return self.url_result(str(redirect), BiliBiliBangumiIE)

    def _search_json(self, pattern, string, name, video_id, **kwargs):
        state = super()._search_json(pattern, string, name, video_id, **kwargs)
        if name != "initial state" or state:
            return state
        risk = super()._search_json(r"\bwindow\._riskdata_\s*=", string, "risk", video_id, default={})
        if risk.get("v_voucher"):
            raise ExtractorError("You have exceeded the rate limit. Try again later", expected=True)
        result = self._download_json(
            "https://api.bilibili.com/x/web-interface/wbi/view/detail", video_id,
            note="Downloading video details", query=self._sign_wbi(self._studio_query, video_id),
            headers={"Referer": "https://www.bilibili.com/", "Origin": "https://www.bilibili.com"})
        detail = result.get("data") or {}
        video = detail.get("View") or {}
        if result.get("code") != 0 or not video.get("bvid"):
            raise ExtractorError(f"Bilibili video details unavailable: {result.get('message') or result.get('code')}",
                                 expected=True)
        redirect = video.get("redirect_url") or ""
        if redirect and BiliBiliBangumiIE.suitable(redirect):
            raise _BangumiRedirect(redirect)
        return {"videoData": video, "upData": video.get("owner") or {}, "tags": detail.get("Tags") or []}

    def extract_formats(self, play_info):
        formats = super().extract_formats(play_info)
        # Some networks cannot reach the primary Akamai host. Bilibili supplies
        # signed backup URLs for the exact same media; expose them to yt-dlp's
        # selected-format availability check, preserving quality and both tracks.
        dash = play_info.get("dash") or {}
        streams = list(dash.get("video") or []) + list(dash.get("audio") or [])
        streams += list((dash.get("dolby") or {}).get("audio") or [])
        flac = (dash.get("flac") or {}).get("audio")
        if isinstance(flac, dict):
            streams.append(flac)
        by_url = {s.get("baseUrl") or s.get("base_url") or s.get("url"): s for s in streams}
        alternates = []
        for fmt in formats:
            stream = by_url.get(fmt.get("url")) or {}
            urls = stream.get("backupUrl") or stream.get("backup_url") or []
            if not isinstance(urls, list):
                continue
            seen = {fmt.get("url")}
            for index, url in enumerate(urls, 1):
                if not isinstance(url, str) or url in seen or urlsplit(url).scheme not in ("http", "https"):
                    continue
                seen.add(url)
                alternates.append({**fmt, "url": url, "format_id": f"{fmt.get('format_id')}-backup{index}",
                                   "source_preference": -index})
        return formats + alternates


def extract(ydl, url, download=True):
    """Register only on this Movie Search download; all other extractors stay as shipped."""
    ydl.add_info_extractor(StudioBilibiliIE())
    return ydl.extract_info(url, download=download, ie_key=StudioBilibiliIE.ie_key())
