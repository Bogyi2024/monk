"""Tools that open in their own window (copies in ../tool_apps, made by tools/sync_tools.py): Dubbing, Subtitle,
Original→Recap. Each runs in its own process — Dubbing, Recap and Storytelling load Whisper/torch CUDA libraries
that crash each other inside one process (Dubbing 2026-10-07: "Could not load symbol cudnnGetLibConfig").

Before a tool opens, its settings file is pointed at the Profile's Gemini keys (keys_file.py); Studio99 closes the
tools when it closes."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import keys_file
import local_mode
import token_store

ROOT = Path(__file__).resolve().parents[1]
APPS = ROOT / "tool_apps"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


@dataclass(frozen=True)
class WindowTool:
    id: str
    folder: str
    args: tuple[str, ...]
    settings: str                 # the tool's own settings file (relative to its folder)
    key_field: str                # the field in it that holds the .env path


WINDOW_TOOLS = {
    "dubbing": WindowTool("dubbing", "dubbing", ("run_dubber.py", "ui"), "last_config.json", "env_file"),
    "subtitle": WindowTool("subtitle", "subtitle", ("app.py",), "ui_settings.json", "env_file"),
    "storytelling": WindowTool("storytelling", "storytelling", ("app/controller.py",), "config.json",
                                 "gemini_env_path"),
}
_running: dict[str, subprocess.Popen] = {}


def pythonw() -> str:
    exe = Path(sys.executable)
    candidate = exe.with_name("pythonw.exe")
    return str(candidate if candidate.exists() else exe)


def available(tool_id: str) -> bool:
    tool = WINDOW_TOOLS.get(tool_id)
    return bool(tool) and (APPS / tool.folder / tool.args[0]).is_file()


def _point_at_keys(tool: WindowTool, keys: Path | None) -> None:
    path = APPS / tool.folder / tool.settings
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        data = {}
    data[tool.key_field] = str(keys) if keys else ""
    token_store._atomic_write(path, json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"))


def is_running(tool_id: str) -> bool:
    proc = _running.get(tool_id)
    return proc is not None and proc.poll() is None


def launch(tool_id: str, *, token: str = "", server: str = "") -> bool:
    """Open the tool's window. False when it is already open."""
    if is_running(tool_id):
        return False
    tool = WINDOW_TOOLS[tool_id]
    # Keep a stable shared path even when Profile has no key yet. Saving in Profile
    # after this window opens must make the file available to that same window.
    _point_at_keys(tool, keys_file.write() or keys_file.KEYS_FILE)
    import ffmpeg_speed                      # encode speed chosen in Studio99, in the tool and its workers
    env = ffmpeg_speed.child_env(dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", STUDIO99="1"), tool_id)
    if token:
        env["STUDIO99_TOKEN"] = token
    if server:
        env["STUDIO99_SERVER"] = server
    if local_mode.enabled():
        env["STUDIO99_LOCAL"] = "1"             # the tool's own require_vip() is skipped offline
    log = open(ROOT / "logs" / f"{tool_id}.log", "ab") if (ROOT / "logs").is_dir() else subprocess.DEVNULL
    hook = str(Path(__file__).with_name("embed_hook.py"))      # keyboard focus while shown inside Studio99
    _running[tool_id] = subprocess.Popen([pythonw(), "-X", "utf8", hook, *tool.args], cwd=str(APPS / tool.folder), env=env,
                                         stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                         creationflags=NO_WINDOW)
    if log is not subprocess.DEVNULL:
        log.close()
    return True


def running_titles() -> list[str]:
    return [tool_id for tool_id in WINDOW_TOOLS if is_running(tool_id)]


def stop_all() -> None:
    from web_tool_job import stop_process
    for proc in _running.values():
        stop_process(proc)
