"""Local GPU VoxCPM2 TTS engine (openbmb/VoxCPM2) ? Clean Official API + Colab/Kaggle Multi-GPU.

Uses the official `VoxCPM.from_pretrained(..., load_denoiser=False, optimize=...)` and `model.generate(...)` API
without risky dtype/monkey-patch hacks:
- Colab T4 (cc 7.5, 12.7 GB RAM): 1 worker, steps=6, compile=OFF (no bfloat16 compile warnings)
- Kaggle T4 x 2 (30 GB RAM): 2 parallel GPU workers (cuda:0 + cuda:1)
- Ampere+ L4/A100 (cc >= 8.0): TF32 + torch.compile ON, steps=8
- Unloads model from RAM/VRAM before FFmpeg video rendering to prevent Colab OOM
"""
from __future__ import annotations

import gc
import hashlib
import os
import queue
import shutil
import subprocess
import threading
import uuid
from pathlib import Path
from typing import Any

MODEL_ID = os.environ.get("STUDIO99_VOXCPM2_MODEL", "openbmb/VoxCPM2")

PRESETS: dict[str, tuple[str, str]] = {
    "voxcpm2:male_narrator": (
        "VoxCPM2 Male Narrator (48kHz)",
        "A calm adult man with a warm, clear storytelling narrator voice and steady pace",
    ),
    "voxcpm2:female_narrator": (
        "VoxCPM2 Female Narrator (48kHz)",
        "A gentle adult woman with a clear, expressive storytelling narrator voice and steady pace",
    ),
    "voxcpm2:male_dramatic": (
        "VoxCPM2 Male Dramatic (48kHz)",
        "A deep resonant male narrator with a dramatic cinematic movie recap tone",
    ),
    "voxcpm2:female_warm": (
        "VoxCPM2 Female Warm (48kHz)",
        "A warm young woman with a friendly conversational voice and natural intonation",
    ),
    "voxcpm2:clone": (
        "VoxCPM2 Voice Clone (Upload Reference Audio)",
        "",
    ),
    "voxcpm2:design": (
        "VoxCPM2 Custom Voice Design",
        "",
    ),
    "voxcpm2:auto": (
        "VoxCPM2 Auto Voice (48kHz)",
        "",
    ),
}

VOXCPM2_VOICES: tuple[str, ...] = tuple(PRESETS.keys())

_MODELS: dict[int, Any] = {}
_MODEL_OPTIMIZED: dict[int, bool] = {}
_GPU_LOCKS: dict[int, threading.RLock] = {}
_GPU_POOL: queue.Queue[int] | None = None
_HW_PROFILE: dict[str, Any] | None = None
_GLOBAL_LOCK = threading.RLock()


def is_voxcpm2(voice: str) -> bool:
    return str(voice or "").strip().lower().startswith("voxcpm2:")


def available() -> bool:
    try:
        import voxcpm  # noqa: F401
        return True
    except Exception:
        return False


def detect_hardware() -> dict[str, Any]:
    """Inspect GPU count, VRAM, compute capability, System RAM, and compiler to pick optimal Colab/Kaggle settings."""
    global _HW_PROFILE
    if _HW_PROFILE is not None:
        return dict(_HW_PROFILE)

    ram_gb = 0.0
    try:
        import psutil
        ram_gb = psutil.virtual_memory().total / (1024 ** 3)
    except Exception:
        try:
            ram_gb = (os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")) / (1024 ** 3)
        except Exception:
            ram_gb = 12.0

    gpu_name = "CPU"
    vram_gb = 0.0
    cc = (0, 0)
    cuda_ok = False
    gpu_count = 0
    try:
        import torch
        if torch.cuda.is_available():
            cuda_ok = True
            gpu_count = max(1, int(torch.cuda.device_count()))
            props = torch.cuda.get_device_properties(0)
            gpu_name = str(props.name)
            vram_gb = props.total_memory / (1024 ** 3)
            cc = (int(props.major), int(props.minor))
    except Exception:
        pass

    has_compiler = bool(shutil.which("gcc") or shutil.which("clang") or os.environ.get("CC"))
    try:
        import triton  # noqa: F401
        has_triton = True
    except Exception:
        has_triton = False

    # Turing T4 (cc 7.5) does not support native bfloat16 inductor compilation;
    # enable torch.compile by default only on Ampere+ (cc >= 8.0) unless forced via env var.
    use_tf32 = cuda_ok and cc[0] >= 8
    compile_env = os.environ.get("STUDIO99_VOXCPM2_COMPILE", "").strip().lower()
    if compile_env in ("1", "true", "yes", "on"):
        use_compile = cuda_ok and has_compiler and has_triton
    elif compile_env in ("0", "false", "no", "off"):
        use_compile = False
    else:
        use_compile = cuda_ok and cc[0] >= 8 and has_compiler and has_triton

    if not cuda_ok:
        auto_steps = 5
        workers = 1
    elif gpu_count >= 2 and ram_gb >= 18.0:
        auto_steps = 6 if cc[0] < 8 else 8
        workers = min(gpu_count, 2)
    elif vram_gb >= 22.0:
        auto_steps = 8
        workers = 1
    else:
        auto_steps = 6
        workers = 1

    workers_env = os.environ.get("STUDIO99_VOXCPM2_WORKERS", "").strip()
    if workers_env.isdigit():
        req_w = max(1, int(workers_env))
        workers = min(req_w, max(1, gpu_count)) if cuda_ok else 1

    platform_name = "Kaggle" if os.path.isdir("/kaggle/working") else ("Colab" if os.path.isdir("/content") else "Local")

    _HW_PROFILE = {
        "platform": platform_name,
        "cuda": cuda_ok,
        "gpu_count": gpu_count,
        "gpu_name": gpu_name,
        "vram_gb": round(vram_gb, 1),
        "ram_gb": round(ram_gb, 1),
        "compute_cap": f"{cc[0]}.{cc[1]}" if cuda_ok else "cpu",
        "use_tf32": use_tf32,
        "use_compile": use_compile,
        "auto_steps": auto_steps,
        "workers": workers,
    }
    return dict(_HW_PROFILE)


def _configure_torch(hw: dict[str, Any]) -> None:
    try:
        import torch
        if hw["cuda"]:
            torch.backends.cudnn.benchmark = True
            if hw["use_tf32"]:
                torch.backends.cuda.matmul.allow_tf32 = True
                torch.backends.cudnn.allow_tf32 = True
                if hasattr(torch, "set_float32_matmul_precision"):
                    torch.set_float32_matmul_precision("high")
    except Exception:
        pass


def _get_gpu_lock(gpu_id: int) -> threading.RLock:
    with _GLOBAL_LOCK:
        lock = _GPU_LOCKS.get(gpu_id)
        if lock is None:
            lock = threading.RLock()
            _GPU_LOCKS[gpu_id] = lock
        return lock


def _ensure_gpu_pool() -> queue.Queue[int]:
    global _GPU_POOL
    with _GLOBAL_LOCK:
        if _GPU_POOL is None:
            hw = detect_hardware()
            q: queue.Queue[int] = queue.Queue()
            for gid in range(max(1, int(hw["workers"]))):
                q.put(gid)
            _GPU_POOL = q
        return _GPU_POOL


def _load_model_on_gpu(gpu_id: int, log=print, force_eager: bool = False):
    lock = _get_gpu_lock(gpu_id)
    with lock:
        if gpu_id in _MODELS and not (force_eager and _MODEL_OPTIMIZED.get(gpu_id, False)):
            return _MODELS[gpu_id]
        try:
            from voxcpm import VoxCPM
        except ImportError as exc:
            raise RuntimeError(
                "VoxCPM2 မတင်ရသေးပါ — setup cell မှာ `pip install voxcpm soundfile` ကို run ပါ။"
            ) from exc

        hw = detect_hardware()
        _configure_torch(hw)
        want_opt = hw["use_compile"] and not force_eager
        dev_str = f"cuda:{gpu_id}" if hw["cuda"] else "cpu"

        if hw["cuda"]:
            import torch
            torch.cuda.set_device(gpu_id)

        gpu_tag = f"{hw['gpu_name']} x{hw['gpu_count']}" if hw["gpu_count"] > 1 else hw["gpu_name"]
        log(
            f"⚡ VoxCPM2 [{hw['platform']} · {dev_str}]: {gpu_tag} ({hw['vram_gb']} GB VRAM) | "
            f"RAM {hw['ram_gb']} GB → workers={hw['workers']}, steps={hw['auto_steps']}, "
            f"compile={'ON' if want_opt else 'OFF'}, TF32={'ON' if hw['use_tf32'] else 'OFF'}"
        )

        def _do_load(opt_flag: bool):
            with _GLOBAL_LOCK:
                gc.collect()
                if hw["cuda"]:
                    import torch
                    torch.cuda.set_device(gpu_id)
                try:
                    return VoxCPM.from_pretrained(MODEL_ID, load_denoiser=False, optimize=opt_flag, device=dev_str)
                except TypeError:
                    try:
                        return VoxCPM.from_pretrained(MODEL_ID, load_denoiser=False, optimize=opt_flag)
                    except TypeError:
                        return VoxCPM.from_pretrained(MODEL_ID, load_denoiser=False)

        try:
            model = _do_load(want_opt)
            opt_used = want_opt
        except Exception as exc:
            if want_opt:
                log(f"⚠️ [{dev_str}] torch.compile fallback to eager mode: {exc}")
                model = _do_load(False)
                opt_used = False
            else:
                raise

        if hw["cuda"]:
            try:
                import torch
                tts_m = getattr(model, "tts_model", None)
                if tts_m is not None and hasattr(tts_m, "to"):
                    tts_m.to(torch.device(dev_str))
            except Exception:
                pass

        gc.collect()
        _MODELS[gpu_id] = model
        _MODEL_OPTIMIZED[gpu_id] = opt_used
        log(f"✅ VoxCPM2 model ready on {dev_str} (48kHz).")
        return model


def _load_model(log=print, force_eager: bool = False):
    return _load_model_on_gpu(0, log=log, force_eager=force_eager)


def _ensure_wav(ref_path: Path, work_dir: Path, ffmpeg: str = "ffmpeg") -> Path:
    ref_path = Path(ref_path).expanduser().resolve()
    if not ref_path.is_file():
        raise FileNotFoundError(f"VoxCPM2 reference audio မတွေ့ပါ: {ref_path}")
    if ref_path.suffix.lower() == ".wav":
        return ref_path
    work_dir.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha1(f"{ref_path}|{ref_path.stat().st_mtime_ns}".encode("utf-8")).hexdigest()[:12]
    out_wav = work_dir / f"voxcpm_ref_{digest}.wav"
    if not out_wav.is_file():
        with _GLOBAL_LOCK:
            if not out_wav.is_file():
                ff = shutil.which(ffmpeg) or ffmpeg
                subprocess.run(
                    [ff, "-y", "-v", "error", "-i", str(ref_path), "-ac", "1", "-ar", "48000", "-c:a", "pcm_s16le", str(out_wav)],
                    check=True,
                )
    return out_wav


def _effective_steps(steps: int | None) -> int:
    val = int(steps or 0)
    if val <= 0:
        return int(detect_hardware()["auto_steps"])
    return max(4, min(40, val))


def fingerprint(
    voice: str,
    *,
    ref_audio: str = "",
    prompt_text: str = "",
    design: str = "",
    steps: int = 0,
) -> str:
    eff_steps = _effective_steps(steps)
    ref_sig = ""
    if ref_audio:
        p = Path(ref_audio)
        if p.is_file():
            ref_sig = f"{p.name}:{p.stat().st_size}:{p.stat().st_mtime_ns}"
        else:
            ref_sig = ref_audio
    raw = f"{MODEL_ID}|{voice}|{ref_sig}|{prompt_text.strip()}|{design.strip()}|{eff_steps}"
    return f"{voice}|voxcpm2|" + hashlib.sha256(raw.encode("utf-8")).hexdigest()


def synthesize(
    text: str,
    voice: str,
    output_wav: Path,
    *,
    ref_audio: str = "",
    prompt_text: str = "",
    design: str = "",
    steps: int = 0,
    cfg_value: float = 2.0,
    ffmpeg: str = "ffmpeg",
    work_dir: Path | None = None,
    log=print,
    gpu_id: int | None = None,
) -> Path:
    """Generate speech to output_wav using the clean official VoxCPM.generate() API."""
    clean_text = " ".join(str(text or "").split()).strip()
    if not clean_text:
        raise ValueError("VoxCPM2 text ဗလာဖြစ်နေပါတယ်။")

    output_wav = Path(output_wav)
    output_wav.parent.mkdir(parents=True, exist_ok=True)
    cache_dir = Path(work_dir) if work_dir else output_wav.parent

    voice_key = str(voice or "voxcpm2:male_narrator").strip()
    preset_desc = PRESETS.get(voice_key, ("", ""))[1]
    style_desc = str(design or "").strip() or preset_desc
    eff_steps = _effective_steps(steps)

    kwargs: dict[str, Any] = {
        "cfg_value": float(cfg_value),
        "inference_timesteps": eff_steps,
    }

    ref_clean = str(ref_audio or "").strip()
    prompt_clean = str(prompt_text or "").strip()

    if voice_key == "voxcpm2:clone":
        if not ref_clean:
            raise ValueError("VoxCPM2 Voice Clone အတွက် Reference Audio (3-10s WAV/MP3) ကို အရင် upload လုပ်ပါ။")
        wav_ref_str = str(_ensure_wav(Path(ref_clean), cache_dir, ffmpeg=ffmpeg))
        kwargs["reference_wav_path"] = wav_ref_str
        if prompt_clean:
            kwargs["prompt_wav_path"] = wav_ref_str
            kwargs["prompt_text"] = prompt_clean
    elif ref_clean and Path(ref_clean).is_file():
        wav_ref_str = str(_ensure_wav(Path(ref_clean), cache_dir, ffmpeg=ffmpeg))
        kwargs["reference_wav_path"] = wav_ref_str
        if prompt_clean:
            kwargs["prompt_wav_path"] = wav_ref_str
            kwargs["prompt_text"] = prompt_clean

    synth_text = f"({style_desc}){clean_text}" if style_desc else clean_text

    import numpy as np
    import soundfile as sf
    import torch

    pool = None
    assigned_gpu = gpu_id
    if assigned_gpu is None:
        pool = _ensure_gpu_pool()
        assigned_gpu = pool.get()

    try:
        model = _load_model_on_gpu(assigned_gpu, log=log)
        lock = _get_gpu_lock(assigned_gpu)
        with lock:
            if torch.cuda.is_available():
                torch.cuda.set_device(assigned_gpu)
            try:
                wav = model.generate(text=synth_text, **kwargs)
            except Exception as exc:
                if _MODEL_OPTIMIZED.get(assigned_gpu, False) and (
                    "inductor" in str(exc).lower() or "compile" in str(exc).lower() or "compiler" in str(exc).lower()
                ):
                    log(f"⚠️ [cuda:{assigned_gpu}] torch.compile failed ({exc}); switching to eager mode...")
                    model = _load_model_on_gpu(assigned_gpu, log=log, force_eager=True)
                    wav = model.generate(text=synth_text, **kwargs)
                else:
                    raise
            sample_rate = int(getattr(getattr(model, "tts_model", None), "sample_rate", 48000))
    finally:
        if pool is not None:
            pool.put(assigned_gpu)

    if hasattr(wav, "detach"):
        wav = wav.detach().float().cpu().numpy()
    wav = np.asarray(wav, dtype=np.float32)
    if wav.ndim > 1:
        wav = wav.squeeze()

    part = output_wav.with_name(f".{output_wav.stem}_{uuid.uuid4().hex[:6]}.wav")
    sf.write(str(part), wav, sample_rate)
    part.replace(output_wav)
    return output_wav


def unload_models(log=print) -> None:
    """Free VoxCPM2 weights from CPU RAM and GPU VRAM before FFmpeg video rendering."""
    with _GLOBAL_LOCK:
        had_models = bool(_MODELS)
        _MODELS.clear()
        _MODEL_OPTIMIZED.clear()
    gc.collect()
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
    except Exception:
        pass
    try:
        import ctypes
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass
    if had_models and log:
        log("🧹 VoxCPM2 unloaded from RAM/VRAM before video render.")
