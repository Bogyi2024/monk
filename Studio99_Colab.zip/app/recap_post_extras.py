"""Auto-generate Facebook/TikTok Burmese Caption + Hashtags (.txt) and Key-frame Thumbnail (.jpg)
for finished Recap videos in Studio99 Colab, plus Drive Auto-Save."""
from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path


def _extract_thumbnail(ffmpeg: str, video_path: Path, out_jpg: Path, duration: float = 0.0) -> Path | None:
    ff = shutil.which(ffmpeg) or ffmpeg
    ts = max(1.5, min(duration * 0.30, max(1.5, duration - 1.5))) if duration > 4.0 else 1.0
    out_jpg.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        ff, "-y", "-hide_banner", "-loglevel", "error",
        "-ss", f"{ts:.2f}", "-i", str(video_path),
        "-frames:v", "1", "-q:v", "2", str(out_jpg),
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    return out_jpg if r.returncode == 0 and out_jpg.is_file() and out_jpg.stat().st_size > 500 else None


def _build_caption_text(title: str, script_lines: list[str], gemini_keys: list[str]) -> str:
    joined = "\n".join(line.strip() for line in script_lines[:40] if line.strip())[:3500]
    fallback = (
        f"🎬 {title}\n\n"
        + (" ".join(script_lines[:3])[:260] + "...\n\n" if script_lines else "")
        + "အဆုံးထိ ကြည့်ပြီး ဘယ်လိုထင်လဲ Comment မှာ ပြောပြသွားဦးနော် 👇\n\n"
        + "#MovieRecap #MyanmarRecap #ဇာတ်ကားအကျဉ်း #မြန်မာစာတန်းထိုး #RecapMyanmar #MovieReviewMM"
    )
    if not gemini_keys or not joined:
        return fallback
    prompt = (
        "You are a Burmese movie recap social media editor.\n"
        "Write a short, engaging Facebook/TikTok post caption in natural Myanmar (Burmese) based on the recap script below.\n"
        "Format:\n"
        "1. One catchy hook headline with 1-2 relevant emojis\n"
        "2. 2-3 short suspenseful sentences summarizing the premise WITHOUT spoiling the ending\n"
        "3. One engaging question for comments\n"
        "4. 8-10 relevant Myanmar & English hashtags on the last line\n\n"
        f"Title: {title}\nScript excerpt:\n{joined}"
    )
    try:
        import custom_llm_client
        _cfg = custom_llm_client.load_config()
        _m = (_cfg["models"][0] if _cfg["models"] else "gemini-2.5-flash")
        for key in gemini_keys[:3]:
            try:
                client = custom_llm_client.make_client(api_key=key)
                resp = client.models.generate_content(model=_m, contents=prompt)
                text = str(getattr(resp, "text", "") or "").strip()
                if len(text) > 30:
                    return text
            except Exception:
                continue
    except Exception:
        pass
    return fallback


def generate_extras(
    final_video: Path,
    plan: dict,
    *,
    ffmpeg: str = "ffmpeg",
    duration: float = 0.0,
    title: str = "",
    gemini_keys: list[str] | None = None,
    log=print,
) -> list[Path]:
    """Create <stem>_thumb.jpg and <stem>_caption.txt next to final_video. Never raises."""
    created: list[Path] = []
    final_video = Path(final_video)
    display_title = (title or final_video.stem).strip()
    display_title = re.sub(r"_Myanmar_[0-9a-f]{6}_\d{3}$", "", display_title)

    try:
        thumb = _extract_thumbnail(
            ffmpeg, final_video, final_video.with_name(f"{final_video.stem}_thumb.jpg"), duration=duration
        )
        if thumb:
            created.append(thumb)
            log(f"🖼️ Thumbnail saved: {thumb.name}")
    except Exception as exc:
        log(f"⚠️ Thumbnail skipped: {exc}")

    try:
        segs = plan.get("segments") or []
        lines = [str(s.get("narration") or "").strip() for s in segs if str(s.get("narration") or "").strip()]
        caption = _build_caption_text(display_title, lines, list(gemini_keys or []))
        cap_path = final_video.with_name(f"{final_video.stem}_caption.txt")
        cap_path.write_text(caption, encoding="utf-8")
        created.append(cap_path)
        log(f"✍️ Caption + Hashtags saved: {cap_path.name}")
    except Exception as exc:
        log(f"⚠️ Caption skipped: {exc}")

    return created


def auto_save_to_drive(files: list[Path], log=print) -> list[Path]:
    """If Google Drive is mounted at /content/drive/MyDrive, copy finished files to Studio99Outputs."""
    drive_root = Path("/content/drive/MyDrive")
    if not drive_root.is_dir():
        return []
    dest_dir = drive_root / "Studio99Outputs"
    dest_dir.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []
    for src in files:
        try:
            src_p = Path(src).expanduser().resolve()
            if not src_p.is_file():
                continue
            if dest_dir.resolve() in src_p.parents or src_p.parent == dest_dir.resolve():
                continue
            dst = dest_dir / src_p.name
            shutil.copy2(src_p, dst)
            saved.append(dst)
        except Exception as exc:
            log(f"⚠️ Drive auto-save failed for {Path(src).name}: {exc}")
    if saved:
        log(f"☁️ Auto-saved {len(saved)} file(s) to Google Drive: {dest_dir}")
    return saved
