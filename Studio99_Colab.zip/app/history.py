"""What the tools made (for Home's "this month" count): %APPDATA%\\Studio99Desktop\\history.json, newest last.
Kept small (the last 2000 entries)."""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path

from token_store import APP_DIR

FILE = APP_DIR / "history.json"
_lock = threading.Lock()


def load() -> list[dict]:
    try:
        return list(json.loads(FILE.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        return []


def add(kind: str, path: str | Path, title: str = "") -> None:
    with _lock:
        items = load()[-1999:]
        items.append({"kind": kind, "path": str(path), "title": title, "at": time.strftime("%Y-%m-%d %H:%M")})
        APP_DIR.mkdir(parents=True, exist_ok=True)
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(FILE)


def this_month() -> int:
    month = time.strftime("%Y-%m")
    return sum(1 for item in load() if str(item.get("at", "")).startswith(month))
