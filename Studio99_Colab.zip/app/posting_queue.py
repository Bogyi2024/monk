"""Auto Posting list: finished videos waiting to be posted. The engine (engine/studio99/posting_bridge.py) posts
them at the times its routes allow; this module adds and removes items. Both use the same file and lock
(engine/studio99/posting_list.py): engine/state/studio99_posting_list.json.

Each tool sends to its own card (category): Recap → post_recap, Splitter → post_splitter, … A video that is already
on the list for that card, or was ever posted by it (engine/state/studio99_posted.json), is not added again."""
from __future__ import annotations

import sys
import uuid
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "engine"
if str(ENGINE) not in sys.path:
    sys.path.append(str(ENGINE))
from studio99 import posting_list  # noqa: E402  (no heavy imports: the list format + lock)

QUEUE_FILE = ENGINE / "state" / posting_list.LIST_NAME
LEDGER_FILE = ENGINE / "state" / posting_list.LEDGER_NAME
CATEGORIES = posting_list.CATEGORIES
category_for_origin = posting_list.category_for_origin
item_key = posting_list.item_key


def load() -> list[dict]:
    return [x for x in posting_list.load(QUEUE_FILE) if x.get("status") != "removed"]


def ledger() -> dict:
    return posting_list.load_ledger(LEDGER_FILE)


def _item(video: str | Path, *, caption: str, targets: list[str], post_at: str, source: str, origin: str,
          delete_after_post: bool, kind: str = "video", images: list[str] | None = None, text: str = "") -> dict:
    """kind "photo": images + text as one Facebook photo post ("video" = the cover, the item's key and preview)."""
    return {"id": uuid.uuid4().hex[:12], "video": str(video), "caption": str(caption or "").strip(),
            "kind": kind if kind in posting_list.KINDS else "video", "images": [str(x) for x in images or []],
            "text": str(text or ""),
            "category": category_for_origin(origin), "targets": list(targets), "post_at": str(post_at or "").strip(),
            "source": str(source or ""), "origin": origin, "status": "queued",
            "delete_after_post": bool(delete_after_post), "added": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "done": {}, "failed": {}}


def add_many(entries: list[dict], *, origin: str, targets: list[str] | None = None, post_at: str = "",
             delete_after_post: bool = False) -> dict:
    """entries: [{video, caption?, source?, kind?, images?, text?}] in the order they should be posted
    (Splitter parts / Novel parts: part 1 first).
    Returns {"added": [...], "skipped": [{video, why}]} — already on this card's list / already posted by it."""
    category = category_for_origin(origin)
    posted = ledger()
    added, skipped = [], []
    with posting_list.locked(QUEUE_FILE):
        items = posting_list.load(QUEUE_FILE)
        waiting = set().union(*(posting_list.item_keys(x) for x in items
                                if x.get("category") == category and x.get("status") != "removed"))
        for entry in entries:
            item = _item(entry["video"], caption=entry.get("caption") or Path(str(entry["video"])).stem,
                         targets=list(targets or []), post_at=entry.get("post_at") or post_at,
                         source=entry.get("source") or "", origin=origin, delete_after_post=delete_after_post,
                         kind=entry.get("kind") or "video", images=entry.get("images"), text=entry.get("text") or "")
            keys = posting_list.item_keys(item)          # its link and its file: either one already known = same video
            if keys & waiting:
                skipped.append({"video": item["video"], "why": "list ထဲမှာ ရှိပြီးသား"})
                continue
            if posting_list.posted_before(posted, item, category):
                skipped.append({"video": item["video"], "why": "တင်ပြီးသား"})
                continue
            waiting |= keys
            items.append(item)
            added.append(item)
        if added:
            posting_list.save(QUEUE_FILE, items)
    return {"added": added, "skipped": skipped}


def add(video: str | Path, *, caption: str, targets: list[str], post_at: str = "", source: str = "",
        origin: str = "recap", delete_after_post: bool = False) -> dict | None:
    """One video. targets: route keys of the item's card ([] = every enabled route of it);
    post_at: "" = the route's next time slot, else not before "YYYY-MM-DD HH:MM".
    None when the card already has it (waiting or posted)."""
    out = add_many([{"video": video, "caption": caption, "source": source}], origin=origin, targets=targets,
                   post_at=post_at, delete_after_post=delete_after_post)
    return out["added"][0] if out["added"] else None


def remove(ids: set[str] | list[str], *, videos: set[str] | None = None) -> None:
    """Take items off the list (by id, or every item of the given video paths). The posted ledger is kept."""
    ids, videos = set(ids), {str(Path(v)) for v in videos or ()}
    with posting_list.locked(QUEUE_FILE):
        items = [x for x in posting_list.load(QUEUE_FILE)
                 if x.get("id") not in ids and str(Path(x.get("video", ""))) not in videos]
        posting_list.save(QUEUE_FILE, items)


def contains(video: str | Path) -> bool:
    return any(Path(x.get("video", "")) == Path(video) for x in load())


def summary() -> dict[str, dict]:
    """Per card: waiting / posting / posted today / posted in all / failed."""
    today = datetime.now().strftime("%Y-%m-%d")
    out = {key: {"waiting": 0, "posting": 0, "today": 0, "posted": 0, "failed": 0} for key in CATEGORIES}
    for item in load():
        s = out.setdefault(item.get("category") or "",
                           {"waiting": 0, "posting": 0, "today": 0, "posted": 0, "failed": 0})
        status = item.get("status")
        if status == "queued":
            s["waiting"] += 1
        elif status == "posting":
            s["posting"] += 1
        if item.get("failed"):
            s["failed"] += 1
    for entry in ledger().values():
        s = out.get(entry.get("category") or "")
        if s is None:
            continue
        s["posted"] += 1
        if any(str(at).startswith(today) for at in (entry.get("routes") or {}).values()):
            s["today"] += 1
    return out
