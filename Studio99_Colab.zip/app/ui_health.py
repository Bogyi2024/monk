"""WebView2 startup diagnostics and bounded renderer recovery, separate from tool engines."""
from __future__ import annotations

import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import re
import time


def configure_rendering(environ=None):
    """Use software composition for the app window; Whisper/FFmpeg/CUDA settings are independent."""
    env = os.environ if environ is None else environ
    flags = env.get('WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS', '')
    if env.get('STUDIO99_UI_HARDWARE') != '1':
        for flag in ('--disable-gpu', '--disable-gpu-compositing'):
            if flag not in flags.split():
                flags = (flags + ' ' + flag).strip()
    env['WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS'] = flags
    return flags


def safe_detail(value):
    text = str(value)[:6000]
    for pattern in (r'AIza[\w-]{30,}', r'sk-(?:proj-)?[\w-]{20,}', r'eyJ[\w-]+\.[\w-]+\.[\w-]+',
                    r'\b\d{8,12}:AA[\w-]{20,}'):
        text = re.sub(pattern, '[redacted]', text)
    return text


class UIHealth:
    def __init__(self, logs: Path, *, clock=time.monotonic):
        self.clock = clock
        self.window = None
        self._core = None
        self._handlers = []
        self._failures = []
        self._fallback = None
        self.logger = logging.getLogger(f'studio99.ui.{id(self)}')
        self.logger.setLevel(logging.INFO)
        self.logger.propagate = False
        try:
            Path(logs).mkdir(parents=True, exist_ok=True)
            handler = RotatingFileHandler(Path(logs)/'ui_health.log', maxBytes=512*1024, backupCount=1, encoding='utf-8')
            handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
            self.logger.addHandler(handler)
        except OSError:
            self.logger.addHandler(logging.NullHandler())

    def record(self, event, **details):
        self.logger.info('%s %s', event, safe_detail(json.dumps(details, ensure_ascii=False, default=str)))

    def attach(self, window):
        self.window = window
        window.events.shown += self.bind_native
        window.events.loaded += self.loaded
        self.record('startup', software_rendering=os.environ.get('STUDIO99_UI_HARDWARE') != '1')

    def loaded(self):
        self.record('document_loaded')
        self.bind_native()

    def bind_native(self):
        if os.name != 'nt' or self.window is None:
            return
        try:
            from System import Action
            view = self.window.native.webview
            def bind():
                if self._core is not None:
                    return
                if view.CoreWebView2 is not None:
                    self._bind_core(view.CoreWebView2)
                elif not self._handlers:
                    def ready(sender, args):
                        if args.IsSuccess:
                            self._bind_core(sender.CoreWebView2)
                        else:
                            self.record('initialization_failed', error=args.InitializationException)
                            self._native_message()
                    view.CoreWebView2InitializationCompleted += ready
                    self._handlers.append(ready)
            view.Invoke(Action(bind))
        except Exception as exc:
            self.record('native_hook_error', error=exc)

    def _bind_core(self, core):
        if self._core is not None:
            return
        self._core = core
        core.ProcessFailed += self._process_failed
        self._handlers.append(self._process_failed)
        self.record('native_ready', browser_version=core.Environment.BrowserVersionString)

    def _process_failed(self, sender, args):
        kind = str(args.ProcessFailedKind)
        self.record('process_failed', kind=kind, reason=getattr(args,'Reason',''), exit_code=getattr(args,'ExitCode',''))
        self.recover(kind, sender.Reload, self._native_message)

    def recover(self, kind, reload, fallback):
        """GPU/utility failures auto-recover; main renderer failures need a reload (bounded)."""
        if kind == 'BrowserProcessExited':
            fallback()
            return 'restart_required'
        if kind not in {'RenderProcessExited','RenderProcessUnresponsive'}:
            return 'automatic'
        now = self.clock()
        self._failures = [stamp for stamp in self._failures if now-stamp < 60]
        if len(self._failures) >= 2:
            fallback()
            return 'restart_required'
        self._failures.append(now)
        try:
            reload()
            self.record('renderer_reload', attempt=len(self._failures))
            return 'reloaded'
        except Exception as exc:
            self.record('reload_failed', error=exc)
            fallback()
            return 'restart_required'

    def _native_message(self):
        """Remain readable even when the browser process itself can no longer draw HTML."""
        if self._fallback is not None:
            return
        try:
            from System.Drawing import Color, Font
            from System.Windows.Forms import DockStyle, Label, Padding
            label = Label()
            label.Dock = DockStyle.Fill
            label.BackColor = Color.FromArgb(11,13,18)
            label.ForeColor = Color.White
            label.Font = Font('Segoe UI',12)
            label.Padding = Padding(32)
            label.Text = ('Studio99 display could not recover.\n\n'
                          'Please close and reopen Studio99. Your saved projects remain available.\n\n'
                          'Diagnostic file: logs/ui_health.log')
            self.window.native.Controls.Add(label)
            label.BringToFront()
            self._fallback = label
        except Exception as exc:
            self.record('fallback_error', error=exc)

    def close(self):
        for handler in list(self.logger.handlers):
            handler.close()
            self.logger.removeHandler(handler)
