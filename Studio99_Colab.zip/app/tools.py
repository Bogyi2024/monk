"""The tools shown as boxes on the home screen. `status`: ready / soon. `vip`: only VIP members can open it.
Icons are Segoe MDL2 Assets glyphs (on every Windows 10/11). Free/VIP as the user set them (2026-10-17)."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Tool:
    id: str
    title: str
    subtitle: str
    icon: str
    color: str
    status: str = "ready"
    vip: bool = False
    vip_plus: bool = False

    @property
    def tier_label(self) -> str:
        return "VIP+" if self.vip_plus else "VIP" if self.vip else "Free"

    def allowed(self, session) -> bool:
        if self.vip_plus:
            return session is not None and session.is_vip_plus is True
        return not self.vip or (session is not None and session.is_vip is True)


TOOLS: list[Tool] = [
    Tool("recap", "Recap", "ဘယ်ဘာသာ video မဆို → မြန်မာ narration  (VIP: YouTube / TikTok channel အလိုလို)",
         "", "#5b8cff"),
    Tool("splitter", "Splitter", "ရှည်တဲ့ video ကို မိနစ်အလိုက် အပိုင်းခွဲ", "", "#22c3a6"),
    Tool("dubbing", "Dubbing", "မူရင်းအသံ → မြန်မာ / ဘာသာမျိုးစုံ အသံ", "", "#e2568c", vip=True),
    Tool("long_to_short", "Long to Short", "ရှည်တဲ့ video ထဲက အကောင်းဆုံး အပိုင်းတွေ → Short / Reel", "",
         "#4bc06e"),
    Tool("subtitle", "Subtitle", "Video → မြန်မာ စာတန်းထိုး", "", "#f2a93b", vip=True),
    Tool("storytelling", "Original → Recap", "ဇာတ်ကားအစစ် → ဇာတ်လမ်းပြော recap", "", "#9b6bff",
         vip=True),
    Tool("story_motion", "Story Motion", "Idea → ဇာတ်လမ်း → ပုံ + အသံ + ရွေ့တဲ့ effect → video", "", "#3fb4f0", vip=True),
    Tool("novel", "Novel", "မြန်မာဝတ္ထု ၄ ပိုင်း + cover ပုံ (Facebook post)", "", "#c58b5b"),
    Tool("movie_review", "Movie Review", "ဇာတ်ကား review post + thumbnail + Reel", "", "#ef5b5b", vip=True, vip_plus=True),
    Tool("football_news", "Football News", "ဘောလုံးသတင်း video", "", "#2fbf71", status="soon", vip=True, vip_plus=True),
    Tool("auto_posting", "Auto Posting", "Facebook Page အများကြီး / TikTok — တင်ချိန် သတ်မှတ်ပြီး အလိုလို တင်", "",
         "#ff7b54", vip=True, vip_plus=True),
]
