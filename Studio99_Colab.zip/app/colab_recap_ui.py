"""Colab web adapters for the native Recap editor's config, preview, script and job views."""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

from colab_runtime import DATA, JOBS, OUTPUTS, TMP, _validate_source, _within_colab, _read_config

ROOT = Path(__file__).resolve().parent.parent
RECAP_APP = ROOT / "recap_tool_src" / "app"
_VIDEO = {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v"}
_IMAGE = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}


def _safe_name(text: str) -> str:
    return re.sub(r"[^\w\-]+", "_", text, flags=re.UNICODE).strip("_")[:80] or "recap"


def job_dir(source: str | Path) -> Path:
    source = _validate_source(str(source))
    sig = hashlib.sha1(str(source.resolve()).encode("utf-8")).hexdigest()[:8]
    return JOBS / f"{_safe_name(source.stem)}_{sig}"


def load_editor(source: str) -> dict:
    source = _validate_source(source)
    folder = job_dir(source)
    candidates = [folder / "editor_overlays.json"]
    if not candidates[0].is_file() and JOBS.is_dir():
        candidates = sorted(JOBS.glob(f"{_safe_name(source.stem)}_*/editor_overlays.json"),
                            key=lambda p: p.stat().st_mtime if p.is_file() else 0, reverse=True)[:1]
    for path in candidates:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except (OSError, ValueError):
            pass
    return {}


def save_editor(source: str, settings: dict) -> dict:
    source = _validate_source(source)
    if not isinstance(settings, dict):
        raise ValueError("Editor settings មិនမှန်ပါ။")
    allowed = {"blur_boxes", "blur_strength", "title_text", "title_position", "title_font_size",
               "logo_enabled", "logo_path", "logo_position", "logo_width_fraction", "logo_opacity",
               "extra_text", "extra_text_position", "extra_text_font_size", "extra_text_opacity",
               "subtitles"}
    data = {key: settings[key] for key in allowed if key in settings}
    boxes = data.get("blur_boxes") or []
    if not isinstance(boxes, list) or len(boxes) > 30:
        raise ValueError("Blur box အများဆုံး 30 ခု ထည့်နိုင်ပါတယ်။")
    clean_boxes = []
    for box in boxes:
        if not isinstance(box, dict):
            continue
        vals = {k: max(0.0, min(1.0, float(box.get(k, 0)))) for k in ("x", "y", "w", "h")}
        vals["w"] = max(0.01, min(vals["w"], 1 - vals["x"]))
        vals["h"] = max(0.01, min(vals["h"], 1 - vals["y"]))
        clean_boxes.append(vals)
    data["blur_boxes"] = clean_boxes
    data["subtitles"] = settings.get("subtitles", data.get("subtitles")) or None
    for key, default in (("title_position", [.5, .12]), ("logo_position", [.8, .06]),
                         ("extra_text_position", [.5, .84])):
        value = data.get(key, default)
        data[key] = [max(0.0, min(1.0, float(value[0]))), max(0.0, min(1.0, float(value[1])))]
    data["blur_strength"] = max(4, min(40, int(data.get("blur_strength", 18))))
    data["title_font_size"] = max(12, min(144, int(data.get("title_font_size", 54))))
    data["extra_text_font_size"] = max(12, min(144, int(data.get("extra_text_font_size", 42))))
    data["logo_width_fraction"] = max(.05, min(.8, float(data.get("logo_width_fraction", .16))))
    data["logo_opacity"] = max(.1, min(1., float(data.get("logo_opacity", .65))))
    data["extra_text_opacity"] = max(.1, min(1., float(data.get("extra_text_opacity", .65))))
    logo = str(data.get("logo_path") or "").strip()
    if data.get("logo_enabled"):
        if not logo:
            raise ValueError("Logo ပုံတစ်ပုံ ရွေးပါ။")
        path = Path(logo).expanduser().resolve()
        if not _within_colab(path) or path.suffix.lower() not in _IMAGE or not path.is_file():
            raise ValueError("Colab ထဲက image file ကိုပဲ Logo အဖြစ် သုံးပါ။")
        data["logo_path"] = str(path)
    else:
        data["logo_path"] = ""
    if isinstance(data.get("subtitles"), dict):
        sys_path = str(RECAP_APP)
        import sys
        if sys_path not in sys.path:
            sys.path.insert(0, sys_path)
        from subtitle_png import style as subtitle_style
        data["subtitles"] = subtitle_style(data["subtitles"])
    path = job_dir(source) / "editor_overlays.json"
    _atomic_json(path, data)
    return data


def save_config(values: dict) -> dict:
    if not isinstance(values, dict):
        raise ValueError("Recap settings မမှန်ပါ။")
    cfg = _read_config()
    allowed = {"source_language", "narrator_voice", "edge_tts_voice_mm", "edge_tts_rate",
               "edge_tts_pitch", "gemini_direction", "narration_style", "run_mode", "output_ratio", "frame_fill", "video_quality",
               "zoom_factor", "mirror_video", "voice_volume_percent", "short_pauses", "reuse_transcript_and_plan",
               "auto_blur_original_subtitles", "whisper_model_other", "final_output_folder", "subtitles",
               "logo_enabled", "logo_path", "logo_width_fraction", "logo_opacity", "title_text",
               "title_font_size", "extra_text", "extra_text_font_size", "extra_text_opacity",
               "overlay_blur_strength", "delete_work_after"}
    for key in allowed:
        if key in values:
            cfg[key] = values[key]
    cfg["gemini_env_path"] = ""  # Colab notebook owns runtime-only Gemini key storage.
    voice = str(cfg.get("narrator_voice") or cfg.get("edge_tts_voice_mm") or "gemini:Charon")
    cfg["narrator_voice"] = cfg["edge_tts_voice_mm"] = voice
    cfg["source_language"] = str(cfg.get("source_language") or "auto")
    cfg["output_ratio"] = str(cfg.get("output_ratio") or "Original")
    cfg["frame_fill"] = str(cfg.get("frame_fill") or "blur")
    cfg["video_quality"] = str(cfg.get("video_quality") or "1080").removesuffix("p")
    try:
        cfg["zoom_factor"] = max(1.0, min(1.25, float(cfg.get("zoom_factor", 1.05))))
        cfg["voice_volume_percent"] = max(50, min(300, int(cfg.get("voice_volume_percent", 100))))
    except (TypeError, ValueError):
        raise ValueError("Zoom / Voice volume တန်ဖိုး မမှန်ပါ။") from None
    folder = str(cfg.get("final_output_folder") or "").strip()
    if folder:
        dest = Path(folder).expanduser().resolve()
        if not _within_colab(dest):
            raise ValueError("Output folder ကို /content အောက်မှာ ရွေးပါ။")
        cfg["final_output_folder"] = str(dest)
    if isinstance(cfg.get("subtitles"), dict):
        import sys
        if str(RECAP_APP) not in sys.path:
            sys.path.insert(0, str(RECAP_APP))
        from subtitle_png import style as subtitle_style
        cfg["subtitles"] = subtitle_style(cfg["subtitles"])
    cfg["run_mode"] = str(cfg.get("run_mode") or "auto")
    narration_style = cfg.get("narration_style") or {}
    if isinstance(narration_style, dict):
        narration_style = dict(narration_style)
        narration_style["instructions"] = str(values.get("narration_style", {}).get("instructions", narration_style.get("instructions", "")))
        narration_style["sample"] = str(values.get("narration_style", {}).get("sample", narration_style.get("sample", "")))
        narration_style["preset"] = str(values.get("narration_style", {}).get("preset", narration_style.get("preset", "")))
        narration_style["mode"] = str(values.get("narration_style", {}).get("mode", narration_style.get("mode", "original")))
        cfg["narration_style"] = narration_style
    _atomic_json(ROOT / "recap_config.json", cfg)
    return {"ok": True, "defaults": _defaults()}


def _defaults() -> dict:
    cfg = _read_config()
    cfg["gemini_env_path"] = ""
    cfg["final_output_folder"] = cfg.get("final_output_folder") if str(cfg.get("final_output_folder") or "").startswith("/content/") else ""
    cfg["source_language"] = str(cfg.get("source_language") or "auto")
    cfg["narrator_voice"] = cfg.get("narrator_voice") or cfg.get("edge_tts_voice_mm") or "gemini:Charon"
    cfg["output_ratio"] = cfg.get("output_ratio") or "Original"
    cfg["frame_fill"] = cfg.get("frame_fill") or "blur"
    cfg["video_quality"] = str(cfg.get("video_quality") or "1080").removesuffix("p")
    cfg.setdefault("zoom_factor", 1.05)
    cfg.setdefault("voice_volume_percent", 100)
    cfg.setdefault("short_pauses", True)
    cfg.setdefault("reuse_transcript_and_plan", True)
    cfg.setdefault("auto_blur_original_subtitles", True)
    cfg.setdefault("gemini_direction", "storyteller")
    cfg.setdefault("edge_tts_rate", "+0%")
    cfg.setdefault("edge_tts_pitch", "+0Hz")
    cfg.setdefault("whisper_model_other", "medium")
    cfg.setdefault("subtitles", {"enabled": True})
    cfg.setdefault("narration_style", {"mode": "original"})
    return cfg


def options(engine) -> dict:
    base = engine.options()
    d = _defaults()
    d.update({"source_title": "", "gemini_env_path": "", "run_mode": d.get("run_mode", "auto"),
              "title_position": d.get("title_position", [.5, .12]), "logo_position": d.get("logo_position", [.8, .06]),
              "extra_text_position": d.get("extra_text_position", [.5, .84]),
              "logo_path": d.get("logo_path", ""), "logo_enabled": bool(d.get("logo_enabled", False)),
              "title_text": d.get("title_text", ""), "extra_text": d.get("extra_text", ""),
              "extra_text_opacity": d.get("extra_text_opacity", .65), "overlay_blur_strength": d.get("overlay_blur_strength", 18),
              "subtitles_style": d.get("subtitles") or {"enabled": True},
              "delete_work_after": bool(d.get("delete_work_after", True))})
    d["video_quality"] = str(d.get("video_quality", "1080")).removesuffix("p")
    base["defaults"] = d
    base["run_modes"] = {"auto": "Auto — start to finish", "review": "Script Review — review/edit before voice + video"}
    base["gemini"] = {"configured": bool(__import__("keys_file").gemini_keys()),
                       "hint": "Gemini API key is set privately in the Colab notebook; it is not displayed in this page."}
    base["jobs_path"] = str(JOBS)
    try:
        __import__("sys").path.insert(0, str(RECAP_APP))
        from recap_planner import STYLE_PRESETS
        base["style_presets"] = {k: v[0] for k, v in STYLE_PRESETS.items()}
        from subtitle_fonts import myanmar_fonts
        base["subtitle_fonts"] = sorted(myanmar_fonts().keys()) or ["Noto Sans Myanmar"]
    except Exception:
        base["style_presets"] = {}
        base["subtitle_fonts"] = ["Noto Sans Myanmar"]
    try:
        from subtitle_png import DEFAULTS as subtitle_defaults
        base["subtitle_defaults"] = subtitle_defaults
    except Exception:
        base["subtitle_defaults"] = {"enabled": True, "font": "Noto Sans Myanmar", "size": 48, "bold": False,
                                      "color": "#FFFFFF", "outline_color": "#252525", "outline_width": -1,
                                      "shadow": 0, "box_enabled": True, "box_color": "#383838",
                                      "box_opacity": 62, "width": .86, "position": [.5, .92]}
    return base


def _atomic_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, raw = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(raw, path)
    finally:
        Path(raw).unlink(missing_ok=True)


def _stamp(value: Any) -> str:
    if isinstance(value, (int, float)):
        seconds = max(0, int(value))
        h, rem = divmod(seconds, 3600); m, s = divmod(rem, 60)
        return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"
    text = str(value or "").strip("[] ")
    if "-->" in text:
        text = text.split("-->", 1)[0].strip()
    return text


def script_status(source: str) -> dict:
    source = _validate_source(source)
    folder = job_dir(source)
    import sys
    if str(RECAP_APP) not in sys.path:
        sys.path.insert(0, str(RECAP_APP))
    from script_review import read_script
    partial, expected, done = read_script(folder)
    if not partial:
        return {"available": False, "job_dir": str(folder), "lines": [], "total": expected, "ready": False,
                "planner_state": "waiting"}
    if not (folder / "smart_sync_plan.json").is_file():
        lines = [{"id": int(x.get("id") or i + 1), "segment_id": None,
                  "source_index": None, "time": str(x.get("time") or ""),
                  "start": float(x.get("start") or 0), "end": float(x.get("end") or 0),
                  "source": str(x.get("source") or ""), "text": str(x.get("text") or ""),
                  "atomic_id": int(x.get("id") or i + 1)} for i, x in enumerate(partial)]
        return {"available": True, "job_dir": str(folder), "lines": lines, "total": expected,
                "ready": False, "planner_state": "translating"}
    plan_path = folder / "smart_sync_plan.json"
    try:
        preplan = json.loads(plan_path.read_text(encoding="utf-8"))
        preplan_segments = preplan.get("segments") or []
        plan_ready = bool(done)
        if not plan_ready:
            lines = [{"id": i + 1, "segment_id": None, "source_index": i,
                      "time": _stamp(row.get("start", row.get("timestamp", ""))),
                      "start": 0.0, "end": 0.0,
                      "source": str(row.get("source_text") or row.get("source") or ""),
                      "text": str(row.get("narration") or row.get("translation") or ""),
                      "atomic_id": row.get("atomic_id")}
                     for i, row in enumerate(preplan_segments)]
            return {"available": bool(lines), "job_dir": str(folder), "lines": lines,
                    "total": expected or len(lines), "ready": False, "planner_state": "finalizing"}
    except (OSError, ValueError):
        plan_ready = False
    import sys
    if str(RECAP_APP) not in sys.path:
        sys.path.insert(0, str(RECAP_APP))
    from core import normalize_segments
    try:
        plan = json.loads((folder / "smart_sync_plan.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ValueError(f"Recap plan ဖတ်မရပါ: {exc}") from None
    segments = normalize_segments(plan)
    lines = []
    for index, seg in enumerate(segments):
        row = plan["segments"][seg["source_index"]]
        lines.append({"id": index + 1, "segment_id": seg["segment_id"], "source_index": seg["source_index"],
                      "time": _stamp(row.get("start", row.get("timestamp", ""))),
                      "start": seg["video_start"], "end": seg["video_end"],
                      "source": str(row.get("source_text") or row.get("source") or ""),
                      "text": str(row.get("narration") or row.get("translation") or ""),
                      "atomic_id": row.get("atomic_id")})
    try:
        checkpoint = json.loads((folder / "planner_checkpoint.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        checkpoint = {}
    return {"available": True, "job_dir": str(folder), "lines": lines, "total": len(lines),
            "ready": bool(checkpoint.get("plan_ready")) or bool(done),
            "planner_state": checkpoint.get("phase", "ready")}


def save_script_line(source: str, segment_id: int, text: str) -> dict:
    source = _validate_source(source)
    text = str(text or "").strip()
    if not text:
        raise ValueError("စာသား အလွတ် မဖြစ်ရပါ။")
    if len(text) > 4000:
        raise ValueError("စာကြောင်း 4000 characters ထက်မပိုစေရပါ။")
    status = script_status(source)
    match = next((x for x in status["lines"] if x.get("segment_id") is not None and int(x["segment_id"]) == int(segment_id)), None)
    if not match:
        raise ValueError("ဒီ narration segment ကို ရှာမတွေ့ပါ။")
    folder = Path(status["job_dir"])
    path = folder / "smart_sync_plan.json"
    plan = json.loads(path.read_text(encoding="utf-8"))
    row = plan["segments"][int(match["source_index"])]
    row["narration"] = text
    row["translation"] = text
    _atomic_json(path, plan)
    translations = folder / "timestamp_translations.json"
    atomic_id = row.get("atomic_id")
    if translations.is_file() and atomic_id is not None:
        try:
            saved = json.loads(translations.read_text(encoding="utf-8"))
            for item in saved.get("items") or []:
                if int(item.get("id", -1)) == int(atomic_id):
                    item["translation"] = text
            _atomic_json(translations, saved)
        except (OSError, ValueError, TypeError):
            pass
    return {"ok": True, "segment_id": int(segment_id), "text": text}


def export_script(source: str, output_folder: str = "") -> list[dict]:
    status = script_status(source)
    if not status["lines"]:
        raise RuntimeError("Script မရှိသေးပါ။")
    folder = Path(status["job_dir"])
    title = _safe_name(Path(source).stem)
    plain = "\r\n".join(x["text"] for x in status["lines"]) + "\r\n"
    timed = "\r\n".join(f"[{x['time']}] {x['text']}\r\n    {x['source']}" for x in status["lines"]) + "\r\n"
    paths = [folder / f"script_{title}.txt", folder / f"script_{title}_timed.txt"]
    root = str(output_folder or "").strip()
    if root:
        dest = Path(root).expanduser().resolve()
        if not _within_colab(dest):
            raise ValueError("Script folder ကို /content အောက်မှာ ရွေးပါ။")
        dest = dest / "Scripts"
        paths += [dest / f"{title}_script.txt", dest / f"{title}_script_timed.txt"]
    for i, path in enumerate(paths):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(plain if i % 2 == 0 else timed, encoding="utf-8-sig")
    return [{"name": p.name, "path": str(p)} for p in paths]


def narration_style_preview(source: str, style: dict) -> list[dict]:
    source = _validate_source(source)
    folder = job_dir(source)
    keys = __import__("keys_file").gemini_keys()
    if not keys:
        raise RuntimeError("Gemini API key ကို Colab notebook မှာ тохируулна уу.")
    if str(RECAP_APP) not in __import__("sys").path:
        __import__("sys").path.insert(0, str(RECAP_APP))
    from recap_planner import preview_style
    keyfile = Path(__import__("keys_file").write())
    return preview_style(runtime_root=ROOT / "recap_tool_src" / "recap_runtime", gemini_env_path=str(keyfile),
                         job_dir=folder, style=dict(style or {}, mode="test"), log=lambda _m: None)


def list_jobs() -> list[dict]:
    import sys
    if str(ROOT / "app") not in sys.path:
        sys.path.insert(0, str(ROOT / "app"))
    import storage
    return [{**x, "path": str(x["path"]), "final_in_job": str(x["final_in_job"] or ""),
             "final_saved": str(x["final_saved"] or ""), "date": datetime.fromtimestamp(x["modified"]).strftime("%Y-%m-%d %H:%M")}
            for x in storage.list_jobs(JOBS)]


def delete_jobs(paths: list[str], running_job: str = "") -> dict:
    import sys
    if str(ROOT / "app") not in sys.path:
        sys.path.insert(0, str(ROOT / "app"))
    import storage
    if not isinstance(paths, list) or not paths or len(paths) > 100:
        raise ValueError("ဖျက်မယ့် Recap job တစ်ခုနှင့်အထက် ရွေးပါ။")
    allowed = {str((JOBS / p.name).resolve()): p for p in JOBS.iterdir() if p.is_dir()} if JOBS.is_dir() else {}
    selected = []
    for value in paths:
        path = Path(value).expanduser().resolve()
        if str(path) not in allowed or path.parent != JOBS.resolve():
            raise ValueError("Recap job folder မဟုတ်တဲ့ path ပါဝင်နေပါတယ်။")
        if running_job and path == Path(running_job).resolve():
            raise RuntimeError("လက်ရှိ လုပ်နေတဲ့ job ကို ဖျက်လို့မရပါ။")
        if path not in selected:
            selected.append(path)
    bytes_before = sum(storage.folder_size(p) for p in selected)
    for path in selected:
        storage.delete_job(JOBS, path)
        marker = storage.done_marker(path)
        marker.unlink(missing_ok=True)
    return {"jobs": len(selected), "bytes": bytes_before, "removed": [p.name for p in selected]}


def _fonts_and_the_rest():
    return None
