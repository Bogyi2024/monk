"""Auto Posting engine = the TT master's own code copied into ../engine (tools/sync_engine.py).

One background process (engine/tt_master_scheduler.py) runs the master's scheduler AND its dashboard on
127.0.0.1:8799; the dashboard is shown in a WebView2 window (engine_window.py). Posting follows the master's rules:
only while the process runs and Today is armed. The buyer's Gemini keys (Profile) are passed as environment
variables, never written into engine/.env."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import local_mode
import token_store

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "engine"
PORT = 8799
URL = f"http://127.0.0.1:{PORT}/"
HIDE_TABS = "search,astro"
LOG = ROOT / "logs" / "engine_process.log"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

_engine: subprocess.Popen | None = None
_window: subprocess.Popen | None = None
_window_parent = 0


def _python(windowless: bool) -> str:
    exe = Path(sys.executable)
    name = "pythonw.exe" if windowless else "python.exe"
    candidate = exe.with_name(name)
    return str(candidate if candidate.exists() else exe)


def engine_env() -> dict[str, str]:
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith("GEMINI_")}
    env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8", TT_WEB_PORT=str(PORT), TT_UI_PRODUCT="Studio99",
               TT_UI_HIDE_TABS=HIDE_TABS, TT_NO_BROWSER="1", STUDIO99_POSTING_ONLY="1",
               STUDIO99_POSTING_LIST=str(ENGINE / "state" / "studio99_posting_list.json"),
               STUDIO99_PARENT_PID=str(os.getpid()))         # the engine exits with this app (engine/studio99)
    keys = token_store.load_keys()
    for i, key in enumerate([k.strip() for k in keys.get("gemini") or [] if k.strip()], 1):
        env[f"GEMINI_IMAGE_PROJECT_{i}_KEY"] = key
    if (keys.get("fal") or "").strip():
        env["FAL_KEY"] = keys["fal"].strip()
    if local_mode.enabled():
        env["STUDIO99_LOCAL"] = "1"
    return env


def running() -> bool:
    try:
        with urllib.request.urlopen(URL + "health", timeout=1.5) as response:
            return response.status == 200
    except Exception:
        return False


def start() -> None:
    """Start the engine once (a second start while it runs does nothing)."""
    global _engine
    if (_engine is not None and _engine.poll() is None) or running():
        return
    LOG.parent.mkdir(parents=True, exist_ok=True)
    log = open(LOG, "ab")
    _engine = subprocess.Popen([_python(False), "-X", "utf8", "tt_master_scheduler.py"], cwd=str(ENGINE),
                               env=engine_env(), stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                               creationflags=NO_WINDOW)
    log.close()


def _today_state(path: str, data: bytes | None = None) -> dict:
    request = urllib.request.Request(URL + path, data=data, method="POST" if data is not None else "GET",
                                     headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.loads(response.read().decode("utf-8")).get("state") or {}


def armed() -> bool:
    """Will the engine post today? It only works on an "armed" day."""
    try:
        return bool(_today_state("api/today-control").get("armed"))
    except Exception:
        return False


def arm_today() -> bool:
    """▶ စမယ် = post today too: starting the process alone left the day unarmed and nothing was ever posted
    (2026-10-30, `armed: False`); the engine arms by itself only at midnight."""
    try:
        return bool(_today_state("api/today-arm", b"{}").get("armed"))
    except Exception:
        return False


def wait_ready(timeout: float = 60) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        if running():
            return True
        if _engine is not None and _engine.poll() is not None:
            return False                      # it stopped: see logs/engine_process.log
        time.sleep(0.5)
    return False


def last_log_lines(n: int = 12) -> str:
    try:
        return "\n".join(LOG.read_text(encoding="utf-8", errors="replace").splitlines()[-n:])
    except OSError:
        return ""


def open_window(parent: int = 0) -> None:
    """The dashboard: inside Studio99 (child of the frame whose window handle is `parent`) or its own window."""
    global _window, _window_parent
    if _window is not None and _window.poll() is None:
        if _window_parent == parent:
            return
        _window.terminate()                    # another frame now: open it there
    args = [_python(True), str(Path(__file__).with_name("engine_window.py")), URL]
    if parent:
        args += ["--parent", str(parent)]
    _window, _window_parent = subprocess.Popen(args, cwd=str(ROOT), creationflags=NO_WINDOW), parent


def close_window() -> None:
    global _window
    if _window is not None and _window.poll() is None:
        _window.terminate()
    _window = None


def window_open() -> bool:
    return _window is not None and _window.poll() is None


def stop() -> None:
    """Stop the window and the engine this app started (posting stops with it)."""
    for proc in (_window, _engine):
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()


def _read(name: str) -> dict:
    try:
        return json.loads((ENGINE / "config" / name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def destinations(category: str | None = None, enabled_only: bool = True) -> list[dict]:
    """The posting routes set up in the dashboard (Categories → Recap videos / Splitter parts / Other videos):
    each = one Facebook Page and/or TikTok account with its own daily count and times."""
    accounts = _read("tt_accounts.json")
    pages, tiktok = accounts.get("facebook_pages") or {}, accounts.get("tiktok_accounts") or {}
    out = []
    for cat_key, cat in ((_read("tt_categories.json").get("categories")) or {}).items():
        if not cat_key.startswith("post_") or (category and cat_key != category):
            continue
        for key, route in (cat.get("routes") or {}).items():
            if not isinstance(route, dict) or (enabled_only and not (route.get("enabled", True) and
                                                                   cat.get("enabled", True))):
                continue
            where = []
            if route.get("facebook_page"):
                page = pages.get(route["facebook_page"]) or {}
                where.append(f"📘 {page.get('label') or route['facebook_page']}")
            if route.get("tiktok_account"):
                acc = tiktok.get(route["tiktok_account"]) or {}
                where.append(f"🎵 {acc.get('label') or route['tiktok_account']}")
            out.append({"id": key, "category": cat_key, "label": route.get("label") or key,
                        "where": "  ".join(where) or "Page မချိတ်ရသေး", "daily": int(route.get("daily_limit") or 0),
                        "enabled": bool(route.get("enabled", True) and cat.get("enabled", True)
                                        and (route.get("facebook_page") or route.get("tiktok_account")))})
    return out
