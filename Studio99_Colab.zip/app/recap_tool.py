"""Studio99 Desktop Recap: the shared tool's Recap screen inside the app, in two modes (user, 2026-10-23):

✋ Manual — videos are added by hand (Browse / Folder), as in the shared tool. A VIP member is asked after each
           finished video whether it goes to Auto Posting (or uses "📮 Auto Posting ပို့မယ်" in the app).
🤖 Auto (VIP) — YouTube channels / TikTok accounts the user added are checked every N minutes; new videos are
           downloaded, recapped one by one and put on the Auto Posting list (the Recap card), which posts them at
           its routes' times. Every video is noted in the registry (channel_source.py, like the TT master's
           recap_source_registry.json) and the posts in the engine's ledger, so nothing is made or posted twice.

Switching to Manual while Auto is working queues a stop: the video being downloaded / recapped is finished first,
then Auto stops (videos already downloaded wait in the registry for the next Auto start). The mode and "Auto on" are
kept in recap_config.json, so Auto goes on after the app is opened again."""
from __future__ import annotations

import json
import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk

import channel_source
import keys_file
import posting_queue
import storage
import ui_thread

BG, SURFACE, SURFACE_2, FIELD, BORDER = "#0b0d12", "#141821", "#1b2030", "#0a0c10", "#2a3142"
FG, MUTED, ACCENT, GOLD, OK = "#eef1f7", "#98a2b3", "#5b8cff", "#f5c451", "#3ecf8e"
MODES = (("manual", "✋  Manual", False), ("auto", "🤖  Auto mode", True))
STATUS_WORDS = {"downloading": "ဒေါင်းနေ", "downloaded": "ဒေါင်းပြီး · စောင့်နေ", "recapping": "Recap လုပ်နေ",
                "done": "Recap ပြီး", "queued": "📮 Auto Posting ထဲ", "download_failed": "⚠️ ဒေါင်းမရ",
                "recap_failed": "⚠️ Recap မပြီး", "old": "အဟောင်း"}


class RecapToolView(tk.Frame):
    def __init__(self, master: tk.Misc, *, app, public_tool: Path, config_file: Path) -> None:
        super().__init__(master, bg=BG)
        self.app = app
        self.mode = "manual"
        self.pending: list[dict] = []          # downloaded channel videos waiting for Recap
        self.running_item: dict | None = None
        self.auto_running = False
        self.stop_requested = False            # Manual chosen while Auto works: stop after the current video
        self.interval = tk.StringVar(value="30")
        self.new_url = tk.StringVar()
        self.new_kind = tk.StringVar(value="Videos")
        self.status = tk.StringVar(value="")
        self.auto_state = tk.StringVar(value="")
        self._auto_job = None
        self._checking = False

        self.source_bar = tk.Frame(self, bg=SURFACE)
        self.source_bar.pack(fill="x")
        self.mode_buttons: dict[str, tk.Label] = {}
        tk.Label(self.source_bar, text="Mode", bg=SURFACE, fg=MUTED, font=("Segoe UI", 10)).pack(side="left", padx=(16, 8),
                                                                                              pady=8)
        for key, label, vip in MODES:
            b = tk.Label(self.source_bar, text=label + ("   VIP" if vip else ""), bg=SURFACE_2, fg=FG,
                         font=("Segoe UI Semibold", 10), padx=14, pady=6, cursor="hand2")
            b.pack(side="left", padx=4, pady=6)
            b.bind("<Button-1>", lambda _e, k=key: self._set_mode(k))
            self.mode_buttons[key] = b
        jobs = tk.Label(self.source_bar, text="🗂  Jobs / Storage", bg=SURFACE_2, fg=FG, font=("Segoe UI Semibold", 10),
                        padx=12, pady=6, cursor="hand2")
        jobs.pack(side="right", padx=(4, 12), pady=6)
        jobs.bind("<Button-1>", lambda _e: JobsDialog(self))
        self.delete_after = tk.BooleanVar(value=True)
        tk.Checkbutton(self.source_bar, text="ပြီးရင် work files ဖျက် (output folder ထဲက video ပဲချန်)",
                       variable=self.delete_after, command=self._delete_after_changed, bg=SURFACE, fg=FG,
                       selectcolor=FIELD, activebackground=SURFACE, activeforeground=FG,
                       font=("Myanmar Text", 9)).pack(side="right", padx=8)
        tk.Label(self.source_bar, textvariable=self.status, bg=SURFACE, fg=MUTED, font=("Myanmar Text", 9)).pack(
            side="right", padx=16)

        self.channel_panel = tk.Frame(self, bg=BG)
        self._build_channel_panel()

        import sys
        sys.path.insert(0, str(public_tool / "app"))
        import controller as recap_controller
        from controller import RecapView      # the shared tool's Recap screen
        self.config_file = config_file
        try:
            cfg = json.loads(config_file.read_text(encoding="utf-8"))
        except Exception:
            cfg = {}
        self.cfg = cfg
        self.rc = recap_controller
        self.delete_after.set(bool(cfg.get("delete_work_after", True)))
        self.interval.set(str(cfg.get("auto_interval_minutes") or 30))
        if cfg.get("work_folder"):              # where the job folders go (Jobs / Storage -> Work folder)
            recap_controller.JOBS_DIR = Path(cfg["work_folder"])
            recap_controller.JOBS_DIR.mkdir(parents=True, exist_ok=True)
        self.recap = RecapView(self, cfg=cfg, on_finished=self._finished, save=self._save_cfg)
        self.recap.pack(fill="both", expand=True)
        env = keys_file.write() or keys_file.KEYS_FILE
        self.recap.gemini_env.set(str(env))
        resume = cfg.get("recap_mode") == "auto" and cfg.get("auto_running") and self.app.session.is_vip
        self._set_mode("auto" if resume else "manual", quiet=True)
        if resume:
            self.after(3000, self._start_auto)
        self.after(5000, self._feed)

    # ------------------------------------------------------------------ modes
    def _save_cfg(self) -> None:
        self.config_file.write_text(json.dumps(self.cfg, ensure_ascii=False, indent=2), encoding="utf-8")

    def _remember(self, **values) -> None:
        self.cfg.update(values)
        self._save_cfg()

    def _busy(self) -> bool:
        """Auto has a video in hand: being checked/downloaded or being recapped."""
        return self._checking or self.running_item is not None

    def _set_mode(self, mode: str, quiet: bool = False) -> None:
        if mode == "auto" and not self.app.session.is_vip:
            from tkinter import messagebox
            messagebox.showinfo("VIP", "YouTube channel / TikTok account ကနေ အလိုလို recap လုပ်ပြီး တင်တာ (Auto mode) က "
                                       "VIP member တွေအတွက်ပါ။")
            return
        if mode == "manual" and self.auto_running:
            if self._busy():                    # finish the video in hand first
                self.stop_requested = True
                self._show_auto_state()
                self.status.set("Auto ရပ်ဖို့ queue ထဲ ထည့်ထားပါတယ် — လက်ရှိ video ပြီးမှ ရပ်ပြီး Manual ပြောင်းပါမယ်")
                self._log("⏸️ Auto stop queued: the current video is finished first, then Manual mode")
                return
            self._stop_auto()
        self.mode = mode
        if mode == "manual":
            self.recap.unattended = False             # a person starts the next video: DONE / ERROR boxes again
        for key, b in self.mode_buttons.items():
            b.configure(bg=ACCENT if key == mode else SURFACE_2, fg="#ffffff" if key == mode else FG)
        if mode == "manual":
            self.channel_panel.pack_forget()
            if not quiet:
                self.status.set("Manual — Source Video / Folder ကို ကိုယ်တိုင် ရွေးပြီး START")
        else:
            self.channel_panel.pack(fill="x", before=self.recap if hasattr(self, "recap") else None, padx=12, pady=(8, 0))
            self._refresh_channels()
            self._refresh_registry()
            self._show_auto_state()
        if hasattr(self, "cfg"):
            self._remember(recap_mode=mode)

    def _build_channel_panel(self) -> None:
        p = self.channel_panel
        row = tk.Frame(p, bg=BG)
        row.pack(fill="x")
        ttk.Label(row, text="Channel link").pack(side="left")
        ttk.Entry(row, textvariable=self.new_url, width=46).pack(side="left", padx=6)
        self.kind_combo = ttk.Combobox(row, textvariable=self.new_kind, values=("Videos", "Shorts"), width=8,
                                       state="readonly")
        self.kind_combo.pack(side="left")
        ttk.Button(row, text="+ Add", style="Compact.TButton", command=self._add_channel).pack(side="left", padx=6)
        ttk.Button(row, text="TikTok login", style="Compact.TButton", command=self._tiktok_login).pack(side="left")
        tk.Label(row, text="YouTube channel (သို့) TikTok account — video အသစ်ကို အရင်လုပ်ပြီး၊ အသစ်မရှိရင် မတင်ရသေးတဲ့ အဟောင်းကို လုပ်ပါမယ်",
                 bg=BG, fg=MUTED, font=("Myanmar Text", 9)).pack(side="left", padx=10)

        mid = tk.Frame(p, bg=BG)
        mid.pack(fill="x", pady=(6, 0))
        side = tk.Frame(mid, bg=BG)                 # packed first: never squeezed out in a narrow window
        side.pack(side="right", padx=(10, 0), anchor="n")
        ttk.Button(side, text="Remove", style="Compact.TButton", command=self._remove_channel).pack(fill="x")
        ttk.Button(side, text="Check now", style="Compact.TButton", command=self._check_now).pack(fill="x", pady=4)
        self.channels_view = ttk.Treeview(mid, columns=("platform", "kind", "checked"), height=4)
        self.channels_view.heading("#0", text="Channel / Account")
        for col, text, width in (("platform", "Platform", 80), ("kind", "Type", 64), ("checked", "Last check", 110)):
            self.channels_view.heading(col, text=text)
            self.channels_view.column(col, width=width, anchor="center", stretch=False)
        self.channels_view.column("#0", width=240, minwidth=160, stretch=True)
        self.channels_view.pack(side="left", fill="x", expand=True)
        self.registry_view = ttk.Treeview(mid, columns=("status", "at"), height=4)
        self.registry_view.heading("#0", text="Video (registry)")
        for col, text, width in (("status", "State", 130), ("at", "When", 90)):
            self.registry_view.heading(col, text=text)
            self.registry_view.column(col, width=width, anchor="center", stretch=False)
        self.registry_view.column("#0", width=220, minwidth=140, stretch=True)
        self.registry_view.pack(side="left", fill="x", expand=True, padx=(8, 0))

        bottom = tk.Frame(p, bg=BG)
        bottom.pack(fill="x", pady=(6, 2))
        ttk.Label(bottom, text="Video အသစ် စစ်မယ် — every").pack(side="left")
        ttk.Spinbox(bottom, from_=10, to=720, increment=10, width=5, textvariable=self.interval,
                    command=self._interval_changed).pack(side="left", padx=4)
        ttk.Label(bottom, text="min").pack(side="left")
        self.auto_button = ttk.Button(bottom, text="▶ Auto စမယ်", style="Accent.TButton", command=self._toggle_auto)
        self.auto_button.pack(side="left", padx=12)
        tk.Label(bottom, textvariable=self.auto_state, bg=BG, fg=GOLD, font=("Myanmar Text", 10)).pack(side="left")

    def _refresh_channels(self) -> None:
        view = self.channels_view
        view.delete(*view.get_children())
        for c in channel_source.load()["channels"]:
            view.insert("", "end", iid=f"{c['url']}|{c.get('kind')}", text=c["url"],
                        values=("YouTube" if c.get("platform") == "youtube" else "TikTok",
                                c.get("kind", "videos").title(), c.get("last_checked") or "—"))

    def _refresh_registry(self) -> None:
        view = self.registry_view
        view.delete(*view.get_children())
        posted = posting_queue.ledger()
        for e in channel_source.recent(30):
            state = STATUS_WORDS.get(e.get("status"), e.get("status", ""))
            routes = (posted.get(e.get("url", "")) or {}).get("routes") or {}
            if routes:
                state = f"✓ တင်ပြီး ({len(routes)})"
            view.insert("", "end", text=e.get("title") or e.get("url") or e["video_id"],
                        values=(state, str(e.get("status_at") or "")[5:]))

    def _show_auto_state(self) -> None:
        if self.stop_requested:
            text = "⏸️ ရပ်ဖို့ စောင့်နေ — လက်ရှိ video ပြီးမှ ရပ်မယ်"
        elif self.auto_running:
            text = "● Auto run နေပါတယ် — ပြီးတဲ့ video တွေ Auto Posting (Recap card) ထဲ ရောက်ပြီး အချိန်ကျရင် တင်ပါမယ်"
        else:
            text = "Auto ရပ်ထားပါတယ်"
        self.auto_state.set(text)
        self.auto_button.configure(text="■ Auto ရပ်မယ်" if self.auto_running else "▶ Auto စမယ်")

    def _interval_changed(self) -> None:
        try:
            self._remember(auto_interval_minutes=max(10, int(float(self.interval.get()))))
        except ValueError:
            pass

    def _thread(self, work, done=None) -> None:
        def run():
            try:
                result = work()
                if done:
                    ui_thread.post(lambda: done(result))
            except Exception as exc:  # noqa: BLE001
                ui_thread.post(lambda e=exc: self.status.set(f"⚠️ {str(e)[:120]}"))
        threading.Thread(target=run, daemon=True).start()

    def _add_channel(self) -> None:
        url = self.new_url.get().strip()
        plat = channel_source.platform(url)
        if plat not in ("youtube", "tiktok"):
            self.status.set("YouTube channel link (သို့) TikTok account link ထည့်ပါ")
            return
        self.status.set("Channel ကို စစ်နေပါတယ်…")
        kind = "shorts" if self.new_kind.get() == "Shorts" and plat == "youtube" else "videos"
        self._thread(lambda: channel_source.add_channel(url, kind, True, log=self._log),
                     lambda _c: (self.new_url.set(""), self.status.set("ထည့်ပြီးပါပြီ — video အသစ် ထွက်မှ recap လုပ်မယ်"),
                                 self._refresh_channels()))

    def _remove_channel(self) -> None:
        sel = self.channels_view.selection()
        if sel:
            url, kind = sel[0].rsplit("|", 1)
            channel_source.remove_channel(url, kind)
            self._refresh_channels()

    def _tiktok_login(self) -> None:
        self.status.set("ပွင့်လာတဲ့ browser မှာ TikTok ကို login ဝင်ပြီး window ကို ပိတ်ပါ")
        self._thread(channel_source.open_tiktok_login,
                     lambda _r: self.status.set("TikTok login ✓" if channel_source.tiktok_logged_in()
                                                else "TikTok login မဝင်ရသေးပါ"))

    def _log(self, text: str) -> None:
        self.recap._log(text)

    # ------------------------------------------------------------------ auto mode
    def _toggle_auto(self) -> None:
        if self.auto_running:
            if self._busy():
                self.stop_requested = True
                self._log("⏸️ Auto stop queued: the current video is finished first")
                self._show_auto_state()
            else:
                self._stop_auto()
        else:
            self._start_auto()

    def _start_auto(self) -> None:
        if not channel_source.load()["channels"]:
            self.status.set("Channel တစ်ခု အရင်ထည့်ပါ")
            return
        self.auto_running, self.stop_requested = True, False
        known = {x["id"] for x in self.pending} | ({self.running_item["id"]} if self.running_item else set())
        for item in channel_source.resumable():          # downloaded before the app was closed
            if item["id"] not in known:
                channel_source.mark(item["id"], "downloaded")
                self.pending.append(item)
        if self.pending:
            self._log(f"▶ Auto: {len(self.pending)} downloaded video(s) from before go first")
        self._remember(recap_mode="auto", auto_running=True)
        self._show_auto_state()
        self._check_now()

    def _stop_auto(self) -> None:
        """Auto off now (nothing in hand). Downloaded videos stay 'downloaded' for the next start."""
        self.auto_running, self.stop_requested = False, False
        if self._auto_job is not None:
            self.after_cancel(self._auto_job)
            self._auto_job = None
        self.pending.clear()
        self._remember(auto_running=False)
        self._log("⏹️ Auto stopped")
        self._show_auto_state()

    def _queued_stop_reached(self) -> None:
        """The video in hand is finished and a stop was queued: stop, and go to Manual if that was asked."""
        if not self.stop_requested or self._busy():
            return
        self._stop_auto()
        if self.mode == "auto":
            self._set_mode("manual")

    def _schedule_next(self) -> None:
        if self._auto_job is not None:
            self.after_cancel(self._auto_job)
            self._auto_job = None
        if self.auto_running and not self.stop_requested:
            try:
                minutes = max(10, int(float(self.interval.get())))
            except ValueError:
                minutes = 30
            self._auto_job = self.after(minutes * 60_000, self._check_now)

    def _check_now(self) -> None:
        if self._checking or self.stop_requested:
            return
        self._checking = True
        self.status.set("Video အသစ် ရှာနေပါတယ်…")

        def work():
            self._recheck_vip()
            if not self._vip_now():
                return []
            found = channel_source.check_new(log=self._log)
            for item in found:
                if self.stop_requested:                    # stop queued: leave the rest for the next start
                    break
                old = channel_source.load()["videos"].get(item["id"]) or {}
                channel_source.register_found(item)
                try:
                    path = old.get("path") if old.get("path") and Path(old["path"]).is_file() else None
                    item["path"] = str(path or channel_source.download(item["url"], log=self._log))
                    channel_source.mark(item["id"], "downloaded", path=item["path"])
                    self.pending.append(item)
                except Exception as exc:  # noqa: BLE001
                    channel_source.mark(item["id"], "download_failed", error=str(exc)[:200])
                    self._log(f"⚠️ Download failed: {item['url']} ({str(exc)[:120]})")
            return found

        def done(found):
            if not self._vip_now():
                self._vip_ended()
            self.status.set(f"Video အသစ် {len(found)} ခု" if found else "Video အသစ် မရှိသေးပါ")
            self._refresh_channels()
            self._refresh_registry()
            self._schedule_next()
            self._queued_stop_reached()

        def guarded():
            try:
                return work()
            finally:
                self._checking = False
        self._thread(guarded, done)

    def _vip_now(self) -> bool:
        """Auto mode is VIP. The clock decides an expiry here; _recheck_vip (off the UI thread) also sees an
        admin's change."""
        return not getattr(self, "_vip_lost", False) and self.app.session.is_vip

    def _recheck_vip(self) -> None:
        """Read the account again (membership_access, at most every 30 s); no answer keeps the last state."""
        try:
            from membership_access import current_session, desktop_context
            if desktop_context():
                self._vip_lost = not current_session().is_vip
        except RuntimeError as exc:
            from pb_client import ServerUnreachable
            if not isinstance(exc, ServerUnreachable):
                self._vip_lost = True
                self._log(f"VIP ပြန်စစ်မရပါ: {exc}")

    def _vip_ended(self) -> None:
        """VIP ended (2026-10-30, user: the job in hand finishes, then it stops): the video being recapped
        finishes, then Auto stops and Manual opens — the same queued stop as switching to Manual."""
        if self.stop_requested or not self.auto_running:
            return
        self.stop_requested = True
        self._log("⏹️ VIP သက်တမ်း ကုန်သွားလို့ Auto mode ကို ရပ်ပါမယ် — လက်ရှိ video ပြီးမှ ရပ်ပါမယ်")
        self.status.set("VIP သက်တမ်း ကုန်ပါပြီ — Auto ရပ်ဖို့ queue ထဲ ထည့်ထားပါတယ်")
        self._show_auto_state()
        if not self._busy():
            self._queued_stop_reached()

    def _feed(self) -> None:
        """Hand the next downloaded channel video to Recap when Recap is idle."""
        try:
            if self.auto_running and not self.stop_requested and not self._vip_now():
                self._vip_ended()
            idle = self.recap.worker is None or not self.recap.worker.is_alive()
            if (idle and self.running_item is None and self.pending and self.auto_running
                    and not self.stop_requested):
                item = self.pending.pop(0)
                self.running_item, self._idle_checks = item, 0
                channel_source.mark(item["id"], "recapping")
                self._log(f"▶ Channel video: {item.get('title') or item['url']}")
                self.recap._clear_batch()
                self.recap.output_ratio.set("Original")
                self.recap._load_source(item["path"])
                self.recap.force_auto = True          # channel videos always go all the way (no Script Review stop)
                self.recap.unattended = True          # and never wait for a click on a DONE / ERROR box
                self.recap._start()
                self._refresh_registry()
            elif idle and self.running_item is not None:
                # the job ended without a finished video (error / stop): two idle looks (10 s) to let the
                # "finished" message arrive first, then the next video goes on
                self._idle_checks = getattr(self, "_idle_checks", 0) + 1
                if self._idle_checks >= 2:
                    channel_source.mark(self.running_item["id"], "recap_failed")
                    self._log(f"⚠️ Recap did not finish: {self.running_item['url']}")
                    self.running_item = None
                    self._refresh_registry()
                    self._queued_stop_reached()
        finally:
            if self.winfo_exists():
                self.after(5000, self._feed)

    # ------------------------------------------------------------------ finished videos
    def _delete_after_changed(self) -> None:
        self.cfg["delete_work_after"] = bool(self.delete_after.get())
        self._save_cfg()

    def _free_job(self, final: str, source: str) -> None:
        """The finished video is safe in the output folder: delete the job's work files (and a channel download)."""
        if not self.delete_after.get():
            return
        job = self.rc._job_dir_for(Path(source))
        final_path = Path(final)
        if not final_path.is_file() or final_path.resolve().is_relative_to(job.resolve()):
            self._log("ℹ️ Work files မဖျက်ပါ — 'Save final to' folder ရွေးထားမှ (video ကို အပြင်ထုတ်ထားမှ) ဖျက်ပါမယ်")
            return
        jobs_dir = self.rc.JOBS_DIR

        def work():
            size = storage.folder_size(job)
            storage.mark_done(job, str(final_path), source)
            storage.delete_job(jobs_dir, job)
            storage.delete_download(channel_source.DOWNLOADS, source)
            return size
        self._thread(work, lambda size: self._log(f"🧹 Work files ဖျက်ပြီး {storage.human(size)} ပြန်ရပါပြီ ({job.name})"))

    @staticmethod
    def _same_video(item: dict, source: str) -> bool:
        """Recap reports its source after .resolve(), the registry keeps the download path as written (2026-10-30:
        they did not compare equal, the video stayed "recapping" and never went to Auto Posting by itself)."""
        import os
        a, b = str(item.get("path") or ""), str(source or "")
        if a and os.path.normcase(os.path.realpath(a)) == os.path.normcase(os.path.realpath(b)):
            return True
        vid = str(item.get("id") or "")
        return bool(vid) and f"[{vid}]" in Path(b).name

    def _finished(self, final: str, source: str) -> None:
        import history
        import post_caption
        history.add("recap", final, Path(source).stem)
        lines = post_caption.narration(self.rc._job_dir_for(Path(source)))    # before _free_job may delete the job
        self._free_job(final, source)
        item, self.running_item = self.running_item, None
        if item and self._same_video(item, source):
            channel_source.mark(item["id"], "done", final=str(final))
            if not self.app.session.is_vip_plus:
                self._log("✓ Recap သိမ်းပြီးပါပြီ။ Auto Posting ပို့ရန် VIP+ လိုအပ်ပါသည်။")
                self._refresh_registry()
                self._queued_stop_reached()
                return
            title = item.get("title") or Path(source).stem

            def write_caption() -> str:                   # Gemini: the master's title + caption + hashtags
                return post_caption.make(lines, title, keys_file.gemini_keys(), log=self._log)

            def send(caption: str) -> None:
                added = posting_queue.add(final, caption=caption,
                                          targets=list((item.get("channel") or {}).get("targets") or []),
                                          source=item.get("url", ""), origin="channel")
                if added:
                    channel_source.mark(item["id"], "queued")
                    self._log("📮 Auto Posting (Recap card) ထဲ ထည့်ပြီးပါပြီ — အချိန်ကျရင် တင်ပါမယ်")
                else:
                    self._log("ℹ️ ဒီ video က Auto Posting ထဲ ရှိပြီး / တင်ပြီးသားမို့ ထပ်မထည့်ပါ")
                self._refresh_registry()
                self._queued_stop_reached()
            self._log("✍️ Post caption (title + hashtags) ရေးနေပါတယ်…")
            self._thread(write_caption, send)
            return
        self._queued_stop_reached()
        if self.app.session.is_vip_plus and not posting_queue.contains(final):
            AskPostDialog(self, final, Path(source).stem)

    def shutdown(self) -> None:
        if self._auto_job is not None:
            self.after_cancel(self._auto_job)
        self.recap.close()


class JobsDialog(tk.Toplevel):
    """Every Recap job folder with its size: delete whole jobs to free the disk, choose the work folder."""

    def __init__(self, view: RecapToolView) -> None:
        super().__init__(view, bg=SURFACE)
        self.view = view
        self.title("Recap jobs / Storage")
        self.geometry("980x560")
        self.transient(view.winfo_toplevel())
        top = tk.Frame(self, bg=SURFACE)
        top.pack(fill="x", padx=16, pady=(14, 6))
        self.folder = tk.Label(top, text="", bg=SURFACE, fg=MUTED, font=("Segoe UI", 9), anchor="w")
        self.folder.pack(side="left", fill="x", expand=True)
        ttk.Button(top, text="Work folder ပြောင်း", style="Compact.TButton", command=self._change_folder).pack(side="right")
        self.tree = ttk.Treeview(self, columns=("size", "date", "state"), height=16, selectmode="extended")
        self.tree.heading("#0", text="Job")
        for col, text, width in (("size", "Size", 100), ("date", "Date", 140), ("state", "Final video", 300)):
            self.tree.heading(col, text=text)
            self.tree.column(col, width=width, anchor="center", stretch=False)
        self.tree.column("#0", width=420)
        self.tree.pack(fill="both", expand=True, padx=16)
        bottom = tk.Frame(self, bg=SURFACE)
        bottom.pack(fill="x", padx=16, pady=12)
        ttk.Button(bottom, text="🗑  ရွေးထားတာ ဖျက်မယ်", style="Danger.TButton", command=self._delete).pack(side="left")
        ttk.Button(bottom, text="Folder ဖွင့်", style="Compact.TButton", command=self._open).pack(side="left", padx=8)
        self.total = tk.Label(bottom, text="", bg=SURFACE, fg=FG, font=("Myanmar Text", 10))
        self.total.pack(side="right")
        self.jobs: dict[str, dict] = {}
        self._load()

    def _load(self) -> None:
        jobs_dir = self.view.rc.JOBS_DIR
        self.folder.configure(text=f"Work folder:  {jobs_dir}")
        self.total.configure(text="တွက်နေပါတယ်…")

        def done(jobs):
            if not self.winfo_exists():
                return
            from datetime import datetime
            self.tree.delete(*self.tree.get_children())
            self.jobs = {}
            for i, job in enumerate(jobs):
                iid = str(i)
                self.jobs[iid] = job
                if job["final_saved"]:
                    state = "✓ output folder ထဲမှာ"
                elif job["final_in_job"]:
                    state = "job ထဲမှာပဲ (ဖျက်ရင် video ပါပျက်)"
                else:
                    state = "မပြီးသေး / resume data"
                self.tree.insert("", "end", iid=iid, text=job["name"], values=(
                    storage.human(job["size"]), datetime.fromtimestamp(job["modified"]).strftime("%Y-%m-%d %H:%M"),
                    state))
            total = sum(j["size"] for j in jobs)
            self.total.configure(text=f"Job {len(jobs)} ခု · စုစုပေါင်း {storage.human(total)}")
        self.view._thread(lambda: storage.list_jobs(jobs_dir), done)

    def _selected(self) -> list[dict]:
        return [self.jobs[i] for i in self.tree.selection() if i in self.jobs]

    def _delete(self) -> None:
        from tkinter import messagebox
        jobs = self._selected()
        if not jobs:
            return
        running = self.view.recap.current_job
        busy = self.view.recap.worker is not None and self.view.recap.worker.is_alive()
        if busy and running is not None and any(Path(j["path"]) == Path(running) for j in jobs):
            messagebox.showwarning("Jobs", "Run နေတဲ့ job ကို ဖျက်လို့မရပါ — အရင် Stop လုပ်ပါ။", parent=self)
            return
        size = sum(j["size"] for j in jobs)
        lost = [j for j in jobs if j["final_in_job"] and not j["final_saved"]]
        text = f"Job {len(jobs)} ခု ({storage.human(size)}) ကို လုံးဝ ဖျက်မှာပါ။ ပြန်ယူလို့ မရပါ။"
        if lost:
            text += (f"\n\n⚠️ {len(lost)} ခုမှာ ပြီးသား video က job ထဲမှာပဲ ရှိပါတယ် (output folder ထဲ မရှိ) — "
                     "အဲ့ video တွေပါ ပျက်ပြီး Auto Posting list ထဲကလည်း ဖယ်ပါမယ်။")
        if not messagebox.askyesno("ဖျက်မလား?", text, icon="warning", parent=self):
            return
        jobs_dir = self.view.rc.JOBS_DIR

        def work():
            gone = {str(Path(j["final_in_job"])) for j in lost}
            for job in jobs:
                storage.delete_job(jobs_dir, Path(job["path"]))
            if gone:
                posting_queue.remove([], videos=gone)
            return size

        def done(freed):
            self.view._log(f"🧹 Job {len(jobs)} ခု ဖျက်ပြီး {storage.human(freed)} ပြန်ရပါပြီ")
            self._load()
        self.view._thread(work, done)

    def _open(self) -> None:
        import os
        jobs = self._selected()
        path = Path(jobs[0]["path"]) if jobs else self.view.rc.JOBS_DIR
        if path.exists():
            os.startfile(path)

    def _change_folder(self) -> None:
        from tkinter import filedialog
        folder = filedialog.askdirectory(title="Recap work files (jobs) ထားမယ့် folder — နေရာလွတ်များတဲ့ drive", parent=self)
        if not folder:
            return
        self.view.rc.JOBS_DIR = Path(folder)
        self.view.rc.JOBS_DIR.mkdir(parents=True, exist_ok=True)
        self.view.cfg["work_folder"] = folder
        self.view._save_cfg()
        self._load()


class AskPostDialog(tk.Toplevel):
    """After a video is made: put it on the Posting list for the routes of its tool (Auto Posting → Categories)."""

    def __init__(self, master: tk.Misc, video: str, title: str, origin: str = "recap") -> None:
        super().__init__(master, bg=SURFACE)
        self.title("Auto Posting")
        self.resizable(False, False)
        self.transient(master.winfo_toplevel())
        self.video, self.origin = video, origin
        self.caption = tk.StringVar(value=title)
        import engine_runner
        self.category = posting_queue.category_for_origin(origin)
        self.dest = [(d, tk.BooleanVar(value=True)) for d in engine_runner.destinations(self.category)]
        self.when = tk.StringVar(value="auto")
        self.at = tk.StringVar(value="")
        self.delete_after = tk.BooleanVar(value=False)
        pad = {"padx": 22}
        tk.Label(self, text="Auto Posting list ထဲ ထည့်မလား?", bg=SURFACE, fg=FG, font=("Myanmar Text", 14, "bold")).pack(
            anchor="w", pady=(18, 4), **pad)
        tk.Label(self, text=Path(video).name, bg=SURFACE, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", **pad)
        tk.Label(self, text="Caption", bg=SURFACE, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(12, 0), **pad)
        ttk.Entry(self, textvariable=self.caption, width=60, font=("Myanmar Text", 10)).pack(anchor="w", **pad)
        label = posting_queue.CATEGORIES[self.category][0]
        tk.Label(self, text=f"ဘယ် Page တွေကို တင်မလဲ  ({label})", bg=SURFACE, fg=MUTED, font=("Myanmar Text", 9)).pack(
            anchor="w", pady=(12, 0), **pad)
        row = tk.Frame(self, bg=SURFACE)
        row.pack(anchor="w", **pad)
        if not self.dest:
            tk.Label(row, text=f"တင်မယ့် Page မရှိသေးပါ — Auto Posting → {label} ကတ် → Page / အချိန် မှာ "
                     "Route (Page + အချိန်) ထည့်ပြီး ဖွင့်ပါ။ အခု list ထဲ ထည့်ထားရင် ဖွင့်ပြီးတာနဲ့ တင်ပါမယ်။",
                     bg=SURFACE, fg=GOLD, font=("Myanmar Text", 9), wraplength=520, justify="left").pack(anchor="w")
        for i, (d, var) in enumerate(self.dest):
            tk.Checkbutton(row, text=f"{d['label']}   {d['where']}  ·  {d['daily']}/ရက်", variable=var, bg=SURFACE, fg=FG,
                           selectcolor=FIELD, activebackground=SURFACE, activeforeground=FG,
                           font=("Myanmar Text", 10)).grid(row=i, column=0, sticky="w")
        when = tk.Frame(self, bg=SURFACE)
        when.pack(anchor="w", pady=(10, 0), **pad)
        tk.Radiobutton(when, text="Page ရဲ့ နောက်အချိန်မှာ", value="auto", variable=self.when, bg=SURFACE, fg=FG,
                       selectcolor=FIELD, activebackground=SURFACE, font=("Myanmar Text", 10)).pack(anchor="w")
        at_row = tk.Frame(when, bg=SURFACE)
        at_row.pack(anchor="w")
        tk.Radiobutton(at_row, text="ဒီအချိန်နောက်မှ", value="at", variable=self.when, bg=SURFACE, fg=FG,
                       selectcolor=FIELD, activebackground=SURFACE, font=("Myanmar Text", 10)).pack(side="left")
        ttk.Entry(at_row, textvariable=self.at, width=18).pack(side="left", padx=6)
        tk.Label(at_row, text="YYYY-MM-DD HH:MM", bg=SURFACE, fg=MUTED, font=("Segoe UI", 8)).pack(side="left")
        tk.Checkbutton(self, text="Page အားလုံး တင်ပြီးရင် ဒီ video ဖိုင်ကို ဖျက်မယ် (storage)", variable=self.delete_after,
                       bg=SURFACE, fg=FG, selectcolor=FIELD, activebackground=SURFACE, activeforeground=FG,
                       font=("Myanmar Text", 10)).pack(anchor="w", pady=(10, 0), **pad)
        self.msg = tk.Label(self, text="", bg=SURFACE, fg="#ff8a8a", font=("Myanmar Text", 9))
        self.msg.pack(anchor="w", **pad)
        buttons = tk.Frame(self, bg=SURFACE)
        buttons.pack(fill="x", pady=(8, 18), **pad)
        ttk.Button(buttons, text="ထည့်မယ်", style="Accent.TButton", command=self._add).pack(side="left")
        ttk.Button(buttons, text="မထည့်ဘူး", command=self.destroy).pack(side="left", padx=8)
        self.grab_set()

    def _add(self) -> None:
        if not self.master.app.session.is_vip_plus:
            self.msg.configure(text="Auto Posting ပို့ရန် VIP+ လိုအပ်ပါသည်။")
            return
        targets = [d["id"] for d, v in self.dest if v.get()]
        if self.dest and not targets:
            self.msg.configure(text="Page တစ်ခုခု ရွေးပါ")
            return
        at = self.at.get().strip() if self.when.get() == "at" else ""
        if self.when.get() == "at":
            from datetime import datetime
            try:
                datetime.strptime(at, "%Y-%m-%d %H:%M")
            except ValueError:
                self.msg.configure(text="အချိန်ကို 2026-10-18 20:30 ပုံစံနဲ့ ရေးပါ")
                return
        if len(targets) == len(self.dest):
            targets = []                       # every route of the tool, also ones added later
        if posting_queue.add(self.video, caption=self.caption.get(), targets=targets, post_at=at, origin=self.origin,
                             delete_after_post=self.delete_after.get()) is None:
            self.msg.configure(text="ဒီ video က Auto Posting ထဲ ရှိပြီး / တင်ပြီးသားပါ")
            return
        self.destroy()
