"""Loaded by Python at start-up in a copied tool's processes (PYTHONPATH set by ffmpeg_speed.child_env):
the Studio99 encode-speed hook (app/ffmpeg_speed.py). Never stops a tool from starting."""
try:
    import os
    import sys

    _app = os.environ.get("STUDIO99_APP_DIR")
    if _app and os.environ.get("STUDIO99_TOOL_ID"):
        if _app not in sys.path:
            sys.path.append(_app)
        import ffmpeg_speed
        ffmpeg_speed.install()
except Exception:  # noqa: BLE001
    pass
