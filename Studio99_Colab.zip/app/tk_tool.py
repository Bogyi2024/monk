"""Recap and Splitter in their own Tk window, started by the web app (webapp.py → open_tool):

    pythonw -X utf8 tk_tool.py recap [--source <video>]
    pythonw -X utf8 tk_tool.py splitter

They are the shared tool's Tk screens (recap_tool_src), so they keep Tk. The login comes from the web app as the
STUDIO99_TOKEN environment variable (never on the command line or on disk); VIP is checked again here with the
server."""
from __future__ import annotations

import os
import shutil
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox

import embed_hook  # noqa: F401  (keyboard focus while shown inside the Studio99 window)
import local_mode
import ui_thread
from main import LOGS, PUBLIC_TOOL, ROOT, apply_theme, load_config, save_config
from pb_client import PocketBase

TITLES = {"recap": "Studio99 — Recap", "splitter": "Studio99 — Splitter"}


def main() -> None:
    tool = sys.argv[1] if len(sys.argv) > 1 else "recap"
    source = sys.argv[sys.argv.index("--source") + 1] if "--source" in sys.argv else ""
    root = tk.Tk()
    root.title(TITLES.get(tool, "Studio99"))
    if os.environ.get("STUDIO99_EMBED"):
        root.geometry("1360x860+-32000+-32000")     # shown inside the Studio99 window (embed.py) — no flash first
    else:
        root.geometry("1360x860")
        root.minsize(980, 640)
        try:
            root.state("zoomed")
        except tk.TclError:
            pass
    apply_theme(root)
    ui_thread.install(root)
    cfg = load_config()
    if local_mode.enabled():
        session = local_mode.session()             # offline developer mode: no server check
    else:
        try:
            session = PocketBase(cfg.get("server") or "https://api.recapboxx.com").refresh(os.environ["STUDIO99_TOKEN"])
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Studio99", f"Login ပြန်စစ်လို့ မရပါ — Studio99 ကနေ ပြန်ဖွင့်ပါ။\n\n{exc}")
            return
    app = type("App", (), {})()
    app.session, app.cfg = session, cfg
    from membership_access import bind_session
    bind_session(lambda: app.session)
    membership_stop = threading.Event()

    def watch_membership():
        from membership_access import current_session
        from pb_client import ServerUnreachable
        while not membership_stop.wait(30):
            try:
                current_session()
            except ServerUnreachable:
                continue
            except RuntimeError:
                app.session.user = {**app.session.user, "is_vip": False}
    threading.Thread(target=watch_membership, daemon=True).start()

    if tool == "splitter":
        sys.path.insert(0, str(PUBLIC_TOOL / "app"))
        from splitter_tab import SplitterTab

        def tool_path(name: str) -> str:
            for candidate in (cfg.get(f"{name}_path"), PUBLIC_TOOL / "ffmpeg" / f"{name}.exe", shutil.which(name)):
                if candidate and Path(candidate).is_file():
                    return str(candidate)
            return name
        LOGS.mkdir(exist_ok=True)
        def parts_made(parts: list[Path]) -> None:    # for Home's count and "📮 Auto Posting ပို့မယ်"
            import history
            for part in parts:
                history.add("splitter", part, Path(part).stem)
        view = SplitterTab(root, cfg=cfg, save=lambda: save_config(cfg), tool=tool_path, logs_dir=LOGS,
                           on_done=parts_made)
    else:
        from recap_tool import RecapToolView
        view = RecapToolView(root, app=app, public_tool=PUBLIC_TOOL, config_file=ROOT / "recap_config.json")
        if source and Path(source).is_file():
            root.after(800, lambda: view.recap._load_source(source))
        inbox = Path(os.environ.get("APPDATA") or Path.home()) / "Studio99Desktop" / f"{tool}_inbox.txt"

        def check_inbox() -> None:            # a video the web app sends while this window is open (Movie Search)
            try:
                if inbox.is_file():
                    path = inbox.read_text(encoding="utf-8").strip()
                    inbox.unlink()
                    if path and Path(path).is_file():
                        view.recap._load_source(path)
            except OSError:
                pass
            root.after(1000, check_inbox)
        root.after(1500, check_inbox)
    view.pack(fill="both", expand=True)

    def close() -> None:
        membership_stop.set()
        if hasattr(view, "shutdown"):
            view.shutdown()
        root.destroy()
    root.protocol("WM_DELETE_WINDOW", close)
    root.mainloop()


if __name__ == "__main__":
    main()
