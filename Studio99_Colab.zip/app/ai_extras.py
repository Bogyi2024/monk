"""AI extras for the exe: torch + torchaudio, downloaded the first time a tool needs them (user, 2026-10-18: "check
whether they are on the PC and download them automatically" — the installer leaves them out, 4.3 GB).

Needed by Dubbing ("Keep background sounds": Hybrid Demucs) and Original→Recap (smooth motion: RIFE). Both load torch
in a CHILD process (python -m dubber.background / smooth_motion.py --serve), so once the files are here the next
video uses them without restarting the tool; until then the tools carry on without them, as before.

Layout beside Studio99.exe:  ai_extras/site/…  (unzipped wheels)  +  ai_extras/installed.json
The launcher appends ai_extras/site to sys.path (after the exe's own libraries, so those always win).
The wheels come from download.pytorch.org (CUDA 12.1 build when an NVIDIA GPU is found, else the CPU build) and
PyPI, each checked against its published sha256; a broken download resumes where it stopped."""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sys
import threading
import time
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable

TORCH = "2.5.1"
PYPI_WHEELS = [("sympy", "1.13.1"), ("mpmath", "1.3.0"), ("networkx", "3.6.1"), ("typing_extensions", "4.15.0")]
TOOLS = {"dubbing", "storytelling"}                 # the Home tools that use them
SIZE_GB = {"cu121": 2.6, "cpu": 0.25}               # download size (unzipped ≈ 1.7×)

BASE = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parents[1]
EXTRAS = BASE / "ai_extras"
SITE = EXTRAS / "site"
MARKER = EXTRAS / "installed.json"


class ExtrasError(RuntimeError):
    pass


def frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def installed() -> bool:
    if not frozen():
        return True                                  # the dev PC's Python has its own torch
    try:
        return json.loads(MARKER.read_text(encoding="utf-8")).get("torch") == TORCH and (SITE / "torch").is_dir()
    except (OSError, ValueError):
        return False


def has_nvidia() -> bool:
    try:
        import ctranslate2
        return ctranslate2.get_cuda_device_count() > 0
    except Exception:  # noqa: BLE001
        return bool(shutil.which("nvidia-smi")) or Path(os.environ.get("SystemRoot", r"C:\Windows"),
                                                         "System32", "nvidia-smi.exe").is_file()


def flavor() -> str:
    return "cu121" if has_nvidia() else "cpu"


# ------------------------------------------------------------------ network (proxy as the PC has it, then direct)
def _openers():
    yield urllib.request.build_opener()                                  # env / Windows proxy (v2rayN …)
    yield urllib.request.build_opener(urllib.request.ProxyHandler({}))   # direct


def _get(url: str) -> bytes:
    last = None
    for opener in _openers():
        try:
            with opener.open(urllib.request.Request(url, headers={"User-Agent": "Studio99"}), timeout=60) as resp:
                return resp.read()
        except OSError as exc:
            last = exc
    raise ExtrasError(f"{url}: {last}")


def wheel_list(flav: str) -> list[dict]:
    """[{name, url, sha256, size}] — the two torch wheels from PyTorch's index, the rest from PyPI."""
    out = []
    for name in ("torch", "torchaudio"):
        html = _get(f"https://download.pytorch.org/whl/{flav}/{name}/").decode("utf-8", "replace")
        file = f"{name}-{TORCH}%2B{flav}-cp312-cp312-win_amd64.whl"
        m = re.search(r'href="([^"]*' + re.escape(file) + r')#sha256=([0-9a-f]{64})"', html)
        if not m:
            raise ExtrasError(f"{file} not found on download.pytorch.org")
        url = m.group(1) if m.group(1).startswith("http") else "https://download.pytorch.org" + m.group(1)
        out.append({"name": name, "url": url, "sha256": m.group(2), "size": 0})
    for name, version in PYPI_WHEELS:
        info = json.loads(_get(f"https://pypi.org/pypi/{name}/{version}/json"))
        files = [u for u in info["urls"] if u["packagetype"] == "bdist_wheel" and u["filename"].endswith("-none-any.whl")]
        if not files:
            raise ExtrasError(f"{name} {version}: no wheel on PyPI")
        out.append({"name": name, "url": files[0]["url"], "sha256": files[0]["digests"]["sha256"],
                    "size": files[0]["size"]})
    return out


def _download(item: dict, folder: Path, report: Callable[[int, int], None], stop: Callable[[], bool]) -> Path:
    target = folder / item["url"].rsplit("/", 1)[-1].replace("%2B", "+")
    if target.is_file() and _sha256(target) == item["sha256"]:
        return target
    last = None
    for attempt in range(6):
        for opener in _openers():
            have = target.stat().st_size if target.exists() else 0
            req = urllib.request.Request(item["url"], headers={"User-Agent": "Studio99"})
            if have:
                req.add_header("Range", f"bytes={have}-")
            try:
                with opener.open(req, timeout=60) as resp:
                    if have and resp.status != 206:              # the server ignored Range: start again
                        have = 0
                    total = have + int(resp.headers.get("Content-Length") or 0)
                    with open(target, "ab" if have else "wb") as fh:
                        done = have
                        while True:
                            if stop():
                                raise ExtrasError("stopped")
                            chunk = resp.read(1 << 20)
                            if not chunk:
                                break
                            fh.write(chunk)
                            done += len(chunk)
                            report(done, total)
                if _sha256(target) == item["sha256"]:
                    return target
                target.unlink()                                   # damaged: whole file again
                last = ExtrasError(f"{target.name}: checksum did not match")
            except ExtrasError:
                raise
            except OSError as exc:
                last = exc
        time.sleep(min(30, 3 * (attempt + 1)))
    raise ExtrasError(f"{target.name}: {last}")


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 22), b""):
            h.update(block)
    return h.hexdigest()


def install(progress: Callable[[float, str], None], stop: Callable[[], bool] = lambda: False) -> None:
    """Download + unzip everything (progress(percent, message)); safe to call again after a failure."""
    flav = flavor()
    need = SIZE_GB[flav] * 2.8 * 1024 ** 3                         # wheels + unzipped copy
    EXTRAS.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(EXTRAS).free < need:
        raise ExtrasError(f"Disk နေရာ မလောက်ပါ — {need / 1024 ** 3:.1f} GB လိုပါတယ် ({EXTRAS.drive})")
    progress(0, "စာရင်း ယူနေပါတယ်…")
    items = wheel_list(flav)
    downloads = EXTRAS / "downloads"
    downloads.mkdir(exist_ok=True)
    weights = [SIZE_GB[flav] * 0.9 if i["name"] == "torch" else 0.02 for i in items]
    files = []
    for n, item in enumerate(items):
        before = sum(weights[:n]) / sum(weights) * 90

        def report(done, total, n=n, before=before, name=item["name"]):
            share = weights[n] / sum(weights) * 90
            progress(before + share * (done / total if total else 0),
                     f"{name} ဒေါင်းနေပါတယ် — {done / 1024 ** 2:,.0f}" + (f" / {total / 1024 ** 2:,.0f} MB" if total else " MB"))
        files.append(_download(item, downloads, report, stop))
    progress(91, "ဖြည်နေပါတယ်…")
    part = EXTRAS / "site.part"
    shutil.rmtree(part, ignore_errors=True)
    for path in files:
        with zipfile.ZipFile(path) as zf:
            zf.extractall(part)
    shutil.rmtree(SITE, ignore_errors=True)
    part.rename(SITE)
    MARKER.write_text(json.dumps({"torch": TORCH, "flavor": flav, "at": time.strftime("%Y-%m-%d %H:%M")}),
                      encoding="utf-8")
    shutil.rmtree(downloads, ignore_errors=True)
    if str(SITE) not in sys.path:
        sys.path.append(str(SITE))
    progress(100, "ပြီးပါပြီ")


class Installer:
    """One background install for the web app; state for the page and events while it runs."""

    def __init__(self, emit: Callable[..., None]):
        self._emit = emit
        self._lock = threading.Lock()
        self._stop = False
        self.state = {"running": False, "percent": 0.0, "message": "", "error": ""}

    def status(self) -> dict:
        flav = flavor() if frozen() else "cu121"
        return dict(self.state, installed=installed(), needed=frozen() and not installed(), flavor=flav,
                    gpu=flav == "cu121", size_gb=SIZE_GB[flav])

    def start(self) -> bool:
        with self._lock:
            if self.state["running"] or installed():
                return False
            self.state.update(running=True, percent=0.0, message="", error="")
            self._stop = False
        threading.Thread(target=self._run, daemon=True).start()
        return True

    def stop(self) -> None:
        self._stop = True

    def _run(self) -> None:
        last = [0.0]

        def progress(percent: float, message: str) -> None:
            self.state.update(percent=round(percent, 1), message=message)
            if time.time() - last[0] > 0.7 or percent >= 100:
                last[0] = time.time()
                self._emit("ai", **self.status())
        try:
            install(progress, lambda: self._stop)
        except Exception as exc:  # noqa: BLE001
            self.state["error"] = "ရပ်လိုက်ပါပြီ" if str(exc) == "stopped" else str(exc)
        self.state["running"] = False
        self._emit("ai", **self.status())


# ------------------------------------------------------------------ FFmpeg (in the installer; fetched again if missing)
FFMPEG_DIR = BASE / "recap_tool_src" / "ffmpeg"
FFMPEG_ZIP = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"


def ffmpeg_ok() -> bool:
    return (FFMPEG_DIR / "ffmpeg.exe").is_file() and (FFMPEG_DIR / "ffprobe.exe").is_file() or \
        bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


def ensure_ffmpeg(progress: Callable[[float, str], None] = lambda p, m: None) -> bool:
    """The exe ships FFmpeg; when it is gone (an antivirus took it, a damaged install) it is downloaded again."""
    if not frozen() or ffmpeg_ok():
        return False
    FFMPEG_DIR.mkdir(parents=True, exist_ok=True)
    want = _get(FFMPEG_ZIP + ".sha256").decode("ascii", "replace").split()[0].strip().lower()
    item = {"name": "ffmpeg", "url": FFMPEG_ZIP, "sha256": want}
    path = _download(item, FFMPEG_DIR, lambda d, t: progress(d / t * 100 if t else 0, "FFmpeg ဒေါင်းနေပါတယ်"),
                     lambda: False)
    with zipfile.ZipFile(path) as zf:
        for info in zf.infolist():
            name = info.filename.rsplit("/", 1)[-1]
            if name in ("ffmpeg.exe", "ffprobe.exe"):
                (FFMPEG_DIR / name).write_bytes(zf.read(info))
    path.unlink(missing_ok=True)
    if str(FFMPEG_DIR) not in os.environ.get("PATH", ""):
        os.environ["PATH"] = str(FFMPEG_DIR) + os.pathsep + os.environ.get("PATH", "")
    return True
