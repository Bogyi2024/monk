"""Extra Local GPU TTS engines for Studio99 (Colab & Kaggle T4 optimized):
1. F5-Myanmar-TTS (`f5mm:*`) ? freococo/F5-Myanmar-TTS v2 (674MB native FP16, 24kHz, Burmese + Voice Clone)
2. VoxCPM2-GGUF (`voxcpm2_gguf:*`) ? llama.cpp-omni (`voxcpm2-cli`) or `llama-server` HTTP (/v1/audio/speech),
   native CUDA FP16/Q8_0 on Tesla T4 with minimal CPU RAM (~1-2 GB, zero PyTorch OOM risk).
"""
from __future__ import annotations

import gc
import hashlib
import inspect
import json
import os
import shutil
import subprocess
import threading
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from typing import Any

import voxcpm2_local

F5MM_VOICES: tuple[str, ...] = (
    "f5mm:default",
    "f5mm:clone",
)

VOXCPM2_GGUF_PRESETS: dict[str, str] = {
    "voxcpm2_gguf:male_narrator": "A calm adult man with a warm, clear storytelling narrator voice and steady pace",
    "voxcpm2_gguf:female_narrator": "A gentle adult woman with a clear, expressive storytelling narrator voice and steady pace",
    "voxcpm2_gguf:male_dramatic": "A deep resonant male narrator with a dramatic cinematic movie recap tone",
    "voxcpm2_gguf:female_warm": "A warm young woman with a friendly conversational voice and natural intonation",
    "voxcpm2_gguf:clone": "",
    "voxcpm2_gguf:design": "",
    "voxcpm2_gguf:auto": "",
}

VOXCPM2_GGUF_VOICES: tuple[str, ...] = tuple(VOXCPM2_GGUF_PRESETS.keys())

_F5_MODEL = None
_F5_LOCK = threading.RLock()
_GGUF_LOCK = threading.RLock()
_GGUF_HELP_CACHE: dict[str, str] = {}


def is_f5mm(voice: str) -> bool:
    return str(voice or "").strip().lower().startswith("f5mm:")


def is_voxcpm2_gguf(voice: str) -> bool:
    return str(voice or "").strip().lower().startswith("voxcpm2_gguf:")


def _ensure_wav_24k_or_48k(ref_path: Path, work_dir: Path, sample_rate: int = 24000, ffmpeg: str = "ffmpeg") -> Path:
    ref_path = Path(ref_path).expanduser().resolve()
    if not ref_path.is_file():
        raise FileNotFoundError(f"Reference audio မတွေ့ပါ: {ref_path}")
    if ref_path.suffix.lower() == ".wav":
        return ref_path
    work_dir.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha1(f"{ref_path}|{ref_path.stat().st_mtime_ns}|{sample_rate}".encode("utf-8")).hexdigest()[:12]
    out_wav = work_dir / f"ref_{sample_rate}_{digest}.wav"
    if not out_wav.is_file():
        ff = shutil.which(ffmpeg) or ffmpeg
        subprocess.run(
            [ff, "-y", "-v", "error", "-i", str(ref_path), "-ac", "1", "-ar", str(sample_rate), "-c:a", "pcm_s16le", str(out_wav)],
            check=True,
        )
    return out_wav


# ---------------------------------------------------------------------------
# Engine 1: F5-Myanmar-TTS (freococo/F5-Myanmar-TTS v2, Native FP16 on T4)
# ---------------------------------------------------------------------------

def _load_f5mm(log=print):
    global _F5_MODEL
    with _F5_LOCK:
        if _F5_MODEL is not None:
            return _F5_MODEL
        try:
            from f5_myanmar_tts import MyanmarTTS
        except ImportError as exc:
            raise RuntimeError(
                "f5-myanmar-tts မတင်ရသေးပါ — setup cell မှာ `pip install f5-myanmar-tts` ကို run ပါ။"
            ) from exc
        log("⚡ Loading F5-Myanmar-TTS v2 (FP16 · ~674 MB, native T4 Tensor Core)...")
        _F5_MODEL = MyanmarTTS()
        log("✅ F5-Myanmar-TTS ready (24kHz FP16).")
        return _F5_MODEL


def unload_f5mm(log=print) -> None:
    global _F5_MODEL
    with _F5_LOCK:
        had = _F5_MODEL is not None
        _F5_MODEL = None
    gc.collect()
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
    except Exception:
        pass
    try:
        import ctypes
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass
    if had and log:
        log("🧹 F5-Myanmar-TTS unloaded from RAM/VRAM before video render.")


def _save_audio_result(res: Any, output_wav: Path, default_sr: int = 24000) -> Path:
    import numpy as np
    import soundfile as sf

    if isinstance(res, (str, Path)) and Path(res).is_file():
        src = Path(res).resolve()
        if src != output_wav.resolve():
            shutil.copy2(src, output_wav)
        return output_wav

    sr = default_sr
    audio = res
    if isinstance(res, tuple) and len(res) >= 2:
        a, b = res[0], res[1]
        if isinstance(a, (int, float)) and not isinstance(b, (int, float)):
            sr, audio = int(a), b
        elif isinstance(b, (int, float)) and not isinstance(a, (int, float)):
            audio, sr = a, int(b)
    elif isinstance(res, dict):
        audio = res.get("audio") if "audio" in res else res.get("wav")
        sr = int(res.get("sample_rate") or res.get("sr") or default_sr)

    if output_wav.is_file() and output_wav.stat().st_size > 100 and audio is None:
        return output_wav

    if hasattr(audio, "detach"):
        audio = audio.detach().float().cpu().numpy()
    arr = np.asarray(audio, dtype=np.float32)
    if arr.ndim > 1:
        arr = arr.squeeze()
    part = output_wav.with_name(f".{output_wav.stem}_{uuid.uuid4().hex[:6]}.wav")
    sf.write(str(part), arr, int(sr))
    part.replace(output_wav)
    return output_wav


def synthesize_f5mm(
    text: str,
    voice: str,
    output_wav: Path,
    *,
    ref_audio: str = "",
    prompt_text: str = "",
    steps: int = 0,
    ffmpeg: str = "ffmpeg",
    work_dir: Path | None = None,
    log=print,
) -> Path:
    clean_text = " ".join(str(text or "").split()).strip()
    if not clean_text:
        raise ValueError("F5-Myanmar-TTS text ဗလာဖြစ်နေပါတယ်။")

    output_wav = Path(output_wav)
    output_wav.parent.mkdir(parents=True, exist_ok=True)
    cache_dir = Path(work_dir) if work_dir else output_wav.parent

    voice_key = str(voice or "f5mm:default").strip().lower()
    ref_clean = str(ref_audio or "").strip()
    prompt_clean = str(prompt_text or "").strip()
    ref_wav = ""
    if voice_key == "f5mm:clone":
        if not ref_clean:
            raise ValueError("F5-Myanmar-TTS Voice Clone အတွက် Reference Audio (3-10s WAV/MP3) ကို အရင် upload လုပ်ပါ။")
        ref_wav = str(_ensure_wav_24k_or_48k(Path(ref_clean), cache_dir, sample_rate=24000, ffmpeg=ffmpeg))
    elif ref_clean and Path(ref_clean).is_file():
        ref_wav = str(_ensure_wav_24k_or_48k(Path(ref_clean), cache_dir, sample_rate=24000, ffmpeg=ffmpeg))

    model = _load_f5mm(log=log)
    with _F5_LOCK:
        fn = None
        for meth in ("generate", "synthesize", "infer", "tts", "speak", "__call__"):
            cand = getattr(model, meth, None)
            if callable(cand):
                fn = cand
                break
        if fn is None:
            raise RuntimeError("Unsupported f5_myanmar_tts.MyanmarTTS interface.")

        sig = inspect.signature(fn)
        params = sig.parameters
        has_var_kw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values())
        kwargs: dict[str, Any] = {}

        # Map output path parameter if accepted
        for out_k in ("output_path", "output_file", "out_path", "output", "save_path", "file_path"):
            if out_k in params:
                kwargs[out_k] = str(output_wav)
                break

        # Map reference audio & transcript parameters if cloning
        if ref_wav:
            for ref_k in ("ref_audio", "ref_file", "reference_audio", "ref_wav", "prompt_wav"):
                if ref_k in params or has_var_kw:
                    kwargs[ref_k] = ref_wav
                    break
            if prompt_clean:
                for txt_k in ("ref_text", "prompt_text", "reference_text"):
                    if txt_k in params or has_var_kw:
                        kwargs[txt_k] = prompt_clean
                        break

        # Map steps if explicitly provided
        if int(steps or 0) > 0:
            for st_k in ("nfe_step", "steps", "num_steps"):
                if st_k in params:
                    kwargs[st_k] = max(8, min(64, int(steps)))
                    break

        # Call with text kwarg or positional
        text_kw = next((k for k in ("text", "gen_text", "target_text") if k in params), None)
        if text_kw:
            kwargs[text_kw] = clean_text
            res = fn(**kwargs)
        else:
            res = fn(clean_text, **kwargs)

        return _save_audio_result(res, output_wav, default_sr=24000)


def fingerprint_f5mm(voice: str, *, ref_audio: str = "", prompt_text: str = "", steps: int = 0) -> str:
    ref_sig = ""
    if ref_audio:
        p = Path(ref_audio)
        ref_sig = f"{p.name}:{p.stat().st_size}:{p.stat().st_mtime_ns}" if p.is_file() else ref_audio
    raw = f"f5-myanmar-tts-v2|{voice}|{ref_sig}|{prompt_text.strip()}|{int(steps or 0)}"
    return f"{voice}|f5mm|" + hashlib.sha256(raw.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Engine 2: VoxCPM2-GGUF (llama.cpp-omni voxcpm2-cli OR llama-server HTTP)
# ---------------------------------------------------------------------------

def _search_gguf_assets() -> tuple[str, str, str]:
    """Locate (voxcpm2_cli_bin, base_gguf, acoustic_gguf) from env vars or standard Colab/Kaggle/Drive dirs."""
    cli = os.environ.get("STUDIO99_VOXCPM2_GGUF_CLI", "").strip()
    base = os.environ.get("STUDIO99_VOXCPM2_GGUF_BASE", "").strip()
    acoustic = os.environ.get("STUDIO99_VOXCPM2_GGUF_ACOUSTIC", "").strip()

    data_root = Path(os.environ.get("STUDIO99_COLAB_DATA", "/content/Studio99Data"))
    search_dirs = [
        data_root / "models" / "voxcpm2_gguf",
        Path("/content/Studio99Data/models/voxcpm2_gguf"),
        Path("/kaggle/temp/Studio99Data/models/voxcpm2_gguf"),
        Path("/content/llama.cpp-omni/build/bin"),
        Path("/kaggle/working/llama.cpp-omni/build/bin"),
        Path("/kaggle/temp/voxcpm2_gguf"),
        Path("/content/voxcpm2_gguf"),
        Path("/content/drive/MyDrive/Studio99Models/voxcpm2_gguf"),
    ]

    if not cli:
        found = shutil.which("voxcpm2-cli")
        if found:
            cli = found
        else:
            for d in search_dirs:
                cand = d / "voxcpm2-cli"
                if cand.is_file():
                    cli = str(cand)
                    break

    if not base or not acoustic:
        for d in search_dirs:
            if not d.is_dir():
                continue
            for f in sorted(d.glob("*.gguf")):
                low = f.name.lower()
                if not base and ("baselm" in low or "base" in low):
                    base = str(f)
                elif not acoustic and ("acoustic" in low or "vae" in low):
                    acoustic = str(f)
            if base and acoustic:
                break

    return cli, base, acoustic


def _gguf_subprocess_env(cli_bin: str = "") -> dict[str, str]:
    """Build subprocess env with CUDA 13 / NCCL library paths for precompiled sm_75 voxcpm2-cli."""
    env = os.environ.copy()
    if os.name == "nt":
        return env

    extra_libs: list[str] = []
    cand_roots: list[Path] = []
    if cli_bin:
        cand_roots.append(Path(cli_bin).resolve().parent / "cu13_libs")
    data_root = Path(os.environ.get("STUDIO99_COLAB_DATA", "/content/Studio99Data"))
    cand_roots.append(data_root / "models" / "voxcpm2_gguf" / "cu13_libs")

    for root in cand_roots:
        nv_dir = root / "nvidia"
        if nv_dir.is_dir():
            for lib_dir in sorted(nv_dir.glob("*/lib")):
                if lib_dir.is_dir():
                    extra_libs.append(str(lib_dir))

    for sys_lib in ("/usr/local/cuda-13.0/lib64", "/usr/local/cuda-13/lib64", "/usr/local/cuda/lib64"):
        if os.path.isdir(sys_lib):
            extra_libs.append(sys_lib)

    for mod_name in ("nvidia.cuda_runtime", "nvidia.cublas", "nvidia.nccl"):
        try:
            mod = __import__(mod_name, fromlist=["__path__"])
            for p in getattr(mod, "__path__", []):
                lib_dir = os.path.join(p, "lib")
                if os.path.isdir(lib_dir):
                    extra_libs.append(lib_dir)
        except Exception:
            pass

    existing = [p for p in env.get("LD_LIBRARY_PATH", "").split(":") if p]
    merged: list[str] = []
    for p in extra_libs + existing:
        if p and p not in merged:
            merged.append(p)
    if merged:
        env["LD_LIBRARY_PATH"] = ":".join(merged)
    return env


def gguf_status() -> dict[str, Any]:
    """Return current VoxCPM2-GGUF availability and resolved paths for Colab diagnostics."""
    http_url = os.environ.get("STUDIO99_VOXCPM2_GGUF_URL", "").strip()
    cli, base, acoustic = _search_gguf_assets()
    if http_url:
        return {
            "ready": True,
            "mode": "http",
            "url": http_url,
            "cli": cli,
            "base": base,
            "acoustic": acoustic,
            "missing": [],
        }
    missing = []
    if not cli or not Path(cli).is_file():
        missing.append("voxcpm2-cli")
    if not base or not Path(base).is_file():
        missing.append("VoxCPM2-BaseLM-*.gguf")
    if not acoustic or not Path(acoustic).is_file():
        missing.append("VoxCPM2-Acoustic-F16.gguf")
    return {
        "ready": not missing,
        "mode": "cli" if not missing else "missing",
        "url": "",
        "cli": cli,
        "base": base,
        "acoustic": acoustic,
        "missing": missing,
    }


def _cli_help_text(cli_bin: str) -> str:
    if cli_bin in _GGUF_HELP_CACHE:
        return _GGUF_HELP_CACHE[cli_bin]
    try:
        out = subprocess.run(
            [cli_bin, "--help"],
            capture_output=True,
            text=True,
            timeout=10,
            env=_gguf_subprocess_env(cli_bin),
        )
        txt = (out.stdout or "") + "\n" + (out.stderr or "")
    except Exception:
        txt = ""
    _GGUF_HELP_CACHE[cli_bin] = txt
    return txt


def synthesize_voxcpm2_gguf(
    text: str,
    voice: str,
    output_wav: Path,
    *,
    ref_audio: str = "",
    prompt_text: str = "",
    design: str = "",
    steps: int = 0,
    cfg_value: float = 2.0,
    ffmpeg: str = "ffmpeg",
    work_dir: Path | None = None,
    log=print,
) -> Path:
    clean_text = " ".join(str(text or "").split()).strip()
    if not clean_text:
        raise ValueError("VoxCPM2-GGUF text ဗလာဖြစ်နေပါတယ်။")

    output_wav = Path(output_wav)
    output_wav.parent.mkdir(parents=True, exist_ok=True)
    cache_dir = Path(work_dir) if work_dir else output_wav.parent

    voice_key = str(voice or "voxcpm2_gguf:female_narrator").strip().lower()
    preset_desc = VOXCPM2_GGUF_PRESETS.get(voice_key, "")
    style_desc = str(design or "").strip() or preset_desc
    synth_text = f"({style_desc}){clean_text}" if style_desc else clean_text

    ref_clean = str(ref_audio or "").strip()
    prompt_clean = str(prompt_text or "").strip()
    ref_wav = ""
    if voice_key == "voxcpm2_gguf:clone":
        if not ref_clean:
            raise ValueError("VoxCPM2-GGUF Voice Clone အတွက် Reference Audio (3-10s WAV/MP3) ကို အရင် upload လုပ်ပါ။")
        ref_wav = str(_ensure_wav_24k_or_48k(Path(ref_clean), cache_dir, sample_rate=48000, ffmpeg=ffmpeg))
    elif ref_clean and Path(ref_clean).is_file():
        ref_wav = str(_ensure_wav_24k_or_48k(Path(ref_clean), cache_dir, sample_rate=48000, ffmpeg=ffmpeg))

    # Mode A: llama-server HTTP endpoint (e.g. `llama-server -hf ggml-org/VoxCPM2-GGUF --port 8084`)
    http_url = os.environ.get("STUDIO99_VOXCPM2_GGUF_URL", "").strip()
    if http_url:
        endpoint = http_url.rstrip("/")
        if not endpoint.endswith("/audio/speech"):
            endpoint = endpoint + ("/audio/speech" if endpoint.endswith("/v1") else "/v1/audio/speech")
        payload: dict[str, Any] = {
            "model": "voxcpm2-gguf",
            "input": synth_text,
            "voice": voice_key,
            "response_format": "wav",
        }
        if ref_wav:
            payload["reference_wav_path"] = ref_wav
        if prompt_clean:
            payload["prompt_text"] = prompt_clean
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(endpoint, data=data, headers={"Content-Type": "application/json"}, method="POST")
        part = output_wav.with_name(f".{output_wav.stem}_{uuid.uuid4().hex[:6]}.wav")
        try:
            with urllib.request.urlopen(req, timeout=180) as resp:
                part.write_bytes(resp.read())
        except urllib.error.URLError as exc:
            raise RuntimeError(f"VoxCPM2-GGUF server ({endpoint}) ချိတ်ဆက်မရပါ: {exc}") from exc
        part.replace(output_wav)
        return output_wav

    # Mode B: llama.cpp-omni `voxcpm2-cli` binary + GGUF weights (precompiled T4 sm_75)
    cli_bin, base_gguf, acoustic_gguf = _search_gguf_assets()
    if not cli_bin or not Path(cli_bin).is_file():
        raise RuntimeError(
            "VoxCPM2-GGUF (`voxcpm2-cli`) မတင်ရသေးပါ — Notebook ရဲ့ [Step 2B - Optional] VoxCPM2-GGUF Setup cell ကို အရင် run ပါ။"
        )
    if not base_gguf or not acoustic_gguf:
        raise RuntimeError(
            "VoxCPM2-GGUF model files (BaseLM + Acoustic .gguf) မတွေ့ပါ — [Step 2B - Optional] cell ကို run ပါ။"
        )

    if os.name != "nt" and not os.access(cli_bin, os.X_OK):
        try:
            os.chmod(cli_bin, 0o755)
        except OSError:
            pass

    part = output_wav.with_name(f".{output_wav.stem}_{uuid.uuid4().hex[:6]}.wav")
    help_txt = _cli_help_text(cli_bin)
    cmd = [cli_bin, "-t", synth_text, "-o", str(part)]

    # Voice cloning: `-r/--reference` for zero-shot cloning, plus `--prompt-wav`/`--prompt-text` for ultimate cloning.
    if ref_wav:
        if "--reference" in help_txt or "-r," in help_txt or not help_txt:
            cmd.extend(["-r", ref_wav])
            if prompt_clean and ("--prompt-wav" in help_txt or not help_txt):
                cmd.extend(["--prompt-wav", ref_wav, "--prompt-text", prompt_clean])
        else:
            cmd.extend(["--prompt-wav", ref_wav])
            if prompt_clean and "--prompt-text" in help_txt:
                cmd.extend(["--prompt-text", prompt_clean])

    # IMPORTANT: In voxcpm2-cli, `--timesteps` is CFM inference timesteps (default 10),
    # while `--steps` is max decode steps (default 200). Never pass 6/8/10 to `--steps`.
    eff_timesteps = max(4, min(40, int(steps or 0) or 8))
    if "--timesteps" in help_txt or not help_txt:
        cmd.extend(["--timesteps", str(eff_timesteps)])
    if "--cfg" in help_txt or not help_txt:
        cmd.extend(["--cfg", f"{float(cfg_value):.2f}"])

    # Pass GGUF model files (positional `<BaseLM.gguf> <Acoustic.gguf>` by default)
    if "--base-model" in help_txt and "--acoustic-model" in help_txt:
        cmd.extend(["--base-model", base_gguf, "--acoustic-model", acoustic_gguf])
    else:
        cmd.extend([base_gguf, acoustic_gguf])

    run_env = _gguf_subprocess_env(cli_bin)
    with _GGUF_LOCK:
        res = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=300,
            env=run_env,
        )
        if res.returncode != 0 or not part.is_file() or part.stat().st_size < 100:
            err_tail = ((res.stderr or "") + "\n" + (res.stdout or "")).strip()[-800:]
            raise RuntimeError(f"voxcpm2-cli failed (code {res.returncode}): {err_tail}")

    part.replace(output_wav)
    return output_wav


def fingerprint_voxcpm2_gguf(
    voice: str,
    *,
    ref_audio: str = "",
    prompt_text: str = "",
    design: str = "",
    steps: int = 0,
) -> str:
    eff_timesteps = max(4, min(40, int(steps or 0) or 8))
    ref_sig = ""
    if ref_audio:
        p = Path(ref_audio)
        ref_sig = f"{p.name}:{p.stat().st_size}:{p.stat().st_mtime_ns}" if p.is_file() else ref_audio
    raw = f"voxcpm2-gguf|{voice}|{ref_sig}|{prompt_text.strip()}|{design.strip()}|{eff_timesteps}"
    return f"{voice}|voxcpm2_gguf|" + hashlib.sha256(raw.encode("utf-8")).hexdigest()
