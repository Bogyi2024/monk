"""Headless Colab runner for Studio99 Original -> Recap (Storytelling) engine."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import uuid
from pathlib import Path
from typing import Any

APP = Path(__file__).resolve().parent
ROOT = APP.parent
TOOL = ROOT / "tool_apps" / "storytelling"
ENGINE = TOOL / "app" / "engine" / "manju_v62_engine.py"
DATA = Path(os.environ.get("STUDIO99_COLAB_DATA", "/content/Studio99Data")).resolve()
OUTPUTS = DATA / "storytelling_outputs"
WORK = DATA / "storytelling_work"
CONFIG_FILE = DATA / "storytelling_colab.json"
VIDEO_EXTS = {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v", ".ts"}

STORY_LENGTHS = [
    ["short", "Short — to the point"],
    ["short_steady", "Short — steady picture (<=1.25x)"],
    ["medium", "Medium — in between (<=1.4x)"],
    ["full", "Full story (as before)"],
    ["recap", "Recap — custom length (min or % of video)"],
]
TELLING_STYLES = [
    ["default", "Default"],
    ["light", "Light — like telling a friend"],
    ["calm", "Calm — clear explainer"],
    ["gripping", "Gripping — tense"],
    ["humor", "A little humor"],
]
LANGUAGES = [
    ["my", "Burmese (မြန်မာ)"],
    ["en", "English"],
    ["th", "Thai"],
    ["vi", "Vietnamese"],
    ["id", "Indonesian"],
]
VOICES = [
    ["my-MM-ThihaNeural", "Thiha (Myanmar Male)"],
    ["my-MM-NilarNeural", "Nilar (Myanmar Female)"],
    ["en-US-GuyNeural", "Guy (English Male)"],
    ["en-US-AriaNeural", "Aria (English Female)"],
]
DEFAULTS: dict[str, Any] = {
    "output_mode": "video",
    "language": "my",
    "story_length": "short_steady",
    "recap_minutes": 12,
    "recap_unit": "min",
    "telling_style": "default",
    "style_notes": "",
    "style_sample": "",
    "narration_style": "default",
    "tts_voice": "my-MM-ThihaNeural",
    "tts_rate_percent": 25,
    "gemini_models": "gemini-3-flash-preview,gemini-3.5-flash,gemini-3.5-flash-lite",
    "gemini_timeout_sec": 180,
    "whisper_check": True,
    "smooth_motion": False,
    "analysis_speed": 1,
    "share_registry": True,
    "output_dir": "",
}


def _within_colab(path: Path) -> bool:
    from colab_runtime import _within_colab as _ok
    return _ok(path)


def _validate_video(raw: str) -> Path:
    if not raw or len(raw) > 4096:
        raise ValueError("Video path ထည့်ပါ။")
    p = Path(raw).expanduser().resolve()
    if not _within_colab(p) or not p.is_file() or p.suffix.lower() not in VIDEO_EXTS:
        raise ValueError("/content အောက်က ဖတ်လို့ရတဲ့ video ဖိုင်ကို ရွေးပါ။")
    return p


def _load_saved() -> dict[str, Any]:
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {**DEFAULTS, **data}
    except (OSError, ValueError):
        pass
    return dict(DEFAULTS)


def _save_settings(s: dict[str, Any]) -> None:
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")


class ColabStorytellingJobs:
    def __init__(self, emit):
        self.emit = emit
        self.lock = threading.RLock()
        self.current: dict[str, Any] | None = None
        self.proc: subprocess.Popen | None = None
        self.stop_event = threading.Event()
        self.logs: list[str] = []

    def options(self) -> dict:
        OUTPUTS.mkdir(parents=True, exist_ok=True)
        recent = [
            {"name": p.name, "path": str(p)}
            for p in sorted(
                (p for p in OUTPUTS.rglob("*") if p.is_file() and p.suffix.lower() in {".mp4", ".txt"}),
                key=lambda x: x.stat().st_mtime, reverse=True,
            )[:30]
        ]
        return {
            "story_lengths": STORY_LENGTHS,
            "telling_styles": TELLING_STYLES,
            "languages": LANGUAGES,
            "voices": VOICES,
            "output_modes": [["video", "Video + Script"], ["script", "Script only (.txt)"]],
            "narration_styles": [["default", "Standard beat-by-beat"], ["flow", "Flowing storytelling"]],
            "defaults": _load_saved(),
            "recent_outputs": recent,
        }

    def status(self) -> dict:
        with self.lock:
            base = dict(self.current) if self.current else {
                "status": "idle", "progress": 0, "stage": "Ready", "job_id": "", "outputs": [], "error": "",
            }
            base["logs"] = self.logs[-250:]
            return base

    def start(self, request: dict) -> dict:
        if not isinstance(request, dict):
            raise ValueError("Storytelling settings မမှန်ပါ။")
        raw_sources = request.get("source_paths")
        if isinstance(raw_sources, list) and raw_sources:
            sources = [_validate_video(str(x)) for x in raw_sources[:50]]
        else:
            sources = [_validate_video(str(request.get("source_path") or ""))]
        merged = {**_load_saved(), **{k: request[k] for k in DEFAULTS if k in request}}
        _save_settings(merged)
        out_raw = str(merged.get("output_dir") or "").strip()
        out_dir = Path(out_raw).expanduser().resolve() if out_raw else OUTPUTS
        if out_raw and not _within_colab(out_dir):
            raise ValueError("Output folder ကို /content အောက်မှာသာ ထားပါ။")
        out_dir.mkdir(parents=True, exist_ok=True)

        with self.lock:
            if self.current and self.current.get("status") in {"starting", "running", "stopping"}:
                raise RuntimeError("Original → Recap job တစ်ခု လုပ်နေဆဲပါ။")
            jid = uuid.uuid4().hex
            self.stop_event.clear()
            self.logs = []
            self.current = {
                "job_id": jid, "status": "starting", "progress": 0, "stage": "Preparing Original → Recap",
                "sources": [s.name for s in sources], "output_dir": str(out_dir), "outputs": [], "error": "",
            }
            threading.Thread(target=self._run, args=(jid, sources, out_dir, merged), daemon=True).start()
            return {"job_id": jid, "status": "starting"}

    def stop(self) -> dict:
        self.stop_event.set()
        with self.lock:
            if self.current and self.current.get("status") in {"starting", "running"}:
                self.current.update(status="stopping", stage="Stopping Original → Recap")
            proc = self.proc
        if proc and proc.poll() is None:
            try:
                from web_tool_job import stop_process
                stop_process(proc)
            except Exception:
                try:
                    proc.terminate()
                except Exception:
                    pass
        return self.status()

    def _log(self, jid: str, line: str) -> None:
        text = str(line).rstrip()
        if not text:
            return
        with self.lock:
            if self.current and self.current.get("job_id") == jid:
                self.logs.append(text)
                self.logs = self.logs[-500:]
        self.emit("storytelling_log", job_id=jid, line=text)

    def _progress(self, jid: str, pct: int, stage: str) -> None:
        pct = max(0, min(100, int(pct)))
        with self.lock:
            if self.current and self.current.get("job_id") == jid:
                self.current.update(status="running", progress=pct, stage=stage)
        self.emit("storytelling_progress", job_id=jid, progress=pct, stage=stage)

    def _run(self, jid: str, sources: list[Path], out_dir: Path, s: dict[str, Any]) -> None:
        made: list[str] = []
        try:
            import keys_file
            env_file = keys_file.write()
            if not env_file or not keys_file.gemini_keys():
                raise RuntimeError("Profile မှာ Gemini API key အရင်ထည့်ပါ။")
            WORK.mkdir(parents=True, exist_ok=True)
            prev_memory: Path | None = None
            total = len(sources)
            for idx, src in enumerate(sources, 1):
                if self.stop_event.is_set():
                    raise InterruptedError("Stopped")
                work = WORK / f"{src.stem[:60]}_{jid[:6]}_{idx:02d}"
                work.mkdir(parents=True, exist_ok=True)
                self._progress(jid, int(((idx - 1) / total) * 100) + 2, f"Video {idx}/{total}: {src.name}")
                cmd = [
                    sys.executable, "-X", "utf8", "-u", str(ENGINE), str(src),
                    "--output-dir", str(work),
                    "--gemini-env-file", str(env_file),
                    "--proxy", "",
                    "--gemini-models", str(s.get("gemini_models") or DEFAULTS["gemini_models"]),
                    "--gemini-timeout-ms", str(int(s.get("gemini_timeout_sec", 180)) * 1000),
                    "--tts-voice", str(s.get("tts_voice") or "my-MM-ThihaNeural"),
                    "--tts-rate", f"{int(s.get('tts_rate_percent', 25)):+d}%",
                ]
                if s.get("share_registry", True):
                    cmd += ["--registry-path", str(out_dir / "CHARACTER_REGISTRY.json"), "--series-memory"]
                    if prev_memory and prev_memory.is_file():
                        cmd += ["--story-memory-in", str(prev_memory)]
                script_mode = s.get("output_mode") == "script"
                if script_mode:
                    cmd += ["--script-only"]
                lang = str(s.get("language") or "my")
                if lang != "my":
                    cmd += ["--narration-language", lang]
                if s.get("narration_style") == "flow":
                    cmd += ["--narration-style", "flow"]
                length = str(s.get("story_length") or "short_steady")
                if length in {"short", "short_steady", "medium", "recap"}:
                    cmd += ["--narration-length", length]
                    if length == "recap":
                        if s.get("recap_unit") == "percent":
                            cmd += ["--recap-percent", str(s.get("recap_minutes", 75))]
                        else:
                            cmd += ["--recap-minutes", str(s.get("recap_minutes", 12))]
                if s.get("whisper_check", True):
                    cmd += ["--whisper-check"]
                if s.get("smooth_motion", False) and not script_mode:
                    cmd += ["--smooth-motion"]
                if int(s.get("analysis_speed", 1) or 1) != 1:
                    cmd += ["--analysis-speed", str(int(s["analysis_speed"]))]
                preset = str(s.get("telling_style") or "default")
                notes = str(s.get("style_notes") or "").strip()
                sample = str(s.get("style_sample") or "").strip()
                if preset != "default" or notes or sample:
                    style_path = work / "TELLING_STYLE.json"
                    style_path.write_text(
                        json.dumps({"preset": preset, "notes": notes, "sample": sample}, ensure_ascii=False, indent=2),
                        encoding="utf-8",
                    )
                    cmd += ["--story-style-file", str(style_path)]

                env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", STUDIO99="1", STUDIO99_LOCAL="1")
                proc = subprocess.Popen(
                    cmd, cwd=str(work), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, encoding="utf-8", errors="replace", bufsize=1,
                )
                with self.lock:
                    self.proc = proc
                assert proc.stdout is not None
                for raw in proc.stdout:
                    line = raw.rstrip("\r\n")
                    self._log(jid, line)
                    m = re.search(r"(\d{1,3})\s*%", line)
                    if m:
                        local_pct = min(99, int(m.group(1)))
                        overall = int((((idx - 1) + local_pct / 100.0) / total) * 100)
                        self._progress(jid, overall, f"[{idx}/{total}] {line[:80]}")
                rc = proc.wait()
                with self.lock:
                    self.proc = None
                if self.stop_event.is_set():
                    raise InterruptedError("Stopped")
                if rc != 0:
                    raise RuntimeError(f"Original → Recap exited with code {rc} on {src.name}")

                mem_file = work / "STORY_MEMORY.json"
                if mem_file.is_file():
                    prev_memory = mem_file
                if script_mode:
                    script_file = work / "NARRATOR_SCRIPT.txt"
                    if script_file.is_file():
                        dest = out_dir / f"{src.stem[:80]}_script_{jid[:6]}.txt"
                        shutil.copy2(script_file, dest)
                        made.append(str(dest))
                else:
                    for cand in (work / "FINAL_STORYTELLING_THIHA_28.mp4", work / "engine_output_NO_EFFECTS.mp4"):
                        if cand.is_file():
                            dest = out_dir / f"{src.stem[:80]}_recap_{jid[:6]}.mp4"
                            shutil.copy2(cand, dest)
                            made.append(str(dest))
                            break
                with self.lock:
                    self.current.update(outputs=list(made))

            with self.lock:
                self.current.update(status="done", progress=100, stage="Completed", outputs=made, error="")
            self.emit("storytelling_done", job_id=jid, outputs=made)
        except InterruptedError:
            with self.lock:
                if self.current and self.current.get("job_id") == jid:
                    self.current.update(status="stopped", stage="Stopped", outputs=made)
            self.emit("storytelling_stopped", job_id=jid, outputs=made)
        except Exception as exc:
            self._log(jid, f"❌ {exc}")
            with self.lock:
                if self.current and self.current.get("job_id") == jid:
                    self.current.update(status="error", stage="Error", outputs=made, error=str(exc))
            self.emit("storytelling_error", job_id=jid, message=str(exc))
