"""Video quality for Studio99's own renders (Story Motion …), the same three steps as the Recap tool's core.py
(user, 2026-10-24: "low-end PCs take very long"). Measured on 4 CPU threads, 20 s of a real video, 9:16:
1080p medium crf18 52.5 s, 720p veryfast crf20 9.3 s, 480p superfast crf23 3.6 s."""
from __future__ import annotations

from typing import Any

SCALES = {"1080": 1.0, "720": 720 / 1080, "480": 480 / 1080}
LABELS = {"1080": "1080p — အကောင်းဆုံး", "720": "720p — မြန် (Reel / TikTok အတွက် လုံလောက်)",
          "480": "480p — အမြန်ဆုံး (စက်နိမ့်)"}
X264 = {"1080": ["-preset", "veryfast", "-crf", "20"], "720": ["-preset", "veryfast", "-crf", "21"],
        "480": ["-preset", "superfast", "-crf", "23"]}
NVENC = {"1080": ["-preset", "p5", "-cq", "20", "-b:v", "0"], "720": ["-preset", "p4", "-cq", "22", "-b:v", "0"],
         "480": ["-preset", "p3", "-cq", "24", "-b:v", "0"]}


def code(value: Any) -> str:
    text = str(value or "").strip().lower().removesuffix("p")
    return text if text in SCALES else "1080"


def scale(value: Any) -> float:
    return SCALES[code(value)]


def frame(width: int, height: int, value: Any) -> tuple[int, int]:
    """A 1080-quality frame size at the chosen quality (even numbers, as H.264 needs)."""
    k = scale(value)
    if k == 1.0:
        return width, height
    return max(2, round(width * k / 2) * 2), max(2, round(height * k / 2) * 2)


def encoder_args(nvenc: bool, value: Any) -> list[str]:
    q = code(value)
    return ["-c:v", "h264_nvenc", *NVENC[q]] if nvenc else ["-c:v", "libx264", *X264[q]]
