"""The same own-voice editor for Recap, Original→Recap, Movie Review and Story Motion."""
from __future__ import annotations

import argparse
import json
import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from own_voice import (Recorder, VoiceStore, cut, duration, ffmpeg_path, finish, join_samples,
                       microphone_devices, normalize, read_pcm, write_pcm)

BG, FG = "#11141b", "#e7eaf0"


def standalone_theme(root):
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure(".", background=BG, foreground=FG, font=("Myanmar Text", 10))
    style.configure("TButton", padding=(9, 5), background="#252d3b", foreground=FG)
    style.map("TButton", background=[("active", "#37445a")], foreground=[("disabled", "#707989")])
    style.configure("TCombobox", fieldbackground="#202735", foreground=FG, background="#252d3b")
    style.map("TCombobox", fieldbackground=[("readonly", "#202735")], foreground=[("readonly", FG)])
    style.configure("TSpinbox", fieldbackground="#202735", foreground=FG, background="#252d3b")


class ScriptBox:
    def __init__(self, parent):
        self.frame = tk.Frame(parent, bg="#0b0d12", height=60)
        self.frame.pack(fill="both", expand=True, pady=12)
        self.frame.pack_propagate(False)
        self.native, self.text = None, None
        try:
            from own_voice_native_text import NativeTextBox
            self.native = NativeTextBox(self.frame, font="Myanmar Text", size_pt=15, bg="#0b0d12", fg=FG)
            self.native.user32.SendMessageW(self.native.hwnd, 0x00CF, 1, 0)  # EM_SETREADONLY
        except (ImportError, OSError, AttributeError):
            self.text = tk.Text(self.frame, wrap="word", font=("Myanmar Text", 15), bg="#0b0d12", fg=FG,
                                padx=16, pady=12, relief="flat")
            self.text.pack(fill="both", expand=True)

    def set(self, value):
        if self.native:
            self.native.set(value)
        else:
            self.text.configure(state="normal")
            self.text.delete("1.0", "end")
            self.text.insert("1.0", value)
            self.text.configure(state="disabled")


class OwnVoiceEditor(tk.Toplevel):
    def __init__(self, master, work, rows, *, ffmpeg=None, title="ကိုယ်ပိုင်အသံ", on_complete=None):
        from membership_access import require_vip_audio
        require_vip_audio()
        super().__init__(master)
        if not rows:
            self.destroy()
            raise ValueError("Script မရှိသေးပါ")
        self.rows = [{"id": str(r["id"]), "text": str(r["text"])} for r in rows]
        if len({r["id"] for r in self.rows}) != len(self.rows):
            self.destroy()
            raise ValueError("Script part IDs must be unique")
        self.store, self.ffmpeg = VoiceStore(work), ffmpeg or ffmpeg_path()
        self.store.enable(True)
        self.index, self.busy, self.recorder = 0, False, None
        self.player, self.play_job = None, None
        self.events, self.drafts = queue.Queue(), {}
        self.complete, self.on_complete = False, on_complete
        self.samples, self.selection, self.anchor = [], None, None
        self.configure(bg=BG)
        self.title(title + " — Studio99")
        width = min(1080, max(880, self.winfo_screenwidth() - 80))
        height = min(780, max(620, self.winfo_screenheight() - 90))
        self.geometry(f"{width}x{height}")
        self.minsize(880, 620)
        if master.winfo_viewable():
            self.transient(master.winfo_toplevel())
        self.previous_grab = self.grab_current()
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.font = ("Myanmar Text", 11)
        box = ttk.Frame(self, padding=16)
        box.pack(fill="both", expand=True)
        self.info = tk.StringVar()
        ttk.Label(box, textvariable=self.info, font=("Segoe UI", 13, "bold")).pack(anchor="w")
        self.script = ScriptBox(box)
        mic = ttk.Frame(box)
        mic.pack(fill="x")
        ttk.Label(mic, text="Microphone").pack(side="left")
        self.device = tk.StringVar()
        self.pick = ttk.Combobox(mic, textvariable=self.device, state="readonly", width=65)
        self.pick.pack(side="left", padx=8, fill="x", expand=True)
        ttk.Button(mic, text="↻", command=self.devices).pack(side="left")
        actions = ttk.Frame(box)
        actions.pack(fill="x", pady=10)
        self.record_btn = ttk.Button(actions, text="● Record / ဆက်သွင်း", command=self.record)
        self.record_btn.pack(side="left")
        self.stop_btn = ttk.Button(actions, text="■ Stop", command=self.stop, state="disabled")
        self.stop_btn.pack(side="left", padx=8)
        ttk.Button(actions, text="အသံဖိုင်ထည့်", command=self.import_audio).pack(side="left")
        ttk.Button(actions, text="▶ မူရင်း", command=lambda: self.play(False)).pack(side="left", padx=8)
        ttk.Button(actions, text="▶ သန့်စင်ပြီး", command=lambda: self.play(True)).pack(side="left")
        ttk.Button(actions, text="■ နားထောင်တာရပ်", command=self.stop_playback).pack(side="left", padx=8)
        self.canvas = tk.Canvas(box, height=120, bg="#080b10", highlightthickness=1, highlightbackground="#303744")
        self.canvas.pack(fill="x")
        self.canvas.bind("<Configure>", lambda e: self.draw())
        self.canvas.bind("<Button-1>", self.select_start)
        self.canvas.bind("<B1-Motion>", self.select_end)
        edit = ttk.Frame(box)
        edit.pack(fill="x", pady=8)
        ttk.Label(edit, text="Waveform ပေါ်ဆွဲရွေးပြီး ဖြတ်နိုင်တယ်").pack(side="left")
        ttk.Button(edit, text="Cut", command=self.cut).pack(side="left", padx=8)
        ttk.Button(edit, text="Undo", command=self.undo).pack(side="left")
        ttk.Button(edit, text="Delete Part", command=self.delete).pack(side="left", padx=8)
        effects = ttk.Frame(box)
        effects.pack(fill="x", pady=6)
        self.noise, self.tone = tk.StringVar(value="medium"), tk.StringVar(value="natural")
        self.compact = tk.BooleanVar(value=True)
        self.gain, self.pitch = tk.DoubleVar(value=0), tk.DoubleVar(value=0)
        ttk.Label(effects, text="Noise removal").pack(side="left")
        self.noise_pick = ttk.Combobox(effects, state="readonly", textvariable=self.noise,
                                       values=["off", "light", "medium", "strong"], width=10)
        self.noise_pick.pack(side="left", padx=8)
        ttk.Checkbutton(effects, text="အကြာကြီးရပ်တဲ့နေရာ လျှော့မယ်", variable=self.compact,
                         command=self.invalidate).pack(side="left")
        ttk.Label(effects, text="Tone").pack(side="left", padx=(12, 4))
        tone_pick = ttk.Combobox(effects, state="readonly", textvariable=self.tone,
                                 values=["natural", "warm", "bright"], width=9)
        tone_pick.pack(side="left")
        self.noise_pick.bind("<<ComboboxSelected>>", lambda e: self.invalidate())
        tone_pick.bind("<<ComboboxSelected>>", lambda e: self.invalidate())
        knobs = ttk.Frame(box)
        knobs.pack(fill="x", pady=8)
        ttk.Label(knobs, text="Volume dB").pack(side="left")
        gain = ttk.Spinbox(knobs, from_=-12, to=12, textvariable=self.gain, width=6, command=self.invalidate)
        gain.pack(side="left", padx=8)
        ttk.Label(knobs, text="Pitch semitones").pack(side="left")
        pitch = ttk.Spinbox(knobs, from_=-4, to=4, increment=0.5, textvariable=self.pitch, width=6, command=self.invalidate)
        pitch.pack(side="left", padx=8)
        gain.bind("<KeyRelease>", lambda e: self.invalidate())
        pitch.bind("<KeyRelease>", lambda e: self.invalidate())
        self.status = tk.StringVar(value="CPU နဲ့ offline သန့်စင်မယ်။ Record နှိပ်မှ မိုက်အသံသွင်းမယ်။")
        ttk.Label(box, textvariable=self.status, wraplength=990).pack(fill="x", pady=6)
        footer = ttk.Frame(box)
        footer.pack(fill="x", pady=8)
        ttk.Button(footer, text="◀ အရင်", command=lambda: self.step(-1)).pack(side="left")
        ttk.Button(footer, text="Finish", command=self.finish).pack(side="left", padx=8)
        ttk.Button(footer, text="Send to Recap", command=self.send).pack(side="left")
        ttk.Button(footer, text="Next ▶", command=lambda: self.step(1)).pack(side="left", padx=8)
        ttk.Button(footer, text="AI အသံ ပြန်သုံးမယ်", command=self.use_ai).pack(side="right")
        ttk.Button(footer, text="✓ အားလုံးပို့ပြီး — ဆက်လုပ်မယ်", command=self.done).pack(side="right", padx=8)
        self.controls = []
        def collect(widget):
            for child in widget.winfo_children():
                if isinstance(child, (ttk.Button, ttk.Combobox, ttk.Spinbox, ttk.Checkbutton)):
                    self.controls.append(child)
                collect(child)
        collect(box)
        self.show()
        self.after(80, self.pump)
        self.devices()

    @property
    def row(self):
        return self.rows[self.index]

    @property
    def draft(self):
        return self.drafts.setdefault(self.row["id"], {"edit": None, "finished": None, "history": [],
                                                     "effects": {"noise":"medium", "compact":True, "gain":0, "pitch":0, "tone":"natural"}})

    def task(self, fn, done):
        if self.busy or self.recorder:
            return
        self.busy = True
        self.lock(True)
        def worker():
            try:
                self.events.put((done, fn(), None))
            except Exception as exc:
                self.events.put((None, None, str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def pump(self):
        while not self.events.empty():
            done, value, error = self.events.get_nowait()
            self.busy = False
            self.lock(False)
            if error:
                self.status.set("⚠️ " + error)
            elif done:
                done(value)
        self.after(80, self.pump)

    def lock(self, value):
        for control in self.controls:
            if control is not self.stop_btn:
                control.state(["disabled" if value else "!disabled"])
        self.stop_btn.state(["!disabled" if self.recorder is not None else "disabled"])

    def devices(self):
        def got(items):
            self.pick.configure(values=items)
            if items and self.device.get() not in items:
                self.device.set(items[0])
            if not items:
                self.status.set("Microphone မတွေ့ပါ။ မိုက်ချိတ်ပြီး ↻ နှိပ်ပါ သို့မဟုတ် အသံဖိုင်ထည့်ပါ။")
        self.task(lambda: microphone_devices(self.ffmpeg), got)

    def show(self):
        self.script.set(self.row["text"])
        if self.draft["edit"] is None:
            from own_voice import text_key, digest
            item = self.store.read().get("parts", {}).get(self.row["id"], {})
            path = self.store.root / str(item.get("file", ""))
            if item.get("text") == text_key(self.row["text"]) and path.is_file() and path.parent == self.store.root:
                self.draft.update(edit=path, finished=path)
                raw = self.store.root / str(item.get("source_file", ""))
                if raw.parent == self.store.root and raw.is_file() and digest(raw) == item.get("source_sha256"):
                    self.draft["edit"] = raw
                self.draft["effects"].update(item.get("effects") or {})
        for name, value in self.draft["effects"].items():
            if name in {"noise", "compact", "gain", "pitch", "tone"}:
                getattr(self, name).set(value)
        self.selection = None
        self.refresh()

    def refresh(self):
        self.samples = read_pcm(self.draft["edit"]) if self.draft["edit"] else []
        data = self.store.read()
        from own_voice import text_key
        count = sum(data.get("parts", {}).get(r["id"], {}).get("text") == text_key(r["text"]) for r in self.rows)
        self.info.set(f"အပိုင်း {self.index + 1} / {len(self.rows)} · Recap သို့ ပို့ပြီး {count} / {len(self.rows)} · {len(self.samples) / 48000:.1f} s")
        self.draw()

    def draw(self):
        self.canvas.delete("all")
        w, h = max(1, self.canvas.winfo_width()), 120
        if self.selection:
            a, b = sorted(self.selection)
            self.canvas.create_rectangle(a * w, 0, b * w, h, fill="#334d68", outline="")
        stride = max(1, len(self.samples) // w)
        for x in range(min(w, (len(self.samples) + stride - 1) // stride)):
            values = self.samples[x * stride:(x + 1) * stride]
            peak = max(map(abs, values), default=0) / 32768 * 55
            self.canvas.create_line(x, 60 - peak, x, 60 + peak, fill="#57bbcf")

    def select_start(self, event):
        if self.busy or self.recorder:
            return
        self.anchor = max(0, min(1, event.x / max(1, self.canvas.winfo_width())))
        self.selection = None

    def select_end(self, event):
        if self.anchor is not None and not self.busy and not self.recorder:
            self.selection = (self.anchor, max(0, min(1, event.x / max(1, self.canvas.winfo_width()))))
            self.draw()

    def invalidate(self):
        if self.busy or self.recorder:
            return
        self.draft["finished"] = None
        self.store.unsend(self.row["id"])
        try:
            self.draft["effects"] = self.effects()
        except (tk.TclError, ValueError):
            self.status.set("Volume / Pitch နံပါတ်ကို ပြည့်စုံအောင်ထည့်ပါ")
            return
        self.status.set("ပြောင်းလဲမှုကို သုံးဖို့ Finish → Send to Recap ပြန်လုပ်ပါ")

    def replace(self, path):
        self.store.unsend(self.row["id"])
        self.draft["history"].append(self.draft["edit"])
        self.draft.update(edit=path, finished=None)
        self.selection = None
        self.refresh()

    def import_audio(self):
        if not self._paid():
            return
        if self.busy or self.recorder:
            return
        path = filedialog.askopenfilename(parent=self, filetypes=[("Audio", "*.wav *.mp3 *.m4a *.aac *.flac *.ogg *.opus"), ("All", "*.*")])
        if path:
            self.stop_playback()
            self.task(lambda: normalize(path, self.store.temp("import"), self.ffmpeg), self.replace)

    def record(self):
        if not self._paid():
            return
        if self.busy or self.recorder:
            return
        if not self.device.get():
            self.status.set("Microphone ရွေးပါ")
            return
        self.stop_playback()
        try:
            self.recorder = Recorder(self.device.get(), self.store.temp(), self.ffmpeg)
            self.lock(True)
            self.status.set("● အသံသွင်းနေပါတယ် — ပြီးရင် Stop နှိပ်ပါ")
        except Exception as exc:
            self.status.set(str(exc))

    def stop(self):
        if not self.recorder:
            return
        recorder, self.recorder = self.recorder, None
        old = self.draft["edit"]
        def stopped():
            take = normalize(recorder.stop(), self.store.temp("capture"), self.ffmpeg)
            if old:
                take = write_pcm(self.store.temp("continued"), join_samples(read_pcm(old), read_pcm(take)))
            return take
        self.task(stopped, self.replace)

    def cut(self):
        if self.busy or self.recorder or not self.selection or not self.draft["edit"]:
            return
        a, b = sorted(self.selection)
        seconds = len(self.samples) / 48000
        self.stop_playback()
        self.task(lambda: cut(self.draft["edit"], self.store.temp("cut"), a * seconds, b * seconds), self.replace)

    def undo(self):
        if not self.busy and not self.recorder and self.draft["history"]:
            self.stop_playback()
            self.draft["edit"] = self.draft["history"].pop()
            self.draft["finished"] = None
            self.store.unsend(self.row["id"])
            self.refresh()

    def delete(self):
        if not self.busy and not self.recorder:
            self.stop_playback()
            self.replace(None)

    def finish(self):
        if not self._paid():
            return
        if self.busy or self.recorder or not self.draft["edit"]:
            return
        try:
            opts = self.effects()
        except (tk.TclError, ValueError):
            self.status.set("Volume / Pitch နံပါတ်ကို ပြည့်စုံအောင်ထည့်ပါ")
            return
        self.draft["effects"] = dict(opts)
        opts["ffmpeg"] = self.ffmpeg
        source, target = self.draft["edit"], self.store.temp("finished")
        self.status.set("အသံသန့်စင်နေပါတယ်… CPU / offline")
        def got(path):
            self.draft["finished"] = path
            self.status.set("Finish ပြီးပြီ — နားထောင်ပြီး Send to Recap နှိပ်ပါ")
        self.task(lambda: finish(source, target, **opts), got)

    def send(self):
        if not self._paid():
            return
        if self.busy or self.recorder:
            return False
        if not self.draft["finished"]:
            self.status.set("Finish အရင်လုပ်ပါ")
            return False
        self.store.send(self.row, self.draft["finished"], source=self.draft["edit"], effects=self.effects())
        self.status.set("✓ Recap သို့ ပို့ပြီးပါပြီ")
        self.refresh()
        return True

    def _paid(self):
        from membership_access import require_vip_audio
        try:
            require_vip_audio()
            return True
        except RuntimeError as exc:
            messagebox.showinfo("VIP", str(exc), parent=self)
            return False

    def effects(self):
        return dict(noise=self.noise.get(), compact=self.compact.get(), gain=self.gain.get(),
                    pitch=self.pitch.get(), tone=self.tone.get())

    def step(self, direction):
        if self.busy or self.recorder:
            return
        if direction > 0 and not self.send():
            return
        self.stop_playback()
        self.index = max(0, min(len(self.rows) - 1, self.index + direction))
        self.show()

    def stop_playback(self):
        if self.player is not None:
            if self.player.poll() is None:
                self.player.terminate()
            self.player.wait(timeout=5)
            self.player = None
        if self.play_job is not None:
            self.play_job.close()
            self.play_job = None

    def play(self, processed):
        if self.busy or self.recorder:
            return
        path = self.draft["finished" if processed else "edit"]
        if path:
            try:
                import subprocess
                import shutil
                from own_voice import ChildJob, NO_WINDOW
                self.stop_playback()
                player = Path(self.ffmpeg).with_name("ffplay.exe")
                if not player.is_file():
                    player = shutil.which("ffplay")
                if not player:
                    raise RuntimeError("Audio player မတွေ့ပါ — Studio99 ကို ပြန်တင်ပါ")
                self.player = subprocess.Popen([str(player), "-nodisp", "-autoexit", "-loglevel", "error", str(path)],
                                               stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                               stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)
                self.play_job = ChildJob(self.player)
            except Exception as exc:
                self.stop_playback()
                self.status.set(str(exc))

    def done(self):
        if self.busy or self.recorder:
            return
        try:
            if self.draft["finished"]:
                self.send()
            self.store.enable(True)
            self.store.resolve(self.rows)
        except Exception as exc:
            self.status.set(str(exc))
            return
        self.complete = True
        if self.on_complete:
            self.on_complete()
        self.close()

    def use_ai(self):
        if not self.busy and not self.recorder:
            self.store.enable(False)
            self.close()

    def close(self):
        if self.recorder:
            self.stop()
            self.status.set("အသံသိမ်းနေပါတယ်။ ပြီးရင် Close ပြန်နှိပ်ပါ")
            return
        if self.busy:
            self.status.set("လုပ်ဆောင်မှု ပြီးတဲ့အထိ ခဏစောင့်ပါ")
            return
        self.stop_playback()
        self.grab_release()
        if self.previous_grab is not None and self.previous_grab.winfo_exists():
            self.previous_grab.grab_set()
        self.destroy()


def open_standalone(work, rows, *, title="ကိုယ်ပိုင်အသံ", ffmpeg=None):
    root = tk.Tk()
    root.withdraw()
    root.option_add("*Font", "{Myanmar Text} 10")
    standalone_theme(root)
    editor = OwnVoiceEditor(root, work, rows, title=title, ffmpeg=ffmpeg)
    editor.wait_window()
    complete = editor.complete
    root.destroy()
    return complete


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("work")
    parser.add_argument("rows")
    args = parser.parse_args()
    open_standalone(args.work, json.loads(Path(args.rows).read_text(encoding="utf-8")))
