"""Worker threads hand UI work to the Tk main thread through this queue (2026-10-17: calling widget.after() from
the login thread raised "main thread is not in main loop" and the app stayed on the Login screen)."""
from __future__ import annotations

import queue
from typing import Callable

_queue: "queue.Queue[Callable[[], object]]" = queue.Queue()


def post(fn: Callable[[], object]) -> None:
    _queue.put(fn)


def install(root) -> None:
    def pump() -> None:
        while True:
            try:
                fn = _queue.get_nowait()
            except queue.Empty:
                break
            try:
                fn()
            except Exception:  # noqa: BLE001 - shown by the app's error handler
                root.report_callback_exception(*__import__("sys").exc_info())
        root.after(50, pump)
    root.after(50, pump)
