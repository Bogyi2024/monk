from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path


@dataclass
class Box:
    x: float
    y: float
    w: float
    h: float
    enabled: bool = True

    def pixels(self, width: int, height: int) -> tuple[int, int, int, int]:
        x, y = min(width - 2, round(self.x * width)), min(height - 2, round(self.y * height))
        return (x, y, min(width - x, max(2, round(self.w * width))),
                min(height - y, max(2, round(self.h * height))))

    def validate(self) -> None:
        if not all(0 <= value <= 1 for value in (self.x, self.y, self.w, self.h)):
            raise ValueError("Box coordinates must be between 0 and 100%")
        if self.w <= 0 or self.h <= 0 or self.x + self.w > 1.001 or self.y + self.h > 1.001:
            raise ValueError("A box extends outside the video frame")


@dataclass
class Layout:
    blur: Box = field(default_factory=lambda: Box(.10, .50, .80, .19, True))
    watermark: Box = field(default_factory=lambda: Box(.04, .025, .42, .065, True))
    title: Box = field(default_factory=lambda: Box(.12, .11, .76, .085, True))
    subtitle: Box = field(default_factory=lambda: Box(.06, .82, .88, .15, True))

    @classmethod
    def load(cls, path: Path) -> Layout:
        if not path.is_file():
            return cls()
        raw = json.loads(path.read_text(encoding="utf-8"))
        result = cls(**{name: Box(**raw[name]) for name in ("blur", "watermark", "title", "subtitle")})
        result.validate()
        return result

    def save(self, path: Path) -> None:
        self.validate()
        path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")

    def validate(self) -> None:
        for box in (self.blur, self.watermark, self.title, self.subtitle):
            box.validate()
