"""Atomic, non-secret job metadata shared by resumable stages."""
from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path


def write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def read_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def file_signature(path: Path) -> list:
    path = path.expanduser().resolve()
    stat = path.stat()
    return [str(path), stat.st_size, stat.st_mtime_ns]


def save_job(job: Path, options) -> None:
    values = asdict(options)
    values.pop("api_key", None)
    for key in ("video", "output_dir", "source_srt", "env_file"):
        values[key] = str(getattr(options, key).expanduser().resolve()) if getattr(options, key) else None
    write_json(job / "resume_job.json", {
        "version": 1, "options": values, "input": file_signature(options.video),
        "source_srt": file_signature(options.source_srt) if options.source_srt else None,
    })


def load_job(job: Path):
    from core import Options
    from layout import Box, Layout

    data = read_json(job / "resume_job.json")
    if not data or data.get("version") != 1:
        raise ValueError("Choose a job folder containing resume_job.json")
    values = dict(data["options"])
    for key in ("video", "output_dir", "source_srt", "env_file"):
        values[key] = Path(values[key]) if values.get(key) else None
    if file_signature(values["video"]) != data["input"]:
        raise ValueError("The original video changed. Start a new job instead of resuming this one.")
    if values["source_srt"] and file_signature(values["source_srt"]) != data["source_srt"]:
        raise ValueError("The source SRT changed. Start a new job instead of resuming this one.")
    if values.get("layout"):
        values["layout"] = Layout(**{key: Box(**value) for key, value in values["layout"].items()})
        values["layout"].validate()
    return Options(**values)
