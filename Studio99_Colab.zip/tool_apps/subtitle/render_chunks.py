"""Resume encoded video chunks, then mux the original audio once without cutting it."""
from __future__ import annotations

import hashlib
import json
import subprocess
from dataclasses import asdict
from fractions import Fraction
from pathlib import Path

from checkpoints import file_signature, read_json, write_json
from long_jobs import process

RENDER_PROFILE = "resumable_cfr_render_v2"


def valid_output(path, metadata, identity):
    return (metadata.get("identity") == identity and path.is_file() and path.stat().st_size > 0
            and metadata.get("output") == file_signature(path))


def render_resumable(options, result, cues, info, ass, output, ffmpeg, log, progress, cancel):
    from core import Cue, _check_cancel, _find_program, ass_fonts, render_video, write_ass
    from fonts import ass_filter

    video = options.video.expanduser().resolve()
    folder = Path(result["job_dir"]) / "chunks" / "render"
    folder.mkdir(parents=True, exist_ok=True)
    chunk_seconds = options.chunk_minutes * 60
    identity = {"profile": RENDER_PROFILE, "input": file_signature(video),
                "ass": hashlib.sha256(ass.read_bytes()).hexdigest(),
                "layout": asdict(options.layout) if options.layout else None,
                "chunk_seconds": chunk_seconds, "info": info}
    final_record = folder / "finished.json"
    if valid_output(output, read_json(final_record, {}), identity):
        log("Resume: completed MP4 already matches the saved subtitles and layout")
        return
    if info["duration"] <= chunk_seconds:
        render_video(video, ass, output, ffmpeg, log, cancel, options.layout,
                     (info["width"], info["height"]), fonts=[options.subtitle_font, options.overlay_font])
        write_json(final_record, {"identity": identity, "output": file_signature(output)})
        return

    rate = Fraction(info.get("frame_rate") or "25")
    if not 0 < rate <= 240:
        raise ValueError("Cannot determine a usable frame rate for chunked rendering")
    fps = f"{rate.numerator}/{rate.denominator}"
    total_frames = max(1, round(Fraction(str(info["duration"])) * rate))
    chunk_frames = max(1, round(Fraction(str(chunk_seconds)) * rate))
    count = (total_frames + chunk_frames - 1) // chunk_frames
    parts = []
    for index, first_frame in enumerate(range(0, total_frames, chunk_frames)):
        _check_cancel(cancel)
        frames = min(chunk_frames, total_frames - first_frame)
        start = float(first_frame / rate)
        duration = float(frames / rate)
        end = start + duration
        part = folder / f"part_{index:05d}.mp4"
        part_ass = folder / f"part_{index:05d}.ass"
        record = folder / f"part_{index:05d}.json"
        local_cues = [Cue(max(0, cue.start - start), min(duration, cue.end - start), cue.source, cue.text)
                      for cue in cues if cue.end > start and cue.start < end]
        write_ass(local_cues, part_ass, info["width"], info["height"], options.font_size,
                  options.bottom_margin, options.layout, options.title, options.part, options.watermark, duration,
                  **ass_fonts(options))
        part_identity = {"profile": RENDER_PROFILE, "input": identity["input"], "layout": identity["layout"],
                         "fps": fps, "first_frame": first_frame, "frames": frames,
                         "ass": hashlib.sha256(part_ass.read_bytes()).hexdigest()}
        if valid_output(part, read_json(record, {}), part_identity):
            log(f"Resume: render chunk {index + 1}/{count} already saved")
        else:
            log(f"Rendering chunk {index + 1}/{count}: {start / 60:.2f}–{end / 60:.2f} min")
            partial = part.with_name(part.stem + ".partial.mp4")
            # Reset the output frame grid to zero even if a VFR seek's first frame is late.
            cadence = f"fps={fps}:start_time=0,tpad=stop_mode=clone:stop_duration=1"
            subtitle_filter = ass_filter(part_ass, [options.subtitle_font, options.overlay_font])
            filters = ["-vf", f"{cadence},{subtitle_filter}"]
            video_map = "0:v:0"
            if options.layout and options.layout.blur.enabled:
                x, y, w, h = options.layout.blur.pixels(info["width"], info["height"])
                radius = max(1, min(18, (min(w, h) - 1) // 2))
                chroma = max(0, min(8, (min(w, h) - 2) // 4))
                filters = ["-filter_complex", f"[0:v]{cadence},split=2[base][copy];"
                           f"[copy]crop={w}:{h}:{x}:{y},boxblur={radius}:2:{chroma}:2[patch];"
                           f"[base][patch]overlay={x}:{y},{subtitle_filter}[vout]"]
                video_map = "[vout]"
            try:
                # Each boundary lies on the same frame grid. CFR conversion prevents cumulative
                # per-chunk rounding drift for VFR input; original audio stays on its full timeline.
                process([ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-ss", str(start),
                         "-i", str(video), *filters, "-map", video_map, "-an", "-frames:v", str(frames),
                         "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
                         "-video_track_timescale", str(rate.numerator), "-movflags", "+faststart", str(partial)],
                        cancel, cwd=folder)
                if not partial.is_file() or partial.stat().st_size == 0:
                    raise RuntimeError(f"Render chunk {index + 1} produced no video")
                probe = subprocess.run([_find_program("ffprobe"), "-v", "error", "-select_streams", "v:0",
                                        "-show_entries", "stream=nb_frames", "-of", "json", str(partial)],
                                       capture_output=True, text=True, check=True)
                actual_frames = int(json.loads(probe.stdout)["streams"][0]["nb_frames"])
                if actual_frames != frames:
                    raise RuntimeError(f"Render chunk {index + 1} has {actual_frames}/{frames} frames; incomplete chunk was not saved")
                partial.replace(part)
                write_json(record, {"identity": part_identity, "output": file_signature(part)})
            finally:
                partial.unlink(missing_ok=True)
        parts.append(part)
        progress(82 + round(15 * (index + 1) / count), f"Render chunk {index + 1}/{count} saved")

    _check_cancel(cancel)
    manifest = folder / "concat.txt"
    manifest.write_text("".join(f"file '{part.name}'\n" for part in parts), encoding="utf-8")
    partial = output.with_name(output.stem + ".partial.mp4")
    progress(98, "Joining saved video chunks and original audio")
    try:
        for codec in ("copy", "aac"):
            try:
                process([ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "1",
                         "-i", manifest.name, "-i", str(video), "-map", "0:v:0", "-map", "1:a?",
                         "-map_metadata", "1", "-c:v", "copy", "-c:a", codec, "-movflags", "+faststart", str(partial)],
                        cancel, cwd=folder)
                break
            except RuntimeError:
                if codec == "aac":
                    raise
                log("Original audio could not be copied into MP4; retrying final mux with AAC")
        partial.replace(output)
        write_json(final_record, {"identity": identity, "output": file_signature(output)})
    finally:
        partial.unlink(missing_ok=True)
