"""Name memory: one Burmese spelling per name for the whole job (<job>/NAME_GLOSSARY.json).

Each Gemini request sees only a few neighbouring lines, and Whisper writes a name a little
differently from scene to scene, so the same name could come out two ways (天罗 = ထျန်းလော်
nine times, တျန်လော့ once on the 5-hour job). The names are asked for once, before translating,
from the whole transcript; lines already translated are shown with their Burmese, so spellings
already on screen are kept. Every request then gets the names its lines mention.
Edit "mm" in the file to change a spelling: it is re-read when it changes. Never stops a run.
"""
from __future__ import annotations

import hashlib
import json
import re
import threading
import time
import unicodedata
from pathlib import Path

from checkpoints import read_json, write_json

GLOSSARY_FILE = "NAME_GLOSSARY.json"
VERSION = 1
CHUNK_CHARS = 40_000  # transcript + Burmese per request
MAX_NAMES_PER_REQUEST = 40


def _signature(cues) -> str:
    return hashlib.sha256("\n".join(c.source for c in cues).encode("utf-8")).hexdigest()


def _strip_format(value) -> str:
    # Zero-width joiners and similar invisible characters come back now and then.
    return "".join(ch for ch in str(value or "") if unicodedata.category(ch) != "Cf").strip()


def _forms(entry: dict) -> list[str]:
    return [f for f in [entry.get("source"), *(entry.get("other_forms") or [])] if isinstance(f, str) and f.strip()]


def _mentions(form: str, text: str) -> bool:
    form = form.strip()
    if len(form) < 2:
        return False  # a lone surname character would match far too much
    if re.search(r"[A-Za-z0-9]", form):
        return re.search(r"(?<![A-Za-z0-9])" + re.escape(form) + r"(?![A-Za-z0-9])", text, re.I) is not None
    return form in text


def _valid_mm(value: str) -> bool:
    from core import validate_myanmar_text

    try:
        validate_myanmar_text(value)
        return True
    except ValueError:
        return False


def clean_entry(raw) -> dict | None:
    """A usable entry or None (no source, or a spelling that is not plain Myanmar script)."""
    if not isinstance(raw, dict):
        return None
    source = _strip_format(raw.get("source"))
    mm = _strip_format(raw.get("mm"))
    if not source or not mm or not _valid_mm(mm):
        return None
    others = []
    for form in raw.get("other_forms") or []:
        form = _strip_format(form)
        if form and form != source and form not in others:
            others.append(form)
    gender = str(raw.get("gender") or "").strip().lower()
    return {"source": source, "other_forms": others, "kind": str(raw.get("kind") or "").strip().lower(),
            "who": str(raw.get("who") or "").strip(), "gender": gender if gender in {"male", "female"} else "",
            "mm": mm}


def merge(names: list[dict], new: dict) -> bool:
    """Add `new`, or fold its forms into the entry that already has one of them. True if anything changed."""
    new_forms = set(_forms(new))
    for entry in names:
        if new_forms & set(_forms(entry)):
            added = [f for f in _forms(new) if f not in _forms(entry)]
            entry["other_forms"] = [*(entry.get("other_forms") or []), *added]
            if not entry.get("gender") and new.get("gender"):
                entry["gender"] = new["gender"]
                return True
            return bool(added)
    names.append(new)
    return True


def _chunks(cues, texts) -> list[tuple[int, int]]:
    ranges, start, size = [], 0, 0
    for index, cue in enumerate(cues):
        line = len(cue.source) + len(texts[index] or "") + 8
        if size and size + line > CHUNK_CHARS:
            ranges.append((start, index))
            start, size = index, 0
        size += line
    ranges.append((start, len(cues)))
    return ranges


def _prompt(cues, texts, start: int, end: int, names: list[dict], language: str) -> str:
    listed = [{"source": e["source"], "other_forms": e.get("other_forms") or [], "mm": e["mm"]} for e in names]
    lines = "\n".join(f"{i + 1}. {cues[i].source}" + (f" => {texts[i]}" if texts[i] else "")
                      for i in range(start, end))
    return f"""
You make the NAME LIST for Burmese (Myanmar) subtitles of one video (source language: {language}).
It keeps every name spelled the same way for the whole video.

NAMES ALREADY LISTED (keep their spelling):
{json.dumps(listed, ensure_ascii=False)}

TRANSCRIPT lines {start + 1}-{end} of {len(cues)}. It comes from speech recognition, so one name may be
written with different characters. After "=>" is the Burmese subtitle already made for that line.
{lines}

List every proper name in these lines: people (and nicknames used as their name), places, families,
clans, sects and organizations, named skills and treasures. Not common nouns, and not titles or forms
of address (师父, 公子, 小姐, sir, master) unless the story uses them as a name. For each give:
- source: the name as this transcript most often writes it
- other_forms: other ways this transcript writes the same name (misheard characters, full name vs
  given name); never another person's name
- kind: person / place / group / other
- who: a few words to recognize it (role or relation)
- gender: male or female for a person when the story makes it clear, else ""
- mm: the name in Myanmar letters the way Burmese subtitles transliterate it. If a "=>" line already
  shows this name, copy that exact spelling. Short and easy to read; Myanmar letters only, never
  Latin, Thai or Khmer letters.
A name already listed is returned only to add other_forms to it.
Return only JSON: {{"names": [{{"source": "...", "other_forms": [], "kind": "...", "who": "...", "gender": "", "mm": "..."}}]}}
""".strip()


def _ask(keys, models, prompt: str, cancel=None) -> tuple[str, dict]:
    from google.genai import types

    from core import _check_cancel
    from gemini_keys import is_daily_quota, is_key_limited

    errors = []
    for model in models:
        for _attempt in range(len(keys)):
            _check_cancel(cancel)
            picked = keys.current(model, spread=True)
            if picked is None:
                break  # every key used today's quota for this model
            index, client = picked
            try:
                response = client.models.generate_content(
                    model=model, contents=prompt,
                    config=types.GenerateContentConfig(response_mime_type="application/json", temperature=0.1))
                data = json.loads(str(getattr(response, "text", "") or "").strip())
                if not isinstance(data, dict) or not isinstance(data.get("names"), list):
                    raise ValueError("answer has no names list")
                return model, data
            except InterruptedError:
                raise
            except Exception as exc:
                errors.append(f"{model} [{keys.keys[index][0]}]: {str(exc)[:160]}")
                if is_daily_quota(exc):
                    keys.mark_spent(index, model)
                elif is_key_limited(exc):
                    keys.rotate(exc, from_index=index)
                elif not isinstance(exc, (ValueError, KeyError)):
                    break  # busy model or dropped connection: the next model
    raise RuntimeError(" | ".join(errors[-2:]) or "no Gemini key")


def build_glossary(path: Path, cues, texts: list[str], language: str, keys, models, log, cancel=None) -> list[dict]:
    """Make (or finish) the job's name list; an existing complete list, maybe edited by hand, is kept."""
    path = Path(path)
    data = read_json(path, {}) or {}
    signature = _signature(cues)
    if data.get("version") != VERSION or data.get("source_signature") != signature:
        data = {"version": VERSION, "language": language, "source_signature": signature, "next_line": 0,
                "complete": False, "names": []}
    names = [e for e in (clean_entry(raw) for raw in data.get("names") or []) if e]
    if data.get("complete"):
        return names
    start = int(data.get("next_line") or 0)
    ranges = [(a, b) for a, b in _chunks(cues, texts) if b > start]
    if ranges:
        ranges[0] = (start, ranges[0][1])
    log(f"Name list: reading lines {start + 1}-{len(cues)} for names ({len(ranges)} request(s))")
    for first, last in ranges:
        prompt = _prompt(cues, texts, first, last, names, language)
        for attempt in (1, 2):
            model, answer = _ask(keys, models, prompt, cancel)
            refused = []
            for raw in answer.get("names") or []:
                entry = clean_entry(raw)
                if entry:
                    merge(names, entry)
                elif isinstance(raw, dict) and raw.get("source") and raw.get("mm"):
                    refused.append(str(raw["source"]))
            refused = [s for s in refused if not any(s in _forms(e) for e in names)]
            if not refused or attempt == 2:
                break
            # flash-lite mixes Thai / Khmer letters into a Burmese name now and then
            prompt += ("\n\nYour last answer wrote these names with letters of another script: "
                       f"{', '.join(refused[:20])}. Write every mm in Myanmar letters only.")
        data.update(names=names, next_line=last, model=model, made=time.strftime("%Y-%m-%d %H:%M"))
        write_json(path, data)
    data.update(complete=True)
    write_json(path, data)
    log(f"Name list: {len(names)} names → {path} (change a spelling there; it is used from the next request)")
    return names


class NameMemory:
    """Thread-safe reader of NAME_GLOSSARY.json that picks the names a request's lines mention."""

    def __init__(self, path: Path, log=None) -> None:
        self.path = Path(path)
        self.log = log or (lambda _msg: None)
        self._lock = threading.Lock()
        self._stamp = None
        self._names: list[dict] = []

    def names(self) -> list[dict]:
        with self._lock:
            try:
                stamp = self.path.stat().st_mtime_ns
            except OSError:
                return self._names
            if stamp != self._stamp:
                raw = (read_json(self.path, {}) or {}).get("names") or []
                names = [e for e in (clean_entry(r) for r in raw) if e]
                if self._stamp is not None:
                    self.log(f"Name list re-read: {len(names)} names")
                if len(names) < len(raw):
                    self.log(f"Name list: {len(raw) - len(names)} entry(ies) skipped (empty or not Myanmar letters)")
                self._stamp, self._names = stamp, names
            return self._names

    def for_lines(self, lines: list[str]) -> list[dict]:
        text = "\n".join(line for line in lines if line)
        found = [e for e in self.names() if any(_mentions(form, text) for form in _forms(e))]
        return [{k: e[k] for k in ("source", "other_forms", "mm", "gender", "who") if e.get(k)}
                for e in found[:MAX_NAMES_PER_REQUEST]]
