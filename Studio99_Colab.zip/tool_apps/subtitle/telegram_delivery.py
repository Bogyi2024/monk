from __future__ import annotations

import hashlib
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit


TOPIC_FILE = Path(__file__).with_name("telegram_topic.json")


def saved_topic() -> dict:
    if not TOPIC_FILE.is_file():
        return {}
    return json.loads(TOPIC_FILE.read_text(encoding="utf-8"))


def settings(env_file: Path | None, chat_id: str = "", thread_id: str = "", base: str = "") -> dict[str, str]:
    from dotenv import dotenv_values

    values = dotenv_values(env_file) if env_file and env_file.is_file() else {}

    def value(name: str) -> str:
        return str(values.get(name) or os.getenv(name) or "").strip()

    token = re.sub(r"[^0-9A-Za-z:_-]", "", value("DUB_TELEGRAM_BOT_TOKEN"))
    topic = saved_topic()
    result = {
        "token": token,
        "chat_id": chat_id.strip() or str(topic.get("chat_id") or "") or value("DUB_TELEGRAM_CHAT_ID"),
        "thread_id": thread_id.strip() or str(topic.get("message_thread_id") or ""),
        "base": (base.strip() or value("DUB_TELEGRAM_BOT_API_BASE")).rstrip("/"),
    }
    validate(result)
    if (result["thread_id"] == value("DUB_TELEGRAM_THREAD_ID") and
            result["chat_id"] == value("DUB_TELEGRAM_CHAT_ID")):
        raise ValueError("Choose the dedicated Subtitle translation topic, not the DUB topic")
    return result


def validate(config: dict[str, str]) -> None:
    parsed = urlsplit(config.get("base", ""))
    if parsed.scheme not in {"http", "https"} or parsed.hostname not in {"localhost", "127.0.0.1", "::1"}:
        raise ValueError("Telegram Bot API base must point to the local server (localhost or 127.0.0.1)")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Invalid local Telegram Bot API URL")
    if not config.get("token"):
        raise ValueError("DUB_TELEGRAM_BOT_TOKEN is missing from the selected .env")
    if not re.fullmatch(r"-?\d+", config.get("chat_id", "")):
        raise ValueError("Telegram group chat ID must be numeric")
    if not re.fullmatch(r"[1-9]\d*", config.get("thread_id", "")):
        raise ValueError("Telegram topic ID must be a positive number")


def send_video(video: Path, config: dict[str, str], caption: str, log=print) -> dict:
    """Send a completed MP4 once to the exact group topic; never log the bot token."""
    validate(config)
    video = video.resolve()
    if not video.is_file() or video.stat().st_size == 0:
        raise ValueError("Completed MP4 does not exist")
    lock = video.with_name(video.stem + ".telegram.lock")
    try:
        handle = lock.open("x", encoding="utf-8")
    except FileExistsError:
        raise RuntimeError("Telegram delivery is locked. Check the topic and receipt before retrying; another send may still be running.") from None
    try:
        with handle:
            handle.write(str(os.getpid()))
        return _send_locked(video, config, caption, log)
    finally:
        lock.unlink(missing_ok=True)


def _send_locked(video: Path, config: dict[str, str], caption: str, log) -> dict:
    import requests

    digest = hashlib.sha256()
    with video.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    identity = hashlib.sha256(
        f"{digest.hexdigest()}|{config['chat_id']}|{config['thread_id']}".encode("utf-8")
    ).hexdigest()
    receipt_file = video.with_name(video.stem + ".telegram.json")
    deliveries = {}
    if receipt_file.is_file():
        try:
            old = json.loads(receipt_file.read_text(encoding="utf-8"))
            deliveries = old.get("deliveries") or ({old["identity"]: old} if old.get("identity") else {})
            previous = deliveries.get(identity, {})
            if previous.get("status") == "sent":
                log("Telegram: already sent this exact output to this topic")
                return previous
            if previous.get("status") in {"pending", "uncertain"}:
                raise RuntimeError("Telegram delivery outcome is uncertain. Check this topic before retrying; automatic resend was blocked to avoid duplicates.")
        except (ValueError, OSError):
            raise RuntimeError("Telegram receipt cannot be read; check delivery before retrying to avoid duplicates") from None

    def record(receipt: dict) -> None:
        deliveries[identity] = receipt
        temporary = receipt_file.with_name(receipt_file.name + ".tmp")
        temporary.write_text(json.dumps({**receipt, "deliveries": deliveries}, indent=2), encoding="utf-8")
        temporary.replace(receipt_file)

    receipt = {"identity": identity, "status": "pending", "chat_id": config["chat_id"],
               "thread_id": config["thread_id"], "started_at": datetime.now(timezone.utc).isoformat()}
    # Record before sending: a lost response or crash must not silently cause a duplicate.
    record(receipt)
    data = {"chat_id": config["chat_id"], "message_thread_id": config["thread_id"],
            "caption": caption[:1024], "supports_streaming": "true"}
    url = f"{config['base']}/bot{config['token']}/sendVideo"
    log(f"Telegram: sending {video.name} to group {config['chat_id']} topic {config['thread_id']}")
    try:
        with video.open("rb") as stream:
            response = requests.post(url, data=data,
                                     files={"video": (video.name, stream, "video/mp4")},
                                     timeout=(30, 1800), allow_redirects=False)
    except requests.RequestException as exc:
        record({**receipt, "status": "uncertain"})
        raise RuntimeError(f"Telegram response was lost ({type(exc).__name__}); check the topic before retrying to avoid duplicates") from None
    try:
        payload = response.json()
    except ValueError:
        payload = {}
    if not isinstance(payload, dict):
        payload = {}
    if not response.ok or not payload.get("ok"):
        description = str(payload.get("description") or f"HTTP {response.status_code}")
        record({**receipt, "status": "failed" if payload.get("ok") is False else "uncertain"})
        raise RuntimeError(f"Telegram upload failed: {description}")
    if not (payload.get("result") or {}).get("message_id"):
        record({**receipt, "status": "uncertain"})
        raise RuntimeError("Telegram returned no message ID; check the topic before retrying")
    receipt = {"identity": identity, "status": "sent", "message_id": (payload.get("result") or {}).get("message_id"),
               "chat_id": config["chat_id"], "thread_id": config["thread_id"],
               "sent_at": datetime.now(timezone.utc).isoformat()}
    record(receipt)
    log(f"Telegram: sent (message {receipt['message_id']})")
    return receipt
