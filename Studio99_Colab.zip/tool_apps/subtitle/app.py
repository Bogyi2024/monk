from __future__ import annotations

import json
import os
import queue
import re
import threading
import tkinter as tk
from dataclasses import replace
from pathlib import Path
from tkinter import colorchooser, filedialog, messagebox, ttk

from core import Options, ass_color, part_label, render_prepared, run
from batch_review import BatchReviewDialog
from layout import Layout
from preview import PreviewDialog, PreviewPanel
from review import ReviewDialog
from telegram_delivery import saved_topic, send_video, settings
from checkpoints import load_job, read_json


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
LAYOUT_FILE = ROOT / "layout.json"
UI_SETTINGS_FILE = ROOT / "ui_settings.json"
VIDEO_SUFFIXES = {".mp4", ".mkv", ".mov", ".webm", ".avi"}
LANGUAGES = {
    "Auto detect": "auto", "English": "en", "Korean": "ko", "Chinese": "zh",
    "Japanese": "ja", "Thai": "th", "Indonesian": "id", "Hindi": "hi",
    "Spanish": "es", "Myanmar (no translation)": "my",
}


class SubtitleApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Myanmar Subtitle Studio")
        self.geometry("1400x900")
        self.minsize(1100, 680)
        try:
            self.state("zoomed")
        except tk.TclError:
            pass
        self.configure(bg="#101725")
        self.events: queue.Queue[tuple] = queue.Queue()
        self.cancel_event = threading.Event()
        self.worker: threading.Thread | None = None
        self.last_result: dict | None = None
        self.pending_jobs: list[Options] = []
        self.telegram_config: dict | None = None
        self.completed_total = 0
        self.errors_total = 0

        self.video = tk.StringVar()
        self.input_folder = tk.StringVar()
        self.source_srt = tk.StringVar()
        self.output_dir = tk.StringVar(value=str(ROOT / "outputs"))
        self.language = tk.StringVar(value="Auto detect")
        self.whisper_model = tk.StringVar(value="medium")
        self.gemini_model = tk.StringVar(value="gemini-3.5-flash")
        self.api_key = tk.StringVar()
        existing_env = WORKSPACE / "recap_personal" / ".env"
        self.env_file = tk.StringVar(value=str(existing_env) if existing_env.is_file() else "")
        self.font_size = tk.StringVar(value="48")
        self.bottom_margin = tk.StringVar(value="64")
        self.srt_only = tk.BooleanVar(value=False)
        self.audio_crosscheck = tk.BooleanVar(value=True)
        self.batch_size = tk.StringVar(value="10")
        self.chunk_minutes = tk.StringVar(value="15")
        self.translation_workers = tk.StringVar(value="4")
        self.cues_per_request = tk.StringVar(value="30")
        self.name_memory = tk.BooleanVar(value=True)
        self.subtitle_font = tk.StringVar(value="Myanmar Text")
        self.subtitle_bold = tk.BooleanVar(value=False)
        self.overlay_font = tk.StringVar(value="Myanmar Text")
        self.overlay_font_size = tk.IntVar(value=0)
        self.subtitle_color = tk.StringVar(value="#FFFFFF")
        self.outline_color = tk.StringVar(value="#252525")
        self.outline_width = tk.StringVar(value="Auto")
        self.shadow = tk.StringVar(value="0")
        self.box_enabled = tk.BooleanVar(value=True)
        self.box_color = tk.StringVar(value="#383838")
        self.box_opacity = tk.IntVar(value=62)
        self.output_mode = tk.StringVar(value="full")  # "full" = one video, "parts" = N-minute parts
        self.part_minutes = tk.StringVar(value="4")
        self.current_job: Path | None = None
        self.title_text = tk.StringVar()
        self.part_text = tk.StringVar()
        self.watermark_text = tk.StringVar()
        self.speaker_context = tk.StringVar()
        self.telegram_send = tk.BooleanVar(value=False)
        self.telegram_chat = tk.StringVar()
        self.telegram_topic = tk.StringVar()
        self.telegram_base = tk.StringVar()
        try:
            from dotenv import dotenv_values
            existing = dotenv_values(existing_env) if existing_env.is_file() else {}
            topic = saved_topic()
            self.telegram_chat.set(str(topic.get("chat_id") or existing.get("DUB_TELEGRAM_CHAT_ID") or ""))
            self.telegram_topic.set(str(topic.get("message_thread_id") or ""))
            self.telegram_base.set(str(existing.get("DUB_TELEGRAM_BOT_API_BASE") or ""))
        except (OSError, ValueError):
            pass
        self.status = tk.StringVar(value="Ready")
        self.percent = tk.IntVar(value=0)

        self._build()
        self._load_ui_settings()
        self._font_scale_var.set(float(self.font_size.get() or 48))
        self._overlay_scale_var.set(float(self.overlay_font_size.get()))
        self._overlay_size_changed(self.overlay_font_size.get())
        self.after(100, self._drain_events)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build(self) -> None:
        bg, fg, muted = "#101725", "#e8edf7", "#9da9be"
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure(".", background=bg, foreground=fg)
        style.configure("TFrame", background=bg)
        style.configure("App.TFrame", background=bg)
        style.configure("TLabel", background=bg, foreground=fg, font=("Myanmar Text", 10))
        style.configure("App.TLabel", background=bg, foreground=fg, font=("Myanmar Text", 10))
        style.configure("Heading.TLabel", background=bg, foreground="#ffffff", font=("Myanmar Text", 15, "bold"))
        style.configure("Muted.TLabel", background=bg, foreground=muted, font=("Myanmar Text", 9))
        style.configure("TLabelframe", background=bg, bordercolor="#2a3550")
        style.configure("TLabelframe.Label", background=bg, foreground=fg, font=("Segoe UI Semibold", 10))
        style.configure("Accent.TButton", padding=9, font=("Myanmar Text", 10, "bold"))
        style.configure("App.TButton", padding=5, font=("Myanmar Text", 9))
        style.configure("TCheckbutton", background=bg, foreground=fg, font=("Myanmar Text", 9))
        style.map("TCheckbutton", background=[("active", bg)])
        style.configure("App.TCheckbutton", background=bg, foreground=fg, font=("Myanmar Text", 9))
        style.map("App.TCheckbutton", background=[("active", bg)])
        style.configure("TRadiobutton", background=bg, foreground=fg)
        style.map("TRadiobutton", background=[("active", bg)])
        style.configure("TPanedwindow", background=bg)
        field = "#0b1020"
        for name in ("TEntry", "TCombobox", "TSpinbox"):
            style.configure(name, fieldbackground=field, foreground=fg, insertcolor=fg,
                            bordercolor="#2a3550", lightcolor="#2a3550", darkcolor="#2a3550", arrowcolor=fg)
        style.map("TCombobox", fieldbackground=[("readonly", field)], foreground=[("readonly", fg)],
                  selectbackground=[("readonly", field)], selectforeground=[("readonly", fg)])
        self.option_add("*TCombobox*Listbox.background", field)
        self.option_add("*TCombobox*Listbox.foreground", fg)

        outer = ttk.Frame(self, style="App.TFrame", padding=(12, 8, 12, 8))
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(1, weight=1)
        header = ttk.Frame(outer, style="App.TFrame")
        header.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(header, text="Myanmar Subtitle Studio", style="Heading.TLabel").pack(side="left")
        ttk.Label(header, text="မူရင်းအသံကို ထားပြီး မြန်မာစာတန်းထိုး MP4 + SRT ထုတ်ပေးသည်",
                  style="Muted.TLabel").pack(side="left", padx=(14, 0), pady=(6, 0))

        main = ttk.PanedWindow(outer, orient="horizontal")
        main.grid(row=1, column=0, sticky="nsew")
        left = ttk.PanedWindow(main, orient="vertical")

        # ---------------- settings (scrollable)
        settings_host = ttk.Frame(left, style="App.TFrame")
        settings_host.rowconfigure(0, weight=1)
        settings_host.columnconfigure(0, weight=1)
        canvas = tk.Canvas(settings_host, bg=bg, highlightthickness=0, width=560)
        scrollbar = ttk.Scrollbar(settings_host, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        form = ttk.Frame(canvas, style="App.TFrame", padding=(4, 0, 10, 6))
        window = canvas.create_window((0, 0), window=form, anchor="nw")
        form.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(window, width=event.width))
        form.columnconfigure(0, weight=1)

        def section(title: str) -> ttk.LabelFrame:
            frame = ttk.LabelFrame(form, text=title, padding=(8, 4, 8, 6))
            frame.grid(row=len(form.grid_slaves()), column=0, sticky="ew", pady=(0, 8))
            frame.columnconfigure(1, weight=1)
            return frame

        box = section("Input")
        self._file_row(box, 0, "Video / ဗီဒီယို", self.video, lambda: self._choose_file(self.video, [("Videos", "*.mp4 *.mkv *.mov *.webm *.avi"), ("All files", "*.*")]))
        self._file_row(box, 1, "Or folder / ဖိုင်တွဲ", self.input_folder, self._choose_input_folder, folder=True)
        self._file_row(box, 2, "Source SRT (optional)", self.source_srt, lambda: self._choose_file(self.source_srt, [("SRT", "*.srt"), ("All files", "*.*")]))
        self._file_row(box, 3, "Output folder", self.output_dir, self._choose_output, folder=True)

        box = section("Language & AI")
        self._label(box, 0, "Source language")
        ttk.Combobox(box, textvariable=self.language, values=list(LANGUAGES), state="readonly", width=22).grid(row=0, column=1, sticky="w", pady=3)
        self._label(box, 1, "Speaker notes")
        ttk.Entry(box, textvariable=self.speaker_context).grid(row=1, column=1, columnspan=2, sticky="ew", pady=3)
        self._label(box, 2, "Whisper model")
        ttk.Combobox(box, textvariable=self.whisper_model, values=["small", "medium", "large-v3"], width=22).grid(row=2, column=1, sticky="w", pady=3)
        self._label(box, 3, "Gemini model")
        ttk.Entry(box, textvariable=self.gemini_model).grid(row=3, column=1, columnspan=2, sticky="ew", pady=3)
        self._label(box, 4, "Gemini API key")
        ttk.Entry(box, textvariable=self.api_key, show="*").grid(row=4, column=1, sticky="ew", pady=3)
        ttk.Label(box, text="not saved", style="Muted.TLabel").grid(row=4, column=2, sticky="w", padx=8)
        self._label(box, 6, "Translate at once")
        workers_row = ttk.Frame(box, style="App.TFrame")
        workers_row.grid(row=6, column=1, columnspan=2, sticky="w", pady=3)
        ttk.Spinbox(workers_row, from_=1, to=8, textvariable=self.translation_workers, width=5).pack(side="left")
        ttk.Label(workers_row, text="Gemini requests sent at the same time · 1 = one at a time",
                  style="Muted.TLabel").pack(side="left", padx=8)
        self._label(box, 7, "Cues per request")
        per_row = ttk.Frame(box, style="App.TFrame")
        per_row.grid(row=7, column=1, columnspan=2, sticky="w", pady=3)
        ttk.Spinbox(per_row, from_=1, to=30, textvariable=self.cues_per_request, width=5).pack(side="left")
        ttk.Label(per_row, text="neighbouring cues in one Gemini request (tested up to 30) · 1 = one cue each",
                  style="Muted.TLabel").pack(side="left", padx=8)
        ttk.Checkbutton(box, text="Keep names the same (name list NAME_GLOSSARY.json in the job folder · editable)",
                        variable=self.name_memory, style="App.TCheckbutton").grid(row=8, column=1, columnspan=2,
                                                                                 sticky="w", pady=3)
        self._file_row(box, 5, ".env file", self.env_file, lambda: self._choose_file(self.env_file, [("Env files", "*.env *.txt"), ("All files", "*.*")]))

        box = section("Subtitle & Render")
        self._label(box, 0, "Font size")
        font_row = ttk.Frame(box, style="App.TFrame")
        font_row.grid(row=0, column=1, columnspan=2, sticky="ew", pady=3)
        font_row.columnconfigure(0, weight=1)
        self._font_scale_var = tk.DoubleVar(value=float(self.font_size.get() or 48))
        ttk.Scale(font_row, from_=22, to=100, orient="horizontal", variable=self._font_scale_var,
                  command=self._font_slider_changed).grid(row=0, column=0, sticky="ew")
        self.font_size_label = ttk.Spinbox(font_row, from_=22, to=100, textvariable=self.font_size, width=5,
                                           command=self._font_spin_changed)
        self.font_size_label.grid(row=0, column=1, padx=(8, 0))
        self.font_size_label.bind("<KeyRelease>", lambda _e: self._font_spin_changed())
        ttk.Checkbutton(box, text="SRT only (skip video render)", variable=self.srt_only,
                        style="App.TCheckbutton").grid(row=1, column=1, columnspan=2, sticky="w", pady=3)
        ttk.Checkbutton(box, text="Check audio with Gemini + Whisper", variable=self.audio_crosscheck,
                        style="App.TCheckbutton").grid(row=2, column=1, columnspan=2, sticky="w", pady=3)
        self._label(box, 5, "Subtitle font")
        font_pick = ttk.Frame(box, style="App.TFrame")
        font_pick.grid(row=5, column=1, columnspan=2, sticky="ew", pady=3)
        font_pick.columnconfigure(0, weight=1)
        self.subtitle_font_box = ttk.Combobox(font_pick, textvariable=self.subtitle_font, values=["Myanmar Text"], state="readonly")
        self.subtitle_font_box.grid(row=0, column=0, sticky="ew")
        ttk.Checkbutton(font_pick, text="Bold", variable=self.subtitle_bold, style="App.TCheckbutton",
                        command=self._update_preview_texts).grid(row=0, column=1, padx=(8, 0))
        self._label(box, 6, "Text colour")
        colour_row = ttk.Frame(box, style="App.TFrame")
        colour_row.grid(row=6, column=1, columnspan=2, sticky="w", pady=3)
        self._color_button(colour_row, self.subtitle_color).pack(side="left")
        ttk.Label(colour_row, text="Stroke", style="App.TLabel").pack(side="left", padx=(12, 4))
        self._color_button(colour_row, self.outline_color).pack(side="left")
        ttk.Spinbox(colour_row, values=["Auto"] + [str(n) for n in range(0, 13)], textvariable=self.outline_width,
                    width=5, command=self._update_preview_texts).pack(side="left", padx=(6, 0))
        ttk.Label(colour_row, text="px", style="Muted.TLabel").pack(side="left", padx=(3, 0))
        ttk.Label(colour_row, text="Shadow", style="App.TLabel").pack(side="left", padx=(12, 4))
        ttk.Spinbox(colour_row, from_=0, to=10, textvariable=self.shadow, width=4,
                    command=self._update_preview_texts).pack(side="left")
        self._label(box, 7, "Background box")
        bg_row = ttk.Frame(box, style="App.TFrame")
        bg_row.grid(row=7, column=1, columnspan=2, sticky="ew", pady=3)
        bg_row.columnconfigure(2, weight=1)
        ttk.Checkbutton(bg_row, text="On", variable=self.box_enabled, style="App.TCheckbutton",
                        command=self._update_preview_texts).grid(row=0, column=0)
        self._color_button(bg_row, self.box_color).grid(row=0, column=1, padx=(8, 8))
        ttk.Scale(bg_row, from_=0, to=100, orient="horizontal", variable=self.box_opacity,
                  command=lambda v: (self.box_opacity.set(int(round(float(v)))), self._update_preview_texts())
                  ).grid(row=0, column=2, sticky="ew")
        ttk.Label(bg_row, textvariable=self.box_opacity, width=4).grid(row=0, column=3, padx=(6, 0))
        ttk.Label(bg_row, text="%", style="Muted.TLabel").grid(row=0, column=4)
        for var in (self.outline_width, self.shadow):
            var.trace_add("write", lambda *_: self._update_preview_texts())
        self._label(box, 8, "Video output")
        output_row = ttk.Frame(box, style="App.TFrame")
        output_row.grid(row=8, column=1, columnspan=2, sticky="w", pady=3)
        ttk.Radiobutton(output_row, text="Full video", value="full", variable=self.output_mode).pack(side="left")
        ttk.Radiobutton(output_row, text="Parts of", value="parts", variable=self.output_mode).pack(side="left", padx=(14, 4))
        ttk.Spinbox(output_row, from_=1, to=60, textvariable=self.part_minutes, width=4).pack(side="left")
        ttk.Label(output_row, text="min · each part is made as soon as it is translated",
                  style="Muted.TLabel").pack(side="left", padx=6)
        self._label(box, 3, "Folder review size")
        ttk.Spinbox(box, from_=1, to=100, textvariable=self.batch_size, width=6).grid(row=3, column=1, sticky="w", pady=3)
        self._label(box, 4, "Long video chunk")
        chunk_row = ttk.Frame(box, style="App.TFrame")
        chunk_row.grid(row=4, column=1, columnspan=2, sticky="w", pady=3)
        ttk.Spinbox(chunk_row, from_=1, to=60, textvariable=self.chunk_minutes, width=6).pack(side="left")
        ttk.Label(chunk_row, text="minutes · ပြီးသောအပိုင်းကို သိမ်းပြီး Resume ရသည်", style="Muted.TLabel").pack(side="left", padx=8)

        box = section("Text on video (drag the boxes in Preview)")
        self._label(box, 0, "Title / ခေါင်းစဉ်")
        ttk.Entry(box, textvariable=self.title_text).grid(row=0, column=1, columnspan=2, sticky="ew", pady=3)
        self._label(box, 1, "Part / အပိုင်း")
        ttk.Entry(box, textvariable=self.part_text).grid(row=1, column=1, columnspan=2, sticky="ew", pady=3)
        ttk.Label(box, text="Folder run: empty = each filename · {stem} = filename · Parts: {n} = 1, 2 · {mm} = ၁, ၂", style="Muted.TLabel").grid(row=2, column=1, columnspan=2, sticky="w")
        self._label(box, 3, "Watermark text")
        ttk.Entry(box, textvariable=self.watermark_text).grid(row=3, column=1, columnspan=2, sticky="ew", pady=3)
        self._label(box, 4, "Title / Watermark font")
        self.overlay_font_box = ttk.Combobox(box, textvariable=self.overlay_font, values=["Myanmar Text"], state="readonly")
        self.overlay_font_box.grid(row=4, column=1, columnspan=2, sticky="ew", pady=3)
        self._label(box, 5, "Title / Watermark size")
        overlay_row = ttk.Frame(box, style="App.TFrame")
        overlay_row.grid(row=5, column=1, columnspan=2, sticky="ew", pady=3)
        overlay_row.columnconfigure(0, weight=1)
        self._overlay_scale_var = tk.DoubleVar(value=0.0)
        ttk.Scale(overlay_row, from_=0, to=140, orient="horizontal", variable=self._overlay_scale_var,
                  command=self._overlay_size_changed).grid(row=0, column=0, sticky="ew")
        self.overlay_size_label = ttk.Label(overlay_row, text="Auto", width=6)
        self.overlay_size_label.grid(row=0, column=1, padx=(8, 0))
        ttk.Label(box, text="Size 0 = Auto (fits the box) · fonts: installed Myanmar fonts", style="Muted.TLabel").grid(row=6, column=1, columnspan=2, sticky="w")

        box = section("Telegram")
        ttk.Checkbutton(box, text="Send finished MP4 to Telegram topic", variable=self.telegram_send,
                        style="App.TCheckbutton").grid(row=0, column=0, columnspan=3, sticky="w", pady=3)
        telegram = ttk.Frame(box, style="App.TFrame")
        telegram.grid(row=1, column=0, columnspan=3, sticky="ew")
        ttk.Label(telegram, text="Group ID", style="App.TLabel").pack(side="left")
        ttk.Entry(telegram, textvariable=self.telegram_chat, width=16).pack(side="left", padx=(5, 12))
        ttk.Label(telegram, text="Topic ID", style="App.TLabel").pack(side="left")
        ttk.Entry(telegram, textvariable=self.telegram_topic, width=10).pack(side="left", padx=(5, 12))
        self._label(box, 2, "Local Telegram API")
        ttk.Entry(box, textvariable=self.telegram_base).grid(row=2, column=1, columnspan=2, sticky="ew", pady=3)

        def wheel(event):
            canvas.yview_scroll(int(-event.delta / 120), "units")

        def bind_wheel(widget):
            if not isinstance(widget, (ttk.Combobox, ttk.Spinbox, ttk.Scale)):
                widget.bind("<MouseWheel>", wheel, add="+")
            for child in widget.winfo_children():
                bind_wheel(child)
        canvas.bind("<MouseWheel>", wheel, add="+")
        bind_wheel(form)

        # ---------------- log
        log_host = ttk.LabelFrame(left, text="Log", padding=4)
        log_host.rowconfigure(0, weight=1)
        log_host.columnconfigure(0, weight=1)
        self.log_widget = tk.Text(log_host, height=8, bg="#0b1020", fg="#d3ddec", insertbackground="#fff",
                                  wrap="word", relief="flat", font=("Consolas", 9))
        self.log_widget.grid(row=0, column=0, sticky="nsew")
        log_scroll = ttk.Scrollbar(log_host, orient="vertical", command=self.log_widget.yview)
        log_scroll.grid(row=0, column=1, sticky="ns")
        self.log_widget.configure(yscrollcommand=log_scroll.set, state="disabled")
        left.add(settings_host, weight=3)
        left.add(log_host, weight=1)

        # ---------------- preview (always visible)
        preview_box = ttk.LabelFrame(main, text="Preview — box positions apply to every video", padding=8)
        preview_box.rowconfigure(0, weight=1)
        preview_box.columnconfigure(0, weight=1)
        self.preview_panel = PreviewPanel(preview_box, LAYOUT_FILE)
        self.preview_panel.grid(row=0, column=0, sticky="nsew")
        main.add(left, weight=2)
        main.add(preview_box, weight=3)
        self._main_pane, self._left_pane = main, left
        self.after(300, self._apply_pane_layout)

        # ---------------- buttons / status
        buttons = ttk.Frame(outer, style="App.TFrame")
        buttons.grid(row=2, column=0, sticky="ew", pady=(8, 4))
        self.start_button = ttk.Button(buttons, text="▶  Start / Resume", style="Accent.TButton", command=self._start)
        self.start_button.pack(side="left")
        self.cancel_button = ttk.Button(buttons, text="Pause", style="App.TButton", command=self._cancel, state="disabled")
        self.cancel_button.pack(side="left", padx=8)
        self.resume_button = ttk.Button(buttons, text="Resume saved job", style="App.TButton", command=self._resume)
        self.resume_button.pack(side="left")
        ttk.Label(buttons, textvariable=self.status, style="App.TLabel").pack(side="left", padx=(16, 0))
        self.open_button = ttk.Button(buttons, text="Open output", style="App.TButton", command=self._open_output, state="disabled")
        self.open_button.pack(side="right")
        self.review_button = ttk.Button(buttons, text="Review / Edit", style="App.TButton", command=self._review)
        self.review_button.pack(side="right", padx=8)
        ttk.Progressbar(outer, variable=self.percent, maximum=100).grid(row=3, column=0, sticky="ew", pady=(2, 0))

        # Preview follows the chosen video/folder and the text fields as they are typed.
        self._preview_job = None
        for var in (self.video, self.input_folder):
            var.trace_add("write", lambda *_: self._schedule_preview_video())
        for var in (self.title_text, self.part_text, self.watermark_text, self.subtitle_font, self.overlay_font):
            var.trace_add("write", lambda *_: self._update_preview_texts())
        threading.Thread(target=self._load_font_list, daemon=True).start()
        self.after(300, self._schedule_preview_video)

    # ---------------------------------------------------------- preview / settings helpers
    def _apply_pane_layout(self) -> None:
        """Settings get ~72% of the left column (log the rest); left column ~40% wide."""
        try:
            self.update_idletasks()
            width, height = self._main_pane.winfo_width(), self._left_pane.winfo_height()
            if width < 400 or height < 200:
                self.after(250, self._apply_pane_layout)
                return
            self._main_pane.sashpos(0, max(520, int(width * 0.40)))
            self._left_pane.sashpos(0, int(height * 0.72))
        except tk.TclError:
            pass

    def _load_font_list(self) -> None:
        try:
            from fonts import myanmar_fonts
            self.events.put(("fonts", sorted(myanmar_fonts(), key=str.casefold)))
        except Exception as exc:
            self.events.put(("log", f"Font list unavailable ({exc}); using Myanmar Text"))

    def _overlay_size_changed(self, value) -> None:
        size = int(round(float(value)))
        self.overlay_font_size.set(size)
        self.overlay_size_label.configure(text="Auto" if size == 0 else str(size))
        self._update_preview_texts()

    def _font_slider_changed(self, value) -> None:
        self.font_size.set(str(int(round(float(value)))))
        self._update_preview_texts()

    def _font_spin_changed(self) -> None:
        try:
            size = int(self.font_size.get())
        except ValueError:
            return
        if 22 <= size <= 100:
            self._font_scale_var.set(float(size))
            self._update_preview_texts()

    def _color_button(self, parent, var: tk.StringVar) -> tk.Button:
        def pick() -> None:
            chosen = colorchooser.askcolor(color=var.get(), parent=self)[1]
            if chosen:
                var.set(chosen.upper())

        button = tk.Button(parent, width=9, relief="groove", cursor="hand2", command=pick)

        def show(*_) -> None:
            try:
                ass_color(var.get())
                value = var.get()
            except ValueError:
                return
            r, g, b = (int(value[i:i + 2], 16) for i in (1, 3, 5))
            button.configure(bg=value, activebackground=value, text=value.upper(),
                             fg="#000000" if r * .3 + g * .59 + b * .11 > 140 else "#FFFFFF")
            self._update_preview_texts()

        var.trace_add("write", show)
        show()
        return button

    def _split_minutes(self) -> float:
        """0 for one full video, else the part length in minutes (raises ValueError when invalid)."""
        if self.output_mode.get() != "parts":
            return 0
        minutes = float(self.part_minutes.get())
        if not 1 <= minutes <= 60:
            raise ValueError("Part length must be between 1 and 60 minutes")
        return minutes

    def _subtitle_style(self) -> dict:
        width = self.outline_width.get().strip()
        return dict(text_color=self.subtitle_color.get(), outline_color=self.outline_color.get(),
                    outline_width=-1 if width.lower() in {"", "auto"} else int(width),
                    shadow=int(self.shadow.get() or 0), box_enabled=self.box_enabled.get(),
                    box_color=self.box_color.get(), box_opacity=int(self.box_opacity.get()))

    def _schedule_preview_video(self) -> None:
        if self._preview_job is not None:
            self.after_cancel(self._preview_job)
        self._preview_job = self.after(400, self._refresh_preview_video)

    def _refresh_preview_video(self) -> None:
        self._preview_job = None
        try:
            video = self._input_videos()[0]
        except (OSError, ValueError):
            video = None
        self._update_preview_texts(video)
        self.preview_panel.set_video(video)

    def _update_preview_texts(self, video: Path | None = None) -> None:
        if not hasattr(self, "preview_panel"):
            return
        video = video or self.preview_panel.video
        part = part_label(self.part_text.get().strip(), 1)
        if video is not None:
            part = part.replace("{stem}", video.stem)
            if not part and self.input_folder.get().strip():
                part = video.stem
        try:
            size = int(self.font_size.get())
        except ValueError:
            size = None
        self.preview_panel.set_texts(self.title_text.get().strip(), part, self.watermark_text.get().strip(), size,
                                     subtitle_font=self.subtitle_font.get(), subtitle_bold=self.subtitle_bold.get(),
                                     overlay_font=self.overlay_font.get(), overlay_size=self.overlay_font_size.get(),
                                     style=self._preview_style())

    def _preview_style(self) -> dict | None:
        try:
            style = self._subtitle_style()
            ass_color(style["text_color"]), ass_color(style["outline_color"]), ass_color(style["box_color"])
            return style
        except (ValueError, tk.TclError):
            return None  # half-typed value; keep the last good preview

    SAVED_FIELDS = ("video", "input_folder", "source_srt", "output_dir", "language", "whisper_model",
                    "gemini_model", "env_file", "font_size", "srt_only", "audio_crosscheck", "batch_size",
                    "chunk_minutes", "title_text", "part_text", "watermark_text", "speaker_context",
                    "telegram_send", "telegram_base", "subtitle_font", "subtitle_bold", "overlay_font",
                    "overlay_font_size", "translation_workers", "cues_per_request", "subtitle_color",
                    "outline_color", "outline_width", "shadow", "box_enabled", "box_color", "box_opacity",
                    "output_mode", "part_minutes", "name_memory")

    def _load_ui_settings(self) -> None:
        """Restore the last window settings (never the API key)."""
        if os.environ.get("SUBTITLE_STUDIO_NO_SETTINGS"):
            return
        data = read_json(UI_SETTINGS_FILE, {}) or {}
        for name in self.SAVED_FIELDS:
            if name in data:
                try:
                    getattr(self, name).set(data[name])
                except (tk.TclError, ValueError, TypeError):
                    pass

    def _save_ui_settings(self) -> None:
        if os.environ.get("SUBTITLE_STUDIO_NO_SETTINGS"):
            return
        try:
            data = {name: getattr(self, name).get() for name in self.SAVED_FIELDS}
            UI_SETTINGS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except (OSError, tk.TclError):
            pass

    def _label(self, parent, row: int, title: str) -> None:
        ttk.Label(parent, text=title, style="App.TLabel").grid(row=row, column=0, sticky="w", padx=(0, 12), pady=3)

    def _file_row(self, parent, row: int, title: str, variable: tk.StringVar,
                  action, folder: bool = False) -> None:
        self._label(parent, row, title)
        ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", pady=3)
        ttk.Button(parent, text="Folder..." if folder else "Browse...", command=action, style="App.TButton").grid(row=row, column=2, sticky="w", padx=(8, 0), pady=2)

    def _choose_file(self, variable: tk.StringVar, types) -> None:
        chosen = filedialog.askopenfilename(filetypes=types)
        if chosen:
            variable.set(chosen)

    def _choose_output(self) -> None:
        chosen = filedialog.askdirectory(initialdir=self.output_dir.get() or str(ROOT))
        if chosen:
            self.output_dir.set(chosen)

    def _choose_input_folder(self) -> None:
        chosen = filedialog.askdirectory(initialdir=self.input_folder.get() or str(WORKSPACE))
        if chosen:
            self.input_folder.set(chosen)

    def _input_videos(self) -> list[Path]:
        folder = self.input_folder.get().strip()
        if folder:
            directory = Path(folder)
            if not directory.is_dir():
                raise ValueError("Input folder does not exist")
            # Natural order: ep2 before ep10.
            videos = sorted((p for p in directory.iterdir() if p.is_file() and p.suffix.lower() in VIDEO_SUFFIXES),
                            key=lambda p: [int(t) if t.isdigit() else t.casefold() for t in re.split(r"(\d+)", p.name)])
            if not videos:
                raise ValueError("No videos found directly in the selected folder")
            return videos
        video = Path(self.video.get().strip())
        if not video.is_file():
            raise ValueError("Choose a video or input folder first")
        return [video]

    def _preview(self) -> None:
        try:
            video = self._input_videos()[0]
            PreviewDialog(self, video, LAYOUT_FILE, self.title_text.get(),
                          self.part_text.get(), self.watermark_text.get())
        except Exception as exc:
            messagebox.showerror("Preview error", str(exc))

    def _append_log(self, message: str) -> None:
        self.log_widget.configure(state="normal")
        self.log_widget.insert("end", message + "\n")
        self.log_widget.see("end")
        self.log_widget.configure(state="disabled")

    def _start(self) -> None:
        if self.worker and self.worker.is_alive():
            return
        try:
            videos = self._input_videos()
            if self.input_folder.get().strip() and self.source_srt.get().strip():
                raise ValueError("For folder batches, place a same-name .srt next to each video")
            font_size = int(self.font_size.get())
            bottom_margin = int(self.bottom_margin.get())
            if not 22 <= font_size <= 100 or not 8 <= bottom_margin <= 300:
                raise ValueError("Font size or bottom margin is outside the allowed range")
            batch_size = int(self.batch_size.get())
            if not 1 <= batch_size <= 100:
                raise ValueError("Folder review size must be between 1 and 100")
            translation_workers = int(self.translation_workers.get())
            if not 1 <= translation_workers <= 8:
                raise ValueError("Translate at once must be between 1 and 8")
            cues_per_request = int(self.cues_per_request.get())
            if not 1 <= cues_per_request <= 30:
                raise ValueError("Cues per request must be between 1 and 30")
            split_minutes = self._split_minutes()
            style = self._subtitle_style()
            for key in ("text_color", "outline_color", "box_color"):
                ass_color(style[key])
            if not -1 <= style["outline_width"] <= 12 or not 0 <= style["shadow"] <= 10:
                raise ValueError("Stroke must be Auto or 0-12 px and shadow 0-10")
            chunk_minutes = int(self.chunk_minutes.get())
            if not 1 <= chunk_minutes <= 60:
                raise ValueError("Work chunk length must be between 1 and 60 minutes")
            layout = Layout.load(LAYOUT_FILE)
            env_file = Path(self.env_file.get().strip()) if self.env_file.get().strip() else None
            if self.telegram_send.get() and self.srt_only.get():
                raise ValueError("Telegram send needs a rendered MP4; turn off SRT only")
            telegram_config = settings(env_file, self.telegram_chat.get(), self.telegram_topic.get(),
                                       self.telegram_base.get()) if self.telegram_send.get() else None
            jobs = []
            for video in videos:
                matched = video.with_suffix(".srt")
                source_srt = (Path(self.source_srt.get().strip()) if self.source_srt.get().strip()
                              else matched if matched.is_file() else None)
                part_text = self.part_text.get().strip().replace("{stem}", video.stem)
                if not part_text and self.input_folder.get().strip():
                    part_text = video.stem
                jobs.append(Options(
                    video=video, output_dir=Path(self.output_dir.get().strip()), source_srt=source_srt,
                    source_language=LANGUAGES[self.language.get()], whisper_model=self.whisper_model.get().strip(),
                    gemini_model=self.gemini_model.get().strip(), api_key=self.api_key.get(), env_file=env_file,
                    font_size=font_size, bottom_margin=bottom_margin, srt_only=self.srt_only.get(),
                    layout=layout, title=self.title_text.get().strip(), part=part_text,
                    watermark=self.watermark_text.get().strip(),
                    speaker_context=self.speaker_context.get().strip(),
                    audio_crosscheck=self.audio_crosscheck.get(), chunk_minutes=chunk_minutes,
                    subtitle_font=self.subtitle_font.get() or "Myanmar Text", subtitle_bold=self.subtitle_bold.get(),
                    overlay_font=self.overlay_font.get() or "Myanmar Text",
                    overlay_font_size=int(self.overlay_font_size.get()),
                    translation_workers=translation_workers, cues_per_request=cues_per_request,
                    subtitle_color=style["text_color"], outline_color=style["outline_color"],
                    outline_width=style["outline_width"], shadow=style["shadow"],
                    box_enabled=style["box_enabled"], box_color=style["box_color"],
                    box_opacity=style["box_opacity"], split_minutes=split_minutes,
                    name_memory=self.name_memory.get()))
        except (OSError, ValueError, KeyError) as exc:
            messagebox.showerror("Input error", str(exc))
            return
        self._save_ui_settings()
        self._begin(jobs, telegram_config, batch_size,
                    folder_review=bool(self.input_folder.get().strip() and not self.srt_only.get()))

    def _resume(self) -> None:
        if self.worker and self.worker.is_alive():
            return
        chosen = filedialog.askdirectory(initialdir=self.output_dir.get() or str(ROOT / "outputs"),
                                         title="Resume: choose the output job folder")
        if not chosen:
            return
        try:
            # Speed settings come from the window, so an old job can resume with batching.
            options = replace(load_job(Path(chosen)), api_key=self.api_key.get(),
                              translation_workers=max(1, min(8, int(self.translation_workers.get() or 4))),
                              cues_per_request=max(1, min(30, int(self.cues_per_request.get() or 30))),
                              split_minutes=self._split_minutes(), name_memory=self.name_memory.get())
            telegram_config = settings(options.env_file, self.telegram_chat.get(), self.telegram_topic.get(),
                                       self.telegram_base.get()) if self.telegram_send.get() else None
            if telegram_config and options.srt_only:
                raise ValueError("This saved job is SRT-only. Turn off Telegram delivery before resuming.")
        except (OSError, ValueError, KeyError, TypeError) as exc:
            messagebox.showerror("Resume error", str(exc))
            return
        self._append_log(f"Resuming saved job: {options.video.name}")
        progress = read_json(Path(chosen) / "progress.json", {})
        if progress.get("stage"):
            self._append_log(f"Last saved stage: {progress['stage']}")
        saved = read_json(Path(chosen) / "prepared_result.json")
        self._begin([options], telegram_config, 1, folder_review=False,
                    prepared=[(options, saved)] if saved else None)

    def _begin(self, jobs, telegram_config, batch_size, folder_review, prepared=None) -> None:
        self.last_result = None
        self.current_job = None
        self.completed_total = self.errors_total = 0
        self.cancel_event = threading.Event()
        self.percent.set(0)
        self.status.set("Starting...")
        self.start_button.configure(state="disabled")
        self.resume_button.configure(state="disabled")
        self.review_button.configure(state="disabled")
        self.cancel_button.configure(state="normal")
        self.open_button.configure(state="disabled")
        self._append_log(f"Queued {len(jobs)} video(s)")
        self.telegram_config = telegram_config
        self.batch_limit = batch_size
        self.pending_jobs = jobs if folder_review else []
        if self.pending_jobs:
            self._next_batch()
        else:
            self._run_jobs(jobs, preparing=False, prepared=prepared)

    def _next_batch(self) -> None:
        jobs = self.pending_jobs[:self.batch_limit]
        del self.pending_jobs[:self.batch_limit]
        if jobs:
            self._append_log(f"Preparing {len(jobs)} video(s) for one review")
            self._run_jobs(jobs, preparing=True)

    def _run_jobs(self, jobs: list[Options], preparing: bool, prepared: list | None = None) -> None:
        def worker() -> None:
            try:
                completed, errors = [], []
                for index, options in enumerate(jobs, 1):
                    if self.cancel_event.is_set():
                        break
                    self.events.put(("log", f"[{index}/{len(jobs)}] {options.video.name}"))
                    try:
                        from membership_access import require_vip
                        require_vip("Subtitle")
                        callbacks = dict(log=lambda msg: self.events.put(("log", msg)),
                                         progress=lambda pct, msg: self.events.put(("progress", pct, f"{index}/{len(jobs)} · {msg}")),
                                         cancel=self.cancel_event)
                        result = (render_prepared(options, prepared[index - 1][1], **callbacks) if prepared
                                  else run(options, prepare_only=preparing, **callbacks))
                        completed.append((options, result) if preparing else result)
                        parts = [] if preparing else result.get("parts") or []
                        videos = parts or ([result["video"]] if not preparing and result.get("video") else [])
                        for number, path in enumerate(videos, 1):
                            if not self.telegram_config or self.cancel_event.is_set():
                                break
                            label = part_label(options.part, number) or (f"Part {number}" if parts else "")
                            caption = " · ".join(x for x in (options.title or options.video.stem, label,
                                                             "Myanmar subtitles") if x)
                            send_video(Path(path), self.telegram_config, caption,
                                       log=lambda msg: self.events.put(("log", msg)))
                    except InterruptedError:
                        self.cancel_event.set()
                        break
                    except Exception as exc:
                        errors.append(f"{options.video.name}: {exc}")
                        self.events.put(("log", "ERROR: " + errors[-1]))
                self.events.put(("prepared" if preparing else "done", completed, errors))
            except Exception as exc:
                self.events.put(("error", str(exc)))

        self.worker = threading.Thread(target=worker, daemon=True)
        self.worker.start()

    def _cancel(self) -> None:
        self.cancel_event.set()
        self.status.set("Pausing; finished checkpoints are saved...")
        self.cancel_button.configure(state="disabled")

    def _on_close(self) -> None:
        if self.worker and self.worker.is_alive():
            self._cancel()
            self.after(250, self._on_close)
            return
        self._save_ui_settings()
        self.destroy()

    def _open_output(self) -> None:
        result = self.last_result or {}
        if result.get("parts"):
            os.startfile(Path(result["parts"][0]).parent)
        elif result.get("job_dir"):
            os.startfile(result["job_dir"])
        elif self.current_job and self.current_job.is_dir():
            # While a job runs (parts appear one by one), open its folder.
            os.startfile(self.current_job)

    def _review(self) -> None:
        if self.last_result:
            job = Path(self.last_result["job_dir"])
        else:
            chosen = filedialog.askdirectory(initialdir=self.output_dir.get() or str(ROOT / "outputs"),
                                             title="Choose a subtitle output job")
            if not chosen:
                return
            job = Path(chosen)
        if not (job / "translated_cues.json").is_file():
            messagebox.showerror("Review", "This folder has no translated_cues.json")
            return
        ReviewDialog(self, job)

    def _drain_events(self) -> None:
        try:
            while True:
                event = self.events.get_nowait()
                if event[0] == "log":
                    self._append_log(event[1])
                    if event[1].startswith("Resume folder: "):
                        self.current_job = Path(event[1][len("Resume folder: "):])
                        self.open_button.configure(state="normal")
                elif event[0] == "fonts":
                    for combo in (self.subtitle_font_box, self.overlay_font_box):
                        combo.configure(values=event[1])
                elif event[0] == "progress":
                    self.percent.set(event[1])
                    self.status.set(event[2])
                elif event[0] == "prepared":
                    prepared, errors = event[1], event[2]
                    self.errors_total += len(errors)
                    self.last_result = prepared[-1][1] if prepared else None
                    self.cancel_button.configure(state="disabled")
                    self.open_button.configure(state="normal" if prepared else "disabled")
                    self._append_log(f"Prepared {len(prepared)} video(s) for review; errors {len(errors)}")
                    if errors:
                        messagebox.showerror("Subtitle preparation errors", "\n".join(errors[:8]))
                    if prepared and not self.cancel_event.is_set():
                        self.status.set(f"Review {len(prepared)} video(s), then Save & Render All")
                        options = [item[0] for item in prepared]

                        def render_batch() -> None:
                            self.cancel_button.configure(state="normal")
                            self.status.set(f"Rendering {len(options)} reviewed video(s)...")
                            self._run_jobs(options, preparing=False, prepared=prepared)

                        def keep_prepared() -> None:
                            self.start_button.configure(state="normal")
                            self.resume_button.configure(state="normal")
                            self.review_button.configure(state="normal")
                            self.status.set("Review edits saved; restart folder to resume this batch")

                        dialog = BatchReviewDialog(self, prepared, render_batch, keep_prepared)
                        dialog.grab_set()
                    elif self.pending_jobs and not self.cancel_event.is_set():
                        self._next_batch()
                    else:
                        self.start_button.configure(state="normal")
                        self.resume_button.configure(state="normal")
                        self.review_button.configure(state="normal")
                        self.status.set("Prepared subtitles saved; rendering not started")
                elif event[0] == "done":
                    completed, errors = event[1], event[2]
                    self.completed_total += len(completed)
                    self.errors_total += len(errors)
                    if completed:
                        self.last_result = completed[-1]
                    self._append_log(f"Completed {len(completed)} video(s); errors {len(errors)}")
                    self.open_button.configure(state="normal" if self.last_result else "disabled")
                    if errors:
                        messagebox.showerror("Subtitle batch errors", "\n".join(errors[:8]))
                    if self.pending_jobs and not self.cancel_event.is_set():
                        self._next_batch()
                    else:
                        state = "Stopped" if self.cancel_event.is_set() else "Done"
                        self.status.set(f"{state}: {self.completed_total} output(s), {self.errors_total} errors")
                        self.start_button.configure(state="normal")
                        self.resume_button.configure(state="normal")
                        self.review_button.configure(state="normal")
                        self.cancel_button.configure(state="disabled")
                elif event[0] == "error":
                    self._append_log("ERROR: " + event[1])
                    self.status.set("Stopped" if self.cancel_event.is_set() else "Failed")
                    self.start_button.configure(state="normal")
                    self.resume_button.configure(state="normal")
                    self.review_button.configure(state="normal")
                    self.cancel_button.configure(state="disabled")
                    messagebox.showerror("Subtitle job failed", event[1])
        except queue.Empty:
            pass
        self.after(100, self._drain_events)


if __name__ == "__main__":
    SubtitleApp().mainloop()
