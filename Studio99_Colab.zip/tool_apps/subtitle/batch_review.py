"""One review window for a prepared folder batch."""

from __future__ import annotations

import json
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

from core import Cue, cue_identity, validate_myanmar_text


def save_reviews(jobs: list[dict]) -> int:
    """Persist all edits before any render begins."""
    for entry in jobs:
        for row in entry["data"]["cues"]:
            validate_myanmar_text(row["text"])
    total = 0
    for entry in jobs:
        job = Path(entry["job_dir"])
        data = entry["data"]
        rows = data["cues"]
        changed = [i for i, row in enumerate(rows) if row["text"] != entry["original"][i]]
        if not changed:
            continue
        review_path = job / "manual_review.json"
        review = json.loads(review_path.read_text(encoding="utf-8")) if review_path.is_file() else {"version": 1, "items": {}}
        items = review.setdefault("items", {})
        for index in changed:
            row = rows[index]
            validate_myanmar_text(row["text"])
            items[cue_identity(Cue(row["start"], row["end"], row["source"]))] = row["text"]
        for path, value in ((review_path, review), (job / "translated_cues.json", data)):
            temporary = path.with_name(path.name + ".tmp")
            temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
            temporary.replace(path)
        entry["original"] = [row["text"] for row in rows]
        total += len(changed)
    return total


class BatchReviewDialog(tk.Toplevel):
    def __init__(self, parent, prepared: list[tuple], on_render, on_close=None) -> None:
        super().__init__(parent)
        self.on_render = on_render
        self.on_close = on_close
        self.jobs = []
        for options, result in prepared:
            job = Path(result["job_dir"])
            data = json.loads((job / "translated_cues.json").read_text(encoding="utf-8"))
            # Show the evidence used for these translations, never a stale audio cache.
            audio = data.get("audio_hints") or []
            self.jobs.append({"options": options, "job_dir": job, "data": data,
                              "original": [row["text"] for row in data["cues"]],
                              "audio": audio})
        self.current_job = -1
        self.current_cue = -1
        self.title(f"Review batch · {len(self.jobs)} videos")
        self.geometry("1240x750")
        self.minsize(900, 560)
        self.transient(parent)
        self.protocol("WM_DELETE_WINDOW", self._close)
        self._build()
        if self.jobs:
            self._select_job(0)

    def _build(self) -> None:
        outer = ttk.Frame(self, padding=12)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="စာတန်းအားလုံးကို ဒီမှာတစ်ခါတည်း ပြင်ပါ။ ⚠ = Gemini/Whisper ကွာခြားမှု သို့မဟုတ် speaker မသေချာမှု။",
                  font=("Myanmar Text", 10)).pack(anchor="w", pady=(0, 8))
        middle = ttk.Frame(outer)
        middle.pack(fill="both", expand=True)
        files = ttk.Frame(middle)
        files.pack(side="left", fill="y")
        ttk.Label(files, text="Videos").pack(anchor="w")
        self.file_list = tk.Listbox(files, width=27, exportselection=False, font=("Myanmar Text", 10))
        self.file_list.pack(fill="y", expand=True)
        for entry in self.jobs:
            flagged = sum(bool(row.get("needs_review")) for row in entry["audio"])
            self.file_list.insert("end", f"{entry['options'].video.name}  ⚠{flagged}" if flagged else entry["options"].video.name)
        self.file_list.bind("<<ListboxSelect>>", self._file_changed)
        cues_box = ttk.Frame(middle, padding=(10, 0, 0, 0))
        cues_box.pack(side="left", fill="both", expand=True)
        ttk.Label(cues_box, text="Subtitle cues").pack(anchor="w")
        self.cue_list = tk.Listbox(cues_box, width=46, exportselection=False, font=("Myanmar Text", 10))
        self.cue_list.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(cues_box, command=self.cue_list.yview)
        scroll.pack(side="right", fill="y")
        self.cue_list.configure(yscrollcommand=scroll.set)
        self.cue_list.bind("<<ListboxSelect>>", self._cue_changed)
        editor = ttk.Frame(middle, padding=(12, 0, 0, 0))
        editor.pack(side="left", fill="both", expand=True)
        self.time_label = ttk.Label(editor, text="", font=("Myanmar Text", 11, "bold"))
        self.time_label.pack(anchor="w")
        ttk.Label(editor, text="Whisper source / မူရင်း", font=("Myanmar Text", 10)).pack(anchor="w", pady=(9, 2))
        self.source = tk.Text(editor, height=4, wrap="word", font=("Segoe UI", 11))
        self.source.pack(fill="x")
        self.source.configure(state="disabled")
        ttk.Label(editor, text="Gemini audio transcript / speaker", font=("Myanmar Text", 10)).pack(anchor="w", pady=(9, 2))
        self.audio = tk.Text(editor, height=4, wrap="word", font=("Segoe UI", 11))
        self.audio.pack(fill="x")
        self.audio.configure(state="disabled")
        ttk.Label(editor, text="Myanmar / ပြင်မယ့်စာ", font=("Myanmar Text", 10)).pack(anchor="w", pady=(9, 2))
        self.translation = tk.Text(editor, height=6, wrap="word", font=("Myanmar Text", 14))
        self.translation.pack(fill="both", expand=True)
        ttk.Label(editor, text="Timing ကို Whisper/SRT မှ ထားထားသည်။ Voice gender သည် ခန့်မှန်းချက်သာဖြစ်သည်။",
                  font=("Myanmar Text", 9)).pack(anchor="w", pady=8)
        buttons = ttk.Frame(outer)
        buttons.pack(fill="x", pady=(10, 0))
        ttk.Button(buttons, text="Save all edits", command=self._save).pack(side="left")
        ttk.Button(buttons, text="Save & Render All", command=self._render).pack(side="left", padx=10)
        ttk.Button(buttons, text="Keep prepared / Close", command=self._close).pack(side="right")

    def _commit(self) -> bool:
        if self.current_job < 0 or self.current_cue < 0:
            return True
        value = " ".join(self.translation.get("1.0", "end-1c").split())
        try:
            validate_myanmar_text(value)
        except ValueError as exc:
            messagebox.showerror("Invalid Myanmar text", str(exc), parent=self)
            return False
        self.jobs[self.current_job]["data"]["cues"][self.current_cue]["text"] = value
        self._refresh_cue(self.current_cue)
        return True

    def _refresh_cue(self, index: int) -> None:
        entry = self.jobs[self.current_job]
        row = entry["data"]["cues"][index]
        audio = entry["audio"]
        flag = "⚠ " if index < len(audio) and audio[index].get("needs_review") else ""
        self.cue_list.delete(index)
        self.cue_list.insert(index, f"{flag}{index + 1:02d}  {row['start']:.1f}s  {row['text'][:50]}")

    def _file_changed(self, _event) -> None:
        selected = self.file_list.curselection()
        if selected:
            self._select_job(selected[0])

    def _select_job(self, index: int) -> None:
        if index == self.current_job:
            return
        if not self._commit():
            self.file_list.selection_clear(0, "end")
            self.file_list.selection_set(self.current_job)
            return
        self.current_job = index
        self.current_cue = -1
        self.file_list.selection_clear(0, "end")
        self.file_list.selection_set(index)
        self.cue_list.delete(0, "end")
        for cue in range(len(self.jobs[index]["data"]["cues"])):
            self._refresh_cue(cue)
        if self.cue_list.size():
            self._select_cue(0)

    def _cue_changed(self, _event) -> None:
        selected = self.cue_list.curselection()
        if selected:
            self._select_cue(selected[0])

    def _select_cue(self, index: int) -> None:
        if index == self.current_cue:
            return
        if not self._commit():
            self.cue_list.selection_clear(0, "end")
            self.cue_list.selection_set(self.current_cue)
            return
        self.current_cue = index
        self.cue_list.selection_clear(0, "end")
        self.cue_list.selection_set(index)
        self.cue_list.see(index)
        entry = self.jobs[self.current_job]
        row = entry["data"]["cues"][index]
        audio = entry["audio"][index] if index < len(entry["audio"]) else {}
        self.time_label.configure(text=f"Cue {index + 1}/{len(entry['data']['cues'])} · {row['start']:.2f}–{row['end']:.2f}s")
        self._set_readonly(self.source, row["source"])
        self._set_readonly(self.audio, (f"{audio.get('gemini') or '(audio check unavailable)'}\n"
                                        f"Speaker: {audio.get('speaker_id') or '?'}; perceived voice: {audio.get('voice_gender') or 'unknown'}\n"
                                        f"Used for translation: {'yes' if audio.get('use_for_translation') else 'no'}"))
        self.translation.delete("1.0", "end")
        self.translation.insert("1.0", row["text"])

    @staticmethod
    def _set_readonly(widget, value: str) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", value)
        widget.configure(state="disabled")

    def _save(self) -> None:
        if not self._commit():
            return
        try:
            count = save_reviews(self.jobs)
        except (OSError, ValueError) as exc:
            messagebox.showerror("Save failed", str(exc), parent=self)
            return
        messagebox.showinfo("Saved", f"Saved {count} edited cue(s) across {len(self.jobs)} videos.", parent=self)

    def _render(self) -> None:
        if not self._commit():
            return
        try:
            save_reviews(self.jobs)
        except (OSError, ValueError) as exc:
            messagebox.showerror("Save failed", str(exc), parent=self)
            return
        self.destroy()
        self.on_render()

    def _close(self) -> None:
        if not self._commit():
            return
        try:
            save_reviews(self.jobs)
        except (OSError, ValueError) as exc:
            messagebox.showerror("Save failed", str(exc), parent=self)
            return
        self.destroy()
        if self.on_close:
            self.on_close()
