from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import threading
import time
import unicodedata
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Callable

from layout import Layout
from checkpoints import read_json, save_job, write_json


Log = Callable[[str], None]
Progress = Callable[[int, str], None]
CUE_PROFILE = "sentence_anchored_v2"
TRANSLATION_PROFILE = "contextual_audio_gender_v4"


@dataclass
class Cue:
    start: float
    end: float
    source: str
    text: str = ""


@dataclass
class Options:
    video: Path
    output_dir: Path
    source_srt: Path | None = None
    source_language: str = "auto"
    whisper_model: str = "medium"
    gemini_model: str = "gemini-3.5-flash"
    api_key: str = ""
    env_file: Path | None = None
    font_size: int = 48
    bottom_margin: int = 64
    srt_only: bool = False
    layout: Layout | None = None
    title: str = ""
    part: str = ""
    watermark: str = ""
    speaker_context: str = ""
    audio_crosscheck: bool = False
    chunk_minutes: float = 15
    # Requests sent at the same time.
    translation_workers: int = 4
    # Neighbouring cues per Gemini request (1 = one cue per request). Free-tier quotas count
    # requests, so 10 per request makes ~10x fewer requests for the same video.
    cues_per_request: int = 1
    # Fonts (family names as installed). overlay_font_size 0 = fit the Title/Watermark box.
    subtitle_font: str = "Myanmar Text"
    subtitle_bold: bool = False
    overlay_font: str = "Myanmar Text"
    overlay_font_size: int = 0
    # Subtitle look. outline_width -1 = auto (7.5% of the font size); box = the panel behind the text.
    subtitle_color: str = "#FFFFFF"
    outline_color: str = "#252525"
    outline_width: int = -1
    shadow: int = 0
    box_enabled: bool = True
    box_color: str = "#383838"
    box_opacity: int = 62
    # Video output: 0 = one full video; N = N-minute parts in <job>\parts_<N>min, each rendered
    # as soon as all of its cues are translated (export_parts.py).
    split_minutes: float = 0
    # One Burmese spelling per name for the whole video (<job>/NAME_GLOSSARY.json, names.py).
    name_memory: bool = True


MYANMAR_DIGITS = str.maketrans("0123456789", "၀၁၂၃၄၅၆၇၈၉")


def part_label(text: str, number: int) -> str:
    """Part text with {n} = 1, 2, 3 and {mm} = ၁, ၂, ၃ filled in."""
    return (text or "").replace("{n}", str(number)).replace("{mm}", str(number).translate(MYANMAR_DIGITS))


def _split_minutes(options) -> float:
    return max(0.0, float(getattr(options, "split_minutes", 0) or 0))


def _clean_text(value: str) -> str:
    return " ".join(str(value or "").replace("\r", " ").replace("\n", " ").split()).strip()


def cue_identity(cue: Cue) -> str:
    return hashlib.sha256(
        f"{cue.start:.3f}|{cue.end:.3f}|{cue.source}".encode("utf-8")
    ).hexdigest()


def _srt_time(value: str) -> float:
    m = re.fullmatch(r"(\d+):(\d\d):(\d\d)[,.](\d{1,3})", value.strip())
    if not m:
        raise ValueError(f"Invalid SRT timestamp: {value}")
    hours, minutes, seconds, millis = m.groups()
    return int(hours) * 3600 + int(minutes) * 60 + int(seconds) + int(millis.ljust(3, "0")) / 1000


def parse_srt(path: Path) -> list[Cue]:
    raw = path.read_text(encoding="utf-8-sig")
    cues: list[Cue] = []
    for block in re.split(r"\n\s*\n", raw.replace("\r\n", "\n").strip()):
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        timing = next((i for i, line in enumerate(lines) if "-->" in line), None)
        if timing is None:
            continue
        start_text, end_text = [x.strip().split()[0] for x in lines[timing].split("-->", 1)]
        start, end = _srt_time(start_text), _srt_time(end_text)
        text = _clean_text(" ".join(re.sub(r"<[^>]+>", "", x) for x in lines[timing + 1:]))
        if text and end > start:
            cues.append(Cue(start, end, text))
    if not cues:
        raise ValueError("No valid subtitle cues found in SRT file")
    return sorted(cues, key=lambda x: x.start)


def cues_from_whisper_segments(segments: list[dict], *, max_words: int = 18,
                               max_seconds: float = 6.5, pause_seconds: float = 0.85) -> list[Cue]:
    """Make complete spoken clauses before translation; keep source word timing."""
    words: list[dict] = []
    fallback: list[Cue] = []
    for segment in segments:
        timed = segment.get("words") or []
        if timed:
            for word in timed:
                token = str(word.get("word") or "")
                start, end = float(word["start"]), float(word["end"])
                if token.strip() and end > start:
                    words.append({"word": token, "start": start, "end": end})
        elif _clean_text(segment.get("text") or ""):
            start, end = float(segment["start"]), float(segment["end"])
            if end > start:
                fallback.append(Cue(start, end, _clean_text(segment["text"])))

    words.sort(key=lambda row: row["start"])
    result: list[Cue] = []
    group: list[dict] = []

    def flush() -> None:
        if not group:
            return
        # Whisper's leading spaces preserve English words; CJK tokens remain joined.
        raw = "".join(str(w["word"]) for w in group)
        text = _clean_text(raw)
        if text:
            result.append(Cue(float(group[0]["start"]), float(group[-1]["end"]), text))
        group.clear()

    for word in words:
        if group and float(word["start"]) - float(group[-1]["end"]) >= pause_seconds:
            flush()
        if group and (len(group) >= max_words or float(word["end"]) - float(group[0]["start"]) > max_seconds):
            flush()
        group.append(word)
        token = str(word["word"]).rstrip()
        duration = float(group[-1]["end"]) - float(group[0]["start"])
        if re.search(r"[.!?။！？][\"'’”)]?$", token) and duration >= .55:
            flush()
        elif re.search(r"[,;:၊][\"'’”)]?$", token) and duration >= 3.0 and len(group) >= 5:
            flush()
    flush()
    result.extend(fallback)
    result.sort(key=lambda cue: cue.start)
    if not result:
        raise RuntimeError("No spoken words were found in the video")
    return result


def _check_cancel(cancel: threading.Event | None) -> None:
    if cancel and cancel.is_set():
        raise InterruptedError("Cancelled by user")


def transcribe_video(video: Path, model_name: str, language: str, log: Log,
                     cancel: threading.Event | None = None) -> tuple[list[Cue], str]:
    rows, detected = transcribe_segments(video, model_name, language, log, cancel)
    return cues_from_whisper_segments(rows), detected


def transcribe_segments(video: Path, model_name: str, language: str, log: Log,
                        cancel: threading.Event | None = None, *, model_cache=None) -> tuple[list[dict], str]:
    from faster_whisper import WhisperModel

    _check_cancel(cancel)
    model_cache = model_cache if model_cache is not None else {}
    model, gpu = model_cache.get("model"), model_cache.get("gpu", True)
    if model is None:
        try:
            model = WhisperModel(model_name, device="cuda", compute_type="float16")
            log(f"Whisper {model_name}: GPU")
        except Exception as exc:
            log(f"GPU unavailable ({str(exc)[:120]}); using CPU/int8")
            gpu = False
            model = WhisperModel(model_name, device="cpu", compute_type="int8")
        model_cache.update(model=model, gpu=gpu)

    def collect(current_model):
        _check_cancel(cancel)
        segments, info = current_model.transcribe(
            str(video), language=None if language == "auto" else language,
            vad_filter=True, beam_size=5, word_timestamps=True,
        )
        rows = []
        for segment in segments:
            _check_cancel(cancel)
            rows.append({
                "start": float(segment.start), "end": float(segment.end),
                "text": str(segment.text or ""),
                "words": [
                    {"start": float(w.start), "end": float(w.end), "word": str(w.word or "")}
                    for w in (segment.words or [])
                ],
            })
            if len(rows) % 20 == 0:
                log(f"Transcribed {segment.end / 60:.1f} min / {len(rows)} segments")
        return rows, str(info.language or language)

    try:
        return collect(model)
    except RuntimeError as exc:
        # CUDA libraries can fail only when the lazy segment iterator is consumed.
        if not gpu or not any(word in str(exc).lower() for word in ("cuda", "cublas", "cudnn", "gpu")):
            raise
        _check_cancel(cancel)
        log(f"GPU transcription failed ({str(exc)[:120]}); retrying on CPU/int8")
        del model
        model = WhisperModel(model_name, device="cpu", compute_type="int8")
        model_cache.update(model=model, gpu=False)
        return collect(model)


def _read_api_key(options: Options) -> str:
    if options.api_key.strip():
        return options.api_key.strip()
    if os.getenv("GEMINI_API_KEY", "").strip():
        return os.environ["GEMINI_API_KEY"].strip()
    if options.env_file and options.env_file.is_file():
        from dotenv import dotenv_values
        values = dotenv_values(options.env_file)
        # The existing workspace keeps its working text-capable key in project 15.
        # This is only consulted when the user explicitly selects that .env file.
        for name in ("GEMINI_API_KEY", "GEMINI_IMAGE_PROJECT_15_KEY"):
            if str(values.get(name) or "").strip():
                return str(values[name]).strip()
    raise RuntimeError("Gemini API key missing. Enter one in the UI or select a .env file.")


def validate_myanmar_text(value: str) -> None:
    if not any("\u1000" <= ch <= "\u109f" for ch in value):
        raise ValueError("Translation contains no Myanmar characters")
    if "\ufffd" in value:
        raise ValueError("Translation contains a replacement character")
    for ch in value:
        code = ord(ch)
        if unicodedata.category(ch) == "Cc" and ch not in "\n\r\t":
            raise ValueError(f"Translation contains a control character: U+{code:04X}")
        if 0x202A <= code <= 0x202E or 0x2066 <= code <= 0x2069:
            raise ValueError("Translation contains a directional control character")
        if code < 128 or 0x1000 <= code <= 0x109F or 0xA9E0 <= code <= 0xA9FF:
            continue
        if ch.isalpha() or ch.isdigit() or unicodedata.category(ch).startswith("M"):
            raise ValueError(f"Translation contains a non-Myanmar script character: U+{code:04X}")


def strip_foreign_letters(value: str) -> tuple[str, str]:
    """(text without letters of other scripts, the letters removed): a stray Thai/Korean letter or a
    Chinese name copied in brackets, which flash-lite writes into a line now and then."""
    kept, removed = [], []
    for ch in value:
        code = ord(ch)
        foreign = (code >= 128 and not (0x1000 <= code <= 0x109F or 0xA9E0 <= code <= 0xA9FF)
                   and (ch.isalpha() or ch.isdigit() or unicodedata.category(ch).startswith("M")))
        (removed if foreign else kept).append(ch)
    text = re.sub(r"[(\[（【]\s*[)\]）】]", "", "".join(kept))  # brackets that held the copied name
    return _clean_text(text), "".join(removed)


class BatchMismatch(ValueError):
    """A multi-cue reply that did not map one-to-one onto the IDs; the batch is split in halves."""


class PartialBatch(Exception):
    """Every ID came back, but some lines failed the Myanmar check (lite slips in a Thai/Korean letter
    about once in 30-60 lines): the good lines are kept and only the bad ones are asked again."""

    def __init__(self, good: dict[int, str], bad: list[int]) -> None:
        super().__init__(f"{len(bad)} line(s) not in Myanmar letters")
        self.good, self.bad = good, bad


def _translate_batch(client, model: str, batch: list[Cue], source_language: str,
                     context_before: list[str] | None = None,
                     context_after: list[str] | None = None,
                     speaker_context: str = "", cue_number: int = 0,
                     audio_hint: dict | None = None,
                     audio_rows: list[dict] | None = None,
                     names: list[dict] | None = None,
                     repaired: list[str] | None = None) -> list[str]:
    from google.genai import types

    rows = [{"id": i, "start_seconds": cue.start, "end_seconds": cue.end,
             "source": cue.source} for i, cue in enumerate(batch)]
    for row, hint in zip(rows, audio_rows or []):
        if hint:
            row["audio_check"] = hint
    if len(batch) == 1:
        scope = ("Translate ONLY the supplied source subtitle into natural spoken Burmese (Myanmar). "
                 "It is one exact spoken time window. Do not translate the next or previous sentence, ")
    else:
        # Whisper cuts sentences by sound, so one sentence often spans two IDs. Burmese word
        # order would pull words into the earlier ID and show them before they are spoken.
        scope = ("Translate EACH target row separately into natural spoken Burmese (Myanmar). "
                 "Each ID is its own exact spoken time window and must contain ONLY the meaning of that "
                 "ID's own source words. When one sentence continues across IDs, translate each piece in "
                 "its own ID even if the Burmese then reads as a fragment; never pull words forward or back "
                 "between IDs to make a smoother sentence, and never leave an ID empty. Do not translate "
                 "the next or previous sentence, ")
    prompt = (
        scope +
        "invent missing dialogue, summarize, omit, merge, or move meaning to another time window. "
        "For a sentence fragment, translate only that fragment without completing the sentence. "
        "Use surrounding source lines only to identify the speaker and meaning, never translate them in the target. "
        "Keep the speaker's gender, person, and tone consistent. If gender is uncertain, prefer gender-neutral Burmese wording. "
        "An audio transcript is provided when available; use it to correct obvious Whisper mishearing within this same time window. "
        "Perceived voice gender is only a weak clue; never invent a character's gender from it alone. "
        + ("names gives the fixed Burmese spelling of names in this video; other_forms are the same name as "
           "speech recognition also wrote it. When a target row uses one of them as that name, write exactly "
           "its mm, in Myanmar letters only: never copy the source characters (such as 万字真言) into the "
           "subtitle, not even in brackets. If a form is used there as an ordinary word (for example 男子 "
           "meaning 'a man'), translate the word instead. A listed person's gender decides pronouns and "
           "kinship words. Never add a name the row does not say. " if names else "") +
        "Use valid Myanmar Unicode only; never mix in Gujarati, Khmer, Thai, or other scripts. "
        "Return only a JSON object {\"translations\":[{\"id\":0,\"mm\":\"...\"}]} "
        "with exactly the supplied IDs and no timestamps. Keep each line concise and readable. "
        f"Source language: {source_language}.\n"
        + json.dumps({"speaker_notes": speaker_context, **({"names": names} if names else {}),
                      "audio_check": audio_hint or {},
                      "target_cue_number": cue_number,
                      "context_before": context_before or [], "target": rows,
                      "context_after": context_after or []}, ensure_ascii=False)
    )
    response = client.models.generate_content(
        model=model, contents=prompt,
        config=types.GenerateContentConfig(response_mime_type="application/json", temperature=0.2),
    )
    raw = str(getattr(response, "text", "") or "").strip()
    data = json.loads(raw)
    items = data.get("translations") if isinstance(data, dict) else data if isinstance(data, list) else None
    if len(batch) == 1:
        if isinstance(items, dict):
            items = [{"id": 0, "mm": items.get("0") or items.get("mm") or items.get("translation")}]
        elif isinstance(items, list) and len(items) == 1 and isinstance(items[0], str):
            items = [{"id": 0, "mm": items[0]}]
        elif not isinstance(items, list) and isinstance(data, dict):
            single = data.get("mm") or data.get("translation") or data.get("text")
            if single:
                items = [{"id": 0, "mm": single}]
    mismatch = BatchMismatch if len(batch) > 1 else ValueError
    if not isinstance(items, list) or len(items) != len(batch):
        raise mismatch(f"Translation count mismatch: expected {len(batch)}")
    translated: dict[int, str] = {}
    for item in items:
        if not isinstance(item, dict):
            raise ValueError("Translation item is not a JSON object")
        index = int(item["id"])
        value = _clean_text(item.get("mm") or "")
        if index in translated or not value:
            raise mismatch("Duplicate ID or empty Myanmar translation")
        if len(batch) == 1:
            try:
                validate_myanmar_text(value)
            except ValueError:
                # Lite can write the same stray letter into one line on every try (lines 1565/1665 of
                # the 5-hour job), which used to stop the whole run: a few such letters are dropped.
                fixed, removed = strip_foreign_letters(value)
                if not removed or len(removed) > 6 or len(removed) > 0.3 * len(value):
                    raise
                validate_myanmar_text(fixed)
                if repaired is not None:
                    repaired.append(removed)
                value = fixed
        translated[index] = value
    if set(translated) != set(range(len(batch))):
        raise mismatch("Translation IDs do not match source cues")
    bad = []
    for index, value in translated.items():
        try:
            validate_myanmar_text(value)
        except ValueError:
            bad.append(index)
    if bad:
        raise PartialBatch({i: v for i, v in translated.items() if i not in bad}, sorted(bad))
    return [translated[i] for i in range(len(batch))]


def translation_identity(cues: list[Cue], index: int, speaker_context: str,
                         audio_hints: list[dict]) -> str:
    """Checkpoint key of one cue's translation (chunks/translations/<key>.json); export_parts reads it too."""
    cue = cues[index]
    return hashlib.sha256(
            f"{cue.start:.3f}|{cue.end:.3f}|{cue.source}|{speaker_context}|"
            f"{audio_hints[index] if index < len(audio_hints) else {}}|"
            f"{[c.source for c in cues[max(0, index - 4):index]]}|"
            f"{[c.source for c in cues[index + 1:index + 4]]}".encode("utf-8")
    ).hexdigest()


def translate_cues(cues: list[Cue], options: Options, source_language: str,
                   log: Log, progress: Progress, cancel: threading.Event | None = None,
                   checkpoint_path: Path | None = None,
                   audio_hints: list[dict] | None = None,
                   on_progress: Callable[[list[str]], None] | None = None,
                   glossary_path: Path | None = None) -> list[Cue]:
    """on_progress(texts) runs after the saved cues load and after each new one ("" = not yet)."""
    if source_language in {"my", "mm"}:
        return [Cue(c.start, c.end, c.source, c.source) for c in cues]
    audio_hints = audio_hints or []
    from gemini_keys import GeminiKeys, discover_keys, is_daily_quota, is_key_limited

    keys = GeminiKeys(discover_keys(options.api_key, options.env_file), log)
    translated: list[Cue] = []
    checkpoint: dict[str, str] = {}
    if checkpoint_path and checkpoint_path.is_file():
        try:
            stored = json.loads(checkpoint_path.read_text(encoding="utf-8"))
            if stored.get("profile") == TRANSLATION_PROFILE:
                checkpoint = dict(stored.get("items") or {})
        except (OSError, ValueError, TypeError):
            checkpoint = {}
    # gemini-2.5-flash was retired (404 "no longer available", 2026-10-04).
    models = list(dict.fromkeys((options.gemini_model, "gemini-3.5-flash-lite",
                                 "gemini-3.1-flash-lite", "gemini-3-flash-preview")))
    active_model = models[0]
    names = None  # NameMemory once the job's name list exists

    def model_is_temporarily_unavailable(exc: Exception) -> bool:
        message = str(exc).lower()
        return any(token in message for token in (
            "503", "504", "429", "unavailable", "high demand", "resource_exhausted",
            "model not found", "not found for api version", "deadline exceeded",
            "404", "no longer available",
        ))

    def is_network_error(exc: Exception) -> bool:
        # Dropped proxy/HTTP connections and timeouts are transient, never a reason to stop.
        names = {type(e).__name__ for e in (exc, exc.__cause__, exc.__context__) if e is not None}
        message = str(exc).lower()
        return bool(names & {"RemoteProtocolError", "ReadError", "ConnectError", "ReadTimeout", "ConnectTimeout",
                             "WriteError", "PoolTimeout", "TimeoutException", "TimeoutError",
                             "ConnectionError", "ConnectionResetError", "ProxyError", "SSLError"}) or any(
            token in message for token in ("disconnected", "timed out", "connection reset", "connection aborted",
                                           "eof occurred", "proxy"))

    # Routine retries are counted and shown in a summary every 25 cues instead of one line each.
    retry_counts = {"rate limit": 0, "network": 0, "busy model": 0, "bad JSON": 0, "batch → halves": 0,
                    "lines re-asked": 0}
    request_count = [0]
    retry_lock = threading.Lock()

    def count_retry(kind: str) -> None:
        with retry_lock:
            retry_counts[kind] += 1

    def translate_window(window: list[Cue], index: int) -> list[str]:
        errors: list[str] = []
        # Busy spells (per-minute limits, 503 high demand) pass; wait instead of failing the run.
        for wait in (20, 45, 90, None):
            result = try_models(window, index, errors)
            if result is not None:
                return result
            if wait is None:
                break
            log(f"All keys/models busy; waiting {wait}s (cue {index + 1})")
            for _ in range(wait * 4):
                _check_cancel(cancel)
                time.sleep(.25)
        raise RuntimeError("Translation models unavailable: " + " | ".join(errors[-3:]))

    def try_models(window: list[Cue], index: int, errors: list[str]) -> list[str] | None:
        nonlocal active_model
        _check_cancel(cancel)
        ordered_models = [active_model] + [model for model in models if model != active_model]
        for model in ordered_models:
            attempt = 0
            keys_tried = 0
            network_retries = 0
            while True:
                _check_cancel(cancel)
                picked = keys.current(model, spread=True)
                if picked is None:
                    break  # every key spent today's quota for this model
                key_index, client = picked
                try:
                    repaired: list[str] = []
                    result = _translate_batch(
                        client, model, window, source_language,
                        context_before=[c.source for c in cues[max(0, index - 4):index]],
                        context_after=[c.source for c in cues[index + len(window):index + len(window) + 3]],
                        speaker_context=options.speaker_context,
                        cue_number=index + 1,
                        audio_hint=({"transcript": audio_hints[index]["gemini"],
                                     "speaker_id": audio_hints[index]["speaker_id"],
                                     "voice_gender": audio_hints[index]["voice_gender"]}
                                    if len(window) == 1 and index < len(audio_hints)
                                    and audio_hints[index].get("use_for_translation") else {}),
                        audio_rows=([{"transcript": audio_hints[i]["gemini"], "speaker_id": audio_hints[i]["speaker_id"],
                                      "voice_gender": audio_hints[i]["voice_gender"]}
                                     if i < len(audio_hints) and audio_hints[i].get("use_for_translation") else {}
                                     for i in range(index, index + len(window))] if len(window) > 1 else None),
                        names=(names.for_lines([c.source for c in cues[max(0, index - 4):index + len(window) + 3]])
                               if names else None),
                        repaired=repaired,
                    )
                    with retry_lock:
                        request_count[0] += 1
                    for removed in repaired:
                        log(f"Line {index + 1}: removed letters of another script ({removed}); check it in Review")
                    if model != active_model:
                        log(f"Translation model fallback: {model}")
                        active_model = model
                    return result
                except Exception as exc:
                    # Only answered requests count toward the daily quota; 429/503/dropped ones do not.
                    if isinstance(exc, (ValueError, KeyError, PartialBatch)):
                        with retry_lock:
                            request_count[0] += 1
                    errors.append(f"{model} [{keys.keys[key_index][0]}]: {str(exc)[:160]}")
                    if isinstance(exc, (BatchMismatch, PartialBatch)):
                        raise  # translate_group keeps the good lines and splits or re-asks the rest
                    if is_daily_quota(exc):
                        keys.mark_spent(key_index, model)
                        continue
                    # Quota/key problems are per project: the next request already takes the next key.
                    if is_key_limited(exc) and keys_tried < len(keys) - 1:
                        keys.rotate(exc, from_index=key_index)
                        keys_tried += 1
                        count_retry("rate limit")
                        continue
                    if is_network_error(exc):
                        network_retries += 1
                        count_retry("network")
                        if network_retries <= 2:
                            time.sleep(2 * network_retries)
                            continue
                        break
                    if model_is_temporarily_unavailable(exc):
                        count_retry("busy model")
                        break
                    if isinstance(exc, (ValueError, KeyError, json.JSONDecodeError)):
                        attempt += 1
                        count_retry("bad JSON")
                        if attempt < 3:
                            time.sleep(attempt)
                            continue
                        break
                    raise
        return None

    def cue_identity_for(index: int, cue: Cue) -> str:
        return translation_identity(cues, index, options.speaker_context, audio_hints)

    def cue_file(identity: str) -> Path | None:
        return (checkpoint_path.parent / "chunks" / "translations" / f"{identity}.json"
                if checkpoint_path else None)

    texts: list[str] = [""] * len(cues)
    identities = [cue_identity_for(index, cue) for index, cue in enumerate(cues)]
    for index, identity in enumerate(identities):
        text = checkpoint.get(identity, "")
        saved = read_json(cue_file(identity), {}) if cue_file(identity) else {}
        # Any model's finished line is kept: switching the model (e.g. to lite when flash's daily
        # quota is gone) must not translate the finished lines again.
        if saved.get("profile") == TRANSLATION_PROFILE:
            text = saved.get("text") or text
        if text:
            try:
                validate_myanmar_text(text)
            except ValueError:
                text = ""
        texts[index] = text
    pending = [index for index, text in enumerate(texts) if not text]
    done_count = len(cues) - len(pending)
    if on_progress:
        on_progress(texts)

    def report() -> None:
        progress(25 + int(55 * done_count / max(1, len(cues))),
                 f"Translated {done_count}/{len(cues)} spoken cues")

    def translate_one(index: int) -> str:
        _check_cancel(cancel)
        text = translate_window([cues[index]], index)[0]
        validate_myanmar_text(text)
        return text

    def translate_group(group: list[int]) -> list[tuple[int, str]]:
        if len(group) == 1:
            return [(group[0], translate_one(group[0]))]
        _check_cancel(cancel)
        try:
            texts_out = translate_window([cues[i] for i in group], group[0])
            for text in texts_out:
                validate_myanmar_text(text)
            return list(zip(group, texts_out))
        except PartialBatch as partial:
            # IDs all matched, so the good lines are safe to keep; only the bad ones are asked again.
            for _ in partial.bad:
                count_retry("lines re-asked")
            # Bad lines are asked again in runs of neighbouring lines, each with its own context.
            runs: list[list[int]] = []
            for index in (group[i] for i in partial.bad):
                if runs and runs[-1][-1] == index - 1:
                    runs[-1].append(index)
                else:
                    runs.append([index])
            kept = [(group[i], text) for i, text in partial.good.items()]
            for run in runs:
                kept += translate_group(run)
            return sorted(kept)
        except (BatchMismatch, ValueError):
            # Lines went missing or got mixed up: halves cost 2 requests, not one per line.
            count_retry("batch → halves")
            middle = len(group) // 2
            return translate_group(group[:middle]) + translate_group(group[middle:])

    def save(index: int, text: str) -> None:
        nonlocal done_count
        texts[index] = text
        checkpoint[identities[index]] = text
        if cue_file(identities[index]):
            write_json(cue_file(identities[index]), {"profile": TRANSLATION_PROFILE,
                                                     "model": options.gemini_model, "text": text})
        done_count += 1
        report()
        if on_progress:
            on_progress(texts)
        if done_count % 25 == 0 or done_count == len(cues):
            with retry_lock:
                retried = ", ".join(f"{n} {k}" for k, n in retry_counts.items() if n)
            log(f"Translated {done_count}/{len(cues)} · model {active_model} · answered requests {request_count[0]}"
                + (f" · retries so far: {retried}" if retried else " · no retries"))

    if glossary_path and pending:
        from names import NameMemory, build_glossary

        try:
            build_glossary(glossary_path, cues, texts, source_language, keys, models, log, cancel)
        except InterruptedError:
            keys.close()
            raise
        except Exception as exc:
            log(f"Name list not made now ({str(exc)[:160]}); translating without it, it is tried again next run")
        if Path(glossary_path).is_file():
            names = NameMemory(glossary_path, log)
    workers = max(1, min(8, int(getattr(options, "translation_workers", 1) or 1)))
    per_request = max(1, min(30, int(getattr(options, "cues_per_request", 1) or 1)))
    groups: list[list[int]] = []
    for index in pending:
        # Only neighbouring cues share a request, so context and order stay intact.
        if groups and groups[-1][-1] == index - 1 and len(groups[-1]) < per_request:
            groups[-1].append(index)
        else:
            groups.append([index])
    if pending:
        log(f"Translating {len(pending)} cue(s) · {per_request} per request ({len(groups)} requests) · "
            f"{workers} at a time")
    try:
        if workers == 1:
            for group in groups:
                for index, text in translate_group(group):
                    save(index, text)
        else:
            import concurrent.futures

            # Results are saved as each request finishes, so Pause/Resume keeps finished cues.
            pool = concurrent.futures.ThreadPoolExecutor(max_workers=workers, thread_name_prefix="translate")
            futures = {pool.submit(translate_group, group): group for group in groups}
            failure: BaseException | None = None
            try:
                for future in concurrent.futures.as_completed(futures):
                    try:
                        for index, text in future.result():
                            save(index, text)
                    except BaseException as exc:
                        if failure is None:
                            failure = exc
                            for other in futures:
                                other.cancel()
            finally:
                pool.shutdown(wait=True, cancel_futures=True)
            if failure is not None:
                raise failure
        _check_cancel(cancel)
    finally:
        keys.close()
    return [Cue(cue.start, cue.end, cue.source, text) for cue, text in zip(cues, texts)]


def _fmt_srt(seconds: float) -> str:
    ms = max(0, round(seconds * 1000))
    h, rem = divmod(ms, 3600000)
    m, rem = divmod(rem, 60000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _fmt_ass(seconds: float) -> str:
    cs = max(0, round(seconds * 100))
    h, rem = divmod(cs, 360000)
    m, rem = divmod(rem, 6000)
    s, cs = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def write_srt(cues: list[Cue], path: Path) -> None:
    lines = []
    for index, cue in enumerate(cues, 1):
        lines.extend([str(index), f"{_fmt_srt(cue.start)} --> {_fmt_srt(cue.end)}", cue.text, ""])
    path.write_text("\n".join(lines), encoding="utf-8-sig")


def _clusters(text: str) -> list[str]:
    result: list[str] = []
    for ch in text:
        if result and (unicodedata.category(ch) in {"Mn", "Mc", "Me"}
                       or ch in "\u200c\u200d\ufe0f" or result[-1][-1] in "\u1039\u200d"):
            result[-1] += ch
        else:
            result.append(ch)
    return result


def wrap_two_lines(text: str, max_clusters: int) -> tuple[str, int]:
    """Break on a phrase boundary near the middle without splitting Myanmar marks."""
    clean = _clean_text(text)
    clusters = _clusters(clean)
    if len(clusters) <= max_clusters:
        return clean, 1
    if len(clusters) > max_clusters * 2:
        return clean, 3
    midpoint = len(clusters) // 2
    candidates = [i for i in range(1, len(clusters)) if clusters[i - 1].isspace()
                  or clusters[i - 1] in {"၊", "။", ",", ";", "—"}]
    candidates = [i for i in candidates if i <= max_clusters + 2 and len(clusters) - i <= max_clusters + 2]
    split = min(candidates, key=lambda i: abs(i - midpoint)) if candidates else midpoint
    left, right = "".join(clusters[:split]).strip(), "".join(clusters[split:]).strip()
    return f"{left}\\N{right}", 2


def ass_color(value: str, opacity: int = 100) -> str:
    """'#RRGGBB' -> ASS '&HAABBGGRR' (ASS alpha 00 = solid, FF = invisible)."""
    value = str(value or "").strip().lstrip("#")
    if len(value) != 6 or any(c not in "0123456789abcdefABCDEF" for c in value):
        raise ValueError(f"Colour must look like #RRGGBB, got {value!r}")
    alpha = round(255 * (1 - max(0, min(100, int(opacity))) / 100))
    return f"&H{alpha:02X}{value[4:6]}{value[2:4]}{value[0:2]}".upper()


def subtitle_outline(size: int, outline_width: int) -> int:
    return max(2, round(size * .075)) if outline_width is None or int(outline_width) < 0 else int(outline_width)


def fit_subtitle(text: str, size: int, box_width: int, box_bottom: int) -> tuple[str, int, int, int, bool]:
    """(wrapped text, font size, padding, panel height, fits) for one cue; the preview uses it too.

    The chosen font size is kept: the box sets the width and the bottom line, and a two-line
    cue grows upward from the box bottom. Only a cue that needs more than two lines at that
    width is shrunk (never its speech timing).
    """
    local_size = size
    while True:
        padding = max(3, round(local_size * .2))
        capacity = max(1, int((box_width - 2 * padding) / (local_size * .72)))
        wrapped, line_count = wrap_two_lines(text, capacity)
        panel_height = round(local_size * 1.32 * line_count + 2 * padding)
        fits = line_count <= 2 and panel_height <= box_bottom
        if fits or local_size <= 12:
            return wrapped, local_size, padding, panel_height, fits
        local_size = max(12, local_size - 2)


def _ass_escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}")


def write_ass(cues: list[Cue], path: Path, width: int, height: int,
              font_size: int, bottom_margin: int, layout: Layout | None = None,
              title: str = "", part: str = "", watermark: str = "",
              duration: float = 0, font_name: str = "Myanmar Text", bold: bool = False,
              overlay_font: str = "Myanmar Text", overlay_size: int = 0,
              text_color: str = "#FFFFFF", outline_color: str = "#252525", outline_width: int = -1,
              shadow: int = 0, box_enabled: bool = True, box_color: str = "#383838",
              box_opacity: int = 62) -> None:
    size = max(22, min(100, int(font_size)))
    primary, outline = ass_color(text_color), ass_color(outline_color)
    panel_fill = ass_color(box_color)[4:]  # BBGGRR, used as \1c&H..&
    panel_alpha = ass_color(box_color, box_opacity)[2:4]
    shadow = max(0, min(10, int(shadow or 0)))
    font_name = (font_name or "Myanmar Text").replace(",", " ")
    overlay_font = (overlay_font or "Myanmar Text").replace(",", " ")
    margin = max(8, min(height // 3, int(bottom_margin)))
    if layout is None:
        layout = Layout()
        layout.subtitle.y = max(0.0, 1.0 - margin / height - layout.subtitle.h)
    layout.validate()
    sx, sy, sw, sh = layout.subtitle.pixels(width, height)
    subtitle_x = sx + sw // 2
    header = (
        "[Script Info]\nScriptType: v4.00+\nWrapStyle: 2\nScaledBorderAndShadow: yes\n"
        f"PlayResX: {width}\nPlayResY: {height}\n\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
        "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
        "Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Myanmar,{font_name},{size},{primary},{primary},{outline},&H80000000,"
        f"{-1 if bold else 0},0,0,0,100,100,0,0,1,{subtitle_outline(size, outline_width)},{shadow},2,16,16,{margin},1\n"
        "Style: Panel,Arial,20,&H70383838,&H70383838,&H70383838,&H70383838,"
        "0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1\n"
        f"Style: Overlay,{overlay_font},{max(22, round(size * .62))},&H00FFFFFF,&H00FFFFFF,&H00252525,&H88383838,"
        f"1,0,0,0,100,100,0,0,3,8,0,5,0,0,0,1\n\n"
        "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )
    rows = [header]
    if duration > 0:
        for name, box, value in (("title", layout.title, " · ".join(x for x in (title.strip(), part.strip()) if x)),
                                 ("watermark", layout.watermark, watermark.strip())):
            if box.enabled and value:
                x, y, w, h = box.pixels(width, height)
                midx, midy = x + w // 2, y + h // 2
                size_override = (int(overlay_size) if overlay_size and int(overlay_size) > 0
                                 else max(18, min(round(h * .55), round(w / max(len(value), 1) * 1.6))))
                rows.append(f"Dialogue: 1,0:00:00.00,{_fmt_ass(duration)},Overlay,,0,0,0,,"
                            f"{{\\an5\\pos({midx},{midy})\\fs{size_override}}}{_ass_escape(value)}\n")
    for cue in cues if layout.subtitle.enabled else []:
        text = _ass_escape(cue.text)
        wrapped, local_size, padding, panel_height, fits = fit_subtitle(text, size, sw, sy + sh)
        if not fits:
            raise ValueError(f"Subtitle does not fit its box at {_fmt_srt(cue.start)}; shorten the cue or widen the subtitle box in Preview / Position")
        panel_top = sy + sh - panel_height
        subtitle_y = sy + sh - padding
        if box_enabled and int(box_opacity) > 0:
            panel_color = "{\\an7\\pos(%d,%d)\\p1\\1c&H%s&\\1a&H%s&}" % (sx, panel_top, panel_fill, panel_alpha)
            shape = f"m 0 0 l {sw} 0 l {sw} {panel_height} l 0 {panel_height}"
            rows.append(f"Dialogue: -1,{_fmt_ass(cue.start)},{_fmt_ass(cue.end)},Panel,,0,0,0,,{panel_color}{shape}\n")
        override = f"{{\\pos({subtitle_x},{subtitle_y})\\fs{local_size}}}"
        rows.append(f"Dialogue: 0,{_fmt_ass(cue.start)},{_fmt_ass(cue.end)},Myanmar,,0,0,0,,{override}{wrapped}\n")
    path.write_text("".join(rows), encoding="utf-8-sig")


def probe_video(video: Path, ffprobe: str) -> dict:
    proc = subprocess.run(
        [ffprobe, "-v", "error", "-show_entries", "stream=codec_type,width,height,avg_frame_rate,r_frame_rate", "-show_entries",
         "format=duration", "-of", "json", str(video)],
        capture_output=True, text=True, encoding="utf-8", errors="replace", check=True,
    )
    data = json.loads(proc.stdout)
    visual = next((s for s in data.get("streams", []) if s.get("codec_type") == "video"), None)
    if not visual:
        raise ValueError("Input file has no video stream")
    return {"width": int(visual["width"]), "height": int(visual["height"]),
            "frame_rate": visual.get("avg_frame_rate") if visual.get("avg_frame_rate") not in {None, "0/0"}
                          else visual.get("r_frame_rate") or "25/1",
            "duration": float(data.get("format", {}).get("duration") or 0)}


def _find_program(name: str) -> str:
    found = shutil.which(name)
    if found:
        return found
    installed = Path("C:/ffmpeg/bin") / (name + ".exe")
    if installed.is_file():
        return str(installed)
    raise RuntimeError(f"{name} not found. Install FFmpeg or add it to PATH.")


def ass_fonts(options: "Options") -> dict:
    """write_ass() font keyword arguments from Options (older saved jobs lack the fields)."""
    return dict(font_name=getattr(options, "subtitle_font", "Myanmar Text"),
                bold=bool(getattr(options, "subtitle_bold", False)),
                overlay_font=getattr(options, "overlay_font", "Myanmar Text"),
                overlay_size=int(getattr(options, "overlay_font_size", 0) or 0),
                text_color=getattr(options, "subtitle_color", "#FFFFFF"),
                outline_color=getattr(options, "outline_color", "#252525"),
                outline_width=int(getattr(options, "outline_width", -1)),
                shadow=int(getattr(options, "shadow", 0) or 0),
                box_enabled=bool(getattr(options, "box_enabled", True)),
                box_color=getattr(options, "box_color", "#383838"),
                box_opacity=int(getattr(options, "box_opacity", 62)))


def render_video(video: Path, ass: Path, output: Path, ffmpeg: str,
                 log: Log, cancel: threading.Event | None = None,
                 layout: Layout | None = None, dimensions: tuple[int, int] | None = None,
                 fonts: list[str] | None = None) -> None:
    from fonts import ass_filter

    partial = output.with_name(output.stem + ".partial.mp4")
    if partial.exists():
        partial.unlink()
    subtitle_filter = ass_filter(ass, list(fonts or []))
    filters = ["-vf", subtitle_filter]
    video_map = "0:v:0"
    if layout and layout.blur.enabled:
        if not dimensions:
            raise ValueError("Video dimensions required for blur box")
        x, y, w, h = layout.blur.pixels(*dimensions)
        blur_radius = max(1, min(18, (min(w, h) - 1) // 2))
        chroma_radius = max(0, min(8, (min(w, h) - 2) // 4))
        filters = ["-filter_complex", f"[0:v]split=2[base][copy];"
                   f"[copy]crop={w}:{h}:{x}:{y},boxblur={blur_radius}:2:{chroma_radius}:2[patch];"
                   f"[base][patch]overlay={x}:{y},{subtitle_filter}[vout]"]
        video_map = "[vout]"
    base = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-i", str(video),
            *filters, "-map", video_map, "-map", "0:a?",
            "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
            "-c:a", "copy", "-movflags", "+faststart", str(partial)]
    for audio_codec in ("copy", "aac"):
        _check_cancel(cancel)
        cmd = list(base)
        cmd[cmd.index("-c:a") + 1] = audio_codec
        log(f"Rendering video; original audio {'copied' if audio_codec == 'copy' else 're-encoded'}")
        proc = subprocess.Popen(cmd, cwd=ass.parent, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, encoding="utf-8", errors="replace")
        try:
            while True:
                _check_cancel(cancel)
                try:
                    _, stderr = proc.communicate(timeout=.25)
                    break
                except subprocess.TimeoutExpired:
                    continue
        except BaseException:
            proc.terminate()
            try:
                proc.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate()
            partial.unlink(missing_ok=True)
            raise
        if proc.returncode == 0 and partial.is_file() and partial.stat().st_size > 0:
            partial.replace(output)
            return
        if audio_codec == "aac":
            partial.unlink(missing_ok=True)
            raise RuntimeError("FFmpeg render failed: " + stderr[-2500:])


def run(options: Options, log: Log = print, progress: Progress = lambda *_: None,
        cancel: threading.Event | None = None, *, prepare_only: bool = False) -> dict:
    if not 0 < options.chunk_minutes <= 60:
        raise ValueError("Work chunk length must be between 0 and 60 minutes")
    video = options.video.expanduser().resolve()
    if not video.is_file():
        raise FileNotFoundError(video)
    if options.source_srt and not options.source_srt.is_file():
        raise FileNotFoundError(options.source_srt)
    ffprobe, ffmpeg = _find_program("ffprobe"), _find_program("ffmpeg")
    info = probe_video(video, ffprobe)
    srt_signature = ""
    if options.source_srt:
        source_srt = options.source_srt.expanduser().resolve()
        srt_signature = f"{source_srt}|{source_srt.stat().st_size}|{source_srt.stat().st_mtime_ns}"
    key_material = f"{video}|{video.stat().st_size}|{video.stat().st_mtime_ns}|{srt_signature}|{options.whisper_model}|{options.source_language}|{CUE_PROFILE}"
    job_id = hashlib.sha256(key_material.encode("utf-8")).hexdigest()[:10]
    job = options.output_dir.expanduser().resolve() / f"{video.stem}_mm_{job_id}"
    job.mkdir(parents=True, exist_ok=True)
    log(f"Resume folder: {job}")
    speaker_file = job / "speaker_context.txt"
    if options.speaker_context.strip():
        speaker_file.write_text(options.speaker_context.strip(), encoding="utf-8")
        options = replace(options, speaker_context=options.speaker_context.strip())
    elif speaker_file.is_file():
        options = replace(options, speaker_context=speaker_file.read_text(encoding="utf-8").strip())
    save_job(job, options)
    (job / "prepared_result.json").unlink(missing_ok=True)
    notify_progress = progress

    def progress(percent, message):
        write_json(job / "progress.json", {"percent": percent, "stage": message})
        notify_progress(percent, message)
    source_cache = job / "source_cues.json"
    translation_cache = job / "translated_cues.json"
    translation_checkpoint = job / "partial_translations.json"
    manual_review = job / "manual_review.json"
    progress(2, "Checking input")
    _check_cancel(cancel)
    data = read_json(source_cache, {})
    if data.get("profile") == CUE_PROFILE:
        cues = [Cue(**row) for row in data["cues"]]
        detected = str(data["language"])
        log(f"Reusing {len(cues)} timed source cues")
    elif options.source_srt:
        cues = parse_srt(options.source_srt)
        detected = options.source_language
        write_json(source_cache, {"profile": CUE_PROFILE, "language": detected, "cues": [asdict(c) for c in cues]})
        log(f"Loaded {len(cues)} source subtitle cues")
    else:
        progress(5, "Transcribing original audio")
        from long_jobs import transcribe_chunks
        cues, detected = transcribe_chunks(video, job, info["duration"], options.chunk_minutes * 60,
                                          options.whisper_model, options.source_language, ffmpeg,
                                          log, progress, cancel)
        write_json(source_cache, {"profile": CUE_PROFILE, "language": detected, "cues": [asdict(c) for c in cues]})
        log(f"Timed {len(cues)} spoken subtitle cues")
    audio_hints: list[dict] = []
    if options.audio_crosscheck and detected not in {"my", "mm"}:
        progress(20, "Checking audio transcript with Gemini")
        try:
            from audio_review import check_audio
            from gemini_keys import GeminiKeys, discover_keys
            audio_hints = check_audio(video, cues, job,
                                      lambda: GeminiKeys(discover_keys(options.api_key, options.env_file), log),
                                      options.gemini_model,
                                      ffmpeg, log, cancel)
        except InterruptedError:
            raise
        except Exception as exc:
            log(f"Gemini audio check unavailable; using Whisper source: {exc}")
            from audio_review import compare_cues
            audio_hints = compare_cues(cues, [])
    progress(25, "Translating to Myanmar")
    _check_cancel(cancel)
    data = read_json(translation_cache, {})
    if (data and data.get("profile") == TRANSLATION_PROFILE and
            data.get("model") == options.gemini_model and
            data.get("speaker_context", "") == options.speaker_context and
            data.get("audio_hints", []) == audio_hints and
            data.get("source") == [asdict(c) for c in cues]):
        translated = [Cue(**row) for row in data["cues"]]
        log(f"Reusing {len(translated)} Myanmar translations")
    else:
        live_parts = _split_minutes(options) > 0 and not options.srt_only and not prepare_only
        from names import GLOSSARY_FILE
        glossary = job / GLOSSARY_FILE if getattr(options, "name_memory", True) else None
        translated = _translate_with_parts(cues, options, detected, log, progress, cancel, translation_checkpoint,
                                           audio_hints, job, info, ffmpeg, live_parts, glossary)
    if manual_review.is_file():
        overrides = json.loads(manual_review.read_text(encoding="utf-8")).get("items") or {}
        applied = 0
        for cue in translated:
            replacement = overrides.get(cue_identity(cue))
            if replacement:
                validate_myanmar_text(replacement)
                cue.text = _clean_text(replacement)
                applied += 1
        if applied:
            log(f"Applied {applied} manually reviewed subtitle corrections")
    for cue in translated:
        validate_myanmar_text(cue.text)
    write_json(translation_cache, {"profile": TRANSLATION_PROFILE, "model": options.gemini_model,
                                             "speaker_context": options.speaker_context,
                                             "audio_hints": audio_hints,
                                             "source": [asdict(c) for c in cues],
                                             "cues": [asdict(c) for c in translated]})
    result = {"job_dir": str(job), "cues": len(translated), "source_language": detected,
              "input_signature": _input_signature(video),
              "cue_ids": [cue_identity(c) for c in cues]}
    write_json(job / "prepared_result.json", result)
    return _export(options, result, translated, info, ffmpeg, log, progress, cancel, prepare_only)


def _translate_with_parts(cues, options, detected, log, progress, cancel, checkpoint, audio_hints,
                          job, info, ffmpeg, live_parts: bool, glossary: Path | None = None) -> list[Cue]:
    """translate_cues(); in parts mode each finished part is rendered while translation continues."""
    if not live_parts:
        return translate_cues(cues, options, detected, log, progress, cancel, checkpoint, audio_hints,
                              glossary_path=glossary)
    from export_parts import PartRenderer

    renderer = PartRenderer(options, job, cues, info, ffmpeg, log, cancel)
    try:
        return translate_cues(cues, options, detected, log, progress, cancel, checkpoint, audio_hints,
                              on_progress=renderer.update, glossary_path=glossary)
    except InterruptedError:
        raise
    except Exception:
        if renderer.pending():
            log(f"Translation stopped; finishing the {renderer.pending()} part(s) already translated first")
        raise
    finally:
        renderer.close()


def _input_signature(video: Path) -> list:
    video = video.expanduser().resolve()
    stat = video.stat()
    return [str(video), stat.st_size, stat.st_mtime_ns]


def render_prepared(options: Options, prepared: dict, log: Log = print,
                    progress: Progress = lambda *_: None,
                    cancel: threading.Event | None = None) -> dict:
    """Render the exact reviewed cues, with no transcription or Gemini requests."""
    _check_cancel(cancel)
    if _input_signature(options.video) != prepared["input_signature"]:
        raise ValueError("Input video changed after preparation; prepare it again before rendering")
    data = json.loads((Path(prepared["job_dir"]) / "translated_cues.json").read_text(encoding="utf-8"))
    cues = [Cue(**row) for row in data["cues"]]
    if [cue_identity(c) for c in cues] != prepared["cue_ids"]:
        raise ValueError("Source text or timing changed after preparation; prepare this video again")
    for cue in cues:
        validate_myanmar_text(cue.text)
    log(f"Rendering {len(cues)} reviewed cues without calling Gemini")
    notify_progress = progress

    def progress(percent, message):
        write_json(Path(prepared["job_dir"]) / "progress.json", {"percent": percent, "stage": message})
        notify_progress(percent, message)

    info = probe_video(options.video, _find_program("ffprobe"))
    return _export(options, dict(prepared), cues, info, _find_program("ffmpeg"), log, progress, cancel)


def _export(options: Options, result: dict, cues: list[Cue], info: dict, ffmpeg: str,
            log: Log, progress: Progress, cancel, prepare_only: bool = False) -> dict:
    _check_cancel(cancel)
    job = Path(result["job_dir"])
    video = options.video.expanduser().resolve()
    srt, ass = job / "myanmar.srt", job / "myanmar.ass"
    write_srt(cues, srt)
    result.update(srt=str(srt), ass="", video="")
    split = _split_minutes(options)
    parts_options = options
    options = replace(options, part=part_label(options.part, 1))  # the full video is "part 1"
    # Layout errors must not prevent the user from opening review to shorten a cue.
    if prepare_only:
        progress(100, "Ready for review")
        return result
    try:
        write_ass(cues, ass, info["width"], info["height"], options.font_size,
                  options.bottom_margin, options.layout, options.title, options.part,
                  options.watermark, info["duration"], **ass_fonts(options))
        result["ass"] = str(ass)
    except ValueError as exc:
        if not options.srt_only:
            raise
        log(f"SRT saved; ASS layout needs review: {exc}")
    output = job / f"{video.stem}_myanmar_subtitled.mp4"
    if not options.srt_only and split:
        progress(82, f"Burning subtitles into {split:g}-minute parts")
        from export_parts import render_parts
        result["parts"] = [str(path) for path in
                           render_parts(parts_options, job, cues, info, ffmpeg, log, progress, cancel)]
    elif not options.srt_only:
        progress(82, "Burning subtitles into original video")
        from render_chunks import render_resumable
        render_resumable(options, result, cues, info, ass, output, ffmpeg, log, progress, cancel)
        result["video"] = str(output)
    progress(100, "Done")
    return result
