"""Standalone Myanmar subtitle creator."""
