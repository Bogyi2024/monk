from __future__ import annotations

import json
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

from core import validate_myanmar_text
from batch_review import save_reviews


class ReviewDialog(tk.Toplevel):
    """Edit translated text while preserving source words and timestamps."""

    def __init__(self, parent: tk.Tk, job_dir: Path) -> None:
        super().__init__(parent)
        self.job_dir = job_dir
        self.cache_path = job_dir / "translated_cues.json"
        self.data = json.loads(self.cache_path.read_text(encoding="utf-8"))
        self.rows = self.data["cues"]
        self.original = [row["text"] for row in self.rows]
        self.current = -1
        self.title(f"Review Myanmar subtitles · {job_dir.name}")
        self.geometry("1050x680")
        self.minsize(740, 500)
        self.transient(parent)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self._close)
        self._build()
        if self.rows:
            self.listbox.selection_set(0)
            self._select(0)

    def _build(self) -> None:
        outer = ttk.Frame(self, padding=12)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="Cue ကိုရွေးပြီး မြန်မာစာကို ပြင်ပါ။ Save လုပ်ပြီး video ကို ပြန် render လုပ်ပါ။",
                  font=("Myanmar Text", 11)).pack(anchor="w", pady=(0, 8))
        middle = ttk.Frame(outer)
        middle.pack(fill="both", expand=True)
        left = ttk.Frame(middle)
        left.pack(side="left", fill="both", expand=True)
        self.listbox = tk.Listbox(left, font=("Myanmar Text", 10), exportselection=False)
        self.listbox.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(left, orient="vertical", command=self.listbox.yview)
        scroll.pack(side="right", fill="y")
        self.listbox.configure(yscrollcommand=scroll.set)
        for number, row in enumerate(self.rows, 1):
            self.listbox.insert("end", f"{number:02d}  {row['start']:.1f}–{row['end']:.1f}s  {row['text'][:65]}")
        self.listbox.bind("<<ListboxSelect>>", self._selection_changed)
        right = ttk.Frame(middle, padding=(12, 0, 0, 0))
        right.pack(side="left", fill="both", expand=True)
        self.time_label = ttk.Label(right, text="", font=("Myanmar Text", 11, "bold"))
        self.time_label.pack(anchor="w")
        ttk.Label(right, text="Source / မူရင်း", font=("Myanmar Text", 10)).pack(anchor="w", pady=(10, 2))
        self.source = tk.Text(right, height=4, wrap="word", font=("Segoe UI", 12))
        self.source.pack(fill="x")
        self.source.configure(state="disabled")
        ttk.Label(right, text="Myanmar / ပြင်မယ့်စာ", font=("Myanmar Text", 10)).pack(anchor="w", pady=(14, 2))
        self.translation = tk.Text(right, height=5, wrap="word", font=("Myanmar Text", 14))
        self.translation.pack(fill="x")
        ttk.Label(right, text="ဤ dialog သည် စာသားကိုသာ ပြင်သည်။ Timing မပြောင်းပါ။",
                  font=("Myanmar Text", 9)).pack(anchor="w", pady=8)
        buttons = ttk.Frame(outer)
        buttons.pack(fill="x", pady=(10, 0))
        ttk.Button(buttons, text="Save corrections", command=self._save).pack(side="left")
        ttk.Button(buttons, text="Save & Close", command=self._close).pack(side="right")

    def _commit_current(self) -> bool:
        if self.current < 0:
            return True
        value = " ".join(self.translation.get("1.0", "end-1c").split())
        try:
            validate_myanmar_text(value)
        except ValueError as exc:
            messagebox.showerror("Invalid Myanmar text", str(exc), parent=self)
            return False
        self.rows[self.current]["text"] = value
        row = self.rows[self.current]
        self.listbox.delete(self.current)
        self.listbox.insert(self.current, f"{self.current + 1:02d}  {row['start']:.1f}–{row['end']:.1f}s  {value[:65]}")
        return True

    def _selection_changed(self, _event) -> None:
        selected = self.listbox.curselection()
        if selected:
            self._select(selected[0])

    def _select(self, index: int) -> None:
        if index == self.current:
            return
        if not self._commit_current():
            self.listbox.selection_clear(0, "end")
            self.listbox.selection_set(self.current)
            return
        self.current = index
        self.listbox.selection_clear(0, "end")
        self.listbox.selection_set(index)
        self.listbox.see(index)
        row = self.rows[index]
        self.time_label.configure(text=f"Cue {index + 1}/{len(self.rows)} · {row['start']:.2f}–{row['end']:.2f}s")
        self.source.configure(state="normal")
        self.source.delete("1.0", "end")
        self.source.insert("1.0", row["source"])
        self.source.configure(state="disabled")
        self.translation.delete("1.0", "end")
        self.translation.insert("1.0", row["text"])

    def _save(self, notify: bool = True) -> bool:
        if not self._commit_current():
            return False
        entry = {"job_dir": self.job_dir, "data": self.data, "original": self.original}
        try:
            count = save_reviews([entry])
        except (OSError, ValueError) as exc:
            messagebox.showerror("Save failed", str(exc), parent=self)
            return False
        self.original = entry["original"]
        if notify:
            messagebox.showinfo("Saved", f"Saved {count} cue(s). Re-run this video to update its MP4.", parent=self)
        return True

    def _close(self) -> None:
        if self._save(notify=False):
            self.destroy()
