from __future__ import annotations

import io
import subprocess
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

from PIL import Image, ImageFilter, ImageTk

from core import _find_program, fit_subtitle, probe_video, subtitle_outline
from layout import Layout


BOX_NAMES = ("blur", "watermark", "title", "subtitle")
COLORS = {"blur": "#ff795c", "watermark": "#50c4e8", "title": "#f9c66a", "subtitle": "#9fe180"}
SAMPLE_SUBTITLE = "မြန်မာစာတန်းထိုး နမူနာ စာကြောင်း"


def _fmt(seconds: float) -> str:
    seconds = max(0, int(seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


class PreviewPanel(ttk.Frame):
    """Live frame preview with draggable/resizable layout boxes.

    Box positions are 0..1 fractions of the video frame, saved to layout.json on every
    change, so the preview can be any size without moving where boxes land in the render.
    """

    def __init__(self, parent: tk.Misc, layout_path: Path, *, bg: str = "#141821") -> None:
        super().__init__(parent)
        self.layout_path = layout_path
        self.layout = Layout.load(layout_path)
        self.video: Path | None = None
        self.info: dict | None = None
        self.title_text = self.part_text = self.watermark_text = ""
        self.font_size = 48
        self.subtitle_font, self.subtitle_bold = "Myanmar Text", False
        self.overlay_font, self.overlay_size = "Myanmar Text", 0
        self.style = dict(text_color="#FFFFFF", outline_color="#252525", outline_width=-1, shadow=0,
                          box_enabled=True, box_color="#383838", box_opacity=62)
        self.selected = tk.StringVar(value="subtitle")
        self.seconds = tk.DoubleVar(value=20.0)
        self.image = None
        self.photo = None
        self.drag_start: tuple[int, int, float, float, float, float, str] | None = None
        self._redraw_job = None
        self._build(bg)

    # ------------------------------------------------------------------ UI
    def _build(self, bg: str) -> None:
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        choices = ttk.Frame(self)
        choices.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(choices, text="Box").pack(side="left", padx=(0, 6))
        for name in BOX_NAMES:
            ttk.Radiobutton(choices, text=name.title(), value=name, variable=self.selected,
                            command=self._selected_changed).pack(side="left", padx=5)
        self.enabled = tk.BooleanVar(value=getattr(self.layout, self.selected.get()).enabled)
        ttk.Checkbutton(choices, text="Show selected box in video", variable=self.enabled,
                        command=self._toggle).pack(side="right")

        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, width=640, height=400, cursor="crosshair")
        self.canvas.grid(row=1, column=0, sticky="nsew")
        self.canvas.bind("<Configure>", lambda _e: self._schedule_draw())
        self.canvas.bind("<Button-1>", self._press)
        self.canvas.bind("<B1-Motion>", self._drag)
        self.canvas.bind("<ButtonRelease-1>", self._release)

        seek = ttk.Frame(self)
        seek.grid(row=2, column=0, sticky="ew", pady=(6, 0))
        seek.columnconfigure(1, weight=1)
        ttk.Button(seek, text="◀ 5s", width=6, command=lambda: self._step(-5)).grid(row=0, column=0, padx=(0, 6))
        self.slider = ttk.Scale(seek, from_=0, to=100, orient="horizontal", variable=self.seconds,
                                command=lambda _v: self._update_time_label())
        self.slider.grid(row=0, column=1, sticky="ew")
        self.slider.bind("<ButtonRelease-1>", lambda _e: self.load_frame())
        ttk.Button(seek, text="5s ▶", width=6, command=lambda: self._step(5)).grid(row=0, column=2, padx=(6, 8))
        self.time_label = ttk.Label(seek, text="00:00 / 00:00", width=17)
        self.time_label.grid(row=0, column=3)
        self.coords = ttk.Label(self, text="Drag a box to move it · drag its bottom-right corner to resize")
        self.coords.grid(row=3, column=0, sticky="w", pady=(4, 0))

    # ------------------------------------------------------------- public API
    def set_video(self, video: Path | None) -> None:
        if video is None or not Path(video).is_file():
            self.video, self.info, self.image = None, None, None
            self._schedule_draw()
            return
        video = Path(video)
        if self.video == video and self.info:
            return
        try:
            self.info = probe_video(video, _find_program("ffprobe"))
        except Exception as exc:
            self.video, self.info, self.image = None, None, None
            self.coords.configure(text=f"Preview error: {exc}")
            self._schedule_draw()
            return
        self.video = video
        duration = float(self.info.get("duration") or 0) or 1.0
        self.slider.configure(to=max(0.1, duration))
        self.seconds.set(min(duration * 0.2, max(0.0, duration - 0.1)))
        self.load_frame()

    def set_texts(self, title: str, part: str, watermark: str, font_size: int | None = None,
                  subtitle_font: str | None = None, subtitle_bold: bool | None = None,
                  overlay_font: str | None = None, overlay_size: int | None = None,
                  style: dict | None = None) -> None:
        self.title_text, self.part_text, self.watermark_text = title, part, watermark
        if style:
            self.style.update(style)
        if font_size:
            self.font_size = int(font_size)
        if subtitle_font:
            self.subtitle_font = subtitle_font
        if subtitle_bold is not None:
            self.subtitle_bold = bool(subtitle_bold)
        if overlay_font:
            self.overlay_font = overlay_font
        if overlay_size is not None:
            self.overlay_size = int(overlay_size)
        self._schedule_draw()

    def reload_layout(self) -> None:
        self.layout = Layout.load(self.layout_path)
        self.enabled.set(getattr(self.layout, self.selected.get()).enabled)
        self._schedule_draw()

    def load_frame(self) -> None:
        self._update_time_label()
        if not self.video or not self.info:
            return
        cmd = [_find_program("ffmpeg"), "-hide_banner", "-loglevel", "error", "-ss", f"{self.seconds.get():.3f}",
               "-i", str(self.video), "-frames:v", "1", "-f", "image2pipe", "-vcodec", "png", "pipe:1"]
        try:
            result = subprocess.run(cmd, capture_output=True, timeout=30, check=True)
            self.image = Image.open(io.BytesIO(result.stdout)).convert("RGB")
            self._draw()
        except (OSError, subprocess.SubprocessError, ValueError) as exc:
            messagebox.showerror("Preview error", str(exc), parent=self.winfo_toplevel())

    # -------------------------------------------------------------- internals
    def _step(self, delta: float) -> None:
        duration = float((self.info or {}).get("duration") or 0)
        value = self.seconds.get() + delta
        self.seconds.set(max(0.0, min(value, max(0.0, duration - 0.1))) if duration else max(0.0, value))
        self.load_frame()

    def _update_time_label(self) -> None:
        duration = float((self.info or {}).get("duration") or 0)
        self.time_label.configure(text=f"{_fmt(self.seconds.get())} / {_fmt(duration)}")

    def _frame_rect(self) -> tuple[int, int, int, int]:
        cw, ch = max(self.canvas.winfo_width(), 100), max(self.canvas.winfo_height(), 100)
        vw, vh = (self.info["width"], self.info["height"]) if self.info else (16, 9)
        ratio = min(cw / vw, ch / vh)
        w, h = round(vw * ratio), round(vh * ratio)
        return (cw - w) // 2, (ch - h) // 2, w, h

    def _schedule_draw(self) -> None:
        if self._redraw_job is not None:
            self.after_cancel(self._redraw_job)
        self._redraw_job = self.after(40, self._draw)

    def _draw(self) -> None:
        self._redraw_job = None
        self.canvas.delete("all")
        ox, oy, fw, fh = self._frame_rect()
        if self.image:
            frame = self.image.resize((fw, fh), Image.Resampling.LANCZOS)
            blur = self.layout.blur
            if blur.enabled:
                bx, by, bw, bh = (round(blur.x*fw), round(blur.y*fh), round(blur.w*fw), round(blur.h*fh))
                region = frame.crop((bx, by, bx+bw, by+bh)).filter(ImageFilter.GaussianBlur(10))
                frame.paste(region, (bx, by))
            self.photo = ImageTk.PhotoImage(frame)
            self.canvas.create_image(ox, oy, image=self.photo, anchor="nw")
        else:
            self.canvas.create_rectangle(ox, oy, ox + fw, oy + fh, fill="#263143", outline="")
            self.canvas.create_text(ox + fw / 2, oy + fh / 2, fill="#9da9be", font=("Segoe UI", 12),
                                    text="Choose a video (or a folder) — its frame appears here")
        labels = {"blur": "Original subtitle blur", "watermark": self.watermark_text or "Watermark",
                  "title": " · ".join(x for x in (self.title_text, self.part_text) if x) or "Title · Part",
                  "subtitle": ""}
        for name in BOX_NAMES:
            box = getattr(self.layout, name)
            x, y, w, h = ox + box.x * fw, oy + box.y * fh, box.w * fw, box.h * fh
            color = COLORS[name]
            fill = "#252525" if name in {"title", "watermark"} and box.enabled else ""
            self.canvas.create_rectangle(x, y, x+w, y+h, outline=color, width=3 if name == self.selected.get() else 2,
                                         fill=fill, stipple="gray50" if fill else "")
            vh = (self.info or {}).get("height") or 1080
            scale = fh / vh
            if name == "subtitle" and box.enabled:
                self._draw_sample_subtitle(box, x, y, w, h, scale)
            elif name in {"title", "watermark"} and box.enabled and (
                    self.watermark_text if name == "watermark" else (self.title_text or self.part_text)):
                # Same size rule as the renderer (core.write_ass): fixed size, or fit the box.
                text = labels[name]
                bw, bh = box.w * (self.info or {}).get("width", 1920), box.h * vh
                px = self.overlay_size if self.overlay_size > 0 else max(18, min(round(bh * .55), round(bw / max(len(text), 1) * 1.6)))
                self.canvas.create_text(x + w / 2, y + h / 2, text=text, fill="white",
                                        font=(self.overlay_font, -max(6, int(px * scale)), "bold"))
                if name == self.selected.get():
                    self._draw_handle(x, y, w, h, color)
                continue
            if labels[name] or not box.enabled:
                self.canvas.create_text(x+5, y+5, text=(labels[name] or name.title()) + ("" if box.enabled else " (off)"),
                                        anchor="nw", fill="white", font=("Myanmar Text", 10, "bold"))
            if name == self.selected.get():
                self._draw_handle(x, y, w, h, color)
        box = getattr(self.layout, self.selected.get())
        self.coords.configure(text=f"{self.selected.get()}: x={box.x*100:.1f}%  y={box.y*100:.1f}%  "
                                   f"w={box.w*100:.1f}%  h={box.h*100:.1f}%  · drag to move, bottom-right corner to resize")

    def _draw_sample_subtitle(self, box, x, y, w, h, scale) -> None:
        """Sample cue with the renderer's own wrap/size rule (core.fit_subtitle), colours and stroke."""
        vw = (self.info or {}).get("width") or 1920
        vh = (self.info or {}).get("height") or 1080
        _bx, by, bw, bh = box.pixels(vw, vh)
        st = self.style
        size = max(22, min(100, int(self.font_size)))
        wrapped, size, padding, panel_h, _fits = fit_subtitle(SAMPLE_SUBTITLE, size, bw, by + bh)
        bottom = y + h
        if st["box_enabled"] and int(st["box_opacity"]) > 0:
            opacity = int(st["box_opacity"])
            stipple = ("" if opacity >= 85 else "gray75" if opacity >= 60 else "gray50" if opacity >= 35
                       else "gray25" if opacity >= 15 else "gray12")
            self.canvas.create_rectangle(x, bottom - panel_h * scale, x + w, bottom, fill=st["box_color"],
                                         outline="", stipple=stipple)
        # Negative Tk font size = pixels (positive would be points, ~1.33x larger).
        font = (self.subtitle_font, -max(6, int(size * scale)), "bold" if self.subtitle_bold else "normal")
        text = wrapped.replace("\\N", "\n")
        tx, ty = x + w / 2, bottom - padding * scale

        def put(dx, dy, color):
            self.canvas.create_text(tx + dx, ty + dy, text=text, fill=color, font=font, anchor="s", justify="center")

        shadow = int(st["shadow"]) * scale
        stroke = subtitle_outline(size, int(st["outline_width"])) * scale
        if shadow > 0:
            put(shadow + stroke * .7, shadow + stroke * .7, "#000000")
        if stroke > 0:
            r = max(1.0, stroke)
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (.7, .7), (-.7, .7), (.7, -.7), (-.7, -.7)):
                put(dx * r, dy * r, st["outline_color"])
        put(0, 0, st["text_color"])

    def _draw_handle(self, x, y, w, h, color) -> None:
        self.canvas.create_rectangle(x+w-8, y+h-8, x+w+4, y+h+4, fill=color, outline=color)

    def _selected_changed(self) -> None:
        self.enabled.set(getattr(self.layout, self.selected.get()).enabled)
        self._draw()

    def _toggle(self) -> None:
        getattr(self.layout, self.selected.get()).enabled = self.enabled.get()
        self._draw()
        self._save()

    def _press(self, event) -> None:
        self.drag_start = None
        ox, oy, fw, fh = self._frame_rect()
        for name in reversed(BOX_NAMES):
            box = getattr(self.layout, name)
            x, y, w, h = ox + box.x * fw, oy + box.y * fh, box.w * fw, box.h * fh
            if x <= event.x <= x+w+6 and y <= event.y <= y+h+6:
                self.selected.set(name)
                self.enabled.set(box.enabled)
                mode = "resize" if abs(event.x-(x+w)) < 18 and abs(event.y-(y+h)) < 18 else "move"
                self.drag_start = (event.x, event.y, box.x, box.y, box.w, box.h, mode)
                break
        self._draw()

    def _drag(self, event) -> None:
        if not self.drag_start:
            return
        ox, oy, fw, fh = self._frame_rect()
        px, py, x, y, w, h, mode = self.drag_start
        dx, dy = (event.x-px)/fw, (event.y-py)/fh
        box = getattr(self.layout, self.selected.get())
        if mode == "move":
            box.x = max(0, min(1-w, x+dx))
            box.y = max(0, min(1-h, y+dy))
        else:
            box.w = max(.05, min(1-x, w+dx))
            box.h = max(.035, min(1-y, h+dy))
        self._draw()

    def _release(self, _event) -> None:
        if self.drag_start:
            self._save()
        self.drag_start = None

    def _save(self) -> None:
        self.layout.save(self.layout_path)


class PreviewDialog(tk.Toplevel):
    """Pop-up wrapper kept for compatibility; the main window embeds PreviewPanel."""

    def __init__(self, parent: tk.Tk, video: Path, layout_path: Path,
                 title_text: str, part_text: str, watermark_text: str) -> None:
        super().__init__(parent)
        self.title("Preview & box positions")
        self.geometry("900x700")
        self.transient(parent)
        self.panel = PreviewPanel(self, layout_path)
        self.panel.pack(fill="both", expand=True, padx=10, pady=10)
        self.panel.set_texts(title_text, part_text, watermark_text)
        self.panel.set_video(video)
        ttk.Button(self, text="Save positions", command=self._close).pack(pady=(0, 10))

    def _close(self) -> None:
        self.panel._save()
        self.destroy()
