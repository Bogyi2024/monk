"""N-minute parts of a subtitled video: <job>\\parts_<N>min\\<stem>_part_01.mp4, 02, ...

- run() with Options.split_minutes renders each part as soon as every cue touching it is
  translated (PartRenderer), so a long video shows results while translation continues;
- _export() then renders whatever part is still missing (render_parts);
- `python -X utf8 export_parts.py <job> --minutes 4` exports the finished parts of a paused job.

A finished part is remade only when its subtitle text or timing changed (a manual review
edit). A new look (font, size, colours, layout, title) applies to the parts made after it, so
pressing Start again never re-renders finished parts; delete a part's MP4 to remake it.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import queue
import sys
import threading
import time
from dataclasses import replace
from pathlib import Path

from checkpoints import file_signature, load_job, read_json, write_json
from core import (TRANSLATION_PROFILE, Cue, _check_cancel, _clean_text, _find_program, ass_fonts, cue_identity,
                  part_label, probe_video, translation_identity, validate_myanmar_text, write_ass, write_srt)
from long_jobs import process

PARTS_PROFILE = "export_parts_v1"
# Parts are rendered while translation runs, so a fast preset; the full-video render uses medium.
PRESET = "veryfast"
# A tail shorter than this joins the previous part instead of becoming its own file.
MIN_LAST_PART = 15.0


def _clock(seconds: float) -> str:
    seconds = int(seconds)
    return f"{seconds // 3600}:{seconds % 3600 // 60:02d}:{seconds % 60:02d}"


def parts_folder(job: Path, minutes: float) -> Path:
    return Path(job) / f"parts_{float(minutes):g}min"


def part_plan(duration: float, minutes: float) -> list[tuple[int, float, float]]:
    """[(number, start, end)] covering the whole video."""
    length = float(minutes) * 60
    if length <= 0:
        raise ValueError("Part length must be above 0 minutes")
    starts = [index * length for index in range(max(1, math.ceil(duration / length)))]
    if len(starts) > 1 and duration - starts[-1] < MIN_LAST_PART:
        starts.pop()
    return [(number, start, starts[number] if number < len(starts) else duration)
            for number, start in enumerate(starts, 1)]


def _touching(cues: list[Cue], start: float, end: float) -> list[int]:
    return [index for index, cue in enumerate(cues) if cue.end > start and cue.start < end]


def _manual_overrides(job: Path) -> dict:
    return (read_json(Path(job) / "manual_review.json", {}) or {}).get("items") or {}


def render_part(options, info: dict, ffmpeg: str, out_dir: Path, number: int, start: float, end: float,
                cues: list[Cue], texts: list[str], width: int = 2, cancel=None, log=None,
                total: int = 0) -> tuple[Path, str]:
    """Write <stem>_part_NN.srt/.ass and render the MP4 if needed.

    Returns (path, state): "made" = rendered now, "same" = already up to date, "kept" = finished
    with an earlier look and the same subtitles, so left as it is.
    """
    video = options.video.expanduser().resolve()
    name = f"{video.stem}_part_{number:0{width}d}"
    out_dir.mkdir(parents=True, exist_ok=True)
    output, record, ass = out_dir / f"{name}.mp4", out_dir / f"{name}.json", out_dir / f"{name}.ass"
    # A cue crossing a boundary appears in both parts, cut at the boundary.
    local = [Cue(max(0.0, cues[i].start - start), min(end - start, cues[i].end - start), cues[i].source, texts[i])
             for i in _touching(cues, start, end)]
    write_srt(local, out_dir / f"{name}.srt")
    write_ass(local, ass, info["width"], info["height"], options.font_size, options.bottom_margin,
              options.layout, options.title, part_label(options.part, number), options.watermark,
              end - start, **ass_fonts(options))
    text = hashlib.sha256(json.dumps([[round(c.start, 3), round(c.end, 3), _clean_text(c.text)] for c in local],
                                     ensure_ascii=False).encode("utf-8")).hexdigest()
    identity = {"profile": PARTS_PROFILE, "input": file_signature(video), "start": start, "end": end,
                "ass": hashlib.sha256(ass.read_bytes()).hexdigest(), "text": text, "preset": PRESET}
    saved = read_json(record, {}) or {}
    old = saved.get("identity") or {}
    finished = (output.is_file() and saved.get("output") == file_signature(output)
                and all(old.get(key) == identity[key] for key in ("profile", "input", "start", "end")))
    if finished and old.get("ass") == identity["ass"]:
        return output, "same"
    # Records from before 2026-10-04 21:10 have no text hash; their text has not changed since.
    if finished and old.get("text", text) == text:
        if "text" not in old:
            write_json(record, {"identity": {**old, "text": text}, "output": saved["output"]})
        return output, "kept"
    if log:
        log(f"Rendering part {number}{f'/{total}' if total else ''} ({_clock(start)}–{_clock(end)})")
    _encode(video, ass, output, ffmpeg, info, options, start, end - start, cancel)
    write_json(record, {"identity": identity, "output": file_signature(output)})
    return output, "made"


def _encode(video: Path, ass: Path, output: Path, ffmpeg: str, info: dict, options,
            start: float, duration: float, cancel=None) -> None:
    from fonts import ass_filter

    cadence = f"fps={info.get('frame_rate') or '30'}:start_time=0"
    subtitles = ass_filter(ass, [options.subtitle_font, options.overlay_font])
    if options.layout and options.layout.blur.enabled:
        x, y, w, h = options.layout.blur.pixels(info["width"], info["height"])
        radius = max(1, min(18, (min(w, h) - 1) // 2))
        chroma = max(0, min(8, (min(w, h) - 2) // 4))
        filters = ["-filter_complex", f"[0:v]{cadence},split=2[base][copy];"
                   f"[copy]crop={w}:{h}:{x}:{y},boxblur={radius}:2:{chroma}:2[patch];"
                   f"[base][patch]overlay={x}:{y},{subtitles}[vout]", "-map", "[vout]"]
    else:
        filters = ["-vf", f"{cadence},{subtitles}", "-map", "0:v:0"]
    partial = output.with_name(output.stem + ".partial.mp4")
    try:
        # Input seek + re-encode is frame-accurate; the part's ASS times start at 0.
        process([ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{start:.3f}", "-i", str(video),
                 *filters, "-map", "0:a:0?", "-t", f"{duration:.3f}",
                 "-c:v", "libx264", "-preset", PRESET, "-crf", "20", "-pix_fmt", "yuv420p",
                 "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(partial)], cancel, cwd=ass.parent)
        if not partial.is_file() or partial.stat().st_size == 0:
            raise RuntimeError(f"{output.name}: FFmpeg produced no video")
        partial.replace(output)
    finally:
        partial.unlink(missing_ok=True)


class PartRenderer:
    """Renders part N in a background thread as soon as every cue touching it is translated."""

    def __init__(self, options, job: Path, cues: list[Cue], info: dict, ffmpeg: str, log, cancel=None) -> None:
        self.options, self.job, self.cues, self.info, self.ffmpeg = options, Path(job), cues, info, ffmpeg
        self.log, self.cancel = log, cancel
        self.plan = part_plan(info["duration"], options.split_minutes)
        self.width = max(2, len(str(len(self.plan))))
        self.rows = [_touching(cues, start, end) for _number, start, end in self.plan]
        self.out_dir = parts_folder(job, options.split_minutes)
        self.next = 0
        self.made = 0
        self.kept = 0
        self.failed: Exception | None = None
        self._queue: queue.Queue = queue.Queue()
        self._thread = threading.Thread(target=self._work, name="part-render", daemon=True)
        self._thread.start()
        log(f"Parts: {len(self.plan)} × {options.split_minutes:g} min → {self.out_dir} "
            f"(each one is made as soon as it is translated)")

    def update(self, texts: list[str]) -> None:
        """Called by translate_cues after each saved cue; queues newly finished parts in order."""
        try:
            overrides = None
            while self.next < len(self.plan) and all(texts[i] for i in self.rows[self.next]):
                if overrides is None:
                    overrides = _manual_overrides(self.job)
                final = list(texts)
                for i in self.rows[self.next]:
                    replacement = overrides.get(cue_identity(self.cues[i]))
                    if replacement:
                        final[i] = _clean_text(replacement)
                self._queue.put((self.plan[self.next], final))
                self.next += 1
        except Exception as exc:  # rendering problems must never stop translation
            self.log(f"Parts: could not queue part {self.next + 1}: {exc}")

    def pending(self) -> int:
        return self._queue.qsize()

    def _work(self) -> None:
        while True:
            item = self._queue.get()
            if item is None:
                return
            (number, start, end), texts = item
            if self.failed or (self.cancel and self.cancel.is_set()):
                continue
            began = time.monotonic()
            try:
                path, state = render_part(self.options, self.info, self.ffmpeg, self.out_dir, number, start, end,
                                          self.cues, texts, self.width, self.cancel, self.log, len(self.plan))
            except InterruptedError:
                continue
            except Exception as exc:
                self.failed = exc
                self.log(f"Part {number} could not be rendered now; it is tried again at the end: {str(exc)[:300]}")
                continue
            if state == "made":
                self.made += 1
                self.log(f"Part {number}/{len(self.plan)} saved in {time.monotonic() - began:.0f}s → {path.name}")
            elif state == "kept":
                self.kept += 1
                if self.kept == 1:
                    self.log("Finished parts are kept as they are; a new font/colour/layout applies to the next "
                             "parts (delete a part's MP4 to remake it with the new look)")

    def close(self) -> None:
        """Finish the queued parts (after Pause they are skipped), then stop the thread."""
        self._queue.put(None)
        self._thread.join()


def render_parts(options, job: Path, cues: list[Cue], info: dict, ffmpeg: str, log, progress,
                 cancel=None) -> list[Path]:
    """Every part of a fully translated video (cues carry the final text); finished parts are kept."""
    plan = part_plan(info["duration"], options.split_minutes)
    width = max(2, len(str(len(plan))))
    out_dir = parts_folder(job, options.split_minutes)
    texts = [cue.text for cue in cues]
    paths, states = [], []
    for index, (number, start, end) in enumerate(plan):
        _check_cancel(cancel)
        path, state = render_part(options, info, ffmpeg, out_dir, number, start, end, cues, texts, width, cancel,
                                  log, len(plan))
        paths.append(path)
        states.append(state)
        progress(82 + round(17 * (index + 1) / len(plan)), f"Part {number}/{len(plan)} ready")
    log(f"{len(plan)} parts in {out_dir} ({states.count('made')} rendered now, "
        f"{len(plan) - states.count('made')} already done)")
    return paths


def _audio_hints(job: Path, cues: list[Cue], options, language: str) -> list[dict]:
    """The same hints run() handed to translate_cues (they are part of each checkpoint key)."""
    if not options.audio_crosscheck or language in {"my", "mm"}:
        return []
    from audio_review import PROFILE, compare_cues

    data = read_json(job / "audio_review.json", {}) or {}
    signature = [[round(c.start, 3), round(c.end, 3), c.source] for c in cues]
    if (data.get("profile") == PROFILE and data.get("complete") and data.get("source") == signature
            and len(data.get("cues") or []) == len(cues)):
        return data["cues"]
    return compare_cues(cues, [])


def finished_translations(job: Path, options) -> tuple[list[Cue], list[str]]:
    """(source cues, Myanmar text per cue; "" = not translated yet), read from a job's checkpoints."""
    source = read_json(job / "source_cues.json", {}) or {}
    if not source.get("cues"):
        raise ValueError(f"{job} has no timed source cues yet")
    cues = [Cue(**row) for row in source["cues"]]
    language = str(source.get("language") or "")
    if language in {"my", "mm"}:
        return cues, [c.source for c in cues]
    speaker_file = job / "speaker_context.txt"
    speaker_context = (speaker_file.read_text(encoding="utf-8").strip() if speaker_file.is_file()
                       else options.speaker_context.strip())
    hints = _audio_hints(job, cues, options, language)
    stored = read_json(job / "partial_translations.json", {}) or {}
    checkpoint = (stored.get("items") or {}) if stored.get("profile") == TRANSLATION_PROFILE else {}
    overrides = _manual_overrides(job)
    texts = []
    for index, cue in enumerate(cues):
        identity = translation_identity(cues, index, speaker_context, hints)
        saved = read_json(job / "chunks" / "translations" / f"{identity}.json", {}) or {}
        text = checkpoint.get(identity, "")
        if saved.get("profile") == TRANSLATION_PROFILE:
            text = saved.get("text") or text
        text = overrides.get(cue_identity(cue)) or text
        try:
            validate_myanmar_text(text)
        except ValueError:
            text = ""
        texts.append(_clean_text(text))
    return cues, texts


def export_finished(job: Path, minutes: float = 4, part_text: str = "", limit: int = 0, log=print) -> dict:
    """Render the finished parts of a paused or stopped job (the job itself is only read)."""
    job = job.expanduser().resolve()
    options = replace(load_job(job), split_minutes=float(minutes))
    if part_text:
        options = replace(options, part=part_text)
    cues, texts = finished_translations(job, options)
    first_missing = next((i for i, text in enumerate(texts) if not text), len(cues))
    info = probe_video(options.video.expanduser().resolve(), _find_program("ffprobe"))
    ffmpeg = _find_program("ffmpeg")
    plan = part_plan(info["duration"], minutes)
    width = max(2, len(str(len(plan))))
    out_dir = parts_folder(job, minutes)
    done_until = cues[first_missing].start if first_missing < len(cues) else info["duration"]
    log(f"Translated {first_missing}/{len(cues)} cues in order · finished up to "
        f"{_clock(done_until)} of {_clock(info['duration'])}")
    ready, made = 0, 0
    for number, start, end in plan:
        if any(not texts[i] for i in _touching(cues, start, end)):
            break  # parts are numbered in order; stop at the first unfinished one
        ready += 1
        if limit and made >= limit:
            continue
        path, state = render_part(options, info, ffmpeg, out_dir, number, start, end, cues, texts, width,
                                  log=log, total=len(plan))
        if state == "made":
            made += 1
            log(f"Part {number} saved → {path.name}")
    if ready < len(plan):
        log(f"Parts ready: {ready} of {len(plan)} · the next part starts at {_clock(plan[ready][1])}")
    else:
        log(f"All {len(plan)} parts ready")
    return {"ready": ready, "made": made, "count": len(plan), "out_dir": str(out_dir), "done_until": done_until}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("job", type=Path, help="job folder (outputs\\<name>_mm_<id>)")
    parser.add_argument("--minutes", type=float, default=4, help="part length (default 4)")
    parser.add_argument("--part-text", default="",
                        help='Part text on the video, e.g. "အပိုင်း ({mm})"; {n}=1,2,3 {mm}=၁,၂,၃ (default: the job\'s)')
    parser.add_argument("--limit", type=int, default=0, help="render at most this many new parts")
    parser.add_argument("--dry-run", action="store_true", help="only report how far the job is finished")
    args = parser.parse_args()
    if args.dry_run:
        job = args.job.expanduser().resolve()
        cues, texts = finished_translations(job, load_job(job))
        first = next((i for i, t in enumerate(texts) if not t), len(cues))
        until = cues[first].start if first < len(cues) else cues[-1].end
        print(f"Translated {first}/{len(cues)} cues in order · finished up to {_clock(until)} · "
              f"{int(until // (args.minutes * 60))} full {args.minutes:g}-minute parts")
        return 0
    export_finished(args.job, args.minutes, args.part_text, args.limit)
    return 0


if __name__ == "__main__":
    sys.exit(main())
