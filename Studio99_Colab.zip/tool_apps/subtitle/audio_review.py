"""Use Gemini audio as an independent transcript check for Whisper-timed cues."""

from __future__ import annotations

import json
import subprocess
import tempfile
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path
from checkpoints import write_json


PROFILE = "gemini_audio_check_v5"


def _normalise(value: str) -> str:
    return " ".join(_words(value.casefold()))


def _words(value: str) -> list[str]:
    """Retain combining marks; expose CJK characters even without spaces."""
    words, token = [], ""
    for ch in value.replace("’", "'"):
        cjk = "\u3400" <= ch <= "\u9fff" or "\u3040" <= ch <= "\u30ff" or "\uac00" <= ch <= "\ud7af"
        if cjk:
            if token:
                words.append(token)
                token = ""
            words.append(ch)
        elif ch.isalnum() or unicodedata.category(ch).startswith("M") or ch == "'":
            token += ch
        elif token:
            words.append(token)
            token = ""
    if token:
        words.append(token)
    return words


def compare_cues(cues, rows: list[dict]) -> list[dict]:
    """Align Gemini's continuous transcript to Whisper words, never to Gemini row IDs."""
    ordered = sorted((row for row in rows if isinstance(row, dict) and str(row.get("id", "")).isdigit()),
                     key=lambda row: int(row["id"]))
    whisper_words, whisper_owner = [], []
    for index, cue in enumerate(cues):
        words = _words(cue.source.casefold())
        whisper_words.extend(words)
        whisper_owner.extend([index] * len(words))
    gemini_words, gemini_owner = [], []
    for row_index, row in enumerate(ordered):
        words = _words(str(row.get("transcript") or ""))
        gemini_words.extend(words)
        gemini_owner.extend([row_index] * len(words))
    anchors: list[list[int]] = [[] for _ in cues]
    for block in SequenceMatcher(None, whisper_words, [word.casefold() for word in gemini_words],
                                 autojunk=False).get_matching_blocks():
        for offset in range(block.size):
            anchors[whisper_owner[block.a + offset]].append(block.b + offset)
    checked = []
    for index, cue in enumerate(cues):
        matched = anchors[index]
        if matched:
            start, end = max(0, matched[0] - 2), min(len(gemini_words), matched[-1] + 3)
            previous = next((anchors[i][-1] for i in range(index - 1, -1, -1) if anchors[i]), None)
            following = next((anchors[i][0] for i in range(index + 1, len(cues)) if anchors[i]), None)
            if previous is not None:
                start = max(start, previous + 1)
            if following is not None:
                end = min(end, following)
            span = gemini_words[start:end]
            transcript = " ".join(span)
            owners = [gemini_owner[i] for i in range(start, end)]
            speakers = {str(ordered[i].get("speaker_id") or "").strip() for i in owners}
            genders = {str(ordered[i].get("voice_gender") or "unknown").lower().strip() for i in owners}
            # A cue spanning multiple voices must never inherit a majority speaker.
            row = {"speaker_id": next(iter(speakers)) if len(speakers) == 1 else "",
                   "voice_gender": next(iter(genders)) if len(genders) == 1 and len(speakers) == 1 else "unknown"}
        else:
            transcript, row = "", {}
        similarity = (SequenceMatcher(None, _normalise(cue.source), _normalise(transcript)).ratio()
                      if transcript else 0.0)
        speaker = str(row.get("speaker_id") or "").strip()[:24]
        gender = str(row.get("voice_gender") or "unknown").lower().strip()
        if gender not in {"male", "female", "unknown"}:
            gender = "unknown"
        reliable = bool(transcript and similarity >= 0.72 and
                        len(matched) / max(1, len(_words(cue.source))) >= 0.6)
        if not reliable:
            speaker, gender = "", "unknown"
        checked.append({
            "id": index, "start": cue.start, "end": cue.end,
            "whisper": cue.source, "gemini": transcript, "speaker_id": speaker,
            "voice_gender": gender, "similarity": round(similarity, 3),
            "use_for_translation": reliable,
            "needs_review": not reliable or not speaker or gender == "unknown",
        })
    return checked


def check_audio(video: Path, cues, job: Path, api_key: str, model: str,
                ffmpeg: str, log, cancel=None) -> list[dict]:
    cache = job / "audio_review.json"
    signature = [[round(c.start, 3), round(c.end, 3), c.source] for c in cues]
    # gemini-2.5-flash was retired (404 "no longer available", 2026-10-04).
    models = list(dict.fromkeys((model, "gemini-3.5-flash-lite", "gemini-3-flash-preview")))
    cached = None
    if cache.is_file():
        try:
            data = json.loads(cache.read_text(encoding="utf-8"))
            if data.get("profile") == PROFILE and data.get("model") in models and data.get("source") == signature:
                if len(data["cues"]) == len(cues):
                    cached = data["cues"]
                    if data.get("complete"):
                        log("Reusing Gemini audio transcript check")
                        return cached
        except (OSError, ValueError, KeyError, TypeError):
            pass
    from google import genai
    from google.genai import types

    if cancel and cancel.is_set():
        raise InterruptedError("Cancelled by user")
    groups: list[tuple[int, list]] = []
    for index, cue in enumerate(cues):
        if (not groups or len(groups[-1][1]) >= 18 or
                cue.end - groups[-1][1][0].start > 50):
            groups.append((index, []))
        groups[-1][1].append(cue)
    from gemini_keys import GeminiKeys, is_daily_quota, is_key_limited

    keys = api_key() if callable(api_key) else api_key
    if not isinstance(keys, GeminiKeys):
        keys = GeminiKeys([("key", str(keys))], log)
    checked: list[dict] = [dict(row) for row in cached] if cached else compare_cues(cues, [])
    if not cached:
        for row in checked:
            row["audio_available"] = False
    successful = 0

    def checkpoint(complete=False):
        write_json(cache, {"profile": PROFILE, "model": model, "source": signature,
                           "complete": complete, "cues": checked})
    try:
        with tempfile.TemporaryDirectory(prefix="subtitle_audio_") as directory:
            for group_number, (first_index, group) in enumerate(groups, 1):
                if cancel and cancel.is_set():
                    raise InterruptedError("Cancelled by user")
                previous = cached[first_index:first_index + len(group)] if cached else []
                if previous and all(row.get("audio_available") for row in previous):
                    checked[first_index:first_index + len(group)] = previous
                    successful += 1
                    continue
                offset = max(0.0, group[0].start - 0.5)
                duration = group[-1].end - offset + 0.5
                audio = Path(directory) / f"audio_{group_number}.mp3"
                subprocess.run([ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
                                "-ss", str(offset), "-i", str(video), "-t", str(duration),
                                "-vn", "-ac", "1", "-ar", "16000", "-b:a", "64k", str(audio)],
                               check=True, capture_output=True)
                prompt = (
                    "Independently transcribe all audible speech in this short audio clip. "
                    "The numbered time windows below are relative to this clip; another recognizer created them, "
                    "but its words are hidden. Do not translate or invent speech. "
                    "Assign speaker_id S1, S2 etc to distinguishable voices. "
                    "voice_gender means perceived vocal presentation only: male, female, or unknown; "
                    "use unknown when uncertain. Return JSON object "
                    "{\"cues\":[{\"id\":0,\"transcript\":\"...\",\"speaker_id\":\"S1\",\"voice_gender\":\"unknown\"}]} "
                    "with one row per ID, in spoken order.\n"
                    + json.dumps([{"id": i, "start": round(c.start - offset, 2),
                                   "end": round(c.end - offset, 2)} for i, c in enumerate(group)]))
                uploaded = None
                upload_client = None
                try:
                    failures = []
                    response = None
                    # An upload belongs to one project, so a key change needs a fresh upload.
                    for key_round in range(len(keys)):
                        client = keys.client()
                        if uploaded is None:
                            log(f"Uploading temporary audio chunk {group_number}/{len(groups)} to Gemini [{keys.label}]")
                            uploaded, upload_client = client.files.upload(file=str(audio)), client
                        key_limited = False
                        for candidate in models:
                            if cancel and cancel.is_set():
                                raise InterruptedError("Cancelled by user")
                            if keys.is_spent(keys.index, candidate):
                                continue  # this key already used today's quota for this model
                            try:
                                response = client.models.generate_content(
                                    model=candidate, contents=[prompt, uploaded],
                                    config=types.GenerateContentConfig(response_mime_type="application/json", temperature=0),
                                )
                                model = candidate
                                models = [candidate] + [name for name in models if name != candidate]
                                break
                            except Exception as exc:
                                failures.append(f"{candidate} [{keys.label}]: {str(exc)[:180]}")
                                # A per-day cap is per model: use the next model with the same upload
                                # instead of re-uploading the audio under every other key.
                                if is_daily_quota(exc):
                                    keys.mark_spent(keys.index, candidate)
                                    continue
                                if is_key_limited(exc) and key_round < len(keys) - 1:
                                    key_limited = True
                                    keys.rotate(exc)
                                    break
                                log(f"Gemini audio model {candidate} unavailable; trying fallback")
                        if response is not None or not key_limited:
                            break
                        try:
                            upload_client.files.delete(name=uploaded.name)
                        except Exception:
                            pass
                        uploaded = upload_client = None
                    if response is None:
                        raise RuntimeError("Audio transcript models unavailable: " + " | ".join(failures[-4:]))
                    rows = json.loads(str(getattr(response, "text", "") or ""))["cues"]
                    if not isinstance(rows, list):
                        raise ValueError("Gemini audio transcript has no cue list")
                    group_checked = compare_cues(group, rows)
                    if not any(row["gemini"] for row in group_checked):
                        raise ValueError("Gemini transcript could not be aligned to any source cue")
                    for row in group_checked:
                        row["audio_available"] = True
                        if row["speaker_id"]:
                            # Speaker numbering restarts for each independent audio request.
                            row["speaker_id"] = f"G{group_number}:{row['speaker_id']}"
                    successful += 1
                except InterruptedError:
                    raise
                except Exception as exc:
                    log(f"Audio chunk {group_number} unavailable; flagging for review: {exc}")
                    group_checked = compare_cues(group, [])
                    for row in group_checked:
                        row["audio_available"] = False
                finally:
                    if uploaded is not None and upload_client is not None:
                        try:
                            upload_client.files.delete(name=uploaded.name)
                        except Exception as exc:
                            log(f"Could not remove temporary Gemini upload: {exc}")
                for row in group_checked:
                    row["id"] += first_index
                checked[first_index:first_index + len(group)] = group_checked
                checkpoint()
        checkpoint(complete=successful == len(groups))
        log(f"Gemini audio checked {len(checked)} cues; {sum(r['needs_review'] for r in checked)} flagged")
        return checked
    finally:
        keys.close()
