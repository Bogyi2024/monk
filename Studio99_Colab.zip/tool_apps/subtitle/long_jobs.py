"""Bounded audio extraction and durable Whisper chunks for long videos."""
from __future__ import annotations

import math
import re
import subprocess
import tempfile
from pathlib import Path

from checkpoints import file_signature, read_json, write_json

CHUNK_PROFILE = "whisper_word_chunks_v1"
OVERLAP_SECONDS = 2.0


def process(command, cancel=None, cwd=None) -> str:
    from core import _check_cancel

    _check_cancel(cancel)
    child = subprocess.Popen(command, cwd=cwd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                             text=True, encoding="utf-8", errors="replace")
    try:
        while True:
            _check_cancel(cancel)
            try:
                _, stderr = child.communicate(timeout=.25)
                break
            except subprocess.TimeoutExpired:
                pass
    except BaseException:
        child.terminate()
        try:
            child.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            child.kill()
            child.communicate()
        raise
    if child.returncode:
        raise RuntimeError("FFmpeg failed: " + stderr[-2500:])
    return stderr


def chunk_plan(video, duration, seconds, ffmpeg, cancel=None):
    """Prefer silence within five seconds of each nominal cut; intervals stay contiguous."""
    if not math.isfinite(duration) or duration <= 0 or not math.isfinite(seconds) or seconds <= 0:
        raise ValueError("Video duration and chunk length must be positive")
    boundaries = [0.0]
    for index in range(1, math.ceil(duration / seconds)):
        nominal = index * seconds
        radius = min(5.0, seconds / 5)
        offset = max(0, nominal - radius)
        length = min(duration - offset, radius * 2)
        stderr = process([ffmpeg, "-hide_banner", "-nostats", "-ss", str(offset), "-i", str(video),
                          "-t", str(length), "-vn", "-af", "silencedetect=noise=-35dB:d=0.25",
                          "-f", "null", "-"], cancel)
        silences, start = [], None
        for match in re.finditer(r"silence_(start|end):\s*([\d.]+)", stderr):
            if match[1] == "start":
                start = float(match[2])
            elif start is not None:
                silences.append(offset + (start + float(match[2])) / 2)
                start = None
        cut = min(silences, key=lambda value: abs(value - nominal)) if silences else nominal
        if boundaries[-1] < cut < duration:
            boundaries.append(round(cut, 6))
    boundaries.append(duration)
    return [[a, b] for a, b in zip(boundaries, boundaries[1:])]


def owned_segments(rows, offset, start, end, duration):
    """Keep each word in one owning interval; timestamps remain on the original timeline."""
    result = []
    for row in rows:
        words = []
        for word in row.get("words") or []:
            a, b = float(word["start"]) + offset, float(word["end"]) + offset
            if start <= (a + b) / 2 < end and b > a:
                words.append({"word": word["word"], "start": round(max(0, a), 6),
                              "end": round(min(duration, b), 6)})
        if words:
            result.append({"start": words[0]["start"], "end": words[-1]["end"],
                           "text": "".join(word["word"] for word in words), "words": words})
        elif not row.get("words"):
            a, b = float(row["start"]) + offset, float(row["end"]) + offset
            if start <= (a + b) / 2 < end and b > a:
                result.append({"start": max(0, a), "end": min(duration, b), "text": row["text"], "words": []})
    return result


def merge_segments(chunks):
    """Remove only duplicated boundary words whose recognized time intervals overlap."""
    merged = []
    for rows in chunks:
        for row in rows:
            clean = dict(row)
            clean["words"] = []
            for word in row.get("words") or []:
                previous = next((part["words"][-1] for part in reversed(merged) if part["words"]), None)
                if clean["words"]:
                    previous = clean["words"][-1]
                if (previous and str(previous["word"]).strip().casefold() == str(word["word"]).strip().casefold()
                        and min(previous["end"], word["end"]) - max(previous["start"], word["start"]) >
                        .5 * min(previous["end"] - previous["start"], word["end"] - word["start"])):
                    continue
                clean["words"].append(word)
            if clean["words"] or not row.get("words"):
                merged.append(clean)
    return merged


def transcribe_chunks(video: Path, job: Path, duration: float, chunk_seconds: float,
                      model_name: str, language: str, ffmpeg: str, log, progress, cancel=None):
    from core import _check_cancel, cues_from_whisper_segments, transcribe_segments

    folder = job / "chunks" / "whisper"
    signature = {"profile": CHUNK_PROFILE, "input": file_signature(video), "seconds": chunk_seconds,
                 "model": model_name, "language": language}
    manifest = read_json(folder / "plan.json", {})
    if manifest.get("signature") == signature:
        plan = manifest["intervals"]
    else:
        log(f"Splitting audio into approximately {chunk_seconds / 60:g}-minute work chunks")
        plan = chunk_plan(video, duration, chunk_seconds, ffmpeg, cancel)
        write_json(folder / "plan.json", {"signature": signature, "intervals": plan})
    chunks, detected, model_cache = [], language, {}
    with tempfile.TemporaryDirectory(prefix="subtitle_whisper_") as temporary:
        audio = Path(temporary) / "chunk.wav"
        for index, (start, end) in enumerate(plan):
            _check_cancel(cancel)
            chunk_file = folder / f"{index:05d}.json"
            cached = read_json(chunk_file, {})
            identity = {"signature": signature, "interval": [start, end]}
            if cached.get("identity") == identity:
                rows, chunk_language = cached["segments"], cached["language"]
                log(f"Resume: Whisper chunk {index + 1}/{len(plan)} already saved")
            else:
                offset = max(0, start - OVERLAP_SECONDS)
                stop = min(duration, end + OVERLAP_SECONDS)
                log(f"Whisper chunk {index + 1}/{len(plan)}: {start / 60:.2f}–{end / 60:.2f} min")
                process([ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-ss", str(offset),
                         "-i", str(video), "-t", str(stop - offset), "-vn", "-ac", "1", "-ar", "16000",
                         "-c:a", "pcm_s16le", str(audio)], cancel)
                raw, chunk_language = transcribe_segments(audio, model_name, language, log, cancel,
                                                           model_cache=model_cache)
                rows = owned_segments(raw, offset, start, end, duration)
                write_json(chunk_file, {"identity": identity, "language": chunk_language, "segments": rows})
            if detected == "auto" and rows:
                detected = chunk_language
            chunks.append(rows)
            progress(5 + round(14 * (index + 1) / len(plan)), f"Whisper chunk {index + 1}/{len(plan)} saved")
    return cues_from_whisper_segments(merge_segments(chunks)), detected
