"""Gemini API key rotation for the subtitle tool.

A key whose project hit its quota (429 / RESOURCE_EXHAUSTED) or that is rejected
(401 / 403 / invalid key) is swapped for the next key before falling back to another
model. Only key labels are ever logged, never the key values.
"""
from __future__ import annotations

import os
import re
import threading
from pathlib import Path
from typing import Callable

_PROJECT_RE = re.compile(r"GEMINI_IMAGE_PROJECT_(\d+)_KEY")
# Project 15 was the subtitle tool's only key before rotation; keep it first.
_PREFERRED_PROJECT = 15
# Per request; without it a dropped connection could hang a cue for many minutes.
REQUEST_TIMEOUT_MS = 120_000
_KEY_LIMIT_TOKENS = (
    "429", "resource_exhausted", "quota", "rate limit", "rate_limit",
    "api key not valid", "api_key_invalid", "permission_denied", "unauthenticated", "401", "403",
)


def is_daily_quota(exc: BaseException) -> bool:
    """429 for the project's per-day request cap (e.g. gemini-3.5-flash free tier = 20/day).

    Waiting will not help until the next day, so that key + model is skipped for the run.
    """
    message = str(exc).lower()
    return "429" in message and "perday" in message.replace("_", "").replace(" ", "")


def is_key_limited(exc: BaseException) -> bool:
    """True when another API key (another project) may succeed where this one failed."""
    message = str(exc).lower()
    return any(token in message for token in _KEY_LIMIT_TOKENS)


def discover_keys(api_key: str = "", env_file: Path | None = None) -> list[tuple[str, str]]:
    """[(label, key)]: UI key, GEMINI_API_KEY, project 15, then the other projects in order."""
    found: list[tuple[str, str]] = []
    if str(api_key or "").strip():
        found.append(("UI key", api_key.strip()))
    if os.getenv("GEMINI_API_KEY", "").strip():
        found.append(("GEMINI_API_KEY (environment)", os.environ["GEMINI_API_KEY"].strip()))
    if env_file and Path(env_file).is_file():
        from dotenv import dotenv_values

        values = dotenv_values(env_file)
        if str(values.get("GEMINI_API_KEY") or "").strip():
            found.append(("GEMINI_API_KEY", str(values["GEMINI_API_KEY"]).strip()))
        numbers = sorted({int(m.group(1)) for m in (_PROJECT_RE.fullmatch(str(k or "").strip()) for k in values) if m})
        numbers.sort(key=lambda n: (n != _PREFERRED_PROJECT, n))
        for number in numbers:
            label = f"GEMINI_IMAGE_PROJECT_{number}_KEY"
            if str(values.get(label) or "").strip():
                found.append((label, str(values[label]).strip()))
    unique, seen = [], set()
    for label, key in found:
        if key not in seen:
            unique.append((label, key))
            seen.add(key)
    return unique


class GeminiKeys:
    """Key pool with lazily created clients.

    Translation calls current(model, spread=True): each request takes the next key in turn,
    so per-minute limits are shared across all projects instead of one key being hammered
    until it returns 429. Audio check keeps one key (its upload belongs to that project)
    and calls rotate() to move on. Routine 429s are counted, not logged line by line.
    """

    def __init__(self, keys: list[tuple[str, str]], log: Callable[[str], None] | None = None) -> None:
        if not keys:
            raise RuntimeError("Gemini API key missing. Enter one in the UI or select a .env file.")
        self.keys = list(keys)
        self.index = 0
        self._next = 0
        self.log = log or (lambda _msg: None)
        self._clients: dict[int, object] = {}
        self._lock = threading.Lock()  # translation runs several requests at once
        self._spent: set[tuple[int, str]] = set()  # (key index, model) out of daily quota
        self.rate_limited = 0  # 429s answered by trying another key (shown in summaries)

    def __len__(self) -> int:
        return len(self.keys)

    @property
    def label(self) -> str:
        return self.keys[self.index][0]

    def _client_for(self, index: int):
        if index not in self._clients:
            from google import genai

            self._clients[index] = genai.Client(api_key=self.keys[index][1],
                                                http_options={"timeout": REQUEST_TIMEOUT_MS})
        return self._clients[index]

    def current(self, model: str | None = None, spread: bool = False) -> tuple[int, object] | None:
        """(key index, client) for one request; None when every key spent its daily quota for model."""
        with self._lock:
            n = len(self.keys)
            start = self._next if spread else self.index
            for offset in range(n):
                index = (start + offset) % n
                if model is None or (index, model) not in self._spent:
                    if spread:
                        self._next = (index + 1) % n
                    self.index = index
                    return index, self._client_for(index)
            return None

    def client(self):
        return self.current()[1]

    def is_spent(self, index: int, model: str) -> bool:
        with self._lock:
            return (index, model) in self._spent

    def live_count(self, model: str) -> int:
        with self._lock:
            return sum(1 for i in range(len(self.keys)) if (i, model) not in self._spent)

    def mark_spent(self, index: int, model: str) -> None:
        with self._lock:
            if (index, model) in self._spent:
                return
            first = not any(m == model for _i, m in self._spent)
            self._spent.add((index, model))
            remaining = sum(1 for i in range(len(self.keys)) if (i, model) not in self._spent)
        # One line when a model starts running out and one when it is gone, not one per key.
        if first:
            self.log(f"{model}: today's free quota is used up on some keys; skipping those keys")
        if remaining == 0:
            self.log(f"{model}: today's free quota is used up on all {len(self.keys)} keys; using the next model")

    def rotate(self, reason: BaseException | str = "", from_index: int | None = None) -> str:
        """Move to the next key (counted; not logged). With from_index, only if nobody else moved."""
        with self._lock:
            self.rate_limited += 1
            if from_index is not None and from_index != self.index:
                return self.label
            self.index = (self.index + 1) % len(self.keys)
            return self.label

    def close(self) -> None:
        for client in self._clients.values():
            close = getattr(client, "close", None)
            if callable(close):
                try:
                    close()
                except Exception:
                    pass
        self._clients.clear()
