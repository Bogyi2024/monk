from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any

import requests
from dotenv import dotenv_values


class FalImageService:
    """Small standalone FAL queue client with paid-request checkpoint recovery."""

    def __init__(self, config: dict[str, Any], env_path: str | Path):
        self.config = dict(config)
        self.env_path = Path(env_path).resolve()
        values = dotenv_values(self.env_path)
        self.api_key = str(
            values.get("FAL_KEY") or values.get("FAL_API_KEY") or ""
        ).strip()
        if not self.api_key:
            raise RuntimeError(f"FAL_KEY missing in {self.env_path}")

    @staticmethod
    def _response_error(response: requests.Response) -> str:
        return f"HTTP {response.status_code}: {(response.text or '')[-2500:]}"

    def generate(
        self,
        prompt: str,
        save_path: str | Path,
        *,
        width: int,
        height: int,
    ) -> Path:
        save_path = Path(save_path)
        model = str(self.config.get("fal_model") or "fal-ai/flux/schnell").strip()
        steps = max(1, min(12, int(self.config.get("fal_num_inference_steps", 4))))
        guidance = float(self.config.get("fal_guidance_scale", 3.5))
        output_format = str(self.config.get("fal_output_format") or "jpeg").lower()
        timeout_seconds = max(60, int(self.config.get("fal_timeout_seconds", 240)))
        poll_interval = max(0.5, float(self.config.get("fal_poll_interval_seconds", 2.0)))
        if not (512 <= width <= 2048 and 512 <= height <= 2048):
            raise ValueError(f"FAL image size must be 512..2048 per side, got {width}x{height}")
        if model.rstrip("/") not in {"fal-ai/flux/schnell", "fal-ai/flux-1/schnell"}:
            raise ValueError(f"Standalone Novel only permits FLUX Schnell, got {model}")
        if output_format not in {"jpeg", "png", "webp"}:
            output_format = "jpeg"

        headers = {
            "Authorization": f"Key {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        payload = {
            "prompt": str(prompt).strip(),
            "image_size": {"width": width, "height": height},
            "num_images": 1,
            "output_format": output_format,
            "guidance_scale": guidance,
            "num_inference_steps": steps,
            "enable_safety_checker": True,
        }
        checkpoint = save_path.with_suffix(save_path.suffix + ".fal_queue.json")
        prompt_sha = hashlib.sha256(
            f"{model}\n{width}x{height}\n{prompt}".encode("utf-8")
        ).hexdigest()
        request_id = ""
        status_url = ""
        response_url = ""

        if checkpoint.exists() and not save_path.exists():
            try:
                saved = json.loads(checkpoint.read_text(encoding="utf-8"))
                if saved.get("prompt_sha") == prompt_sha and saved.get("model") == model:
                    request_id = str(saved.get("request_id") or "")
                    status_url = str(saved.get("status_url") or "")
                    response_url = str(saved.get("response_url") or "")
                    if status_url and response_url:
                        print(f"♻️ Novel FAL queue resume → {request_id} (no duplicate charge)")
            except Exception as exc:
                print(f"⚠️ Novel FAL checkpoint read warning: {exc}")

        if not status_url or not response_url:
            response = requests.post(
                f"https://queue.fal.run/{model}",
                headers=headers,
                json=payload,
                timeout=60,
            )
            if not response.ok:
                raise RuntimeError(f"FAL submit failed: {self._response_error(response)}")
            data = response.json()
            request_id = str(data.get("request_id") or "")
            status_url = str(data.get("status_url") or "")
            response_url = str(data.get("response_url") or "")
            if not status_url or not response_url:
                raise RuntimeError(f"FAL queue URLs missing: {data}")
            checkpoint.parent.mkdir(parents=True, exist_ok=True)
            checkpoint.write_text(
                json.dumps(
                    {
                        "request_id": request_id,
                        "status_url": status_url,
                        "response_url": response_url,
                        "prompt_sha": prompt_sha,
                        "model": model,
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
            print(
                f"🟣 Novel FAL FLUX.1 Schnell queued → {request_id} | "
                f"{width}x{height} | steps={steps}"
            )

        started = time.monotonic()
        transient_errors = 0
        final_status: dict[str, Any] = {}
        while time.monotonic() - started <= timeout_seconds:
            try:
                response = requests.get(
                    status_url,
                    headers={"Authorization": f"Key {self.api_key}", "Accept": "application/json"},
                    params={"logs": 1},
                    timeout=30,
                )
                if not response.ok:
                    if 400 <= response.status_code < 500:
                        checkpoint.unlink(missing_ok=True)
                        raise RuntimeError(self._response_error(response))
                    raise requests.RequestException(self._response_error(response))
                final_status = response.json()
                transient_errors = 0
            except RuntimeError:
                raise
            except Exception as exc:
                transient_errors += 1
                if transient_errors > 8:
                    raise RuntimeError(
                        f"FAL status unavailable; request preserved: {request_id}; {exc}"
                    ) from exc
                time.sleep(min(10.0, transient_errors * 2.0))
                continue
            state = str(final_status.get("status") or final_status.get("state") or "").upper()
            if state in {"COMPLETED", "SUCCESS"}:
                if final_status.get("error") or final_status.get("error_type"):
                    checkpoint.unlink(missing_ok=True)
                    raise RuntimeError(f"FAL generation failed: {final_status}")
                break
            if state in {"FAILED", "ERROR", "CANCELLED"}:
                checkpoint.unlink(missing_ok=True)
                raise RuntimeError(f"FAL generation failed: {final_status}")
            time.sleep(poll_interval)
        else:
            raise RuntimeError(f"FAL timeout; request preserved for resume: {request_id}")

        response_url = str(final_status.get("response_url") or response_url)
        result: dict[str, Any] | None = None
        last_error: Exception | None = None
        for attempt in range(1, 6):
            try:
                response = requests.get(
                    response_url,
                    headers={"Authorization": f"Key {self.api_key}", "Accept": "application/json"},
                    timeout=60,
                )
                if not response.ok:
                    if 400 <= response.status_code < 500:
                        checkpoint.unlink(missing_ok=True)
                        raise RuntimeError(self._response_error(response))
                    raise requests.RequestException(self._response_error(response))
                result = response.json()
                break
            except RuntimeError:
                raise
            except Exception as exc:
                last_error = exc
                if attempt < 5:
                    time.sleep(min(10.0, attempt * 2.0))
        if result is None:
            raise RuntimeError(
                f"FAL result unavailable; request preserved: {request_id}; {last_error}"
            )
        images = result.get("images") or []
        image_url = str(images[0].get("url") if images else "")
        if not image_url:
            raise RuntimeError(f"FAL result has no image URL: {result}")
        image_response = requests.get(image_url, timeout=120)
        image_response.raise_for_status()
        save_path.parent.mkdir(parents=True, exist_ok=True)
        save_path.write_bytes(image_response.content)
        checkpoint.unlink(missing_ok=True)
        print(f"✅ Novel FAL cover saved → {save_path}")
        return save_path
