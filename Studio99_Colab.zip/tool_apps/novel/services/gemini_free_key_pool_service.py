from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, TypeVar

from dotenv import dotenv_values
from google import genai
from google.genai import types


T = TypeVar("T")


@dataclass(frozen=True)
class GeminiFreeKeyEntry:
    alias: str
    env_name: str
    value: str


class GeminiFreeKeyPoolService:
    """Use only numbered free Gemini keys from one explicit env file."""

    _PROJECT_RE = re.compile(r"^GEMINI_IMAGE_PROJECT_(\d+)_KEY$", re.I)

    def __init__(
        self,
        env_path: str | Path,
        *,
        request_timeout_ms: int | None = None,
    ):
        self.env_path = Path(env_path).resolve()
        self.request_timeout_ms = (
            max(1_000, int(request_timeout_ms))
            if request_timeout_ms is not None
            else None
        )
        self.entries = self.discover_entries(self.env_path)
        if not self.entries:
            raise RuntimeError(
                f"No free Gemini key found in {self.env_path}. Add "
                "GEMINI_IMAGE_PROJECT_<N>_KEY; paid/process fallback is disabled."
            )
        self._clients: dict[str, Any] = {}
        self._disabled_for_run: set[str] = set()
        self._active_alias: str | None = None
        print(
            "🔑 Novel Gemini FREE pool: "
            + " → ".join(entry.alias for entry in self.entries)
            + " | paid fallback=OFF"
        )

    @classmethod
    def discover_entries(cls, env_path: str | Path) -> list[GeminiFreeKeyEntry]:
        values = dotenv_values(Path(env_path))
        ranked: list[tuple[int, GeminiFreeKeyEntry]] = []
        seen_values: set[str] = set()
        dedicated = str(values.get("GEMINI_TEXT_FREE_KEY") or "").strip()
        if dedicated:
            ranked.append((0, GeminiFreeKeyEntry("text_free", "GEMINI_TEXT_FREE_KEY", dedicated)))
            seen_values.add(dedicated)
        for raw_name, raw_value in values.items():
            env_name = str(raw_name or "").strip()
            value = str(raw_value or "").strip()
            match = cls._PROJECT_RE.match(env_name)
            if not match or not value or value in seen_values:
                continue
            number = int(match.group(1))
            ranked.append(
                (number + 1000, GeminiFreeKeyEntry(f"project_{number}", env_name, value))
            )
            seen_values.add(value)
        ranked.sort(key=lambda row: row[0])
        return [entry for _, entry in ranked]

    def _ordered_entries(self) -> list[GeminiFreeKeyEntry]:
        entries = [entry for entry in self.entries if entry.alias not in self._disabled_for_run]
        if self._active_alias:
            active = next((entry for entry in entries if entry.alias == self._active_alias), None)
            if active is not None:
                entries.remove(active)
                entries.insert(0, active)
        return entries

    def _client_for(self, entry: GeminiFreeKeyEntry):
        client = self._clients.get(entry.alias)
        if client is None:
            kwargs: dict[str, Any] = {"api_key": entry.value}
            if self.request_timeout_ms is not None:
                kwargs["http_options"] = types.HttpOptions(timeout=self.request_timeout_ms)
            client = genai.Client(**kwargs)
            self._clients[entry.alias] = client
        return client

    @staticmethod
    def _safe_error(exc: Exception) -> str:
        text = re.sub(r"([?&]key=)[^&\s]+", r"\1***", str(exc), flags=re.I)
        return text[-1200:]

    def call(self, operation: str, callback: Callable[[Any], T]) -> T:
        failures: list[str] = []
        for entry in self._ordered_entries():
            try:
                result = callback(self._client_for(entry))
                if self._active_alias != entry.alias:
                    print(f"✅ Novel Gemini FREE key active → {entry.alias} | operation={operation}")
                self._active_alias = entry.alias
                return result
            except Exception as exc:
                self._disabled_for_run.add(entry.alias)
                safe = self._safe_error(exc)
                failures.append(f"{entry.alias}: {safe}")
                print(f"⚠️ Novel Gemini FREE key unavailable → {entry.alias} | {safe}")
        raise RuntimeError(
            f"All free Gemini keys failed for {operation}; paid fallback is OFF. "
            + " | ".join(failures[-3:])
        )
