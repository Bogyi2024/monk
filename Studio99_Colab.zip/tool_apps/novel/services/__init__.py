"""Standalone Novel services."""
