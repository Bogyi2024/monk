from __future__ import annotations

import asyncio
import base64
import hashlib
import html
import json
import os
import random
import re
import tempfile
import time
import uuid
from datetime import date, timedelta
from pathlib import Path
from typing import Any

from google.genai import types
from PIL import Image, ImageDraw, ImageFilter

from services.fal_image_service import FalImageService
from services.gemini_free_key_pool_service import GeminiFreeKeyPoolService


class NovelStandaloneService:
    """Generate one original four-part Burmese novel as durable standalone artifacts."""

    PARTS_COUNT = 4
    MYANMAR_DIGITS = str.maketrans("0123456789", "၀၁၂၃၄၅၆၇၈၉")

    def __init__(
        self,
        config_path: str | Path = "config/novel.json",
        *,
        key_pool: GeminiFreeKeyPoolService | Any | None = None,
        project_root: str | Path | None = None,
    ):
        self.root = (
            Path(project_root).resolve()
            if project_root is not None
            else Path(__file__).resolve().parents[1]
        )
        raw_config_path = Path(config_path)
        self.config_path = (
            raw_config_path.resolve()
            if raw_config_path.is_absolute()
            else (self.root / raw_config_path).resolve()
        )
        if not self.config_path.exists():
            raise FileNotFoundError(f"Novel config missing: {self.config_path}")
        self.config = json.loads(self.config_path.read_text(encoding="utf-8"))
        self._validate_config()
        self.env_path = self._resolve_env_path()
        self.key_pool = key_pool or GeminiFreeKeyPoolService(
            env_path=self.env_path,
            request_timeout_ms=int(self.config.get("text_request_timeout_ms", 180000))
        )

    def _resolve_env_path(self) -> Path:
        local = self.root / ".env"
        if local.exists():
            return local.resolve()
        fallback = str(self.config.get("env_fallback_path") or "").strip()
        if fallback:
            path = Path(fallback)
            path = path.resolve() if path.is_absolute() else (self.root / path).resolve()
            if path.exists():
                print(f"🔐 Novel env migration fallback → {path}")
                return path
        return local.resolve()

    def _validate_config(self) -> None:
        if int(self.config.get("parts_count", 0)) != self.PARTS_COUNT:
            raise ValueError("Standalone Novel parts_count must be exactly 4")
        target = int(self.config.get("target_chars_per_part", 5000))
        minimum = int(self.config.get("min_chars_per_part", 4500))
        maximum = int(self.config.get("max_chars_per_part", 5500))
        if not (1 <= minimum <= target <= maximum):
            raise ValueError("Novel character limits must satisfy min <= target <= max")
        if int(self.config.get("max_thi_count_per_part", 6)) < 0:
            raise ValueError("Novel max_thi_count_per_part must be zero or greater")
        if float(self.config.get("max_thi_per_1000_chars", 1.5)) < 0:
            raise ValueError("Novel max_thi_per_1000_chars must be zero or greater")

    def _find_myanmar_font_file(self) -> Path:
        """Use the same Myanmar font preference as the proven Chromium renderers."""
        candidates: list[Path] = []
        for env_name in ("NOVEL_MM_FONT", "EPISODE_SPLITTER_MM_FONT"):
            value = str(os.environ.get(env_name) or "").strip()
            if value:
                candidates.append(Path(value))

        configured = str(self.config.get("myanmar_font") or "").strip()
        if configured:
            path = Path(configured)
            candidates.append(path if path.is_absolute() else self.root / path)

        for relative in (
            "assets/fonts/BURMA020-THIN.TTF",
            "assets/fonts/Burma020-Thin.ttf",
            "assets/fonts/Pyidaungsu-Regular.ttf",
            "assets/fonts/Pyidaungsu.ttf",
            "assets/fonts/NotoSansMyanmar-Regular.ttf",
            "assets/fonts/mmrtext.ttf",
            "fonts/BURMA020-THIN.TTF",
            "fonts/Burma020-Thin.ttf",
            "fonts/Pyidaungsu-Regular.ttf",
            "fonts/Pyidaungsu.ttf",
            "fonts/NotoSansMyanmar-Regular.ttf",
            "fonts/mmrtext.ttf",
        ):
            candidates.append(self.root / relative)

        local = os.environ.get("LOCALAPPDATA")
        user = os.environ.get("USERPROFILE")
        windir = os.environ.get("WINDIR", r"C:\Windows")
        user_font_dirs: list[Path] = []
        if local:
            user_font_dirs.append(Path(local) / "Microsoft/Windows/Fonts")
        if user:
            user_font_dirs.append(Path(user) / "AppData/Local/Microsoft/Windows/Fonts")
        exact_names = (
            "BURMA020-THIN.TTF",
            "Burma020-Thin.ttf",
            "Burma020-Light.ttf",
            "BURMA020-LIGHT.TTF",
            "Pyidaungsu.ttf",
            "NotoSansMyanmar-Regular.ttf",
            "mmrtext.ttf",
            "MyanmarText.ttf",
        )
        for folder in user_font_dirs:
            candidates.extend(folder / name for name in exact_names)
        win_fonts = Path(windir) / "Fonts"
        candidates.extend(win_fonts / name for name in exact_names)
        candidates.extend((
            Path("/usr/share/fonts/truetype/noto/NotoSansMyanmar-Regular.ttf"),
            Path("/usr/share/fonts/truetype/noto/NotoSansMyanmar-Bold.ttf"),
            Path("/usr/share/fonts/truetype/padauk/Padauk-Regular.ttf"),
            Path("/usr/share/fonts/truetype/padauk/PadaukBook-Regular.ttf"),
        ))

        legacy_cover_font = str(self.config.get("cover_font") or "").strip()
        if legacy_cover_font:
            path = Path(legacy_cover_font)
            candidates.append(path if path.is_absolute() else self.root / path)

        seen: set[str] = set()
        for path in candidates:
            key = str(path).casefold()
            if key in seen:
                continue
            seen.add(key)
            if path.is_file():
                return path.resolve()

        for folder in [*user_font_dirs, win_fonts]:
            if not folder.is_dir():
                continue
            try:
                found = sorted(
                    [
                        path for path in folder.iterdir()
                        if path.is_file()
                        and "burma020" in path.name.casefold().replace("-", "").replace("_", "")
                    ],
                    key=lambda path: (
                        "thin" not in path.name.casefold(),
                        "light" not in path.name.casefold(),
                        path.name.casefold(),
                    ),
                )
                if found:
                    return found[0].resolve()
            except OSError:
                pass
        raise FileNotFoundError(
            "No Myanmar font found for Novel Chromium rendering. "
            "Set NOVEL_MM_FONT to a Unicode Myanmar .ttf/.otf file."
        )

    @staticmethod
    def _browser_candidates(playwright: Any):
        """Match the shared Chromium -> Chrome -> Edge production fallback order."""
        yield (
            "playwright-chromium",
            lambda: playwright.chromium.launch(headless=True, timeout=60_000),
        )
        yield (
            "google-chrome-channel",
            lambda: playwright.chromium.launch(channel="chrome", headless=True, timeout=60_000),
        )
        yield (
            "msedge-channel",
            lambda: playwright.chromium.launch(channel="msedge", headless=True, timeout=60_000),
        )

        paths: list[Path] = []
        program_files = os.environ.get("PROGRAMFILES")
        program_files_x86 = os.environ.get("PROGRAMFILES(X86)")
        local = os.environ.get("LOCALAPPDATA")
        if program_files:
            paths.extend((
                Path(program_files) / "Google/Chrome/Application/chrome.exe",
                Path(program_files) / "Microsoft/Edge/Application/msedge.exe",
            ))
        if program_files_x86:
            paths.extend((
                Path(program_files_x86) / "Google/Chrome/Application/chrome.exe",
                Path(program_files_x86) / "Microsoft/Edge/Application/msedge.exe",
            ))
        if local:
            paths.extend((
                Path(local) / "Google/Chrome/Application/chrome.exe",
                Path(local) / "Microsoft/Edge/Application/msedge.exe",
            ))
        paths.extend((Path("/usr/bin/chromium"), Path("/usr/bin/google-chrome")))

        seen: set[str] = set()
        for executable in paths:
            key = str(executable).casefold()
            if key in seen or not executable.is_file():
                continue
            seen.add(key)
            yield (
                str(executable),
                lambda executable=executable: playwright.chromium.launch(
                    executable_path=str(executable), headless=True, timeout=60_000
                ),
            )

    @classmethod
    def _launch_chromium(cls, playwright: Any) -> tuple[Any, str]:
        errors: list[str] = []
        for label, launcher in cls._browser_candidates(playwright):
            try:
                return launcher(), label
            except Exception as exc:
                errors.append(f"{label}: {type(exc).__name__}: {str(exc)[-180:]}")
        raise RuntimeError(
            "No Chromium/Chrome/Edge browser could be launched for Novel Myanmar rendering. "
            + " | ".join(errors[-4:])
        )

    def _myanmar_font_face(self) -> tuple[Path, str]:
        font_path = self._find_myanmar_font_file()
        font_b64 = base64.b64encode(font_path.read_bytes()).decode("ascii")
        return font_path, (
            "@font-face{font-family:'NovelMyanmar';"
            f"src:url(data:font/ttf;base64,{font_b64}) format('truetype');"
            "font-style:normal;font-weight:100 900;font-display:block;}"
        )

    @staticmethod
    def _wait_for_myanmar_font(page: Any) -> None:
        status = page.evaluate(
            "async () => { await document.fonts.ready; "
            "return {status: document.fonts.status, loaded: document.fonts.check(\"32px NovelMyanmar\")}; }"
        )
        if not isinstance(status, dict) or status.get("status") != "loaded" or not status.get("loaded"):
            raise RuntimeError("Novel Myanmar web font did not finish loading in Chromium")

    @staticmethod
    def _atomic_json(path: Path, data: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        os.close(fd)
        tmp = Path(name)
        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            os.replace(tmp, path)
        finally:
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass

    @staticmethod
    def _parse_json(raw: str) -> dict[str, Any]:
        text = str(raw or "").strip()
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
        text = re.sub(r"\s*```$", "", text)
        start, end = text.find("{"), text.rfind("}")
        if start < 0 or end < start:
            raise ValueError("Gemini returned no JSON object")
        data = json.loads(text[start : end + 1])
        if not isinstance(data, dict):
            raise ValueError("Gemini JSON root must be an object")
        return data

    @staticmethod
    def count_story_chars(text: str) -> int:
        """Count visible non-whitespace characters; titles/metadata are excluded."""
        return len(re.sub(r"\s+", "", str(text or "")))

    @classmethod
    def style_stats(cls, text: str) -> dict[str, Any]:
        """Return measurable Burmese prose-style stats for the publishing gate."""
        value = str(text or "")
        chars = cls.count_story_chars(value)
        thi_count = value.count("သည်")
        return {
            "visible_chars": chars,
            "thi_count": thi_count,
            "thi_per_1000_chars": round((thi_count * 1000.0 / chars), 3) if chars else 0.0,
            "tae_count": value.count("တယ်"),
            "par_tae_count": value.count("ပါတယ်"),
        }

    def validate_prose_style(self, text: str) -> tuple[bool, dict[str, Any], str]:
        stats = self.style_stats(text)
        maximum_count = int(self.config.get("max_thi_count_per_part", 6))
        maximum_rate = float(self.config.get("max_thi_per_1000_chars", 1.5))
        ok = (
            int(stats["thi_count"]) <= maximum_count
            and float(stats["thi_per_1000_chars"]) <= maximum_rate
        )
        reason = "" if ok else (
            f"formal 'သည်' overuse: {stats['thi_count']} occurrences / "
            f"{stats['thi_per_1000_chars']} per 1000 chars; "
            f"limits are {maximum_count} and {maximum_rate}"
        )
        return ok, stats, reason

    @staticmethod
    def _clean_text(value: Any) -> str:
        text = str(value or "").strip()
        text = re.sub(r"^```(?:text)?\s*", "", text, flags=re.I)
        text = re.sub(r"\s*```$", "", text)
        return text.strip()

    async def _generate_json(
        self,
        *,
        operation: str,
        prompt: str,
        schema: dict[str, Any],
        temperature: float,
    ) -> dict[str, Any]:
        model = str(self.config.get("text_model") or "gemini-3-flash-preview")

        def call():
            return self.key_pool.call(
                operation,
                lambda client: client.models.generate_content(
                    model=model,
                    contents=prompt,
                    config=types.GenerateContentConfig(
                        temperature=temperature,
                        response_mime_type="application/json",
                        response_schema=schema,
                    ),
                ),
            )

        response = await asyncio.to_thread(call)
        return self._parse_json(str(getattr(response, "text", "") or ""))

    @staticmethod
    def _blueprint_schema() -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "genre": {"type": "string"},
                "hook": {"type": "string"},
                "premise": {"type": "string"},
                "character_bible": {"type": "string"},
                "four_part_outline": {
                    "type": "array",
                    "minItems": 4,
                    "maxItems": 4,
                    "items": {
                        "type": "object",
                        "properties": {
                            "part_no": {"type": "integer"},
                            "part_title": {"type": "string"},
                            "opening": {"type": "string"},
                            "key_events": {"type": "array", "items": {"type": "string"}},
                            "ending_beat": {"type": "string"},
                        },
                        "required": ["part_no", "part_title", "opening", "key_events", "ending_beat"],
                    },
                },
                "cover_prompt": {"type": "string"},
            },
            "required": ["title", "genre", "hook", "premise", "character_bible", "four_part_outline", "cover_prompt"],
        }

    @staticmethod
    def _episode_schema() -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "episode_text": {"type": "string"},
                "episode_summary": {"type": "string"},
                "continuity_notes": {"type": "string"},
            },
            "required": ["episode_text", "episode_summary", "continuity_notes"],
        }

    def _validate_blueprint(self, data: dict[str, Any]) -> dict[str, Any]:
        title = self._clean_text(data.get("title"))
        genre = self._clean_text(data.get("genre"))
        hook = self._clean_text(data.get("hook"))
        premise = self._clean_text(data.get("premise"))
        character_bible = self._clean_text(data.get("character_bible"))
        cover_prompt = re.sub(r"\s+", " ", str(data.get("cover_prompt") or "")).strip()
        outline = data.get("four_part_outline") or []
        if not title or not genre or not hook or not premise or not character_bible or not cover_prompt:
            raise ValueError("Novel blueprint is missing required text")
        hook_count = self.count_story_chars(hook)
        if hook_count < 45 or hook_count > 260:
            raise ValueError(f"Novel hook must be 45..260 visible characters, got {hook_count}")
        if not isinstance(outline, list) or len(outline) != self.PARTS_COUNT:
            raise ValueError("Novel blueprint must contain exactly four outline parts")
        cleaned_outline: list[dict[str, Any]] = []
        for expected, row in enumerate(outline, 1):
            if not isinstance(row, dict) or int(row.get("part_no") or 0) != expected:
                raise ValueError(f"Novel outline part sequence invalid at {expected}")
            events = [self._clean_text(x) for x in row.get("key_events") or [] if self._clean_text(x)]
            if len(events) < 2:
                raise ValueError(f"Novel outline part {expected} needs at least two key events")
            part_title = self._clean_text(row.get("part_title"))
            opening = self._clean_text(row.get("opening"))
            ending_beat = self._clean_text(row.get("ending_beat"))
            if not part_title or not opening or not ending_beat:
                raise ValueError(f"Novel outline part {expected} is missing required story beats")
            cleaned_outline.append({
                "part_no": expected,
                "part_title": part_title,
                "opening": opening,
                "key_events": events,
                "ending_beat": ending_beat,
            })
        return {
            "title": title,
            "genre": genre,
            "hook": hook,
            "premise": premise,
            "character_bible": character_bible,
            "four_part_outline": cleaned_outline,
            "cover_prompt": cover_prompt,
        }

    async def _generate_blueprint(self, genre: str, story_seed: str = "") -> dict[str, Any]:
        requested_story = self._clean_text(story_seed)
        prompt = f"""
မင်းက မူရင်းမြန်မာဝတ္ထုရေးဆရာတစ်ယောက်ပါ။ ဇာတ်ကောင်နာမည်နှင့် အသေးစိတ်များကို မင်းကိုယ်တိုင်ဖန်တီးပါ။
Genre: {genre}
အသုံးပြုသူလိုချင်သော ဇာတ်လမ်းအကျဉ်း: {requested_story or "မပေးထားပါ — genre နဲ့ကိုက်ညီသော original plot ကို အလိုအလျောက်ဖန်တီးပါ။"}

အကျဉ်းပေးထားလျှင် အဓိက premise၊ relationship နှင့်လိုချင်သောဖြစ်ရပ်ကို မဖျက်ဘဲ ပိုမိုကောင်းမွန်သော four-part plot အဖြစ်ချဲ့ပါ။

အောက်ပါအရာအားလုံးကို မင်းကိုယ်တိုင် အသစ်ဖန်တီးပါ။
- မှတ်မိလွယ်ပြီး သဘာဝကျသော မြန်မာဇာတ်ကောင်နာမည်များ
- ဇာတ်ကောင်အသက်၊ စရိုက်၊ ဆက်ဆံရေး၊ အလုပ်အကိုင်နှင့် မပြောင်းလဲရမည့်အချက်များ
- မူပိုင်ခွင့်ရှိ ဝတ္ထု၊ ရုပ်ရှင်၊ viral story တစ်ခုခုကို မကူးသော original plot
- အပိုင်းလေးပိုင်းတိတိဖြင့် ဇာတ်သိမ်းနိုင်မည့် အစမှအဆုံး outline

HOOK ကို အထူးတင်းကြပ်စွာရေးပါ:
- hook field က ၁–၃ ဝါကျ၊ visible characters 45–260 အတွင်းဖြစ်ရမည်။
- အပိုင်း (၁) ရဲ့ ပထမဆုံးစာကြောင်းအဖြစ် တိုက်ရိုက်သုံးနိုင်ရမည်။ နောက်ခံသမိုင်းဖြင့် ဖြည်းဖြည်းမစရ။
- သရဲ/Horror ဆိုလျှင် ပထမအခိုက်မှာ မဖြစ်နိုင်သည့်ကြောက်မက်ဖွယ်ဖြစ်ရပ် သို့မဟုတ် အသက်အန္တရာယ်ကိုပြပါ။
- Thriller ဆိုလျှင် လျှို့ဝှက်ချက်၊ လိုက်လံခြိမ်းခြောက်မှု၊ သက်သေ သို့မဟုတ် အချိန်ကန့်သတ်အန္တရာယ်ကိုချက်ချင်းပြပါ။
- အိမ်ထောင်ရေးဖောက်ပြန်မှုဆိုလျှင် မိမိအရင်းနှီးဆုံးသူနှင့် ဖောက်ပြန်နေသောသက်သေ၊ ဖုန်းစာ၊ ဟိုတယ်ခန်း သို့မဟုတ် မထင်မှတ်သောကိုယ်ဝန်ကဲ့သို့ အိမ်ထောင်ရေးကိုချက်ချင်းပေါက်ကွဲစေမည့်တွေ့ရှိမှုဖြင့်စပါ။
- Clickbait နီးပါး curiosity gap ပြင်းရမည်၊ သို့သော် ဇာတ်လမ်းထဲတွင် အမှန်တကယ်ဖြစ်မည့်အရာကိုသာ ကတိပေးရမည်။ အလိမ်အညာမလုပ်ရ။
- “တစ်ခါတုန်းက”၊ ရာသီဥတု၊ အခန်းအလှ၊ ဇာတ်ကောင်၏နေ့စဉ်လုပ်ရိုးလုပ်စဉ်ဖြင့် မစရ။

Four-part arc ကိုတိတိကျကျလိုက်နာပါ။
1. အပိုင်း (၁): hook field ထဲက ပြင်းထန်သောဖြစ်ရပ်ကို opening အဖြစ်သုံး၊ ဇာတ်ကောင်/ပဋိပက္ခမိတ်ဆက်၊ ဆက်ဖတ်ချင်စေမည့် ending beat
2. အပိုင်း (၂): ပြဿနာပိုကြီးလာခြင်း၊ ဆက်ဆံရေး/လျှို့ဝှက်ချက်တိုးတက်ခြင်း၊ မပြေလည်သေးသော ending beat
3. အပိုင်း (၃): အဓိက twist၊ peak drama နီးကပ်ခြင်း၊ နောက်ဆုံးဆုံးဖြတ်ချက်မတိုင်မီ ending beat
4. အပိုင်း (၄): အကြောင်းရင်းနှင့်အကျိုးဆက်အားလုံးဖြေရှင်း၍ အပြည့်အဝဇာတ်သိမ်းပါ။ နောက်အပိုင်း tease မထားရ။

cover_prompt ကို English cinematic prompt အဖြစ်ရေးပါ။ အဓိကဇာတ်ကောင်များ၏ မျက်နှာ၊ အသက်၊ ဆံပင်၊ အဝတ်အစားနှင့် mood တိတိကျကျပါစေ။
Cover သည် non-graphic, fully clothed adult characters ပါသောပုံဖြစ်ရမည်။ Horror ဆိုလည်း eerie setting, shadow, fog, symbolic objects ဖြင့်သာဖော်ပြပါ။ Blood, visible injury, severed body parts, gore, nudity သို့ explicit sexual imagery မပါရ။
Cover ထဲတွင် text, letters, title, number, watermark, logo မပါရ။
JSON schema အတိုင်းသာပြန်ပေးပါ။
""".strip()
        retries = max(1, int(self.config.get("generation_retries", 3)))
        last_exc: Exception | None = None
        for attempt in range(1, retries + 1):
            try:
                raw = await self._generate_json(
                    operation="novel_blueprint",
                    prompt=prompt,
                    schema=self._blueprint_schema(),
                    temperature=0.85,
                )
                return self._validate_blueprint(raw)
            except Exception as exc:
                last_exc = exc
                print(f"⚠️ Novel blueprint validation retry {attempt}/{retries}: {exc}")
                await asyncio.sleep(min(attempt * 2, 5))
        raise RuntimeError(f"Novel blueprint generation failed: {last_exc}")

    async def _generate_part(
        self,
        *,
        blueprint: dict[str, Any],
        part_no: int,
        previous_parts: list[dict[str, Any]],
    ) -> dict[str, Any]:
        target = int(self.config.get("target_chars_per_part", 5000))
        minimum = int(self.config.get("min_chars_per_part", 4500))
        maximum = int(self.config.get("max_chars_per_part", 5500))
        outline = blueprint["four_part_outline"][part_no - 1]
        previous_context = [
            {
                "part_no": int(row.get("part_no", 0)),
                "summary": str(row.get("episode_summary") or ""),
                "continuity_notes": str(row.get("continuity_notes") or ""),
            }
            for row in previous_parts
        ]
        ending_rule = (
            "ဒီအပိုင်းက နောက်ဆုံးအပိုင်းဖြစ်သည်။ မဖြေရှင်းရသေးသော အဓိကပြဿနာအားလုံးကို ဇာတ်လမ်းသဘာဝအတိုင်းပိတ်ပါ။ "
            "'နောက်အပိုင်းတွင်'၊ sequel tease သို့မဟုတ် cliffhanger လုံးဝမထားရ။"
            if part_no == self.PARTS_COUNT
            else "Outline ရဲ့ ending_beat မှာပိတ်ပြီး နောက်အပိုင်းဖတ်ချင်စေပါ။ နောက်ပိုင်းဖြစ်ရပ်ကို ကြိုမဖော်ရ။"
        )
        hook = self._clean_text(blueprint.get("hook"))
        hook_rule = (
            f"အပိုင်း (၁) ၏ episode_text ကို အောက်ပါ locked hook နဲ့ စာလုံးတစ်လုံးမပြောင်းဘဲ တန်းစပါ။ "
            f"Hook ပြီးမှ context ကိုရှင်းပါ။ ဖြည်းဖြည်းမစရ။\nLOCKED HOOK: {hook}"
            if part_no == 1
            else "ဒီအပိုင်း၏ ပထမစာပိုဒ်ကိုလည်း ချက်ချင်းဖြစ်ပျက်နေသော conflict/reveal ဖြင့်စပါ။"
        )
        repair_context = ""
        retries = max(
            1,
            int(
                self.config.get(
                    "part_generation_retries",
                    self.config.get("generation_retries", 3),
                )
            ),
        )
        last_exc: Exception | None = None
        best_draft: dict[str, Any] | None = None

        for attempt in range(1, retries + 1):
            prompt = f"""
မင်းက မြန်မာဝတ္ထုရှည်ရေးရာမှာ ကျွမ်းကျင်တဲ့ စာရေးဆရာတစ်ယောက်ပါ။
အောက်က locked series bible နဲ့ outline ကို မပြောင်းဘဲ အပိုင်း ({part_no}) ကိုရေးပါ။

LOCKED SERIES BLUEPRINT:
{json.dumps(blueprint, ensure_ascii=False)}

THIS PART OUTLINE:
{json.dumps(outline, ensure_ascii=False)}

PREVIOUS PART SUMMARIES AND CONTINUITY:
{json.dumps(previous_context, ensure_ascii=False) if previous_context else "အပိုင်း (၁) ဖြစ်သောကြောင့် မရှိသေးပါ။"}

တင်းကြပ်သောရေးဟန်စည်းကမ်းများ:
1. episode_text သက်သက်ကို မြန်မာ visible characters {minimum}–{maximum} အတွင်းရေးပြီး {target} ဝန်းကျင်ကိုရည်ရွယ်ပါ။ ခေါင်းစဉ်နဲ့ summary ကို character count ထဲမထည့်ပါနှင့်။
2. Facebook မှာ လူတစ်ယောက်ပြောပြသလို သဘာဝကျတဲ့ခေတ်ပေါ်မြန်မာစကားပြေကို သုံးပါ။ ဝါကျအဆုံးကို “တယ်၊ ပါတယ်၊ ခဲ့တယ်၊ နေတယ်၊ ဖြစ်တယ်၊ လိုက်တယ်” စသဖြင့် သဘာဝကျကျပြောင်းသုံးပါ။ episode_text တစ်ပိုင်းလုံးမှာ “သည်” ကို {int(self.config.get('max_thi_count_per_part', 6))} ကြိမ်ထက် မပိုရ။ “သည်” ဆက်တိုက်သုံးသော အစီရင်ခံစာ/ဘာသာပြန်စာဟန် လုံးဝမရေးရ။
3. စာစီစာကုံး summary ပုံစံမရေးဘဲ scene၊ action၊ reaction၊ dialogue နဲ့ခံစားချက်များပါသော ဝတ္ထုပုံစံရေးပါ။
4. ဇာတ်ကောင်အမည်၊ အသက်၊ စရိုက်၊ ဆက်ဆံရေး၊ အတိတ်ဖြစ်ရပ်နဲ့နေရာတွေကို blueprint/ရှေ့အပိုင်းနဲ့ မလွဲရ။
5. အပိုင်းမတူဘဲ ဖြစ်ရပ်တူကို ပြန်ရေးတာ၊ filler ထည့်တာ၊ စကားတစ်မျိုးတည်းထပ်ခါထပ်ခါသုံးတာ မလုပ်ရ။
6. “ဟုတ်ကဲ့ပါ”၊ “ရေးပေးလိုက်ပါတယ်”၊ စာရေးသူရှင်းလင်းချက်၊ Markdown heading မပါရ။
7. မူပိုင်ခွင့်ရှိ ဝတ္ထု၊ ရုပ်ရှင် သို့ viral story ကိုမကူးရ။ Original ဖြစ်ရမည်။
8. {ending_rule}
9. episode_summary မှာ ဒီအပိုင်း၏ continuity အတွက်လိုအပ်သောဖြစ်ရပ်များကို 6–10 ဝါကျဖြင့်ရေးပါ။
10. continuity_notes မှာ နောက်အပိုင်းတွင် မပြောင်းရမည့် ဇာတ်ကောင်အခြေအနေ၊ ပစ္စည်း၊ လျှို့ဝှက်ချက်နှင့် relationship state ကိုတိုတောင်းစွာမှတ်တမ်းတင်ပါ။
11. {hook_rule}
{repair_context}

JSON schema အတိုင်းသာပြန်ပေးပါ။
""".strip()
            try:
                raw = await self._generate_json(
                    operation=f"novel_part_{part_no}",
                    prompt=prompt,
                    schema=self._episode_schema(),
                    temperature=0.72,
                )
                text = self._clean_text(raw.get("episode_text"))
                summary = self._clean_text(raw.get("episode_summary"))
                notes = self._clean_text(raw.get("continuity_notes"))
                if part_no == 1 and hook and not text.startswith(hook):
                    text = f"{hook}\n\n{text}"
                count = self.count_story_chars(text)
                if not text or not summary or not notes:
                    raise ValueError("episode_text/summary/continuity_notes missing")
                candidate = {
                    "episode_text": text,
                    "episode_summary": summary,
                    "continuity_notes": notes,
                    "char_count": count,
                    "style_stats": self.style_stats(text),
                }
                if best_draft is None or abs(count - target) < abs(
                    int(best_draft["char_count"]) - target
                ):
                    best_draft = candidate
                if count < minimum or count > maximum:
                    raise ValueError(f"part {part_no} character count {count} outside {minimum}..{maximum}")
                style_ok, style_stats, style_reason = self.validate_prose_style(text)
                if not style_ok:
                    raise ValueError(f"part {part_no} style gate failed: {style_reason}")
                return {
                    "part_no": part_no,
                    "part_title": str(outline.get("part_title") or f"အပိုင်း {part_no}"),
                    "episode_text": text,
                    "episode_summary": summary,
                    "continuity_notes": notes,
                    "char_count": count,
                    "style_stats": style_stats,
                }
            except Exception as exc:
                last_exc = exc
                match = re.search(r"character count (\d+)", str(exc))
                current = int(match.group(1)) if match else 0
                if "style gate failed" in str(exc) and best_draft:
                    maximum_count = int(self.config.get("max_thi_count_per_part", 6))
                    repair_context = f"""
STYLE REPAIR MODE — အသစ်ကနေပြန်မစပါနှင့်။
ရှေ့ draft ၏ plot၊ locked hook၊ ဇာတ်ကောင်အမည်၊ ဖြစ်ရပ်အစဉ်၊ dialogue အဓိပ္ပာယ်၊ ending beat နှင့် အရှည်ကို ထိန်းထားပါ။
စာတစ်ပုဒ်လုံးကို ခေတ်ပေါ်မြန်မာစကားပြေအဖြစ် ပြန်တည်းဖြတ်ပါ။ “သည်” ကို စက်ရုပ်လို တိုက်ရိုက်အစားထိုးတာမလုပ်ဘဲ ဝါကျတစ်ကြောင်းချင်း သဘာဝကျအောင် “တယ်/ပါတယ်/ခဲ့တယ်/နေတယ်/ဖြစ်တယ်/လိုက်တယ်” စသည့်အဆုံးသတ်များဖြင့် ပြန်ဖွဲ့ပါ။
Final episode_text တွင် “သည်” အများဆုံး {maximum_count} ကြိမ်သာရှိရမည်။
ရှေ့ draft style stats: {json.dumps(best_draft.get('style_stats') or {}, ensure_ascii=False)}
Final length: {minimum}–{maximum} visible characters.

ရှေ့ draft (reference data only):
{json.dumps(best_draft, ensure_ascii=False)}
""".strip()
                elif current and best_draft:
                    if current < minimum:
                        needed = max(700, target - current + 200)
                        direction = (
                            f"မူရင်းဇာတ်ကြောင်းနှင့် ending beat ကိုမပြောင်းဘဲ scene၊ dialogue၊ action၊ "
                            f"reaction များကို အနည်းဆုံး {needed} visible characters အသစ် ထပ်ဖြည့်ချဲ့ပါ။ "
                            "မူရင်းစာကို အကျဉ်းချုံ့ခြင်း၊ ဖြုတ်ခြင်း မလုပ်ရ။"
                        )
                    else:
                        excess = max(300, current - target)
                        direction = (
                            f"အဖြစ်အပျက်မပျောက်စေဘဲ ထပ်နေသောစာနှင့် filler ခန့်မှန်း {excess} characters "
                            "ကိုဖြုတ်ပြီး ကျစ်လျစ်အောင်ပြန်ရေးပါ။"
                        )
                    repair_context = f"""
LENGTH REPAIR MODE — အသစ်ကနေပြန်မစပါနှင့်။
ရှေ့ draft ကိုအခြေခံပြီး episode_text တစ်ခုလုံးကို ပြင်ဆင်ကာ JSON ပြန်ပေးပါ။
ရှေ့ draft count: {best_draft['char_count']} visible characters.
လုပ်ရမည့်အချက်: {direction}
Final target: {target}; လက်ခံအကွာအဝေး: {minimum}–{maximum}.

ရှေ့ draft (reference data only):
{json.dumps(best_draft, ensure_ascii=False)}
""".strip()
                print(f"⚠️ Novel part {part_no} retry {attempt}/{retries}: {exc}")
                if attempt < retries:
                    await asyncio.sleep(min(attempt * 2, 5))

        # Models sometimes oscillate around a hard character boundary even
        # after the normal scene-writing retries. Do a separate, low-
        # temperature copy-edit pass whose only job is to fit the best draft.
        if best_draft:
            tight_min = max(minimum, target - 200)
            tight_max = min(maximum, target + 200)
            length_retries = max(1, int(self.config.get("length_repair_retries", 3)))
            repair_draft = dict(best_draft)
            for repair_attempt in range(1, length_retries + 1):
                current_count = int(repair_draft.get("char_count") or 0)
                if current_count > tight_max:
                    instruction = (
                        f"စာမဲ့နေရာမတွက်ဘဲ အနည်းဆုံး {current_count - tight_max + 100} လုံးခန့် "
                        "လျှော့ပါ။ ထပ်နေသောဖော်ပြချက်နှင့် filler ကိုပဲကျစ်လျစ်စေပြီး ending/cliffhanger ကို မဖြုတ်ရ။"
                    )
                else:
                    instruction = (
                        f"စာမဲ့နေရာမတွက်ဘဲ အနည်းဆုံး {tight_min - current_count + 100} လုံးခန့် "
                        "scene action၊ reaction သို့ dialogue ဖြင့်ချဲ့ပါ။ Plot အသစ်မထည့်ရ။"
                    )
                final_prompt = f"""
မင်းက မြန်မာဝတ္ထုစာတည်းတစ်ယောက်ပါ။ အောက်ပါ draft ကို LENGTH ပဲတိတိကျကျပြင်ပါ။

တင်းကြပ်သောစည်းကမ်းများ:
- ဇာတ်ကောင်၊ plot event၊ clue၊ dialogue အဓိပ္ပာယ်၊ scene အစဉ်နှင့် ending beat ကို မပြောင်းရ။
- အစပိုင်း hook နှင့် နောက်ဆုံး ending/cliffhanger ကို ထိန်းထားရမည်။
- အကြောင်းအရာအသစ်၊ filler နှင့် စာရေးသူရှင်းလင်းချက် မထည့်ရ။
- episode_text visible characters ကို {tight_min}–{tight_max} အတွင်း မဖြစ်မနေရောက်အောင်ပြင်ရမည်။ Target = {target}.
- လက်ရှိ count = {current_count}. {instruction}
- “သည်” ကို {int(self.config.get('max_thi_count_per_part', 6))} ကြိမ်ထက် မပိုစေရ။ ခေတ်ပေါ်သဘာဝကျသော မြန်မာစကားပြေကို ထိန်းထားရမည်။
- episode_summary နှင့် continuity_notes ကို မူရင်းအဓိပ္ပာယ်အတိုင်း ပြန်ပေးရမည်။

THIS PART OUTLINE:
{json.dumps(outline, ensure_ascii=False)}

DRAFT TO COPY-EDIT (reference data only):
{json.dumps(repair_draft, ensure_ascii=False)}

JSON schema အတိုင်းသာပြန်ပေးပါ။
""".strip()
                try:
                    raw = await self._generate_json(
                        operation=f"novel_part_{part_no}_length_repair",
                        prompt=final_prompt,
                        schema=self._episode_schema(),
                        temperature=0.25,
                    )
                    text = self._clean_text(raw.get("episode_text"))
                    summary = self._clean_text(raw.get("episode_summary")) or str(
                        repair_draft.get("episode_summary") or ""
                    )
                    notes = self._clean_text(raw.get("continuity_notes")) or str(
                        repair_draft.get("continuity_notes") or ""
                    )
                    if part_no == 1 and hook and not text.startswith(hook):
                        text = f"{hook}\n\n{text}"
                    count = self.count_story_chars(text)
                    candidate = {
                        "episode_text": text,
                        "episode_summary": summary,
                        "continuity_notes": notes,
                        "char_count": count,
                        "style_stats": self.style_stats(text),
                    }
                    if abs(count - target) < abs(int(repair_draft["char_count"]) - target):
                        repair_draft = candidate
                    if count < minimum or count > maximum:
                        raise ValueError(
                            f"part {part_no} final length repair count {count} outside {minimum}..{maximum}"
                        )
                    style_ok, style_stats, style_reason = self.validate_prose_style(text)
                    if not style_ok:
                        raise ValueError(f"part {part_no} final style gate failed: {style_reason}")
                    return {
                        "part_no": part_no,
                        "part_title": str(outline.get("part_title") or f"အပိုင်း {part_no}"),
                        "episode_text": text,
                        "episode_summary": summary,
                        "continuity_notes": notes,
                        "char_count": count,
                        "style_stats": style_stats,
                    }
                except Exception as exc:
                    last_exc = exc
                    print(
                        f"⚠️ Novel part {part_no} final length repair "
                        f"{repair_attempt}/{length_retries}: {exc}"
                    )
                    if repair_attempt < length_retries:
                        await asyncio.sleep(min(repair_attempt * 2, 4))

            # Do not throw away an otherwise valid post for a tiny final
            # overshoot. This safety valve is deliberately narrow and is used
            # only after all dedicated length repairs have failed.
            emergency_overrun = max(0, int(self.config.get("emergency_max_char_overrun", 250)))
            emergency_count = int(repair_draft.get("char_count") or 0)
            style_ok, style_stats, style_reason = self.validate_prose_style(
                str(repair_draft.get("episode_text") or "")
            )
            if maximum < emergency_count <= maximum + emergency_overrun and style_ok:
                print(
                    f"⚠️ Novel part {part_no} accepted with emergency length tolerance: "
                    f"{emergency_count} chars (hard target max {maximum})"
                )
                return {
                    "part_no": part_no,
                    "part_title": str(outline.get("part_title") or f"အပိုင်း {part_no}"),
                    "episode_text": str(repair_draft.get("episode_text") or ""),
                    "episode_summary": str(repair_draft.get("episode_summary") or ""),
                    "continuity_notes": str(repair_draft.get("continuity_notes") or ""),
                    "char_count": emergency_count,
                    "style_stats": style_stats,
                    "length_tolerance_used": True,
                }
            if not style_ok:
                last_exc = ValueError(f"part {part_no} emergency style gate failed: {style_reason}")
        raise RuntimeError(f"Novel part {part_no} generation failed: {last_exc}")

    def _output_root(self) -> Path:
        value = Path(str(self.config.get("output_root") or "outputs/novel_standalone"))
        return value.resolve() if value.is_absolute() else (self.root / value).resolve()

    def _all_output_roots(self) -> list[Path]:
        roots = [self._output_root()]
        for value in self.config.get("legacy_output_roots") or []:
            path = Path(str(value))
            path = path.resolve() if path.is_absolute() else (self.root / path).resolve()
            if path not in roots:
                roots.append(path)
        return roots

    def _series_folders(self) -> list[Path]:
        folders: list[Path] = []
        for root in self._all_output_roots():
            if root.exists():
                folders.extend(path for path in root.iterdir() if path.is_dir())
        return sorted(folders, key=lambda path: path.stat().st_mtime, reverse=True)

    def latest_incomplete_dir(self) -> Path | None:
        for folder in self._series_folders():
            state_path = folder / "series.json"
            if not state_path.exists():
                continue
            try:
                state = json.loads(state_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if int(state.get("parts_count") or 0) == self.PARTS_COUNT and not bool(
                state.get("complete")
            ):
                return folder
        return None

    def latest_series_dir(self) -> Path | None:
        for folder in self._series_folders():
            state_path = folder / "series.json"
            if not state_path.exists():
                continue
            try:
                state = json.loads(state_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if int(state.get("parts_count") or 0) == self.PARTS_COUNT:
                return folder
        return None

    @staticmethod
    def _series_id() -> str:
        return time.strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:8]

    def _new_state(self, series_id: str, genre: str, story_seed: str, route_key: str = "") -> dict[str, Any]:
        return {
            "version": 1,
            "series_id": series_id,
            "status": "generating",
            "parts_count": self.PARTS_COUNT,
            "target_chars_per_part": int(self.config.get("target_chars_per_part", 5000)),
            "genre_requested": genre,
            "story_seed": self._clean_text(story_seed),
            "tt_route_key": str(route_key or "").strip(),
            "blueprint": None,
            "parts": [],
            "cover": {},
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }

    @staticmethod
    def _publish_start_date(value: str) -> str:
        raw = str(value or "").strip()
        if not raw:
            return date.today().isoformat()
        try:
            return date.fromisoformat(raw).isoformat()
        except ValueError as exc:
            raise ValueError("publish start date must use YYYY-MM-DD") from exc

    def _part_post_text(self, state: dict[str, Any], part: dict[str, Any]) -> str:
        title = str((state.get("blueprint") or {}).get("title") or "မြန်မာဝတ္ထု")
        digit = str(part["part_no"]).translate(self.MYANMAR_DIGITS)
        total = str(self.PARTS_COUNT).translate(self.MYANMAR_DIGITS)
        hashtags = " ".join(str(x).strip() for x in self.config.get("hashtags") or [] if str(x).strip())
        return (
            f"{title}\nအပိုင်း ({digit}/{total}) — {part['part_title']}\n\n"
            f"{part['episode_text']}"
            + (f"\n\n{hashtags}" if hashtags else "")
            + "\n"
        )

    def _save_part_files(self, series_dir: Path, state: dict[str, Any], part: dict[str, Any]) -> None:
        parts_dir = series_dir / "parts"
        parts_dir.mkdir(parents=True, exist_ok=True)
        number = int(part["part_no"])
        (parts_dir / f"part_{number:02d}.txt").write_text(part["episode_text"] + "\n", encoding="utf-8")
        (parts_dir / f"part_{number:02d}_post.txt").write_text(
            self._part_post_text(state, part), encoding="utf-8"
        )

    async def _repair_existing_part_style(
        self,
        *,
        state: dict[str, Any],
        part: dict[str, Any],
    ) -> dict[str, Any]:
        minimum = int(self.config.get("min_chars_per_part", 4500))
        maximum = int(self.config.get("max_chars_per_part", 5500))
        target = int(self.config.get("target_chars_per_part", 5000))
        maximum_thi = int(self.config.get("max_thi_count_per_part", 6))
        retries = max(1, int(self.config.get("part_generation_retries", 5)))
        draft = self._clean_text(part.get("episode_text"))
        last_exc: Exception | None = None
        for attempt in range(1, retries + 1):
            stats = self.style_stats(draft)
            prompt = f"""
မင်းက မြန်မာဝတ္ထုစာတည်းတစ်ယောက်ပါ။ အောက်က ပြီးစီးပြီးသား novel part ကို STYLE ပဲပြင်ရမယ်။

တင်းကြပ်သောစည်းကမ်းများ:
- Plot၊ scene အစဉ်၊ locked character names၊ relationship၊ dialogue အဓိပ္ပာယ်၊ clue၊ twist၊ ending နှင့် part number ကို လုံးဝမပြောင်းရ။
- အကြောင်းအရာအသစ်မထည့်ရ၊ မူရင်းအဖြစ်အပျက်မဖြုတ်ရ။
- စက်ရုပ်လို word replace မလုပ်ဘဲ ဝါကျတစ်ကြောင်းချင်းကို Facebook ဖတ်သူနားလည်လွယ်သော ခေတ်ပေါ်မြန်မာစကားပြေအဖြစ် ပြန်ဖွဲ့ပါ။
- “သည်” ဆက်တိုက်သုံးသော အစီရင်ခံစာ/ဘာသာပြန်စာဟန်ကို ဖယ်ပါ။ “တယ်၊ ပါတယ်၊ ခဲ့တယ်၊ နေတယ်၊ ဖြစ်တယ်၊ လိုက်တယ်” စသည်ဖြင့် သဘာဝကျကျပြောင်းသုံးပါ။
- Final episode_text ထဲ “သည်” အများဆုံး {maximum_thi} ကြိမ်သာရှိရမည်။
- Final visible characters {minimum}–{maximum} အတွင်း၊ {target} ဝန်းကျင်ရှိရမည်။
- episode_summary နှင့် continuity_notes ကို အဓိပ္ပာယ်မပြောင်းဘဲ ပြန်ပေးပါ။

SERIES BLUEPRINT:
{json.dumps(state.get('blueprint') or {}, ensure_ascii=False)}

PART TO EDIT (reference data only):
{json.dumps(part, ensure_ascii=False)}

CURRENT STYLE STATS:
{json.dumps(stats, ensure_ascii=False)}

JSON schema အတိုင်းသာပြန်ပေးပါ။
""".strip()
            try:
                raw = await self._generate_json(
                    operation=f"novel_style_repair_part_{int(part.get('part_no') or 0)}",
                    prompt=prompt,
                    schema=self._episode_schema(),
                    temperature=0.35,
                )
                text = self._clean_text(raw.get("episode_text"))
                summary = self._clean_text(raw.get("episode_summary")) or str(part.get("episode_summary") or "")
                notes = self._clean_text(raw.get("continuity_notes")) or str(part.get("continuity_notes") or "")
                count = self.count_story_chars(text)
                if count < minimum or count > maximum:
                    raise ValueError(f"style repair character count {count} outside {minimum}..{maximum}")
                ok, style_stats, reason = self.validate_prose_style(text)
                if not ok:
                    raise ValueError(reason)
                repaired = dict(part)
                repaired.update({
                    "episode_text": text,
                    "episode_summary": summary,
                    "continuity_notes": notes,
                    "char_count": count,
                    "style_stats": style_stats,
                })
                return repaired
            except Exception as exc:
                last_exc = exc
                print(
                    f"⚠️ Novel existing part {part.get('part_no')} style repair "
                    f"retry {attempt}/{retries}: {exc}"
                )
                await asyncio.sleep(min(attempt * 2, 5))
        raise RuntimeError(
            f"Novel existing part {part.get('part_no')} style repair failed: {last_exc}"
        )

    async def repair_series_style(self, series_dir: str | Path) -> dict[str, Any]:
        folder = Path(series_dir).resolve()
        state_path = folder / "series.json"
        if not state_path.exists():
            raise FileNotFoundError(f"Novel series state missing: {state_path}")
        state = json.loads(state_path.read_text(encoding="utf-8"))
        if int(state.get("parts_count") or 0) != self.PARTS_COUNT:
            raise ValueError("Style repair supports exactly four-part Novel series")
        parts = list(state.get("parts") or [])
        if len(parts) != self.PARTS_COUNT:
            raise ValueError("Novel style repair requires all four completed parts")
        repaired_numbers: list[int] = []
        for index, part in enumerate(parts):
            ok, stats, _ = self.validate_prose_style(str(part.get("episode_text") or ""))
            if ok:
                part["style_stats"] = stats
                self._save_part_files(folder, state, part)
                continue
            number = int(part.get("part_no") or index + 1)
            print(f"📝 Novel style repair start → part {number} | 'သည်'={stats['thi_count']}")
            parts[index] = await self._repair_existing_part_style(state=state, part=part)
            state["parts"] = parts
            self._save_part_files(folder, state, parts[index])
            self._atomic_json(state_path, state)
            repaired_numbers.append(number)
            print(
                f"✅ Novel style repaired → part {number} | "
                f"'သည်'={parts[index]['style_stats']['thi_count']}"
            )
        state["parts"] = parts
        state["total_chars"] = sum(int(row.get("char_count") or 0) for row in parts)
        if repaired_numbers:
            # Existing screenshot ranges belong to the pre-repair text.  Keep the
            # image files recoverable on disk but remove them from publish state so
            # the next photo-mode run must render verified pages from repaired text.
            state["story_pages"] = {}
            for row in state.get("publishing_plan") or []:
                if isinstance(row, dict):
                    row["story_pages"] = []
        state["style_gate"] = {
            "passed": True,
            "max_thi_count_per_part": int(self.config.get("max_thi_count_per_part", 6)),
            "checked_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }
        self._atomic_json(state_path, state)
        manifest_path = folder / "manifest.json"
        manifest = self._atomic_manifest_from_state(folder, state)
        self._atomic_json(manifest_path, manifest)
        return {**manifest, "style_repaired_parts": repaired_numbers}

    def _atomic_manifest_from_state(self, series_dir: Path, state: dict[str, Any]) -> dict[str, Any]:
        numbered_covers = list((state.get("cover") or {}).get("parts") or [])
        return {
            "success": True,
            "series_id": state.get("series_id") or series_dir.name,
            "title": state.get("title") or (state.get("blueprint") or {}).get("title") or series_dir.name,
            "tt_route_key": str(state.get("tt_route_key") or ""),
            "parts_count": self.PARTS_COUNT,
            "total_chars": int(state.get("total_chars") or 0),
            "series_dir": str(series_dir),
            "state_path": str(series_dir / "series.json"),
            "posts": [str(series_dir / "parts" / f"part_{i:02d}_post.txt") for i in range(1, 5)],
            "covers": numbered_covers,
            "story_pages": state.get("story_pages") or {},
            "publishing_plan": list(state.get("publishing_plan") or []),
        }

    @staticmethod
    def _non_graphic_cover_prompt(blueprint: dict[str, Any]) -> str:
        """Replace rejected artwork with genuinely non-graphic, symbolic art."""
        genre = str(blueprint.get("genre") or "").lower()
        if any(word in genre for word in ("horror", "သရဲ", "သဘာဝလွန်", "သည်းထိတ်")):
            scene = (
                "An atmospheric mystery novel cover: an old colonial mansion in Myanmar "
                "at night, soft moonlight and drifting mist. An ornate intact wooden mirror "
                "reflects an empty dim hallway. A vintage camera rests on a wooden table. "
                "A fully clothed adult Burmese figure stands at a distance, seen from behind. "
                "Quiet suspense, cinematic teal and warm amber lighting, realistic textures. "
            )
        else:
            scene = (
                "A cinematic Burmese drama novel cover: fully clothed adult Burmese "
                "characters standing apart in a rain-lit Myanmar street, thoughtful expressions, "
                "emotional tension conveyed through distance and lighting, realistic textures. "
            )
        return scene + (
            "Vertical 4:5 portrait composition, elegant professional poster photography, "
            "highly detailed, no text, no letters, no title, no episode number, no logo, no watermark."
        )

    async def _generate_base_cover(self, blueprint: dict[str, Any], output_path: Path) -> None:
        prompt = (
            str(blueprint.get("cover_prompt") or "").strip()
            + " Vertical cinematic Burmese novel cover art, 4:5 portrait composition, "
              "consistent adult characters, emotionally compelling, no text, no letters, "
              "no title, no episode number, no logo, no watermark."
        )
        original_sha = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
        override_path = output_path.parent / "cover_prompt_override.json"
        safe_prompt = self._non_graphic_cover_prompt(blueprint)

        def save_safe_override(reason: str) -> None:
            self._atomic_json(override_path, {
                "version": 1,
                "original_prompt_sha256": original_sha,
                "prompt": safe_prompt,
                "reason": reason,
            })

        try:
            override = json.loads(override_path.read_text(encoding="utf-8"))
            if (
                isinstance(override, dict)
                and override.get("original_prompt_sha256") == original_sha
                and override.get("prompt") == safe_prompt
            ):
                prompt = safe_prompt
        except (OSError, json.JSONDecodeError):
            pass
        if prompt != safe_prompt and re.search(
            r"\b(?:severed|decapitat\w*|dismember\w*|mutilat\w*|gore|gory|"
            r"bloody|exposed\s+organs|graphic\s+(?:injur\w*|wound\w*))\b",
            prompt,
            flags=re.I,
        ):
            save_safe_override("graphic_cover_content")
            prompt = safe_prompt
            print("🖼️ Novel cover changed to non-graphic atmospheric artwork; story text unchanged")
        try:
            provider = str(self.config.get("image_provider") or "fal").strip().lower()
            if provider != "fal":
                raise RuntimeError(
                    f"Unsupported Novel cover provider: {provider}; expected fal/FLUX Schnell"
                )
            try:
                await self._generate_base_cover_fal(prompt, output_path)
            except Exception as exc:
                # Only explicit content rejection changes the artwork. Network,
                # auth and billing failures must retain their original cause.
                if "content_policy_violation" not in str(exc).lower() or prompt == safe_prompt:
                    raise
                save_safe_override("fal_content_policy_violation")
                print("🖼️ Novel cover rejected; retrying once with non-graphic symbolic artwork")
                await self._generate_base_cover_fal(safe_prompt, output_path)
        except Exception as exc:
            if not bool(self.config.get("allow_local_cover_fallback", True)):
                raise
            print(f"⚠️ Novel FAL cover unavailable; local cinematic fallback used: {exc}")
            await asyncio.to_thread(self._create_local_cover_fallback, output_path)

    async def _generate_base_cover_fal(self, prompt: str, output_path: Path) -> None:
        """Generate one base image using this standalone app's FAL queue client."""
        runner = FalImageService(self.config, self.env_path)
        await asyncio.to_thread(
            runner.generate,
            prompt,
            output_path,
            width=int(self.config.get("cover_width", 1080)),
            height=int(self.config.get("cover_height", 1350)),
        )

    def _create_local_cover_fallback(self, output_path: Path) -> None:
        width = int(self.config.get("cover_width", 1080))
        height = int(self.config.get("cover_height", 1350))
        image = Image.new("RGB", (width, height), (18, 12, 33))
        draw = ImageDraw.Draw(image, "RGBA")
        colors = [(83, 37, 112, 115), (16, 103, 122, 100), (176, 59, 78, 85)]
        rng = random.Random(99173)
        for idx in range(18):
            radius = rng.randint(120, 380)
            x = rng.randint(-radius, width)
            y = rng.randint(-radius, height)
            color = colors[idx % len(colors)]
            draw.ellipse((x, y, x + radius * 2, y + radius * 2), fill=color)
        image = image.filter(ImageFilter.GaussianBlur(radius=55))
        output_path.parent.mkdir(parents=True, exist_ok=True)
        image.save(output_path, quality=94)

    def _render_numbered_cover(
        self,
        *,
        base_cover: Path,
        title: str,
        part_no: int,
        output_path: Path,
    ) -> None:
        from playwright.sync_api import sync_playwright

        width = int(self.config.get("cover_width", 1080))
        height = int(self.config.get("cover_height", 1350))
        title = self._clean_text(title)[: int(self.config.get("cover_title_max_chars", 58))]
        digit = str(part_no).translate(self.MYANMAR_DIGITS)
        _font_path, font_face = self._myanmar_font_face()
        image_b64 = base64.b64encode(base_cover.read_bytes()).decode("ascii")
        title_html = html.escape(title, quote=True)
        part_html = html.escape(f"အပိုင်း ({digit})", quote=True)
        page_html = f"""<!doctype html><html lang="my"><head><meta charset="utf-8"><style>
{font_face}
*{{box-sizing:border-box}}html,body{{margin:0;width:{width}px;height:{height}px;overflow:hidden}}
body{{font-family:'NovelMyanmar','Pyidaungsu','Myanmar Text','Noto Sans Myanmar',sans-serif;background:#111;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}}
.cover{{position:absolute;inset:0;background:url(data:image/jpeg;base64,{image_b64}) center/cover no-repeat;filter:saturate(1.04)}}
.shade{{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.18) 0%,rgba(0,0,0,.04) 42%,rgba(0,0,0,.84) 100%)}}
.copy{{position:absolute;left:70px;right:70px;bottom:78px;color:white;text-align:center;text-shadow:0 3px 12px #000,0 1px 3px #000}}
.title{{font-size:70px;line-height:1.28;font-weight:700}}
.part{{display:inline-block;margin-top:30px;padding:13px 34px 17px;border-radius:18px;background:rgba(0,0,0,.64);border:2px solid rgba(255,255,255,.76);font-size:54px;line-height:1.2;font-weight:700}}
</style></head><body><div class="cover"></div><div class="shade"></div><div class="copy"><div class="title">{title_html}</div><div class="part">{part_html}</div></div></body></html>"""

        output_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with sync_playwright() as playwright:
                browser, _browser_label = self._launch_chromium(playwright)
                try:
                    page = browser.new_page(viewport={"width": width, "height": height})
                    page.set_content(page_html, wait_until="load", timeout=30_000)
                    self._wait_for_myanmar_font(page)
                    page.wait_for_timeout(650)
                    page.screenshot(path=str(output_path), timeout=30_000)
                finally:
                    browser.close()
        except Exception as exc:
            raise RuntimeError(f"Novel cover text render failed: {exc}") from exc
        if not output_path.exists():
            raise RuntimeError("Novel numbered cover was not created")

    def _render_story_pages(
        self,
        *,
        series_dir: Path,
        title: str,
        parts: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Render exact episode text into dynamic 9:16 pages without rewriting it."""
        from playwright.sync_api import sync_playwright

        width = int(self.config.get("screenshot_page_width", 1080))
        height = int(self.config.get("screenshot_page_height", 1920))
        font_size = int(self.config.get("screenshot_font_size", 42))
        line_height = float(self.config.get("screenshot_line_height", 1.75))
        max_pages = max(1, int(self.config.get("screenshot_max_pages_per_part", 20)))
        quality = max(70, min(100, int(self.config.get("screenshot_jpeg_quality", 92))))
        if width != 1080 or height != 1920:
            raise ValueError("Novel story screenshot pages must use a 1080x1920 (9:16) canvas")

        manifest_path = series_dir / "pages_manifest.json"
        existing: dict[str, Any] = {}
        try:
            existing = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            existing = {}
        existing_parts = {
            int(row.get("part_no") or 0): row
            for row in (existing.get("parts") or [])
            if isinstance(row, dict)
        }
        reusable = True
        for part in parts:
            number = int(part.get("part_no") or 0)
            text = str(part.get("episode_text") or "")
            row = existing_parts.get(number) or {}
            paths = [Path(str(item.get("path") or "")) for item in row.get("pages") or []]
            if (
                str(row.get("text_sha256") or "") != hashlib.sha256(text.encode("utf-8")).hexdigest()
                or not paths
                or not all(path.exists() for path in paths)
            ):
                reusable = False
                break
        if int(existing.get("version") or 0) == 2 and reusable and len(existing_parts) == len(parts):
            return existing

        font_path, font_face = self._myanmar_font_face()
        page_html = f"""<!doctype html><html lang="my"><head><meta charset="utf-8"><style>
{font_face}
*{{box-sizing:border-box}}html,body{{margin:0;width:{width}px;height:{height}px;overflow:hidden}}
body{{font-family:'NovelMyanmar','Pyidaungsu','Myanmar Text','Noto Sans Myanmar',sans-serif;background:#f4eddf;color:#241c18;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}}
.sheet{{position:absolute;inset:0;padding:76px 76px 66px;background:linear-gradient(155deg,#fffaf0 0%,#f0e4d2 100%)}}
.rule{{height:8px;border-radius:5px;background:linear-gradient(90deg,#8d2f3e,#d39a4a);margin-bottom:28px}}
.title{{font-size:34px;line-height:1.35;font-weight:700;color:#702737;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
.part{{margin-top:8px;font-size:28px;font-weight:700;color:#705e50}}
.story{{position:absolute;left:76px;right:76px;top:232px;bottom:132px;overflow:hidden;white-space:pre-wrap;word-break:break-word;font-size:{font_size}px;line-height:{line_height};font-weight:500;text-align:left}}
.footer{{position:absolute;left:76px;right:76px;bottom:54px;text-align:center;font-size:25px;color:#846f60}}
</style></head><body><div class="sheet"><div class="rule"></div><div id="title" class="title"></div><div id="part" class="part"></div><div id="story" class="story"></div><div id="footer" class="footer"></div></div></body></html>"""

        rendered_parts: list[dict[str, Any]] = []
        browser_label = ""
        try:
            with sync_playwright() as playwright:
                browser, browser_label = self._launch_chromium(playwright)
                try:
                    page = browser.new_page(viewport={"width": width, "height": height})
                    page.set_content(page_html, wait_until="load", timeout=30_000)
                    self._wait_for_myanmar_font(page)
                    for part in parts:
                        number = int(part.get("part_no") or 0)
                        text = str(part.get("episode_text") or "")
                        if not text.strip():
                            raise ValueError(f"Novel part {number} has no text for screenshot rendering")
                        page.locator("#title").evaluate("(el, value) => el.textContent = value", title)
                        part_digit = str(number).translate(self.MYANMAR_DIGITS)
                        page.locator("#part").evaluate(
                            "(el, value) => el.textContent = value", f"အပိုင်း ({part_digit})"
                        )

                        def fits(value: str) -> bool:
                            return bool(page.locator("#story").evaluate(
                                "(el, value) => { el.textContent = value; return el.scrollHeight <= el.clientHeight + 1; }",
                                value,
                            ))

                        boundaries = sorted({
                            match.end()
                            for match in re.finditer(r"(?:\r?\n\s*\r?\n|[။!?…]+[\"'”’)]*\s*|\s+)", text)
                            if match.end() > 0
                        } | {len(text)})
                        ranges: list[tuple[int, int]] = []
                        start = 0
                        while start < len(text):
                            low, high, best = start + 1, len(text), start
                            while low <= high:
                                middle = (low + high) // 2
                                if fits(text[start:middle]):
                                    best = middle
                                    low = middle + 1
                                else:
                                    high = middle - 1
                            if best <= start:
                                raise RuntimeError(f"Novel part {number} screenshot text cannot fit on a page")
                            preferred = [point for point in boundaries if start < point <= best]
                            end = preferred[-1] if preferred else best
                            ranges.append((start, end))
                            if len(ranges) > max_pages:
                                raise RuntimeError(
                                    f"Novel part {number} needs more than {max_pages} screenshot pages"
                                )
                            start = end
                        if "".join(text[a:b] for a, b in ranges) != text:
                            raise RuntimeError(f"Novel part {number} screenshot pagination changed the text")

                        part_dir = series_dir / "story_pages" / f"part_{number:02d}"
                        part_dir.mkdir(parents=True, exist_ok=True)
                        for stale in part_dir.glob("page_*.jpg"):
                            stale.unlink(missing_ok=True)
                        page_rows: list[dict[str, Any]] = []
                        total = len(ranges)
                        for index, (start, end) in enumerate(ranges, 1):
                            chunk = text[start:end]
                            page.locator("#story").evaluate("(el, value) => el.textContent = value", chunk)
                            page.locator("#footer").evaluate(
                                "(el, value) => el.textContent = value",
                                f"{index} / {total}",
                            )
                            target = (part_dir / f"page_{index:03d}.jpg").resolve()
                            page.screenshot(
                                path=str(target), type="jpeg", quality=quality, timeout=30_000
                            )
                            page_rows.append({
                                "page_no": index,
                                "start": start,
                                "end": end,
                                "text_sha256": hashlib.sha256(chunk.encode("utf-8")).hexdigest(),
                                "path": str(target),
                            })
                        rendered_parts.append({
                            "part_no": number,
                            "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                            "page_count": total,
                            "pages": page_rows,
                        })
                finally:
                    browser.close()
        except Exception as exc:
            raise RuntimeError(f"Novel story screenshot render failed: {exc}") from exc

        manifest = {
            "version": 2,
            "canvas": {"width": width, "height": height},
            "renderer": "chromium-myanmar",
            "browser": browser_label,
            "font": str(font_path),
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "parts": rendered_parts,
        }
        self._atomic_json(manifest_path, manifest)
        return manifest

    async def generate(
        self,
        *,
        genre: str = "",
        story_seed: str = "",
        publish_start_date: str = "",
        route_key: str = "",
        resume_dir: str | Path | None = None,
        force_cover: bool = False,
        render_screenshot_pages: bool = False,
    ) -> dict[str, Any]:
        if resume_dir:
            series_dir = Path(resume_dir).resolve()
            state_path = series_dir / "series.json"
            if not state_path.exists():
                raise FileNotFoundError(f"Novel resume state missing: {state_path}")
            state = json.loads(state_path.read_text(encoding="utf-8"))
            if int(state.get("parts_count") or 0) != self.PARTS_COUNT:
                raise ValueError("Resume state is not a four-part novel")
            print(f"♻️ Novel resume → {series_dir}")
        else:
            choices = [str(x).strip() for x in self.config.get("genres") or [] if str(x).strip()]
            selected_genre = str(genre or "").strip() or random.choice(choices or ["ဒရာမာ"])
            series_id = self._series_id()
            series_dir = self._output_root() / series_id
            series_dir.mkdir(parents=True, exist_ok=False)
            state_path = series_dir / "series.json"
            state = self._new_state(series_id, selected_genre, story_seed, route_key)
            state["publish_start_date"] = self._publish_start_date(publish_start_date)
            self._atomic_json(state_path, state)
            print(f"📚 Novel standalone start → {selected_genre} | {series_id}")

        if not state.get("blueprint"):
            state["blueprint"] = await self._generate_blueprint(
                str(state.get("genre_requested") or genre),
                str(state.get("story_seed") or story_seed),
            )
            state["title"] = state["blueprint"]["title"]
            self._atomic_json(state_path, state)
            print(f"✅ Novel blueprint locked → {state['title']} | four parts")

        parts = list(state.get("parts") or [])
        for part_no in range(1, self.PARTS_COUNT + 1):
            existing = next((row for row in parts if int(row.get("part_no") or 0) == part_no), None)
            if existing:
                self._save_part_files(series_dir, state, existing)
                print(f"♻️ Novel part {part_no}/4 reuse → {existing.get('char_count', 0)} chars")
                continue
            part = await self._generate_part(
                blueprint=state["blueprint"],
                part_no=part_no,
                previous_parts=parts,
            )
            parts.append(part)
            state["parts"] = parts
            state["last_completed_part"] = part_no
            self._save_part_files(series_dir, state, part)
            self._atomic_json(state_path, state)
            print(f"✅ Novel part {part_no}/4 → {part['char_count']} chars")

        cover_dir = series_dir / "covers"
        base_cover = cover_dir / "cover_base.jpg"
        if force_cover:
            rebuild_base = cover_dir / "cover_base.rebuild.jpg"
            if not rebuild_base.exists():
                await self._generate_base_cover(state["blueprint"], rebuild_base)
            rebuild_covers: list[tuple[Path, Path]] = []
            for part_no in range(1, self.PARTS_COUNT + 1):
                rebuild_target = cover_dir / f"part_{part_no:02d}_cover.rebuild.jpg"
                await asyncio.to_thread(
                    self._render_numbered_cover,
                    base_cover=rebuild_base,
                    title=str(state.get("title") or "မြန်မာဝတ္ထု"),
                    part_no=part_no,
                    output_path=rebuild_target,
                )
                rebuild_covers.append(
                    (rebuild_target, cover_dir / f"part_{part_no:02d}_cover.jpg")
                )
            os.replace(rebuild_base, base_cover)
            for rebuild_target, final_target in rebuild_covers:
                os.replace(rebuild_target, final_target)
            print("✅ Novel cover rebuilt with FAL FLUX Schnell — story text reused")
        elif not base_cover.exists():
            await self._generate_base_cover(state["blueprint"], base_cover)
            state["cover"]["base"] = str(base_cover)
            self._atomic_json(state_path, state)
            print("✅ Novel base cover ready — reused by all four parts")

        numbered_covers: list[str] = []
        for part_no in range(1, self.PARTS_COUNT + 1):
            target = cover_dir / f"part_{part_no:02d}_cover.jpg"
            if not target.exists():
                await asyncio.to_thread(
                    self._render_numbered_cover,
                    base_cover=base_cover,
                    title=str(state.get("title") or "မြန်မာဝတ္ထု"),
                    part_no=part_no,
                    output_path=target,
                )
            numbered_covers.append(str(target))

        if render_screenshot_pages or bool(self.config.get("screenshot_pages_enabled", False)):
            state["story_pages"] = await asyncio.to_thread(
                self._render_story_pages,
                series_dir=series_dir,
                title=str(state.get("title") or "မြန်မာဝတ္ထု"),
                parts=parts,
            )
            self._atomic_json(state_path, state)
            print("✅ Novel 9:16 story screenshot pages ready")

        page_parts = {
            int(row.get("part_no") or 0): [
                str(item.get("path") or "") for item in (row.get("pages") or []) if str(item.get("path") or "")
            ]
            for row in ((state.get("story_pages") or {}).get("parts") or [])
            if isinstance(row, dict)
        }

        total_chars = sum(int(row.get("char_count") or 0) for row in parts)
        if not state.get("publish_start_date"):
            state["publish_start_date"] = self._publish_start_date(publish_start_date)
        plan_start = date.fromisoformat(str(state["publish_start_date"]))
        publishing_plan = [
            {
                "day_offset": part_no - 1,
                "publish_date": (plan_start + timedelta(days=part_no - 1)).isoformat(),
                "part_no": part_no,
                "post_text": str(series_dir / "parts" / f"part_{part_no:02d}_post.txt"),
                "cover": numbered_covers[part_no - 1],
                "story_pages": page_parts.get(part_no, []),
                "status": "ready",
            }
            for part_no in range(1, self.PARTS_COUNT + 1)
        ]
        state.update({
            "status": "ready",
            "complete": True,
            "total_chars": total_chars,
            "cover": {"base": str(base_cover), "parts": numbered_covers},
            "publishing_plan": publishing_plan,
            "finished_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        })
        manifest = {
            "success": True,
            "series_id": state["series_id"],
            "title": state["title"],
            "tt_route_key": str(state.get("tt_route_key") or ""),
            "parts_count": self.PARTS_COUNT,
            "total_chars": total_chars,
            "series_dir": str(series_dir),
            "state_path": str(state_path),
            "posts": [str(series_dir / "parts" / f"part_{i:02d}_post.txt") for i in range(1, 5)],
            "covers": numbered_covers,
            "story_pages": state.get("story_pages") or {},
            "publishing_plan": publishing_plan,
        }
        self._atomic_json(state_path, state)
        self._atomic_json(series_dir / "manifest.json", manifest)
        print(f"🎉 Novel standalone READY → 4 parts | total={total_chars} chars | {series_dir}")
        return manifest
