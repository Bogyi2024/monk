from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path

from services.novel_service import NovelStandaloneService


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate one automatic four-part Burmese novel with reusable numbered covers."
    )
    parser.add_argument("--genre", default="", help="Optional genre override; story/names remain automatic.")
    parser.add_argument(
        "--synopsis",
        default="",
        help="Optional desired story summary/seed. Character names remain automatic.",
    )
    parser.add_argument(
        "--start-date",
        default="",
        help="Part 1 publish date in YYYY-MM-DD; parts 2-4 follow on consecutive days.",
    )
    parser.add_argument(
        "--route-key",
        default="",
        help="Optional TT Master Novel route that owns this generated series.",
    )
    parser.add_argument(
        "--interactive",
        action="store_true",
        help="Ask for genre, synopsis and start date before creating a new series.",
    )
    resume = parser.add_mutually_exclusive_group()
    resume.add_argument("--resume", default="", help="Existing series output folder to resume.")
    resume.add_argument(
        "--resume-latest",
        action="store_true",
        help="Resume the newest incomplete series; start a new one when none exists.",
    )
    parser.add_argument("--config", default="config/novel.json")
    parser.add_argument(
        "--rebuild-cover",
        action="store_true",
        help="Reuse completed text and replace the base/numbered covers with a fresh provider image.",
    )
    parser.add_argument(
        "--repair-style",
        action="store_true",
        help="Repair formal 'သည်' overuse in an existing completed series without changing its plot.",
    )
    parser.add_argument(
        "--screenshot-pages",
        action="store_true",
        help="Render each completed part as exact-text 9:16 story-page images.",
    )
    parser.add_argument("--show-config", action="store_true", help="Validate and display config without API calls.")
    return parser.parse_args()


async def main() -> None:
    args = parse_args()
    service = NovelStandaloneService(config_path=args.config)
    if args.show_config:
        print(json.dumps(service.config, ensure_ascii=False, indent=2))
        return
    if args.interactive:
        print("\nNovel genres:")
        for index, item in enumerate(service.config.get("genres") or [], 1):
            print(f"  {index}. {item}")
        args.genre = input("\nGenre (နံပါတ် သို့ စာသား): ").strip()
        choices = list(service.config.get("genres") or [])
        if args.genre.isdigit() and 1 <= int(args.genre) <= len(choices):
            args.genre = str(choices[int(args.genre) - 1])
        args.synopsis = input("လိုချင်တဲ့ဇာတ်လမ်းအကျဉ်း: ").strip()
        args.start_date = input("Part 1 date YYYY-MM-DD (blank=today): ").strip()
    resume_dir = Path(args.resume) if args.resume else None
    if args.resume_latest:
        resume_dir = (
            service.latest_series_dir()
            if args.rebuild_cover or args.repair_style
            else service.latest_incomplete_dir()
        )
        if resume_dir:
            label = "latest Novel" if (args.rebuild_cover or args.repair_style) else "latest incomplete Novel"
            print(f"♻️ {label} found → {resume_dir}")
        else:
            if args.rebuild_cover or args.repair_style:
                raise RuntimeError("No existing Novel series found for the requested repair/rebuild")
            print("🆕 No incomplete Novel found — starting a new four-part series")
    if args.rebuild_cover and resume_dir is None:
        raise RuntimeError("--rebuild-cover requires --resume or --resume-latest")
    if args.repair_style and resume_dir is None:
        raise RuntimeError("--repair-style requires --resume or --resume-latest")
    if args.repair_style:
        result = await service.repair_series_style(resume_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    result = await service.generate(
        genre=args.genre,
        story_seed=args.synopsis,
        publish_start_date=args.start_date,
        route_key=args.route_key,
        resume_dir=resume_dir,
        force_cover=args.rebuild_cover,
        render_screenshot_pages=args.screenshot_pages,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
