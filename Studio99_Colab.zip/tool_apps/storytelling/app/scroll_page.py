"""Keep the complete native tool reachable when Studio99 embeds it in a small area."""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk


class ScrollPage(ttk.Frame):
    def __init__(self, master, *, background):
        super().__init__(master)
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.canvas = tk.Canvas(self, background=background, highlightthickness=0, borderwidth=0)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.vertical = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.vertical.grid(row=0, column=1, sticky="ns")
        self.horizontal = ttk.Scrollbar(self, orient="horizontal", command=self.canvas.xview)
        self.horizontal.grid(row=1, column=0, sticky="ew")
        self.canvas.configure(yscrollcommand=self.vertical.set, xscrollcommand=self.horizontal.set,
                              yscrollincrement=24, xscrollincrement=24)
        self.content = ttk.Frame(self.canvas)
        self.window = self.canvas.create_window(0, 0, anchor="nw", window=self.content)
        self._pending = None
        self.content.bind("<Configure>", self._schedule, add="+")
        self.canvas.bind("<Configure>", self._schedule, add="+")
        self.root = self.winfo_toplevel()
        self.tag = f"StoryPageScroll{id(self)}"
        for event in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.root.bind_class(self.tag, event, self._wheel)
        self.root.bind("<Map>", self._mapped, add="+")
        self.after_idle(lambda: self._wire(self.root))

    def _schedule(self, _event=None):
        if self._pending is None:
            self._pending = self.after_idle(self._layout)

    def _layout(self):
        self._pending = None
        if not self.winfo_exists():
            return
        # Never squeeze the content below its requested height: that hid the
        # Queue entirely while the non-shrinking settings consumed its space.
        width = max(self.canvas.winfo_width(), self.content.winfo_reqwidth())
        height = max(self.canvas.winfo_height(), self.content.winfo_reqheight())
        if int(self.canvas.itemcget(self.window, "width")) != width:
            self.canvas.itemconfigure(self.window, width=width)
        if int(self.canvas.itemcget(self.window, "height")) != height:
            self.canvas.itemconfigure(self.window, height=height)
        self.canvas.configure(scrollregion=(0, 0, width, height))

    def _mapped(self, event):
        if isinstance(event.widget, tk.Misc) and event.widget.winfo_toplevel() is self.root:
            self._wire(event.widget)

    def _wire(self, widget):
        if widget.winfo_toplevel() is not self.root:
            return
        tags = widget.bindtags()
        if self.tag not in tags:
            widget.bindtags((tags[0], self.tag, *tags[1:]))
        for child in widget.winfo_children():
            self._wire(child)

    @staticmethod
    def _can_scroll(widget, axis, units):
        first, last = getattr(widget, axis + "view")()
        return (units < 0 and first > 0.0001) or (units > 0 and last < 0.9999)

    def _wheel(self, event):
        widget = event.widget
        if not isinstance(widget, tk.Misc) or widget.winfo_toplevel() is not self.root:
            return
        if getattr(event, "num", None) in (4, 5):
            units = -1 if event.num == 4 else 1
        else:
            delta = getattr(event, "delta", 0)
            if not delta:
                return
            units = -max(1, round(abs(delta) / 120)) if delta > 0 else max(1, round(abs(delta) / 120))
        axis = "x" if event.state & 0x1 else "y"  # Shift + wheel moves horizontally.
        current = widget
        while current is not self.root:
            # Text/Queue/Production Tools keep their own scroll first. At an
            # edge, the wheel continues with the surrounding whole-tool page.
            if isinstance(current, (tk.Canvas, tk.Text, tk.Listbox, ttk.Treeview)):
                try:
                    if self._can_scroll(current, axis, units):
                        getattr(current, axis + "view_scroll")(units, "units")
                        return "break"
                except (AttributeError, tk.TclError):
                    pass
            current = current.master
        if self._can_scroll(self.canvas, axis, units):
            getattr(self.canvas, axis + "view_scroll")(units, "units")
        return "break"  # wheel over settings must not accidentally change a spinbox/combobox value
