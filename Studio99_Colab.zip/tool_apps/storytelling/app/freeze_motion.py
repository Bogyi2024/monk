"""One eased hold per slow beat, with its exact slice and frame count preserved."""
from __future__ import annotations

import hashlib


def plan(source_duration, frames, guard, fps, floor_speed=0.8, hold_max=3.0):
    motion_frames = frames - guard
    natural_frames = max(1, round(source_duration / floor_speed * fps))
    hold_frames = min(max(0, motion_frames - natural_frames), round(hold_max * fps))
    play_frames = motion_frames - hold_frames
    return {"play_frames": play_frames, "hold_frames": hold_frames,
            "hold_seconds": hold_frames / fps, "motion_seconds": play_frames / fps,
            "play_speed": source_duration / (play_frames / fps)}


def filter_graph(info, width, height, fps_arg, canvas, guard, number, zoom=1.25):
    play = info["play_frames"]
    held = info["hold_frames"]
    # The frame clock drives easing; the tail guard remains at the final zoom position.
    t = f"min(1,max(0,(on-{play})/{max(1, held - 1)}))"
    ease = f"(3*pow({t},2)-2*pow({t},3))"
    amount = f"1+{zoom - 1:.6f}*{ease}" if number % 2 else f"{zoom:.6f}-{zoom - 1:.6f}*{ease}"
    return (f"setpts=(PTS-STARTPTS)/{info['play_speed']:.12f},fps={fps_arg},{canvas},"
            f"tpad=stop_mode=clone:stop_duration={info['hold_seconds'] + (guard + 4) / float_ratio(fps_arg):.6f},"
            f"scale={width * 2}:{height * 2},"
            f"zoompan=z='if(lt(on,{play}),1,{amount})':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':"
            f"d=1:s={width}x{height}:fps={fps_arg},setsar=1")


def float_ratio(value):
    from fractions import Fraction
    return float(Fraction(value))


def token(original, info, number, zoom=1.25):
    tag = f"{original}|freeze-v1|{info['play_frames']}|{info['hold_frames']}|{number % 2}|zoom={zoom}"
    return hashlib.sha1(tag.encode()).hexdigest()[:12]
