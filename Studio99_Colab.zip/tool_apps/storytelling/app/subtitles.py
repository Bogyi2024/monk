"""Burned-in Myanmar narration subtitles for Storytelling Recap Studio.

Timing: where each narration block sits in the finished video comes from the engine's
SMART_SYNC_REPORT.json (exact frame count per block). Inside a block, Edge TTS
WordBoundary events for the same text / voice / rate give when each phrase is spoken
(VoxCPM runs: the same word positions stretched onto the block audio's measured speech).
Rendering: ASS + libass with a Myanmar font (the path myanmar_subtitle_tool already uses),
and lines only ever break between Myanmar grapheme clusters.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import struct
import time
import unicodedata
from fractions import Fraction
from pathlib import Path

MM_FONTS = ("Myanmar Text", "Pyidaungsu", "Noto Sans Myanmar", "Padauk")
SAMPLE_TEXT = "ဒီနေရာမှာ မြန်မာစာတန်းထိုး ပေါ်ပါမယ်။"
MEDIALS = "\u103b\u103c\u103d\u103e"


# ---------------------------------------------------------------- Myanmar text -------

def clean_text(value: str) -> str:
    return " ".join(str(value or "").replace("\r", " ").replace("\n", " ").split()).strip()


def clusters(text: str) -> list[str]:
    """Grapheme-ish clusters: marks and stacked consonants stay with their base letter."""
    result: list[str] = []
    for ch in text:
        if result and (unicodedata.category(ch) in {"Mn", "Mc", "Me"}
                       or ch in "\u200c\u200d\ufe0f" or result[-1][-1] in "\u1039\u200d"):
            result[-1] += ch
        else:
            result.append(ch)
    return result


def _is_mm_base(ch: str) -> bool:
    return "\u1000" <= ch <= "\u109f" and unicodedata.category(ch) not in {"Mn", "Mc", "Me"}


def myanmar_issues(text: str) -> list[str]:
    """Deterministic Unicode checks: they catch broken / mis-ordered / Zawgyi-style text.

    They do not judge spelling or grammar.
    """
    issues: list[str] = []
    t = str(text or "")
    if not any("\u1000" <= ch <= "\u109f" for ch in t):
        return ["no Myanmar characters"]
    for i, ch in enumerate(t):
        code = ord(ch)
        cat = unicodedata.category(ch)
        if ch == "\ufffd":
            issues.append(f"replacement character at {i}")
        elif cat == "Cc" and ch not in "\n\r\t":
            issues.append(f"control character U+{code:04X} at {i}")
        elif 0x202A <= code <= 0x202E or 0x2066 <= code <= 0x2069 or code in (0x200B, 0x200E, 0x200F):
            issues.append(f"invisible/direction mark U+{code:04X} at {i}")
        elif 0x1050 <= code <= 0x109F and code not in range(0x1040, 0x104A):
            issues.append(f"non-Burmese Myanmar-block letter U+{code:04X} at {i} (Zawgyi or other language?)")
        elif code >= 128 and not (0x1000 <= code <= 0x109F) and (ch.isalpha() or cat.startswith("M")):
            issues.append(f"other-script character U+{code:04X} at {i}")
        if cat in {"Mn", "Mc"} and "\u1000" <= ch <= "\u109f":
            prev = t[i - 1] if i else ""
            if not prev or not ("\u1000" <= prev <= "\u109f"):
                issues.append(f"mark U+{code:04X} without a base letter at {i}")
            elif prev == ch:
                issues.append(f"doubled mark U+{code:04X} at {i}")
    pairs = {
        "\u102f\u102d": "ု before ိ (should be ို)",
        "\u103e\u103d": "ှ before ွ (should be ွှ)",
        "\u1036\u102f": "ံ before ု (should be ုံ)",
    }
    for bad, why in pairs.items():
        if bad in t:
            issues.append(f"mark order: {why}")
    for i in range(len(t) - 1):
        if t[i] == "\u1031" and t[i + 1] in MEDIALS:
            issues.append(f"mark order: ေ before a medial at {i} (medial must come first)")
            break
    return issues


def text_issues(text: str, code: str = "my") -> list[str]:
    """Correctness check for one subtitle line in the narration language."""
    if code == "my":
        return myanmar_issues(text)
    import languages
    issues: list[str] = []
    for i, ch in enumerate(str(text or "")):
        cp, cat = ord(ch), unicodedata.category(ch)
        if ch == "�":
            issues.append(f"replacement character at {i}")
        elif cat == "Cc" and ch not in "\n\r\t":
            issues.append(f"control character U+{cp:04X} at {i}")
        elif cp in (0x200B,) or 0x202A <= cp <= 0x202E or 0x2066 <= cp <= 0x2069:
            issues.append(f"invisible/direction mark U+{cp:04X} at {i}")
        elif not ch.isascii() and (cat[0] in "LM") and not languages.in_script(ch, code):
            issues.append(f"letter from another script U+{cp:04X} at {i}")
    if not any(languages.in_script(ch, code) for ch in str(text or "")) and languages.get(code)["script"] is not languages.LATIN:
        issues.append(f"no {languages.get(code)['label']} letters")
    return issues


def _wrap_raw(text: str, max_clusters: int, breaks: list[int] | None = None) -> list[str]:
    """One or two lines, split near the middle at a space / clause mark, or at a word start
    from `breaks` (character offsets) for scripts written without spaces (Thai, Japanese)."""
    text = clean_text(text)
    parts = clusters(text)
    if len(parts) <= max_clusters:
        return [text]
    midpoint = len(parts) // 2
    candidates = {i for i in range(1, len(parts)) if parts[i - 1].isspace() or parts[i - 1] in {"၊", "။", ",", ";", "—", "、", "，"}}
    if breaks:
        starts, pos = {}, 0
        for idx, part in enumerate(parts):
            starts[pos] = idx
            pos += len(part)
        candidates |= {starts[b] for b in breaks if b in starts and 0 < starts[b] < len(parts)}
    candidates = sorted(candidates)
    fitting = [i for i in candidates if i <= max_clusters + 2 and len(parts) - i <= max_clusters + 2]
    split = min(fitting or candidates or [midpoint], key=lambda i: abs(i - midpoint))
    return ["".join(parts[:split]).strip(), "".join(parts[split:]).strip()]


def wrap_two_lines(text: str, max_clusters: int, breaks: list[int] | None = None) -> tuple[str, int]:
    """Break on a phrase boundary near the middle without splitting Myanmar marks."""
    lines = _wrap_raw(text, max_clusters, breaks)
    return "\\N".join(lines), len(lines)


# ---------------------------------------------------------------- timing -------------

def block_timeline(work_dir: Path) -> tuple[list[dict], dict]:
    """Narration blocks with their exact start/end inside the finished video."""
    report = json.loads((Path(work_dir) / "smart_sync_thiha_28" / "SMART_SYNC_REPORT.json").read_text(encoding="utf-8"))
    num, den = str(report.get("fps") or "30/1").split("/", 1)
    fps = Fraction(int(num), int(den))
    rows, cum = [], 0
    for b in report["blocks"]:
        frames = int(b["frames"])
        start = float(Fraction(cum, 1) / fps)
        # "short" story: a pause after the narration is part of the block's audio, not of its speech
        speech = float(b["audio_duration"]) - float(b.get("pause_after_sec") or 0.0)
        rows.append({
            "bid": b["sync_block_id"],
            "text": clean_text(b.get("narration_text") or ""),
            "start": start,
            "speech_end": start + speech,
            "block_end": float(Fraction(cum + frames, 1) / fps),
            "audio_duration": speech,
            "words": b.get("words") or None,      # flow narration: exact timings cut from the same audio
        })
        cum += frames
    return rows, report


async def _stream_boundaries(text: str, voice: str, rate: str) -> tuple[list[dict], float]:
    import edge_tts
    comm = edge_tts.Communicate(text, voice, rate=rate, boundary="WordBoundary")
    words, audio_bytes = [], 0
    async for chunk in comm.stream():
        if chunk["type"] == "audio":
            audio_bytes += len(chunk["data"])
        elif chunk["type"] == "WordBoundary":
            start = chunk["offset"] / 1e7
            words.append({"start": start, "end": start + chunk["duration"] / 1e7, "text": chunk["text"]})
    # edge-tts default output: 24 kHz mono MP3 at 48 kbit/s
    return words, audio_bytes * 8 / 48000.0


def word_boundaries(text: str, voice: str, rate: str, cache_dir: Path) -> dict:
    """Phrase timing for one narration block (cached per text / voice / rate).

    edge-tts honours HTTP(S)_PROXY; the Studio clears those at startup (Gemini gets --proxy).
    """
    key = hashlib.sha1(f"{text}|{voice}|{rate}|wb1".encode("utf-8")).hexdigest()[:16]
    cache = Path(cache_dir) / f"wb_{key}.json"
    if cache.is_file():
        try:
            return json.loads(cache.read_text(encoding="utf-8"))
        except Exception:
            pass
    last_exc = None
    for attempt in range(3):
        try:
            words, audio_sec = asyncio.run(_stream_boundaries(text, voice, rate))
            data = {"words": words, "audio_sec": audio_sec}
            cache.parent.mkdir(parents=True, exist_ok=True)
            cache.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            return data
        except Exception as exc:  # network hiccup
            last_exc = exc
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"Edge TTS word timing failed: {last_exc}")


SENTENCE_MARKS = "။.!?。！？؟।"
CLAUSE_MARKS = "၊,،、;；:"


def _cluster_break_ok(text: str, i: int) -> bool:
    """A cue or line may start at text[i] without splitting a letter cluster."""
    if i <= 0 or i >= len(text):
        return True
    ch, prev = text[i], text[i - 1]
    return not (unicodedata.category(ch) in {"Mn", "Mc", "Me"} or ch in "‌‍️" or prev in "္‍")


def anchor_words(text: str, words: list[dict]) -> list[dict] | None:
    """Word timings -> tokens with their character span in text.

    Edge TTS sometimes splits a word right before a combining mark (ပြ|ုံး); such a token is
    merged into the previous one, so no cue or line ever starts inside a letter cluster.
    None when a word cannot be found in the text.
    """
    tokens, pos = [], 0
    for w in words:
        t = str(w.get("text") or "").strip()
        if not t:
            continue
        i = text.find(t, pos)
        if i < 0:
            return None
        if tokens and not _cluster_break_ok(text, i):
            tokens[-1]["end"], tokens[-1]["t1"] = i + len(t), float(w["end"])
        else:
            tokens.append({"start": i, "end": i + len(t), "t0": float(w["start"]), "t1": float(w["end"])})
        pos = i + len(t)
    return tokens or None


def _chunk_tokens(text: str, tokens: list[dict], max_clusters: int, spaced: bool = True) -> list[list[dict]]:
    """Cues of at most two lines: always cut after sentence punctuation, prefer after a clause mark."""
    chunks, cur, size = [], [], 0
    limit = max_clusters * 2
    gap = 1 if spaced else 0
    for k, tok in enumerate(tokens):
        n = len(clusters(text[tok["start"]:tok["end"]])) + (gap if cur else 0)
        if cur and size + n > limit:
            chunks.append(cur)
            cur, size = [], 0
            n -= gap
        cur.append(tok)
        size += n
        # the word itself plus whatever follows it up to the next word (punctuation may be in either)
        tail = text[tok["start"]:tokens[k + 1]["start"] if k + 1 < len(tokens) else len(text)].rstrip()
        if tail and (tail[-1] in SENTENCE_MARKS or (tail[-1] in CLAUSE_MARKS and size >= max_clusters)):
            chunks.append(cur)
            cur, size = [], 0
    if cur:
        chunks.append(cur)
    return chunks


def _chunk_words(words: list[dict], max_clusters: int) -> list[list[dict]]:
    """Group phrases into cues: at most two lines, always cut after ။, prefer cutting after ၊."""
    chunks, cur, size = [], [], 0
    limit = max_clusters * 2
    for w in words:
        n = len(clusters(w["text"])) + (1 if cur else 0)
        if cur and size + n > limit:
            chunks.append(cur)
            cur, size = [], 0
            n = len(clusters(w["text"]))
        cur.append(w)
        size += n
        text = w["text"].rstrip()
        if text.endswith("။") or (text.endswith("၊") and size >= max_clusters):
            chunks.append(cur)
            cur, size = [], 0
    if cur:
        chunks.append(cur)
    return chunks


def _proportional_words(text: str, duration: float, offset: float = 0.0) -> list[dict]:
    """Fallback when word timing is unavailable: spread phrases by cluster count."""
    phrases = [p for p in clean_text(text).split(" ") if p]
    weights = [max(1, len(clusters(p))) for p in phrases]
    total = float(sum(weights)) or 1.0
    t, words = offset, []
    for p, wgt in zip(phrases, weights):
        d = duration * wgt / total
        words.append({"start": t, "end": t + d, "text": p})
        t += d
    return words


def speech_span(wav_path: Path, threshold_db: float = -38.0) -> tuple[float, float] | None:
    """(first, last) second where a 16-bit PCM WAV is louder than peak + threshold_db."""
    import wave
    import numpy as np

    with wave.open(str(wav_path), "rb") as wf:
        rate, channels, width = wf.getframerate(), wf.getnchannels(), wf.getsampwidth()
        if width != 2:
            return None
        data = np.frombuffer(wf.readframes(wf.getnframes()), dtype="<i2")
    if not data.size:
        return None
    level = np.abs(data.reshape(-1, channels).astype(np.float32)).max(axis=1)
    win = max(1, rate // 100)                                   # 10 ms windows
    count = level.size // win
    if not count:
        return None
    env = level[: count * win].reshape(count, win).max(axis=1)
    loud = np.nonzero(env >= env.max() * 10 ** (threshold_db / 20.0))[0]
    if not loud.size or env.max() <= 0:
        return None
    return float(loud[0] * win / rate), float((loud[-1] + 1) * win / rate)


def _fit_words(words: list[dict], span: tuple[float, float]) -> list[dict]:
    """Edge TTS word positions stretched onto another voice's speech span (VoxCPM blocks)."""
    w0, w1 = words[0]["start"], max(w["end"] for w in words)
    if w1 - w0 < 0.05 or span[1] - span[0] < 0.05:
        return []
    k = (span[1] - span[0]) / (w1 - w0)
    return [{"start": span[0] + (w["start"] - w0) * k, "end": span[0] + (w["end"] - w0) * k, "text": w["text"]}
            for w in words]


def build_cues(blocks: list[dict], voice: str, rate: str, cache_dir: Path, max_clusters: int,
               log=lambda _m: None, spans: dict | None = None, spaced: bool = True) -> list[dict]:
    """spans (VoxCPM runs): block id -> measured speech span of its audio. Edge word timing then
    only gives relative phrase positions, stretched onto that span. Blocks that carry "words"
    (flow narration: cut from the same continuous TTS audio) use those timings as they are."""
    cues: list[dict] = []
    for b in blocks:
        if not b["text"]:
            continue
        span = (spans or {}).get(b["bid"])
        words: list[dict] = [dict(w) for w in (b.get("words") or []) if str(w.get("text") or "").strip()]
        if not words:
            try:
                wb = word_boundaries(b["text"], voice, rate, cache_dir)
                if span and wb.get("words"):
                    words = _fit_words(wb["words"], span)
                else:
                    scale = b["audio_duration"] / wb["audio_sec"] if wb.get("audio_sec") else 1.0
                    if wb.get("words") and 0.85 <= scale <= 1.15:
                        words = [{"start": w["start"] * scale, "end": w["end"] * scale, "text": w["text"]} for w in wb["words"]]
            except Exception as exc:
                log(f"⚠️ {b['bid']}: word timing unavailable ({exc}); using proportional timing")
        if not words:
            if span:
                words = _proportional_words(b["text"], max(0.3, span[1] - span[0]), span[0])
            else:
                words = _proportional_words(b["text"], max(0.5, b["audio_duration"] - 0.3))
        tokens = anchor_words(b["text"], words)
        if tokens:
            # cue text is cut from the narration itself: original spacing, punctuation kept
            chunks = _chunk_tokens(b["text"], tokens, max_clusters, spaced)
            timed = []
            for i, ch in enumerate(chunks):
                cut = chunks[i + 1][0]["start"] if i + 1 < len(chunks) else len(b["text"])
                raw = b["text"][ch[0]["start"]:cut]
                lead = len(raw) - len(raw.lstrip())
                # scripts without spaces (Thai, Japanese) may only wrap at a word start
                breaks = None if spaced else [t["start"] - ch[0]["start"] - lead for t in ch[1:]]
                timed.append((ch[0]["t0"], ch[-1]["t1"], raw.strip(), breaks))
        else:       # words not found in the text: join them, but never put a space before a mark
            timed = [(ch[0]["start"], ch[-1]["end"],
                      "".join((" " if k and spaced and _cluster_break_ok(" " + w["text"].strip(), 1) else "")
                              + w["text"].strip() for k, w in enumerate(ch)).strip(), None)
                     for ch in _chunk_words(words, max_clusters)]
        for i, (t0, t1, text, breaks) in enumerate(timed):
            start = b["start"] + t0
            if i + 1 < len(timed):
                end = b["start"] + timed[i + 1][0]
            else:
                end = min(b["block_end"], b["start"] + t1 + 0.35)
            if end - start < 0.25:
                end = start + 0.25
            cues.append({"start": start, "end": end, "text": text, "bid": b["bid"],
                         **({"breaks": breaks} if breaks else {})})
    for a, nxt in zip(cues, cues[1:]):   # never overlap
        a["end"] = min(a["end"], nxt["start"])
    return cues


# ---------------------------------------------------------------- files --------------

def _fmt_ass(seconds: float) -> str:
    cs = max(0, round(seconds * 100))
    h, rem = divmod(cs, 360000)
    m, rem = divmod(rem, 6000)
    s, cs = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _fmt_srt(seconds: float) -> str:
    ms = max(0, round(seconds * 1000))
    h, rem = divmod(ms, 3600000)
    m, rem = divmod(rem, 60000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _ass_escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}")


def line_capacity(width: int, size: int, char_w: float = 0.72) -> int:
    """Clusters per line (same heuristic as myanmar_subtitle_tool). char_w = average glyph
    width / font size for the script: Burmese 0.72, Latin 0.52, Japanese 1.0 (languages.py)."""
    return max(6, int(width * 0.88 / (size * char_w)))


PANEL_ALPHA = 0x60          # ASS alpha of the box panel (0 = opaque, 255 = invisible) -> ~62% opaque


def _style_line(style: dict, plain: bool = False) -> str:
    size = int(style.get("size", 60))
    font = str(style.get("font") or MM_FONTS[0])
    if plain:       # measuring: white text only, no outline / shadow
        spec = "&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0"
    elif str(style.get("style", "box")) == "box":
        spec = f"&H00FFFFFF,&H00FFFFFF,&H00202020,&HFF000000,0,0,0,0,100,100,0,0,1,{max(1, size // 40)},0"
    else:
        spec = f"&H00FFFFFF,&H00FFFFFF,&H00101010,&H96000000,0,0,0,0,100,100,0,0,1,{max(2, round(size * 0.075))},{max(1, size // 28)}"
    return f"Style: MM,{font},{size},{spec},5,20,20,20,1\n"


def _ass_header(width: int, height: int, style: dict, plain: bool = False) -> str:
    return (
        "[Script Info]\nScriptType: v4.00+\nWrapStyle: 2\nScaledBorderAndShadow: yes\n"
        f"PlayResX: {width}\nPlayResY: {height}\n\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
        "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
        "Alignment, MarginL, MarginR, MarginV, Encoding\n"
        + _style_line(style, plain)
        + "Style: Panel,Arial,20,&H00000000,&H00000000,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1\n\n"
        "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )


def wrapped_lines(text: str, width: int, size: int, char_w: float = 0.72,
                  breaks: list[int] | None = None) -> tuple[str, int]:
    lines = _wrap_raw(text, line_capacity(width, size, char_w), breaks)
    return "\\N".join(_ass_escape(line) for line in lines), len(lines)


def panel_rect(extent: tuple[float, float] | None, lines: int, style: dict, width: int, height: int) -> tuple[int, int, int, int]:
    """Box panel around one cue: width from the measured text, height from the line count."""
    size = int(style.get("size", 60))
    pad_x, pad_y = max(10, round(size * 0.35)), max(6, round(size * 0.18))
    cx, cy = width * 0.5, height * float(style.get("pos_y", 0.76))
    half_w = (extent[1] - extent[0]) / 2.0 if extent else width * 0.40
    offset = (extent[0] + extent[1]) / 2.0 if extent else 0.0
    half_h = size * 1.28 * lines / 2.0
    x1 = int(round(max(0, cx + offset - half_w - pad_x)))
    x2 = int(round(min(width, cx + offset + half_w + pad_x)))
    y1 = int(round(max(0, cy - half_h - pad_y)))
    y2 = int(round(min(height, cy + half_h + pad_y)))
    return x1, y1, x2, y2


def _rounded(w: int, h: int, r: int) -> str:
    r = max(0, min(r, w // 2, h // 2))
    return (f"m {r} 0 l {w - r} 0 b {w} 0 {w} 0 {w} {r} l {w} {h - r} b {w} {h} {w} {h} {w - r} {h} "
            f"l {r} {h} b 0 {h} 0 {h} 0 {h - r} l 0 {r} b 0 0 0 0 {r} 0")


def measure_extents(texts: list[str], width: int, height: int, style: dict, work_dir: Path, ffmpeg: str,
                    breaks_list: list | None = None) -> list:
    """Horizontal ink extent of each wrapped cue, relative to the centre anchor.

    Measured by libass itself (the renderer that burns the video): PIL cannot shape
    Myanmar here, so its widths would be wrong.
    """
    import shutil
    import subprocess
    from PIL import Image

    work_dir = Path(work_dir)
    tmp = work_dir / "_subtitle_measure"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True, exist_ok=True)
    mw, mh = max(2, width // 4 * 2), max(2, height // 4 * 2)   # half resolution is plenty
    size = int(style.get("size", 60))
    rows = [_ass_header(width, height, style, plain=True)]
    for i, text in enumerate(texts):
        wrapped, _lines = wrapped_lines(text, width, size, style.get("char_w", 0.72),
                                        breaks_list[i] if breaks_list else None)
        # frame i of the 1 fps source is at exactly t=i s, so cue i must cover [i, i+1)
        rows.append(f"Dialogue: 0,{_fmt_ass(i)},{_fmt_ass(i + 0.9)},MM,,0,0,0,,"
                    f"{{\\an5\\pos({width // 2},{height // 2})}}{wrapped}\n")
    (tmp / "measure.ass").write_text("".join(rows), encoding="utf-8-sig")
    subprocess.run(
        [ffmpeg, "-v", "error", "-y", "-f", "lavfi", "-i", f"color=c=black:s={mw}x{mh}:r=1:d={len(texts)}",
         "-vf", "ass=measure.ass", "-frames:v", str(len(texts)), "m_%05d.png"],
        cwd=str(tmp), check=True, capture_output=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    scale = width / float(mw)
    extents = []
    for i in range(len(texts)):
        with Image.open(tmp / f"m_{i + 1:05d}.png") as im:
            bbox = im.convert("L").point(lambda v: 255 if v > 48 else 0).getbbox()
        extents.append(None if not bbox else (bbox[0] * scale - width / 2.0, bbox[2] * scale - width / 2.0))
    shutil.rmtree(tmp, ignore_errors=True)
    return extents


def write_ass(cues: list[dict], path: Path, width: int, height: int, style: dict,
              extents: list | None = None) -> Path:
    size = int(style.get("size", 60))
    box = str(style.get("style", "box")) == "box"
    cx = int(round(width * 0.5))
    cy = int(round(height * float(style.get("pos_y", 0.76))))
    rows = [_ass_header(width, height, style)]
    for i, cue in enumerate(cues):
        wrapped, lines = wrapped_lines(cue["text"], width, size, style.get("char_w", 0.72), cue.get("breaks"))
        start, end = _fmt_ass(cue["start"]), _fmt_ass(cue["end"])
        if box:
            x1, y1, x2, y2 = panel_rect(extents[i] if extents else None, lines, style, width, height)
            shape = _rounded(x2 - x1, y2 - y1, max(6, size // 4))
            rows.append(f"Dialogue: 0,{start},{end},Panel,,0,0,0,,"
                        f"{{\\an7\\pos({x1},{y1})\\p1\\bord0\\shad0\\1c&H000000&\\1a&H{PANEL_ALPHA:02X}&}}{shape}{{\\p0}}\n")
        rows.append(f"Dialogue: 1,{start},{end},MM,,0,0,0,,{{\\an5\\pos({cx},{cy})}}{wrapped}\n")
    path.write_text("".join(rows), encoding="utf-8-sig")
    return path


def render_preview_png(text: str, width: int, height: int, style: dict, pw: int, ph: int,
                       work_dir: Path, ffmpeg: str):
    """The subtitle exactly as libass burns it, as an RGBA image at preview scale.

    Rendered on black and on white; the difference gives exact alpha (panel included).
    Returns (image, (left, top)) where left/top are preview pixels.
    """
    import subprocess
    import numpy as np
    from PIL import Image

    work_dir = Path(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)
    extents = measure_extents([text], width, height, style, work_dir, ffmpeg)
    write_ass([{"start": 0.0, "end": 5.0, "text": text}], work_dir / "preview_sub.ass", width, height, style, extents)
    planes = []
    for bg in ("black", "white"):
        out = work_dir / f"preview_sub_{bg}.png"
        subprocess.run(
            [ffmpeg, "-v", "error", "-y", "-f", "lavfi", "-i", f"color=c={bg}:s={pw}x{ph}:d=1",
             "-vf", "ass=preview_sub.ass", "-frames:v", "1", out.name],
            cwd=str(work_dir), check=True, capture_output=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        with Image.open(out) as im:
            planes.append(np.asarray(im.convert("RGB"), dtype=np.float32))
    on_black, on_white = planes
    alpha = np.clip(1.0 - (on_white - on_black).mean(axis=2) / 255.0, 0.0, 1.0)
    rgb = np.where(alpha[..., None] > 0.003, on_black / np.maximum(alpha[..., None], 0.003), 0)
    rgba = np.dstack([np.clip(rgb, 0, 255), alpha * 255]).astype("uint8")
    img = Image.fromarray(rgba, "RGBA")
    bbox = img.getchannel("A").point(lambda v: 255 if v > 3 else 0).getbbox()
    if not bbox:
        return None, (0, 0)
    return img.crop(bbox), (bbox[0], bbox[1])


def write_srt(cues: list[dict], path: Path) -> Path:
    lines = []
    for i, cue in enumerate(cues, 1):
        lines += [str(i), f"{_fmt_srt(cue['start'])} --> {_fmt_srt(cue['end'])}", cue["text"], ""]
    path.parent.mkdir(parents=True, exist_ok=True)      # FINALS_<CODE> may not exist yet
    path.write_text("\n".join(lines), encoding="utf-8-sig")
    return path


def installed_fonts(code: str = "my") -> list[str]:
    """Subtitle fonts for the narration language that are installed (preferred first)."""
    if code == "my":
        return installed_mm_fonts()
    import languages

    wanted = list(languages.get(code)["fonts"])
    found = _font_families()
    names = [n for n in wanted if n in found]
    return names or wanted[:1]


_FAMILIES: set[str] | None = None


def _font_families() -> set[str]:
    """Family names of the fonts in the Windows Fonts folder (scanned once)."""
    global _FAMILIES
    if _FAMILIES is None:
        from PIL import ImageFont
        found: set[str] = set()
        fonts_dir = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
        if fonts_dir.is_dir():
            for f in fonts_dir.iterdir():
                if f.suffix.lower() in (".ttf", ".otf", ".ttc"):
                    try:
                        found.add(ImageFont.truetype(str(f), 12).getname()[0])
                    except Exception:
                        continue
        _FAMILIES = found
    return _FAMILIES


def _myanmar_shaping(path: Path) -> bool:
    """A Unicode Myanmar font: its OpenType GSUB/GPOS script list holds Myanmar ('mym2', or the older 'mymr').
    Zawgyi fonts draw on the Myanmar code points without those rules (Unicode text comes out scrambled) and some
    art fonts have no Myanmar letters at all: neither is offered (BurmaArt2, BurmaArt 02; 2026-10-04)."""
    try:
        data = path.read_bytes()
        tables = {}
        for i in range(struct.unpack_from(">H", data, 4)[0]):
            tag, _sum, offset, _size = struct.unpack_from(">4sIII", data, 12 + 16 * i)
            tables[tag] = offset
        for tag in (b"GSUB", b"GPOS"):
            if tag not in tables:
                continue
            script_list = struct.unpack_from(">H", data, tables[tag] + 4)[0]
            if not script_list:
                continue
            scripts = tables[tag] + script_list
            for i in range(struct.unpack_from(">H", data, scripts)[0]):
                if data[scripts + 2 + 6 * i:scripts + 6 + 6 * i] in (b"mym2", b"mymr"):
                    return True
    except (OSError, struct.error):
        pass
    return False


def installed_mm_fonts() -> list[str]:
    """Family names (as libass/DirectWrite sees them) of installed Unicode Myanmar fonts."""
    from PIL import ImageFont

    dirs = [Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts"]
    hints = ("mmrtext", "myanmar", "pyidaungsu", "padauk", "burma", "masterpiece", "zawdecode")
    names: list[str] = []
    for d in dirs:
        if not d.is_dir():
            continue
        for f in sorted(d.iterdir()):
            if f.suffix.lower() not in (".ttf", ".otf") or not any(h in f.name.lower() for h in hints):
                continue
            if not _myanmar_shaping(f):          # Zawgyi or no Myanmar letters: the subtitles would come out broken
                continue
            try:
                family = ImageFont.truetype(str(f), 12).getname()[0]
            except Exception:
                continue
            if family and family not in names:
                names.append(family)
    if "Myanmar Text" in names:
        names.remove("Myanmar Text")
    return ["Myanmar Text"] + names
