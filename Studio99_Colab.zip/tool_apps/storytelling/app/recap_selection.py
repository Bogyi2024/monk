"""Whole-scene recap selection, with evidence-only bridges and stable source block IDs."""
from __future__ import annotations

from pathlib import Path


def group_scenes(beats, letters_per_sec=20.0):
    scenes = []
    for i, original in enumerate(beats):
        b = dict(original, _v67_block_id=f"B{i + 1:04d}")
        start, end = float(b["file_start_sec"]), float(b["file_end_sec"])
        previous = scenes[-1]["beats"][-1] if scenes else None
        same = previous and b["source_file"] == previous["source_file"] and b.get("location") == previous.get("location")
        if not same or start - float(previous["file_end_sec"]) > 3:
            scenes.append({"id": len(scenes), "beats": [], "estimate": 0.0, "score": 0.0})
        scene = scenes[-1]
        b["recap_scene_id"] = scene["id"]
        scene["beats"].append(b)
        # The short writer's max_letters estimate at the chosen voice rate.
        estimate = max(1.8, 1.1 * max(0.03, end - start)) * 20.0 / letters_per_sec
        scene["estimate"] += estimate
        scene["score"] = max(scene["score"], float(b.get("importance") or 3))
    return scenes


def source_seconds(beats):
    """The analysed footage: the end of each source file's last beat, added up."""
    ends = {}
    for b in beats:
        ends[b["source_file"]] = max(ends.get(b["source_file"], 0.0), float(b["file_end_sec"]))
    return sum(ends.values())


def target_seconds(beats, minutes=12.0, percent=0.0):
    """Recap length for this video (2026-10-25, user: "2 h video → 1 h 30 recap, never longer than the video"):
    N minutes, or N% of the video when a percent is given; at most the video's own length."""
    source = source_seconds(beats)
    target = source * float(percent) / 100 if percent else float(minutes) * 60
    return min(target, source) if source > 0 else target, source


INTRO_MIN_BEATS = 5      # a person in at least this many beats comes back: their first scene is kept first


def _people(b):
    return [p for p in [b.get("speaker")] + list(b.get("actors") or []) + list(b.get("targets") or [])
            if isinstance(p, str) and p.strip() and not p.upper().startswith(("UNKNOWN", "NEW_"))]


def recurring_people(scenes, important=()):
    """{person: (the scene they first appear in, beats they are in)} for everyone who comes back (2026-10-25, user:
    "a person turns up and nobody knows how he got there": the 12-min recap of a 1 h video had dropped the first
    scene of 28 of its 33 recurring people). Recurring = in INTRO_MIN_BEATS+ beats, or main / supporting in the
    cast (`important`)."""
    count, first = {}, {}
    for s in scenes:
        for b in s["beats"]:
            for p in set(_people(b)):
                count[p] = count.get(p, 0) + 1
                first.setdefault(p, s["id"])
    return {p: (first[p], count[p] + (100000 if p in important else 0))
            for p in first if count[p] >= INTRO_MIN_BEATS or p in important}


def intro_scenes(recurring):
    """{scene id: weight} — each recurring person's first scene; the weight is the most-seen person's beat count."""
    out = {}
    for sid, weight in recurring.values():
        out[sid] = max(out.get(sid, 0), weight)
    return out


def choose_scenes(scenes, target_seconds, recurring=None):
    if not scenes:
        return set()
    kept = {scenes[0]["id"], scenes[-1]["id"]}
    duration = sum(s["estimate"] for s in scenes if s["id"] in kept)
    by_id = {s["id"]: s for s in scenes}
    # the scenes that introduce the people who come back, the most-seen people first, as far as the target allows
    for sid, _weight in sorted(intro_scenes(recurring or {}).items(), key=lambda kv: (-kv[1], kv[0])):
        if sid not in kept and duration + by_id[sid]["estimate"] <= target_seconds:
            kept.add(sid)
            duration += by_id[sid]["estimate"]
    candidates = sorted((s for s in scenes if s["id"] not in kept),
                        key=lambda s: (-s["score"], -s["score"] / max(s["estimate"], 0.01), s["id"]))
    for s in candidates:
        new = duration + s["estimate"]
        if new <= target_seconds * 1.1 and (duration < target_seconds * 0.9 or
                                              abs(new - target_seconds) < abs(duration - target_seconds)):
            kept.add(s["id"])
            duration = new
    return kept


def kept_beats(scenes, kept, report_path=None, target_seconds=None, recurring=None):
    result, skipped = [], []
    # a recurring person whose first scene was left out is introduced where the recap first shows them
    pending = {p for p, (sid, _w) in (recurring or {}).items() if sid not in kept}
    introduced = []
    for scene in scenes:
        if scene["id"] not in kept:
            skipped.extend(scene["beats"])
            continue
        rows = [dict(b) for b in scene["beats"]]
        if skipped and rows:
            evidence = []
            for b in skipped:
                parts = [str(b.get(k) or "").strip() for k in ("dialogue_meaning", "visual_action")]
                fact = "; ".join(p for p in parts if p)
                if fact:
                    evidence.append(fact)
            rows[0]["after_skipped"] = " | ".join(evidence)[:2400]
            rows[0]["recap_bridge"] = True
            skipped = []
        for b in rows:
            new = [p for p in dict.fromkeys(_people(b)) if p in pending]
            if new:
                b["introduce"] = new
                pending.difference_update(new)
                introduced.append((new, b))
        result.extend(rows)
    if report_path:
        firsts = {}
        for p, (sid, _w) in (recurring or {}).items():
            firsts.setdefault(sid, []).append(p)
        lines = [f"Target: {target_seconds or 0:.1f}s; kept {len(kept)}/{len(scenes)} whole scenes",
                 "Estimates precede TTS; opening and ending are always kept, then the scenes where the people "
                 "who come back first appear."]
        for s in scenes:
            first, last = s["beats"][0], s["beats"][-1]
            lines.append(f"{'KEEP' if s['id'] in kept else 'DROP'} scene {s['id']:04d}: "
                         f"{first['source_file']} {float(first['file_start_sec']):.2f}–{float(last['file_end_sec']):.2f}s "
                         f"importance={s['score']:g} estimated speech={s['estimate']:.1f}s"
                         + (f" | first appearance: {', '.join(firsts[s['id']])}" if s["id"] in firsts else ""))
        for new, b in introduced:
            lines.append(f"INTRODUCED IN ONE LINE at {float(b['file_start_sec']):.2f}s: {', '.join(new)} "
                         "(their first scene was left out)")
        Path(report_path).write_text("\n".join(lines) + "\n", encoding="utf-8")
    return result


def drop_over_target(scenes, kept, blocks, durations, target_seconds, recurring=None):
    """Use measured TTS; drop the lowest importance removable scene until within +10% (a scene that introduces a
    recurring person last, the least-seen person first)."""
    intros = intro_scenes(recurring or {})
    actual = {}
    for b, dur in zip(blocks, durations):
        sid = b["recap_scene_id"]
        actual[sid] = actual.get(sid, 0.0) + float(dur)
    result = set(kept)
    total = sum(durations)
    mandatory = {scenes[0]["id"], scenes[-1]["id"]}
    for s in sorted((s for s in scenes if s["id"] in kept - mandatory),
                    key=lambda s: (s["id"] in intros, intros.get(s["id"], 0), s["score"],
                                   -actual.get(s["id"], 0), s["id"])):
        if total <= target_seconds * 1.1:
            break
        result.remove(s["id"])
        total -= actual.get(s["id"], 0)
    return result
