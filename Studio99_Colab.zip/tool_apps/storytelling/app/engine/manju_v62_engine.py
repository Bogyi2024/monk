# -*- coding: utf-8 -*-
"""
Manju V6.0 — Gemini-only transcript/timestamps + visual/VFX timeline + storytelling sync

Main changes from V2
- Uses faster-whisper / CTranslate2 for lower VRAM use and better speed.
- Default: medium + CUDA + int8_float16.
- 10-minute resumable chunk cache.
- Detects repetition loops and retries only suspicious windows.
- Retry log includes exact source file + file-relative timestamps.
- MANUAL_REVIEW.txt contains only unresolved spots.
- No word-level timestamps.
- Keeps a compact MP3 audio reference for speaker-attribution checks in Gemini.
- Creates COMBINED_AUDIO_REFERENCE.mp3 + AUDIO_REFERENCE_MAP.txt for easy upload.
- Temporary 16 kHz WAV cache is still deleted by default.

Install (default V6):
    pip install -U google-genai

Optional legacy Whisper mode:
    pip install -U faster-whisper

Run:
    python manju_whisper_transcribe_v3.1.py "C:\\Users\\myosi\\Desktop\\HenShi"

V4.2.1 short-command example (env + proxy are built-in defaults):
    python manju_video_recap_v4.2.1_shortcmd.py "C:\\Users\\myosi\\Desktop\\HenShi"

Lower VRAM fallback:
    python manju_whisper_transcribe_v3.1.py "C:\\Users\\myosi\\Desktop\\HenShi" --compute-type int8
"""

import argparse
import contextlib
import copy
import importlib.util
import json
import re
import shutil
import subprocess
import sys
import math
import threading
import time
from pathlib import Path

# Script Review imports this engine by filename, without the engine directory on
# sys.path. Resolve our sibling explicitly for both that path and the CLI, using
# a private module name so another tool's gemini_response cannot shadow it.
_reply_path = Path(__file__).resolve().with_name("gemini_response.py")
_reply_name = "_studio99_storytelling_gemini_response"
_reply = sys.modules.get(_reply_name)
if _reply is None or Path(_reply.__file__).resolve() != _reply_path:
    _reply_spec = importlib.util.spec_from_file_location(_reply_name, _reply_path)
    _reply = importlib.util.module_from_spec(_reply_spec)
    _reply_spec.loader.exec_module(_reply)
    sys.modules[_reply_name] = _reply
GeminiReplyError = _reply.GeminiReplyError
raise_if_terminal = _reply.raise_if_terminal
response_json = _reply.response_json
response_text = _reply.response_text
safe_error = _reply.safe_error
transport_json_error = _reply.transport_json_error

# V6 Gemini-only mode has NO Whisper dependency. Import legacy Whisper lazily/optionally.
try:
    import ctranslate2
    from faster_whisper import WhisperModel
except ImportError:
    ctranslate2 = None
    WhisperModel = None

VIDEO_EXTS = {".mp4", ".mkv", ".mov", ".avi", ".webm", ".m4v", ".ts"}
AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".opus"}
SUPPORTED_EXTS = VIDEO_EXTS | AUDIO_EXTS
PUNCT_RE = re.compile(r"""[\s，。！？、；：,.!?;:'\"“”‘’（）()\[\]{}<>《》【】…—\-~·]+""")

# MANJU local defaults — command line stays short.
DEFAULT_GEMINI_ENV_FILE = r""
DEFAULT_GEMINI_PROXY = ""
# 2026-10-02 benchmark on the link test (3 clips judged by the V6.3 check + Whisper, one story part): 3-flash-preview
# 3/3 right and the best Burmese, never busy; 3.8/3.7/3.6 answered 503 to 77-91% of 85-91 tries (a 503 on a video
# request came after ~100 s); 3.5-flash right but slow; flash-lite fast but 2 of 3 clips wrong (kept last, halves).
DEFAULT_GEMINI_MODELS = "gemini-3-flash-preview,gemini-3.5-flash,gemini-3.5-flash-lite"


def command_exists(cmd):
    return shutil.which(cmd) is not None


def run(cmd, quiet=False):
    if not quiet:
        print("\n>", " ".join(f'"{str(x)}"' if " " in str(x) else str(x) for x in cmd))
    subprocess.run(
        cmd,
        check=True,
        stdout=subprocess.DEVNULL if quiet else None,
        stderr=subprocess.DEVNULL if quiet else None,
    )


def ffprobe_duration(src):
    out = subprocess.check_output(
        [
            "ffprobe", "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            str(src),
        ],
        text=True,
        encoding="utf-8",
        errors="ignore",
    ).strip()
    return float(out)


def srt_time(seconds):
    seconds = max(0.0, float(seconds))
    total_ms = int(round(seconds * 1000))
    h, rem = divmod(total_ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def normalize_text(text):
    return PUNCT_RE.sub("", (text or "").strip()).lower()


def parse_clock_seconds(value):
    """Parse HH:MM:SS,mmm (or HH:MM:SS.mmm) into seconds."""
    value = (value or "").strip().replace(".", ",")
    h, m, rest = value.split(":")
    if "," in rest:
        s, ms = rest.split(",", 1)
    else:
        s, ms = rest, "0"
    ms = (ms + "000")[:3]
    return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000.0


def load_previous_manual_review_ranges(path):
    """Return {source_filename: [(start_sec, end_sec), ...]} from old MANUAL_REVIEW.txt."""
    ranges = {}
    if not path.exists():
        return ranges

    current_file = None
    try:
        lines = path.read_text(encoding="utf-8-sig", errors="ignore").splitlines()
    except Exception:
        return ranges

    for raw in lines:
        line = raw.strip()
        if line.startswith("FILE:"):
            current_file = line.split(":", 1)[1].strip()
        elif line.startswith("TIME:") and current_file and "->" in line:
            value = line.split(":", 1)[1].strip()
            left, right = [x.strip() for x in value.split("->", 1)]
            try:
                start = parse_clock_seconds(left)
                end = parse_clock_seconds(right)
                ranges.setdefault(current_file, []).append((start, end))
            except Exception:
                pass
    return ranges


def ranges_overlap(start_a, end_a, start_b, end_b):
    return start_a < end_b and end_a > start_b


def natural_sort_key(path_or_name):
    """Natural numeric sort: 1, 2, 3, ... 10, 11 instead of 1, 10, 11, 2."""
    name = Path(path_or_name).name.lower()
    return [
        int(part) if part.isdigit() else part
        for part in re.split(r"(\d+)", name)
    ]


def extract_full_audio(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    run([
        "ffmpeg", "-y", "-i", str(src), "-vn",
        "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(dst),
    ])


def extract_reference_audio(src, dst, bitrate="64k"):
    """Create a compact, voice-friendly MP3 that stays aligned to source time."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    run([
        "ffmpeg", "-y", "-i", str(src), "-vn",
        "-ac", "1", "-ar", "32000",
        "-c:a", "libmp3lame", "-b:a", str(bitrate),
        "-map_metadata", "-1", str(dst),
    ], quiet=True)


def _ffconcat_escape_filename(name):
    # The concat list sits in the same folder as the MP3 references, so a filename is enough.
    return str(name).replace("\\", "/").replace("'", "'\\''")


def create_combined_audio_reference(reference_files, output_path):
    """Concatenate same-format MP3 references without re-encoding."""
    refs = [Path(p) for p in reference_files if Path(p).exists()]
    if not refs:
        return False
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if len(refs) == 1:
        shutil.copy2(refs[0], output_path)
        return True

    list_path = refs[0].parent / "_audio_concat_list.txt"
    lines = [f"file '{_ffconcat_escape_filename(p.name)}'" for p in refs]
    list_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        run([
            "ffmpeg", "-y", "-f", "concat", "-safe", "0",
            "-i", str(list_path), "-c", "copy", str(output_path),
        ], quiet=True)
        return True
    finally:
        try:
            list_path.unlink()
        except Exception:
            pass


def write_audio_reference_map(completed_files, path, combined_name):
    """Map file-relative timestamps to positions in the combined reference audio."""
    lines = [
        "MANJU V3.1 AUDIO REFERENCE MAP",
        "",
        f"COMBINED AUDIO: {combined_name}",
        "",
        "RULE:",
        "- Per-file MP3 references use the SAME file-relative timestamps as the source video.",
        "- For the combined MP3, add the GLOBAL START below to the source-file timestamp.",
        "",
    ]
    global_offset = 0.0
    for item in completed_files:
        src = item["src"]
        duration = float(item["duration"])
        ref = item.get("audio_reference")
        lines += [
            f"FILE: {src.name}",
            f"REFERENCE: audio_reference/{Path(ref).name if ref else src.stem + '.mp3'}",
            f"GLOBAL START: {srt_time(global_offset)}",
            f"GLOBAL END: {srt_time(global_offset + duration)}",
            f"DURATION: {srt_time(duration)}",
            "",
        ]
        global_offset += duration
    path.write_text("\n".join(lines), encoding="utf-8-sig")


def write_gemini_upload_guide(path, combined_audio, map_path):
    body = f"""MANJU V3.1 — GEMINI SPEAKER CHECK UPLOAD GUIDE

Preferred files to upload for each story project:
1. COMBINED_TRANSCRIPT.txt
2. {combined_audio.name}
3. {map_path.name}

Use the transcript as the primary source of dialogue meaning.
Use the audio as secondary evidence for speaker turns, voice continuity, emotion, and speaker attribution.
Use AUDIO_REFERENCE_MAP.txt to convert a source-file timestamp into the combined-audio position.

If a speaker is still genuinely unresolved after checking the audio, flag the exact source file + timestamp instead of inventing a name.
"""
    path.write_text(body, encoding="utf-8-sig")


def extract_chunk(src_wav, dst_wav, start, duration, speech_clean=False):
    dst_wav.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "ffmpeg", "-y", "-ss", f"{start:.3f}", "-t", f"{duration:.3f}",
        "-i", str(src_wav), "-ac", "1", "-ar", "16000",
    ]
    if speech_clean:
        cmd += ["-af", "highpass=f=80,lowpass=f=7800,afftdn=nf=-25,dynaudnorm=f=150:g=9"]
    cmd += ["-c:a", "pcm_s16le", str(dst_wav)]
    run(cmd, quiet=True)


def compact_segment(seg):
    return {
        "start": float(seg.start),
        "end": float(seg.end),
        "text": (seg.text or "").strip(),
        "avg_logprob": float(getattr(seg, "avg_logprob", 0.0) or 0.0),
        "no_speech_prob": float(getattr(seg, "no_speech_prob", 0.0) or 0.0),
        "compression_ratio": float(getattr(seg, "compression_ratio", 0.0) or 0.0),
    }


def transcribe_audio(model, audio_path, language, beam_size, vad, duration_hint=None, show_progress=True):
    kwargs = dict(
        language=language,
        task="transcribe",
        beam_size=beam_size,
        condition_on_previous_text=False,
        temperature=0.0,
        compression_ratio_threshold=2.4,
        log_prob_threshold=-1.0,
        no_speech_threshold=0.6,
        word_timestamps=False,
        vad_filter=vad,
    )
    if vad:
        kwargs["vad_parameters"] = dict(min_silence_duration_ms=1000)

    segments_gen, info = model.transcribe(str(audio_path), **kwargs)
    out = []
    next_progress = 10

    for seg in segments_gen:
        item = compact_segment(seg)
        if item["text"]:
            out.append(item)
        if show_progress and duration_hint and duration_hint > 0:
            pct = min(100, int((float(seg.end) / duration_hint) * 100))
            if pct >= next_progress:
                print(f"    Progress: {pct:3d}% ({srt_time(seg.end)} / {srt_time(duration_hint)})")
                while next_progress <= pct:
                    next_progress += 10
    return out, info


def detect_repetition_blocks(segments, min_repeats=4):
    if not segments:
        return []
    norm = [normalize_text(s.get("text", "")) for s in segments]
    blocks = []

    i = 0
    while i < len(segments):
        token = norm[i]
        if not token:
            i += 1
            continue
        j = i + 1
        while j < len(segments) and norm[j] == token:
            j += 1
        count = j - i
        if count >= min_repeats:
            blocks.append({
                "start": float(segments[i]["start"]),
                "end": float(segments[j - 1]["end"]),
                "reason": f"same text repeated {count}x: {segments[i]['text']!r}",
            })
        i = j

    window = 8
    for i in range(0, max(0, len(segments) - window + 1)):
        chunk = norm[i:i + window]
        usable = [x for x in chunk if x]
        if len(usable) < window:
            continue
        unique = set(usable)
        avg_len = sum(len(x) for x in usable) / len(usable)
        if len(unique) <= 2 and avg_len <= 3:
            blocks.append({
                "start": float(segments[i]["start"]),
                "end": float(segments[i + window - 1]["end"]),
                "reason": f"tiny-text repetition window ({len(unique)} unique token(s))",
            })

    if not blocks:
        return []
    blocks.sort(key=lambda x: x["start"])
    merged = [blocks[0].copy()]
    for b in blocks[1:]:
        last = merged[-1]
        if b["start"] <= last["end"] + 1.0:
            last["end"] = max(last["end"], b["end"])
            if b["reason"] not in last["reason"]:
                last["reason"] += " | " + b["reason"]
        else:
            merged.append(b.copy())
    return merged


def replace_time_range(segments, start, end, replacement):
    kept = []
    inserted = False
    for seg in segments:
        midpoint = (float(seg["start"]) + float(seg["end"])) / 2.0
        if start <= midpoint <= end:
            if not inserted:
                kept.extend(replacement)
                inserted = True
            continue
        kept.append(seg)
    if not inserted and replacement:
        kept.extend(replacement)
    kept.sort(key=lambda s: (float(s["start"]), float(s["end"])))
    return kept


def join_text(segments):
    return " / ".join((s.get("text") or "").strip() for s in segments if (s.get("text") or "").strip())


def retry_block(model, full_wav, block, chunk_file_start, file_duration, retry_tmp,
                language, beam_size, retry_id, vad=False):
    pad_before = 3.0
    pad_after = 3.0
    bad_file_start = chunk_file_start + float(block["start"])
    bad_file_end = chunk_file_start + float(block["end"])
    clip_file_start = max(0.0, bad_file_start - pad_before)
    clip_file_end = min(file_duration, bad_file_end + pad_after)
    clip_duration = max(0.2, clip_file_end - clip_file_start)
    retry_wav = retry_tmp / f"retry_{retry_id:04d}.wav"

    extract_chunk(full_wav, retry_wav, clip_file_start, clip_duration, speech_clean=True)
    retry_segments, _ = transcribe_audio(
        model, retry_wav, language, beam_size, vad,
        duration_hint=clip_duration, show_progress=False,
    )

    converted = []
    for seg in retry_segments:
        abs_start = clip_file_start + float(seg["start"])
        abs_end = clip_file_start + float(seg["end"])
        midpoint = (abs_start + abs_end) / 2.0
        if bad_file_start <= midpoint <= bad_file_end:
            new_seg = dict(seg)
            new_seg["start"] = max(0.0, abs_start - chunk_file_start)
            new_seg["end"] = max(new_seg["start"], abs_end - chunk_file_start)
            converted.append(new_seg)

    try:
        retry_wav.unlink()
    except Exception:
        pass
    return converted



def collapse_consecutive_duplicate_segments(segments, max_repeats=2):
    """Best-effort cleanup for a retry that is still repetition-heavy.

    Keeps timing/order and preserves up to max_repeats consecutive identical lines,
    so genuine emphasis is not completely erased.
    """
    cleaned = []
    last_norm = None
    run_count = 0

    for seg in segments:
        token = normalize_text(seg.get("text", ""))
        if token and token == last_norm:
            run_count += 1
        else:
            last_norm = token
            run_count = 1

        if not token or run_count <= max_repeats:
            cleaned.append(dict(seg))

    return cleaned


def repair_repetitions(model, source_name, segments, full_wav, chunk_file_start,
                       file_duration, retry_tmp, language, beam_size,
                       retry_log_lines, manual_review_lines):
    current = list(segments)

    for sweep in range(1, 3):
        blocks = detect_repetition_blocks(current)
        if not blocks:
            break
        print(f"  [WARN] {source_name}: {len(blocks)} suspicious repetition block(s)")

        for n, block in enumerate(blocks, start=1):
            file_bad_start = chunk_file_start + float(block["start"])
            file_bad_end = chunk_file_start + float(block["end"])
            original = [
                s for s in current
                if block["start"] <= ((float(s["start"]) + float(s["end"])) / 2.0) <= block["end"]
            ]

            print(
                f"    Retry {n}/{len(blocks)} | FILE {srt_time(file_bad_start)} -> "
                f"{srt_time(file_bad_end)} | {block['reason']}"
            )

            # Retry 1: speech-clean audio, no VAD. This preserves faint/short dialogue.
            replacement = retry_block(
                model, full_wav, block, chunk_file_start, file_duration, retry_tmp,
                language, beam_size, sweep * 1000 + n, vad=False,
            )
            still_bad = bool(detect_repetition_blocks(replacement)) if replacement else True

            vad_replacement = []
            vad_still_bad = True

            if replacement and not still_bad:
                current = replace_time_range(current, block["start"], block["end"], replacement)
                status = "REPAIRED"
                print(f"      [OK] Retry 1 repaired: {join_text(replacement)}")
            else:
                # Retry 2: same cleaned window with Silero VAD ON.
                # This is aimed at scenes with sparse dialogue + music/SFX, where
                # Whisper may otherwise repeat the last phrase through non-speech.
                print("      [VAD RETRY] Retry 1 still suspicious; trying speech-only VAD pass...")
                vad_replacement = retry_block(
                    model, full_wav, block, chunk_file_start, file_duration, retry_tmp,
                    language, beam_size, sweep * 1000 + n + 5000, vad=True,
                )
                vad_still_bad = bool(detect_repetition_blocks(vad_replacement)) if vad_replacement else True

                if vad_replacement and not vad_still_bad:
                    current = replace_time_range(current, block["start"], block["end"], vad_replacement)
                    status = "REPAIRED_VAD"
                    print(f"      [OK] Retry 2 VAD repaired: {join_text(vad_replacement)}")
                else:
                    # Both retries remain suspicious. Prefer VAD text if it produced
                    # anything useful, otherwise Retry 1, then original. Collapse only
                    # consecutive exact repeats to at most 2 copies.
                    if vad_replacement:
                        salvage_source = vad_replacement
                    elif replacement:
                        salvage_source = replacement
                    else:
                        salvage_source = original

                    salvage = collapse_consecutive_duplicate_segments(salvage_source, max_repeats=2)

                    if salvage:
                        current = replace_time_range(current, block["start"], block["end"], salvage)
                        status = "RETRY2 STILL SUSPICIOUS - used de-duplicated salvage; manual review required"
                        print(f"      [CHECK] {status}")
                        print(f"      [SALVAGE] {join_text(salvage)}")
                    else:
                        status = "RETRY2 STILL SUSPICIOUS - no usable salvage; manual review required"
                        print(f"      [CHECK] {status}")

                    review = (
                        f"FILE: {source_name}\n"
                        f"TIME: {srt_time(file_bad_start)} -> {srt_time(file_bad_end)}\n"
                        f"REASON: {block['reason']}\n"
                        f"FIRST PASS: {join_text(original)}\n"
                        f"RETRY 1 (NO VAD): {join_text(replacement)}\n"
                        f"RETRY 2 (VAD): {join_text(vad_replacement)}\n"
                        f"SALVAGE USED IN MAIN TRANSCRIPT: {join_text(salvage)}\n"
                        "ACTION: Listen to this short section if exact wording/dialogue matters.\n"
                    )
                    if review not in manual_review_lines:
                        manual_review_lines.append(review)

            log_line = (
                f"FILE={source_name} | TIME={srt_time(file_bad_start)} -> {srt_time(file_bad_end)} | "
                f"REASON={block['reason']} | FIRST_PASS={join_text(original)!r} | "
                f"RETRY1={join_text(replacement)!r} | RETRY2_VAD={join_text(vad_replacement)!r} | STATUS={status}"
            )
            if log_line not in retry_log_lines:
                retry_log_lines.append(log_line)
    return current


def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_srt(segments, path):
    with path.open("w", encoding="utf-8-sig") as f:
        idx = 1
        for seg in segments:
            text = (seg.get("text") or "").strip()
            if not text:
                continue
            f.write(f"{idx}\n")
            f.write(f"{srt_time(seg['start'])} --> {srt_time(seg['end'])}\n")
            f.write(text + "\n\n")
            idx += 1


def write_txt(segments, path):
    with path.open("w", encoding="utf-8-sig") as f:
        for seg in segments:
            text = (seg.get("text") or "").strip()
            if text:
                f.write(f"[{srt_time(seg['start'])}] {text}\n")


def append_combined_srt(fh, segments, offset, start_index):
    idx = start_index
    for seg in segments:
        text = (seg.get("text") or "").strip()
        if not text:
            continue
        fh.write(f"{idx}\n")
        fh.write(
            f"{srt_time(float(seg['start']) + offset)} --> "
            f"{srt_time(float(seg['end']) + offset)}\n"
        )
        fh.write(text + "\n\n")
        idx += 1
    return idx


def clear_path(path):
    if path.is_dir():
        shutil.rmtree(path, ignore_errors=True)
    elif path.exists():
        try:
            path.unlink()
        except Exception:
            pass



# ============================================================================
# V4.2 VIDEO-EVIDENCE FULL-STORYTELLING LAYER
# Keeps the V3.1 Whisper/cache/repetition-repair pipeline intact, then adds:
#   original video -> short overlapping clips -> Gemini visual fact extraction
#   -> character registry -> complete dialogue ledger -> scene ledger -> full Burmese storytelling writer.
# ============================================================================

def _load_dotenv_simple(path):
    """Small .env reader; avoids requiring python-dotenv."""
    values = {}
    if not path:
        return values
    p = Path(path).expanduser()
    if not p.exists():
        return values
    for raw in p.read_text(encoding="utf-8-sig", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k:
            values[k] = v
    return values


def _collect_gemini_keys(env_file=None):
    import os
    pool = []
    merged = dict(os.environ)
    merged.update(_load_dotenv_simple(env_file))

    # Prefer canonical key first, then any project/key-pool variables.
    preferred = ["GEMINI_API_KEY", "GOOGLE_API_KEY"]
    for name in preferred:
        value = (merged.get(name) or "").strip()
        if value and value not in pool:
            pool.append(value)

    # Natural numeric order keeps PROJECT_2 before PROJECT_10.
    for name in sorted(merged, key=natural_sort_key):
        upper = name.upper()
        if "GEMINI" in upper and upper.endswith("_KEY"):
            value = (merged.get(name) or "").strip()
            if value and value not in pool:
                pool.append(value)
    return pool


def _json_from_text(text):
    raw = (text or "").strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
        raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except Exception:
        left = raw.find("{")
        right = raw.rfind("}")
        if left >= 0 and right > left:
            try:
                return json.loads(raw[left:right + 1])
            except Exception:
                pass
        # 2026-10-03: gemini-3-flash-preview now and then writes malformed JSON (6 of 53 answers, e.g. a missing
        # comma at char 3033 - the same on every key at temperature 0). Repair it rather than ask again for ~50 s;
        # the timeline checks and Whisper still judge the repaired answer.
        try:
            import json_repair
            fixed = json_repair.loads(raw)
        except Exception:
            fixed = None
        if isinstance(fixed, dict) and fixed:
            print(f"      [Gemini JSON repaired] {len(raw)} characters", flush=True)
            return fixed
        raise


SCENE_FACT_SCHEMA = {
    "type": "object",
    "properties": {
        "clip_summary": {"type": "string"},
        "characters": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "character_id": {"type": "string"},
                    "name": {"type": "string"},
                    "visual_description": {"type": "string"},
                    "role_hint": {"type": "string"},
                    "confidence": {"type": "number"},
                    "identity_evidence": {"type": "string"}
                },
                "required": ["character_id", "name", "visual_description", "role_hint", "confidence", "identity_evidence"]
            }
        },
        "events": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "start_sec": {"type": "number"},
                    "end_sec": {"type": "number"},
                    "actors": {"type": "array", "items": {"type": "string"}},
                    "action": {"type": "string"},
                    "targets": {"type": "array", "items": {"type": "string"}},
                    "location": {"type": "string"},
                    "evidence": {"type": "string"},
                    "confidence": {"type": "number"}
                },
                "required": ["start_sec", "end_sec", "actors", "action", "targets", "location", "evidence", "confidence"]
            }
        },
        "dialogue": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "transcript_index": {"type": "integer"},
                    "time_sec": {"type": "number"},
                    "speaker": {"type": "string"},
                    "source_text": {"type": "string"},
                    "meaning": {"type": "string"},
                    "confidence": {"type": "number"}
                },
                "required": ["transcript_index", "time_sec", "speaker", "source_text", "meaning", "confidence"]
            }
        },
        "registry_updates": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "character_id": {"type": "string"},
                    "canonical_name": {"type": "string"},
                    "alias": {"type": "string"},
                    "reason": {"type": "string"},
                    "confidence": {"type": "number"}
                },
                "required": ["character_id", "canonical_name", "alias", "reason", "confidence"]
            }
        },
        "uncertainties": {"type": "array", "items": {"type": "string"}}
    },
    "required": ["clip_summary", "characters", "events", "dialogue", "registry_updates", "uncertainties"]
}


VERIFY_SCHEMA = {
    "type": "object",
    "properties": {
        "corrections": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "start_sec": {"type": "number"},
                    "end_sec": {"type": "number"},
                    "actors": {"type": "array", "items": {"type": "string"}},
                    "action": {"type": "string"},
                    "targets": {"type": "array", "items": {"type": "string"}},
                    "confidence": {"type": "number"},
                    "reason": {"type": "string"}
                },
                "required": ["start_sec", "end_sec", "actors", "action", "targets", "confidence", "reason"]
            }
        },
        "remaining_uncertainties": {"type": "array", "items": {"type": "string"}}
    },
    "required": ["corrections", "remaining_uncertainties"]
}


class VideoClip:
    """A clip for generate_json([VideoClip(path, fps), prompt], ...): uploaded once per key with the Files API and
    sent by reference, so a retry, another model or a busy answer does not send the video again (2026-10-03)."""

    def __init__(self, path, fps):
        self.path, self.fps = Path(path), float(fps)


def _release_video(pool, path):
    """Delete a clip's uploads (pools in tests may not upload)."""
    release = getattr(pool, "release_video", None)
    if release:
        release(path)


def _only_lite_free(pool):
    """True when every model not resting right now is a flash-lite (its whole-clip answer is never kept)."""
    ready = getattr(pool, "ready_models", None)
    return bool(ready) and all("lite" in str(m).lower() for m in ready())


class GeminiKeyPool:
    def __init__(self, keys, models, timeout_ms=90000):
        if not keys:
            raise RuntimeError(
                "No Gemini API key found. Check the default .env file or set GEMINI_API_KEY / GEMINI_*_KEY."
            )
        self.keys = list(keys)
        self.models = [m.strip() for m in models if m.strip()]
        if not self.models:
            self.models = DEFAULT_GEMINI_MODELS.split(",")
        self.timeout_ms = int(timeout_ms)
        self.key_index = 0
        self._clients = {}
        # Studio: a model that just answered 503 / timed out is skipped for a while instead of
        # being retried (with a full ~10 MB video upload) on every request. Better models are
        # tried again once their cooldown ends.
        self._cooldown_until = {}
        self.cooldown_sec = 600
        # generate_json_checked: when the stronger models are busy, the model that gave the
        # rejected answer is asked this many more times (its answers vary) before giving up.
        self.check_retries_same_model = 2
        self._tls = threading.local()     # parallel workers: each thread keeps its own key
        # A model that answers 503 rests 90 s (a timeout 180 s), twice as long each time it fails again right
        # away, at most cooldown_sec; an answer resets it. A fixed 10 min after one 503 left the fastest model
        # idle for most of a run while the slowest answered (2026-10-03, 40 of 90 clips by 3.5-flash).
        self.busy_cooldown_sec = 90
        self.timeout_cooldown_sec = 180
        self._fail_streak = {}
        self._out_of_quota = {}          # (model, key index) -> time its quota is back (see _quota_hit)
        # Files API: a clip is uploaded once per key (one upload at a time, so each has the whole uplink) and the
        # requests only refer to it; three failed uploads send clips inline again.
        self._uploads = {}
        self._upload_lock = threading.Lock()
        self._upload_failures = 0

    def use_key(self, index):
        """Parallel workers (2026-10-02): this thread starts from its own key, which spreads the
        per-key rate limits; cooldowns of busy models stay shared by every thread."""
        self._tls.key = int(index) % len(self.keys)

    def _start_key(self):
        key = getattr(self._tls, "key", None)
        return self.key_index if key is None else key

    def _keep_key(self, ki):
        if getattr(self._tls, "key", None) is None:
            self.key_index = ki
        else:
            self._tls.key = ki

    def _models_to_try(self):
        now = time.time()
        ready = [m for m in self.models if self._cooldown_until.get(m, 0) <= now]
        skipped = tuple(m for m in self.models if m not in ready)
        if skipped and skipped != getattr(self, "_last_skipped", ()):
            print(f"      [Gemini skip] {', '.join(skipped)} busy recently -> using {ready[0] if ready else 'all'} "
                  f"(busy models are tried again later)", flush=True)
        self._last_skipped = skipped
        return ready or list(self.models)

    def _cool_down(self, model, seconds=None):
        self._cooldown_until[model] = time.time() + (self.cooldown_sec if seconds is None else seconds)

    def _busy_rest(self, model, message):
        """Seconds a busy or timed-out model rests; see busy_cooldown_sec."""
        upper = str(message).upper()
        timed_out = any(x in upper for x in ("TIMEOUT", "TIMED OUT", "DEADLINE", "504"))
        streak = self._fail_streak.get(model, 0) + 1
        self._fail_streak[model] = streak
        base = self.timeout_cooldown_sec if timed_out else self.busy_cooldown_sec
        return min(self.cooldown_sec, base * 2 ** (streak - 1))

    def _quota_hit(self, model, ki, message):
        """A 429: this key's quota for this model is used up until the time Gemini names - "retry in 14h56m" for
        the free tier's 20 requests per day per project (gemini-3-flash-preview and 3.5-flash, 2026-10-03), seconds
        for a per-minute limit. The key is skipped for this model until then, so no clip goes up to it for nothing.
        Returns the seconds."""
        m = re.search(r"retry in (?:(\d+)h)?(?:(\d+)m)?(?:([\d.]+)s)?", str(message))
        secs = 0.0
        if m and any(m.groups()):
            secs = int(m.group(1) or 0) * 3600 + int(m.group(2) or 0) * 60 + float(m.group(3) or 0)
        secs = secs or 60.0
        self._out_of_quota[(model, ki)] = time.time() + secs
        return secs

    def ready_models(self):
        """The models not resting right now (no log line)."""
        now = time.time()
        return [m for m in self.models if self._cooldown_until.get(m, 0) <= now] or list(self.models)

    def _uploaded(self, path, ki):
        """The Files API file of this clip for key ki, uploaded on first use."""
        from google.genai import types
        f = self._uploads.get((str(path), ki))
        if f is not None:
            return f
        client = self._client(ki)
        with self._upload_lock:
            t0 = time.time()
            f = client.files.upload(file=str(path), config=types.UploadFileConfig(mime_type="video/mp4"))
            sent = time.time() - t0
        while (getattr(f.state, "name", None) or str(f.state)) == "PROCESSING" and time.time() - t0 < 300:
            time.sleep(1.0)
            f = client.files.get(name=f.name)
        state = getattr(f.state, "name", None) or str(f.state)
        if state != "ACTIVE":
            raise RuntimeError(f"uploaded clip is {state}")
        self._uploads[(str(path), ki)] = f
        print(f"      [Gemini upload] {Path(path).name} key#{ki + 1}: {Path(path).stat().st_size / 1048576:.1f} MB "
              f"sent in {sent:.1f} s, ready in {time.time() - t0:.1f} s", flush=True)
        return f

    def _video_part(self, clip, ki):
        from google.genai import types
        meta = types.VideoMetadata(fps=clip.fps)
        if self._upload_failures < 3:
            try:
                f = self._uploaded(clip.path, ki)
                return types.Part(file_data=types.FileData(file_uri=f.uri, mime_type="video/mp4"), video_metadata=meta)
            except Exception as exc:
                raise_if_terminal(exc)
                if any(x in str(exc).upper() for x in ("429", "RESOURCE_EXHAUSTED", "QUOTA")):
                    raise                     # this key is out of quota: generate_json moves to the next key
                self._upload_failures += 1
                print(f"      [Gemini upload] {clip.path.name}: {str(exc).splitlines()[0][:120]} -> sent inline "
                      f"({self._upload_failures}/3)", flush=True)
        return types.Part(inline_data=types.Blob(data=clip.path.read_bytes(), mime_type="video/mp4"), video_metadata=meta)

    def _contents_for(self, contents, ki):
        """[VideoClip, prompt] -> a Content whose video is the uploaded file of key ki; anything else as given."""
        if not isinstance(contents, (list, tuple)) or not any(isinstance(c, VideoClip) for c in contents):
            return contents
        from google.genai import types
        return types.Content(parts=[self._video_part(c, ki) if isinstance(c, VideoClip)
                                    else types.Part(text=c) if isinstance(c, str) else c for c in contents])

    def release_video(self, path):
        """Delete a clip's uploads (best effort: uploads expire after 48 h anyway)."""
        for (p, ki), f in list(self._uploads.items()):
            if p == str(path):
                self._uploads.pop((p, ki), None)
                try:
                    self._client(ki).files.delete(name=f.name)
                except Exception:
                    pass

    def _client(self, key_index):
        if key_index in self._clients:
            return self._clients[key_index]
        try:
            from google import genai
            from google.genai import types
        except ImportError as exc:
            raise RuntimeError("google-genai is not installed. Run: pip install -U google-genai") from exc
        client = genai.Client(
            api_key=self.keys[key_index],
            http_options=types.HttpOptions(timeout=self.timeout_ms),
        )
        self._clients[key_index] = client
        return client

    def generate_json(self, contents, schema, temperature=0.0, max_output_tokens=16384, avoid_model=None,
                      only_models=None):
        from google.genai import types
        errors = []
        reply_failures = []
        total = max(1, len(self.keys) * len(self.models))
        attempts = 0
        start_key = self._start_key()
        candidates = list(only_models) if only_models else self._models_to_try()
        if avoid_model and len(self.models) > 1 and not only_models:
            # That model's last answer was rejected (e.g. foreign letters in Burmese): ask the
            # others first, even if they were busy a few minutes ago; it stays as last resort.
            candidates = [m for m in self.models if m != avoid_model] + [avoid_model]

        for model_index, model in enumerate(candidates, start=1):
            model_failed_keys = 0
            skip_model = False
            for step in range(len(self.keys)):
                attempts += 1
                ki = (start_key + step) % len(self.keys)
                if self._out_of_quota.get((model, ki), 0) > time.time():
                    continue                   # this key's quota for this model is used up (_quota_hit)
                client = self._client(ki)
                key_tag = f"key#{ki + 1}/{len(self.keys)}"
                t_req = time.time()
                try:
                    config = types.GenerateContentConfig(
                        temperature=temperature,
                        max_output_tokens=max_output_tokens,
                        response_mime_type="application/json",
                        response_schema=schema,
                    )
                    request = self._contents_for(contents, ki)
                    print(f"      [Gemini try] {model} {key_tag} | timeout={self.timeout_ms / 1000:.0f}s", flush=True)
                    t_req = time.time()
                    try:
                        response = client.models.generate_content(model=model, contents=request, config=config)
                    except json.JSONDecodeError as exc:
                        raise transport_json_error(exc) from None
                    data = response_json(response, schema, _json_from_text)
                    if ANALYSIS_SPEED != 1 and schema is GEMINI_TIMELINE_SCHEMA_V60:
                        import analysis_speed
                        data = analysis_speed.scale_timeline(data, ANALYSIS_SPEED)
                    self._keep_key(ki)
                    self._fail_streak.pop(model, None)
                    print(f"      [Gemini answer] {model} {key_tag} in {time.time() - t_req:.1f} s", flush=True)
                    return data, model, key_tag
                except Exception as exc:
                    raise_if_terminal(exc)
                    model_failed_keys += 1
                    msg = safe_error(exc, self.keys)
                    reply_failures.append(getattr(exc, "kind", "request_error"))
                    errors.append(f"{model} {key_tag}: {msg[:240]}")
                    upper = msg.upper()

                    if isinstance(exc, GeminiReplyError):
                        if exc.retry_keys:
                            print(f"      [Gemini {exc.kind}] {model} {key_tag}: {msg} -> next key", flush=True)
                            continue
                        print(f"      [Gemini {exc.kind}] {model} {key_tag}: {msg} -> next model", flush=True)
                        skip_model = True
                        break

                    # 429 / quota is usually key/project-specific: keep SAME model and rotate keys.
                    if any(x in upper for x in ["429", "RESOURCE_EXHAUSTED", "QUOTA_EXCEEDED"]):
                        secs = self._quota_hit(model, ki, msg)
                        print(f"      [Gemini key rotate] {model} {key_tag}: quota used up, back in "
                              f"{secs / 3600:.1f} h -> next key")
                        time.sleep(0.3)
                        continue

                    # Model/service-side busy or a request that sat until timeout: do not burn the whole key pool.
                    # A key change usually cannot fix model-wide 503/high-demand, and waiting 15 x timeout is too slow.
                    if any(x in upper for x in [
                        "503", "HIGH DEMAND", "UNAVAILABLE",
                        "504", "DEADLINE", "TIMEOUT", "TIMED OUT",
                        "READTIMEOUT", "CONNECTTIMEOUT"
                    ]):
                        print(f"      [Gemini fast fallback] {model} after {time.time() - t_req:.0f} s: {msg[:120]}")
                        self._cool_down(model, self._busy_rest(model, msg))
                        skip_model = True
                        break

                    # Model itself unavailable: changing API key cannot fix it, so move to next model now.
                    if any(x in upper for x in ["404", "MODEL_NOT_FOUND", "MODEL NOT FOUND", "UNSUPPORTED MODEL", "MODEL IS NOT FOUND", "MODEL DOES NOT EXIST"]):
                        print(f"      [Gemini model unavailable] {model}: {msg[:120]}")
                        self._cool_down(model, 3600)
                        skip_model = True
                        break

                    # Malformed JSON json_repair could not fix: this model writes the same answer on every key at
                    # temperature 0 (3 keys failed at char 3033 on one clip), so the next model is asked instead.
                    if isinstance(exc, json.JSONDecodeError):
                        print(f"      [Gemini bad JSON] {model} {key_tag}: {msg[:100]} -> next model")
                        skip_model = True
                        break

                    # INTERNAL can be key/project/transient specific; try the next key.
                    if "INTERNAL" in upper:
                        print(f"      [Gemini transient retry] {model} {key_tag}: {msg[:120]}")
                        time.sleep(0.7)
                        continue

                    # Other request errors: try the next key first; if every key fails, model fallback below.
                    print(f"      [Gemini key retry] {model} {key_tag}: {msg[:120]}")
                    time.sleep(0.5)

            if model_index < len(candidates):
                reason = ("model unavailable" if skip_model else f"all {model_failed_keys} key(s) failed"
                          if model_failed_keys else "no key has quota left")
                print(f"      [Gemini model fallback] {model} -> {candidates[model_index]} ({reason})")

        # Include the reason on the first line: the Studio uses it while waiting to resume.
        reason = errors[-1] if errors else "No key/model is currently available; quota may still be resting"
        if reply_failures and set(reply_failures) == {"truncated"}:
            raise GeminiReplyError("truncated", "Gemini model အားလုံးမှာ အဖြေ token limit ပြည့်နေပါတယ်။ " +
                                   reason + "; clip/output token settings ကို စစ်ပေးပါ။", terminal=True)
        raise RuntimeError("Gemini request failed after key/model rotation: " + reason +
                           ". Last errors:\n- " + "\n- ".join(errors[-8:]))

    def generate_json_checked(self, contents, schema, check, label="", **kwargs):
        """generate_json whose answer must pass check(data) -> (issues, badness).

        A rejected answer is asked again from every other model, strongest first, even ones in
        cooldown; if some of them are busy, the first model is asked check_retries_same_model
        more times. Returns (data, model, key, issues): issues is empty for a passing answer and
        non-empty when every model answered and none passed (the least bad answer is kept).
        Raises when no answer passed and a model was busy, so the caller retries later instead
        of keeping a bad answer.
        """
        data, model, key = self.generate_json(contents, schema, **kwargs)
        issues, badness = check(data)
        if not issues:
            return data, model, key, []
        print(f"      [Gemini check] {label} {model} rejected: {'; '.join(issues)} -> asking another model", flush=True)
        answers = [(badness, data, model, key, issues)]
        busy = []
        first_model = model
        for other in [m for m in self.models if m != model] + [first_model] * self.check_retries_same_model:
            if other == first_model and not busy:
                break           # every other model answered (badly): the same model again will not help
            if other == first_model:
                print(f"      [Gemini check] {label} stronger models busy -> asking {other} once more", flush=True)
            try:
                d2, m2, k2 = self.generate_json(contents, schema, only_models=[other], **kwargs)
            except Exception as exc:
                raise_if_terminal(exc)
                busy.append(other)
                print(f"      [Gemini check] {label} {other} unavailable: {str(exc).splitlines()[0][:120]}", flush=True)
                continue
            iss2, bad2 = check(d2)
            if not iss2:
                print(f"      [Gemini check] {label} {m2} OK", flush=True)
                return d2, m2, k2, []
            print(f"      [Gemini check] {label} {m2} rejected: {'; '.join(iss2)}", flush=True)
            answers.append((bad2, d2, m2, k2, iss2))
        if busy:
            raise RuntimeError(
                f"Gemini check: {label} failed the timestamp check on every model that answered and "
                f"{', '.join(busy)} busy; run again later (finished clips are cached)"
            )
        best = min(answers, key=lambda a: a[0])
        print(f"      [Gemini check] {label} no model passed; keeping the least bad answer ({best[2]}: {'; '.join(best[4])})",
              flush=True)
        return best[1], best[2], best[3], best[4]

    def generate_text(self, prompt, temperature=0.35, max_output_tokens=32768):
        from google.genai import types
        errors = []
        start_key = self._start_key()
        candidates = self._models_to_try()
        for model_index, model in enumerate(candidates, start=1):
            model_failed_keys = 0
            skip_model = False
            for step in range(len(self.keys)):
                ki = (start_key + step) % len(self.keys)
                if self._out_of_quota.get((model, ki), 0) > time.time():
                    continue
                client = self._client(ki)
                key_tag = f"key#{ki + 1}/{len(self.keys)}"
                try:
                    config = types.GenerateContentConfig(
                        temperature=temperature,
                        max_output_tokens=max_output_tokens,
                    )
                    print(f"      [Gemini try] {model} {key_tag} | timeout={self.timeout_ms / 1000:.0f}s", flush=True)
                    response = client.models.generate_content(model=model, contents=prompt, config=config)
                    text, _detail = response_text(response)
                    self._keep_key(ki)
                    self._fail_streak.pop(model, None)
                    return text.strip(), model, key_tag
                except Exception as exc:
                    raise_if_terminal(exc)
                    model_failed_keys += 1
                    msg = safe_error(exc, self.keys)
                    errors.append(f"{model} {key_tag}: {msg[:240]}")
                    upper = msg.upper()
                    if any(x in upper for x in ["429", "RESOURCE_EXHAUSTED", "QUOTA_EXCEEDED"]):
                        secs = self._quota_hit(model, ki, msg)
                        print(f"      [Gemini key rotate] {model} {key_tag}: quota used up, back in {secs / 3600:.1f} h")
                        time.sleep(0.3)
                        continue
                    if any(x in upper for x in [
                        "503", "HIGH DEMAND", "UNAVAILABLE",
                        "504", "DEADLINE", "TIMEOUT", "TIMED OUT",
                        "READTIMEOUT", "CONNECTTIMEOUT"
                    ]):
                        print(f"      [Gemini fast fallback] {model}: {msg[:120]}")
                        self._cool_down(model, self._busy_rest(model, msg))
                        skip_model = True
                        break
                    if any(x in upper for x in ["404", "MODEL_NOT_FOUND", "MODEL NOT FOUND", "UNSUPPORTED MODEL", "MODEL IS NOT FOUND", "MODEL DOES NOT EXIST"]):
                        print(f"      [Gemini model unavailable] {model}: {msg[:120]}")
                        self._cool_down(model, 3600)
                        skip_model = True
                        break
                    if "INTERNAL" in upper:
                        print(f"      [Gemini transient retry] {model} {key_tag}: {msg[:120]}")
                        time.sleep(0.7)
                        continue
                    print(f"      [Gemini key retry] {model} {key_tag}: {msg[:120]}")
                    time.sleep(0.5)
            if model_index < len(candidates):
                reason = ("model unavailable" if skip_model else f"all {model_failed_keys} key(s) failed"
                          if model_failed_keys else "no key has quota left")
                print(f"      [Gemini model fallback] {model} -> {candidates[model_index]} ({reason})")
        raise RuntimeError("Gemini text request failed. Last errors:\n- " + "\n- ".join(errors[-8:]))


# Parallel Gemini work (user-approved 2026-10-02: a 1h51m video took ~3 h with one request at a time).
# 2026-10-03: clips go up once each through the Files API, one upload at a time, so a slow uplink (~200 KB/s
# in the evening) no longer holds the answers back (four inline uploads at once hit the 180 s read timeout).
# The answer, not the upload, takes most of a clip's time (upload 6-11 s, answer ~49 s), so six clips are asked at
# once (user-approved 2026-10-03; four gave ~28 s per clip). Story chapters send text only; four are written at
# once. Each worker starts on its own key.
GEMINI_WORKERS = 6
WRITER_WORKERS = 4


class _BlockLog:
    """sys.stdout while workers run: a worker's lines are kept and written as one block when its
    clip / story part is done, so run.log stays readable and the Studio's progress lines stay whole."""

    def __init__(self, out):
        self.out, self.lock, self.local = out, threading.Lock(), threading.local()

    def write(self, text):
        buf = getattr(self.local, "buf", None)
        if buf is not None:
            buf.append(text)
            return len(text)
        with self.lock:
            return self.out.write(text)

    def flush(self):
        if getattr(self.local, "buf", None) is None:
            self.out.flush()

    def __getattr__(self, name):
        return getattr(self.out, name)


@contextlib.contextmanager
def _block_log():
    """In a worker: collect this thread's prints and write them out together at the end."""
    out = sys.stdout
    if not isinstance(out, _BlockLog):
        yield
        return
    out.local.buf = []
    try:
        yield
    finally:
        text, out.local.buf = "".join(out.local.buf), None
        with out.lock:
            out.out.write(text)
            out.out.flush()


def _v64_worker_keys(pool, workers):
    """start_thread for _v64_run_in_order: worker thread n starts from its own key (the keys spread evenly
    over the workers). One worker keeps the pool's shared key, as before."""
    if workers <= 1 or not hasattr(pool, "use_key"):
        return None
    return lambda slot: pool.use_key(slot * len(pool.keys) // workers)


def _v64_run_in_order(count, prepare, work, finish, workers, start_thread=None):
    """work(i, prepare(i)) for i in range(count) on up to `workers` threads, and finish(i, result) in order,
    as soon as every job before i is finished. prepare and finish run in this thread, so a job started
    later sees what finish() added (the character registry). The first failure stops new jobs, waits for
    the running ones (their answers are cached) and is raised. start_thread(n) runs once in each worker
    thread, n = 0, 1, ..."""
    from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
    if count <= 0:
        return
    slots, slot_lock = iter(range(1 << 30)), threading.Lock()

    def thread_start():
        with slot_lock:
            slot = next(slots)
        if start_thread:
            start_thread(slot)
    old_out = sys.stdout
    if not isinstance(old_out, _BlockLog):
        sys.stdout = _BlockLog(old_out)
    running, done, failed = {}, {}, None
    next_job = next_finish = 0
    try:
        with ThreadPoolExecutor(max_workers=max(1, workers), initializer=thread_start) as ex:
            while next_finish < count:
                while failed is None and next_job < count and len(running) < max(1, workers):
                    running[ex.submit(work, next_job, prepare(next_job))] = next_job
                    next_job += 1
                if not running:
                    break
                finished, _ = wait(list(running), return_when=FIRST_COMPLETED)
                for fut in finished:
                    i = running.pop(fut)
                    try:
                        done[i] = fut.result()
                    except BaseException as exc:          # noqa: BLE001 - raised below
                        failed = failed or exc
                while failed is None and next_finish in done:
                    finish(next_finish, done.pop(next_finish))
                    next_finish += 1
    finally:
        sys.stdout = old_out
    if failed is not None:
        raise failed


# Analysis clips (2026-10-02): Gemini samples 4 frames per second (--video-fps), so a clip encoded at 24 fps
# uploaded six times the frames it uses. Over the ~200 KB/s uplink measured here a 10 MB clip took ~50 s
# to send and the 1h51m analysis was upload-bound. 8 fps at 650k keeps each sampled frame at least as
# sharp (81 vs 60 kbit per frame) for about half the upload.
ANALYSIS_SPEED = 1
ANALYSIS_CLIP_FPS = 8
ANALYSIS_CLIP_KBPS = 650


def _extract_video_clip(src, dst, start_sec, duration_sec):
    """Create a small (~5 MB per 55 s) analysis clip suitable for inline Gemini input."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "ffmpeg", "-y", "-ss", f"{start_sec:.3f}", "-t", f"{duration_sec:.3f}",
        "-i", str(src),
        "-map", "0:v:0", "-map", "0:a?",
        "-vf", "scale=960:-2",
        "-r", str(ANALYSIS_CLIP_FPS),
        "-c:v", "libx264", "-preset", "veryfast",
        "-b:v", f"{ANALYSIS_CLIP_KBPS}k", "-maxrate", f"{ANALYSIS_CLIP_KBPS * 6 // 5}k",
        "-bufsize", f"{ANALYSIS_CLIP_KBPS * 2}k",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "64k", "-ac", "1", "-ar", "32000",
        "-movflags", "+faststart",
        str(dst),
    ]
    if ANALYSIS_SPEED != 1:
        cmd[cmd.index("-vf") + 1] = f"setpts=0.5*(PTS-STARTPTS),fps={ANALYSIS_CLIP_FPS},scale=960:-2"
        cmd[-1:-1] = ["-af", "atempo=2.0"]
    run(cmd, quiet=True)


def _segments_for_window(segments, start_sec, end_sec):
    rows = []
    for transcript_index, seg in enumerate(segments):
        s = float(seg.get("start", 0.0))
        e = float(seg.get("end", s))
        text = (seg.get("text") or "").strip()
        if text and s < end_sec and e > start_sec:
            rows.append({
                "transcript_index": int(transcript_index),
                "start": max(0.0, s - start_sec),
                "end": max(0.0, e - start_sec),
                "text": text,
            })
    return rows


def _ensure_dialogue_coverage(data, transcript_rows):
    """Guarantee every Whisper transcript row survives the visual pass."""
    dialogue = list(data.get("dialogue") or [])
    by_idx = {}
    for row in dialogue:
        try:
            idx = int(row.get("transcript_index"))
        except Exception:
            continue
        prev = by_idx.get(idx)
        if prev is None or float(row.get("confidence") or 0.0) > float(prev.get("confidence") or 0.0):
            by_idx[idx] = row

    covered = []
    for tr in transcript_rows:
        idx = int(tr["transcript_index"])
        row = dict(by_idx.get(idx) or {})
        row["transcript_index"] = idx
        row["time_sec"] = float(row.get("time_sec") if row.get("time_sec") is not None else tr["start"])
        row["speaker"] = (row.get("speaker") or "UNKNOWN_SPEAKER").strip() or "UNKNOWN_SPEAKER"
        row["source_text"] = (row.get("source_text") or tr["text"]).strip()
        row["meaning"] = (row.get("meaning") or tr["text"]).strip()
        row["confidence"] = float(row.get("confidence") or 0.0)
        covered.append(row)

    data["dialogue"] = covered
    return data


def _compact_registry(registry):
    items = []
    for cid in sorted(registry):
        item = registry[cid]
        items.append({
            "character_id": cid,
            "canonical_name": item.get("canonical_name", ""),
            "aliases": item.get("aliases", []),
            "visual_description": item.get("visual_description", ""),
            "role_hint": item.get("role_hint", ""),
            "last_seen": item.get("last_seen", ""),
        })
    return items


def _replace_ids(obj, mapping):
    if isinstance(obj, str):
        return mapping.get(obj, obj)
    if isinstance(obj, list):
        return [_replace_ids(x, mapping) for x in obj]
    if isinstance(obj, dict):
        return {k: _replace_ids(v, mapping) for k, v in obj.items()}
    return obj


def _next_character_id(registry):
    nums = []
    for cid in registry:
        m = re.fullmatch(r"CHAR_(\d+)", cid)
        if m:
            nums.append(int(m.group(1)))
    return f"CHAR_{(max(nums) + 1 if nums else 1):03d}"


def _reconcile_characters(data, registry, source_name, clip_start):
    mapping = {}
    known = set(registry)
    chars = data.get("characters") or []

    # The model must use NEW_* for identities not already in registry.
    for auto_i, ch in enumerate(chars, start=1):
        raw_id = str(ch.get("character_id") or "").strip()
        if not raw_id:
            raw_id = f"NEW_AUTO_{auto_i}"
            ch["character_id"] = raw_id
        if raw_id.startswith("NEW_"):
            if raw_id not in mapping:
                mapping[raw_id] = _next_character_id({**registry, **{v: {} for v in mapping.values()}})
        elif raw_id.startswith("CHAR_") and raw_id not in known:
            # Do not let the model invent a canonical CHAR_### behind our back.
            if raw_id not in mapping:
                mapping[raw_id] = _next_character_id({**registry, **{v: {} for v in mapping.values()}})

    if mapping:
        data = _replace_ids(data, mapping)

    for ch in data.get("characters") or []:
        cid = str(ch.get("character_id") or "").strip()
        if not cid.startswith("CHAR_"):
            continue
        current = registry.setdefault(cid, {
            "character_id": cid,
            "canonical_name": "",
            "aliases": [],
            "visual_description": "",
            "role_hint": "",
            "first_seen": f"{source_name}@{srt_time(clip_start)}",
            "last_seen": f"{source_name}@{srt_time(clip_start)}",
            "identity_notes": [],
        })
        current["last_seen"] = f"{source_name}@{srt_time(clip_start)}"
        desc = (ch.get("visual_description") or "").strip()
        role = (ch.get("role_hint") or "").strip()
        name = (ch.get("name") or "").strip()
        conf = float(ch.get("confidence") or 0.0)
        if desc and (not current.get("visual_description") or len(desc) > len(current.get("visual_description", ""))):
            current["visual_description"] = desc
        if role and not current.get("role_hint"):
            current["role_hint"] = role
        if name and name.lower() not in {"unknown", "unnamed", "n/a", "none"}:
            if conf >= 0.88 and not current.get("canonical_name"):
                current["canonical_name"] = name
            elif name != current.get("canonical_name") and name not in current["aliases"]:
                current["aliases"].append(name)
        note = (ch.get("identity_evidence") or "").strip()
        if note and note not in current["identity_notes"]:
            current["identity_notes"].append(note)
            current["identity_notes"] = current["identity_notes"][-8:]

    for upd in data.get("registry_updates") or []:
        cid = str(upd.get("character_id") or "").strip()
        if cid not in registry:
            continue
        conf = float(upd.get("confidence") or 0.0)
        name = (upd.get("canonical_name") or "").strip()
        alias = (upd.get("alias") or "").strip()
        if name and conf >= 0.90:
            old = registry[cid].get("canonical_name", "")
            if not old:
                registry[cid]["canonical_name"] = name
            elif old != name and name not in registry[cid]["aliases"]:
                registry[cid]["aliases"].append(name)
        if alias and alias not in registry[cid]["aliases"] and alias != registry[cid].get("canonical_name"):
            registry[cid]["aliases"].append(alias)
    return data


def _scene_prompt(source_name, clip_start, clip_duration, transcript_rows, registry, previous_tail):
    registry_json = json.dumps(_compact_registry(registry), ensure_ascii=False)
    transcript_json = json.dumps(transcript_rows, ensure_ascii=False)
    previous_json = json.dumps(previous_tail[-8:], ensure_ascii=False)
    return f"""
You are the evidence extractor for a VIDEO-TO-RECAP pipeline.
Analyze the ACTUAL VIDEO CLIP first. The transcript is supporting evidence, not a substitute for vision.

SOURCE FILE: {source_name}
CLIP FILE-TIME START: {srt_time(clip_start)}
CLIP DURATION: {clip_duration:.3f} seconds
All output timestamps MUST be seconds relative to the beginning of THIS clip.

EXISTING CHARACTER REGISTRY:
{registry_json}

RECENT VERIFIED EVENTS BEFORE THIS CLIP:
{previous_json}

WHISPER TRANSCRIPT OVERLAPPING THIS CLIP:
{transcript_json}

STRICT RULES:
1. Never invent an action, relationship, identity, name, motive, or speaker.
2. For visible actions, VIDEO is the primary evidence. Transcript/audio can support dialogue and identity.
3. Pay special attention to very short physical actions: slap/hit/push/grab/kiss, handing/taking objects,
   opening/closing doors, entering/leaving, sitting/standing, phone use, weapons, letters/documents.
4. Track WHO performs each action and WHO receives it. Actor/target mistakes are unacceptable.
5. If an existing CHAR_### is clearly the same person, reuse that ID.
6. If identity is not reliable, use NEW_1, NEW_2, ... for this clip. Do NOT guess an existing ID.
7. A character name may be assigned only when the video, subtitles, or dialogue gives evidence. Otherwise keep name empty.
8. If the visual evidence is ambiguous, put it in uncertainties instead of choosing a convenient answer.
9. Events should be concrete observable facts, not prose recap and not interpretation.
10. DIALOGUE COVERAGE IS MANDATORY: for EVERY non-empty WHISPER TRANSCRIPT row above, return exactly one dialogue item.
    - Copy its transcript_index exactly.
    - Preserve the original words in source_text.
    - Put a faithful meaning/paraphrase in meaning; do not shorten away details.
    - Identify the speaker only when video/audio/context supports it; otherwise use UNKNOWN_SPEAKER.
    - Never merge several transcript rows into one dialogue item and never skip a row because it seems unimportant.
11. Overlap with the previous clip may repeat events/dialogue. That is OK; downstream code will de-duplicate.
12. Keep event timing tight enough to identify short actions.

Return only the requested structured JSON.
""".strip()


def _verify_prompt(source_name, clip_start, primary):
    return f"""
Re-check this SAME video clip as a strict visual fact-checker.
SOURCE: {source_name} starting at file time {srt_time(clip_start)}.

The first-pass extraction is below:
{json.dumps(primary, ensure_ascii=False)}

Only correct genuinely wrong/uncertain physical actions or actor/target assignments.
Focus especially on slap/hit/push/grab, door open/close, entering/leaving, handing/taking objects,
phone actions, weapons, and who is physically doing what.
Do not add story interpretation. Do not invent names.
Timestamps are seconds relative to this clip.
Return corrections only; if the first pass is correct, return an empty corrections list.
""".strip()


def _should_verify(primary):
    if primary.get("uncertainties"):
        return True
    for ev in primary.get("events") or []:
        try:
            if float(ev.get("confidence") or 0.0) < 0.78:
                return True
        except Exception:
            return True
    return False


def _apply_verifier(primary, verify):
    corrections = verify.get("corrections") or []
    if not corrections:
        primary["uncertainties"] = verify.get("remaining_uncertainties") or primary.get("uncertainties") or []
        return primary

    events = list(primary.get("events") or [])
    for corr in corrections:
        cs = float(corr.get("start_sec") or 0.0)
        ce = float(corr.get("end_sec") or cs)
        cmid = (cs + ce) / 2.0
        best_i = None
        best_dist = 999999.0
        for i, ev in enumerate(events):
            es = float(ev.get("start_sec") or 0.0)
            ee = float(ev.get("end_sec") or es)
            dist = abs(((es + ee) / 2.0) - cmid)
            if dist < best_dist and dist <= 3.0:
                best_dist = dist
                best_i = i
        new_ev = {
            "start_sec": cs,
            "end_sec": ce,
            "actors": corr.get("actors") or [],
            "action": (corr.get("action") or "").strip(),
            "targets": corr.get("targets") or [],
            "location": events[best_i].get("location", "") if best_i is not None else "",
            "evidence": "verifier: " + (corr.get("reason") or "visual re-check"),
            "confidence": float(corr.get("confidence") or 0.0),
        }
        if best_i is None:
            events.append(new_ev)
        else:
            events[best_i] = new_ev
    events.sort(key=lambda e: (float(e.get("start_sec") or 0.0), float(e.get("end_sec") or 0.0)))
    primary["events"] = events
    primary["uncertainties"] = verify.get("remaining_uncertainties") or []
    return primary


def _event_norm(text):
    return normalize_text(text or "")


def _dedupe_global_events(events):
    out = []
    for ev in sorted(events, key=lambda x: (x["global_start_sec"], x["global_end_sec"])):
        token = _event_norm(ev.get("action", ""))
        actors = tuple(ev.get("actors") or [])
        targets = tuple(ev.get("targets") or [])
        dup = False
        for prev in reversed(out[-12:]):
            if ev["global_start_sec"] - prev["global_start_sec"] > 7.0:
                break
            if (
                token and token == _event_norm(prev.get("action", ""))
                and actors == tuple(prev.get("actors") or [])
                and targets == tuple(prev.get("targets") or [])
                and abs(ev["global_start_sec"] - prev["global_start_sec"]) <= 4.0
            ):
                if float(ev.get("confidence") or 0.0) > float(prev.get("confidence") or 0.0):
                    prev.update(ev)
                dup = True
                break
        if not dup:
            out.append(ev)
    return out


def _character_display(cid, registry):
    item = registry.get(cid, {})
    name = (item.get("canonical_name") or "").strip()
    return f"{name} ({cid})" if name else cid


def _write_scene_ledger_txt(events, registry, path):
    lines = ["MANJU VIDEO RECAP V4.2 - VERIFIED SCENE LEDGER", ""]
    for ev in events:
        actor = ", ".join(_character_display(x, registry) for x in ev.get("actors") or []) or "(none/unclear)"
        target = ", ".join(_character_display(x, registry) for x in ev.get("targets") or []) or ""
        lines.append(
            f"[{srt_time(ev['global_start_sec'])}] {ev['source_file']} @ {srt_time(ev['file_start_sec'])} | "
            f"ACTOR={actor} | ACTION={ev.get('action','')}" + (f" | TARGET={target}" if target else "") +
            f" | CONF={float(ev.get('confidence') or 0.0):.2f}"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")


def _dedupe_dialogue(dialogue_rows):
    """De-duplicate overlap copies using source file + Whisper transcript index."""
    best = {}
    order = []
    for row in sorted(dialogue_rows, key=lambda x: (x["global_start_sec"], x.get("transcript_index", -1))):
        key = (row.get("source_file", ""), int(row.get("transcript_index", -1)))
        if key not in best:
            best[key] = row
            order.append(key)
        else:
            prev = best[key]
            score_prev = float(prev.get("confidence") or 0.0) + (0.25 if prev.get("speaker") not in {"", "UNKNOWN_SPEAKER"} else 0.0)
            score_new = float(row.get("confidence") or 0.0) + (0.25 if row.get("speaker") not in {"", "UNKNOWN_SPEAKER"} else 0.0)
            if score_new > score_prev:
                best[key] = row
    return [best[k] for k in order]


def _write_dialogue_ledger_txt(dialogue_rows, registry, path):
    lines = ["MANJU VIDEO RECAP V4.2 - COMPLETE DIALOGUE LEDGER", ""]
    for row in dialogue_rows:
        raw_speaker = row.get("speaker") or "UNKNOWN_SPEAKER"
        speaker = _character_display(raw_speaker, registry) if str(raw_speaker).startswith("CHAR_") else raw_speaker
        lines.append(
            f"[{srt_time(row['global_start_sec'])}] {row['source_file']} @ {srt_time(row['file_start_sec'])} | "
            f"IDX={row.get('transcript_index')} | SPEAKER={speaker} | SOURCE={row.get('source_text','')} | MEANING={row.get('meaning','')}"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")


def _build_story_timeline(events, dialogue_rows):
    timeline = []
    for ev in events:
        row = dict(ev)
        row["kind"] = "event"
        timeline.append(row)
    for d in dialogue_rows:
        row = dict(d)
        row["kind"] = "dialogue"
        row["file_end_sec"] = float(row.get("file_end_sec", row.get("file_start_sec", 0.0)) or row.get("file_start_sec", 0.0))
        row["global_end_sec"] = float(row.get("global_end_sec", row.get("global_start_sec", 0.0)) or row.get("global_start_sec", 0.0))
        timeline.append(row)
    timeline.sort(key=lambda x: (float(x.get("global_start_sec", 0.0)), 0 if x.get("kind") == "event" else 1))
    for i, row in enumerate(timeline, start=1):
        row["story_item_id"] = f"S{i:06d}"
    return timeline


def _story_chunks(timeline, max_window_sec=300.0):
    """Small chunks reduce the model's tendency to summarize or omit dialogue."""
    if not timeline:
        return []
    groups = []
    cur = []
    start = float(timeline[0]["global_start_sec"])
    for item in timeline:
        if cur and (float(item["global_start_sec"]) - start >= max_window_sec or len(cur) >= 110):
            groups.append(cur)
            cur = []
            start = float(item["global_start_sec"])
        cur.append(item)
    if cur:
        groups.append(cur)
    return groups


STORY_OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "story_text": {"type": "string"},
        "covered_item_ids": {"type": "array", "items": {"type": "string"}}
    },
    "required": ["story_text", "covered_item_ids"]
}


STORY_AUDIT_SCHEMA = {
    "type": "object",
    "properties": {
        "actually_covered_item_ids": {"type": "array", "items": {"type": "string"}},
        "missing_item_ids": {"type": "array", "items": {"type": "string"}},
        "audit_notes": {"type": "array", "items": {"type": "string"}},
        "narrator_style_pass": {"type": "boolean"},
        "style_violations": {"type": "array", "items": {"type": "string"}},
        "evidence_fidelity_pass": {"type": "boolean"},
        "unsupported_claims": {"type": "array", "items": {"type": "string"}}
    },
    "required": [
        "actually_covered_item_ids", "missing_item_ids", "audit_notes",
        "narrator_style_pass", "style_violations",
        "evidence_fidelity_pass", "unsupported_claims"
    ]
}


def _story_text_unicode_issues(text):
    """Return foreign/corrupt Unicode chars that must never reach Burmese narration."""
    import unicodedata
    if OUTPUT_LANGUAGE != "my":     # Studio: the check for the chosen narration language
        return _language_script_issues(text, OUTPUT_LANGUAGE)
    issues = []
    allowed_unicode_punct = set("၊။“”‘’…–—‑−•·")
    for pos, ch in enumerate(str(text or "")):
        cp = ord(ch)
        if ch in "\n\r\t " or ch == "\ufeff":
            continue
        if ch.isascii():
            continue
        if 0x1000 <= cp <= 0x109F or 0xAA60 <= cp <= 0xAA7F:
            continue
        if ch in allowed_unicode_punct:
            continue
        name = unicodedata.name(ch, "UNKNOWN")
        issues.append({"pos": pos, "char": ch, "codepoint": f"U+{cp:04X}", "name": name})
    # Studio: the same Myanmar mark twice in a row is always a typo (武朝大帝 B0557 "ခြေော်"),
    # and Edge TTS reads it as written, so the writer must repair it like a foreign letter.
    t = str(text or "")
    for pos in range(1, len(t)):
        ch = t[pos]
        if ch == t[pos - 1] and 0x1000 <= ord(ch) <= 0x109F and unicodedata.category(ch) in ("Mn", "Mc"):
            issues.append({"pos": pos, "char": ch, "codepoint": f"U+{ord(ch):04X}",
                           "name": "DOUBLED " + unicodedata.name(ch, "MARK")})
    return issues


def _story_style_issue_soft(issue):
    """Screen-talk and literary-style issues: the writer prefers such a fragment when it keeps one for review."""
    return str(issue).startswith(("narrates the footage", "literary Burmese"))


STORY_NEVER_KEEP = ("repeats itself", "far too long")     # would read for minutes over a stretched picture


def _story_strip_foreign(text):
    """A Burmese fragment kept for review without letters of another script (2026-10-25, Flow sample: "二姐တော်တယ်",
    "ရေထဲ जानမိတ်", "မဖျقသိမ်း" - the voice would read them out). Latin is left (names in English read
    understandably); None when the other letters are over 30% of the letters (then the text is kept as it was)."""
    import unicodedata
    t = str(text or "")
    def myanmar(ch):
        return 0x1000 <= ord(ch) <= 0x109F or 0xA9E0 <= ord(ch) <= 0xA9FF or 0xAA60 <= ord(ch) <= 0xAA7F
    letters = [ch for ch in t if ch.isalpha() or myanmar(ch) or unicodedata.category(ch) in ("Mn", "Mc")]
    foreign = {ch for ch in letters if not myanmar(ch) and not ("A" <= ch <= "Z" or "a" <= ch <= "z")}
    if not foreign:
        return t
    if sum(ch in foreign for ch in letters) > 0.3 * len(letters):
        return None
    return re.sub(r"\s{2,}", " ", "".join(ch for ch in t if ch not in foreign)).strip()


def _story_fragment_reusable(text, kept):
    """A cached fragment is used again when it passes today's checks, or when the writer kept it for review after
    three attempts (any issue but a loop or a far too long line, 2026-10-24)."""
    issues = _story_local_style_issues(text)
    if not kept:
        return not _story_text_unicode_issues(text) and not issues
    return not any(str(i).startswith(STORY_NEVER_KEEP) for i in issues)


STORY_LINE_MAX_LETTERS = 1000       # one beat's line; the longest of 3,134 real ones (2026-10-03/04) had 410
_STORY_REPEAT_LOOP = re.compile(r"(.{1,16}?)\1{5,}", re.S)


def _story_repeat_loop(text):
    """The piece a stuck writer repeats 6+ times in a row, or "" (2026-10-04, bGsvBKsuQ80 B0062: "…ခြောက်ဆယ့်ဆယ့်
    ဆယ့်…", 43,582 letters for a 5.5 s beat, read as 22.7 min of TTS over a stretched picture). Dots or spaces
    alone do not count."""
    for m in _STORY_REPEAT_LOOP.finditer(str(text or "")):
        unit = m.group(1)
        if any(ch.isalnum() or 0x1000 <= ord(ch) <= 0x109F for ch in unit):
            return unit
    return ""


def _story_local_style_issues(text):
    """Cheap deterministic guards for errors a semantic auditor may overlook."""
    t = str(text or "")
    issues = []
    loop = _story_repeat_loop(t)        # never kept (not a soft issue): the beat is asked again
    if loop:
        issues.append(f"repeats itself: {loop!r} over and over (the writer got stuck in a loop)")
    if len(t) > STORY_LINE_MAX_LETTERS:
        issues.append(f"far too long for one beat: {len(t)} letters (real lines stay under {STORY_LINE_MAX_LETTERS})")
    if OUTPUT_LANGUAGE != "my":     # Studio: the Burmese guards below do not apply
        if OUTPUT_LANGUAGE == "en":
            talk = sorted(set(m.lower() for m in re.findall(
                r"\b(?:we (?:can )?see|is shown|are shown|in this (?:scene|shot|video|clip)|the camera|on screen)\b", t, re.I)))
            if talk:
                issues.append(f"narrates the footage instead of the story: {', '.join(talk)}")
        return issues
    greetings = [
        "ကဲ ပရိသတ်", "ပရိသတ်တွေခင်ဗျာ", "ဆက်ကြည့်ရအောင်", "ကြည့်ရှုသူများ",
    ]
    for token in greetings:
        if token in t:
            issues.append(f"unwanted audience intro/filler: {token}")
    # V6.2: tell the story, never narrate the footage ("a family photo is shown").
    # Reporting verbs (ပြောပြထား / ရှင်းပြထား / ညွှန်ပြထား / ဖော်ပြထား) are fine, and so is a
    # reflection in the story (မျက်ဝန်းထဲမှာ ဧကရာဇ်ရဲ့ ပုံရိပ်က ထင်ဟပ်နေ: 武朝大帝 21:06, 44:57).
    t = re.sub(r"ပုံရိပ်\S{0,3}\s*ထင်", "", t)
    # 2026-10-24: "the System shows …" is the story in a system/isekai video (Isekai G000297
    # "…ရရှိကြောင်း စနစ်ကပြသလာပါတယ်"), not the footage
    t = re.sub(r"စနစ်\s*(?:က|ရဲ့|မှ)?\s*ပြသ", "စနစ်", t)
    screen_talk = sorted(set(re.findall(
        r"(?<!ပြော)(?<!ရှင်း)(?<!ညွှန်)(?<!ဖော်)ပြထား|ပြသ(?!ွ)|မြင်ရပါတယ်|မြင်ရတယ်|မြင်တွေ့ရ|တွေ့ရပါတယ်|တွေ့ရတယ်|တွေ့ရှိရ"
        r"|ပုံရိပ်|ဗီဒီယို|မြင်ကွင်း|ကင်မရာ|ရိုက်ကွင်း",
        t,
    )))
    if screen_talk:
        issues.append(f"narrates the footage instead of the story: {', '.join(screen_talk)}")
    latin = sorted(set(re.findall(r"[A-Za-z]{2,}", t)))      # V6.4: "Ning Song" read out in English
    if latin:
        issues.append(f"Latin letters in the Burmese narration: {', '.join(latin[:4])} (write names in Burmese script)")
    # 2026-10-02: flash-lite wrote written-style Burmese ("…ကိုင်ထားခဲ့သည် လင်ချွမ်က …", 84 of 231 paragraphs of
    # an English-dub test) although the prompt asks for spoken storytelling. A clause ending in သည် and the
    # particles ၏ / ၌ are refused (သည်း, ဆိုသည်မှာ are not endings and pass).
    literary = sorted(set(re.findall(r"သည်(?=[\s။၊,.!?]|$)|၏|၌", t)))
    if literary:
        issues.append(f"literary Burmese instead of spoken storytelling: {', '.join(literary)} "
                      "(end clauses with …တယ် / …ပါတယ် / …ခဲ့တယ်)")
    return issues


def _is_low_value_visual_event(item):
    """Drop camera/establishing-shot description from STORY narration, not from evidence ledgers.

    Keep plot-changing environment events (red rain, zombies, crash, fire, system activation, etc.).
    """
    if str(item.get("kind") or "event") not in {"event", "visual"}:
        return False
    actors = item.get("actors") or []
    actor_text = " ".join(str(x) for x in actors if x).strip().lower()
    blob = " ".join(
        str(item.get(k) or "")
        for k in ("action", "location", "evidence", "uncertainty", "object")
    ).lower()

    # Never suppress meaningful state changes just because the shot is wide/aerial.
    meaningful = (
        "zombie", "rain", "red rain", "attack", "fight", "hit", "punch", "slap",
        "push", "grab", "open", "close", "door", "enter", "exit", "run", "fall",
        "crash", "explosion", "fire", "blood", "system", "hologram", "phone", "weapon",
        "ဇွန်ဘီ", "မိုး", "တိုက်ခိုက်", "ထိုး", "ရိုက်", "တွန်း", "တံခါး", "ဝင်", "ထွက်",
        "ပြေး", "လဲ", "မီး", "သွေး", "စနစ်", "ဖုန်း",
    )
    if any(k in blob for k in meaningful):
        return False

    camera_meta = (
        "aerial", "overhead", "bird's-eye", "birds-eye", "establishing shot", "wide shot",
        "camera shot", "camera view", "pan shot", "drone shot", "exterior view", "scenic view",
        "high-angle", "high angle", "landscape", "traffic and gas station", "gas station and traffic",
        "ကင်မရာ ရိုက်ချက်", "အာကာသ ကင်မရာ", "အထက်စီး မြင်ကွင်း", "အပေါ်စီး မြင်ကွင်း",
        "ပတ်ဝန်းကျင် မြင်ကွင်း", "ရှုခင်း", "ယာဉ်ကြော ပတ်ဝန်းကျင်",
    )
    generic_environment = (
        "desert highway", "highway view", "road view", "traffic", "gas station",
        "သဲကန္တာရ လမ်းမ", "ဓာတ်ဆီဆိုင်", "ယာဉ်ကြော",
    )
    camera_only = any(k in blob for k in camera_meta)
    environment_only = (not actor_text) and any(k in blob for k in generic_environment)
    return bool(camera_only or environment_only)


def _filter_storytelling_events(events):
    kept, dropped = [], []
    for ev in events:
        if _is_low_value_visual_event(ev):
            dropped.append(ev)
        else:
            kept.append(ev)
    if dropped:
        print(f"[STORY VISUAL FILTER] omitted {len(dropped)} camera/establishing-only event(s) from narration timeline")
        for ev in dropped[:8]:
            print(f"    - {str(ev.get('action') or ev.get('evidence') or '')[:180]}")
    return kept


def _audit_story_coverage(pool, group, story_text):
    """Independently verify that the prose itself represents every mandatory item.

    Writer-declared covered_item_ids are NOT trusted as proof. The auditor must judge
    semantic presence in story_text against the verified timeline evidence.
    """
    evidence = json.dumps(group, ensure_ascii=False)
    prompt = f"""
You are a STRICT COVERAGE AUDITOR for a long-form Burmese storytelling system.

VERIFIED MANDATORY TIMELINE ITEMS:
{evidence}

STORY TEXT TO AUDIT:
{story_text}

AUDIT RULES — COVERAGE:
- Judge the STORY TEXT itself. Do NOT trust any claimed coverage IDs from the writer.
- For each story_item_id, decide whether its actual meaning is represented in the prose.
- A dialogue item counts as covered only if that dialogue turn's meaning and important detail survive.
- "They talked", "they argued", or another vague compression does NOT cover omitted individual dialogue turns.
- A visual event counts as covered only if the concrete action survives: actor/action/target/object/entry/exit/door/phone/etc. as supported by evidence.
- Paraphrase and natural Burmese integration are allowed; exact source wording is not required.
- Do not require unsupported detail and do not penalize uncertainty that was correctly preserved.
- Never mark an item covered merely because adjacent events make it inferable.
- actually_covered_item_ids and missing_item_ids must partition the required story_item_ids.

AUDIT RULES — EVIDENCE FIDELITY:
- evidence_fidelity_pass must be FALSE if STORY TEXT invents or changes any person name, relationship, speaker identity, object, location, cause, motive, action, result, number, time, or other factual detail that is not supported by the VERIFIED MANDATORY TIMELINE ITEMS.
- A name is especially strict: do not accept a newly invented neighbor/relative/character name merely because the surrounding event is plausible.
- If wording is garbled or mixed with unrelated foreign-script characters so the intended meaning is unreliable, evidence_fidelity_pass must be FALSE.
- unsupported_claims must quote or briefly identify every unsupported/changed claim you notice. If none, return an empty array.

AUDIT RULES — SPOKEN NARRATOR STYLE:
- This must sound like a Burmese YouTube/movie-recap narrator SPEAKING, not a novel, essay, report, subtitle dump, or formal written Burmese.
- narrator_style_pass must be FALSE if the text repeatedly uses literary/formal constructions such as “သည်”, “၏”, “၌”, “ထိုသို့”, “သို့သော်”, “ထို့နောက်”, “ဖြစ်ကြောင်း”, “ပြောကြားခဲ့သည်”, “သိရှိရသည်”, or long chained clauses that sound read from a book.
- Prefer conversational Burmese rhythm: “က”, “မှာ”, “တော့”, “ဒါပေမဲ့”, “ပြီးတော့”, “အဲဒီအချိန်မှာ”, “သိလိုက်ရတော့”, “ပြောလိုက်တယ်/ပြောတယ်”.
- Sentences should usually fit one natural breath. Break long multi-clause sentences into shorter voiceover-friendly sentences.
- Do not put English names/transliterations in parentheses after Burmese names unless the evidence requires the English wording to be spoken.
- Dialogue should be retold naturally by the narrator while preserving meaning, not converted into stiff indirect-speech prose.
- A few unavoidable formal words do not fail style by themselves; fail only when the overall delivery sounds written rather than spoken.
- style_violations must briefly identify the actual style problems found.

Return only the requested structured JSON.
""".strip()
    return pool.generate_json(prompt, STORY_AUDIT_SCHEMA, temperature=0.0, max_output_tokens=16384)


def _normalize_audit(required_ids, audit):
    required = list(required_ids)
    required_set = set(required)
    covered = [x for x in (audit.get("actually_covered_item_ids") or []) if x in required_set]
    missing_from_audit = [x for x in (audit.get("missing_item_ids") or []) if x in required_set]
    covered_set = set(covered)
    missing_set = set(missing_from_audit)

    # The auditor may accidentally omit an ID from both arrays. Treat that as missing.
    missing = [x for x in required if x in missing_set or x not in covered_set]
    actually_covered = [x for x in required if x not in set(missing)]
    return actually_covered, missing



def _build_direct_sync_targets_v51(timeline, completed_files):
    """Build the ONLY sync buckets used by V5.1.

    Core rule requested by the user:
      * dialogue narration -> exact Whisper [start,end]
      * non-dialogue story narration -> visual gaps outside Whisper dialogue windows

    No later semantic alignment is allowed. The storyteller writes directly into these
    buckets, so Smart Sync only retimes video to already-correct narration blocks.
    """
    durations = {x["src"].name: float(x.get("duration") or 0.0) for x in completed_files}
    by_file = {}
    for item in timeline:
        by_file.setdefault(str(item.get("source_file") or ""), []).append(item)

    targets = []
    target_seq = 1
    mapped_ids = set()

    for file_item in completed_files:
        name = file_item["src"].name
        duration = max(0.03, float(durations.get(name) or 0.0))
        rows = by_file.get(name, [])
        dialogues = sorted(
            [x for x in rows if x.get("kind") == "dialogue"],
            key=lambda x: (float(x.get("file_start_sec", 0.0)), int(x.get("transcript_index", -1))),
        )
        events = sorted(
            [x for x in rows if x.get("kind") == "event"],
            key=lambda x: (float(x.get("file_start_sec", 0.0)), float(x.get("file_end_sec", 0.0))),
        )

        # Build an interleaved descriptor list first. Dialogue windows are exact Whisper
        # windows. Visual windows are ONLY the remaining video between dialogue windows.
        desc = []
        if not dialogues:
            if events:
                desc.append({
                    "bucket": "VISUAL_GAP", "source_file": name,
                    "source_start_sec": 0.0, "source_end_sec": duration,
                    "items": [], "fallback_overlap": False,
                })
        else:
            prev_end = 0.0
            for i, d in enumerate(dialogues):
                d_start = max(0.0, min(duration, float(d.get("file_start_sec", 0.0) or 0.0)))
                d_end = max(d_start + 0.03, min(duration, float(d.get("file_end_sec", d_start) or d_start)))
                if i + 1 < len(dialogues):
                    next_start = max(0.0, min(duration, float(dialogues[i + 1].get("file_start_sec", duration) or duration)))
                    if next_start >= d_start:
                        d_end = min(d_end, max(d_start + 0.03, next_start))

                # Real non-dialogue source before this transcript anchor.
                if d_start > prev_end + 0.02:
                    desc.append({
                        "bucket": "VISUAL_GAP", "source_file": name,
                        "source_start_sec": prev_end, "source_end_sec": d_start,
                        "items": [], "fallback_overlap": False,
                    })

                desc.append({
                    "bucket": "DIALOGUE_ANCHOR", "source_file": name,
                    "source_start_sec": d_start, "source_end_sec": d_end,
                    "items": [d], "fallback_overlap": False,
                    "transcript_index": d.get("transcript_index"),
                })
                mapped_ids.add(str(d.get("story_item_id") or ""))
                prev_end = max(prev_end, d_end)

            if duration > prev_end + 0.02:
                desc.append({
                    "bucket": "VISUAL_GAP", "source_file": name,
                    "source_start_sec": prev_end, "source_end_sec": duration,
                    "items": [], "fallback_overlap": False,
                })

        visual_desc = [x for x in desc if x["bucket"] == "VISUAL_GAP"]

        def ev_mid(ev):
            a = float(ev.get("file_start_sec", 0.0) or 0.0)
            b = float(ev.get("file_end_sec", a) or a)
            return (a + max(a, b)) / 2.0

        # Every visual event goes to remaining video, never into a transcript anchor.
        # If the action itself happens while dialogue is speaking, place its narration in
        # the next real gap; if there is no later gap, use the nearest previous gap.
        for ev in events:
            sid = str(ev.get("story_item_id") or "")
            if not sid:
                continue
            t = ev_mid(ev)
            chosen = None
            for g in visual_desc:
                if float(g["source_start_sec"]) - 1e-6 <= t < float(g["source_end_sec"]) - 1e-6:
                    chosen = g
                    break
            if chosen is None and visual_desc:
                later = [g for g in visual_desc if float(g["source_start_sec"]) >= t - 1e-6]
                if later:
                    chosen = min(later, key=lambda g: float(g["source_start_sec"]))
                else:
                    chosen = max(visual_desc, key=lambda g: float(g["source_end_sec"]))
            if chosen is None:
                # Pathological case: dialogue covers the whole source with no true gap.
                # Keep dialogue timestamps pure by making a tiny visual fallback from the
                # event's own source range. This may replay a short shot, but never moves
                # dialogue narration away from its Whisper timestamp.
                a = max(0.0, min(duration, float(ev.get("file_start_sec", 0.0) or 0.0)))
                b = max(a + 0.20, min(duration, float(ev.get("file_end_sec", a + 0.20) or (a + 0.20))))
                chosen = {
                    "bucket": "VISUAL_GAP", "source_file": name,
                    "source_start_sec": a, "source_end_sec": min(duration, b),
                    "items": [], "fallback_overlap": True,
                }
                desc.append(chosen)
                visual_desc.append(chosen)
            chosen["items"].append(ev)
            mapped_ids.add(sid)

        # Emit only buckets that have actual mandatory story evidence.
        # Preserve descriptor order; fallback visual buckets are sorted by source time.
        normal = [x for x in desc if x.get("items")]
        normal.sort(key=lambda x: (
            float(x.get("source_start_sec", 0.0)),
            0 if x.get("bucket") == "DIALOGUE_ANCHOR" else 1,
        ))
        for d in normal:
            item_ids = [str(x.get("story_item_id") or "") for x in d.get("items") or [] if str(x.get("story_item_id") or "")]
            if not item_ids:
                continue
            targets.append({
                "target_id": f"T{target_seq:05d}",
                "bucket": d["bucket"],
                "source_file": name,
                "source_start_sec": float(d["source_start_sec"]),
                "source_end_sec": max(float(d["source_start_sec"]) + 0.03, float(d["source_end_sec"])),
                "story_item_ids": item_ids,
                "items": list(d.get("items") or []),
                "transcript_index": d.get("transcript_index"),
                "fallback_overlap": bool(d.get("fallback_overlap")),
            })
            target_seq += 1

    required = [str(x.get("story_item_id") or "") for x in timeline if str(x.get("story_item_id") or "")]
    missing = [sid for sid in required if sid not in mapped_ids]
    if missing:
        raise RuntimeError(f"V5.1 direct sync target mapping missed story item IDs: {missing[:20]}")
    return targets


def _story_output_schema_v51(target_ids):
    props = {str(tid): {"type": "string"} for tid in target_ids}
    return {
        "type": "object",
        "properties": {
            "units": {
                "type": "object",
                "properties": props,
                "required": list(props.keys()),
            }
        },
        "required": ["units"],
    }


def _build_full_storytelling_v51(pool, timeline, registry, story_cache_dir, completed_files):
    """Write the smooth story DIRECTLY into final Whisper/gap sync buckets.

    There is deliberately no post-writing alignment stage in V5.1. The model sees all
    buckets in order and writes them as consecutive fragments of ONE continuous narrator
    script. Python owns timestamps and bucket membership; Gemini owns only the wording.
    """
    story_cache_dir.mkdir(parents=True, exist_ok=True)
    targets = _build_direct_sync_targets_v51(timeline, completed_files)
    target_by_id = {x["target_id"]: x for x in targets}
    groups = _story_chunks(timeline)
    registry_text = json.dumps(_compact_registry(registry), ensure_ascii=False)
    previous_tail = ""
    audit_summary = []
    all_unit_rows = []

    for part_i, group in enumerate(groups, start=1):
        required_ids = [str(x.get("story_item_id") or "") for x in group if str(x.get("story_item_id") or "")]
        required_set = set(required_ids)
        part_targets = []
        for t in targets:
            ids = [sid for sid in t["story_item_ids"] if sid in required_set]
            if not ids:
                continue
            items = [x for x in t["items"] if str(x.get("story_item_id") or "") in set(ids)]
            part_targets.append({
                "target_id": t["target_id"],
                "bucket": t["bucket"],
                "source_file": t["source_file"],
                "source_window": [t["source_start_sec"], t["source_end_sec"]],
                "story_item_ids": ids,
                "items": items,
            })

        if not part_targets:
            continue

        cache = story_cache_dir / f"story_part_{part_i:03d}.json"
        expected_target_ids = [x["target_id"] for x in part_targets]

        def _cache_valid(saved):
            if not isinstance(saved, dict) or saved.get("version") != "v5.1-direct-writer-sync":
                return False
            units = saved.get("sync_units") or []
            if [str(x.get("target_id") or "") for x in units] != expected_target_ids:
                return False
            text = " ".join(str(x.get("text") or "").strip() for x in units).strip()
            if _norm_story_exact_v47(text) != _norm_story_exact_v47(saved.get("story_text") or ""):
                return False
            audit = saved.get("coverage_audit") or {}
            covered, missing = _normalize_audit(required_ids, audit) if audit else ([], required_ids)
            return (
                bool(saved.get("coverage_verified"))
                and bool(saved.get("narrator_style_verified"))
                and not missing
                and required_set.issubset(set(covered))
                and bool(audit.get("evidence_fidelity_pass"))
                and not (audit.get("unsupported_claims") or [])
                and not _story_text_unicode_issues(text)
                and not _story_local_style_issues(text)
            )

        if cache.exists():
            try:
                saved = load_json(cache)
                if _cache_valid(saved):
                    units = saved.get("sync_units") or []
                    text = str(saved.get("story_text") or "").strip()
                    all_unit_rows.extend(units)
                    previous_tail = text
                    audit_summary.append({"part": part_i, "required": len(required_ids), "covered": len(required_ids), "missing": [], "status": "RESUMED_V51"})
                    print(f"  [V5.1 STORY RESUME] part {part_i}/{len(groups)} | direct sync units={len(units)}")
                    continue
            except Exception as exc:
                raise_if_terminal(exc)
                print(f"  [V5.1 STORY CACHE WARN] part {part_i}: {exc}; regenerating.")

        prompt_targets = []
        for t in part_targets:
            compact_items = [_compact_anchor_evidence(x) for x in t["items"]]
            prompt_targets.append({
                "target_id": t["target_id"],
                "bucket": t["bucket"],
                "source_file": t["source_file"],
                "source_window": t["source_window"],
                "mandatory_items": compact_items,
            })

        base_prompt = f"""
Write the next section of a COMPLETE LONG-FORM BURMESE STORYTELLING RETELLING from VERIFIED EVIDENCE ONLY.

THIS VERSION HAS FIXED SMART-SYNC BUCKETS. You are writing ONE smooth continuous spoken Burmese narrator script, but you MUST return one text fragment for EVERY target_id below. When Python concatenates the fragments in target order, they must sound like one naturally flowing story.

CHARACTER REGISTRY:
{registry_text}

FIXED TARGETS IN FINAL NARRATION ORDER:
{json.dumps(prompt_targets, ensure_ascii=False)}

TAIL OF PREVIOUS STORY (continuity only; do not repeat it):
{previous_tail[-2200:]}

CRITICAL SYNC RULES:
- DIALOGUE_ANCHOR means the text will play EXACTLY on that Whisper transcript start/end window. Write ONLY the meaning of the dialogue mandatory_items in that target. Do not add visual actions, camera descriptions, or another dialogue turn there.
- VISUAL_GAP means the text will play in the remaining non-dialogue video between Whisper windows. Write ONLY the supplied visual/action mandatory_items there. Do not repeat the previous dialogue and do not borrow the next dialogue.
- Python owns target IDs and timestamps. NEVER move content to another target. NEVER output IDs/timestamps inside the Burmese narration text.
- Do not repeat the same fact/dialogue/action in two targets.
- Every target_id must have non-empty natural Burmese text because every target contains mandatory evidence.

WRITING RULES:
- Treat all target texts as consecutive fragments of ONE script. Use natural connectors across target boundaries so the listener hears a smooth continuous narrator, not subtitles or disconnected captions.
- Preserve every dialogue turn's actual meaning. Dialogue can be paraphrased naturally in Burmese; it does not need to be quoted word-for-word.
- Preserve only STORY-RELEVANT visible actions supplied in VISUAL_GAP targets.
- Do NOT narrate aerial/overhead/wide-shot language, scenery, road layout, gas stations, traffic, background architecture, camera angle, or “we see...” unless explicitly supplied as a plot-changing mandatory action.
- Preserve chronology. Never invent names, relationships, motives, causes, outcomes, objects, actions, or dialogue.
- Natural SPOKEN Burmese recap style. Avoid formal/literary Burmese such as “သည်”, “၏”, “၌”, “ထိုသို့”, “သို့သော်”, “ထို့နောက်”, “ဖြစ်ကြောင်း”, “ပြောကြားခဲ့သည်”.
- No audience greeting, intro/outro, CTA, or filler.
- Clean Burmese Unicode; no unrelated Thai/Arabic/Khmer/CJK corruption.
- LENGTH IS ALLOWED. Do not shorten away required meaning merely to fit timing. Video will be retimed to the narration.

Return structured JSON only. Under `units`, return EXACTLY every target_id shown above with its Burmese narration fragment.
""".strip()

        schema = _story_output_schema_v51(expected_target_ids)
        final_data = None
        final_audit = None
        final_model = final_key = final_audit_model = final_audit_key = ""
        final_missing = list(required_ids)
        final_style_ok = False
        final_fidelity_ok = False
        final_unsupported = []
        final_unicode = []
        final_local_style = []
        repair_feedback = ""

        for attempt in range(1, 4):
            prompt = base_prompt
            if repair_feedback:
                prompt += "\n\nSTRICT REPAIR FEEDBACK:\n" + repair_feedback
                prompt += "\nRegenerate ALL target texts together so the full concatenated narration remains smooth."

            data, model, key_tag = pool.generate_json(
                prompt, schema, temperature=(0.22 if attempt == 1 else 0.10), max_output_tokens=32768
            )
            unit_map = data.get("units") or {}
            missing_keys = [tid for tid in expected_target_ids if not str(unit_map.get(tid) or "").strip()]
            extra_keys = [str(k) for k in unit_map.keys() if str(k) not in set(expected_target_ids)] if isinstance(unit_map, dict) else []
            if missing_keys or extra_keys:
                repair_feedback = (
                    f"Target-key contract failed. Missing/empty: {json.dumps(missing_keys)}; extra: {json.dumps(extra_keys)}. "
                    "Return every required target exactly once and no extra targets."
                )
                final_data = data; final_model, final_key = model, key_tag
                continue

            units = []
            for t in part_targets:
                txt = str(unit_map.get(t["target_id"]) or "").strip()
                units.append({
                    "target_id": t["target_id"],
                    "bucket": t["bucket"],
                    "text": txt,
                    "story_item_ids": list(t["story_item_ids"]),
                })
            text = " ".join(x["text"] for x in units if x["text"]).strip()
            unicode_issues = _story_text_unicode_issues(text)
            local_style_issues = _story_local_style_issues(text)
            if unicode_issues or local_style_issues:
                repair_feedback = (
                    f"Text guard failed. Unicode issues={json.dumps(unicode_issues[:10], ensure_ascii=False)}; "
                    f"style issues={json.dumps(local_style_issues[:10], ensure_ascii=False)}. "
                    "Rewrite all units as clean natural spoken Burmese without changing target ownership."
                )
                final_data = data; final_model, final_key = model, key_tag
                final_unicode = unicode_issues; final_local_style = local_style_issues
                continue

            print(f"    [V5.1 SEMANTIC AUDIT] part {part_i}/{len(groups)} | direct targets={len(units)} | mandatory items={len(required_ids)}")
            audit, am, ak = _audit_story_coverage(pool, group, text)
            covered, missing = _normalize_audit(required_ids, audit)
            style_ok = bool(audit.get("narrator_style_pass"))
            fidelity_ok = bool(audit.get("evidence_fidelity_pass")) and not (audit.get("unsupported_claims") or [])

            final_data = data; final_audit = audit
            final_model, final_key = model, key_tag
            final_audit_model, final_audit_key = am, ak
            final_missing = missing; final_style_ok = style_ok; final_fidelity_ok = fidelity_ok
            final_unsupported = list(audit.get("unsupported_claims") or [])
            final_unicode = unicode_issues; final_local_style = local_style_issues

            if not missing and style_ok and fidelity_ok and not final_unsupported:
                saved = {
                    "version": "v5.1-direct-writer-sync",
                    "story_text": text,
                    "covered_item_ids": required_ids,
                    "sync_units": units,
                    "coverage_audit": audit,
                    "coverage_verified": True,
                    "narrator_style_verified": True,
                    "coverage_audit_model": am,
                    "coverage_audit_key": ak,
                    "writer_model": model,
                    "writer_key": key_tag,
                }
                save_json(cache, saved)
                all_unit_rows.extend(units)
                previous_tail = text
                audit_summary.append({"part": part_i, "required": len(required_ids), "covered": len(covered), "missing": [], "status": "PASS_V51", "writer_model": model, "audit_model": am})
                print(f"    [V5.1 STORY PASS] writer={model} {key_tag} | auditor={am} {ak} | targets={len(units)}")
                break

            repair_feedback = (
                f"Coverage missing IDs: {json.dumps(missing)}. "
                f"Style violations: {json.dumps(audit.get('style_violations') or [], ensure_ascii=False)}. "
                f"Unsupported claims: {json.dumps(final_unsupported, ensure_ascii=False)}. "
                "Fix the target texts without moving dialogue into visual targets or visual actions into dialogue targets."
            )
        else:
            raise RuntimeError(
                f"V5.1 direct-sync storytelling failed for part {part_i}: missing={final_missing[:20]} "
                f"style={final_style_ok} fidelity={final_fidelity_ok} unsupported={final_unsupported[:6]}"
            )

        save_json(story_cache_dir.parent / "STORY_COVERAGE_AUDIT.json", audit_summary)

    # Merge the same target if a story chunk boundary happened to split its evidence.
    merged = []
    for row in all_unit_rows:
        if merged and merged[-1]["target_id"] == row["target_id"]:
            merged[-1]["text"] = (merged[-1]["text"].rstrip() + " " + row["text"].lstrip()).strip()
            merged[-1]["story_item_ids"].extend(row.get("story_item_ids") or [])
        else:
            merged.append({
                "target_id": row["target_id"], "bucket": row["bucket"],
                "text": row["text"], "story_item_ids": list(row.get("story_item_ids") or []),
            })

    sync_blocks = []
    full_parts = []
    for i, row in enumerate(merged, start=1):
        t = target_by_id[row["target_id"]]
        txt = str(row.get("text") or "").strip()
        if not txt:
            continue
        full_parts.append(txt)
        sync_blocks.append({
            "sync_block_id": f"B{i:04d}",
            "unit_kind": t["bucket"],
            "anchor_id": t["target_id"],
            "source_file": t["source_file"],
            "source_start_sec": float(t["source_start_sec"]),
            "source_end_sec": float(t["source_end_sec"]),
            "source_duration": max(0.03, float(t["source_end_sec"]) - float(t["source_start_sec"])),
            "story_item_ids": list(row.get("story_item_ids") or []),
            "narration_text": txt,
            "preserve_story_text": True,
            "direct_writer_sync_v51": True,
            "fallback_overlap": bool(t.get("fallback_overlap")),
        })

    full_story = " ".join(full_parts).strip()
    if _norm_story_exact_v47(full_story) != _norm_story_exact_v47(" ".join(b["narration_text"] for b in sync_blocks)):
        raise RuntimeError("V5.1 internal story/block guard failed")
    return full_story, sync_blocks


def _build_full_storytelling(pool, timeline, registry, story_cache_dir):
    """Write exhaustive Burmese storytelling with independent semantic coverage audit."""
    story_cache_dir.mkdir(parents=True, exist_ok=True)
    parts = []
    groups = _story_chunks(timeline)
    previous_tail = ""
    registry_text = json.dumps(_compact_registry(registry), ensure_ascii=False)
    audit_summary = []

    for i, group in enumerate(groups, start=1):
        cache = story_cache_dir / f"story_part_{i:03d}.json"
        required_ids = [x["story_item_id"] for x in group]
        required_set = set(required_ids)
        evidence = json.dumps(group, ensure_ascii=False)

        # V4.3 only resumes a story cache after semantic coverage AND spoken narrator-style audit have passed.
        if cache.exists():
            try:
                saved = load_json(cache)
                text = (saved.get("story_text") or "").strip()
                declared = set(saved.get("covered_item_ids") or [])
                audit = saved.get("coverage_audit") or {}
                audit_covered, audit_missing = _normalize_audit(required_ids, audit) if audit else ([], required_ids)
                style_verified = bool(saved.get("narrator_style_verified")) and bool(audit.get("narrator_style_pass"))
                fidelity_verified = bool(audit.get("evidence_fidelity_pass")) and not (audit.get("unsupported_claims") or [])
                unicode_clean = not _story_text_unicode_issues(text)
                local_style_clean = not _story_local_style_issues(text)
                verified = (
                    bool(saved.get("coverage_verified"))
                    and not audit_missing
                    and required_set.issubset(set(audit_covered))
                    and style_verified
                    and fidelity_verified
                    and unicode_clean
                    and local_style_clean
                )

                if text and required_set.issubset(declared) and verified:
                    print(f"  [STORY RESUME] part {i}/{len(groups)} | semantic coverage={len(required_ids)}/{len(required_ids)}")
                    parts.append(text)
                    previous_tail = text
                    audit_summary.append({
                        "part": i,
                        "required": len(required_ids),
                        "covered": len(required_ids),
                        "missing": [],
                        "status": "RESUMED_VERIFIED",
                    })
                    continue

                # Upgrade an older cache by independently auditing its prose before discarding it.
                if text and required_set.issubset(declared):
                    print(f"  [STORY CACHE AUDIT] part {i}/{len(groups)} | verifying old/unverified cache...")
                    audit, am, ak = _audit_story_coverage(pool, group, text)
                    audit_covered, audit_missing = _normalize_audit(required_ids, audit)
                    style_ok = bool(audit.get("narrator_style_pass"))
                    fidelity_ok = bool(audit.get("evidence_fidelity_pass")) and not (audit.get("unsupported_claims") or [])
                    unicode_issues = _story_text_unicode_issues(text)
                    local_style_issues = _story_local_style_issues(text)
                    if not audit_missing and style_ok and fidelity_ok and not unicode_issues and not local_style_issues:
                        saved["coverage_audit"] = audit
                        saved["coverage_verified"] = True
                        saved["narrator_style_verified"] = True
                        saved["coverage_audit_model"] = am
                        saved["coverage_audit_key"] = ak
                        save_json(cache, saved)
                        print(f"    [AUDIT PASS] {am} {ak} | semantic coverage={len(required_ids)}/{len(required_ids)} | narrator style=PASS")
                        parts.append(text)
                        previous_tail = text
                        audit_summary.append({
                            "part": i,
                            "required": len(required_ids),
                            "covered": len(required_ids),
                            "missing": [],
                            "status": "OLD_CACHE_AUDITED_PASS",
                        })
                        continue
                    print(f"    [AUDIT FAIL] old cache missing {len(audit_missing)} item(s); regenerating part.")
            except Exception as exc:
                raise_if_terminal(exc)
                print(f"  [STORY CACHE WARN] part {i}: {exc}; regenerating.")

        base_prompt = f"""
Write the next section of a COMPLETE LONG-FORM BURMESE STORYTELLING RETELLING from VERIFIED EVIDENCE ONLY.

THIS IS NOT A SUMMARY AND NOT A SHORT RECAP.
THIS IS A SPOKEN VOICEOVER SCRIPT, NOT WRITTEN LITERATURE.
Retell the story continuously like a natural Burmese YouTube/movie-recap narrator SPEAKING to viewers, while preserving ALL meaningful actions and EVERY dialogue turn.

CHARACTER REGISTRY:
{registry_text}

MANDATORY TIMELINE ITEMS FOR THIS SECTION:
{evidence}

TAIL OF PREVIOUS STORY (continuity only; do not repeat it):
{previous_tail[-2200:]}

NON-NEGOTIABLE RULES:
- Every story_item_id in MANDATORY TIMELINE ITEMS must be represented in story_text. Do not skip any item.
- Every item with kind="dialogue" is mandatory. Convey that dialogue turn in chronological order even if it seems minor.
- Do NOT collapse a conversation into vague phrases such as "they talked" or "they argued" when individual dialogue meanings are provided.
- Dialogue does not need to be quoted word-for-word. Integrate it naturally into Burmese storytelling, but preserve each turn's actual meaning and important details.
- If a dialogue meaning is still in the source language, translate it faithfully into Burmese while preserving the content.
- Preserve STORY-RELEVANT visible actions: who acts, who receives the action, entry/exit, door actions, object handling, slap/hit/push/grab/kiss, phone use, weapons, letters/documents, sitting/standing, and other actions that change the story.
- Do NOT narrate camera language or decorative establishing shots such as aerial/overhead/wide-shot descriptions, scenery, road layout, gas stations, traffic, background architecture, camera angle, or “we see...” unless that visual itself changes the plot. Never say things like “အာကာသ ကင်မရာ ရိုက်ချက်အရ...” or describe an overhead desert-road view just because it is visible.
- Preserve chronological order. Do not rearrange events for dramatic effect.
- Use canonical character names when known. If unresolved, use the provided character ID / neutral reference; never invent a name.
- Never invent motives, relationships, causes, outcomes, actions, or dialogue absent from evidence.
- Do not turn uncertain evidence into certainty.
- Write smooth connected Burmese in SPOKEN NARRATOR style, not bullets, not JSON inside story_text, and not a technical report.
- The listener should feel that a narrator is TALKING, not reading a novel or formal article.
- Strongly avoid literary/formal written Burmese such as: “သည်”, “၏”, “၌”, “ထိုသို့”, “သို့သော်”, “ထို့နောက်”, “ဖြစ်ကြောင်း”, “ပြောကြားခဲ့သည်”, “သိရှိရသည်”. Rewrite the whole sentence conversationally instead of mechanically swapping words.
- Prefer spoken connectors and particles where natural: “က”, “မှာ”, “တော့”, “ဒါပေမဲ့”, “ပြီးတော့”, “အဲဒီအချိန်မှာ”, “ဒီလိုနဲ့”, “သိလိုက်ရတော့”.
- Keep sentences voiceover-friendly. Usually one sentence should contain one main action/idea or a small pair of tightly related ideas. Split long chains into shorter sentences with natural pauses.
- Retell dialogue as natural spoken narration, e.g. “အဲဒီတော့ သူက ဘယ်သွားခဲ့တာလဲလို့ မေးတယ်။ သူကလည်း ဆေးရုံသွားခဲ့တာလို့ ပြန်ဖြေတယ်။” Preserve every turn's meaning.
- Do NOT append English spellings in parentheses after names, e.g. avoid “အဲလက်စ် (Alex Carter)”. Use the natural Burmese name only once identity is clear.
- Do not become slangy, comedic, or overdramatic unless the evidence itself supports that tone. Keep it clear, conversational, and easy for TTS to read.
- Do not shorten merely to be concise. LENGTH IS ALLOWED. Coverage and fidelity are more important than brevity.
- Start DIRECTLY with the story. Do not address the audience with filler such as “ကဲ ပရိသတ်တွေခင်ဗျာ” or “ဆက်ကြည့်ရအောင်”. Do not add intro/outro/YouTube CTA.
- OUTPUT SCRIPT SAFETY: story_text may contain normal Burmese plus ordinary ASCII English names/terms/numbers/punctuation when genuinely required. NEVER output Thai, Arabic, Khmer, Devanagari, Chinese/Japanese/Korean, replacement characters, or other unrelated-script glyphs inside Burmese narration. If a source name is uncertain, use the verified Burmese/canonical name or a neutral reference; never improvise characters from another script.
- Re-read every generated sentence for accidental word corruption before returning JSON. Examples of INVALID output include mixed-script fragments inside Burmese words.

Return JSON with story_text and covered_item_ids. covered_item_ids MUST include every required story_item_id.
IMPORTANT: covered_item_ids are only a declaration; a separate auditor will inspect BOTH semantic coverage and narrator speaking style.
""".strip()

        print(f"  Writing FULL storytelling part {i}/{len(groups)} | mandatory items={len(required_ids)}...")
        repair_feedback = ""
        final_data = None
        final_audit = None
        final_model = final_key = final_audit_model = final_audit_key = ""
        final_missing = list(required_ids)
        final_style_ok = False
        final_style_violations = []
        final_fidelity_ok = False
        final_unsupported_claims = []
        final_unicode_issues = []
        final_local_style_issues = []

        # Initial write + up to two full-section repairs.
        for attempt in range(1, 4):
            prompt = base_prompt
            if repair_feedback:
                prompt += "\n\nSTRICT REPAIR FEEDBACK FROM INDEPENDENT COVERAGE AUDIT:\n" + repair_feedback
                prompt += "\nRegenerate the WHOLE section, preserving chronology and all prior covered evidence while adding every missing item."

            temperature = 0.25 if attempt == 1 else 0.12
            data, model, key_tag = pool.generate_json(prompt, STORY_OUTPUT_SCHEMA, temperature=temperature, max_output_tokens=32768)
            text = (data.get("story_text") or "").strip()
            declared = set(data.get("covered_item_ids") or [])
            declared_missing = [x for x in required_ids if x not in declared]

            if not text:
                declared_missing = list(required_ids)

            unicode_issues = _story_text_unicode_issues(text)
            local_style_issues = _story_local_style_issues(text)
            if unicode_issues or local_style_issues:
                final_data = data
                final_model, final_key = model, key_tag
                final_missing = []
                final_unicode_issues = unicode_issues
                final_local_style_issues = local_style_issues
                bad_chars = [f"{x['char']}({x['codepoint']} {x['name']})" for x in unicode_issues[:12]]
                print(
                    f"    [TEXT GUARD FAIL] attempt {attempt}/3 | foreign/corrupt chars={len(unicode_issues)} "
                    f"| local style issues={len(local_style_issues)}"
                )
                repair_feedback = (
                    "LOCAL TEXT SAFETY CHECK FAILED. Regenerate the WHOLE section.\n"
                    f"Forbidden/mixed-script characters: {json.dumps(bad_chars, ensure_ascii=False)}\n"
                    f"Local style issues: {json.dumps(local_style_issues, ensure_ascii=False)}\n"
                    "Use clean Burmese Unicode (plus ordinary ASCII English only when genuinely required). "
                    "Do not copy or preserve corrupted glyphs. Start directly with the story, without audience greeting/filler."
                )
                continue

            if declared_missing:
                print(f"    [DECLARED COVERAGE FAIL] attempt {attempt}/3 | missing {len(declared_missing)} ID(s)")
                repair_feedback = (
                    f"The writer declaration omitted these required IDs: {json.dumps(declared_missing)}. "
                    "Their actual evidence must appear naturally in story_text, not only in the ID list."
                )
                final_data = data
                final_model, final_key = model, key_tag
                final_missing = declared_missing
                continue

            print(f"    [SEMANTIC AUDIT] attempt {attempt}/3 | checking prose against {len(required_ids)} mandatory item(s)...")
            audit, audit_model, audit_key = _audit_story_coverage(pool, group, text)
            audit_covered, audit_missing = _normalize_audit(required_ids, audit)

            final_data = data
            final_audit = audit
            final_model, final_key = model, key_tag
            final_audit_model, final_audit_key = audit_model, audit_key
            final_missing = audit_missing
            final_style_ok = bool(audit.get("narrator_style_pass"))
            final_style_violations = list(audit.get("style_violations") or [])
            final_fidelity_ok = bool(audit.get("evidence_fidelity_pass"))
            final_unsupported_claims = list(audit.get("unsupported_claims") or [])
            final_unicode_issues = _story_text_unicode_issues(text)
            final_local_style_issues = _story_local_style_issues(text)

            if (
                not audit_missing
                and final_style_ok
                and final_fidelity_ok
                and not final_unsupported_claims
                and not final_unicode_issues
                and not final_local_style_issues
            ):
                data["coverage_audit"] = audit
                data["coverage_verified"] = True
                data["narrator_style_verified"] = True
                data["coverage_audit_model"] = audit_model
                data["coverage_audit_key"] = audit_key
                save_json(cache, data)
                print(
                    f"    [AUDIT PASS] writer={model} {key_tag} | auditor={audit_model} {audit_key} "
                    f"| semantic coverage={len(required_ids)}/{len(required_ids)} | narrator style=PASS"
                )
                parts.append(text)
                previous_tail = text
                audit_summary.append({
                    "part": i,
                    "required": len(required_ids),
                    "covered": len(audit_covered),
                    "missing": [],
                    "status": "PASS",
                    "writer_model": model,
                    "audit_model": audit_model,
                })
                break

            notes = audit.get("audit_notes") or []
            style_violations = audit.get("style_violations") or []
            print(
                f"    [AUDIT FAIL] attempt {attempt}/3 | missing={len(audit_missing)} "
                f"| narrator_style={'PASS' if final_style_ok else 'FAIL'} "
                f"| evidence_fidelity={'PASS' if final_fidelity_ok and not final_unsupported_claims else 'FAIL'}"
            )
            repair_feedback = (
                f"Independent semantic audit found these story_item_ids missing from the ACTUAL prose: {json.dumps(audit_missing)}.\n"
                f"Coverage notes: {json.dumps(notes, ensure_ascii=False)}\n"
                f"Narrator-style violations: {json.dumps(style_violations, ensure_ascii=False)}\n"
                f"Unsupported/invented claims: {json.dumps(final_unsupported_claims, ensure_ascii=False)}\n"
                f"Foreign/corrupt Unicode issues: {json.dumps(final_unicode_issues, ensure_ascii=False)}\n"
                f"Local style issues: {json.dumps(final_local_style_issues, ensure_ascii=False)}\n"
                "Regenerate as clean natural SPOKEN Burmese voiceover. Preserve every verified dialogue meaning and visual action, "
                "remove unsupported facts/names, remove corrupted foreign-script glyphs, and do not add audience filler."
            )
        else:
            pass

        # The for-loop succeeds only when a verified cache was written and part appended.
        if (
            final_missing
            or not final_style_ok
            or not final_fidelity_ok
            or final_unsupported_claims
            or final_unicode_issues
            or final_local_style_issues
        ):
            fail_record = {
                "part": i,
                "required": len(required_ids),
                "covered": len(required_ids) - len(final_missing),
                "missing": final_missing,
                "narrator_style_pass": final_style_ok,
                "style_violations": final_style_violations,
                "evidence_fidelity_pass": final_fidelity_ok,
                "unsupported_claims": final_unsupported_claims,
                "unicode_issues": final_unicode_issues,
                "local_style_issues": final_local_style_issues,
                "status": "FAILED",
                "writer_model": final_model,
                "audit_model": final_audit_model,
                "audit_notes": (final_audit or {}).get("audit_notes", []),
            }
            audit_summary.append(fail_record)
            save_json(story_cache_dir.parent / "STORY_COVERAGE_AUDIT.json", audit_summary)
            raise RuntimeError(
                f"Storytelling verification failed for part {i} after 3 attempts; "
                f"missing={len(final_missing)} item(s), narrator_style_pass={final_style_ok}, "
                f"evidence_fidelity_pass={final_fidelity_ok}, unicode_issues={len(final_unicode_issues)}. "
                f"Missing IDs: {final_missing[:20]} | Style: {final_style_violations[:6]}"
            )

        save_json(story_cache_dir.parent / "STORY_COVERAGE_AUDIT.json", audit_summary)

    return "\n\n".join(x for x in parts if x.strip()).strip()



# ============================================================================
# V4.4 VIDEO OUTPUT — VERIFIED STORY -> SYNC BLOCKS -> THIHA +28% -> SMART SYNC
# ============================================================================

SYNC_SPLIT_SCHEMA = {
    "type": "object",
    "properties": {
        "blocks": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "story_item_ids": {"type": "array", "items": {"type": "string"}},
                    "narration_text": {"type": "string"},
                },
                "required": ["story_item_ids", "narration_text"],
            },
        }
    },
    "required": ["blocks"],
}

EDGE_TTS_VOICE_V44 = "my-MM-ThihaNeural"
EDGE_TTS_RATE_V44 = "+25%"
# Studio: block TTS provider. "edge" = the V6.2 path above; "voxcpm" = Colab VoxCPM links
# (--tts-provider voxcpm --voxcpm-config <json>), same one-block-one-audio Smart Sync after it.
TTS_PROVIDER = "edge"
VOXCPM_CONFIG = {}
# Studio V6.3 narration style (--narration-style). "classic" = V6.2: one Edge TTS request per
# block, so every block ends in a full stop and a ~0.8 s silence. "flow" = the writer joins the
# beats into one continuous voice-over, and runs of consecutive blocks are voiced as ONE Edge TTS
# utterance that is cut back into blocks at each block's first word (WordBoundary timing).
# Every block still owns exactly its own words and its own beat slice.
NARRATION_STYLE = "classic"
# Studio: narration language (--narration-language, codes in app/languages.py). "my" = the original
# Burmese writer and checks, unchanged; other languages get a generic storyteller prompt and a
# script check for that language. The Gemini timeline is language-free and can be shared.
OUTPUT_LANGUAGE = "my"
# Studio V6.4 length options (A/B before choosing). 武朝大帝: 100.8 min of narration for 52.7 min of
# footage, so the picture ran at half speed on average; 13 min of it was Edge TTS silence (0.19 s
# before and 0.66 s after every block).
# --tts-pause S: cut each classic block's leading/trailing silence and end it with an S-second pause.
# --narration-length short: the writer fits each fragment to its beat (say_within_sec / max_letters).
TTS_PAUSE_SEC = None
NARRATION_LENGTH = "full"
# --smooth-motion (2026-10-10): viewers called the slowed picture choppy (median speed 0.52x, a fifth of the
# screen time under 0.35x: one frame shown 3-11 times, then a jump). Blocks slower than SMOOTH_BELOW_SPEED
# get RIFE in-between frames (smooth_motion.py, own GPU process); same slice, same frame count.
SLOW_STYLE = "rife"
FREEZE_BELOW = 0.6
SMOOTH_MOTION = False
SMOOTH_BELOW_SPEED = 0.9
# --smooth-below 0.5 (2026-10-11): only the slowest blocks get RIFE. A 2.5 h source made a 4 h story
# with 94% of its 2684 blocks under 0.9x (~5 h of RIFE on the RTX 3050); 0.5x-0.9x still repeats
# a frame every 2nd-10th frame, which the user accepts for long videos.
SMOOTH_BELOW_CHOICES = (0.9, 0.5)
NARRATOR_LETTERS_PER_SEC = 20.0    # Thiha +25%: 20.5 Burmese code points (no spaces) per second of speech
WRITER_LENGTH_RULES = {
    "full": "- LENGTH IS ALLOWED. Smart Sync will retime VIDEO to this narration; do not shorten away meaning for timing.",
    # "short" (2026-10-12, Studio "Short — to the point"): the user wants the same story, told to the point, so
    # the picture is hardly slowed and RIFE is hardly needed (full story: 90% of the screen time under 0.9x).
    "short": "- TO THE POINT. Every beat has say_within_sec: its fragment must be spoken within that time, at most "
             "max_letters letters. Still tell everything the beat has - who does what to whom, the point of every "
             "spoken line (in a few words, keep who says it), every visual effect and action - just with fewer words. "
             "Leave out only decoration, repetition, scene-setting flourishes and connectors that add nothing. "
             "Never split or merge beats.",
    # "short_steady" (2026-10-13, Studio "Short — steady picture"): the same, but never under min_letters either.
    "short_steady": "- TO THE POINT. Every beat has say_within_sec: its fragment must be spoken within that time, at "
                    "most max_letters letters. Still tell everything the beat has - who does what to whom, the point "
                    "of every spoken line (in a few words, keep who says it), every visual effect and action - just "
                    "with fewer words. Leave out only decoration, repetition, scene-setting flourishes and connectors "
                    "that add nothing. Every beat also has min_letters: never write fewer letters, so the picture is "
                    "not rushed - a beat with little dialogue is told through what happens in it (the action, the "
                    "effect, how people react), as story, never as filler and never as talk about the screen. Never "
                    "split or merge beats.",
    # V6.5 (2026-10-11, Studio "Story length"): Gemini scores every beat 1-5 first (_v65_beat_importance).
    "skip": "- LENGTH IS ALLOWED. Smart Sync will retime VIDEO to this narration. Minor beats were left out on purpose: "
            "a beat with after_skipped follows such a gap - open its fragment with a short natural bridge (a time, place "
            "or \"meanwhile\" connector) and never narrate the skipped events in detail.",
    "fit": "- A beat with say_within_sec must be spoken within that time, at most max_letters letters: keep who did or "
           "said what to whom and the meaning; drop decoration and repetition. A beat without say_within_sec is a key "
           "story beat: LENGTH IS ALLOWED there. Never split or merge beats.",
}
WRITER_LENGTH_RULES["medium"] = (
    "- MEDIUM DETAIL. Every beat has say_within_sec and max_letters: stay within those limits. "
    "Keep who does what to whom, the point of every spoken line, every visual effect and action. "
    "You may also tell supported feelings, reasons and small details. No filler, invented motives, "
    "split beats or merged beats. The time budget is 1.4x each beat's footage (minimum 2.5 seconds).")
WRITER_LENGTH_RULES["recap"] = WRITER_LENGTH_RULES["short"] + (
    " A beat with after_skipped follows dropped scenes: begin with one short natural bridge using "
    "ONLY the supplied skipped evidence. Summarize only what is needed to understand this beat; "
    "never invent missing events or retell the dropped scenes in detail."
    " A beat with introduce is the first time those people appear in this recap (their first scenes were left "
    "out): say in a few words who each of them is (name, role or look from people / the registry) the moment "
    "they appear; never invent how or why they came.")

# "fit": ordinary beats (importance 1-3) may speak at most FIT_FACTOR x their own footage (never under
# FIT_MIN_SEC), so their picture is never slower than ~0.67x; key beats (4-5) keep the full narration.
FIT_FACTOR = 1.5
FIT_MIN_SEC = 2.5
# "short": every beat may speak SHORT_FACTOR x its footage, so the picture stays near 1x (a fragment up to
# LENGTH_SLACK over is still taken on the 3rd answer).
SHORT_FACTOR = 1.1
MEDIUM_FACTOR = 1.4
MEDIUM_MIN_SEC = 2.5
RECAP_MINUTES = 12.0
RECAP_PERCENT = 0.0     # Studio "% of the video" (2026-10-25): the target follows each video's own length
# "short_steady" (2026-10-13, after the first "short" A/B; the user keeps both): flash-lite also wrote far too little - a 6.8 s beat in 2.5 s, picture
# 2.7x fast, 14% of the screen time over 1.5x, and the visual effects were left out. Every beat now has
# min_letters (SHORT_MIN_FACTOR x its footage; a fragment under min_letters / LENGTH_SLACK is asked again), and
# a block still spoken faster than its footage allows gets a pause after its narration so the picture never
# plays faster than SHORT_MAX_SPEED (the block keeps its own beat slice; the pause is the narrator's silence).
SHORT_MAX_SPEED = 1.25
SHORT_MIN_FACTOR = 1.0 / SHORT_MAX_SPEED
# SHORT_OVER_CAP (2026-10-13, user: "cutting it off would look better" than a rushed picture): in both short
# stories a block whose picture would play faster than SHORT_MAX_SPEED plays at SHORT_MAX_SPEED and the end of
# its beat slice is cut (it still starts on its own beat; the next block starts on its own beat as always).
# "pause" = the morning version (a silence after the line, short_steady only).
SHORT_OVER_CAP = "cut"
# "skip": beats scored 1-2 are left out (their footage too), never more than SKIP_MAX_SHARE of the footage.
SKIP_MAX_SHARE = 0.45
# "fit"/"short": a fragment over LENGTH_SLACK x its max_letters is asked again (attempts 1-2; the third answer is
# kept). In the first A/B (2026-10-11) flash-lite wrote past the limit in 99 of 173 limited beats.
LENGTH_SLACK = 1.2
FLOW_GROUP_TARGET_BYTES = 1800     # one Edge TTS request per group: close it at the next sentence end after this
FLOW_GROUP_HARD_BYTES = 3600       # edge-tts splits requests at 4096 bytes; a group never reaches that
FLOW_GROUP_MAX_BLOCKS = 12
FLOW_SILENCE_DB = -38.0            # below peak + this = silence (cut points, pauses)
FLOW_SENTENCE_PAUSE_SEC = 0.38     # silence after a finished sentence (inside and between groups)
FLOW_LEAD_SEC = 0.08               # silence kept before a group's first word
FLOW_TAIL_SEC = 0.30               # silence kept after the last word of a group

# Audience-address particles (user preference, same rule as VoxCPM V2 recap_planner): ခင်ဗျာ/ခင်ဗျ
# always go; ရှင်/ရှင့် only right after a sentence-final particle (ရုပ်ရှင် / ရှင်ဘုရင် stay).
_ADDRESS_KHINBYA_RE = re.compile(r"\s*ခင်ဗျာ?(?=\s*(?:[။!?၊,…]|$))")
_ADDRESS_SHIN_RE = re.compile(r"(တယ်|ပါ|ပြီ|မယ်|ဘူး|လား|နော်|လေ|ပေါ့)\s*ရှင့?်(?=\s*(?:[။!?၊,…]|$))")


def _strip_address_particles(text):
    text = _ADDRESS_KHINBYA_RE.sub("", str(text or ""))
    return " ".join(_ADDRESS_SHIN_RE.sub(r"\1", text).split())


def _languages():
    """app/languages.py (shared with the Studio UI)."""
    app_dir = str(Path(__file__).resolve().parents[1])
    if app_dir not in sys.path:
        sys.path.insert(0, app_dir)
    import languages
    return languages


def _language_script_issues(text, code):
    """Letters from a script the language does not use (Chinese or Burmese inside English
    narration, Lao inside Thai, ...), invisible or replacement characters."""
    import unicodedata
    langs = _languages()
    issues = []
    for pos, ch in enumerate(str(text or "")):
        cp = ord(ch)
        if ch in "\n\r\t " or ch == "﻿" or ch.isascii() or langs.in_script(ch, code):
            continue
        bidi_ok = code == "ar" and cp in (0x200E, 0x200F)
        if unicodedata.category(ch)[0] in ("P", "Z", "S") and cp not in (0x200B, 0xFFFD) \
                and not (0x202A <= cp <= 0x202E or 0x2066 <= cp <= 0x2069) or bidi_ok:
            continue
        issues.append({"pos": pos, "char": ch, "codepoint": f"U+{cp:04X}", "name": unicodedata.name(ch, "UNKNOWN")})
    return issues
SMART_SYNC_MAX_SPEED_V44 = 1.50
SMART_SYNC_MAX_SLOW_DURATION_V44 = 1.35
SMART_SYNC_TARGET_SLOW_DURATION_V45 = 1.20
SMART_SYNC_ALLOW_FREEZE_V45 = False


def _smart_sync_max_slow_for_block_v462(block, source_duration):
    """Dynamic no-freeze slowdown allowance for short transcript anchors.

    The old production-wide 1.35x duration cap is fine for normal/visual windows, but
    tiny Whisper dialogue timestamps (often ~1s) need a little more local retime to
    fit even a very compact Burmese narrator sentence. This only slows the exact
    transcript video slice; it does NOT steal time from the following VISUAL_GAP and
    it never creates a frozen frame.
    """
    kind = str((block or {}).get("unit_kind") or "")
    d = max(0.03, float(source_duration or 0.0))

    if kind == "DIALOGUE_ANCHOR":
        if d <= 1.50:
            return 1.80
        if d <= 2.50:
            return 1.60
        if d <= 4.00:
            return 1.45
        return SMART_SYNC_MAX_SLOW_DURATION_V44

    if kind == "DIALOGUE_PLUS_ZERO_GAP_VISUAL":
        if d <= 1.50:
            return 1.65
        if d <= 2.50:
            return 1.50
        return SMART_SYNC_MAX_SLOW_DURATION_V44

    if kind == "VISUAL_GAP":
        # Very short action gaps also need a little absolute room; otherwise a valid
        # one-sentence visual narration can be impossible to fit without freezing.
        # Keep this lower than dialogue-anchor allowance so action motion stays natural.
        if d <= 1.50:
            return 1.65
        if d <= 2.50:
            return 1.50
        if d <= 4.00:
            return 1.40
        return SMART_SYNC_MAX_SLOW_DURATION_V44

    return SMART_SYNC_MAX_SLOW_DURATION_V44


def _timeline_item_end(item):
    if item.get("kind") == "event":
        return float(item.get("file_end_sec", item.get("file_start_sec", 0.0)) or 0.0)
    return float(item.get("file_start_sec", 0.0) or 0.0)



ANCHOR_NARRATION_SCHEMA_V46 = {
    "type": "object",
    "properties": {
        "anchors": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "anchor_id": {"type": "string"},
                    "dialogue_text": {"type": "string"},
                    "visual_text": {"type": "string"},
                },
                "required": ["anchor_id", "dialogue_text", "visual_text"],
            },
        }
    },
    "required": ["anchors"],
}

ANCHOR_AUDIT_SCHEMA_V46 = {
    "type": "object",
    "properties": {
        "anchors": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "anchor_id": {"type": "string"},
                    "dialogue_ok": {"type": "boolean"},
                    "visual_ok": {"type": "boolean"},
                    "missing_item_ids": {"type": "array", "items": {"type": "string"}},
                    "misplaced_claims": {"type": "array", "items": {"type": "string"}},
                    "unsupported_claims": {"type": "array", "items": {"type": "string"}},
                },
                "required": [
                    "anchor_id", "dialogue_ok", "visual_ok",
                    "missing_item_ids", "misplaced_claims", "unsupported_claims"
                ],
            },
        }
    },
    "required": ["anchors"],
}


def _enrich_dialogue_with_whisper_bounds(dialogue_rows, completed_files):
    """Use Whisper's real segment start/end as the hard dialogue anchors.

    Gemini's dialogue time_sec is useful for semantics, but final A/V sync must use the
    actual Whisper transcript timestamps the user sees in the transcript.
    """
    file_offsets = {}
    offset = 0.0
    segment_map = {}
    for item in completed_files:
        name = item["src"].name
        file_offsets[name] = offset
        for idx, seg in enumerate(item.get("segments") or []):
            segment_map[(name, int(idx))] = seg
        offset += float(item.get("duration") or 0.0)

    for row in dialogue_rows:
        name = str(row.get("source_file") or "")
        try:
            idx = int(row.get("transcript_index"))
        except Exception:
            continue
        seg = segment_map.get((name, idx))
        if not seg:
            continue
        s = float(seg.get("start", row.get("file_start_sec", 0.0)) or 0.0)
        e = float(seg.get("end", s) or s)
        if e < s:
            e = s
        row["file_start_sec"] = s
        row["file_end_sec"] = e
        row["global_start_sec"] = float(file_offsets.get(name, 0.0)) + s
        row["global_end_sec"] = float(file_offsets.get(name, 0.0)) + e
        row["whisper_anchor_start_sec"] = s
        row["whisper_anchor_end_sec"] = e
    return dialogue_rows


def _compact_anchor_evidence(item):
    if not item:
        return None
    keep = {
        "story_item_id": item.get("story_item_id"),
        "kind": item.get("kind"),
        "source_file": item.get("source_file"),
        "file_start_sec": item.get("file_start_sec"),
        "file_end_sec": item.get("file_end_sec"),
    }
    if item.get("kind") == "dialogue":
        keep.update({
            "transcript_index": item.get("transcript_index"),
            "speaker": item.get("speaker"),
            "source_text": item.get("source_text"),
            "meaning": item.get("meaning"),
            "confidence": item.get("confidence"),
        })
    else:
        keep.update({
            "actors": item.get("actors"),
            "action": item.get("action"),
            "targets": item.get("targets"),
            "object": item.get("object"),
            "location": item.get("location"),
            "confidence": item.get("confidence"),
            "uncertainty": item.get("uncertainty"),
        })
    return keep


def _build_transcript_anchor_specs_v46(timeline, completed_files):
    """Build hard Whisper dialogue windows plus true between-dialogue visual gaps.

    V5.0 fixes the old drift bug: an event that occurs INSIDE a Whisper [start,end]
    is kept in that dialogue window; only events whose midpoint occurs AFTER the
    Whisper end and BEFORE the next Whisper start belong to VISUAL_GAP.
    """
    durations = {x["src"].name: float(x.get("duration") or 0.0) for x in completed_files}
    by_file = {}
    for item in timeline:
        by_file.setdefault(str(item.get("source_file") or ""), []).append(item)

    specs = []
    seq = 1
    for file_item in completed_files:
        name = file_item["src"].name
        duration = durations[name]
        rows = by_file.get(name, [])
        dialogues = sorted(
            [x for x in rows if x.get("kind") == "dialogue"],
            key=lambda x: (float(x.get("file_start_sec", 0.0)), int(x.get("transcript_index", -1))),
        )
        events = sorted(
            [x for x in rows if x.get("kind") == "event"],
            key=lambda x: (float(x.get("file_start_sec", 0.0)), float(x.get("file_end_sec", 0.0))),
        )

        def ev_mid(ev):
            a = float(ev.get("file_start_sec", 0.0) or 0.0)
            b = float(ev.get("file_end_sec", a) or a)
            return (a + max(a, b)) / 2.0

        if not dialogues:
            if events:
                specs.append({
                    "anchor_id": f"A{seq:05d}", "source_file": name, "anchor_kind": "visual_only",
                    "transcript_index": None, "dialogue_item": None, "dialogue_visual_items": [],
                    "visual_items": events, "dialogue_start_sec": None, "dialogue_end_sec": None,
                    "visual_start_sec": 0.0, "visual_end_sec": duration,
                })
                seq += 1
            continue

        first_start = max(0.0, float(dialogues[0].get("file_start_sec", 0.0) or 0.0))
        leading = [e for e in events if ev_mid(e) < first_start - 1e-6]
        if leading:
            specs.append({
                "anchor_id": f"A{seq:05d}", "source_file": name, "anchor_kind": "visual_only",
                "transcript_index": None, "dialogue_item": None, "dialogue_visual_items": [],
                "visual_items": leading, "dialogue_start_sec": None, "dialogue_end_sec": None,
                "visual_start_sec": 0.0, "visual_end_sec": first_start,
            })
            seq += 1

        assigned = {str(e.get("story_item_id")) for e in leading}
        for i, d in enumerate(dialogues):
            d_start = max(0.0, float(d.get("file_start_sec", 0.0) or 0.0))
            raw_d_end = max(d_start, float(d.get("file_end_sec", d_start) or d_start))
            next_start_raw = (
                max(0.0, float(dialogues[i + 1].get("file_start_sec", duration) or duration))
                if i + 1 < len(dialogues) else duration
            )
            # Whisper start/end are hard. If Whisper segments overlap, current dialogue ends
            # at the next dialogue start to avoid duplicate source frames.
            d_end = min(raw_d_end, next_start_raw) if next_start_raw >= d_start else raw_d_end
            d_end = max(d_start + 0.03, min(duration, d_end))
            next_start = max(d_end, min(duration, next_start_raw))

            inside = []
            gap = []
            for ev in events:
                sid = str(ev.get("story_item_id") or "")
                if not sid or sid in assigned:
                    continue
                t = ev_mid(ev)
                if d_start - 1e-6 <= t < d_end - 1e-6:
                    inside.append(ev)
                    assigned.add(sid)
                elif d_end - 1e-6 <= t < next_start - 1e-6:
                    gap.append(ev)
                    assigned.add(sid)

            specs.append({
                "anchor_id": f"A{seq:05d}", "source_file": name, "anchor_kind": "dialogue_anchor",
                "transcript_index": int(d.get("transcript_index", -1)), "dialogue_item": d,
                "dialogue_visual_items": inside, "visual_items": gap,
                "dialogue_start_sec": d_start, "dialogue_end_sec": d_end,
                "raw_dialogue_end_sec": raw_d_end, "visual_start_sec": d_end,
                "visual_end_sec": next_start, "next_dialogue_start_sec": next_start,
            })
            seq += 1

        # Any unassigned event is placed by real timestamp, never by nearest dialogue guess.
        leftovers = [e for e in events if str(e.get("story_item_id") or "") not in assigned]
        for ev in leftovers:
            t = ev_mid(ev)
            # Prefer a dialogue containing the event midpoint.
            chosen = None
            for sp in specs:
                if sp.get("source_file") != name or sp.get("anchor_kind") != "dialogue_anchor":
                    continue
                ds = float(sp.get("dialogue_start_sec") or 0.0)
                de = float(sp.get("dialogue_end_sec") or ds)
                vs = float(sp.get("visual_start_sec") or de)
                ve = float(sp.get("visual_end_sec") or vs)
                if ds <= t < de:
                    sp.setdefault("dialogue_visual_items", []).append(ev); chosen = sp; break
                if vs <= t < ve:
                    sp.setdefault("visual_items", []).append(ev); chosen = sp; break
            if chosen is None:
                # trailing event after final transcript: attach to final visual gap only.
                cands = [sp for sp in specs if sp.get("source_file") == name and sp.get("anchor_kind") == "dialogue_anchor"]
                if cands:
                    cands[-1].setdefault("visual_items", []).append(ev)
            assigned.add(str(ev.get("story_item_id") or ""))

    return specs



STORY_ALIGNMENT_SCHEMA_V501 = {
    "type": "object",
    "properties": {
        "units": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "text": {"type": "string"},
                },
                "required": ["text"],
            },
        }
    },
    "required": ["units"],
}


def _norm_story_exact_v47(text):
    return re.sub(r"\s+", "", str(text or "")).strip()


def _build_story_preserving_sync_units_v47(
    pool, timeline, completed_files, story_cache_dir, align_cache_dir
):
    """Keep verified FULL_STORYTELLING prose unchanged; Gemini aligns only."""
    import hashlib

    align_cache_dir.mkdir(parents=True, exist_ok=True)
    specs = _build_transcript_anchor_specs_v46(timeline, completed_files)
    spec_by_id = {s["anchor_id"]: s for s in specs}

    id_target = {}
    for s in specs:
        d = s.get("dialogue_item")
        if d is not None:
            sid = str(d.get("story_item_id") or "")
            if sid:
                id_target[sid] = (s["anchor_id"], "DIALOGUE_ANCHOR")
        for ev in s.get("dialogue_visual_items") or []:
            sid = str(ev.get("story_item_id") or "")
            if sid:
                id_target[sid] = (s["anchor_id"], "DIALOGUE_ANCHOR")
        for ev in s.get("visual_items") or []:
            sid = str(ev.get("story_item_id") or "")
            if sid:
                id_target[sid] = (s["anchor_id"], "VISUAL_GAP")

    groups = _story_chunks(timeline)
    final_units = []
    seq = 1

    print("\n" + "=" * 78)
    print("V5.0.2 STORY-PRESERVING ALIGNMENT — DETERMINISTIC PYTHON + WHISPER HARD ANCHORS")
    print("=" * 78)

    for part_i, group in enumerate(groups, start=1):
        story_path = story_cache_dir / f"story_part_{part_i:03d}.json"
        if not story_path.exists():
            raise RuntimeError(f"Missing verified story cache: {story_path}")
        saved_story = load_json(story_path)
        story_text = str(saved_story.get("story_text") or "").strip()
        if not story_text:
            raise RuntimeError(f"Empty verified story cache: {story_path}")

        required_ids = [str(x.get("story_item_id") or "") for x in group]
        required_ids = [x for x in required_ids if x]
        required_set = set(required_ids)

        missing_targets = [sid for sid in required_ids if sid not in id_target]
        if missing_targets:
            raise RuntimeError(
                f"V4.7 alignment has no timing bucket for part {part_i}: {missing_targets[:12]}"
            )

        target_rows = []
        target_index = {}
        for sid in required_ids:
            key = id_target[sid]
            if key not in target_index:
                anchor_id, bucket = key
                spec = spec_by_id[anchor_id]
                if bucket == "DIALOGUE_ANCHOR":
                    evidence = [_compact_anchor_evidence(spec.get("dialogue_item"))]
                    evidence += [
                        _compact_anchor_evidence(x)
                        for x in (spec.get("dialogue_visual_items") or [])
                        if str(x.get("story_item_id") or "") in required_set
                    ]
                    window = [spec.get("dialogue_start_sec"), spec.get("dialogue_end_sec")]
                else:
                    evidence = [
                        _compact_anchor_evidence(x)
                        for x in (spec.get("visual_items") or [])
                        if str(x.get("story_item_id") or "") in required_set
                    ]
                    window = [spec.get("visual_start_sec"), spec.get("visual_end_sec")]
                target_index[key] = len(target_rows)
                target_rows.append({
                    "anchor_id": anchor_id,
                    "bucket": bucket,
                    "source_file": spec.get("source_file"),
                    "source_window": window,
                    "story_item_ids": [],
                    "evidence": evidence,
                })
            target_rows[target_index[key]]["story_item_ids"].append(sid)

        # V5.0.2: deterministic alignment. Gemini is NOT used here.
        # The canonical story is already verified and chronological; Python only partitions
        # its exact wording across the already-locked chronological timing targets.
        # This removes unit-count/ID/order failures caused by LLM alignment output.
        def _target_weight_v502(tr):
            ev_len = 0
            for ev in (tr.get("evidence") or []):
                if not isinstance(ev, dict):
                    continue
                for k in ("source_text", "meaning", "action", "object", "location", "actors", "targets"):
                    v = ev.get(k)
                    if v is None:
                        continue
                    if isinstance(v, (list, tuple)):
                        v = " ".join(str(x) for x in v if x is not None)
                    ev_len += len(re.sub(r"\s+", "", str(v)))
            try:
                a, z = tr.get("source_window") or [0.0, 0.0]
                dur = max(0.03, float(z or 0.0) - float(a or 0.0))
            except Exception:
                dur = 0.5
            # Evidence density is primary; source duration is only a mild stabilizer.
            return max(8.0, float(ev_len) + min(60.0, dur * 8.0))

        def _partition_exact_story_v502(text, targets):
            # Split only on whitespace; no character is rewritten or deleted.
            tokens = re.findall(r"\S+", str(text or ""))
            n = len(targets)
            if n <= 0:
                return []
            if len(tokens) < n:
                # Extremely unlikely for long-form narration. Fall back to character chunks
                # at Unicode-codepoint boundaries while still preserving exact non-whitespace text.
                compact = re.sub(r"\s+", "", str(text or ""))
                if len(compact) < n:
                    raise RuntimeError(
                        f"V5.0.2 deterministic alignment cannot create {n} non-empty units from "
                        f"only {len(compact)} non-whitespace characters"
                    )
                base, rem = divmod(len(compact), n)
                out = []
                pos = 0
                for i in range(n):
                    take = base + (1 if i < rem else 0)
                    out.append(compact[pos:pos + take])
                    pos += take
                return out

            weights = [_target_weight_v502(t) for t in targets]
            total_w = max(1e-9, sum(weights))
            cumulative = []
            c = 0.0
            for w in weights:
                c += w
                cumulative.append(c / total_w)

            # Natural boundary candidates: punctuation endings are preferred.
            punct = ("။", "၊", ".", "!", "?", "…", '"', "”", "’", ":", ";")
            natural = {i for i in range(1, len(tokens)) if tokens[i - 1].endswith(punct)}
            cuts = [0]
            for i in range(n - 1):
                min_cut = cuts[-1] + 1
                max_cut = len(tokens) - (n - i - 1)
                ideal = int(round(cumulative[i] * len(tokens)))
                ideal = max(min_cut, min(max_cut, ideal))

                # Prefer a punctuation/clause boundary close to the weighted ideal.
                nearby = [x for x in natural if min_cut <= x <= max_cut and abs(x - ideal) <= 6]
                if nearby:
                    cut = min(nearby, key=lambda x: (abs(x - ideal), x))
                else:
                    cut = ideal
                cuts.append(cut)
            cuts.append(len(tokens))

            pieces = []
            for i in range(n):
                piece = " ".join(tokens[cuts[i]:cuts[i + 1]]).strip()
                if not piece:
                    raise RuntimeError(f"V5.0.2 deterministic alignment produced empty unit {i + 1}/{n}")
                pieces.append(piece)
            if _norm_story_exact_v47(" ".join(pieces)) != _norm_story_exact_v47(text):
                raise RuntimeError("V5.0.2 deterministic alignment changed canonical story text")
            return pieces

        digest = hashlib.sha1(
            (
                "v502-deterministic-story-preserve|"
                + story_text
                + "|"
                + json.dumps(target_rows, ensure_ascii=False, sort_keys=True)
            ).encode("utf-8")
        ).hexdigest()[:16]
        cache_path = align_cache_dir / f"align_part_{part_i:03d}_{digest}.json"

        rows = None
        if cache_path.exists():
            try:
                cached = load_json(cache_path)
                candidate = cached.get("units") or []
                if (
                    len(candidate) == len(target_rows)
                    and cached.get("exact_story_preserved")
                    and cached.get("deterministic_python_alignment")
                    and _norm_story_exact_v47(" ".join(str(x.get("text") or "") for x in candidate))
                       == _norm_story_exact_v47(story_text)
                ):
                    rows = candidate
                    print(
                        f"  [ALIGN RESUME] part {part_i}/{len(groups)} | units={len(rows)} | "
                        "deterministic Python alignment"
                    )
            except Exception:
                pass

        if rows is None:
            pieces = _partition_exact_story_v502(story_text, target_rows)
            rows = []
            for tr, txt in zip(target_rows, pieces):
                rows.append({
                    "anchor_id": tr["anchor_id"],
                    "bucket": tr["bucket"],
                    "text": txt,
                    "story_item_ids": list(tr["story_item_ids"]),
                })
            save_json(cache_path, {
                "version": "v5.0.2-deterministic-story-preserving-alignment",
                "units": rows,
                "exact_story_preserved": True,
                "deterministic_python_alignment": True,
                "gemini_alignment_used": False,
            })
            print(
                f"  [ALIGN PASS] part {part_i}/{len(groups)} | units={len(rows)} | "
                "Python deterministic split | Gemini alignment OFF | canonical text unchanged"
            )

        merged = []
        for row in rows:
            key = (str(row.get("anchor_id") or ""), str(row.get("bucket") or ""))
            txt = str(row.get("text") or "").strip()
            ids = [str(x) for x in (row.get("story_item_ids") or []) if str(x)]
            if merged and (merged[-1]["anchor_id"], merged[-1]["bucket"]) == key:
                merged[-1]["text"] = (merged[-1]["text"].rstrip() + " " + txt).strip()
                merged[-1]["story_item_ids"].extend(ids)
            else:
                merged.append({
                    "anchor_id": key[0],
                    "bucket": key[1],
                    "text": txt,
                    "story_item_ids": list(ids),
                })

        for row in merged:
            spec = spec_by_id[row["anchor_id"]]
            if row["bucket"] == "DIALOGUE_ANCHOR":
                start = float(spec.get("dialogue_start_sec") or 0.0)
                end = float(spec.get("dialogue_end_sec") or start)
                kind = "DIALOGUE_ANCHOR"
            else:
                start = float(spec.get("visual_start_sec") or 0.0)
                end = float(spec.get("visual_end_sec") or start)
                kind = "VISUAL_GAP"

            if (
                kind == "VISUAL_GAP"
                and end - start < 0.18
                and final_units
                and final_units[-1].get("source_file") == spec.get("source_file")
                and final_units[-1].get("anchor_id") == row["anchor_id"]
            ):
                prev = final_units[-1]
                prev["unit_kind"] = "DIALOGUE_PLUS_ZERO_GAP_VISUAL"
                prev["narration_text"] = (
                    prev["narration_text"].rstrip() + " " + row["text"]
                ).strip()
                prev["story_item_ids"].extend(row["story_item_ids"])
                prev["preserve_story_text"] = True
                continue

            final_units.append({
                "sync_block_id": f"B{seq:04d}",
                "unit_kind": kind,
                "anchor_id": row["anchor_id"],
                "source_file": spec.get("source_file"),
                "source_start_sec": start,
                "source_end_sec": max(start + 0.03, end),
                "source_duration": max(0.03, end - start),
                "story_item_ids": row["story_item_ids"],
                "narration_text": row["text"],
                "preserve_story_text": True,
                "story_part": part_i,
            })
            seq += 1

    # V4.7.1: a visual-only narration cannot live in a near-zero source window.
    # Whisper segments can be contiguous (or overlap by a few frames), leaving a 0.03-0.10s
    # VISUAL_GAP even though the canonical story has a real action phrase assigned there.
    # Keep the canonical text unchanged and merge ONLY these unusably tiny visual windows
    # into the chronologically adjacent same-file unit. Prefer the previous unit because a
    # normal visual gap belongs after that dialogue; a leading visual-only unit merges forward.
    def _coalesce_tiny_visual_units_v471(units, min_visual_window=0.65):
        work = [dict(x) for x in units]
        merges = []
        i = 0
        while i < len(work):
            cur = work[i]
            start = float(cur.get("source_start_sec") or 0.0)
            end = float(cur.get("source_end_sec") or start)
            dur = max(0.0, end - start)
            if str(cur.get("unit_kind") or "") != "VISUAL_GAP" or dur >= min_visual_window:
                i += 1
                continue

            same_prev = i > 0 and work[i - 1].get("source_file") == cur.get("source_file")
            same_next = i + 1 < len(work) and work[i + 1].get("source_file") == cur.get("source_file")

            if same_prev:
                prev = work[i - 1]
                prev_start = float(prev.get("source_start_sec") or 0.0)
                prev_end = float(prev.get("source_end_sec") or prev_start)
                prev["source_end_sec"] = max(prev_end, end)
                prev["source_duration"] = max(0.03, float(prev["source_end_sec"]) - prev_start)
                prev["narration_text"] = (str(prev.get("narration_text") or "").rstrip() + " " + str(cur.get("narration_text") or "").lstrip()).strip()
                prev["story_item_ids"] = list(prev.get("story_item_ids") or []) + list(cur.get("story_item_ids") or [])
                prev["unit_kind"] = "DIALOGUE_PLUS_TINY_VISUAL" if str(prev.get("unit_kind") or "").startswith("DIALOGUE") else "MERGED_WITH_TINY_VISUAL"
                prev["preserve_story_text"] = True
                prev["tiny_visual_merged"] = True
                prev.setdefault("merged_sync_units", []).append(cur.get("sync_block_id"))
                merges.append((cur.get("sync_block_id"), prev.get("sync_block_id"), dur, "previous"))
                del work[i]
                i = max(0, i - 1)
                continue

            if same_next:
                nxt = work[i + 1]
                nxt_start = float(nxt.get("source_start_sec") or 0.0)
                nxt_end = float(nxt.get("source_end_sec") or nxt_start)
                nxt["source_start_sec"] = min(start, nxt_start)
                nxt["source_duration"] = max(0.03, nxt_end - float(nxt["source_start_sec"]))
                nxt["narration_text"] = (str(cur.get("narration_text") or "").rstrip() + " " + str(nxt.get("narration_text") or "").lstrip()).strip()
                nxt["story_item_ids"] = list(cur.get("story_item_ids") or []) + list(nxt.get("story_item_ids") or [])
                nxt["unit_kind"] = "LEADING_TINY_VISUAL_PLUS_" + str(nxt.get("unit_kind") or "UNIT")
                nxt["preserve_story_text"] = True
                nxt["tiny_visual_merged"] = True
                nxt.setdefault("merged_sync_units", []).insert(0, cur.get("sync_block_id"))
                merges.append((cur.get("sync_block_id"), nxt.get("sync_block_id"), dur, "next"))
                del work[i]
                continue

            # No same-file neighbor: keep it so validation can expose the real structural issue.
            i += 1

        for n, row in enumerate(work, start=1):
            row["sync_block_id"] = f"B{n:04d}"
            row["source_duration"] = max(
                0.03,
                float(row.get("source_end_sec") or 0.0) - float(row.get("source_start_sec") or 0.0),
            )

        if merges:
            print(f"  [V4.7.2 TINY VISUAL MERGE] merged {len(merges)} visual window(s) < {min_visual_window:.2f}s")
            for old_id, into_id, d, direction in merges[:12]:
                print(f"    {old_id} ({d:.3f}s) -> {direction} neighbor {into_id}")
            if len(merges) > 12:
                print(f"    ... +{len(merges) - 12} more")
        return work

    final_units = _coalesce_tiny_visual_units_v471(final_units)

    canonical_parts = []
    for part_i in range(1, len(groups) + 1):
        s = load_json(story_cache_dir / f"story_part_{part_i:03d}.json")
        canonical_parts.append(str(s.get("story_text") or "").strip())

    canonical_all = "\n\n".join(x for x in canonical_parts if x)
    aligned_all = " ".join(str(x.get("narration_text") or "").strip() for x in final_units)
    if _norm_story_exact_v47(aligned_all) != _norm_story_exact_v47(canonical_all):
        raise RuntimeError("V4.9 global alignment changed canonical story text")

    return final_units


def _validate_anchor_generation_v46(specs, generated):
    expected = [s["anchor_id"] for s in specs]
    got = [str(x.get("anchor_id") or "") for x in generated]
    problems = []
    if got != expected:
        problems.append(f"anchor order/id mismatch expected={expected[:6]} got={got[:6]}")
        return problems
    for spec, row in zip(specs, generated):
        dtext = str(row.get("dialogue_text") or "").strip()
        vtext = str(row.get("visual_text") or "").strip()
        if spec.get("dialogue_item") is None and dtext:
            problems.append(f"{spec['anchor_id']}: dialogue_text must be empty (no transcript anchor)")
        if spec.get("dialogue_item") is not None and not dtext:
            problems.append(f"{spec['anchor_id']}: dialogue_text missing")
        if not (spec.get("visual_items") or []) and vtext:
            problems.append(f"{spec['anchor_id']}: visual_text must be empty (no visual evidence)")
        if (spec.get("visual_items") or []) and not vtext:
            problems.append(f"{spec['anchor_id']}: visual_text missing despite visual evidence")
        for label, txt in (("dialogue", dtext), ("visual", vtext)):
            u = _story_text_unicode_issues(txt)
            st = _story_local_style_issues(txt)
            if u:
                problems.append(f"{spec['anchor_id']} {label}: foreign/corrupt unicode {u[:2]}")
            if st:
                problems.append(f"{spec['anchor_id']} {label}: style guard {st[:2]}")
    return problems


def _audit_anchor_batch_v46(pool, specs, generated):
    audit_input = []
    for spec, row in zip(specs, generated):
        audit_input.append({
            "anchor_id": spec["anchor_id"],
            "dialogue_evidence": _compact_anchor_evidence(spec.get("dialogue_item")),
            "visual_evidence": [_compact_anchor_evidence(x) for x in (spec.get("visual_items") or [])],
            "dialogue_text": str(row.get("dialogue_text") or "").strip(),
            "visual_text": str(row.get("visual_text") or "").strip(),
        })
    prompt = f"""
You are the STRICT TRANSCRIPT-ANCHOR / VISUAL-GAP auditor for a Burmese storytelling video.

ANCHORS TO AUDIT:
{json.dumps(audit_input, ensure_ascii=False)}

For EACH anchor independently:
- dialogue_text may represent ONLY dialogue_evidence. It must preserve that transcript turn's real meaning in natural spoken Burmese narrator style. It must NOT contain the later visual actions from visual_evidence.
- visual_text may represent ONLY visual_evidence assigned after that transcript anchor and before the next transcript anchor. It must NOT repeat the dialogue wording and must NOT borrow the next transcript's dialogue.
- Every supplied story_item_id must be semantically represented in its correct field.
- No invented names, relationships, objects, motives, actions, causes, results, or locations.
- Paraphrase is allowed; omission, bucket-swapping, or chronology changes are not.
- Empty evidence requires an empty corresponding text field.
Return one audit row for every anchor_id in the same order.
""".strip()
    return pool.generate_json(prompt, ANCHOR_AUDIT_SCHEMA_V46, temperature=0.0, max_output_tokens=16384)


def _build_transcript_anchor_plan_v46(pool, timeline, completed_files, registry, sync_cache_dir):
    """Gemini writes dialogue expansion and visual continuation separately per Whisper anchor."""
    import hashlib
    sync_cache_dir.mkdir(parents=True, exist_ok=True)
    specs = _build_transcript_anchor_specs_v46(timeline, completed_files)
    registry_text = json.dumps(_compact_registry(registry), ensure_ascii=False)
    final_plan = []

    print("\n" + "=" * 78)
    print("V4.6 TRANSCRIPT-ANCHOR + VISUAL-GAP NARRATION PASS")
    print("=" * 78)
    print("Rule: Whisper dialogue timestamp = hard anchor; following visual narration = separate gap unit")

    batch_size = 12
    for bi in range(0, len(specs), batch_size):
        batch = specs[bi:bi + batch_size]
        batch_no = bi // batch_size + 1
        payload = []
        for s in batch:
            payload.append({
                "anchor_id": s["anchor_id"],
                "source_file": s["source_file"],
                "transcript_index": s.get("transcript_index"),
                "dialogue_window": [s.get("dialogue_start_sec"), s.get("dialogue_end_sec")],
                "visual_gap_window": [s.get("visual_start_sec"), s.get("visual_end_sec")],
                "dialogue_evidence": _compact_anchor_evidence(s.get("dialogue_item")),
                "visual_evidence": [_compact_anchor_evidence(x) for x in (s.get("visual_items") or [])],
            })
        digest = hashlib.sha1(
            ("v46-anchor-gap|" + json.dumps(payload, ensure_ascii=False, sort_keys=True) + registry_text).encode("utf-8")
        ).hexdigest()[:14]
        cache_path = sync_cache_dir / f"anchor_batch_{batch_no:03d}_{digest}.json"
        if cache_path.exists():
            try:
                saved = load_json(cache_path)
                rows = saved.get("anchors") or []
                if not _validate_anchor_generation_v46(batch, rows) and saved.get("anchor_audit_pass"):
                    print(f"  [ANCHOR RESUME] batch {batch_no} | anchors={len(rows)}")
                    for spec, row in zip(batch, rows):
                        merged = dict(spec)
                        merged["dialogue_text"] = str(row.get("dialogue_text") or "").strip()
                        merged["visual_text"] = str(row.get("visual_text") or "").strip()
                        final_plan.append(merged)
                    continue
            except Exception:
                pass

        base_prompt = f"""
You are the FINAL ALIGNED BURMESE NARRATOR WRITER for a movie-storytelling video.

CHARACTER REGISTRY:
{registry_text}

ANCHOR EVIDENCE:
{json.dumps(payload, ensure_ascii=False)}

OUTPUT EXACTLY ONE row for every anchor_id, in the same order, with:
- dialogue_text
- visual_text

THIS DISTINCTION IS CRITICAL:
1) dialogue_text = ONLY the narration corresponding to the Whisper transcript timestamp.
   Example source dialogue: "ဟေ့ကောင် မင်းဘယ်သူလဲ"
   Good dialogue_text: "သူက ဟေ့ကောင် မင်းဘယ်သူလဲလို့ မေးလိုက်တယ်။"
   Do NOT place a later door push, punch, kneel, phone action, etc. in dialogue_text.

2) visual_text = ONLY the visual actions listed in visual_evidence that continue after that transcript anchor and before the next transcript anchor.
   Example visual continuation: "ပြီးတော့ တံခါးကို တွန်းဖွင့်ပြီး လက်သီးနဲ့ ထိုးလိုက်တယ်။"
   Do NOT repeat the dialogue and do NOT mention the next transcript early.

Then the renderer will do:
DIALOGUE source timestamp -> dialogue_text TTS -> local slow/fast retime
VISUAL GAP after that timestamp -> visual_text TTS -> local slow/fast retime
NEXT transcript timestamp -> next dialogue_text

STRICT WRITING RULES:
- Natural spoken Burmese movie/series recap narrator style; not formal prose, not subtitles, not a report.
- Preserve every dialogue meaning and every concrete visual action supplied. Do not omit or summarize away evidence.
- Keep each field reasonably compact because it must fit its own local source window at Thiha +28%.
- No invented facts, names, relationships, motives, objects, locations, or results.
- No audience greeting, intro, outro, CTA, English name in parentheses, or literary filler.
- Clean Burmese Unicode only; no Thai/Arabic/Khmer/CJK corruption.
- If dialogue_evidence is null, dialogue_text MUST be "".
- If visual_evidence is empty, visual_text MUST be "".
Return structured JSON only.
""".strip()

        feedback = ""
        accepted = None
        accepted_meta = {}
        for attempt in range(1, 4):
            prompt = base_prompt
            if feedback:
                prompt += "\n\nSTRICT REPAIR FEEDBACK:\n" + feedback + "\nRegenerate ALL anchors in this batch."
            data, model, key_tag = pool.generate_json(
                prompt, ANCHOR_NARRATION_SCHEMA_V46, temperature=0.08 if attempt == 1 else 0.03,
                max_output_tokens=24576,
            )
            rows = data.get("anchors") or []
            problems = _validate_anchor_generation_v46(batch, rows)
            if problems:
                feedback = "\n".join("- " + x for x in problems[:20])
                print(f"  [ANCHOR WRITE RETRY] batch {batch_no} attempt {attempt}/3 | {problems[0]}")
                continue

            audit, am, ak = _audit_anchor_batch_v46(pool, batch, rows)
            audit_rows = audit.get("anchors") or []
            audit_map = {str(x.get("anchor_id") or ""): x for x in audit_rows}
            bad = []
            for spec in batch:
                ar = audit_map.get(spec["anchor_id"])
                if not ar:
                    bad.append(f"{spec['anchor_id']}: auditor omitted anchor")
                    continue
                if not bool(ar.get("dialogue_ok")) or not bool(ar.get("visual_ok")):
                    bad.append(
                        f"{spec['anchor_id']}: dialogue_ok={ar.get('dialogue_ok')} visual_ok={ar.get('visual_ok')} "
                        f"missing={(ar.get('missing_item_ids') or [])[:6]} misplaced={(ar.get('misplaced_claims') or [])[:3]} "
                        f"unsupported={(ar.get('unsupported_claims') or [])[:3]}"
                    )
            if bad:
                feedback = "\n".join("- " + x for x in bad[:20])
                print(f"  [ANCHOR AUDIT RETRY] batch {batch_no} attempt {attempt}/3 | {bad[0]}")
                continue
            accepted = rows
            accepted_meta = {"writer_model": model, "writer_key": key_tag, "audit_model": am, "audit_key": ak}
            break

        if accepted is None:
            raise RuntimeError(f"V4.6 transcript-anchor plan failed batch {batch_no}: {feedback[:1000]}")

        save_json(cache_path, {
            "version": "v4.6-transcript-anchor-visual-gap",
            "anchors": accepted,
            "anchor_audit_pass": True,
            **accepted_meta,
        })
        print(f"  [ANCHOR PASS] batch {batch_no} | anchors={len(accepted)}")
        for spec, row in zip(batch, accepted):
            merged = dict(spec)
            merged["dialogue_text"] = str(row.get("dialogue_text") or "").strip()
            merged["visual_text"] = str(row.get("visual_text") or "").strip()
            final_plan.append(merged)

    return final_plan


def _anchor_plan_to_sync_units_v46(anchor_plan):
    """Create alternating DIALOGUE / VISUAL_GAP units. No midpoint boundaries."""
    units = []
    seq = 1
    for anchor in anchor_plan:
        source_file = anchor["source_file"]
        dtext = str(anchor.get("dialogue_text") or "").strip()
        vtext = str(anchor.get("visual_text") or "").strip()
        d_item = anchor.get("dialogue_item")
        visual_items = anchor.get("visual_items") or []

        if d_item is not None and dtext:
            ds = float(anchor.get("dialogue_start_sec") or 0.0)
            de = float(anchor.get("dialogue_end_sec") or ds)
            units.append({
                "sync_block_id": f"B{seq:04d}",
                "unit_kind": "DIALOGUE_ANCHOR",
                "anchor_id": anchor["anchor_id"],
                "source_file": source_file,
                "source_start_sec": ds,
                "source_end_sec": max(ds + 0.03, de),
                "source_duration": max(0.03, de - ds),
                "story_item_ids": [str(d_item.get("story_item_id"))],
                "narration_text": dtext,
                "transcript_index": anchor.get("transcript_index"),
            })
            seq += 1

        if visual_items and vtext:
            vs = float(anchor.get("visual_start_sec") or 0.0)
            ve = float(anchor.get("visual_end_sec") or vs)
            visual_ids = [str(x.get("story_item_id")) for x in visual_items]
            if ve - vs < 0.18 and units and units[-1].get("source_file") == source_file:
                # No usable visual gap exists. Keep chronology and the next transcript
                # boundary exact by merging the visual continuation into the immediately
                # preceding dialogue unit instead of fabricating/freeze-extending a gap.
                prev = units[-1]
                prev["unit_kind"] = "DIALOGUE_PLUS_ZERO_GAP_VISUAL"
                prev["narration_text"] = (prev["narration_text"].rstrip() + " " + vtext).strip()
                prev["story_item_ids"].extend(visual_ids)
                prev["source_end_sec"] = max(float(prev["source_end_sec"]), ve)
                prev["source_duration"] = max(0.03, float(prev["source_end_sec"]) - float(prev["source_start_sec"]))
                prev["zero_gap_visual_merged"] = True
            else:
                units.append({
                    "sync_block_id": f"B{seq:04d}",
                    "unit_kind": "VISUAL_GAP",
                    "anchor_id": anchor["anchor_id"],
                    "source_file": source_file,
                    "source_start_sec": vs,
                    "source_end_sec": max(vs + 0.03, ve),
                    "source_duration": max(0.03, ve - vs),
                    "story_item_ids": visual_ids,
                    "narration_text": vtext,
                    "transcript_index": anchor.get("transcript_index"),
                })
                seq += 1
    return units

def _validate_sync_split(group, blocks):
    required = [x["story_item_id"] for x in group]
    required_pos = {sid: i for i, sid in enumerate(required)}
    flat = []
    problems = []
    for bi, block in enumerate(blocks, start=1):
        ids = [str(x) for x in (block.get("story_item_ids") or [])]
        narration = (block.get("narration_text") or "").strip()
        if not ids:
            problems.append(f"block {bi} has no story_item_ids")
            continue
        if not narration:
            problems.append(f"block {bi} has empty narration_text")
        unknown = [x for x in ids if x not in required_pos]
        if unknown:
            problems.append(f"block {bi} has unknown IDs: {unknown[:8]}")
            continue
        pos = [required_pos[x] for x in ids]
        if pos != list(range(min(pos), max(pos) + 1)):
            problems.append(f"block {bi} IDs are not one contiguous timeline range")
        source_files = {str(group[required_pos[x]].get("source_file") or "") for x in ids}
        if len(source_files) != 1:
            problems.append(f"block {bi} mixes source files: {sorted(source_files)}")
        flat.extend(ids)
    if flat != required:
        missing = [x for x in required if x not in flat]
        dup = sorted({x for x in flat if flat.count(x) > 1})
        extra = [x for x in flat if x not in required_pos]
        problems.append(
            f"ID partition mismatch; missing={missing[:12]}, duplicates={dup[:12]}, extra={extra[:12]}"
        )
    return problems


def _split_verified_story_for_sync(pool, timeline, story_cache_dir, sync_cache_dir):
    """Split already-verified V4.3 narration into source-aligned blocks without rewriting it."""
    sync_cache_dir.mkdir(parents=True, exist_ok=True)
    groups = _story_chunks(timeline)
    id_map = {x["story_item_id"]: x for x in timeline}
    all_blocks = []

    print("\n" + "=" * 78)
    print("V4.4 SYNC-BLOCK PASS — PRESERVE VERIFIED NARRATOR TEXT")
    print("=" * 78)

    for i, group in enumerate(groups, start=1):
        story_path = story_cache_dir / f"story_part_{i:03d}.json"
        if not story_path.exists():
            raise RuntimeError(
                f"Missing verified V4.3 story cache: {story_path}. "
                "Run the same command once so the narrator story can be built/resumed."
            )
        story_saved = load_json(story_path)
        story_text = (story_saved.get("story_text") or "").strip()
        if not story_text:
            raise RuntimeError(f"Empty V4.3 story cache: {story_path}")

        cache_path = sync_cache_dir / f"sync_part_{i:03d}.json"
        required_ids = [x["story_item_id"] for x in group]
        if cache_path.exists():
            try:
                saved = load_json(cache_path)
                blocks = saved.get("blocks") or []
                problems = _validate_sync_split(group, blocks)
                joined_saved = "\n\n".join((b.get("narration_text") or "").strip() for b in blocks).strip()
                audit_saved = saved.get("coverage_audit") or {}
                saved_fidelity_ok = bool(audit_saved.get("evidence_fidelity_pass")) and not (audit_saved.get("unsupported_claims") or [])
                saved_text_clean = not _story_text_unicode_issues(joined_saved) and not _story_local_style_issues(joined_saved)
                if (
                    not problems
                    and saved.get("semantic_coverage_verified")
                    and saved_fidelity_ok
                    and saved_text_clean
                ):
                    print(f"  [SYNC RESUME] part {i}/{len(groups)} | blocks={len(blocks)}")
                    all_blocks.extend(blocks)
                    continue
            except Exception:
                pass

        evidence = json.dumps(group, ensure_ascii=False)
        base_prompt = f"""
You are the TIMING SPLITTER for a Burmese movie-storytelling video pipeline.

The STORY TEXT below has already passed semantic coverage and spoken-narrator-style audits.
DO NOT rewrite the story into a different style. DO NOT summarize it. DO NOT add new facts.
Your job is only to split this already-approved narration into smaller TTS/video-sync blocks and attach the correct contiguous story_item_ids to each block.

VERIFIED TIMELINE ITEMS FOR THIS STORY PART:
{evidence}

APPROVED NARRATOR STORY TEXT:
{story_text}

STRICT RULES:
- Every required story_item_id must appear EXACTLY ONCE across blocks, in the exact chronological order supplied.
- Each block must contain one contiguous range of story_item_ids. Never reorder IDs.
- Never mix two source_file values inside one block.
- narration_text across all blocks must preserve the approved story content and meaning. Split at natural sentence or clause boundaries; only tiny boundary punctuation/connector adjustments are allowed when needed for a clean split.
- Do not delete dialogue meaning, visual actions, names, objects, causes, uncertainty, or chronology already present.
- Do not introduce new intro/outro/CTA or new explanations.
- Prefer practical voiceover blocks: usually about 6–16 seconds of source-time evidence or roughly 3–8 timeline items. A dense conversation should use a smaller time span so narration stays locally aligned with the video.
- Avoid a one-item block unless a major scene boundary or source-file boundary makes it necessary.
- Keep spoken Burmese narrator rhythm suitable for TTS.
- Preserve clean Unicode exactly. NEVER introduce Thai, Arabic, Khmer, CJK, replacement characters, or any other unrelated script into narration_text. Burmese text must remain Burmese; ordinary ASCII English is allowed only when already present/required.
- Do not invent or change any proper name while splitting. If a name is not present in the approved story/evidence, never add it.

Return only structured JSON with blocks[].story_item_ids and blocks[].narration_text.
""".strip()

        final = None
        last_problems = []
        for attempt in range(1, 4):
            prompt = base_prompt
            if last_problems:
                prompt += "\n\nREPAIR THESE STRUCTURAL ERRORS:\n- " + "\n- ".join(last_problems)
                prompt += "\nRegenerate the complete block split for this part."
            data, model, key_tag = pool.generate_json(
                prompt, SYNC_SPLIT_SCHEMA, temperature=0.05, max_output_tokens=32768
            )
            blocks = data.get("blocks") or []
            problems = _validate_sync_split(group, blocks)
            if problems:
                print(f"  [SYNC SPLIT RETRY] part {i} attempt {attempt}/3 | {problems[0]}")
                last_problems = problems
                continue

            joined = "\n\n".join((b.get("narration_text") or "").strip() for b in blocks).strip()
            audit, am, ak = _audit_story_coverage(pool, group, joined)
            audit_covered, audit_missing = _normalize_audit(required_ids, audit)
            style_ok = bool(audit.get("narrator_style_pass"))
            fidelity_ok = bool(audit.get("evidence_fidelity_pass")) and not (audit.get("unsupported_claims") or [])
            unicode_issues = _story_text_unicode_issues(joined)
            local_style_issues = _story_local_style_issues(joined)
            if audit_missing or not style_ok or not fidelity_ok or unicode_issues or local_style_issues:
                style_v = audit.get("style_violations") or []
                unsupported = audit.get("unsupported_claims") or []
                last_problems = []
                if audit_missing:
                    last_problems.append(f"semantic audit missing IDs: {audit_missing[:20]}")
                if not style_ok:
                    last_problems.append(f"narrator style audit failed: {style_v[:8]}")
                if not fidelity_ok:
                    last_problems.append(f"unsupported/invented claims: {unsupported[:8]}")
                if unicode_issues:
                    last_problems.append(f"foreign/corrupt Unicode: {unicode_issues[:8]}")
                if local_style_issues:
                    last_problems.append(f"local style issues: {local_style_issues[:8]}")
                print(
                    f"  [SYNC AUDIT RETRY] part {i} attempt {attempt}/3 | "
                    f"coverage={len(audit_covered)}/{len(required_ids)} | "
                    f"style={'PASS' if style_ok else 'FAIL'} | fidelity={'PASS' if fidelity_ok else 'FAIL'}"
                )
                continue

            local_block_problems = _audit_sync_blocks_locally(pool, blocks, group, id_map)
            if local_block_problems:
                last_problems = local_block_problems
                print(
                    f"  [SYNC LOCAL ALIGN RETRY] part {i} attempt {attempt}/3 | "
                    f"{local_block_problems[0]}"
                )
                continue

            for b in blocks:
                ids = b["story_item_ids"]
                items = [id_map[x] for x in ids]
                b["source_file"] = str(items[0].get("source_file") or "")
                b["first_story_item_id"] = ids[0]
                b["last_story_item_id"] = ids[-1]
                b["anchor_start_sec"] = min(float(x.get("file_start_sec", 0.0) or 0.0) for x in items)
                b["anchor_end_sec"] = max(_timeline_item_end(x) for x in items)

            data["semantic_coverage_verified"] = True
            data["coverage_audit"] = audit
            data["split_model"] = model
            data["split_key"] = key_tag
            data["audit_model"] = am
            data["audit_key"] = ak
            save_json(cache_path, data)
            print(
                f"  [SYNC PASS] part {i}/{len(groups)} | blocks={len(blocks)} | "
                f"coverage={len(required_ids)}/{len(required_ids)} | {model} {key_tag}"
            )
            final = blocks
            break

        if final is None:
            raise RuntimeError(f"Could not produce a valid sync split for story part {i}: {last_problems}")
        all_blocks.extend(final)

    return all_blocks


def _assign_continuous_source_ranges(sync_blocks, completed_files):
    """Turn evidence anchors into continuous per-file source ranges with no gaps/overlaps."""
    by_name = {item["src"].name: item for item in completed_files}
    result = [dict(b) for b in sync_blocks]
    per_file = {}
    for idx, block in enumerate(result):
        per_file.setdefault(block["source_file"], []).append((idx, block))

    for source_file, rows in per_file.items():
        if source_file not in by_name:
            raise RuntimeError(f"Sync block refers to missing source file: {source_file}")
        duration = float(by_name[source_file]["duration"])
        rows.sort(key=lambda t: float(t[1].get("anchor_start_sec", 0.0)))
        boundaries = [0.0]
        for j in range(len(rows) - 1):
            cur = rows[j][1]
            nxt = rows[j + 1][1]
            left = float(cur.get("anchor_end_sec", cur.get("anchor_start_sec", 0.0)) or 0.0)
            right = float(nxt.get("anchor_start_sec", left) or left)
            if right > left:
                boundary = (left + right) / 2.0
            else:
                boundary = max(float(cur.get("anchor_start_sec", 0.0)), right)
            boundary = max(boundaries[-1] + 0.05, min(duration, boundary))
            boundaries.append(boundary)
        boundaries.append(duration)

        for j, (idx, block) in enumerate(rows):
            start = max(0.0, min(duration, boundaries[j]))
            end = max(start + 0.05, min(duration, boundaries[j + 1]))
            if j == len(rows) - 1:
                end = duration
            result[idx]["source_start_sec"] = start
            result[idx]["source_end_sec"] = end
            result[idx]["source_duration"] = max(0.05, end - start)

    # Preserve story order, which is already chronological globally.
    for n, block in enumerate(result, start=1):
        block["sync_block_id"] = f"B{n:04d}"
    return result


def _edge_tts_generate(text, mp3_path, voice=EDGE_TTS_VOICE_V44, rate=EDGE_TTS_RATE_V44):
    import os
    import subprocess
    mp3_path.parent.mkdir(parents=True, exist_ok=True)
    clean = (text or "").strip()
    if not clean:
        raise ValueError("Edge TTS text is empty")
    env = dict(os.environ)
    # Gemini needs the local proxy, Edge TTS should connect directly.
    # Keep external VPN / OS proxy variables unchanged.
    text_path = mp3_path.with_suffix(".txt")
    text_path.write_text(clean, encoding="utf-8")
    cmd = [
        sys.executable, "-m", "edge_tts",
        "--voice", voice,
        "--rate", rate,
        "--file", str(text_path),
        "--write-media", str(mp3_path),
    ]
    errors = []
    attempts = 4  # Studio: several blocks run at once, so ride out short Edge TTS throttling
    for attempt in range(1, attempts + 1):
        p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore", env=env,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if p.returncode == 0 and mp3_path.exists() and mp3_path.stat().st_size > 1000:
            return
        errors.append((p.stderr or p.stdout or "").strip()[-1200:])
        time.sleep(2.0 * attempt)
    raise RuntimeError(f"Edge TTS generation failed after {attempts} attempts:\n" + "\n".join(errors))


def _edge_tts_generate_master_with_boundaries(text, mp3_path, boundary_json_path, voice=EDGE_TTS_VOICE_V44, rate=EDGE_TTS_RATE_V44):
    """Generate ONE continuous Edge-TTS master and collect WordBoundary timings.

    This removes the ~0.8s pause introduced when dozens of independent Edge clips are concatenated.
    """
    import asyncio
    import os
    mp3_path.parent.mkdir(parents=True, exist_ok=True)
    clean = (text or "").strip()
    if not clean:
        raise ValueError("Edge TTS master text is empty")

    # Reuse only when both media and boundary metadata exist.
    if mp3_path.exists() and mp3_path.stat().st_size > 1000 and boundary_json_path.exists():
        try:
            return load_json(boundary_json_path)
        except Exception:
            pass

    old_proxy = {k: os.environ.get(k) for k in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy")}
    # Preserve the external network configuration during voice requests.

    async def _run():
        import edge_tts
        comm = edge_tts.Communicate(clean, voice, rate=rate)
        bounds = []
        with open(mp3_path, "wb") as f:
            async for chunk in comm.stream():
                typ = str(chunk.get("type") or "")
                if typ == "audio":
                    f.write(chunk["data"])
                elif typ == "WordBoundary":
                    bounds.append({
                        "offset_sec": float(chunk.get("offset") or 0) / 10_000_000.0,
                        "duration_sec": float(chunk.get("duration") or 0) / 10_000_000.0,
                        "text": str(chunk.get("text") or ""),
                    })
        return bounds

    try:
        bounds = asyncio.run(_run())
    finally:
        for k, v in old_proxy.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v

    if not mp3_path.exists() or mp3_path.stat().st_size < 1000:
        raise RuntimeError("Continuous Edge-TTS master generation produced no audio")
    save_json(boundary_json_path, bounds)
    return bounds


def _tts_norm_for_boundary_map(text):
    import unicodedata
    out = []
    for ch in str(text or ""):
        cat = unicodedata.category(ch)
        if ch.isspace() or cat.startswith("P") or cat.startswith("Z"):
            continue
        out.append(ch.lower())
    return "".join(out)


def _measure_block_tts_durations_v604(sync_blocks, cache_root, voice=EDGE_TTS_VOICE_V44, rate=EDGE_TTS_RATE_V44):
    """Measure real spoken duration of each narration block for timing only.

    Final audio remains ONE continuous Edge-TTS master. These probe clips are never
    concatenated into the soundtrack. They only replace the inaccurate character-count
    fallback when Burmese Edge-TTS returns no WordBoundary metadata.
    """
    import hashlib
    cache_root = Path(cache_root)
    cache_root.mkdir(parents=True, exist_ok=True)
    durations = []
    for i, block in enumerate(sync_blocks, start=1):
        text = str(block.get("narration_text") or "").strip()
        if not text:
            durations.append(0.05)
            continue
        h = hashlib.sha1((text + "|" + voice + "|" + rate + "|v604-measure-only").encode("utf-8")).hexdigest()[:14]
        raw_mp3 = cache_root / f"m_{i:04d}_{h}.mp3"
        trim_m4a = cache_root / f"m_{i:04d}_{h}_trim.m4a"
        try:
            if not raw_mp3.exists() or raw_mp3.stat().st_size < 1000:
                _edge_tts_generate(text, raw_mp3, voice=voice, rate=rate)
            if not trim_m4a.exists() or trim_m4a.stat().st_size < 1000:
                run([
                    "ffmpeg", "-y", "-i", str(raw_mp3), "-vn",
                    "-af",
                    "silenceremove=start_periods=1:start_duration=0.01:start_threshold=-55dB:"
                    "start_silence=0.01:stop_periods=1:stop_duration=0.02:"
                    "stop_threshold=-55dB:stop_silence=0.01",
                    "-ar", "48000", "-ac", "2", "-c:a", "aac", "-b:a", "128k",
                    str(trim_m4a),
                ], quiet=True)
            d = float(ffprobe_duration(trim_m4a))
            if d <= 0.02:
                raise RuntimeError("empty measured TTS")
            durations.append(d)
        except Exception as exc:
            # Only a last-resort weight; never used as final audio.
            raise_if_terminal(exc)
            fallback = max(0.05, len(_tts_norm_for_boundary_map(text)) / 12.0)
            durations.append(fallback)
            print(f"    [V6.0.4 MEASURE FALLBACK] {block.get('sync_block_id', i)}: {exc}")
    return durations


def _master_audio_windows_for_blocks(sync_blocks, boundaries, master_duration, measured_durations=None):
    """Map canonical blocks onto the continuous TTS master.

    Prefer Edge WordBoundary metadata. Burmese voices may return none; in that case use
    real per-block TTS spoken durations as weights. Character counts are last resort only.
    """
    n = len(sync_blocks)
    if n == 0:
        return []
    master_duration = max(0.05, float(master_duration))
    if measured_durations and len(measured_durations) == n:
        weights = [max(0.05, float(x)) for x in measured_durations]
    else:
        weights = [max(1.0, float(len(_tts_norm_for_boundary_map(b.get("narration_text") or "")))) for b in sync_blocks]
    total_w = max(1e-9, sum(weights))

    usable = []
    cum = 0
    for b in boundaries or []:
        token = _tts_norm_for_boundary_map(b.get("text") or "")
        if not token:
            continue
        cum += len(token)
        usable.append((cum, float(b.get("offset_sec") or 0.0), float(b.get("duration_sec") or 0.0)))

    cuts = [0.0]
    target_cum = 0
    if usable and usable[-1][0] > 0:
        import bisect
        bcounts = [x[0] for x in usable]
        for i, w in enumerate(weights[:-1], start=1):
            target_cum += w
            target_boundary_chars = target_cum / total_w * bcounts[-1]
            j = bisect.bisect_left(bcounts, target_boundary_chars)
            # Cut at the next spoken word start so the natural pause stays with the previous block.
            next_j = min(len(usable) - 1, j + 1)
            cut = usable[next_j][1]
            cut = max(cuts[-1] + 0.02, min(master_duration - 0.02 * (n - i), cut))
            cuts.append(cut)
    else:
        running = 0
        for i, w in enumerate(weights[:-1], start=1):
            running += w
            cut = master_duration * (running / total_w)
            cut = max(cuts[-1] + 0.02, min(master_duration - 0.02 * (n - i), cut))
            cuts.append(cut)
    cuts.append(master_duration)

    windows = []
    for i in range(n):
        a, z = cuts[i], cuts[i + 1]
        windows.append((a, z, max(0.02, z - a)))
    return windows


def _probe_video_geometry(path):
    raw = subprocess.check_output([
        "ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height,r_frame_rate",
        "-of", "json", str(path)
    ], text=True, encoding="utf-8", errors="ignore")
    data = json.loads(raw)
    streams = data.get("streams") or []
    if not streams:
        raise RuntimeError(f"No video stream found: {path}")
    s = streams[0]
    w = int(s.get("width") or 1280)
    h = int(s.get("height") or 720)
    if w % 2: w -= 1
    if h % 2: h -= 1
    rate = str(s.get("r_frame_rate") or "30/1")
    try:
        a, b = rate.split("/", 1)
        fps = float(a) / max(1e-9, float(b))
    except Exception:
        fps = 30.0
    fps = max(12.0, min(60.0, fps))
    return w, h, fps


TIMING_FIT_UNIT_AUDIT_SCHEMA_V461 = {
    "type": "object",
    "properties": {
        "meaning_preserved": {"type": "boolean"},
        "correct_bucket": {"type": "boolean"},
        "narrator_style_pass": {"type": "boolean"},
        "evidence_fidelity_pass": {"type": "boolean"},
        "missing_item_ids": {"type": "array", "items": {"type": "string"}},
        "unsupported_claims": {"type": "array", "items": {"type": "string"}},
        "notes": {"type": "array", "items": {"type": "string"}},
    },
    "required": [
        "meaning_preserved", "correct_bucket", "narrator_style_pass",
        "evidence_fidelity_pass", "missing_item_ids",
        "unsupported_claims", "notes"
    ],
}


def _audit_timing_fit_unit_v461(pool, block, evidence_items, candidate_text):
    """Audit a compact timing-fit candidate using the V4.6 dialogue/visual bucket semantics.

    Do not reuse the long-form whole-story auditor here: tiny one-item transcript anchors
    were producing false coverage/style failures even though the anchor pass had already
    established the correct evidence bucket.
    """
    kind = str(block.get("unit_kind") or "")
    required_ids = [str(x) for x in (block.get("story_item_ids") or [])]
    evidence = json.dumps(evidence_items, ensure_ascii=False)
    prompt = f"""
You are the STRICT LOCAL TIMING-FIT AUDITOR for ONE already-aligned Burmese narration unit.

UNIT KIND: {kind}
REQUIRED STORY ITEM IDS: {json.dumps(required_ids, ensure_ascii=False)}
VERIFIED EVIDENCE FOR THIS UNIT ONLY:
{evidence}

CANDIDATE COMPACT NARRATION:
{candidate_text}

V4.6 BUCKET RULES:
- DIALOGUE_ANCHOR: candidate must preserve ONLY the transcript turn's real meaning. A concise natural sentence is valid coverage. Do NOT require the exact source wording. Do NOT require visual actions that belong after the dialogue timestamp.
- VISUAL_GAP: candidate must preserve the supplied concrete visual actions in chronological order. It must not invent or repeat the next dialogue.
- DIALOGUE_PLUS_ZERO_GAP_VISUAL: candidate must preserve both the transcript meaning first and the attached zero-gap visual actions after it.
- For a ONE-ITEM unit, meaning_preserved is TRUE when that one item's actual semantic meaning survives, even if the sentence is very short. Do not fail merely because it is concise.
- narrator_style_pass means natural spoken Burmese recap narration. A short one-sentence unit is allowed and should not fail merely for brevity.
- evidence_fidelity_pass must be FALSE for invented/changed names, people, objects, actions, motives, causes, results, locations, numbers, or dialogue meaning.
- correct_bucket must be FALSE if dialogue content was moved into a visual-only unit, or visual action was inserted into a dialogue-only unit.
- missing_item_ids must contain only required IDs whose actual meaning/action is absent.
Return structured JSON only.
""".strip()
    return pool.generate_json(
        prompt, TIMING_FIT_UNIT_AUDIT_SCHEMA_V461, temperature=0.0, max_output_tokens=4096
    )


def _timing_fit_rewrite(pool, block, evidence_items, narration, audio_duration, source_duration, attempt_no):
    """Compact one V4.6 sync unit without crossing dialogue/visual boundaries.

    The anchor/visual narration already passed the V4.6 bucket audit. This function only
    shortens it for real Thiha +28% timing, then uses a unit-specific audit with retries.
    """
    required_ids = [str(x) for x in (block.get("story_item_ids") or [])]
    unit_kind = str(block.get("unit_kind") or "UNKNOWN")
    target_seconds = max(0.50, float(source_duration) * SMART_SYNC_TARGET_SLOW_DURATION_V45)
    block_max_slow = _smart_sync_max_slow_for_block_v462(block, source_duration)
    hard_seconds = max(target_seconds, float(source_duration) * block_max_slow)
    ratio = min(0.98, max(0.35, target_seconds / max(0.05, float(audio_duration))))
    base_target_chars = max(18, int(len(narration) * ratio * 0.94))
    evidence = json.dumps(evidence_items, ensure_ascii=False)

    if unit_kind == "DIALOGUE_ANCHOR":
        bucket_rule = (
            "This is a DIALOGUE timestamp unit. Preserve only the actual transcript meaning. "
            "Do not add door/punch/kneel/phone/other visual actions here; those belong to VISUAL_GAP. "
            "Use the shortest natural narrator sentence that still says who said/asked/replied what."
        )
    elif unit_kind == "VISUAL_GAP":
        bucket_rule = (
            "This is a VISUAL_GAP unit. Preserve only the supplied visible actions, in order. "
            "Do not repeat the previous dialogue and do not borrow the next transcript."
        )
    else:
        bucket_rule = (
            "Preserve the transcript meaning first, then the attached zero-gap visual actions. "
            "Do not borrow anything from neighboring anchors."
        )

    feedback = ""
    last_diag = ""
    last_model = last_key = last_am = last_ak = ""

    # One render-level fit attempt gets up to three safe rewrite/audit tries. A single
    # auditor miss must not abort the entire multi-minute video render.
    for local_try in range(1, 4):
        target_chars = max(16, int(base_target_chars * (1.0 - 0.08 * (local_try - 1))))
        prompt = f"""
You are the TIMING-FIT REWRITER for ONE already-aligned Burmese movie-recap sync unit.

UNIT KIND: {unit_kind}
ASSIGNED VERIFIED TIMELINE ITEMS FOR THIS UNIT ONLY:
{evidence}

CURRENT VERIFIED NARRATION:
{narration}

REAL TTS TIMING AT my-MM-ThihaNeural +28%:
- source video window: {source_duration:.3f} seconds
- current narration audio: {audio_duration:.3f} seconds
- preferred narration ceiling: {target_seconds:.3f} seconds
- absolute no-freeze ceiling: {hard_seconds:.3f} seconds
- aim for roughly <= {target_chars} Burmese/ASCII characters if possible
- render fit attempt: {attempt_no}
- local safe rewrite try: {local_try}/3

CRITICAL BUCKET RULE:
{bucket_rule}

STRICT RULES:
- Rewrite ONLY this unit. Never pull facts from a neighboring timestamp.
- Preserve the meaning/action of EVERY required story_item_id.
- Be compact by removing filler, duplicate names, repeated connectors, and wordy framing; do not delete the actual evidence.
- Natural spoken Burmese movie/series recap narration, not formal prose and not a subtitle dump.
- No invented names, motives, relationships, objects, causes, locations, actions, results, intro/outro/CTA, or English name parentheses.
- Clean Unicode only; no Thai, Arabic, Khmer, CJK, replacement characters, or corrupted mixed script.
- covered_item_ids must contain exactly the required IDs.
""".strip()
        if feedback:
            prompt += "\n\nREPAIR FEEDBACK FROM THE PREVIOUS LOCAL AUDIT:\n" + feedback

        try:
            data, model, key_tag = pool.generate_json(
                prompt, STORY_OUTPUT_SCHEMA, temperature=0.05 if local_try == 1 else 0.02,
                max_output_tokens=4096
            )
            last_model, last_key = model, key_tag
        except Exception as exc:
            raise_if_terminal(exc)
            last_diag = f"writer error: {exc}"
            feedback = last_diag
            print(f"      [TIMING FIT WRITE RETRY] {block.get('sync_block_id')} local {local_try}/3 | {last_diag[:180]}")
            continue

        text = (data.get("story_text") or "").strip()
        declared = [str(x) for x in (data.get("covered_item_ids") or [])]
        if not text or set(declared) != set(required_ids) or len(declared) != len(required_ids):
            last_diag = (
                f"declaration mismatch required={required_ids} declared={declared} "
                f"text={'yes' if text else 'no'}"
            )
            feedback = last_diag
            print(f"      [TIMING FIT WRITE RETRY] {block.get('sync_block_id')} local {local_try}/3 | {last_diag}")
            continue

        unicode_issues = _story_text_unicode_issues(text)
        style_issues = _story_local_style_issues(text)
        if unicode_issues or style_issues:
            last_diag = f"local text guard unicode={unicode_issues[:2]} style={style_issues[:2]}"
            feedback = last_diag
            print(f"      [TIMING FIT TEXT RETRY] {block.get('sync_block_id')} local {local_try}/3 | {last_diag[:220]}")
            continue

        try:
            audit, am, ak = _audit_timing_fit_unit_v461(pool, block, evidence_items, text)
            last_am, last_ak = am, ak
        except Exception as exc:
            raise_if_terminal(exc)
            last_diag = f"auditor error: {exc}"
            feedback = last_diag
            print(f"      [TIMING FIT AUDIT RETRY] {block.get('sync_block_id')} local {local_try}/3 | {last_diag[:180]}")
            continue

        missing = [str(x) for x in (audit.get("missing_item_ids") or []) if str(x) in set(required_ids)]
        unsupported = audit.get("unsupported_claims") or []
        meaning_ok = bool(audit.get("meaning_preserved")) and not missing
        bucket_ok = bool(audit.get("correct_bucket"))
        style_ok = bool(audit.get("narrator_style_pass"))
        fidelity_ok = bool(audit.get("evidence_fidelity_pass")) and not unsupported

        if meaning_ok and bucket_ok and style_ok and fidelity_ok:
            if local_try > 1:
                print(
                    f"      [TIMING FIT AUDIT PASS] {block.get('sync_block_id')} local {local_try}/3 | "
                    f"kind={unit_kind} coverage={len(required_ids)}/{len(required_ids)}"
                )
            return text, model, key_tag, am, ak

        last_diag = (
            f"meaning={'PASS' if meaning_ok else 'FAIL'} "
            f"bucket={'PASS' if bucket_ok else 'FAIL'} "
            f"style={'PASS' if style_ok else 'FAIL'} "
            f"fidelity={'PASS' if fidelity_ok else 'FAIL'} "
            f"missing={missing[:6]} unsupported={unsupported[:3]} "
            f"notes={(audit.get('notes') or [])[:3]}"
        )
        feedback = (
            "The previous compact candidate failed this local audit: " + last_diag + ". "
            "Regenerate the SAME unit only. Keep every required meaning/action, stay in the correct dialogue/visual bucket, and make it concise spoken Burmese."
        )
        print(f"      [TIMING FIT AUDIT RETRY] {block.get('sync_block_id')} local {local_try}/3 | {last_diag[:260]}")

    # The original narration already passed the V4.6 anchor audit. If it is still inside
    # the absolute no-freeze limit, keep that verified original and let local video slow
    # down instead of crashing because a timing-fit rewrite/auditor was flaky.
    if float(audio_duration) <= hard_seconds + 0.08:
        print(
            f"      [TIMING FIT SAFE KEEP] {block.get('sync_block_id')} | "
            f"no safe compact rewrite after 3 tries; keeping verified original within hard limit. "
            f"last={last_diag[:180]}"
        )
        return narration, "KEEP_ORIGINAL_SAFE", "", last_am or "unit-audit", last_ak

    raise RuntimeError(
        f"timing-fit unit audit could not produce a safe compact rewrite for {block.get('sync_block_id')} "
        f"kind={unit_kind} ids={required_ids}: {last_diag}"
    )


def _audit_sync_blocks_locally(pool, blocks, group, id_map):
    """Verify each split block against only the evidence IDs attached to that block.

    Whole-part coverage alone can pass even when a sentence is attached to the wrong neighboring video window.
    """
    problems = []
    for bi, block in enumerate(blocks, start=1):
        ids = [str(x) for x in (block.get("story_item_ids") or [])]
        items = [id_map[x] for x in ids if x in id_map]
        text = (block.get("narration_text") or "").strip()
        if not items or not text:
            problems.append(f"block {bi}: missing items/text")
            continue
        audit, _, _ = _audit_story_coverage(pool, items, text)
        covered, missing = _normalize_audit(ids, audit)
        fidelity_ok = bool(audit.get("evidence_fidelity_pass")) and not (audit.get("unsupported_claims") or [])
        style_ok = bool(audit.get("narrator_style_pass"))
        if missing:
            problems.append(f"block {bi}: local coverage {len(covered)}/{len(ids)} missing={missing[:6]}")
        if not fidelity_ok:
            problems.append(f"block {bi}: local unsupported claims={(audit.get('unsupported_claims') or [])[:4]}")
        if not style_ok:
            problems.append(f"block {bi}: local narrator style fail={(audit.get('style_violations') or [])[:4]}")
    return problems


def _smart_sync_decision(source_duration, audio_duration, max_slow_duration=None):
    source_duration = max(0.05, float(source_duration))
    audio_duration = max(0.05, float(audio_duration))
    required_speed = source_duration / audio_duration
    max_slow_duration = float(max_slow_duration or SMART_SYNC_MAX_SLOW_DURATION_V44)
    max_slow_duration = max(1.0, max_slow_duration)
    min_speed = 1.0 / max_slow_duration
    if required_speed > SMART_SYNC_MAX_SPEED_V44:
        speed = SMART_SYNC_MAX_SPEED_V44
        adjusted = source_duration / speed
        return {
            "required_speed": required_speed,
            "video_speed": speed,
            "decision": "SPEED_MAX_TRIM",
            "trim_seconds": max(0.0, adjusted - audio_duration),
            "freeze_seconds": 0.0,
            "max_slow_duration_used": max_slow_duration,
        }
    if required_speed < min_speed:
        speed = min_speed
        adjusted = source_duration / speed
        return {
            "required_speed": required_speed,
            "video_speed": speed,
            "decision": "SLOW_MAX_FREEZE",
            "trim_seconds": 0.0,
            "freeze_seconds": max(0.0, audio_duration - adjusted),
            "max_slow_duration_used": max_slow_duration,
        }
    return {
        "required_speed": required_speed,
        "video_speed": required_speed,
        "decision": "RETIME_OK",
        "trim_seconds": 0.0,
        "freeze_seconds": 0.0,
        "max_slow_duration_used": max_slow_duration,
    }


def _ffconcat_line(path):
    return "file '" + str(Path(path).resolve()).replace("\\", "/").replace("'", "'\\''") + "'"


# V6.2 frame clock. The V4.1/V6.1 block rule is unchanged: every block shows exactly its own
# beat window, retimed to its own TTS (story text immutable, no audio pad/trim, no speed clamp).
# V6.1 let each block's frame rounding add up (-0.83s after 24 blocks on part_001, and
# -shortest then cut the end of the narration); V6.2 gives every block an exact frame count
# from the cumulative audio clock instead. A balanced +/-2s window plan was tried and
# rejected: moving block starts off their beats made the picture trail the narration.
SMART_SYNC_V62_TAIL_GUARD_SEC = 0.25    # last block's picture outlives the final TTS
SMART_SYNC_V62_MAX_BLOCK_AUDIO_SEC = 120.0   # one block's narration; real ones stay under 20 s (2026-10-04: a 22.7-min loop)
STUDIO_TTS_WORKERS = 4                  # Edge TTS blocks voiced at the same time
STUDIO_RENDER_WORKERS = 3               # ffmpeg block parts rendered at the same time
STUDIO_PART_ENCODER = "auto"            # auto = NVENC when the GPU has it (1.6x faster on RTX 3050), else libx264

_PART_CODEC_ARGS = {
    "h264_nvenc": ["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", "21", "-b:v", "0", "-profile:v", "high"],
    "libx264": ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20"],
}


def _pick_part_encoder(width, height):
    """NVENC if a tiny test encode at the real frame size works, else libx264."""
    if STUDIO_PART_ENCODER != "auto":
        return STUDIO_PART_ENCODER
    probe = subprocess.run(
        ["ffmpeg", "-v", "error", "-f", "lavfi", "-i", f"color=c=black:s={width}x{height}:r=30:d=0.2",
         *_PART_CODEC_ARGS["h264_nvenc"], "-pix_fmt", "yuv420p", "-f", "null", "-"],
        capture_output=True, text=True, encoding="utf-8", errors="ignore",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    return "h264_nvenc" if probe.returncode == 0 else "libx264"


def _probe_video_rate_v62(path):
    """Exact r_frame_rate as a Fraction (30000/1001 stays exact), same 12..60 clamp."""
    from fractions import Fraction
    raw = subprocess.check_output([
        "ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=r_frame_rate", "-of", "csv=p=0", str(path)
    ], text=True, encoding="utf-8", errors="ignore")
    try:
        num, den = raw.strip().splitlines()[0].split("/", 1)
        rate = Fraction(int(num), int(den))
    except Exception:
        rate = Fraction(30, 1)
    if not (12 <= rate <= 60):
        rate = Fraction(max(12.0, min(60.0, float(rate)))).limit_denominator(1001)
    return rate


def _probe_video_end_v62(path):
    """Where the source's picture stops (video stream start + duration), None when ffprobe cannot tell."""
    raw = subprocess.check_output([
        "ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=start_time,duration", "-of", "csv=p=0", str(path)
    ], text=True, encoding="utf-8", errors="ignore")
    try:
        start, dur = raw.strip().splitlines()[0].split(",")[:2]
        return float(start or 0) + float(dur)
    except Exception:
        return None


def _count_video_frames_v62(path):
    raw = subprocess.check_output([
        "ffprobe", "-v", "error", "-select_streams", "v:0", "-count_packets",
        "-show_entries", "stream=nb_read_packets", "-of", "csv=p=0", str(path)
    ], text=True, encoding="utf-8", errors="ignore")
    try:
        return int(raw.strip().splitlines()[0])
    except Exception:
        return -1


def _voxcpm_voice_blocks(jobs, root):
    """Studio: raw VoxCPM audio for these blocks over the Colab links (app/voxcpm_client.py).

    jobs: [(bid, narration, raw_path, wav_path)]. Progress uses the Edge TTS line format so
    the Studio's TTS stage/progress keeps working; per-link events go out as @@VOX@@ JSON.
    """
    import threading
    app_dir = str(Path(__file__).resolve().parents[1])
    if app_dir not in sys.path:
        sys.path.insert(0, app_dir)
    import voxcpm_client

    lock = threading.Lock()

    def emit(event):
        lines = ["@@VOX@@ " + json.dumps(event, ensure_ascii=False)]
        if "done" in event:
            lines.append(f"🗣️ [{event['count']}/{event['total']}] {event['done']} generate block TTS (VoxCPM link {event['link']})")
        with lock:
            sys.stdout.write("\n".join(lines) + "\n")
            sys.stdout.flush()

    cfg = VOXCPM_CONFIG
    links, per_link = cfg["links"], cfg["per_link"]
    need = voxcpm_client.required_links(len(jobs), per_link)
    print(f"🗣️ VoxCPM: {len(jobs)} block(s) to voice over {len(links)} Colab link(s) "
          f"({per_link} per link -> {need} needed)", flush=True)
    emit({"need": need, "blocks": len(jobs)})
    if need > len(links):
        print(f"⚠️ VoxCPM: only {len(links)} link(s) for {need} needed — this run voices up to "
              f"{len(links) * per_link} blocks; add links and START again for the rest", flush=True)
    voxcpm_client.generate_blocks(
        [(bid, narration, raw) for bid, narration, raw, _wav in jobs],
        links, cfg["voice"], Path(root) / "voxcpm_downloads", emit, per_link=per_link,
    )


def _voxcpm_block_wav(raw, wav, speed):
    """VoxCPM output -> the block's 48 kHz PCM WAV; speed via atempo (pitch kept), no pad/trim."""
    tempo = 1.0 + int(str(speed).rstrip("%")) / 100.0
    tempo_args = [] if abs(tempo - 1.0) < 1e-6 else ["-af", f"atempo={tempo:.4f}"]
    run([
        "ffmpeg", "-y", "-i", str(raw), "-vn", *tempo_args,
        "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", str(wav)
    ], quiet=True)


def _flow_sentence_end(text):
    t = str(text or "").strip().rstrip("\"'”’)」』")
    if not t or t[-1] in "။!?.。！？؟।…":
        return True
    if OUTPUT_LANGUAGE == "my":
        return t.endswith(("တယ်", "ပြီ", "မယ်", "ဘူး", "ပေါ့", "လေ", "လား"))
    return OUTPUT_LANGUAGE == "th"      # Thai writes no full stop; a block end is the only sentence cue


def _flow_groups(blocks):
    """Runs of consecutive blocks voiced as one utterance; a group closes on a sentence end."""
    groups, cur, size = [], [], 0
    for i, b in enumerate(blocks):
        if cur and str(b.get("source_file")) != str(blocks[cur[-1]].get("source_file")):
            groups.append(cur)
            cur, size = [], 0
        text = str(b.get("narration_text") or "").strip()
        cur.append(i)
        size += len(text.encode("utf-8")) + 1
        if (_flow_sentence_end(text) and (size >= FLOW_GROUP_TARGET_BYTES or len(cur) >= FLOW_GROUP_MAX_BLOCKS)) \
                or size >= FLOW_GROUP_HARD_BYTES:
            groups.append(cur)
            cur, size = [], 0
    if cur:
        groups.append(cur)
    return groups


def _edge_tts_words(text, mp3_path, words_path, voice, rate):
    """One Edge TTS utterance plus its WordBoundary timings (edge-tts sends them only when asked)."""
    import asyncio
    if mp3_path.exists() and mp3_path.stat().st_size >= 1000 and words_path.exists():
        try:
            return load_json(words_path)
        except Exception:
            pass

    async def _run():
        import edge_tts
        comm = edge_tts.Communicate(text, voice, rate=rate, boundary="WordBoundary")
        audio, words = bytearray(), []
        async for chunk in comm.stream():
            if chunk["type"] == "audio":
                audio += chunk["data"]
            elif chunk["type"] == "WordBoundary":
                start = chunk["offset"] / 1e7
                words.append({"start": start, "end": start + chunk["duration"] / 1e7, "text": chunk["text"]})
        return bytes(audio), words

    errors = []
    for attempt in range(1, 5):
        try:
            audio, words = asyncio.run(_run())
            if len(audio) < 1000 or not words:
                raise RuntimeError("no audio or no word timing")
            part = mp3_path.with_name(mp3_path.name + ".part")
            part.write_bytes(audio)
            part.replace(mp3_path)
            save_json(words_path, words)
            return words
        except Exception as exc:
            raise_if_terminal(exc)
            errors.append(str(exc)[:300])
            time.sleep(2.0 * attempt)
    raise RuntimeError("Edge TTS (flow group) failed after 4 attempts: " + " | ".join(errors))


def _edge_tts_block(text, mp3_path, words_path, voice, rate):
    """Classic block TTS together with its word timing, in the same request (2026-10-03: the Studio used to
    synthesize every block a second time only for the subtitle timing, ~11 min on a 2-hour video). Falls back
    to the plain edge-tts command (no timing) when the library call fails."""
    try:
        return _edge_tts_words(text, mp3_path, words_path, voice, rate)
    except Exception as exc:
        raise_if_terminal(exc)
        print(f"    [TTS] {mp3_path.name}: no word timing ({str(exc)[:80]}) -> plain TTS", flush=True)
        if not (mp3_path.exists() and mp3_path.stat().st_size >= 1000):
            _edge_tts_generate(text, mp3_path, voice=voice, rate=rate)
        return None


def _lead_silence_cut(mp3_path, threshold_db=-50.0, keep_sec=0.03):
    """Seconds --tts-pause trimming (silenceremove start_threshold=-50dB, start_silence=0.03) takes from the
    start of this audio: the first sound minus the 0.03 s that is kept."""
    import numpy as np
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", str(mp3_path), "-ac", "1", "-ar", "48000", "-f", "s16le", "-"],
                         capture_output=True, check=True).stdout
    pcm = np.abs(np.frombuffer(raw, np.int16).astype(np.int32))
    loud = np.nonzero(pcm > 32768 * 10 ** (threshold_db / 20.0))[0]
    return max(0.0, float(loud[0]) / 48000.0 - keep_sec) if loud.size else 0.0


def _block_wav_words(mp3_path, wav_path):
    """The block's word timing on its final WAV (subtitles; cached beside the WAV), or None without timing."""
    out = wav_path.with_suffix(".words.json")
    if out.exists():
        try:
            return load_json(out)
        except Exception:
            pass
    words_mp3 = mp3_path.with_suffix(".words.json")
    if not words_mp3.exists():
        return None
    words = load_json(words_mp3)
    cut = _lead_silence_cut(mp3_path) if TTS_PAUSE_SEC is not None else 0.0
    words = [{"start": round(max(0.0, w["start"] - cut), 3), "end": round(max(0.0, w["end"] - cut), 3), "text": w["text"]}
             for w in words]
    save_json(out, words)
    return words


def _write_pcm_wav(path, pcm, sr, channels):
    import wave
    part = Path(str(path) + ".part")
    with wave.open(str(part), "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(2)
        wf.setframerate(sr)
        wf.writeframes(pcm.astype("<i2").tobytes())
    part.replace(path)


def _flow_cut(group_wav, words, texts, sentence_ends):
    """Cut one group's 16-bit PCM WAV at each block's first word.

    The cut sits in the quietest 10 ms around the word gap. Silence before the first word is
    kept to FLOW_LEAD_SEC and after the last word to FLOW_TAIL_SEC; a block that finishes a
    sentence inside the group gets padded to FLOW_SENTENCE_PAUSE_SEC. Returns [(pcm, words)]
    with word times relative to each block's own audio.
    """
    import wave
    import numpy as np
    with wave.open(str(group_wav), "rb") as wf:
        sr, ch = wf.getframerate(), wf.getnchannels()
        pcm = np.frombuffer(wf.readframes(wf.getnframes()), dtype="<i2").reshape(-1, ch)
    joined = " ".join(texts)
    starts, acc = [], 0
    for t in texts:
        starts.append(acc)
        acc += len(t) + 1
    located, pos = [], 0
    for w in words:
        i = joined.find(w["text"], pos) if w.get("text") else -1
        located.append(i if i >= 0 else None)
        if i >= 0:
            pos = i + len(w["text"])
    first = []
    for bi, cs in enumerate(starts):
        nxt = starts[bi + 1] if bi + 1 < len(starts) else len(joined) + 1
        idx = next((k for k, p in enumerate(located) if p is not None and cs <= p < nxt), None)
        if idx is None or (first and idx <= first[-1]):
            raise RuntimeError(f"no word timing found for block {bi + 1} of the group")
        first.append(idx)
    win = max(1, sr // 100)
    level = np.abs(pcm.astype(np.int32)).max(axis=1)
    env = level[: len(level) // win * win].reshape(-1, win).max(axis=1)
    thr = env.max() * 10 ** (FLOW_SILENCE_DB / 20.0)
    loud = np.nonzero(env >= thr)[0]
    if not loud.size:
        raise RuntimeError("group audio is silent")
    total = len(pcm) / sr
    cuts = [max(0.0, loud[0] / 100.0 - FLOW_LEAD_SEC)]
    gaps = []
    for bi in range(1, len(texts)):
        w, pw = words[first[bi]], words[first[bi] - 1]
        lo, hi = sorted((pw["end"], w["start"]))
        a = max(0, int((lo - 0.03) * 100))
        b = min(len(env), int((hi + 0.03) * 100) + 1)
        quiet = np.nonzero(env[a:b] < thr)[0] if b > a else np.array([], dtype=int)
        if quiet.size:      # middle of the longest silent run: half the pause on each side
            runs = np.split(quiet, np.nonzero(np.diff(quiet) > 1)[0] + 1)
            longest = max(runs, key=len)
            k = a + int(longest[len(longest) // 2])
        else:
            k = a + int(np.argmin(env[a:b])) if b > a else int(w["start"] * 100)
        cuts.append(k / 100.0)
        left, right = k, k
        while left > 0 and env[left - 1] < thr:
            left -= 1
        while right < len(env) and env[right] < thr:
            right += 1
        gaps.append((right - left) / 100.0)
    cuts.append(min(total, (loud[-1] + 1) / 100.0 + FLOW_TAIL_SEC))
    pieces = []
    for bi in range(len(texts)):
        s, e = cuts[bi], cuts[bi + 1]
        seg = pcm[int(round(s * sr)): int(round(e * sr))]
        if bi + 1 < len(texts) and sentence_ends[bi] and gaps[bi] < FLOW_SENTENCE_PAUSE_SEC:
            pad = np.zeros((int(round((FLOW_SENTENCE_PAUSE_SEC - gaps[bi]) * sr)), ch), dtype="<i2")
            seg = np.vstack([seg, pad])
        end_word = first[bi + 1] if bi + 1 < len(texts) else len(words)
        bw = [{"start": round(max(0.0, words[k]["start"] - s), 3), "end": round(max(0.0, words[k]["end"] - s), 3),
               "text": words[k]["text"]} for k in range(first[bi], end_word)]
        pieces.append((seg, bw))
    return pieces, sr, ch


def _flow_block_audio(sync_blocks, tts_root, audio_root, voice, rate):
    """Flow style: every group of blocks is ONE Edge TTS utterance, cut back into block WAVs.

    Returns (audio_parts, audio_durs, words) in block order; words[i] = that block's word
    timings (relative to its own audio) for exact subtitles, or None after a fallback.
    """
    import hashlib
    import os
    from concurrent.futures import ThreadPoolExecutor, as_completed

    texts = [str(b.get("narration_text") or "").strip() for b in sync_blocks]
    plan = []
    for gi, idxs in enumerate(_flow_groups(sync_blocks)):
        gtexts = [texts[i] for i in idxs]
        joined = " ".join(gtexts)
        ghash = hashlib.sha1(f"{joined}|{voice}|{rate}|v63-flow".encode("utf-8")).hexdigest()[:14]
        wavs = []
        for k, i in enumerate(idxs):
            token = hashlib.sha1(
                f"{ghash}|{k}|{gtexts[k]}|{FLOW_LEAD_SEC}|{FLOW_TAIL_SEC}|{FLOW_SENTENCE_PAUSE_SEC}|v63-flow-slice".encode("utf-8")
            ).hexdigest()[:12]
            wavs.append(Path(audio_root) / f"{sync_blocks[i]['sync_block_id']}_{token}.wav")
        plan.append({"gi": gi, "idxs": idxs, "texts": gtexts, "joined": joined, "ghash": ghash,
                     "ends": [_flow_sentence_end(t) for t in gtexts], "wavs": wavs})

    def ready(p):
        return all(w.exists() and w.stat().st_size >= 1000 and w.with_suffix(".words.json").exists() for w in p["wavs"])

    def voice_group(p):
        mp3 = Path(tts_root) / f"flow_{p['ghash']}.mp3"
        group_wav = Path(audio_root) / f"flow_{p['ghash']}.wav"
        try:
            words = _edge_tts_words(p["joined"], mp3, mp3.with_suffix(".words.json"), voice, rate)
            run(["ffmpeg", "-y", "-i", str(mp3), "-vn", "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", str(group_wav)], quiet=True)
            pieces, sr, ch = _flow_cut(group_wav, words, p["texts"], p["ends"])
            for (seg, bw), wav in zip(pieces, p["wavs"]):
                _write_pcm_wav(wav, seg, sr, ch)
                save_json(wav.with_suffix(".words.json"), bw)
            group_wav.unlink(missing_ok=True)
        except Exception as exc:
            raise_if_terminal(exc)
            print(f"⚠️ Flow TTS group {p['gi'] + 1}: {exc} -> one TTS per block for this group", flush=True)
            for text, wav in zip(p["texts"], p["wavs"]):
                mp3b = Path(tts_root) / f"{wav.stem}.mp3"
                _edge_tts_generate(text, mp3b, voice=voice, rate=rate)
                run(["ffmpeg", "-y", "-i", str(mp3b), "-vn", "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", str(wav)], quiet=True)
                save_json(wav.with_suffix(".words.json"), [])
        return p

    todo = [p for p in plan if not ready(p)]
    total = sum(len(p["idxs"]) for p in todo)
    # edge-tts honours HTTP(S)_PROXY (aiohttp trust_env); Gemini is finished, so voice directly.
    saved_proxy = {}  # no application-selected proxy to remove
    try:
        if todo:
            print(f"🗣️ Flow TTS: {total} block(s) in {len(todo)} group(s) ({STUDIO_TTS_WORKERS} groups at a time)", flush=True)
            done = 0
            with ThreadPoolExecutor(max_workers=STUDIO_TTS_WORKERS) as tts_pool:
                for fut in as_completed([tts_pool.submit(voice_group, p) for p in todo]):
                    p = fut.result()
                    for i in p["idxs"]:
                        done += 1
                        print(f"🗣️ [{done}/{total}] {sync_blocks[i]['sync_block_id']} generate block TTS (flow group {p['gi'] + 1})",
                              flush=True)
    finally:
        os.environ.update(saved_proxy)

    audio_parts, audio_durs, words = [], [], []
    for p in plan:
        for i, wav in zip(p["idxs"], p["wavs"]):
            dur = float(ffprobe_duration(wav))
            if dur <= 0.02:
                raise RuntimeError(f"Flow TTS: invalid audio for {sync_blocks[i]['sync_block_id']}: {dur}")
            audio_parts.append(wav)
            audio_durs.append(dur)
            words.append(load_json(wav.with_suffix(".words.json")) or None)
    return audio_parts, audio_durs, words


def _render_thiha28_smart_sync(sync_blocks, completed_files, out_dir, pool, timeline, canonical_story_text=None, recap_adjust=None):
    """V6.2: V4.1-style block-native Smart Sync + cumulative frame clock.

    Each timestamp block owns its own TTS file and that TTS is the timing authority for
    exactly its own source slice (beat start -> beat end), as in V6.1. Only the frame count
    changed: block i ends on frame round(cumulative_audio_i * fps), so frame rounding can
    no longer add up across blocks (checked with ffprobe per part and after concat).
    """
    import hashlib
    import math

    if not command_exists("ffmpeg") or not command_exists("ffprobe"):
        raise RuntimeError("ffmpeg/ffprobe are required for final video rendering")
    voxcpm = TTS_PROVIDER == "voxcpm"
    if voxcpm:
        tts_voice, tts_rate = VOXCPM_CONFIG["voice"], VOXCPM_CONFIG["speed"]
    else:
        tts_voice, tts_rate = EDGE_TTS_VOICE_V44, EDGE_TTS_RATE_V44
        try:
            import edge_tts  # noqa: F401
        except ImportError as exc:
            raise RuntimeError("edge-tts is not installed. Run: pip install -U edge-tts") from exc

    if not canonical_story_text:
        canonical_story_text = " ".join(
            str(b.get("narration_text") or "").strip() for b in sync_blocks
            if str(b.get("narration_text") or "").strip()
        ).strip()
    aligned_text = " ".join(
        str(b.get("narration_text") or "").strip() for b in sync_blocks
        if str(b.get("narration_text") or "").strip()
    )
    if _norm_story_exact_v47(aligned_text) != _norm_story_exact_v47(canonical_story_text):
        raise RuntimeError("V6.2 canonical-story guard failed: sync text differs from FULL_STORYTELLING")

    source_map = {item["src"].name: Path(item["src"]).resolve() for item in completed_files}
    first_src = Path(completed_files[0]["src"]).resolve()
    width, height, _ = _probe_video_geometry(first_src)
    fps_q = _probe_video_rate_v62(first_src)
    fps = float(fps_q)
    fps_arg = f"{fps_q.numerator}/{fps_q.denominator}"

    root = Path(out_dir) / "smart_sync_thiha_28"
    tts_root = root / "block_tts_v61"
    audio_root = root / "block_audio_v61"
    video_root = root / "block_video_v62"
    for p in (root, tts_root, audio_root, video_root):
        p.mkdir(parents=True, exist_ok=True)

    print("\n" + "=" * 78)
    print("V6.2 FINAL VIDEO — V4.1-STYLE BLOCK-NATIVE SMART SYNC + FRAME CLOCK")
    print("=" * 78)
    print(f"TTS           : {'VoxCPM (Colab, ' + str(len(VOXCPM_CONFIG['links'])) + ' link(s))' if voxcpm else 'Edge TTS'}")
    print(f"Voice         : {tts_voice}")
    print(f"TTS rate      : {tts_rate}")
    print("Rule          : ONE timestamp block -> ONE TTS audio -> ONE retimed video block")
    print("Video slice   : exactly the block's own beat (no shift, no borrow, no speed clamp)")
    print(f"Frame clock   : cumulative audio time -> exact frames per block @ {fps_arg} fps")
    print("Rewrite       : OFF | audio pad: OFF | audio trim: OFF | freeze: OFF")
    print(f"Blocks        : {len(sync_blocks)}")
    print("=" * 78)

    # 1) Block TTS first: the frame clock needs every block's audio duration.
    #    Studio: blocks are independent files, so missing ones are voiced in parallel with
    #    the same Edge TTS command; durations are then read back in block order.
    from concurrent.futures import ThreadPoolExecutor, as_completed

    tts_jobs = []
    for block in sync_blocks:
        bid = str(block["sync_block_id"])
        if str(block["source_file"]) not in source_map:
            raise RuntimeError(f"Source file not found for {bid}: {block['source_file']}")
        narration = str(block.get("narration_text") or "").strip()
        if not narration:
            raise RuntimeError(f"V6.2 block has empty narration: {bid}")
        if voxcpm:
            # Raw Colab audio depends on text + voice only, so a speed change re-uses it.
            raw_token = hashlib.sha1((narration + "|voxcpm|" + tts_voice + "|v62-voxcpm-raw").encode("utf-8")).hexdigest()[:12]
            token = hashlib.sha1(
                (narration + "|voxcpm|" + tts_voice + "|" + tts_rate + "|v62-voxcpm-block").encode("utf-8")
            ).hexdigest()[:12]
            tts_jobs.append((bid, narration, tts_root / f"{bid}_{raw_token}.vox.wav", audio_root / f"{bid}_{token}.wav"))
            continue
        # Same token as V6.1 so existing block TTS caches are reused unchanged.
        token = hashlib.sha1(
            (narration + "|" + EDGE_TTS_VOICE_V44 + "|" + EDGE_TTS_RATE_V44 + "|v61-block-native").encode("utf-8")
        ).hexdigest()[:12]
        pause_tag = "" if TTS_PAUSE_SEC is None else f"_p{int(round(TTS_PAUSE_SEC * 100)):03d}"
        tts_jobs.append((bid, narration, tts_root / f"{bid}_{token}.mp3", audio_root / f"{bid}_{token}{pause_tag}.wav"))

    def _ready(path):
        return path.exists() and path.stat().st_size >= 1000

    def _voice_block(job):
        bid, narration, mp3, wav = job
        if not _ready(mp3):
            _edge_tts_block(narration, mp3, mp3.with_suffix(".words.json"), EDGE_TTS_VOICE_V44, EDGE_TTS_RATE_V44)
        if not _ready(wav):
            # PCM WAV avoids AAC concat/container-delay drift. Do not pad or duration-fit audio.
            trim = []
            if TTS_PAUSE_SEC is not None:   # V6.4 --tts-pause: Edge's own silence out, a fixed pause after
                cut = "silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.03"
                trim = ["-af", f"{cut},areverse,{cut},areverse,apad=pad_dur={TTS_PAUSE_SEC:.3f}"]
            run([
                "ffmpeg", "-y", "-i", str(mp3), "-vn", *trim,
                "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", str(wav)
            ], quiet=True)
        _block_wav_words(mp3, wav)      # the subtitles' word timing, read from the report below
        return bid

    flow = NARRATION_STYLE == "flow" and not voxcpm     # VoxCPM gives no word timing: per-block audio
    block_words = [None] * len(tts_jobs)
    todo = [] if flow else [job for job in tts_jobs if not (_ready(job[2]) and _ready(job[3]))]
    if flow:
        # Keep the original group's slices/cache when a user changes just one line.
        original_blocks = [dict(b, narration_text=b.get("original_narration_text", b["narration_text"]))
                           for b in sync_blocks]
        audio_parts, audio_durs, block_words = _flow_block_audio(original_blocks, tts_root, audio_root, tts_voice, tts_rate)
        for i, block in enumerate(sync_blocks):
            if "original_narration_text" in block:
                parts, durations, words = _flow_block_audio([block], tts_root, audio_root, tts_voice, tts_rate)
                audio_parts[i], audio_durs[i], block_words[i] = parts[0], durations[0], words[0]
    elif todo and voxcpm:
        need_raw = [job for job in todo if not _ready(job[2])]
        if need_raw:
            _voxcpm_voice_blocks(need_raw, root)
        with ThreadPoolExecutor(max_workers=STUDIO_TTS_WORKERS) as conv:
            list(conv.map(lambda job: _voxcpm_block_wav(job[2], job[3], tts_rate), [j for j in todo if not _ready(j[3])]))
    elif todo:
        print(f"🗣️ Block TTS: {len(todo)} to generate ({STUDIO_TTS_WORKERS} at a time)", flush=True)
        tts_pool = ThreadPoolExecutor(max_workers=STUDIO_TTS_WORKERS)
        try:
            futures = [tts_pool.submit(_voice_block, job) for job in todo]
            for done_n, fut in enumerate(as_completed(futures), start=1):
                print(f"🗣️ [{done_n}/{len(todo)}] {fut.result()} generate block TTS", flush=True)
        except BaseException:
            tts_pool.shutdown(wait=True, cancel_futures=True)
            raise
        tts_pool.shutdown(wait=True)

    if not flow:
        audio_parts, audio_durs = [], []
        if not voxcpm:      # classic Edge blocks: word timing taken with the TTS itself (cached JSON)
            block_words = [_block_wav_words(job[2], job[3]) for job in tts_jobs]
        for bid, _narration, _mp3, wav in tts_jobs:
            audio_dur = float(ffprobe_duration(wav))
            if audio_dur <= 0.02:
                raise RuntimeError(f"V6.2 invalid TTS duration for {bid}: {audio_dur}")
            if audio_dur > SMART_SYNC_V62_MAX_BLOCK_AUDIO_SEC:
                raise RuntimeError(f"V6.2 {bid}: its narration is {audio_dur:.0f} s long (over "
                                   f"{SMART_SYNC_V62_MAX_BLOCK_AUDIO_SEC:.0f} s); the story line is broken - "
                                   "nothing rendered (fix or rewrite that line, then resume)")
            audio_parts.append(wav)
            audio_durs.append(audio_dur)

    if recap_adjust and sum(audio_durs) > RECAP_MINUTES * 60 * 1.1:
        new_story, new_blocks = recap_adjust(sync_blocks, audio_durs)
        return _render_thiha28_smart_sync(new_blocks, completed_files, out_dir, pool, timeline,
                                         canonical_story_text=new_story, recap_adjust=recap_adjust)

    # 1b) "short_steady" story: a block spoken faster than its footage allows gets a pause after its narration,
    #     so its picture (still exactly its own beat slice) plays at most SHORT_MAX_SPEED fast.
    video_ends = {}
    pauses = [0.0] * len(audio_parts)
    if NARRATION_LENGTH == "short_steady" and SHORT_OVER_CAP == "pause":
        for i, block in enumerate(sync_blocks):
            src = source_map[str(block["source_file"])]
            if src not in video_ends:
                video_ends[src] = _probe_video_end_v62(src)
            end = float(block["source_end_sec"])
            if video_ends[src]:
                end = min(end, video_ends[src])
            need = (end - float(block["source_start_sec"])) / SHORT_MAX_SPEED
            if need <= audio_durs[i] + 0.02:
                continue
            wav = Path(audio_parts[i])
            capped = wav.with_name(f"{wav.stem}_cap{int(round(need * 1000))}.wav")
            if not _ready(capped):
                run(["ffmpeg", "-y", "-i", str(wav), "-af", f"apad=whole_dur={need:.3f}",
                     "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", str(capped)], quiet=True)
            dur = float(ffprobe_duration(capped))
            pauses[i] = dur - audio_durs[i]
            audio_parts[i], audio_durs[i] = capped, dur
        if any(pauses):
            print(f"⏸️ Short story (steady): {sum(1 for x in pauses if x)} blocks get a pause after their narration "
                  f"({sum(pauses):.0f} s in all) so the picture is never faster than {SHORT_MAX_SPEED}x", flush=True)

    # 2) Frame clock: block i ends on frame round(cum_audio_i * fps), so the picture is never
    #    more than half a frame away from the narration at any block boundary.
    frame_counts, cum_offsets = [], []
    tail_guard_frames = int(math.ceil(SMART_SYNC_V62_TAIL_GUARD_SEC * fps))
    cum_audio, cum_frames = 0.0, 0
    for i, audio_dur in enumerate(audio_durs):
        cum_audio += audio_dur
        end_frame = max(cum_frames + 1, int(round(cum_audio * fps)))
        frame_counts.append(end_frame - cum_frames)
        cum_frames = end_frame
        cum_offsets.append(cum_frames / fps - cum_audio)
    # The final slice ends at media EOF, and the final mux uses -shortest: clone its last
    # frame so the picture safely outlives the complete final TTS (V6.1.2 tail guard).
    frame_counts[-1] += tail_guard_frames
    cum_frames += tail_guard_frames

    # 3) Render every block: its own beat slice, retimed to exactly its frame count.
    #    Studio: parts are independent (exact frame counts come from step 2), so they are
    #    rendered a few at a time; every part is still frame-checked before the concat.
    #    The encoder is part of the cache token: one concat never mixes x264 and NVENC parts.
    part_encoder = _pick_part_encoder(width, height)
    print(f"Part encoder  : {part_encoder} ({STUDIO_RENDER_WORKERS} parts at a time)", flush=True)
    plans = []
    for n, block in enumerate(sync_blocks, start=1):
        bid = str(block["sync_block_id"])
        src = source_map[str(block["source_file"])]
        start = float(block["source_start_sec"])
        end = float(block["source_end_sec"])
        if src not in video_ends:
            video_ends[src] = _probe_video_end_v62(src)
        if video_ends[src] and end > video_ends[src]:
            # The slice ends where the picture does: a source's sound can run past its last frame (2026-10-04:
            # 0.13 s, and the last block, slowed to 0.26x, came out 10 frames short of its frame lock).
            # The block's frame count (its narration) is unchanged; only the footage it is cut from.
            end = video_ends[src]
            start = min(start, end - 2.0 / fps)
        source_dur = max(2.0 / fps, end - start)
        nf = frame_counts[n - 1]
        guard = tail_guard_frames if n == len(sync_blocks) else 0
        motion_sec = (nf - guard) / fps
        cut_sec = 0.0
        if (SHORT_OVER_CAP == "cut" and NARRATION_LENGTH in ("short", "short_steady", "medium", "recap")
                and source_dur > motion_sec * SHORT_MAX_SPEED + 1e-6):
            # short story: never faster than SHORT_MAX_SPEED - the end of this beat's slice is left out
            cut_sec = source_dur - motion_sec * SHORT_MAX_SPEED
            source_dur = motion_sec * SHORT_MAX_SPEED
            end = start + source_dur
        speed = source_dur / motion_sec
        pad_sec = (guard + 4) / fps  # tpad margin; -frames:v cuts the part to exactly nf
        enc_tag = "" if part_encoder == "libx264" else f"|{part_encoder}"   # keeps old x264 caches valid
        video_token = hashlib.sha1(
            f"{src}|{start:.6f}|{source_dur:.6f}|{nf}|{guard}|v62-exact|{width}x{height}|{fps_arg}{enc_tag}".encode("utf-8")
        ).hexdigest()[:12]
        video_part = video_root / f"{bid}_{video_token}.mp4"
        canvas = (f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
                  f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,setsar=1")
        vf = (
            f"setpts=(PTS-STARTPTS)/{speed:.12f},fps={fps_arg},{canvas},"
            f"tpad=stop_mode=clone:stop_duration={pad_sec:.6f}"
        )
        freeze = None
        if SLOW_STYLE in ("freeze", "mix") and speed < FREEZE_BELOW:
            import freeze_motion
            freeze = freeze_motion.plan(source_dur, nf, guard, fps)
            if freeze["hold_frames"]:
                vf = freeze_motion.filter_graph(freeze, width, height, fps_arg, canvas, guard, n)
                video_part = video_root / f"{bid}_{freeze_motion.token(video_token, freeze, n)}.mp4"
            else:
                freeze = None
        smooth = SMOOTH_MOTION and SLOW_STYLE in ("rife", "mix") and not freeze and speed < SMOOTH_BELOW_SPEED
        smooth_part = video_root / f"{bid}_{hashlib.sha1((video_token + '|' + 'rife425').encode()).hexdigest()[:12]}.mp4"
        plans.append({"n": n, "block": block, "bid": bid, "src": src, "start": start, "end": end,
                      "source_dur": source_dur, "nf": nf, "guard": guard, "motion_sec": motion_sec,
                      "speed": speed, "video_part": smooth_part if smooth else video_part, "plain_part": video_part,
                      "vf": vf, "canvas": canvas, "smooth": smooth, "cut_sec": cut_sec, "freeze": freeze})

    smooth_state = {"worker": None, "tried": False, "fails": 0, "info": {}, "lock": threading.Lock()}
    cut_blocks = [p for p in plans if p["cut_sec"]]
    if cut_blocks:
        print(f"✂️ Short story: {len(cut_blocks)} blocks would play faster than {SHORT_MAX_SPEED}x - the end of their "
              f"footage is left out ({sum(p['cut_sec'] for p in cut_blocks):.0f} s in all)", flush=True)
    smooth_count = sum(1 for p in plans if p["smooth"])
    if smooth_count:
        print(f"Smooth motion : RIFE in-between frames for {smooth_count}/{len(plans)} blocks "
              f"(slower than {SMOOTH_BELOW_SPEED}x)", flush=True)

    def _smooth_worker():
        with smooth_state["lock"]:
            if not smooth_state["tried"]:
                smooth_state["tried"] = True
                import smooth_motion
                worker = smooth_motion.SmoothMotion(log=lambda m: print(m, flush=True))
                if worker.start():
                    smooth_state["worker"] = worker
                    print(f"🎞️ Smooth motion ON ({worker.device})", flush=True)
            return smooth_state["worker"]

    def _smooth_render(p):
        """True when RIFE drew the part; False -> render it the plain ffmpeg way."""
        worker = _smooth_worker()
        if worker is None:
            return False
        import smooth_motion
        try:
            with smooth_state["lock"]:
                info = smooth_state["info"].get(p["src"])
                if info is None:
                    info = smooth_state["info"][p["src"]] = smooth_motion.source_info("ffprobe", p["src"])
            worker.render(smooth_motion.part_job(
                ffmpeg="ffmpeg", src=p["src"], start=p["start"], dur=p["source_dur"], info=info,
                width=width, height=height, nf=p["nf"], step=p["speed"] / fps, out=p["video_part"],
                out_fps=fps_arg, enc=_PART_CODEC_ARGS[part_encoder], vf_in=p["canvas"]))
            return True
        except Exception as exc:
            raise_if_terminal(exc)
            with smooth_state["lock"]:
                smooth_state["fails"] += 1
                give_up = smooth_state["fails"] >= 3 and smooth_state["worker"] is not None
                if give_up:
                    smooth_state["worker"] = None
            print(f"⚠️ Smooth motion failed on {p['bid']} ({str(exc)[:200]}) — plain render", flush=True)
            if give_up:
                print("⚠️ Smooth motion failed 3 times — plain render for the rest", flush=True)
                worker.close()
            return False

    def _render_part(p):
        cached = p["video_part"].exists() and p["video_part"].stat().st_size >= 5000
        if not cached or _count_video_frames_v62(p["video_part"]) != p["nf"]:
            if not (p["smooth"] and _smooth_render(p)):
                p["video_part"], p["smooth"] = p["plain_part"], False
                cached = p["video_part"].exists() and p["video_part"].stat().st_size >= 5000
                if not cached or _count_video_frames_v62(p["video_part"]) != p["nf"]:
                    run([
                        "ffmpeg", "-y", "-ss", f"{p['start']:.6f}", "-t", f"{p['source_dur']:.6f}",
                        "-i", str(p["src"]), "-an", "-vf", p["vf"], "-frames:v", str(p["nf"]), "-r", fps_arg,
                        *_PART_CODEC_ARGS[part_encoder],
                        "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(p["video_part"])
                    ], quiet=True)
        rendered_frames = _count_video_frames_v62(p["video_part"])
        if rendered_frames != p["nf"]:
            raise RuntimeError(f"V6.2 frame lock failed for {p['bid']}: rendered {rendered_frames} frames, planned {p['nf']}")
        return p

    pool = ThreadPoolExecutor(max_workers=STUDIO_RENDER_WORKERS)
    try:
        futures = [pool.submit(_render_part, p) for p in plans]
        for done_n, fut in enumerate(as_completed(futures), start=1):
            p = fut.result()
            print(
                f"✅ [{done_n}/{len(plans)}] {p['bid']} {srt_time(p['start'])} -> {srt_time(p['end'])} | "
                f"audio={audio_durs[p['n'] - 1]:.2f}s | source={p['source_dur']:.2f}s | frames={p['nf']} | speed={p['speed']:.3f}x"
                + (" | smooth" if p["smooth"] else ""),
                flush=True,
            )
    except BaseException:
        pool.shutdown(wait=True, cancel_futures=True)
        raise
    finally:
        if smooth_state["worker"] is not None:
            smooth_state["worker"].close()
    pool.shutdown(wait=True)

    report = []
    video_parts = []
    for p in plans:
        n, block, nf, guard, motion_sec = p["n"], p["block"], p["nf"], p["guard"], p["motion_sec"]
        video_part, source_dur, speed = p["video_part"], p["source_dur"], p["speed"]
        video_parts.append(video_part)
        report.append({
            **dict(block),
            "audio_file": str(audio_parts[n - 1]),
            "audio_duration": audio_durs[n - 1],
            "source_duration": source_dur,
            "video_speed": speed,
            "video_pts_target": motion_sec,
            "video_file": str(video_part),
            "frames": nf,
            "rendered_video_duration": nf / fps,
            "block_av_delta_sec": motion_sec - audio_durs[n - 1],
            "cum_av_offset_sec": cum_offsets[n - 1],
            "final_tail_guard_sec": guard / fps,
            "story_rewritten_for_timing": False,
            "audio_padding_enabled": bool(pauses[n - 1]),
            "pause_after_sec": round(pauses[n - 1], 3),
            "footage_cut_sec": round(p["cut_sec"], 3),
            "audio_trimming_enabled": False,
            "freeze_seconds": p["freeze"]["hold_seconds"] if p["freeze"] else 0.0,
            **({"freeze_motion_sec": p["freeze"]["motion_seconds"], "freeze_play_speed": p["freeze"]["play_speed"]} if p["freeze"] else {}),
            "smooth_motion": bool(p["smooth"]),
            "sync_rule": "one_timestamp_one_tts_one_video",
            **({"words": block_words[n - 1]} if block_words[n - 1] else {}),
        })

    # 4) Same V4.1 ordering: audio parts concat, video parts concat, final mux.
    audio_list = root / "_audio_concat_v62.txt"
    audio_list.write_text("\n".join(_ffconcat_line(x) for x in audio_parts) + "\n", encoding="utf-8")
    joined_audio = root / "_joined_audio_v62.wav"
    print("\n🔗 Timestamp audio parts concat...")
    run([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(audio_list),
        "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", str(joined_audio)
    ], quiet=True)

    video_list = root / "_video_concat_v62.txt"
    video_list.write_text("\n".join(_ffconcat_line(x) for x in video_parts) + "\n", encoding="utf-8")
    joined_video = root / "_joined_video_v62.mp4"
    print("🎬 Smart Sync video parts concat...")
    run([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(video_list),
        "-c", "copy", str(joined_video)
    ], quiet=True)
    joined_frames = _count_video_frames_v62(joined_video)
    if joined_frames != cum_frames:
        raise RuntimeError(f"V6.2 frame lock failed after concat: {joined_frames} frames, planned {cum_frames}")

    audio_dur_total = float(ffprobe_duration(joined_audio))
    video_dur_total = float(ffprobe_duration(joined_video))
    final_path = Path(out_dir) / "FINAL_STORYTELLING_THIHA_28.mp4"
    print("🎧 Block-TTS audio mux...")
    run([
        "ffmpeg", "-y", "-i", str(joined_video), "-i", str(joined_audio),
        "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy",
        "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart",
        str(final_path)
    ], quiet=True)

    final_dur = float(ffprobe_duration(final_path))
    (Path(out_dir) / "FINAL_VIDEO_NARRATION_BURMESE.txt").write_text(
        canonical_story_text.strip() + "\n", encoding="utf-8-sig"
    )
    max_cum_offset = max(abs(x) for x in cum_offsets)
    save_json(root / "SMART_SYNC_REPORT.json", {
        "version": "v6.2-v41-block-native-frame-clock",
        "tts_provider": TTS_PROVIDER,
        "narration_style": "flow" if flow else "classic",
        "language": OUTPUT_LANGUAGE,
        "voice": tts_voice,
        "rate": tts_rate,
        "fps": fps_arg,
        "continuous_tts_master": False,
        "block_native_tts": True,
        "sync_rule": "one_timestamp_one_tts_one_video_then_concat",
        "joined_audio": str(joined_audio),
        "joined_audio_duration": audio_dur_total,
        "joined_video": str(joined_video),
        "joined_video_duration": video_dur_total,
        "joined_video_frames": joined_frames,
        "final_duration": final_dur,
        "final_av_delta_sec": video_dur_total - audio_dur_total,
        "max_abs_block_boundary_offset_sec": max_cum_offset,
        "story_text_immutable": True,
        "timing_fit_gemini_enabled": False,
        "audio_padding_enabled": any(pauses),
        "short_max_speed": SHORT_MAX_SPEED if NARRATION_LENGTH in ("short", "short_steady", "medium", "recap") else None,
        "short_over_cap": SHORT_OVER_CAP if NARRATION_LENGTH in ("short", "short_steady", "medium", "recap") else None,
        "footage_cut_sec": round(sum(p["cut_sec"] for p in plans), 3),
        "audio_trimming_enabled": False,
        "freeze_enabled": any(p["freeze"] for p in plans),
        "source_audio": False,
        "blocks": report,
    })

    print(f"✅ FINAL READY: {final_path}")
    print(
        f"⏱️ Joined audio={audio_dur_total:.2f}s | joined video={video_dur_total:.2f}s | "
        f"delta={video_dur_total-audio_dur_total:+.3f}s | Final={final_dur:.2f}s | "
        f"max block-boundary offset={max_cum_offset*1000:.1f}ms"
    )
    print("🛡️ V6.2 RULE: timestamp block -> own TTS -> own retimed beat slice -> frame-exact ordered concat")
    return final_path, report


def run_video_recap_v4(args, files, base_dir, completed_files):
    if getattr(args, "no_video_recap", False):
        print("\n[V4] Video recap stage skipped (--no-video-recap).")
        return

    import os
    try:
        from google.genai import types
    except ImportError as exc:
        raise RuntimeError(
            "V4 video recap requires google-genai. Install with: pip install -U google-genai"
        ) from exc

    proxy = ""  # OS network / external VPN
    if proxy:
        os.environ["HTTP_PROXY"] = proxy
        os.environ["HTTPS_PROXY"] = proxy
        print(f"[V4] Proxy: {proxy}")

    keys = _collect_gemini_keys(getattr(args, "gemini_env_file", None))
    models = [x.strip() for x in getattr(args, "gemini_models", "gemini-3.8-flash").split(",") if x.strip()]
    pool = GeminiKeyPool(keys, models, timeout_ms=getattr(args, "gemini_timeout_ms", 90000))

    out = Path(base_dir) / "recap_output_v4_2"
    clip_root = out / "_analysis_clips"
    scene_cache = out / "scene_cache"
    recap_cache = out / "recap_cache"  # legacy V4 cache
    story_cache = out / "storytelling_cache_v5_1_direct_writer_sync"
    sync_cache = out / "sync_story_cache_v5_1_unused"
    out.mkdir(parents=True, exist_ok=True)
    clip_root.mkdir(parents=True, exist_ok=True)
    scene_cache.mkdir(parents=True, exist_ok=True)

    if getattr(args, "video_fresh", False):
        clear_path(scene_cache)
        clear_path(recap_cache)
        clear_path(story_cache)
        clear_path(sync_cache)
        clear_path(out / "smart_sync_thiha_28")
        clear_path(out / "CHARACTER_REGISTRY.json")
        clear_path(out / "SCENE_LEDGER.json")
        scene_cache.mkdir(parents=True, exist_ok=True)

    registry_path = out / "CHARACTER_REGISTRY.json"
    if registry_path.exists() and not getattr(args, "video_fresh", False):
        try:
            registry = load_json(registry_path)
        except Exception:
            registry = {}
    else:
        registry = {}

    completed_map = {item["src"].resolve(): item for item in completed_files}
    all_events = []
    all_dialogue = []
    all_uncertainties = []
    global_file_offset = 0.0
    previous_tail = []
    clip_seconds = max(15.0, float(getattr(args, "video_clip_seconds", 55.0)))
    overlap = max(0.0, min(float(getattr(args, "video_clip_overlap", 5.0)), clip_seconds - 1.0))
    step = max(1.0, clip_seconds - overlap)
    video_fps = max(1.0, float(getattr(args, "video_fps", 4.0)))
    test_clips = max(0, int(getattr(args, "video_test_clips", 0)))
    seen_clips = 0

    print("\n" + "=" * 78)
    print("MANJU VIDEO RECAP V5.1 - DIRECT WRITER SYNC + CONTINUOUS TTS")
    print("=" * 78)
    print(f"Gemini models : {', '.join(models)}")
    print(f"Gemini keys   : {len(keys)}")
    print(f"Clip          : {clip_seconds:g}s, overlap {overlap:g}s")
    print(f"Video sampling: {video_fps:g} FPS")
    print(f"Output        : {out}")
    print("=" * 78)

    for file_index, src in enumerate(files, start=1):
        src = src.resolve()
        item = completed_map.get(src)
        if item is None:
            print(f"[V4 WARN] No transcript item for {src.name}; skipping.")
            continue
        duration = float(item["duration"])
        segments = item["segments"]
        file_cache = scene_cache / src.stem
        file_clips = clip_root / src.stem
        file_cache.mkdir(parents=True, exist_ok=True)
        file_clips.mkdir(parents=True, exist_ok=True)

        starts = []
        pos = 0.0
        while pos < duration - 0.05:
            starts.append(pos)
            pos += step
        print(f"\n[V4 FILE {file_index}/{len(files)}] {src.name} | {len(starts)} video clip(s)")

        for ci, clip_start in enumerate(starts):
            if test_clips and seen_clips >= test_clips:
                print(f"[V4 TEST] Reached --video-test-clips {test_clips}; stopping analysis early.")
                break
            seen_clips += 1
            clip_dur = min(clip_seconds, duration - clip_start)
            cache_json = file_cache / f"clip_{ci:04d}.json"
            clip_file = file_clips / f"clip_{ci:04d}.mp4"
            print(f"  Clip {ci + 1}/{len(starts)} [{srt_time(clip_start)} -> {srt_time(clip_start + clip_dur)}]")

            transcript_rows = _segments_for_window(segments, clip_start, clip_start + clip_dur)

            if cache_json.exists() and not getattr(args, "video_fresh", False):
                data = load_json(cache_json)
                print("    [RESUME] verified video facts loaded")
                # Rebuild registry from cache in chronological order.
                data = _reconcile_characters(data, registry, src.name, clip_start)
                # Upgrade old V4 cache content: no transcript line may disappear.
                data = _ensure_dialogue_coverage(data, transcript_rows)
            else:
                _extract_video_clip(src, clip_file, clip_start, clip_dur)
                size_mb = clip_file.stat().st_size / (1024 * 1024)
                if size_mb >= 19.5:
                    raise RuntimeError(
                        f"Analysis clip is {size_mb:.1f} MB, too large for safe inline use: {clip_file}. "
                        "Reduce --video-clip-seconds."
                    )
                prompt = _scene_prompt(src.name, clip_start, clip_dur, transcript_rows, registry, previous_tail)
                video_part = types.Part(
                    inline_data=types.Blob(data=clip_file.read_bytes(), mime_type="video/mp4"),
                    video_metadata=types.VideoMetadata(fps=video_fps),
                )
                contents = types.Content(parts=[video_part, types.Part(text=prompt)])
                data, used_model, key_tag = pool.generate_json(contents, SCENE_FACT_SCHEMA, temperature=0.0)
                data = _reconcile_characters(data, registry, src.name, clip_start)
                data = _ensure_dialogue_coverage(data, transcript_rows)
                print(
                    f"    [FACTS OK] {used_model} {key_tag} | events={len(data.get('events') or [])} "
                    f"| dialogue={len(data.get('dialogue') or [])}/{len(transcript_rows)}"
                )

                if getattr(args, "verify_uncertain", True) and _should_verify(data):
                    verify_prompt = _verify_prompt(src.name, clip_start, data)
                    verify_contents = types.Content(parts=[video_part, types.Part(text=verify_prompt)])
                    verify, vm, vk = pool.generate_json(verify_contents, VERIFY_SCHEMA, temperature=0.0, max_output_tokens=8192)
                    data = _apply_verifier(data, verify)
                    data = _ensure_dialogue_coverage(data, transcript_rows)
                    print(f"    [VERIFY OK] {vm} {vk} | corrections={len(verify.get('corrections') or [])}")

                save_json(cache_json, data)
                save_json(registry_path, registry)
                if not getattr(args, "keep_video_clips", False):
                    try:
                        clip_file.unlink()
                    except Exception:
                        pass

            for ev in data.get("events") or []:
                local_s = max(0.0, min(clip_dur, float(ev.get("start_sec") or 0.0)))
                local_e = max(local_s, min(clip_dur, float(ev.get("end_sec") or local_s)))
                row = dict(ev)
                row["source_file"] = src.name
                row["file_start_sec"] = clip_start + local_s
                row["file_end_sec"] = clip_start + local_e
                row["global_start_sec"] = global_file_offset + clip_start + local_s
                row["global_end_sec"] = global_file_offset + clip_start + local_e
                all_events.append(row)

            for d in data.get("dialogue") or []:
                local_t = max(0.0, min(clip_dur, float(d.get("time_sec") or 0.0)))
                row = dict(d)
                row["source_file"] = src.name
                row["file_start_sec"] = clip_start + local_t
                row["global_start_sec"] = global_file_offset + clip_start + local_t
                all_dialogue.append(row)

            for u in data.get("uncertainties") or []:
                all_uncertainties.append(
                    f"FILE: {src.name}\nTIME: {srt_time(clip_start)} -> {srt_time(clip_start + clip_dur)}\nUNCERTAIN: {u}"
                )

            # Previous tail carries only verified local context; no free-form recap.
            previous_tail.extend(data.get("events") or [])
            previous_tail.extend(data.get("dialogue") or [])
            previous_tail = previous_tail[-18:]

        global_file_offset += duration
        if test_clips and seen_clips >= test_clips:
            break

    all_events = _dedupe_global_events(all_events)
    all_dialogue = _dedupe_dialogue(all_dialogue)
    all_dialogue = _enrich_dialogue_with_whisper_bounds(all_dialogue, completed_files)
    # V5.0: keep the complete scene ledger, but exclude camera/establishing-only events
    # from the mandatory storytelling timeline. This prevents narration like aerial road views.
    storytelling_events = _filter_storytelling_events(all_events)
    timeline = _build_story_timeline(storytelling_events, all_dialogue)
    save_json(registry_path, registry)
    save_json(out / "SCENE_LEDGER.json", all_events)
    _write_scene_ledger_txt(all_events, registry, out / "SCENE_LEDGER.txt")
    save_json(out / "DIALOGUE_LEDGER.json", all_dialogue)
    _write_dialogue_ledger_txt(all_dialogue, registry, out / "DIALOGUE_LEDGER.txt")
    save_json(out / "FULL_STORY_TIMELINE.json", timeline)

    review_path = out / "UNCERTAIN_REVIEW.txt"
    if all_uncertainties:
        review_path.write_text("\n\n".join(all_uncertainties) + "\n", encoding="utf-8-sig")
    else:
        review_path.write_text("No unresolved visual uncertainties.\n", encoding="utf-8-sig")

    if not timeline:
        print("[V4.2 WARN] No verified timeline items produced; storytelling writer skipped.")
        return

    if test_clips:
        print("[V4.2 TEST] Test mode: ledgers written; final storytelling writer skipped.")
        return

    # V5.1: the writer writes DIRECTLY into final sync buckets. There is no later
    # semantic alignment/splitting stage. Dialogue text already belongs to exact Whisper
    # timestamps; visual/action text already belongs to the remaining visual gaps.
    recap, sync_blocks = _build_full_storytelling_v51(
        pool, timeline, registry, story_cache, completed_files
    )
    recap_path = out / "RECAP_BURMESE.txt"  # compatibility filename
    full_story_path = out / "FULL_STORYTELLING_BURMESE.txt"
    recap_path.write_text(recap + "\n", encoding="utf-8-sig")
    full_story_path.write_text(recap + "\n", encoding="utf-8-sig")
    save_json(out / "STORY_ALIGNMENT_V51_DIRECT.json", sync_blocks)
    save_json(out / "SYNC_NARRATION_BLOCKS.json", sync_blocks)
    final_video, smart_report = _render_thiha28_smart_sync(
        sync_blocks, completed_files, out, pool, timeline, canonical_story_text=recap
    )

    if not getattr(args, "keep_video_clips", False):
        shutil.rmtree(clip_root, ignore_errors=True)

    print("\n" + "=" * 78)
    print("V5.1 DIRECT-WRITER + WHISPER-HARD-ANCHOR SMART SYNC DONE")
    print("=" * 78)
    print(f"Character registry : {registry_path}")
    print(f"Scene ledger JSON  : {out / 'SCENE_LEDGER.json'}")
    print(f"Scene ledger TXT   : {out / 'SCENE_LEDGER.txt'}")
    print(f"Dialogue ledger    : {out / 'DIALOGUE_LEDGER.txt'}")
    print(f"Full timeline      : {out / 'FULL_STORY_TIMELINE.json'}")
    print(f"Coverage audit     : {out / 'STORY_COVERAGE_AUDIT.json'}")
    print(f"Uncertain review   : {review_path}")
    print(f"Full storytelling  : {full_story_path}")
    print(f"Compatibility copy : {recap_path}")
    print(f"Story alignment    : {out / 'STORY_ALIGNMENT_V50.json'}")
    print(f"Sync blocks        : {out / 'SYNC_NARRATION_BLOCKS.json'}")
    print(f"Smart Sync report  : {out / 'smart_sync_thiha_28' / 'SMART_SYNC_REPORT.json'}")
    print(f"FINAL VIDEO        : {final_video}")
    print("=" * 78)



# ============================================================================
# V6.0 GEMINI-ONLY VIDEO TIMELINE
# Gemini owns dialogue transcription + story-relevant visual/VFX timestamps.
# Whisper is not used anywhere in this pipeline.
# ============================================================================

GEMINI_TIMELINE_SCHEMA_V60 = {
    "type": "object",
    "properties": {
        "clip_summary": {"type": "string"},
        "characters": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "character_id": {"type": "string"},
                    "name": {"type": "string"},
                    "visual_description": {"type": "string"},
                    "role_hint": {"type": "string"},
                    "confidence": {"type": "number"},
                    "identity_evidence": {"type": "string"},
                },
                "required": ["character_id", "name", "visual_description", "role_hint", "confidence", "identity_evidence"],
            },
        },
        "beats": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "start_sec": {"type": "number"},
                    "end_sec": {"type": "number"},
                    "kind": {"type": "string"},
                    "speaker": {"type": "string"},
                    "source_dialogue": {"type": "string"},
                    "dialogue_meaning": {"type": "string"},
                    "actors": {"type": "array", "items": {"type": "string"}},
                    "visual_action": {"type": "string"},
                    "targets": {"type": "array", "items": {"type": "string"}},
                    "addressee": {"type": "array", "items": {"type": "string"}},
                    "location": {"type": "string"},
                    "confidence": {"type": "number"},
                    "evidence_note": {"type": "string"},
                },
                "required": [
                    "start_sec", "end_sec", "kind", "speaker", "source_dialogue",
                    "dialogue_meaning", "actors", "visual_action", "targets", "location",
                    "confidence", "evidence_note"
                ],
            },
        },
        "registry_updates": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "character_id": {"type": "string"},
                    "canonical_name": {"type": "string"},
                    "alias": {"type": "string"},
                    "reason": {"type": "string"},
                    "confidence": {"type": "number"},
                },
                "required": ["character_id", "canonical_name", "alias", "reason", "confidence"],
            },
        },
        "uncertainties": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["clip_summary", "characters", "beats", "registry_updates", "uncertainties"],
}


# Studio V6.3 timeline check. On 武朝大帝 (55 min, 65/66 clips answered by flash-lite while the
# stronger models were busy) half the clips came back squeezed or incomplete: all events of a
# 55 s clip stamped inside its first 5-30 s (the kick narrated 42 s before the kick), or 40+ s
# of dialogue skipped, or absolute file times instead of clip times. Clips that were right never
# left more than 16 s without a beat; broken ones left 24-55 s.
TIMELINE_MAX_GAP_SEC = 20.0          # longest stretch of a clip allowed without any beat
TIMELINE_CHECK_MIN_CLIP_SEC = 20.0   # shorter tail clips are not judged
# The same squeeze can hide behind one long beat with no dialogue that fills the rest of the
# clip ("officials look on in silence" 25 s over the sword scene, really 40 s of dialogue).
# Real silent actions stayed under 12 s; the catch-all beats were 21-48 s.
TIMELINE_MAX_SILENT_BEAT_SEC = 15.0
# ...or behind one long beat carrying only the line said at its end (22:12-22:35 "朕像个病人",
# said at 22:32 after six skipped lines; 22:40-23:00, 28:03-28:25 the same). A beat's time
# beyond its words (spoken slowly) counts as silent: the catch-alls left 18-21 s, every
# other beat of the 55 min film under 8.5 s.
TIMELINE_SPEECH_CHARS_PER_SEC = 3.0


def _v63_timeline_check(data, clip_dur, max_gap=None, max_silent=None):
    """(issues, badness) for one clip's Gemini beats; no issues = accept."""
    beats = [b for b in ((data or {}).get("beats") or []) if isinstance(b, dict)]
    clip_dur = float(clip_dur)
    max_gap = TIMELINE_MAX_GAP_SEC if max_gap is None else float(max_gap)
    if clip_dur < TIMELINE_CHECK_MIN_CLIP_SEC:
        return [], 0.0
    if not beats:
        return ["no beats"], clip_dur + 100.0
    issues = []
    outside = [b for b in beats if max(float(b.get("start_sec") or 0.0), float(b.get("end_sec") or 0.0)) > clip_dur + 1.0]
    if outside:
        issues.append(f"{len(outside)} beat(s) timed past the {clip_dur:.0f}s clip (file time instead of clip time?)")
    spans = sorted(
        (max(0.0, float(b.get("start_sec") or 0.0)), min(clip_dur, float(b.get("end_sec") or 0.0)))
        for b in beats if b not in outside
    )
    gap, gap_at, cur = 0.0, 0.0, 0.0
    for s, e in spans:
        if s - cur > gap:
            gap, gap_at = s - cur, cur
        cur = max(cur, e)
    if clip_dur - cur > gap:
        gap, gap_at = clip_dur - cur, cur
    if not spans:
        gap, gap_at = clip_dur, 0.0
    if gap > max_gap:
        issues.append(f"no beat for {gap:.0f}s ({gap_at:.0f}-{gap_at + gap:.0f}s of {clip_dur:.0f}s: squeezed or skipped)")
    # shorter spans get a proportionally shorter limit, like the gap
    if max_silent is None:
        max_silent = TIMELINE_MAX_SILENT_BEAT_SEC * max_gap / TIMELINE_MAX_GAP_SEC
    silent = []
    for b in beats:
        if b in outside:
            continue
        s, e = max(0.0, float(b.get("start_sec") or 0.0)), min(clip_dur, float(b.get("end_sec") or 0.0))
        chars = len(normalize_text(str(b.get("source_dialogue") or "")))
        unspoken = (e - s) - chars / TIMELINE_SPEECH_CHARS_PER_SEC
        if unspoken > max_silent:
            silent.append((unspoken, s, e, chars))
    if silent:
        longest, s, e, chars = max(silent)
        if chars:
            issues.append(f"one beat covers {e - s:.0f}s for a {chars}-character line ({s:.0f}-{e:.0f}s): "
                          f"events squeezed before it?")
        else:
            issues.append(f"one beat without dialogue covers {longest:.0f}s ({s:.0f}-{e:.0f}s): events squeezed before it?")
    return issues, gap + 60.0 * len(outside) + sum(u for u, _s, _e, _c in silent)


# The prompt shows the previous clip's last beats as context. On 武朝大帝 flash-lite answered
# 35:00, 40:50 and the 45:50 sword scene with 3-8 of those lines, stamped 20-60 s after they
# were really said (Ning Song's 45:16-45:47 speech over 46:18-46:43, where the sword is drawn).
# Overlapping clips repeat a line only at the same moment; one line said again later happens
# for real (吾皇万岁), several in one clip did not.
TIMELINE_COPY_MIN_CHARS = 6        # shorter lines repeat for real
TIMELINE_COPY_MIN_AGE_SEC = 15.0   # the same line closer than this is the 5 s clip overlap
TIMELINE_COPY_MAX_LINES = 1        # more repeated lines than this = the context was copied


def _v63_copied_lines(data, clip_start, context):
    """[(file time, context file time, line)] for beats repeating a context line said much earlier."""
    earlier = [(float(p.get("file_start_sec") or 0.0), normalize_text(str(p.get("source_dialogue") or "")))
               for p in (context or []) if isinstance(p, dict)]
    copied = []
    for b in ((data or {}).get("beats") or []):
        if not isinstance(b, dict):
            continue
        line = normalize_text(str(b.get("source_dialogue") or ""))
        if len(line) < TIMELINE_COPY_MIN_CHARS:
            continue
        at = float(clip_start) + float(b.get("start_sec") or 0.0)
        for t, old in earlier:
            if at - t > TIMELINE_COPY_MIN_AGE_SEC and len(old) >= TIMELINE_COPY_MIN_CHARS and (
                    line in old or old in line or _v62_text_similarity(line, old) >= 0.80):
                copied.append((at, t, b.get("source_dialogue")))
                break
    return copied


def _v63_clip_check(data, clip_dur, clip_start=0.0, context=None):
    """_v63_timeline_check plus: the answer must not repeat the context beats' lines."""
    issues, badness = _v63_timeline_check(data, clip_dur)
    copied = _v63_copied_lines(data, clip_start, context)
    if len(copied) > TIMELINE_COPY_MAX_LINES:
        at, t, _line = copied[0]
        issues = issues + [f"{len(copied)} lines copied from the previous beats "
                           f"(the {srt_time(t)} line put at {srt_time(at)})"]
        badness += 20.0 * len(copied)
    return issues, badness


TIMELINE_SPLIT_SHARE_SEC = 5.0     # neighbouring parts share this much video in the middle
TIMELINE_SPLIT_MAX_DEPTH = 2       # 55 s clip -> two 30 s halves -> four ~17 s quarters


def _v63_span_check(span_dur, clip_seconds=55.0):
    """The clip check with limits scaled to a shorter span (floors keep real 6-8 s actions)."""
    scale = float(span_dur) / float(clip_seconds)
    max_gap = max(7.0, TIMELINE_MAX_GAP_SEC * scale)
    max_silent = max(8.0, TIMELINE_MAX_SILENT_BEAT_SEC * scale)
    return lambda d: _v63_timeline_check(d, span_dur, max_gap, max_silent)


def _v63_ask_span(pool, types, src, clip_dir, tag, source_name, span_start, span_dur, registry,
                  video_fps, clip_seconds=55.0, depth=1, keep_clips=False):
    """One checked timeline answer for part of a clip (span-relative times).

    flash-lite timed 30 s spans exactly where it drifted on 55 s ones, but a few 30 s spans it
    still covered only ~15 s; a span whose answers keep failing is split again (to ~17 s).
    The previous beats are not shown: flash-lite filled spans with their lines (see
    TIMELINE_COPY_MIN_AGE_SEC); asked without them it timed the 武朝大帝 sword scene exactly.
    """
    part = Path(clip_dir) / f"{tag}.mp4"
    _extract_video_clip(src, part, span_start, span_dur)
    contents = [VideoClip(part, video_fps), _gemini_timeline_prompt_v60(source_name, span_start, span_dur, registry, [])]
    try:
        return pool.generate_json_checked(contents, GEMINI_TIMELINE_SCHEMA_V60, _v63_span_check(span_dur, clip_seconds),
                                          label=tag, temperature=0.0, max_output_tokens=24576)
    except RuntimeError as exc:
        raise_if_terminal(exc)
        if "run again later" not in str(exc) or depth >= TIMELINE_SPLIT_MAX_DEPTH:
            raise
    finally:
        _release_video(pool, part)
        if not keep_clips:
            part.unlink(missing_ok=True)
    print(f"    [TIMELINE SPLIT] {tag}: asking for two shorter parts", flush=True)
    sub = span_dur / 2.0 + TIMELINE_SPLIT_SHARE_SEC / 2.0
    a = _v63_ask_span(pool, types, src, clip_dir, tag + "a", source_name, span_start, sub, registry,
                      video_fps, clip_seconds, depth + 1, keep_clips)
    b = _v63_ask_span(pool, types, src, clip_dir, tag + "b", source_name, span_start + span_dur - sub, sub, registry,
                      video_fps, clip_seconds, depth + 1, keep_clips)
    merged = _v63_merge_halves(a[0], b[0], span_dur - sub, span_dur)
    return merged, f"{a[1]}+{b[1]}", b[2], a[3] + b[3]


def _v63_merge_parts(parts, clip_dur):
    """Overlapping part answers [(payload, offset, length)] -> one clip answer. Neighbouring parts
    share a few seconds, split in the middle: every beat is kept once (by its start, in the part
    that owns that moment), and a beat may not run into the next one."""
    bounds = [float("-inf")]
    for k in range(1, len(parts)):
        prev_end = parts[k - 1][1] + parts[k - 1][2]
        bounds.append((parts[k][1] + prev_end) / 2.0)
    bounds.append(float("inf"))
    beats = []
    for k, (payload, offset, _length) in enumerate(parts):
        for b in (payload or {}).get("beats") or []:
            start = float(b.get("start_sec") or 0.0) + offset
            if bounds[k] <= start < bounds[k + 1]:
                end = min(clip_dur, float(b.get("end_sec") or 0.0) + offset)
                beats.append({**b, "start_sec": round(start, 3), "end_sec": round(max(end, start + 0.3), 3)})
    beats.sort(key=lambda b: (b["start_sec"], b["end_sec"]))
    for a, b in zip(beats, beats[1:]):
        if a["end_sec"] > b["start_sec"]:
            a["end_sec"] = max(round(a["start_sec"] + 0.3, 3), b["start_sec"])
    characters = {}
    for payload, _offset, _length in parts:
        for c in (payload or {}).get("characters") or []:
            characters.setdefault(c.get("character_id") or c.get("name"), c)
    summary = " ".join(str((p or {}).get("clip_summary") or "").strip() for p, _o, _l in parts).strip()
    return {**(parts[0][0] or {}), "clip_summary": summary, "characters": list(characters.values()), "beats": beats}


def _v63_merge_halves(first, second, second_offset, clip_dur):
    """Two half-clip answers (the second starting at second_offset) -> one clip answer."""
    length = clip_dur - second_offset
    return _v63_merge_parts([(first, 0.0, length), (second, second_offset, length)], clip_dur)


def _v63_ask_parts(pool, types, src, clip_dir, tag, source_name, clip_start, clip_dur, registry, video_fps,
                   clip_seconds=55.0, parts=2, keep_clips=False):
    """A clip asked as `parts` overlapping spans (neighbours share TIMELINE_SPLIT_SHARE_SEC), each
    checked, then joined. Returns (data, model, key, issues) like generate_json_checked."""
    share = TIMELINE_SPLIT_SHARE_SEC
    length = (clip_dur + (parts - 1) * share) / parts
    name = {2: "half", 3: "third"}.get(parts, "part")
    answers = []
    for k in range(parts):
        offset = k * (length - share)
        answer = _v63_ask_span(pool, types, src, clip_dir, f"{tag} {name} {k + 1}", source_name, clip_start + offset,
                               length, registry, video_fps, clip_seconds, depth=1, keep_clips=keep_clips)
        answers.append((answer, offset))
    data = _v63_merge_parts([(a[0], offset, length) for a, offset in answers], clip_dur)
    label = {2: "halves", 3: "thirds"}.get(parts, f"{parts} parts")
    model = "+".join(a[1] for a, _offset in answers) + f" ({label})"
    return data, model, answers[-1][0][2], [i for a, _offset in answers for i in a[3]]


def _v63_weak_model(model):
    """flash-lite: exact on 30 s halves, but drifts on a whole 55 s clip ('(halves)' / '(thirds)'
    answers are kept)."""
    m = str(model or "").lower()
    return "lite" in m and "(halves)" not in m and "(thirds)" not in m


def _v63_json_field(path, key):
    try:
        return load_json(path).get(key)
    except Exception:
        return None


def _v63_cached_clip(cache_json, clip_dur, clip_start=0.0, context=None):
    """Cached clip payload, or None when it fails the timeline check (the file is kept as
    *.rejected.json and the clip is asked again). A payload accepted after every model had
    answered carries check_accepted and is not asked again; a whole-clip flash-lite answer
    is always asked again, as two 30 s halves. context = the previous beats its prompt showed."""
    try:
        cached = load_json(cache_json)
    except Exception:
        return None
    if cached.get("version") != "v6.0-gemini-only-timeline":
        return None
    payload = cached.get("payload") or {}
    issues, _ = _v63_clip_check(payload, clip_dur, clip_start, context)
    weak = _v63_weak_model(cached.get("model")) and float(clip_dur) >= 2 * TIMELINE_CHECK_MIN_CLIP_SEC
    if weak:
        issues = issues + ["timed by flash-lite on the whole clip (re-timed in two 30 s halves)"]
    if issues and (weak or not cached.get("check_accepted")):
        print(f"    [TIMELINE CHECK] cached answer from {cached.get('model')} rejected: {'; '.join(issues)} -> asking again")
        try:
            Path(cache_json).replace(Path(cache_json).with_suffix(".rejected.json"))
        except OSError:
            pass
        return None
    return payload


# Studio V6.4 Whisper timing check (user-approved 2026-10-01). Gemini still writes the timeline;
# Whisper only listens. On 武朝大帝 flash-lite answers that passed every check above still stamped
# whole clips 8-22 s early (15:00-15:55 every line ~9 s early, 31:40 ~22 s): their beats covered
# the clip, so nothing in the answer itself looked wrong. Whisper medium, one 55 s clip at a time,
# heard the lines within 1-2 s of the burned-in subtitles.
WHISPER_CHECK_OFF_SEC = 4.0         # a line heard further than this from its beat is off
WHISPER_CHECK_FAR_SEC = 10.0        # one line this far off is enough to ask again
WHISPER_CHECK_SIMILARITY = 0.6      # the same line although Whisper mishears ~1 character in 5
WHISPER_CHECK_SKIPPED_UNITS = 15.0  # this much speech within 10 s that no beat carries = skipped lines
WHISPER_CHECK_MIN_UNITS = 5.0       # shorter lines (吾皇万岁, 拖下去) are too common to place
# flash-lite also invented whole conversations (35:50: 10 of 10 lines never said) at the right
# times, over the real speech. Whisper mishears names and homophones, so a few unmatched lines
# are normal (at most 2 per clip on 武朝大帝); invented clips had 3+ and 40%+ of their lines.
WHISPER_CHECK_UNHEARD_LINES = 3
WHISPER_CHECK_UNHEARD_SHARE = 0.4
WHISPER_CHECK_UNHEARD_WINDOW_SEC = 20.0   # ...or 3 within 20 s (31:40: half a clip invented, 3 of 14 lines)
WHISPER_CHECK_VERSION = 4           # cached verdicts of older rules are checked again
# Without it Whisper drifts into Traditional characters after the first window.
WHISPER_ZH_PROMPT = "以下是普通话的句子，使用简体中文。"


def _v64_norm(text):
    """Letters, digits and combining marks only: Whisper's punctuation varies (﹔ ， ? ...)."""
    import unicodedata
    return "".join(ch for ch in str(text or "").lower() if unicodedata.category(ch)[0] in "LNM")


def _v64_units(text):
    """Amount of speech: a CJK / kana / hangul character counts 1, any other letter 1/4 (about a syllable)."""
    return sum(1.0 if (0x3040 <= ord(ch) <= 0x30FF or 0x3400 <= ord(ch) <= 0x9FFF or 0xAC00 <= ord(ch) <= 0xD7AF
                       or 0xF900 <= ord(ch) <= 0xFAFF) else 0.25 for ch in str(text or ""))


def _v64_clean(words):
    """Drop Whisper's babble: stretches of ~12 words built from 3 or fewer different characters
    ("我啊我啊啊我啊…" over laughter / music on 武朝大帝 10:40)."""
    words = list(words or [])
    norms = [_v64_norm(w.get("w")) for w in words]
    bad = set()
    for i in range(len(words)):
        text = "".join(norms[i:i + 12])
        if len(text) >= 10 and len(set(text)) <= 3:
            bad.update(range(i, min(len(words), i + 12)))
    return [w for i, w in enumerate(words) if i not in bad]


def _v64_stream(words):
    """Whisper words -> (normalized text, file time of each character, word probability of each character)."""
    chars, times, probs = [], [], []
    for w in _v64_clean(words):
        n = _v64_norm(str(w.get("w") or ""))
        if not n:
            continue
        t0 = float(w.get("t") or 0.0)
        t1 = max(t0, float(w.get("e") or t0))
        for k, ch in enumerate(n):
            chars.append(ch)
            times.append(t0 + (t1 - t0) * k / len(n))
            probs.append(float(w.get("p") if w.get("p") is not None else 1.0))
    return "".join(chars), times, probs


def _v64_find_line(line, stream, times, near):
    """(similarity, time heard, (i, j), every nearly-as-good (i, j)) for the stretch of Whisper's text most
    like `line`; among nearly as good stretches (a line said twice) the one nearest `near`.
    (0.0, None, None, []) if none is close."""
    import difflib
    n = len(line)
    if not n or not stream:
        return 0.0, None, None, []
    sm = difflib.SequenceMatcher(None, autojunk=False)
    sm.set_seq2(line)
    found = []
    for width in sorted({max(2, round(n * 0.8)), n, round(n * 1.25)}):
        for i in range(0, max(1, len(stream) - width + 1)):
            sm.set_seq1(stream[i:i + width])
            if sm.real_quick_ratio() < WHISPER_CHECK_SIMILARITY or sm.quick_ratio() < WHISPER_CHECK_SIMILARITY:
                continue
            r = sm.ratio()
            if r >= WHISPER_CHECK_SIMILARITY:
                first = next((a for a, _b, size in sm.get_matching_blocks() if size), 0)
                # a stream shorter than the window (little speech heard) must not give a span past its end
                found.append((r, i, min(len(stream), i + width), times[min(len(times) - 1, i + first)]))
    if not found:
        return 0.0, None, None, []
    best = max(f[0] for f in found)
    good = [f for f in found if f[0] >= best - 0.1]
    r, i, j, heard = min(good, key=lambda f: abs(f[3] - near))
    return r, heard, (i, j), [(f[1], f[2]) for f in good]


def _v64_whisper_check(data, clip_start, clip_dur, words):
    """(issues, badness): one clip's dialogue beats against what Whisper heard in the same clip.

    A line heard more than WHISPER_CHECK_OFF_SEC away from its beat is off. Two off lines (and at
    least 30% of the lines found), or one line more than WHISPER_CHECK_FAR_SEC off, fail the clip;
    so do lines Whisper never hears although it hears speech there (invented dialogue), and clear
    speech that no dialogue beat carries (lines skipped, squeezed elsewhere or replaced)."""
    stream, times, probs = _v64_stream(words)
    if not stream:
        return [], 0.0
    clip_start, clip_dur = float(clip_start), float(clip_dur)
    beats = [b for b in ((data or {}).get("beats") or []) if isinstance(b, dict)]
    found, off, unheard, long_lines = [], [], [], 0
    used = [False] * len(stream)
    short = []       # beats whose line is too short to place: they cover the speech around them
    for b in beats:
        line = _v64_norm(str(b.get("source_dialogue") or ""))
        at = clip_start + float(b.get("start_sec") or 0.0)
        end = clip_start + float(b.get("end_sec") or 0.0)
        if _v64_units(line) < WHISPER_CHECK_MIN_UNITS:
            if line:
                short.append((at - 1.5, end + 1.5))
            continue
        long_lines += 1
        _r, heard, _span, spans = _v64_find_line(line, stream, times, at)
        if heard is None:
            around = "".join(stream[k] for k, t in enumerate(times) if at - 1.0 <= t <= end + 1.0 and probs[k] >= 0.5)
            if len(around) >= 4:
                unheard.append((at, str(b.get("source_dialogue") or ""), around))
            continue
        found.append(at)
        for i, j in spans:          # every time the line is said (a chorus repeated 46:09-46:23)
            for k in range(i, j):
                used[k] = True
        if abs(at - heard) > WHISPER_CHECK_OFF_SEC:
            off.append((at - heard, at, str(b.get("source_dialogue") or "")))
    issues, badness = [], 0.0
    if (len(off) >= 2 and len(off) >= 0.3 * len(found)) or any(abs(o[0]) > WHISPER_CHECK_FAR_SEC for o in off):
        d, at, text = max(off, key=lambda o: abs(o[0]))
        issues.append(f"Whisper hears {len(off)} of {len(found)} lines away from their beats "
                      f"(\"{text[:14]}\" stamped at {at - clip_start:.0f}s, heard at {at - d - clip_start:.0f}s)")
        badness += sum(min(30.0, abs(o[0])) for o in off)
    when = sorted(u[0] for u in unheard)
    together = any(when[i + WHISPER_CHECK_UNHEARD_LINES - 1] - when[i] <= WHISPER_CHECK_UNHEARD_WINDOW_SEC
                   for i in range(len(when) - WHISPER_CHECK_UNHEARD_LINES + 1))
    if len(unheard) >= WHISPER_CHECK_UNHEARD_LINES and (len(unheard) >= WHISPER_CHECK_UNHEARD_SHARE * long_lines
                                                    or together):
        at, text, around = unheard[0]
        issues.append(f"Whisper does not hear {len(unheard)} of {long_lines} lines (\"{text[:14]}\" at "
                      f"{at - clip_start:.0f}s; it hears \"{around[:14]}\")")
        badness += 8.0 * len(unheard)
    # speech no line accounts for: placed long lines cover their own words, short lines the time around them
    lone = [k for k, t in enumerate(times)
            if not used[k] and probs[k] >= 0.5 and clip_start + 2.0 <= t <= clip_start + clip_dur - 2.0
            and not any(s <= t <= e for s, e in short)]
    most, most_span = 0.0, None
    for a, k0 in enumerate(lone):
        group = [k for k in lone[a:] if times[k] - times[k0] <= 10.0]
        units = _v64_units("".join(stream[k] for k in group))
        if units > most:
            most, most_span = units, (times[k0], times[group[-1]], "".join(stream[k] for k in group))
    if most >= WHISPER_CHECK_SKIPPED_UNITS:
        t0, t1, text = most_span
        issues.append(f"Whisper hears speech that no beat carries at {t0 - clip_start:.0f}-{t1 - clip_start:.0f}s "
                      f"(\"{text[:14]}\")")
        badness += most
    return issues, badness


class WhisperReference:
    """faster-whisper loaded on first use, transcribing one analysis clip at a time (cached as JSON
    beside the Gemini clip). Any failure turns the check off for this run instead of stopping it."""

    def __init__(self, src, cache_dir, model_name="medium", device="cuda", compute_type="int8_float16"):
        self.src, self.cache_dir = Path(src), Path(cache_dir)
        self.model_name, self.device, self.compute_type = model_name, device, compute_type
        self.model = None
        self.off_reason = ""
        self._lock = threading.Lock()        # one GPU model: parallel clip workers take turns
        try:
            self.language = load_json(self.cache_dir / "whisper_language.json").get("language") or None
        except Exception:
            self.language = None

    def _load(self):
        if self.model is not None or self.off_reason:
            return
        if WhisperModel is None:
            self.off_reason = "faster-whisper is not installed"
            return
        tries = [(self.model_name, self.device, self.compute_type)]
        if self.device != "cpu":
            tries.append(("small", "cpu", "int8"))
        for name, device, compute in tries:
            try:
                self.model = WhisperModel(name, device=device, compute_type=compute, local_files_only=True)
                print(f"    [WHISPER CHECK] {name} ready on {device}", flush=True)
                return
            except Exception as exc:
                raise_if_terminal(exc)
                print(f"    [WHISPER CHECK] {name} on {device} unavailable: {str(exc).splitlines()[0][:120]}", flush=True)
        self.off_reason = "no Whisper model could be loaded"

    def _audio(self, start, dur):
        import numpy as np
        raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{start:.3f}", "-t", f"{dur:.3f}", "-i", str(self.src),
                              "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-"],
                             capture_output=True, check=True).stdout
        return np.frombuffer(raw, np.int16).astype(np.float32) / 32768.0

    def words(self, tag, start, dur):
        """Whisper's words in start..start+dur as [{"t", "e", "w", "p"}] (file times), or None when off."""
        cache = self.cache_dir / f"{tag}_whisper.json"
        try:
            cached = load_json(cache)
            if cached.get("version") == 1:
                return cached.get("words") or []
        except Exception:
            pass
        with self._lock:
            return self._transcribe(tag, start, dur, cache)

    def _transcribe(self, tag, start, dur, cache):
        self._load()
        if self.off_reason:
            return None
        try:
            audio = self._audio(start, dur)
            if self.language is None:
                language, prob, _all = self.model.detect_language(audio, vad_filter=True)
                if prob >= 0.6:
                    self.language = language
                    save_json(self.cache_dir / "whisper_language.json", {"language": language, "probability": round(prob, 3)})
            kw = {"initial_prompt": WHISPER_ZH_PROMPT} if self.language == "zh" else {}
            segments, _info = self.model.transcribe(audio, language=self.language, beam_size=5, vad_filter=True,
                                                    word_timestamps=True, condition_on_previous_text=True, **kw)
            words = []
            for seg in segments:
                if seg.compression_ratio > 2.4 or (seg.no_speech_prob > 0.6 and seg.avg_logprob < -1.0):
                    continue          # a repeating hallucination / not speech
                for w in seg.words or []:
                    if (w.word or "").strip():
                        words.append({"t": round(start + w.start, 2), "e": round(start + w.end, 2),
                                      "w": w.word.strip(), "p": round(float(w.probability), 2)})
        except Exception as exc:
            raise_if_terminal(exc)
            print(f"    [WHISPER CHECK] {tag}: transcription failed ({str(exc).splitlines()[0][:120]}) -> not checked",
                  flush=True)
            return None
        save_json(cache, {"version": 1, "model": self.model_name, "language": self.language, "start": start,
                          "dur": dur, "words": words})
        return words

    def close(self):
        self.model = None


def _v64_new_clip_answer(pool, types, src, file_clips, ci, clip_start, clip_dur, registry, context, cache_json,
                         video_fps, clip_seconds, keep_clips):
    """Ask Gemini for one clip: the whole clip, checked (V6.3), or two 30 s halves for flash-lite and when
    every model that answered failed while others were busy. Returns (data, model, key, issues); the
    answer is not reconciled with the registry yet (the caller does that, in clip order)."""
    clip_file = file_clips / f"clip_{ci:04d}.mp4"
    _extract_video_clip(src, clip_file, clip_start, clip_dur)
    size_mb = clip_file.stat().st_size/(1024*1024)
    if size_mb >= 19.5:
        raise RuntimeError(f"V6 analysis clip is {size_mb:.1f}MB; reduce --video-clip-seconds")
    prompt = _gemini_timeline_prompt_v60(src.name, clip_start, clip_dur, registry, context)
    contents = [VideoClip(clip_file, video_fps), prompt]
    can_halve = clip_dur >= 2 * TIMELINE_CHECK_MIN_CLIP_SEC
    # a cached flash-lite answer was just rejected: go straight to the halves
    rejected = cache_json.with_suffix(".rejected.json")
    halves = can_halve and rejected.exists() and _v63_weak_model(_v63_json_field(rejected, "model"))
    # only flash-lite is free: its whole-clip answer would be asked again as halves anyway (2026-10-03: 25 of
    # 90 clips paid for a whole-clip answer that was thrown away)
    halves = halves or (can_halve and _only_lite_free(pool))
    data, model, key, issues = None, "", "", []
    if not halves:
        try:
            data, model, key, issues = pool.generate_json_checked(
                contents, GEMINI_TIMELINE_SCHEMA_V60,
                lambda d: _v63_clip_check(d, clip_dur, clip_start, context),
                label=f"clip {ci + 1}", temperature=0.0, max_output_tokens=24576)
            # flash-lite drifts on a 55 s clip even when the answer looks complete
            # (武朝大帝 sword scene: ~37 s early); on 30 s halves it was exact.
            halves = can_halve and _v63_weak_model(model)
        except RuntimeError as exc:
            raise_if_terminal(exc)
            if "run again later" not in str(exc) or not can_halve:
                raise
            halves = True
    if halves:
        # V6.3: two shorter halves (sharing 5 s), each checked (and split again if needed), then joined.
        print(f"    [TIMELINE HALVES] clip {ci + 1}: asking for two 30 s halves", flush=True)
        data, model, key, issues = _v63_ask_parts(
            pool, types, src, file_clips, f"clip {ci + 1}", src.name, clip_start, clip_dur, registry,
            video_fps, clip_seconds, 2, keep_clips)
        # the halves never saw the previous beats: a repeated line here was really said again
        issues = issues + _v63_clip_check(data, clip_dur, clip_start, context)[0]
    _release_video(pool, clip_file)
    if not keep_clips:
        try: clip_file.unlink()
        except Exception: pass
    return data, model, key, issues


def _v64_clip_timeline(pool, types, src, file_cache, file_clips, ci, n_clips, clip_start, clip_dur, registry,
                       context, whisper, review, video_fps, clip_seconds, keep_clips, fresh=False):
    """One clip's Gemini timeline: the cached answer (checked again, V6.3) or a new one, then the Whisper
    check (V6.4). Runs in a worker: the answer is cached as Gemini gave it; the caller gives it registry
    IDs in clip order (_v64_reconcile_clip)."""
    cache_json = file_cache / f"clip_{ci:04d}_v60.json"
    print(f"  Clip {ci+1}/{n_clips} [{srt_time(clip_start)} -> {srt_time(clip_start+clip_dur)}]")
    data = None
    if cache_json.exists() and not fresh:
        try:
            data = _v63_cached_clip(cache_json, clip_dur, clip_start, context)   # V6.3: re-checked on every resume
            if data is not None:
                print(f"    [RESUME] Gemini timeline beats={len(data.get('beats') or [])}")
        except Exception:
            data = None
    if data is None:
        data, model, key, issues = _v64_new_clip_answer(pool, types, src, file_clips, ci, clip_start, clip_dur,
                                                        registry, context, cache_json, video_fps, clip_seconds,
                                                        keep_clips)
        save_json(cache_json, {"version":"v6.0-gemini-only-timeline", "payload":data, "model":model, "key":key,
                               "check_issues": issues, "check_accepted": bool(issues)})
        print(f"    [GEMINI TIMELINE OK] {model} {key} | beats={len(data.get('beats') or [])}")
    if whisper is not None:
        data = _v64_whisper_step(whisper, pool, types, src, file_clips, ci, clip_start, clip_dur, data,
                                 cache_json, context, registry, None, video_fps, clip_seconds, keep_clips, review)
    return data


def _v64_reconcile_clip(cache_json, data, registry, source_name, clip_start):
    """Registry IDs for one clip answer (clips in order). New people's IDs are written into the clip's
    cache too, so a resume does not number the same people again."""
    before = json.dumps(data, ensure_ascii=False, sort_keys=True)
    data = _reconcile_characters(data, registry, source_name, clip_start)
    if json.dumps(data, ensure_ascii=False, sort_keys=True) != before:
        try:
            cached = load_json(cache_json)
            cached["payload"] = data
            save_json(cache_json, cached)
        except Exception:
            pass
    return data


def _v64_routes(pool, types, src, clip_dir, ci, clip_start, clip_dur, registry, context, video_fps, clip_seconds,
                keep_clips, current_model):
    """Other ways to ask for a clip Whisper disagrees with, as (name, ask) with ask() ->
    (data, model, key, issues): the whole clip from the stronger models that are not resting,
    then two halves, then three thirds (parts are asked without the previous beats)."""
    tag = f"clip {ci + 1}"
    strong = [m for m in pool.models if "lite" not in m.lower() and pool._cooldown_until.get(m, 0) <= time.time()]

    def whole():
        clip_file = Path(clip_dir) / f"clip_{ci:04d}_recheck.mp4"
        _extract_video_clip(src, clip_file, clip_start, clip_dur)
        try:
            contents = [VideoClip(clip_file, video_fps),
                        _gemini_timeline_prompt_v60(src.name, clip_start, clip_dur, registry, context)]
            data, model, key = pool.generate_json(contents, GEMINI_TIMELINE_SCHEMA_V60, only_models=strong,
                                                  temperature=0.0, max_output_tokens=24576)
        finally:
            _release_video(pool, clip_file)
            if not keep_clips:
                clip_file.unlink(missing_ok=True)
        return data, model, key, _v63_clip_check(data, clip_dur, clip_start, context)[0]

    routes = []
    if strong and str(current_model or "") not in strong:
        routes.append(("whole clip, stronger models", whole))
    if clip_dur >= 2 * TIMELINE_CHECK_MIN_CLIP_SEC:
        for parts, name in ((2, "halves"), (3, "thirds")):
            routes.append((name, lambda parts=parts: _v63_ask_parts(
                pool, types, src, clip_dir, tag, src.name, clip_start, clip_dur, registry, video_fps, clip_seconds,
                parts, keep_clips)))
    return routes


def _v64_whisper_step(whisper, pool, types, src, clip_dir, ci, clip_start, clip_dur, data, cache_json, context,
                      registry, registry_path, video_fps, clip_seconds, keep_clips, review):
    """Check one clip's timeline against Whisper. When they disagree, ask Gemini again (see _v64_routes)
    and keep the answer Whisper agrees with best; a clip still disagreeing goes on the review list.
    The outcome is cached, so a resume does not ask again. Returns the payload to use."""
    try:
        cached = load_json(cache_json)
    except Exception:
        cached = {}
    entry = {"clip": ci + 1, "source_file": src.name, "start": clip_start, "end": clip_start + clip_dur}
    if cached.get("whisper_checked") == WHISPER_CHECK_VERSION:
        if cached.get("whisper_issues"):
            review.append({**entry, "issues": cached["whisper_issues"], "model": cached.get("model")})
        return data
    words = whisper.words(f"clip_{ci:04d}", clip_start, clip_dur)
    if words is None:
        return data
    issues, badness = _v64_whisper_check(data, clip_start, clip_dur, words)
    if not issues:
        return data
    model = cached.get("model")
    print(f"    [WHISPER CHECK] clip {ci + 1} {model}: {'; '.join(issues)} -> asking again", flush=True)
    best = (badness, data, model, cached.get("key"), issues, cached.get("check_issues") or [], False)
    for name, ask in _v64_routes(pool, types, src, clip_dir, ci, clip_start, clip_dur, registry, context, video_fps,
                                 clip_seconds, keep_clips, model):
        try:
            cand, cmodel, ckey, hard = ask()
        except RuntimeError as exc:
            raise_if_terminal(exc)
            print(f"    [WHISPER CHECK] clip {ci + 1} {name}: {str(exc).splitlines()[0][:140]}", flush=True)
            continue
        iss, bad = _v64_whisper_check(cand, clip_start, clip_dur, words)
        print(f"    [WHISPER CHECK] clip {ci + 1} {name} {cmodel}: {'; '.join(iss) or 'agrees with Whisper'}",
              flush=True)
        if bad < best[0]:
            best = (bad, cand, cmodel, ckey, iss, hard, True)
        if not iss:
            break
    _bad, data, model, key, issues, hard, new = best
    if new and registry_path is not None:     # parallel workers: the caller reconciles in clip order
        data = _reconcile_characters(data, registry, src.name, clip_start)
        save_json(registry_path, registry)
    save_json(cache_json, {"version": "v6.0-gemini-only-timeline", "payload": data, "model": model, "key": key,
                           "check_issues": hard, "check_accepted": bool(hard),
                           "whisper_issues": issues, "whisper_checked": WHISPER_CHECK_VERSION})
    if issues:
        review.append({**entry, "issues": issues, "model": model})
        print(f"    [WHISPER CHECK] clip {ci + 1}: kept the closest answer ({model}); listed for review", flush=True)
    return data


def _v64_write_review(review, out, whisper_off="", video=True):
    """TIMELINE_REVIEW.txt: clips Whisper still disagrees with, at their place in the finished video
    (video=False, a script-only run: at their place in the source)."""
    path = Path(out) / "TIMELINE_REVIEW.txt"
    if whisper_off:
        path.write_text(f"Whisper timing check was off: {whisper_off}\n", encoding="utf-8")
        return path
    if not review:
        path.write_text("Whisper timing check: every clip agrees with Whisper.\n", encoding="utf-8")
        return path
    try:
        if not video:
            raise FileNotFoundError("script only: no rendered video")
        report = load_json(Path(out) / "smart_sync_thiha_28" / "SMART_SYNC_REPORT.json")
        num, _sep, den = str(report.get("fps") or "30").partition("/")
        fps = float(num) / float(den or 1)
        blocks = report.get("blocks") or []
    except Exception:
        fps, blocks = 30.0, []
    placed, pos = [], 0.0
    for b in blocks:
        dur = int(b.get("frames") or 0) / fps
        placed.append((str(b.get("source_file") or ""), float(b.get("source_start_sec") or 0.0),
                       float(b.get("source_end_sec") or 0.0), pos, pos + dur))
        pos += dur

    def clock(t):
        t = max(0.0, t)
        return f"{int(t // 3600)}:{int(t % 3600 // 60):02d}:{int(t % 60):02d}"

    lines = [f"Whisper timing check: {len(review)} clip(s) still disagree with Gemini after asking again.",
             ("Look at these places in the finished video (narration may come early or late there):" if video else
              "Check the script at these places of the source (lines may be missing, misplaced or invented):"), ""]
    for r in review:
        hits = [p for p in placed if p[0] == r["source_file"] and p[2] > r["start"] and p[1] < r["end"]]
        where = (f"video {clock(hits[0][3])}-{clock(hits[-1][4])} | " if hits else "video ? | ") if video else ""
        lines.append(f"{where}source {clock(r['start'])}-{clock(r['end'])} | clip {r['clip']} | {r.get('model')}")
        for issue in r["issues"]:
            lines.append(f"    {issue}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


# Studio "Script only": the story without voice or video. Paragraphs break where the footage has
# a pause of a few seconds; the timed copy marks every 15 minutes for reading long videos in parts.
SCRIPT_PARAGRAPH_GAP_SEC = 6.0
SCRIPT_PARAGRAPH_MAX_LINES = 8
SCRIPT_CHAPTER_SEC = 15 * 60.0


BURMESE_SENTENCE_END = re.compile(r"(?:တယ်|ပြီ|ဘူး|မယ်|လား|လဲ|ပေါ့|နော်|ပါ|ဗျ|ကွ)$")


def _v64_sentence_stop(text):
    """Script only: a Burmese fragment that ends a sentence (…တယ် / …ပြီ / …ဘူး …) but has no ။ gets one, so the
    paragraphs read as sentences (flash-lite left them out, 2026-10-02). A fragment that runs on into the next
    one (Flow: …ပြီး, …တော့) is left as it is."""
    if OUTPUT_LANGUAGE != "my" or not text or text[-1] in "။၊?!":
        return text
    return text + "။" if BURMESE_SENTENCE_END.search(text) else text


def _v64_write_script(sync_blocks, out):
    """NARRATOR_SCRIPT.txt (the narration in paragraphs) and NARRATOR_SCRIPT_TIMED.txt (each paragraph
    with its source time, a heading every 15 minutes). Returns both paths."""
    def hms(t):
        t = int(max(0.0, t))
        return f"{t // 3600:02d}:{t % 3600 // 60:02d}:{t % 60:02d}"

    paragraphs = []          # [start, end, [fragments]]
    for b in sync_blocks:
        text = _v64_sentence_stop(str(b.get("narration_text") or "").strip())
        if not text:
            continue
        s, e = float(b.get("source_start_sec") or 0.0), float(b.get("source_end_sec") or 0.0)
        last = paragraphs[-1] if paragraphs else None
        if (last is None or s - last[1] >= SCRIPT_PARAGRAPH_GAP_SEC or len(last[2]) >= SCRIPT_PARAGRAPH_MAX_LINES
                or int(s // SCRIPT_CHAPTER_SEC) != int(last[0] // SCRIPT_CHAPTER_SEC)):
            paragraphs.append([s, e, [text]])
        else:
            last[1] = max(last[1], e)
            last[2].append(text)
    timed, chapter = [], None
    for s, _e, texts in paragraphs:
        c = int(s // SCRIPT_CHAPTER_SEC)
        if c != chapter:
            chapter = c
            timed.append(f"===== {hms(c * SCRIPT_CHAPTER_SEC)} – {hms((c + 1) * SCRIPT_CHAPTER_SEC)} =====")
        timed.append(f"[{hms(s)}] " + " ".join(texts))
    script, script_timed = Path(out) / "NARRATOR_SCRIPT.txt", Path(out) / "NARRATOR_SCRIPT_TIMED.txt"
    script.write_text("\n\n".join(" ".join(p[2]) for p in paragraphs) + "\n", encoding="utf-8-sig")
    script_timed.write_text("\n\n".join(timed) + "\n", encoding="utf-8-sig")
    return script, script_timed


def _v64_file_words(file_cache):
    """Every Whisper word of one source file, from its per-clip caches (clip overlaps kept once)."""
    words = []
    for f in sorted(Path(file_cache).glob("clip_*_whisper.json")):
        try:
            clip_words = load_json(f).get("words") or []
        except Exception:
            continue
        last = float(words[-1]["t"]) if words else -1.0
        words.extend(w for w in clip_words if float(w.get("t") or 0.0) > last + 0.01)
    return words


# Neighbouring beats with the same line: on 武朝大帝 35 pairs within 12 s. Whisper heard about ten
# of those lines only once (the 5 s overlap between analysis clips or halves gave them twice:
# "娘娘奴婢这次可吃尽苦头了" 18:16 and 18:20), so the narrator said them twice; the others it heard
# twice or more (a chorus, a line said again, an in-video recap) and they stay.
WHISPER_REPEAT_WINDOW_SEC = 12.0


def _v64_drop_repeated_lines(beats, words_by_file):
    """Beats minus the copies of a line Whisper hears only once: the beat stamped nearest to where
    Whisper heard it stays; when one beat's line holds the other's ("大舅哥辛苦了，回去休息吧" and
    "回去休息吧"), the longer beat stays. Lines Whisper hears twice or more, or not at all, are left alone."""
    import difflib
    streams = {name: _v64_stream(words) for name, words in (words_by_file or {}).items() if words}
    order = sorted(range(len(beats)), key=lambda i: (str(beats[i].get("source_file")), float(beats[i].get("file_start_sec") or 0.0)))
    drop = set()
    for pos, i in enumerate(order):
        a = beats[i]
        la = _v64_norm(a.get("source_dialogue"))
        if i in drop or _v64_units(la) < WHISPER_CHECK_MIN_UNITS or a.get("source_file") not in streams:
            continue
        ta = float(a.get("file_start_sec") or 0.0)
        for j in order[pos + 1:]:
            b = beats[j]
            tb = float(b.get("file_start_sec") or 0.0)
            if b.get("source_file") != a.get("source_file") or tb - ta > WHISPER_REPEAT_WINDOW_SEC:
                break
            lb = _v64_norm(b.get("source_dialogue"))
            if j in drop or _v64_units(lb) < WHISPER_CHECK_MIN_UNITS:
                continue
            if not (la in lb or lb in la or difflib.SequenceMatcher(None, la, lb).ratio() >= 0.8):
                continue
            stream, times, _probs = streams[a["source_file"]]
            lo = next((k for k, t in enumerate(times) if t >= ta - 6.0), len(times))
            hi = next((k for k, t in enumerate(times) if t > tb + 8.0), len(times))
            line = la if len(la) <= len(lb) else lb
            _r, heard, _span, spans = _v64_find_line(line, stream[lo:hi], times[lo:hi], ta)
            if heard is None:
                continue
            said = []
            for t in sorted(times[lo + s] for s, _e in spans):
                if not said or t - said[-1] > 1.5:
                    said.append(t)
            if len(said) != 1:
                continue
            if abs(len(la) - len(lb)) >= 2 and (la in lb or lb in la):
                gone = j if len(lb) < len(la) else i     # the longer beat also carries the other line
            else:
                gone = j if abs(tb - said[0]) > abs(ta - said[0]) else i
            drop.add(gone)
            kept = beats[i if gone == j else j]
            print(f"[WHISPER DEDUPE] {srt_time(float(beats[gone]['file_start_sec']))} "
                  f"\"{str(beats[gone].get('source_dialogue') or '')[:16]}\" dropped: Whisper hears it once, at "
                  f"{srt_time(said[0])} (kept the beat at {srt_time(float(kept['file_start_sec']))})", flush=True)
            if gone == i:
                break
    return [b for k, b in enumerate(beats) if k not in drop]


# Studio V6.4 name glossary. The automatic registry lumped different people under one ID on 武朝大帝
# (CHAR_011 = Dai Lian + Ning Song + Li Yi; CHAR_001 = the consort + the Empress Dowager), and the
# writer spelled names differently from part to part or left them in Latin letters ("Ning Song").
# One spelling per person is asked for once and kept beside the registry; edit the file to change one.
NAME_GLOSSARY_FILE = "NAME_GLOSSARY.json"
NAME_GLOSSARY_SCHEMA = {
    "type": "OBJECT",
    "properties": {"people": {"type": "ARRAY", "items": {
        "type": "OBJECT",
        "properties": {
            "name_source": {"type": "STRING"},
            "other_names": {"type": "ARRAY", "items": {"type": "STRING"}},
            "who": {"type": "STRING"},
            "name_target": {"type": "STRING"},
            "title_target": {"type": "STRING"},
        },
        "required": ["name_source", "who", "name_target"],
    }}},
    "required": ["people"],
}


GLOSSARY_NOT_NAMES = {
    "The", "A", "An", "His", "Her", "Their", "Your", "Majesty", "Emperor", "Empress", "Dowager", "Imperial", "Grand",
    "Chief", "Senior", "Elderly", "Young", "Old", "Official", "Officials", "Eunuch", "Minister", "Prince", "Princess",
    "Consort", "Guard", "Guards", "Commander", "Captain", "Jinyiwei", "Seventh", "Palace", "Hall", "Court", "Lord",
    "Lady", "General", "King", "Queen", "Cabinet", "Elder", "Councilor", "Subordinate", "Chubby", "Close", "Up",
}


GLOSSARY_NAME_EXTRA = {"Highness", "Your", "Her", "His", "Sir", "Miss", "Mr", "Mrs", "Madam", "Master", "Of", "The"}


def _v64_name_keys(entry):
    """Romanized personal names of a glossary entry ("Gao Shulin" -> "gaoshulin"); role and title words do not
    count, and a single word does not either (Scribe / Princess / Guard belong to anyone)."""
    keys = set()
    for name in [entry.get("name_source")] + list(entry.get("other_names") or []):
        words = [w for w in re.split(r"[\s\-·.]+", str(name or "")) if w and w.isascii() and w[:1].isalpha()]
        words = [w for w in words if w.capitalize() not in GLOSSARY_NOT_NAMES | GLOSSARY_NAME_EXTRA]
        if len(words) >= 2:
            keys.add("".join(w.lower() for w in words))
    return keys


def _v64_same_person(entry, others):
    """The entry in `others` that is the same person under another written name, or None (2026-10-31, S9: Gemini
    heard 高树林 in part 1 and 高士林 in part 2 - both "Gao Shulin / Gao Shilin, the Emperor's secretary" - and the
    second got its own spelling ကောင်းရှီလင် next to ကောင်းရှုလင်)."""
    mine = _v64_name_keys(entry)
    for other in others:
        if other.get("name_source") != entry.get("name_source") and mine & _v64_name_keys(other):
            return other
    return None


def _v64_glossary_prompt(registry, beats, language_label, cast_checked=False):
    dialogue = [f"{b.get('speaker') or '?'}: {str(b.get('source_dialogue')).strip()}"
                for b in beats if str(b.get("source_dialogue") or "").strip()]
    # names in Gemini's English visual notes ("presses the sword against Zhu Hong's neck"), one example each
    named = {}
    for b in beats:
        visual = str(b.get("visual_action") or "")
        for m in re.finditer(r"\b[A-Z][a-z]+(?:[ -][A-Z][a-z]+)+\b", visual):
            words = [w for w in re.split(r"[ -]", m.group(0)) if w not in GLOSSARY_NOT_NAMES]
            if words:
                named.setdefault(" ".join(words), visual[:160])
    notes = [f"- {name}: {example}" for name, example in named.items()]
    title_hint = (" (ဧကရာဇ်, မင်းသမီး, သခင်ကြီး - not ပိရှ for 陛下)" if "urmese" in language_label else "")
    heading = ("CAST (checked across the whole video: one ID = one person; the speaker IDs below use it)" if cast_checked
               else "CHARACTER REGISTRY (automatic; one ID sometimes lumps several different people together)")
    return f"""
You prepare the NAME GLOSSARY for a {language_label} storytelling narration of a drama.

{heading}:
{json.dumps(_compact_registry(registry), ensure_ascii=False)}

ALL DIALOGUE (speaker ID: line), in story order:
{chr(10).join(dialogue)[:80000]}

NAMES USED IN THE VISUAL NOTES (name: one example):
{chr(10).join(notes)[:20000]}

The DIALOGUE is the authority for names: find every personal name spoken in it (for a Chinese drama names like
李易, 宁嵩, 陈平, 夏云) and list each distinct person exactly once. Never merge two names into one entry, even if
the registry gives them one ID; a person known only by an English name in the visual notes is listed too.
For each person give:
- name_source: the name written as it is spoken in the dialogue (Chinese characters for a Chinese drama: 李易)
- other_names: romanizations / other forms used above (for example Li Yi), and the registry name if it differs
- who: who they are and how to recognize them in the story (role, look, a key scene), one short phrase
- name_target: the name written in {language_label} script the way {language_label} storytellers transliterate it;
  short and easy to say; never Latin letters for a non-Latin script
- title_target: only for people the story mostly calls by a title (the Emperor / Your Majesty, the Empress Dowager):
  that title in {language_label}. The narrator then keeps the title and uses the name only where a line says it.
- A title or honorific is not a name (陛下 Your Majesty, 殿下 Your Highness, 公主 princess, 大人 lord): when the
  dialogue calls someone only by a title, name_target is that title TRANSLATED into {language_label}{title_hint},
  never the sound of the Chinese.
- Keep one person in one entry: the same person heard with slightly different characters (高树林 / 高士林) gets one
  spelling.
Return JSON only.
""".strip()


def _v64_name_glossary(pool, beats, registry, path, language, cast_checked=False):
    """[{"name_source", "other_names", "who", "name_target"}] for `language`, asked for once and kept in
    `path` (shared by every file of a series). It is asked again only when the registry gained people;
    spellings already in the file (maybe edited by hand) are kept. Never stops the run.
    cast_checked (V6.6): `registry` is the cast pass's cast; an earlier entry keeps only its spelling (its
    other names / who came from the lumped registry)."""
    path = Path(path)
    try:
        data = load_json(path) if path.exists() else {}
    except Exception:
        data = {}
    entry = data.get(language) or {}
    old = [p for p in entry.get("people") or [] if isinstance(p, dict) and p.get("name_source")]
    if old and set(registry) <= set(entry.get("registry_ids") or []):
        return old
    import unicodedata
    label = _languages().get(language)["label"]
    latin_ok = _languages().get(language)["script"] == _languages().LATIN     # English, Spanish, ...
    prompt = _v64_glossary_prompt(registry, beats, label, cast_checked)
    people, kept, model = [], {p["name_source"]: p for p in old}, ""
    # flash-lite mixes Thai / Khmer letters into a Burmese name now and then (夏云 -> ရှာယွิน on 武朝大帝):
    # such names are asked for once more
    for attempt in (1, 2):
        try:
            answer, model, _key = pool.generate_json(prompt, NAME_GLOSSARY_SCHEMA, temperature=0.1, max_output_tokens=8192)
        except Exception as exc:
            raise_if_terminal(exc)
            print(f"[NAME GLOSSARY] not made ({str(exc).splitlines()[0][:120]}); the writer uses what it has", flush=True)
            break
        skipped = []
        for p in answer.get("people") or []:
            if not isinstance(p, dict):     # a repaired (cut-off) answer can hold a bare list (S9 s9-2, 2026-10-31)
                continue
            source = str(p.get("name_source") or "").strip()
            # invisible format characters (zero-width joiners and the like) come back now and then
            name = "".join(ch for ch in str(p.get("name_target") or "") if unicodedata.category(ch) != "Cf").strip()
            if not name or not source or any(x["name_source"] == source for x in people):
                continue
            if _story_text_unicode_issues(name) or (re.search(r"[A-Za-z]", name) and not latin_ok):
                print(f"[NAME GLOSSARY] skipped {source} -> {name}: not in the narration script", flush=True)
                skipped.append(source)
                continue
            title = "".join(ch for ch in str(p.get("title_target") or "") if unicodedata.category(ch) != "Cf").strip()
            if title and (_story_text_unicode_issues(title) or (re.search(r"[A-Za-z]", title) and not latin_ok)):
                title = ""
            fresh = {"name_source": source, "other_names": p.get("other_names") or [], "who": p.get("who") or "",
                     "name_target": name, **({"title_target": title} if title else {})}
            earlier = kept.pop(source, None)
            twin = None if earlier else _v64_same_person(fresh, people + list(kept.values()))
            if twin:            # the same person under other characters: the spelling the series already uses
                print(f"[NAME GLOSSARY] {source} is {twin['name_source']} ({', '.join(sorted(_v64_name_keys(fresh) & _v64_name_keys(twin)))})"
                      f": spelled {twin['name_target']} as before", flush=True)
                fresh["name_target"] = twin["name_target"]
                if twin.get("title_target"):
                    fresh["title_target"] = twin["title_target"]
            if earlier and cast_checked:     # keep the spelling the series already uses, not the old lumped notes
                earlier = {**fresh, "name_target": earlier.get("name_target") or name,
                           **({"title_target": earlier["title_target"]} if earlier.get("title_target") else {})}
            people.append(earlier or fresh)
        skipped = [s for s in skipped if not any(x["name_source"] == s for x in people)]
        if not skipped:
            break
        prompt += (f"\n\nYour last answer wrote these names with letters of another script: {', '.join(skipped)}. "
                   f"Write every name_target in {label} letters only.")
    if not people and not old:
        return old
    people.extend(kept.values())          # hand-made or earlier entries the new answer did not mention
    data[language] = {"people": people, "registry_ids": sorted(registry), "model": model,
                      "made": time.strftime("%Y-%m-%d %H:%M")}
    save_json(path, data)
    print(f"[NAME GLOSSARY] {len(people)} name(s) in {label} -> {path}", flush=True)
    return people


def _v64_glossary_text(people, cast_checked=False):
    if not people:
        return ""
    rows = []
    for p in people:
        other = ", ".join(str(x) for x in (p.get("other_names") or []) if str(x).strip())
        title = str(p.get("title_target") or "").strip()
        rows.append(f"- {p['name_source']}{' / ' + other if other else ''} ({str(p.get('who') or '').strip()}) = {p['name_target']}"
                    + (f"; call them {title} as the story does, the name only where a line says {p['name_source']}"
                       if title else ""))
    if cast_checked:        # V6.6: the cast pass made every ID one person
        return ("NAME GLOSSARY (one spelling per person). The cast above was checked across the whole video: each ID "
                "is one person, and a beat's speaker / actors / targets IDs say who is who. When the story needs a "
                "name, use the name of the person behind that ID, spelled exactly as here and never in Latin letters; "
                "a person without a personal name is called by their role (the maid, the father, the system). Keep a "
                "title (the Emperor, the Empress Dowager) where the beat uses one. Never give one person's name to "
                "another:\n" + "\n".join(rows))
    # 武朝大帝 part 1: with a glossary but no rule for doubt, the writer named the consort in the first scene
    # after the Empress Dowager (the registry had lumped the two together). A wrong name is worse than none.
    return ("NAME GLOSSARY (one spelling per person). The registry above sometimes lumps different people under one "
            "ID, so never take a name from the registry or the speaker ID alone: write a personal name only when the "
            "beat's own dialogue or visual note names that person, or the person is unmistakably the one described "
            "below; otherwise call them by their role (the consort, the minister, the eunuch). Keep a title (the "
            "Emperor, the Empress Dowager) where the beat uses one. Whenever you write a personal name, spell it "
            "exactly as here, never in Latin letters:\n" + "\n".join(rows))


# V6.6 cast pass (2026-10-23). Since 2026-10-03 six clips are analysed at once, and a clip sees neither the beats
# before it nor the people the clips still in flight found. One person then gets several CHAR IDs and one ID
# gathers several people (穿越修仙界 10-19: the heroine under 5 IDs, CHAR_010 = heroine + guard + her little
# brother), and the writer named the wrong person; the one-clip-at-a-time run (武朝大帝 10-02) had a clean
# registry. Each clip's own answer is right about its people (names from on-screen text, looks, roles); only
# the IDs across clips are not. So after the analysis a strong model reads the clips in story order, ~17 min
# at a time with the cast so far (like the old run), and says who each clip's IDs are. The beats get these
# cast IDs; the glossary and the writer get the cast instead of the registry. Text only: ~10 requests for 2.5 h.
CAST_PASS_ON = True                 # --no-cast-pass: the registry as before
CAST_PASS_CLIPS = 12                # clips per request (~10 min of video); a cut-off answer is asked again in halves
CAST_PASS_PLACED = 0.8              # an answer that places fewer of the clips' IDs than this is asked again
CAST_PASS_FILE = "CAST_PASS.json"   # work folder: the cast and each clip's ID -> cast ID, reused while the clips match
CAST_FILE = "CAST.json"             # beside a series registry: the cast so far, the next file starts from it
CAST_PASS_VERSION = "v66-cast-3"     # 2: importance + addressee; 3: only new/changed people back, halves
_CHAR_ID = re.compile(r"\bCHAR_\d{3,}\b")

CAST_PASS_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "cast": {"type": "ARRAY", "items": {"type": "OBJECT", "properties": {
            "cast_id": {"type": "STRING"}, "name": {"type": "STRING"},
            "other_names": {"type": "ARRAY", "items": {"type": "STRING"}},
            "gender": {"type": "STRING"}, "look": {"type": "STRING"}, "role": {"type": "STRING"},
            "importance": {"type": "STRING"}},
            "required": ["cast_id", "name", "gender", "look", "role", "importance"]}},
        "mapping": {"type": "ARRAY", "items": {"type": "OBJECT", "properties": {
            "clip": {"type": "INTEGER"}, "id": {"type": "STRING"}, "cast_id": {"type": "STRING"}},
            "required": ["clip", "id", "cast_id"]}},
    },
    "required": ["cast", "mapping"],
}


def _v66_clip_ids(beats):
    """The CHAR IDs one clip's beats use, in order of first use."""
    ids = []
    for b in beats:
        for value in ([b.get("speaker")] + list(b.get("actors") or []) + list(b.get("targets") or [])
                      + list(b.get("addressee") or [])):
            for cid in _CHAR_ID.findall(str(value or "")):
                if cid not in ids:
                    ids.append(cid)
    return ids


def _v66_clip_block(n, beats, people, registry):
    """One clip for the cast prompt: its people as that clip described them, then a few of its lines."""
    start = min(float(b.get("global_start_sec") or 0.0) for b in beats)
    end = max(float(b.get("global_end_sec") or 0.0) for b in beats)
    lines = [f"CLIP {n} ({srt_time(start)[:8]} - {srt_time(end)[:8]})"]
    described = {str(p.get("character_id")): p for p in people or [] if p.get("character_id")}
    for cid in list(described) + [c for c in _v66_clip_ids(beats) if c not in described]:
        p = described.get(cid)
        if p:
            lines.append(f"  {cid}: {str(p.get('name') or '?').strip()} | look: {str(p.get('visual_description') or '')[:150]}"
                         f" | role: {str(p.get('role_hint') or '')[:100]} | evidence: {str(p.get('identity_evidence') or '')[:100]}")
        else:          # used in the beats but not described by this clip: only the (maybe lumped) registry entry
            r = registry.get(cid) or {}
            lines.append(f"  {cid}: (not described in this clip; registry, may lump people: "
                         f"{str(r.get('canonical_name') or '?')} / {', '.join(map(str, (r.get('aliases') or [])[:4]))})")
    talk = [b for b in beats if str(b.get("source_dialogue") or "").strip()][:10]
    for b in talk:
        said = str(b.get("dialogue_meaning") or b.get("source_dialogue") or "").strip()
        to = ", ".join(map(str, b.get("addressee") or []))
        lines.append(f"    {b.get('speaker') or '?'}{' to ' + to if to else ''} says: {said[:110]}")
    for b in [b for b in beats if str(b.get("visual_action") or "").strip()][:4]:
        lines.append(f"    [{', '.join(map(str, b.get('actors') or []))}] {str(b['visual_action'])[:110]}")
    return "\n".join(lines)


def _v66_cast_prompt(cast, blocks, language_label):
    return f"""
You are the casting editor for a {language_label} storytelling recap of a long video. An automatic analysis looked
at the video in short clips, several at once, so its character IDs (CHAR_###) are NOT reliable across clips: the
same person may have different IDs in different clips, and one ID may be used for different people in different
clips. Inside one clip an ID is one person, and what a clip says about its people (names from on-screen text or
dialogue, looks, roles) is usually right.

CAST SO FAR (people identified earlier; keep their cast_id):
{json.dumps(cast, ensure_ascii=False)}

THE NEXT CLIPS IN STORY ORDER (each clip's people: ID, name or label in that clip, look, role, evidence; then some
of its lines and actions with the IDs that clip used):
{chr(10).join(blocks)}

Decide who each clip's IDs really are:
- The same person in different clips gets the same cast_id. Match by name first (on-screen text, how others call
  them), then by look (gender, age, hair, clothes), role and relations. A label like "Host", "Young Woman",
  "Eldest Miss", "Father" or "Handsome Man" is not a name: find from the clip who it is.
- A person not in the cast yet gets a new cast_id (the next free number, format P001). A system, spirit, pet or
  creature is its own entry. An unnamed minor person gets an entry described by look and role ("maid in green");
  the same unnamed person in several clips keeps one entry.
- Never put two different people under one cast_id, and never give a person a name or title another person is
  called by.
Return:
- cast: the people who are NEW in these clips and earlier people whose details you correct (unchanged earlier
  people may be left out; they are kept), each with cast_id, name (the personal name as spoken or shown,
  in the original script or pinyin as given; "" if never named), other_names (only names and titles THIS person is
  called), gender (male / female / unknown), look (one short phrase), role (who they are to the others),
  importance: "main" (the leads and the people the story keeps coming back to: hero, heroine, their family,
  master, sworn brother, main villain), "supporting" (comes back or changes the plot, even if briefly: a traitor,
  a rival) or "minor" (a scene or two with no lasting part: a shopkeeper, a passing guard).
- mapping: one row for EVERY ID listed under every clip above: the clip number (as written after CLIP), the ID,
  its cast_id.
JSON only.
""".strip()


def _v66_cast_registry(cast):
    """The cast in the registry's shape, for the glossary and the writer (_compact_registry)."""
    reg = {}
    for p in cast:
        cid = str(p.get("cast_id") or "")
        if not cid:
            continue
        look = ", ".join(x for x in (str(p.get("gender") or "").strip(), str(p.get("look") or "").strip()) if x)
        role = str(p.get("role") or "").strip()
        importance = str(p.get("importance") or "").strip().lower()
        reg[cid] = {"character_id": cid, "canonical_name": str(p.get("name") or "").strip(),
                    "aliases": [str(x) for x in p.get("other_names") or [] if str(x).strip()],
                    "visual_description": look, "role_hint": f"{importance}: {role}" if importance else role,
                    "importance": importance, "last_seen": ""}
    return reg


def _v66_apply_cast(beats, mapping):
    """The beats with every clip's CHAR IDs replaced by cast IDs (speaker, actors, targets and IDs in notes)."""
    out = []
    for b in beats:
        m = mapping.get(f"{b.get('source_file')}|{b.get('analysis_clip_index')}") or {}
        if not m:
            out.append(b)
            continue
        sub = lambda v: _CHAR_ID.sub(lambda x: m.get(x.group(0), x.group(0)), v) if isinstance(v, str) else v
        actors = []
        for a in b.get("actors") or []:
            a = sub(a)
            if a not in actors:
                actors.append(a)
        row = dict(b, speaker=sub(b.get("speaker")), actors=actors, targets=[sub(t) for t in b.get("targets") or []])
        if b.get("addressee"):
            row["addressee"] = [sub(t) for t in b["addressee"]]
        for key in ("visual_action", "evidence_note"):
            if isinstance(row.get(key), str):
                row[key] = sub(row[key])
        out.append(row)
    return out


def _v66_cast_pass(pool, beats, clip_people, registry, out_dir, series_cast=None, language="my"):
    """(cast registry, beats with cast IDs), or (None, beats) when it cannot be done (the run goes on with the
    registry as before). clip_people: "file|clip index" -> that clip's own `characters` list. Progress is kept
    in out_dir/CAST_PASS.json, so a resume asks only for the clips not done; series_cast (Same series) holds the
    cast the next file starts from."""
    import hashlib
    groups = {}
    for b in beats:
        if b.get("analysis_clip_index") is None:
            continue
        groups.setdefault(f"{b.get('source_file')}|{b.get('analysis_clip_index')}", []).append(b)
    if not groups:
        return None, beats
    order = sorted(groups, key=lambda k: min(float(b.get("global_start_sec") or 0.0) for b in groups[k]))
    series_data = {}
    if series_cast and Path(series_cast).exists():
        try:
            series_data = load_json(series_cast)
        except Exception:
            series_data = {}
    start_cast = list(series_data.get("cast") or [])
    me = "/".join(Path(out_dir).resolve().parts[-2:])     # "S9/s9-2": who wrote the series cast
    blocks = [_v66_clip_block(n, groups[k], clip_people.get(k), registry) for n, k in enumerate(order, start=1)]
    blocks_hash = hashlib.sha1((CAST_PASS_VERSION + "\n".join(blocks)).encode("utf-8")).hexdigest()[:16]
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    state_path = Path(out_dir) / CAST_PASS_FILE
    state = {}
    if state_path.exists():
        try:
            state = load_json(state_path)
        except Exception:
            state = {}
    # 2026-10-31 (S9 s9-2): the series cast this file wrote at the end of its pass is not where it started, so a
    # resume / a re-voice after an edit asked the pass again and, with other IDs, would rewrite the whole story.
    # A finished pass of the same clips is reused when the series cast is this file's own.
    if (series_data.get("by") == me and state.get("done") == len(order)
            and state.get("blocks_hash", blocks_hash) == blocks_hash and state.get("mapping")):
        print(f"[CAST PASS] {me}: this file's own finished pass is reused", flush=True)
        start_cast = state.get("start_cast", start_cast)
        digest = state.get("hash")
    else:
        digest = hashlib.sha1((CAST_PASS_VERSION + json.dumps(start_cast, ensure_ascii=False, sort_keys=True)
                               + "\n".join(blocks)).encode("utf-8")).hexdigest()[:16]
    if state.get("hash") != digest:
        state = {"version": CAST_PASS_VERSION, "hash": digest, "cast": start_cast, "mapping": {}, "done": 0,
                 "models": [], "start_cast": start_cast, "blocks_hash": blocks_hash}
    state.setdefault("blocks_hash", blocks_hash)
    label = _languages().get(language)["label"]
    strong = [m for m in pool.models if "lite" not in m.lower()]
    def ask(lo, hi):
        """(answer, model, expected IDs) for clips lo..hi-1; (None, "empty", expected) when every model answered
        nothing (Gemini blocks some violent stretches outright, 2026-10-24: pirates using people as bait, while
        the halves are fine); (None, None, expected) when no model could be asked (quota, network)."""
        expected = {(n, cid) for n in range(lo + 1, hi + 1)
                    for cid in [str(p.get("character_id")) for p in clip_people.get(order[n - 1]) or []
                                if p.get("character_id")] + _v66_clip_ids(groups[order[n - 1]])}
        prompt = _v66_cast_prompt(state["cast"], blocks[lo:hi], label)
        empty = False
        for only in ([strong] if strong else []) + [None]:      # strong models first; lite only as the last resort
            try:
                answer, model, _key = pool.generate_json(prompt, CAST_PASS_SCHEMA, temperature=0.0,
                                                         max_output_tokens=32768, only_models=only)
                return answer, model, expected
            except Exception as exc:
                raise_if_terminal(exc)
                text = str(exc)
                empty = any(x in text for x in ("Expecting value", "bad JSON", "PROHIBITED", "SAFETY", "blocked"))
                print(f"[CAST PASS] clips {lo + 1}-{hi}: {'strong models' if only else 'any model'} "
                      f"did not answer ({text.splitlines()[0][:120]})", flush=True)
        return None, ("empty" if empty else None), expected

    while state["done"] < len(order):
        lo = state["done"]
        hi = min(len(order), lo + CAST_PASS_CLIPS)
        while True:
            answer, model, expected = ask(lo, hi)
            if answer is None and model == "empty" and hi - lo > 1:
                print(f"[CAST PASS] clips {lo + 1}-{hi}: no answer from any model; asking for "
                      f"{max(1, (hi - lo) // 2)} clips", flush=True)
                hi = lo + max(1, (hi - lo) // 2)
                continue
            if answer is None and model == "empty":     # one clip nobody answers: its people as that clip saw them
                print(f"[CAST PASS] clip {lo + 1}: no answer from any model; its people stay as the clip described "
                      f"them", flush=True)
                answer, model = {"cast": [], "mapping": []}, "none"
                break
            if answer is None:
                save_json(state_path, state)
                print("[CAST PASS] not finished; this run uses the registry as before (a resume continues)", flush=True)
                return None, beats
            cast_ids = {str(p.get("cast_id")) for p in state["cast"]} | {
                str(p.get("cast_id") or "").strip() for p in answer.get("cast") or []}
            placed = {(int(r.get("clip") or 0), str(r.get("id") or "")) for r in answer.get("mapping") or []
                      if str(r.get("cast_id") or "") in cast_ids} & expected
            if len(placed) >= CAST_PASS_PLACED * len(expected) or hi - lo == 1:
                break
            # a cut-off or partial answer (a thinking model ran out of room): ask for fewer clips
            print(f"[CAST PASS] clips {lo + 1}-{hi}: only {len(placed)}/{len(expected)} IDs placed by {model}; "
                  f"asking for {max(1, (hi - lo) // 2)} clips", flush=True)
            hi = lo + max(1, (hi - lo) // 2)
        cast = {str(p.get("cast_id")): p for p in state["cast"]}
        for p in answer.get("cast") or []:
            cid = str(p.get("cast_id") or "").strip()
            if re.fullmatch(r"P\d{3,}", cid):
                cast[cid] = {k: p.get(k) for k in ("cast_id", "name", "other_names", "gender", "look", "role", "importance")}
        got = 0
        for row in answer.get("mapping") or []:
            n, cid, pid = int(row.get("clip") or 0), str(row.get("id") or ""), str(row.get("cast_id") or "")
            if (n, cid) in expected and pid in cast:
                state["mapping"].setdefault(order[n - 1], {})[cid] = pid
                got += 1
        for n, cid in sorted(expected):          # an ID left out keeps its clip's own description as a person
            if cid in state["mapping"].get(order[n - 1], {}):
                continue
            p = next((x for x in clip_people.get(order[n - 1]) or [] if str(x.get("character_id")) == cid), {})
            new = f"P{max([int(k[1:]) for k in cast] + [0]) + 1:03d}"
            cast[new] = {"cast_id": new, "name": "", "other_names": [str(p.get("name") or cid)],
                         "gender": "unknown", "look": str(p.get("visual_description") or "")[:150],
                         "role": str(p.get("role_hint") or ""), "importance": "minor"}
            state["mapping"].setdefault(order[n - 1], {})[cid] = new
        state["cast"] = sorted(cast.values(), key=lambda p: int(str(p["cast_id"])[1:]))
        state["done"] = hi
        state["models"].append(model)
        save_json(state_path, state)
        print(f"[CAST PASS] clips {lo + 1}-{hi}/{len(order)}: {got}/{len(expected)} IDs placed by {model}; "
              f"cast {len(state['cast'])}", flush=True)
    if series_cast:     # the next file keeps the people who matter; a passing shopkeeper is met again as new
        keep = [p for p in state["cast"] if str(p.get("importance") or "").lower() in ("main", "supporting")
                or str(p.get("name") or "").strip()]
        save_json(series_cast, {"cast": keep, "made": time.strftime("%Y-%m-%d %H:%M"), "by": me})
        save_json(state_path, state)
    return _v66_cast_registry(state["cast"]), _v66_apply_cast(beats, state["mapping"])


def _v66_people_labels(cast, glossary):
    """cast ID -> how the writer calls that person: "ရှန်ယဲ့ (main: the hero; male, young man in white)". The
    spelling comes from the glossary, matched on the person's own name only (role words such as "Host" or
    "Young Man" can belong to anyone); a person without one is called by role."""
    spelled = {}
    for g in glossary or []:
        for k in [g.get("name_source")] + list(g.get("other_names") or []):
            k = str(k or "").strip().lower()
            if k and g.get("name_target"):
                spelled.setdefault(k, g["name_target"])
    labels = {}
    for cid, p in (cast or {}).items():
        name = spelled.get(str(p.get("canonical_name") or "").strip().lower(), "")
        about = "; ".join(str(x) for x in (p.get("role_hint"), p.get("visual_description")) if str(x or "").strip())
        labels[cid] = f"{name or '(no name: call them by role)'} ({about})"
    return labels


def _v66_style_from_file(path):
    """The telling style saved by the Studio (TELLING_STYLE.json: preset, notes, sample), "" if none."""
    path = str(path or "").strip()
    if not path or not Path(path).exists():
        return ""
    try:
        data = load_json(Path(path))
    except Exception:
        return ""
    return _v66_style_text(data.get("preset"), data.get("notes"), data.get("sample"))


def _v66_style_preview(pool, beats, registry, story_cache, glossary_text, labels, style, out, seconds):
    """Studio "Preview style": ~`seconds` of the story written in the chosen style from the analysis already made
    (from the first line spoken after the first minute), into out/STYLE_PREVIEW.txt. Own cache, so the story is
    not touched; the same style again costs nothing."""
    talk = [b for b in beats if str(b.get("source_dialogue") or "").strip() and float(b.get("global_start_sec") or 0) >= 60]
    t0 = float((talk or beats)[0].get("global_start_sec") or 0.0)
    window = [b for b in beats if t0 <= float(b.get("global_start_sec") or 0.0) < t0 + seconds]
    story, blocks = _build_story_from_gemini_beats_v60(pool, window, registry, story_cache / "style_preview",
                                                      glossary_text, workers=1, labels=labels, style=style)
    lines = [f"STYLE PREVIEW {srt_time(t0)[:8]} - {srt_time(t0 + seconds)[:8]}"
             f" ({(style.splitlines() or ['default style'])[0][:100] or 'default style'})", ""]
    for blk in blocks:
        start = min(float(b.get("global_start_sec") or 0) for b in window if b["beat_id"] in set(blk.get("story_item_ids") or []))
        lines.append(f"[{srt_time(start)[:8]}] {blk['narration_text']}")
    path = out / "STYLE_PREVIEW.txt"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


# Story memory (2026-10-02, from the user's story_script V1.3). The writer saw only the last ~2200 letters
# of narration, so the later chapters of a long film lost who people are to each other and what happened
# before. Gemini folds each 15-minute chapter's timeline (what is said and done) into a short "story so
# far", and the later chapters are written with it as background (never retold: the picture shows only
# the beat). From the timeline, not the narration, so the chapters can be written at once (parallel).
# Studio "Same series" (--series-memory) keeps the final memory in STORY_MEMORY.json and the next file of
# the queue starts from it (--story-memory-in). Not in the story cache key, like V1.3: cached parts stay.
STORY_MEMORY_FILE = "STORY_MEMORY.json"
STORY_MEMORY_VERSION = "v64-story-memory-2"
STORY_MEMORY_ON = True            # --no-story-memory turns it off (A/B)
STORY_MEMORY_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "story_memory": {"type": "STRING"},
        "current_state": {"type": "STRING"},
        "unresolved_threads": {"type": "ARRAY", "items": {"type": "STRING"}},
    },
    "required": ["story_memory", "current_state", "unresolved_threads"],
}


def _v64_memory_text(memory):
    """The memory as the writer and the next update read it ("" when there is none yet)."""
    memory = memory or {}
    parts = [str(memory.get("story_memory") or "").strip()]
    if str(memory.get("current_state") or "").strip():
        parts.append("WHERE THE STORY STANDS: " + str(memory["current_state"]).strip())
    threads = [str(t).strip() for t in memory.get("unresolved_threads") or [] if str(t).strip()]
    if threads:
        parts.append("OPEN THREADS: " + "; ".join(threads))
    return "\n".join(p for p in parts if p)


def _v64_memory_block(memory):
    """Writer prompt block: background for understanding, never retold or added to a beat."""
    text = _v64_memory_text(memory)
    if not text:
        return ""
    where = "earlier chapters and earlier episodes" if (memory or {}).get("carried_from") else "earlier chapters"
    return (f"STORY SO FAR (memory of {where}; background only):\n{text}\n"
            "Use it only to understand who people are and why things happen, so each beat is told correctly. "
            "NEVER retell it, never add an event or fact the beat itself does not show or say, and never let it "
            "make a fragment longer: the picture shows only that beat while its words are spoken. Spell names as "
            "the glossary does.")


def _v64_memory_prompt(memory, chapter_no, chapter_text, people_text, language_label):
    episodes = " and earlier episodes" if (memory or {}).get("carried_from") else ""
    return f"""
Update a compact continuity memory for a long {language_label} storytelling recap of a film / series.
It is background for the narration writer, NOT narration: do not rewrite or retell the chapter.

PREVIOUS MEMORY (earlier chapters{episodes}):
{_v64_memory_text(memory) or '(none: this chapter starts the story)'}

NEW CHAPTER {chapter_no}: what happens in it (the source timeline: time, speaker ID: what is said | what is done):
{chapter_text}

CHARACTERS AND NAME SPELLINGS:
{people_text}

Return JSON:
- story_memory: at most 2600 characters. Only established facts later chapters may depend on: who people are and
  how they are related, important past events, goals, conflicts, powers / systems, important objects, promises,
  betrayals, secrets revealed. Merge the previous memory in; drop details that no longer matter.
- current_state: at most 900 characters: where the story stands at the end of this chapter.
- unresolved_threads: a short list of open questions, goals and conflicts.
Write it in {language_label}. The IDs (CHAR_001 ...) are for you only: never write one; write a person's name as the
name spellings give it, or their role when the story has no name for them. Do not invent anything; no style advice.
""".strip()


def _v64_chapter_events(beats):
    """A chapter's timeline as the memory update reads it: time, speaker: what is said | what is done."""
    rows = []
    for b in beats:
        said = str(b.get("dialogue_meaning") or b.get("source_dialogue") or "").strip()
        done = str(b.get("visual_action") or "").strip()
        if not said and not done:
            continue
        who = str(b.get("speaker") or "").strip()
        rows.append(f"[{srt_time(float(b.get('global_start_sec') or 0.0))[:8]}] "
                    + (f"{who}: {said}" if said else "") + (" | " if said and done else "") + done)
    return "\n".join(rows)


def _v64_update_memory(pool, memory, chapter_no, chapter_text, people_text, cache_dir):
    """The memory after one more chapter, cached by the previous memory + the chapter's narration.
    A failed or empty answer keeps the previous memory: it never stops the run."""
    import hashlib
    chapter_text = str(chapter_text or "").strip()
    if not chapter_text:
        return memory
    base = {k: memory.get(k) or "" for k in ("story_memory", "current_state", "unresolved_threads")}
    digest = hashlib.sha1(json.dumps([STORY_MEMORY_VERSION, OUTPUT_LANGUAGE, base, chapter_text],
                                     ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()[:16]
    cache = Path(cache_dir) / f"memory_chapter_{chapter_no:03d}_{digest}.json"
    try:
        saved = load_json(cache) if cache.exists() else {}
    except Exception:
        saved = {}
    new = saved.get("memory") if saved.get("version") == STORY_MEMORY_VERSION else None
    if not new:
        label = _languages().get(OUTPUT_LANGUAGE)["label"]
        try:
            answer, model, _key = pool.generate_json(_v64_memory_prompt(memory, chapter_no, chapter_text, people_text, label),
                                                     STORY_MEMORY_SCHEMA, temperature=0.05, max_output_tokens=8192)
        except Exception as exc:
            raise_if_terminal(exc)
            print(f"[STORY MEMORY] chapter {chapter_no}: not updated ({str(exc).splitlines()[0][:120]}); "
                  "the previous memory is kept", flush=True)
            return memory
        new = {"story_memory": str(answer.get("story_memory") or "").strip()[:3200],
               "current_state": str(answer.get("current_state") or "").strip()[:1200],
               "unresolved_threads": [str(t).strip()[:240] for t in answer.get("unresolved_threads") or []
                                      if str(t).strip()][:12]}
        if not new["story_memory"]:
            print(f"[STORY MEMORY] chapter {chapter_no}: empty answer from {model}; the previous memory is kept", flush=True)
            return memory
        Path(cache_dir).mkdir(parents=True, exist_ok=True)
        save_json(cache, {"version": STORY_MEMORY_VERSION, "model": model, "memory": new})
        print(f"[STORY MEMORY] chapter {chapter_no}: {len(new['story_memory'])} letters, "
              f"{len(new['unresolved_threads'])} open thread(s) ({model})", flush=True)
    return {**memory, **new, "chapters": int(memory.get("chapters") or 0) + 1}


def _v64_load_memory(path):
    """--story-memory-in: the previous file's STORY_MEMORY.json ({} when there is none yet)."""
    path = str(path or "").strip()
    if not path:
        return {}
    try:
        memory = load_json(Path(path))
    except Exception:
        print(f"[STORY MEMORY] no memory from the previous file yet ({path}); starting fresh", flush=True)
        return {}
    if not str(memory.get("story_memory") or "").strip():
        return {}
    source = str(memory.get("source") or Path(path).parent.name)
    print(f"[STORY MEMORY] continuing from {source} ({memory.get('chapters') or 0} chapter(s))", flush=True)
    return {k: memory.get(k) for k in ("story_memory", "current_state", "unresolved_threads", "chapters")} | \
        {"carried_from": source}


def _gemini_timeline_prompt_v60(source_name, clip_start, clip_duration, registry, previous_tail):
    original = f"""
You are the ONLY transcript/timestamp/visual-evidence engine for a video storytelling system.
There is NO Whisper transcript. Listen to the clip audio yourself and inspect the actual video frames yourself.

SOURCE FILE: {source_name}
CLIP FILE-TIME START: {srt_time(clip_start)}
CLIP DURATION: {clip_duration:.3f} seconds
ALL start_sec/end_sec values MUST be relative to the beginning of THIS clip: 0.0 is its first frame,
{clip_duration:.1f} its last. Never use file time.

EXISTING CHARACTER REGISTRY:
{json.dumps(_compact_registry(registry), ensure_ascii=False)}

RECENT VERIFIED BEATS BEFORE/OVERLAPPING THIS CLIP (context only; their times are FILE times):
{json.dumps(previous_tail[-10:], ensure_ascii=False)}

RETURN A CHRONOLOGICAL `beats` TIMELINE THAT COVERS THE WHOLE CLIP, from 0.0 to {clip_duration:.1f} s:
every spoken line and every story action in it, in order. Do not stop early or skip the middle.
Each beat is one story-relevant source-video window with its OWN exact start_sec and end_sec.

NON-NEGOTIABLE TIMESTAMP RULES:
1. YOU own the timestamps. Use the actual video/audio timing, not guessed transcript timing supplied by Python.
2. Dialogue: listen to the audio and transcribe EVERY meaningful spoken line/turn. Give the exact audible start_sec and end_sec.
3. Visual/VFX: timestamp story-relevant visible actions/effects yourself: door actions, entering/leaving, hits, grabs, object use,
   phone/system screens, transformations, red rain, zombies appearing, explosions, holograms, important VFX, etc.
4. If dialogue and a visual action truly happen at the same time, return ONE `mixed` beat covering that moment and put BOTH fields in it.
5. Beats inside this clip MUST be chronological and MUST NOT overlap one another. Split at the real change point when a new dialogue turn/action begins.
6. Tight timestamps are more important than covering decorative footage. Do not stretch a beat across unrelated shots.
7. Overlap with the previous analysis clip can repeat a beat; downstream Python will de-duplicate by absolute time/evidence.

DIALOGUE FIELDS:
- kind: `dialogue`, `visual`, or `mixed`.
- source_dialogue: the words you actually hear. Keep it as faithful as possible to the spoken source.
  Write them in the language that is SPOKEN in the audio: a dubbed video is transcribed in the dub's language
  (an English dub of a Chinese show stays English), never translated, never copied from on-screen text.
- dialogue_meaning: faithful meaning in clear English if the source is not English; otherwise a faithful paraphrase.
- speaker: reuse a known CHAR_### only when supported. Otherwise UNKNOWN_SPEAKER or NEW_#.
- addressee: who the line is spoken TO (CHAR_### or NEW_#, the same IDs as speaker); [] for narration,
  voice-over, thoughts or a line said to nobody in particular.

VISUAL FIELDS:
- visual_action must contain ONLY plot-relevant concrete action/effect.
- actors/targets must say WHO did WHAT to WHOM when visible and supported.
- DO NOT create beats for camera language or decorative establishing shots: aerial/overhead/wide shot, scenery, road layout,
  gas station, traffic, background architecture, camera movement/angle, or generic "we see" descriptions.
- A location/background is not story narration by itself. Include it only when it materially changes the plot.

IDENTITY / FIDELITY:
- Never invent a name, relationship, motive, cause, action, result, spoken line, or VFX.
- Reuse existing CHAR_### only for clearly same people. Use NEW_1, NEW_2... for new/uncertain people.
- If evidence is unclear, record it in uncertainties instead of guessing.
- Keep confidence realistic.

Return only the requested structured JSON.
""".strip()
    if ANALYSIS_SPEED == 1:
        return original
    import analysis_speed
    return analysis_speed.timeline_prompt(original, ANALYSIS_SPEED, clip_duration)


def _v6_beat_norm_text(row):
    d = normalize_text(str(row.get("source_dialogue") or ""))
    v = normalize_text(str(row.get("visual_action") or ""))
    return d, v


def _v6_interval_overlap(a, b):
    a0, a1 = float(a.get("global_start_sec") or 0.0), float(a.get("global_end_sec") or 0.0)
    b0, b1 = float(b.get("global_start_sec") or 0.0), float(b.get("global_end_sec") or 0.0)
    inter = max(0.0, min(a1, b1) - max(a0, b0))
    shorter = max(0.05, min(max(0.05, a1-a0), max(0.05, b1-b0)))
    return inter / shorter


def _v62_text_similarity(a, b):
    if not a or not b:
        return 0.0
    import difflib
    return difflib.SequenceMatcher(None, a, b).ratio()


def _v62_clip_edge_margin(row):
    """Seconds between a beat and its analysis-clip edges; a beat cut by an edge is partial."""
    if row.get("analysis_clip_start_sec") is None or row.get("analysis_clip_duration_sec") is None:
        return 99.0
    clip_start = float(row["analysis_clip_start_sec"])
    clip_end = clip_start + float(row["analysis_clip_duration_sec"])
    return min(float(row.get("file_start_sec") or 0.0) - clip_start, clip_end - float(row.get("file_end_sec") or 0.0))


def _v62_same_moment(x, y):
    xs, xe = float(x.get("file_start_sec") or 0.0), float(x.get("file_end_sec") or 0.0)
    ys, ye = float(y.get("file_start_sec") or 0.0), float(y.get("file_end_sec") or 0.0)
    shorter = max(0.05, min(xe - xs, ye - ys))
    if (min(xe, ye) - max(xs, ys)) / shorter >= 0.30:
        return True
    xd, xv = _v6_beat_norm_text(x)
    yd, yv = _v6_beat_norm_text(y)
    return abs(xs - ys) <= 2.0 and max(_v62_text_similarity(xd, yd), _v62_text_similarity(xv, yv)) >= 0.80


def _v62_side_score(beats, members):
    spans = sorted((float(beats[i]["file_start_sec"]), float(beats[i]["file_end_sec"])) for i in members)
    covered, cur_s, cur_e = 0.0, None, None
    for s, e in spans:
        if cur_e is None or s > cur_e:
            if cur_e is not None:
                covered += cur_e - cur_s
            cur_s, cur_e = s, e
        else:
            cur_e = max(cur_e, e)
    if cur_e is not None:
        covered += cur_e - cur_s
    edge_cut = sum(1 for i in members if _v62_clip_edge_margin(beats[i]) < 0.5)
    return covered - 1.0 * edge_cut, sum(float(beats[i].get("confidence") or 0.0) for i in members)


def _v62_resolve_clip_overlaps(beats):
    """V6.2: each clip-overlap zone is analysed twice; keep ONE clip's beats per moment.

    Gemini rarely splits or words the overlap the same way twice ("A+B" in one clip, "A"
    and "B" in the next), so pairwise matching either narrates a line twice or swaps a
    whole line for one fragment. Cross-clip beats that overlap in time (or say nearly the
    same thing within 2s) form a cluster; the clip covering more of it wins (edge-cut beats
    penalised) and the other clip's beats in that cluster are dropped.
    """
    by_file = {}
    for idx, row in enumerate(beats):
        if row.get("analysis_clip_index") is not None:
            by_file.setdefault(str(row.get("source_file") or ""), []).append(idx)
    drop = set()
    for idxs in by_file.values():
        clips = sorted({int(beats[i]["analysis_clip_index"]) for i in idxs})
        for k, k2 in zip(clips, clips[1:]):
            first = [i for i in idxs if int(beats[i]["analysis_clip_index"]) == k]
            second = [i for i in idxs if int(beats[i]["analysis_clip_index"]) == k2]
            zone_start = float(beats[second[0]]["analysis_clip_start_sec"])
            zone_end = float(beats[first[0]]["analysis_clip_start_sec"]) + float(beats[first[0]]["analysis_clip_duration_sec"])
            a_side = [i for i in first if float(beats[i]["file_end_sec"]) > zone_start]
            b_side = [i for i in second if float(beats[i]["file_start_sec"]) < zone_end]
            parent = {i: i for i in a_side + b_side}

            def find(x):
                while parent[x] != x:
                    parent[x] = parent[parent[x]]
                    x = parent[x]
                return x

            for i in a_side:
                for j in b_side:
                    if _v62_same_moment(beats[i], beats[j]):
                        parent[find(i)] = find(j)
            clusters = {}
            for i in a_side + b_side:
                clusters.setdefault(find(i), []).append(i)
            a_set = set(a_side)
            for members in clusters.values():
                mine = [i for i in members if i in a_set]
                theirs = [i for i in members if i not in a_set]
                if not mine or not theirs:
                    continue
                if _v62_side_score(beats, mine) >= _v62_side_score(beats, theirs):
                    drop.update(theirs)
                else:
                    drop.update(mine)
    if drop:
        print(f"[V6.2 OVERLAP DEDUPE] dropped {len(drop)} clip-overlap copy beat(s)")
    return [row for idx, row in enumerate(beats) if idx not in drop]


def _dedupe_gemini_beats_v60(beats):
    """Remove overlap-copy beats from adjacent Gemini clips without collapsing real repeats."""
    beats = _v62_resolve_clip_overlaps(beats)
    out = []
    for row in sorted(beats, key=lambda x: (str(x.get("source_file") or ""), float(x.get("file_start_sec") or 0.0), float(x.get("file_end_sec") or 0.0))):
        d, v = _v6_beat_norm_text(row)
        dup_i = None
        for i in range(len(out)-1, max(-1, len(out)-18), -1):
            prev = out[i]
            if prev.get("source_file") != row.get("source_file"):
                continue
            if float(row.get("file_start_sec") or 0.0) - float(prev.get("file_start_sec") or 0.0) > 7.0:
                break
            pd, pv = _v6_beat_norm_text(prev)
            temporal = _v6_interval_overlap(prev, row)
            start_close = abs(float(prev.get("file_start_sec") or 0.0) - float(row.get("file_start_sec") or 0.0)) <= 0.65
            same_dialogue = bool(d and pd and d == pd)
            same_visual = bool(v and pv and v == pv)
            if (same_dialogue or same_visual) and (temporal >= 0.30 or start_close):
                dup_i = i
                break
        if dup_i is None:
            out.append(row)
        else:
            prev = out[dup_i]
            score_prev = float(prev.get("confidence") or 0.0)
            score_new = float(row.get("confidence") or 0.0)
            richness_prev = len(str(prev.get("source_dialogue") or "")) + len(str(prev.get("visual_action") or ""))
            richness_new = len(str(row.get("source_dialogue") or "")) + len(str(row.get("visual_action") or ""))
            if (score_new, richness_new) > (score_prev, richness_prev):
                out[dup_i] = row
    out.sort(key=lambda x: (float(x.get("global_start_sec") or 0.0), float(x.get("global_end_sec") or 0.0)))
    return out


def _filter_gemini_beats_v60(beats):
    kept, dropped = [], []
    for b in beats:
        dialogue = str(b.get("source_dialogue") or "").strip()
        visual = str(b.get("visual_action") or "").strip()
        if not dialogue and not visual:
            dropped.append(b); continue
        if not dialogue:
            probe = {
                "kind": "event", "actors": b.get("actors") or [], "action": visual,
                "location": b.get("location") or "", "evidence": b.get("evidence_note") or "",
            }
            if _is_low_value_visual_event(probe):
                dropped.append(b); continue
        kept.append(b)
    if dropped:
        print(f"[V6 VISUAL FILTER] omitted {len(dropped)} empty/camera-only beat(s)")
    return kept


def _write_gemini_transcript_v60(beats, path):
    lines = ["MANJU V6.0 - GEMINI-ONLY TRANSCRIPT + SOURCE TIMESTAMPS", ""]
    for b in beats:
        dialogue = str(b.get("source_dialogue") or "").strip()
        if not dialogue:
            continue
        lines.append(
            f"[{srt_time(float(b.get('file_start_sec') or 0.0))} -> {srt_time(float(b.get('file_end_sec') or 0.0))}] "
            f"{b.get('source_file')} | {b.get('speaker') or 'UNKNOWN_SPEAKER'} | {dialogue}"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")


FLOW_WRITER_RULES = """
NARRATION FLOW — the fragments are read back-to-back as ONE continuous voice-over, so write a flowing story, not a list of separate reports:
- A sentence may run across 2-3 consecutive beats: end a beat with a joining form (…ပြီး / …တော့ / …ပေမဲ့ / …တဲ့အခါ / …ရင်း / …လို့ / …တာကြောင့်) and let the NEXT beat continue that same sentence. Close a sentence only where the story naturally pauses.
- Do NOT end every sentence with "ပါတယ်". A narrator varies the endings: "…လိုက်တယ်", "…သွားတယ်", "…ခဲ့တယ်", "…နေတယ်", "…တော့တယ်", "…ပါတော့တယ်" (turning points), "…တာပေါ့", "…လေ" (sparingly). Use "ပါတယ်" only now and then, never on two sentences in a row.
- Inside one beat, join closely linked actions with "…ပြီး", "…ပေမဲ့", "…တော့", "…ချိန်မှာ" instead of stacking short "…ပါတယ်။" sentences.
- NEVER end a sentence with audience-address particles: no "ခင်ဗျာ", "ခင်ဗျ", "ရှင်", "ရှင့်", "နော်".
- Once a character is named, use သူ / သူမ / သူ့ when it is clear who is meant; do not open consecutive beats with the same name.
- Each beat's words must still tell ONLY that beat's own dialogue/action (the picture shows that beat while its words are spoken).
- Example — BAD (a list): B1 "ဘုရင်က ဓားကို ဆွဲထုတ်လိုက်ပါတယ်။" B2 "ဘုရင်က လီယိရဲ့ လည်ပင်းကို ဓားနဲ့ ချိန်လိုက်ပါတယ်။" B3 "လီယိက ကြောက်ပြီး လဲကျသွားပါတယ်။"
  GOOD (one voice-over): B1 "ဘုရင်က အစောင့်ရဲ့ ခါးကဓားကို ဆွဲထုတ်ပြီး" B2 "လီယိရဲ့ လည်ပင်းကို တည့်တည့် ချိန်လိုက်တော့" B3 "လီယိတစ်ယောက် ကြောက်လွန်းလို့ နောက်ပြန် လဲကျသွားတော့တယ်။"
""".strip()


FLOW_WRITER_RULES_ANY = """
NARRATION FLOW — the fragments are read back-to-back as ONE continuous voice-over, so write a flowing story, not a list of separate reports:
- A sentence may run across 2-3 consecutive beats: end a beat mid-sentence (with a comma or a joining word) and let the NEXT beat continue that same sentence. Close a sentence only where the story naturally pauses.
- Vary sentence openings and endings. Once a character is named, use a pronoun when it is clear who is meant; do not open consecutive beats with the same name.
- Each beat's words must still tell ONLY that beat's own dialogue/action (the picture shows that beat while its words are spoken).
""".strip()


WRITER_PEOPLE_RULES = """- Each beat's `people` says who its IDs are: the name to call them (spelled exactly as given), how much they
  matter, their role and look. `speaker` says the line; `addressee` (when given) is who it is said to, otherwise
  take that from the scene. Retelling a line: its I / me / my / we = the speaker, you / your = the person spoken
  to, and he / she / they / brother / father / master ... = the person the line means (from `people`, the dialogue
  and the story so far). Never give one person's line, action or name to another.
- A minor person without a name is called by role and look ("the guard in black"); two people with the same role
  are told apart by look or name. Where a he / she could point at two people, use the name or the role instead."""

# V6.6 telling style (2026-10-24, the user's plan): a preset, the user's own notes and a sample paragraph whose way of
# telling (not its content) is copied. It changes how the story is told, never who did what; part of the story
# cache key, so a new style rewrites the story (voice / speed alone only redo the TTS).
TELLING_STYLE_PRESETS = {
    "default": "",
    "light": "Light and friendly, like telling a friend the story: short simple sentences, everyday words.",
    "calm": "Calm and clear, like a steady explainer: an even pace, plain words, no hype.",
    "gripping": "Gripping and tense: short punchy sentences in fights and danger, build the suspense, let a reveal land.",
    "humor": "A little playful: the narrator's tone may smile at the funny moments (a dry remark now and then), never "
             "mocking and never adding jokes the story does not have.",
}


def _v66_style_text(preset="", notes="", sample=""):
    """The telling style for the writer, "" for the built-in one."""
    parts = []
    base = TELLING_STYLE_PRESETS.get(str(preset or "default").strip().lower(), "")
    if base:
        parts.append(base)
    if str(notes or "").strip():
        parts.append("The user's own notes (follow them): " + str(notes).strip()[:2000])
    if str(sample or "").strip():
        parts.append("A sample of narration the user likes. Copy only its way of telling (words, sentence length, rhythm, "
                     "how sentences join), never its people, events or facts:\n<<<\n" + str(sample).strip()[:3000] + "\n>>>")
    return "\n".join(parts)


def _v66_style_block(style):
    if not style:
        return ""
    return ("TELLING STYLE (how to tell it. It never changes who said or did what, the facts, their order or the beat a "
            "fragment belongs to; keep the outside third-person storyteller voice; no greeting, intro or outro):\n"
            + style + "\n")


def _writer_prompt_any_language(code, registry_text, compact, previous_tail, flow_rules, memory_block="",
                                people_rules="", style_block=""):
    """Storyteller prompt for the Studio's non-Burmese narration languages (same beat contract)."""
    lang = _languages().get(code)
    name = lang["label"]
    return f"""
You are the FINAL {name} narrator writer for a popular YouTube movie / drama / manhwa recap channel.
The source timeline below was created DIRECTLY by Gemini from the original video's audio + frames.
Its timestamps are already final. DO NOT realign, reorder, merge, or move content between beat IDs.

CHARACTER REGISTRY:
{registry_text}

{memory_block}

GEMINI SOURCE BEATS IN EXACT CHRONOLOGICAL ORDER:
{json.dumps(compact, ensure_ascii=False)}

TAIL OF PREVIOUS WRITTEN SECTION (continuity only; never repeat it):
{previous_tail[-2200:]}

For EACH beat_id, write exactly one natural {name} narration fragment belonging ONLY to that beat.

RULES:
- Write ONLY in {name}. Character names: {lang["names"]}.
- You are an OUTSIDE STORYTELLER/NARRATOR. NEVER speak as a character and NEVER switch into character POV.
- If source_dialogue exists, preserve that spoken turn's COMPLETE meaning in that SAME beat, but RETELL it as reported/indirect storytelling that keeps who said what to whom. No raw dub lines, no quotation marks, no subtitle-like speech.
- If the same or similar line is genuinely spoken twice at different beats, keep BOTH turns as two chronological events.
- If visual_action exists, narrate that concrete plot-relevant action/effect in that SAME beat.
- `mixed` beats may combine their dialogue meaning and simultaneous visual action into one fluent storyteller sentence.
- Treat all fragments as consecutive pieces of ONE smooth spoken narration. Use connectors naturally, but do not repeat facts just to create continuity.
- Keep the narrator perspective consistent from the very first beat to the last.
- Plot-relevant on-screen text or a phone/system message is told as what the character reads or learns.
- NEVER narrate the footage itself: no "we see", "is shown", "an image of", "in the video/scene/shot", "the camera" or their {name} equivalents. A photo, insert or close-up beat is told as a story fact inside the characters' world.
- Never mention timestamps, beat IDs, camera angles, aerial/wide shots, scenery or background layout unless a plot-changing event depends on it.
- Never invent names, relationships, motives, causes, actions, results, dialogue, objects, or VFX.
- Sound like a popular {name} YouTube recap narrator: vivid, simple, natural spoken {name} that is easy to listen to; not formal writing, not a screenplay, not subtitles, not dubbing. Use the tense {name} recap narrators normally use.
- No greeting, CTA, intro/outro, or generic filler.
{people_rules}{WRITER_LENGTH_RULES[NARRATION_LENGTH]}
{flow_rules}
{style_block}Under `units`, return EXACTLY every beat_id once and no extra keys.
""".strip()


def _v6_story_groups(beats, max_window_sec=120.0, max_items=20):
    if not beats:
        return []
    groups, cur = [], []
    start = float(beats[0].get("global_start_sec") or 0.0)
    for b in beats:
        t = float(b.get("global_start_sec") or 0.0)
        if cur and (t - start >= max_window_sec or len(cur) >= max_items):
            groups.append(cur); cur = []; start = t
        cur.append(b)
    if cur: groups.append(cur)
    return groups


def _v65_importance_prompt(registry_text, compact):
    return f"""
You rate how much each beat of a video matters to its story, for a narrated recap that may leave minor beats out
or tell them briefly.

CHARACTER REGISTRY:
{registry_text}

BEATS IN CHRONOLOGICAL ORDER (t = seconds from the start, d = length):
{json.dumps(compact, ensure_ascii=False)}

Score EVERY beat_id from 1 to 5:
5 = a turning point, reveal, decision, the outcome of a fight, or a line the later story depends on
4 = an important plot action or dialogue
3 = ordinary story progress
2 = minor: a reaction, a repetition, small talk, atmosphere, one blow inside a longer fight
1 = filler: a recap of earlier episodes, a channel intro/outro or ad, scenery, a comic aside nothing later refers to
Leaving out every beat scored 1-2 must keep the story understandable: who did what, why, and what came of it.
Return JSON only: {{"scores": {{"<beat_id>": <1-5>}}}} with every beat_id once.
""".strip()


def _v65_beat_importance(pool, beats, registry_text, cache_dir, group_size=80):
    """{beat_id: 1-5} - how much each beat matters to the story (cached per group of beats)."""
    import hashlib
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    scores = {}
    for start in range(0, len(beats), group_size):
        group = beats[start:start + group_size]
        compact = [{
            "beat_id": b["beat_id"],
            "t": round(float(b.get("global_start_sec") or 0.0)),
            "d": round(float(b.get("file_end_sec") or 0.0) - float(b.get("file_start_sec") or 0.0), 1),
            "kind": b.get("kind"),
            "speaker": b.get("speaker") or "",
            "dialogue": str(b.get("dialogue_meaning") or b.get("source_dialogue") or "")[:220],
            "action": str(b.get("visual_action") or "")[:220],
        } for b in group]
        digest = hashlib.sha1(json.dumps(compact, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()[:16]
        cache = cache_dir / f"importance_{group[0]['beat_id']}_{digest}.json"
        got = {}
        if cache.exists():
            try:
                got = {str(k): int(v) for k, v in (load_json(cache).get("scores") or {}).items()}
            except Exception:
                got = {}
        ids = [str(b["beat_id"]) for b in group]
        if not all(i in got for i in ids):
            schema = {"type": "object", "properties": {"scores": {
                "type": "object", "properties": {i: {"type": "integer"} for i in ids}, "required": ids}},
                "required": ["scores"]}
            data, model, _key = pool.generate_json(_v65_importance_prompt(registry_text, compact), schema,
                                                   temperature=0.0, max_output_tokens=16384)
            got = {}
            for i in ids:
                try:
                    got[i] = max(1, min(5, int((data.get("scores") or {}).get(i))))
                except (TypeError, ValueError):
                    got[i] = 3
            save_json(cache, {"version": "v6.5-importance", "model": model, "scores": got})
            print(f"  [IMPORTANCE] beats {ids[0]}-{ids[-1]}: " + " ".join(
                f"{n}x{sum(1 for v in got.values() if v == n)}" for n in range(1, 6)) + f" ({model})", flush=True)
        scores.update(got)
    return scores


def _v65_skip_minor(beats, report_path=None):
    """Beats scored 1-2 (then only 1, if that would leave out more than SKIP_MAX_SHARE of the footage) are left
    out; the first and last beat always stay. The next kept beat carries a short note of the skipped events."""
    def dur(b):
        return max(0.0, float(b.get("file_end_sec") or 0.0) - float(b.get("file_start_sec") or 0.0))

    total = sum(dur(b) for b in beats) or 1.0
    limit = 2
    for limit in (2, 1, 0):
        share = sum(dur(b) for i, b in enumerate(beats)
                    if 0 < i < len(beats) - 1 and int(b.get("importance") or 3) <= limit) / total
        if share <= SKIP_MAX_SHARE:
            break
    kept, skipped, run = [], [], []
    for i, b in enumerate(beats):
        if 0 < i < len(beats) - 1 and int(b.get("importance") or 3) <= limit:
            skipped.append(b)
            run.append(str(b.get("dialogue_meaning") or b.get("visual_action") or "").strip())
            continue
        b = dict(b)
        if run:
            b["after_skipped"] = "; ".join(x for x in run if x)[:240]
            run = []
        kept.append(b)
    if report_path:
        rows = [f"Skipped {len(skipped)} of {len(beats)} beats (importance <= {limit}): "
                f"{sum(dur(b) for b in skipped) / 60:.1f} of {total / 60:.1f} min of footage", ""]
        for b in skipped:
            t = float(b.get("global_start_sec") or 0.0)
            rows.append(f"[{int(t // 60):02d}:{t % 60:04.1f}] {b['beat_id']} score {b.get('importance')} | "
                        + str(b.get("dialogue_meaning") or b.get("visual_action") or "")[:160])
        Path(report_path).write_text("\n".join(rows) + "\n", encoding="utf-8-sig")
    print(f"[STORY LENGTH] skip: {len(skipped)}/{len(beats)} minor beats left out "
          f"({sum(dur(b) for b in skipped) / 60:.1f} of {total / 60:.1f} min of footage)", flush=True)
    return kept


def _build_story_from_gemini_beats_v60(pool, beats, registry, story_cache_dir, glossary_text="", memory=None,
                                       series_out=None, workers=1, labels=None, style=""):
    """Gemini writes one narration fragment per Gemini-owned timestamp beat. No later alignment.

    memory: the story so far carried from the previous file (Studio "Same series"); series_out: where to keep
    this file's final memory for the next file (STORY_MEMORY.json), or None. workers > 1: the 15-minute
    chapters are written at once (each chapter's parts in order); the first part of a chapter then sees the
    end of the chapter before it only when that was already written.
    labels (V6.6, with a cast): cast ID -> "name (importance: role; look)", given per beat as `people`.
    style (V6.6): the chosen telling style (preset + own notes + sample), part of the story cache key."""
    import hashlib
    story_cache_dir.mkdir(parents=True, exist_ok=True)
    groups = _v6_story_groups(beats)
    all_units = []
    registry_text = json.dumps(_compact_registry(registry), ensure_ascii=False)
    if glossary_text:                       # V6.4: one spelling per person (NAME_GLOSSARY.json)
        registry_text += "\n\n" + glossary_text
    people_rules = WRITER_PEOPLE_RULES + "\n" if labels else ""
    style_block = _v66_style_block(style)
    memory_dir = story_cache_dir / "story_memory"

    def part_cache(part_i, group):
        """(ids, compact beats, cache file, cached fragments, style_kept, the fragments that can be reused)."""
        ids = [str(x["beat_id"]) for x in group]
        compact = []
        for b in group:
            compact.append({
                "beat_id": b["beat_id"],
                "source_file": b.get("source_file"),
                "source_window": [round(float(b.get("file_start_sec") or 0.0), 3), round(float(b.get("file_end_sec") or 0.0), 3)],
                "kind": b.get("kind"),
                "speaker": b.get("speaker"),
                "source_dialogue": b.get("source_dialogue"),
                "dialogue_meaning": b.get("dialogue_meaning"),
                "actors": b.get("actors") or [],
                "visual_action": b.get("visual_action"),
                "targets": b.get("targets") or [],
                "location": b.get("location"),
            })
            if b.get("addressee"):      # V6.6: who a line is said to (newer analyses)
                compact[-1]["addressee"] = b["addressee"]
            if labels:      # V6.6: who the beat's IDs are, so the writer neither looks them up nor guesses
                used = [i for i in [b.get("speaker")] + list(b.get("actors") or []) + list(b.get("targets") or [])
                        + list(b.get("addressee") or []) if isinstance(i, str) and i in labels]
                if used:
                    compact[-1]["people"] = {i: labels[i] for i in dict.fromkeys(used)}
            if NARRATION_LENGTH in ("short", "short_steady", "medium", "recap"):   # the fragment's room: its beat (+SHORT_FACTOR), never under 1.8 s
                footage = float(b.get("file_end_sec") or 0.0) - float(b.get("file_start_sec") or 0.0)
                room = max(MEDIUM_MIN_SEC, MEDIUM_FACTOR * footage) if NARRATION_LENGTH == "medium" else max(1.8, SHORT_FACTOR * footage)
                compact[-1]["say_within_sec"] = round(room, 1)
                compact[-1]["max_letters"] = int(room * NARRATOR_LETTERS_PER_SEC)
                if NARRATION_LENGTH == "short_steady":
                    compact[-1]["min_letters"] = int(SHORT_MIN_FACTOR * footage * NARRATOR_LETTERS_PER_SEC)
            elif NARRATION_LENGTH == "fit" and int(b.get("importance") or 3) <= 3:
                room = max(FIT_MIN_SEC, FIT_FACTOR * (float(b.get("file_end_sec") or 0.0) - float(b.get("file_start_sec") or 0.0)))
                compact[-1]["say_within_sec"] = round(room, 1)
                compact[-1]["max_letters"] = int(room * NARRATOR_LETTERS_PER_SEC)
            elif NARRATION_LENGTH == "skip" and b.get("after_skipped"):
                compact[-1]["after_skipped"] = b["after_skipped"]
            if NARRATION_LENGTH == "recap" and b.get("after_skipped"):
                compact[-1]["after_skipped"] = b["after_skipped"]
            if NARRATION_LENGTH == "recap" and b.get("introduce"):     # 2026-10-25: their first scene was left out
                compact[-1]["introduce"] = b["introduce"]
        style_tag = "v63-flow-storyteller|" if NARRATION_STYLE == "flow" else "v613-storyteller-only-production|"
        if NARRATION_LENGTH != "full":
            style_tag += f"len={NARRATION_LENGTH}|"
        if NARRATION_LENGTH == "recap":
            style_tag += f"target={RECAP_MINUTES:g}|"
        if OUTPUT_LANGUAGE != "my":
            style_tag += f"lang={OUTPUT_LANGUAGE}|"
        if glossary_text:          # a new or edited glossary rewrites the story with its spellings
            style_tag += "glossary=" + hashlib.sha1(glossary_text.encode("utf-8")).hexdigest()[:10] + "|"
        if style:                  # V6.6: a new telling style rewrites the story
            style_tag += "tellstyle=" + hashlib.sha1(style.encode("utf-8")).hexdigest()[:10] + "|"
        digest = hashlib.sha1((style_tag + json.dumps(compact, ensure_ascii=False, sort_keys=True)).encode("utf-8")).hexdigest()[:16]
        cache = story_cache_dir / f"story_part_{part_i:03d}_{digest}.json"
        cached_units, style_kept = {}, set()
        if cache.exists():
            try:
                cached = load_json(cache)
                cached_units = cached.get("units") or {}
                style_kept = set(cached.get("style_kept") or [])
            except Exception:
                cached_units = {}
        if NARRATION_LENGTH == "recap":
            for row in compact:
                unit_token = hashlib.sha1((style_tag + json.dumps(row, ensure_ascii=False, sort_keys=True)).encode("utf-8")).hexdigest()
                unit_path = story_cache_dir / "recap_units" / (unit_token + ".json")
                if unit_path.exists():
                    saved = load_json(unit_path)
                    cached_units[row["beat_id"]] = saved["text"]
                    if saved.get("style_kept"):
                        style_kept.add(row["beat_id"])
        # V6.2: cached fragments must still pass today's style checks; only failing beats
        # are rewritten below, the rest of the part is reused as-is.
        final_units = {
            x: str(cached_units[x]).strip() for x in ids
            if str(cached_units.get(x) or "").strip() and _story_fragment_reusable(cached_units[x], x in style_kept)
        }
        return ids, compact, cache, cached_units, style_kept, final_units

    def write_part(part_i, group, previous_tail, memory_block):
        """One part's fragments: its cache when every fragment still passes today's checks, else written
        (only the missing / failing beats)."""
        ids, compact, cache, cached_units, style_kept, final_units = part_cache(part_i, group)
        if len(final_units) == len(ids):
            print(f"  [V6 STORY RESUME] part {part_i}/{len(groups)} | beats={len(ids)}")
            return final_units
        problems = {
            x: "; ".join(_story_local_style_issues(cached_units[x]))
            for x in ids if x not in final_units and str(cached_units.get(x) or "").strip()
        }
        if final_units:
            print(
                f"  [V6 STORY RESUME] part {part_i}/{len(groups)} | reuse {len(final_units)} | "
                f"rewrite {len(ids) - len(final_units)} beat(s) failing the style check"
            )

        flow_rules = (FLOW_WRITER_RULES if OUTPUT_LANGUAGE == "my" else FLOW_WRITER_RULES_ANY) \
            if NARRATION_STYLE == "flow" else ""
        if OUTPUT_LANGUAGE != "my":
            base_prompt = _writer_prompt_any_language(OUTPUT_LANGUAGE, registry_text, compact, previous_tail, flow_rules,
                                                      memory_block, people_rules, style_block)
        else:
            base_prompt = f"""
You are the FINAL Burmese movie/storytelling narrator writer.
The source timeline below was created DIRECTLY by Gemini from the original video's audio + frames.
Its timestamps are already final. DO NOT realign, reorder, merge, or move content between beat IDs.

CHARACTER REGISTRY:
{registry_text}

{memory_block}

GEMINI SOURCE BEATS IN EXACT CHRONOLOGICAL ORDER:
{json.dumps(compact, ensure_ascii=False)}

TAIL OF PREVIOUS WRITTEN SECTION (continuity only; never repeat it):
{previous_tail[-2200:]}

For EACH beat_id, write exactly one natural Burmese narration fragment belonging ONLY to that beat.

RULES:
- You are an OUTSIDE STORYTELLER/NARRATOR. NEVER speak as a character and NEVER switch into character POV.
- If source_dialogue exists, preserve that spoken turn's COMPLETE meaning in that SAME beat, but RETELL it as reported/indirect storytelling. Do NOT output raw dub dialogue, standalone character lines, or subtitle-like speech.
- Convert first-person dialogue into third-person storyteller wording using the verified speaker/name/reference. Example pattern: “သူက ... လို့ ပြောတယ် / မေးတယ် / ပြန်ဖြေတယ် / တောင်းပန်တယ် / သတိပေးတယ်”. Do not copy “ကျွန်တော်/ငါ/မင်း...” as if the narrator were the character.
- Do NOT use quotation marks to reproduce character speech. Dialogue content must be integrated into narrator sentences while preserving who said what, to whom, and the actual meaning/details.
- If the same or similar line is genuinely spoken twice in the source at different beats, preserve BOTH turns as two chronological narrator events. Never collapse a real repeated turn merely because wording overlaps.
- If visual_action exists, narrate that concrete plot-relevant action/effect in that SAME beat.
- `mixed` beats may naturally combine their dialogue meaning and simultaneous visual action into one fluent storyteller sentence.
- Treat all fragments as consecutive pieces of ONE smooth spoken narration. Use connectors naturally, but do not repeat facts just to create continuity.
- Keep the narrator perspective consistent from the very first beat to the last. The opening must also be storyteller voice, not self-introduction in the protagonist's voice.
- System/phone/on-screen text that matters to the plot should be described by the narrator (for example, a message/system notice appears); do not turn it into a dub line.
- NEVER narrate the footage itself: no "is shown", "we can see", "an image of", "in the video/scene/shot" (ပြထားပါတယ် / ပြသထားပါတယ် / မြင်ရပါတယ် / တွေ့ရပါတယ် / ပုံရိပ် / ဗီဒီယိုထဲမှာ / ဒီမြင်ကွင်းမှာ). A photo, insert or close-up beat (a family portrait, a phone screen, a document) must be told as a story fact inside the characters' world, using only what the beats support. Example: a beat "family portrait of A, B, C smiling together" becomes "A၊ B နဲ့ C တို့ဟာ အတူတူ ပြုံးပျော်နေခဲ့ကြတဲ့ မိသားစုတစ်စုပါ" — never "…မိသားစုပုံကို ပြသထားပါတယ် / တွေ့ရပါတယ်". A phone-screen beat becomes what the character reads or learns from it.
- Never mention timestamps, beat IDs, camera angles, aerial/overhead/wide shots, scenery, traffic, gas stations, or background layout unless the actual beat says a plot-changing event depends on it.
- Never invent names, relationships, motives, causes, actions, results, dialogue, objects, or VFX.
- Use clean conversational Burmese YouTube/movie-recap storyteller style, not formal written Burmese, not a screenplay, not subtitles, and not dubbing.
- Avoid literary forms such as “သည်”, “၏”, “၌”, “ထိုသို့”, “သို့သော်”, “ထို့နောက်”, “ဖြစ်ကြောင်း”, “ပြောကြားခဲ့သည်”.
- No greeting, CTA, intro/outro, or generic filler.
{people_rules}{WRITER_LENGTH_RULES[NARRATION_LENGTH]}
{flow_rules}
{style_block}Under `units`, return EXACTLY every beat_id once and no extra keys.
""".strip()

        # V6.0.1: keep every valid fragment from each response and repair ONLY missing/bad beats.
        # Large all-at-once structured outputs were the main source of 3/3 failures.
        remaining = [x for x in ids if x not in final_units]
        last_model = last_key = ""
        limits = {str(c["beat_id"]): (int(c["max_letters"]), c.get("say_within_sec"))
                  for c in compact if c.get("max_letters")} if NARRATION_LENGTH in ("fit", "short", "short_steady", "medium", "recap") else {}
        minimums = {str(c["beat_id"]): int(c["min_letters"]) for c in compact if c.get("min_letters")}
        style_only = {}      # beat -> its last fragment refused only by the screen-talk guard
        last_text = {}       # beat -> its last fragment of any kind (kept for review after three attempts)
        avoid_model = None   # a model whose fragment had foreign-script letters gets a rest
        for attempt in range(1, 4):
            current_ids = list(remaining)
            current_schema = _story_output_schema_v51(current_ids)
            if not final_units:
                prompt = base_prompt
            else:
                fix_notes = {x: problems[x] for x in current_ids if problems.get(x)}
                prompt = base_prompt + (
                    "\n\nALREADY ACCEPTED FRAGMENTS (keep them; the repaired beats must continue smoothly "
                    "between them and never repeat them):\n"
                    + json.dumps({x: final_units[x] for x in ids if x in final_units}, ensure_ascii=False)
                    + "\n\nREPAIR ONLY THESE STILL-MISSING/INVALID BEATS:\n"
                    + json.dumps(current_ids, ensure_ascii=False)
                    + ("\nPROBLEMS TO FIX:\n" + json.dumps(fix_notes, ensure_ascii=False) if fix_notes else "")
                    + "\nReturn ONLY those beat IDs under units. Do not rewrite already accepted beats."
                )
            data, model, key = pool.generate_json(
                prompt, current_schema,
                temperature=(0.18 if attempt == 1 else 0.06),
                max_output_tokens=32768,
                avoid_model=avoid_model,
            )
            last_model, last_key = model, key
            units = data.get("units") or {}
            if not isinstance(units, dict):
                units = {}

            accepted_now = []
            bad_now = []
            avoid_model = None
            for beat_id in current_ids:
                txt = str(units.get(beat_id) or "").strip()
                if NARRATION_STYLE == "flow" and OUTPUT_LANGUAGE == "my":
                    txt = _strip_address_particles(txt)
                if not txt:
                    bad_now.append((beat_id, "missing/empty"))
                    continue
                last_text[beat_id] = txt
                u_issues = _story_text_unicode_issues(txt)
                s_issues = _story_local_style_issues(txt)
                if u_issues or s_issues:
                    bad_now.append((beat_id, f"unicode={u_issues[:3]} style={s_issues[:3]}"
                                             + (f" | {txt[:50]}" if s_issues and not u_issues else "")))
                    if u_issues:
                        avoid_model = model
                    elif all(_story_style_issue_soft(i) for i in s_issues):
                        style_only[beat_id] = txt
                    continue
                letters = len(re.sub(r"\s", "", txt))
                if beat_id in limits and attempt < 3 and letters > LENGTH_SLACK * limits[beat_id][0]:
                    limit, room = limits[beat_id]
                    bad_now.append((beat_id, f"too long: {letters} letters; tell it in at most {limit} letters "
                                             f"(spoken within {room} s) - keep who did what and the meaning, drop the rest"))
                    continue
                if beat_id in minimums and attempt < 3 and letters * LENGTH_SLACK < minimums[beat_id]:
                    bad_now.append((beat_id, f"too short: {letters} letters; tell it in at least {minimums[beat_id]} "
                                             "letters - tell more of what happens in this beat (the action, the effect, "
                                             "how people react, what is said), as story, no filler"))
                    continue
                final_units[beat_id] = txt
                accepted_now.append(beat_id)

            remaining = [x for x in ids if x not in final_units]
            extras = [str(x) for x in units.keys() if str(x) not in set(current_ids)]
            print(
                f"    [V6 STORY ATTEMPT {attempt}/3] accepted={len(accepted_now)} "
                f"remaining={len(remaining)} extras_ignored={len(extras)}"
            )
            if bad_now:
                print(f"      repair sample: {bad_now[:5]}")
                problems.update(dict(bad_now))
            if not remaining:
                break

        # 2026-10-24 (user: the story must never stop on one beat, it is fixed in the 📜 Script window; Medium
        # length stopped on Isekai G000297 after "too long" and then "စနစ်ကပြသ"; before, a part stopped the run and
        # only a resume kept screen talk): after three attempts a beat keeps its last fragment (one refused only as
        # screen talk / literary first) unless it loops or runs far too long, and the 📜 window's Problem ▶ finds
        # it. A beat with nothing usable is left out with its footage, like a skipped beat; a resume asks it again.
        for x in [x for x in ids if x not in final_units]:
            txt = style_only.get(x) or last_text.get(x, "")
            if txt and OUTPUT_LANGUAGE == "my":
                txt = _story_strip_foreign(txt) or txt
            issues = _story_local_style_issues(txt) if txt else []
            if txt and not any(str(i).startswith(STORY_NEVER_KEEP) for i in issues):
                final_units[x] = txt
                style_kept.add(x)
                why = "; ".join(str(i) for i in issues + _story_text_unicode_issues(txt)) or str(problems.get(x, ""))
                print(f"      [V6 STORY KEPT FOR REVIEW] {x}: {why[:140]} | {txt[:60]}")
            else:
                final_units[x] = ""
                print(f"      [V6 STORY BEAT LEFT OUT] {x}: nothing usable after three attempts "
                      f"({str(problems.get(x) or 'missing')[:120]}); its footage is left out, a resume asks again")

        final_units = {x: str(final_units[x]).strip() for x in ids}
        save_json(cache, {
            "version": "v6.1.3-storyteller-only-production",
            "units": final_units,
            "writer_model": last_model,
            "writer_key": last_key,
            "max_beats_per_part": 20,
            "targeted_missing_only_repair": True,
            "style_kept": sorted(x for x in style_kept if x in final_units),
        })
        if NARRATION_LENGTH == "recap":
            unit_dir = story_cache_dir / "recap_units"
            unit_dir.mkdir(exist_ok=True)
            for row in compact:
                # Recover the exact tag from the part cache's rows, with the same option-only fields.
                tag = "v63-flow-storyteller|" if NARRATION_STYLE == "flow" else "v613-storyteller-only-production|"
                tag += f"len=recap|target={RECAP_MINUTES:g}|"
                if OUTPUT_LANGUAGE != "my":
                    tag += f"lang={OUTPUT_LANGUAGE}|"
                if glossary_text:
                    tag += "glossary=" + hashlib.sha1(glossary_text.encode("utf-8")).hexdigest()[:10] + "|"
                if style:
                    tag += "tellstyle=" + hashlib.sha1(style.encode("utf-8")).hexdigest()[:10] + "|"
                token = hashlib.sha1((tag + json.dumps(row, ensure_ascii=False, sort_keys=True)).encode("utf-8")).hexdigest()
                save_json(unit_dir / (token + ".json"), {"text": final_units[row["beat_id"]], "style_kept": row["beat_id"] in style_kept})
        print(
            f"  [V6 STORY PASS] part {part_i}/{len(groups)} | beats={len(ids)} | "
            f"{last_model} {last_key} | targeted repair enabled"
        )
        return final_units

    # 15-minute chapters (by each part's first beat). The memory before a chapter is folded from the
    # timeline of the chapters before it, so the chapters can be written at once; it is made only as far
    # as a chapter still to be written needs it (a cached story asks nothing), or to the end for a series.
    chapters = []
    for part_i, group in enumerate(groups, start=1):
        chapter = int(float(group[0].get("global_start_sec") or 0.0) // SCRIPT_CHAPTER_SEC) + 1
        if not chapters or chapters[-1][0] != chapter:
            chapters.append((chapter, []))
        chapters[-1][1].append((part_i, group))
    memories = [dict(memory or {})]
    if STORY_MEMORY_ON:
        todo = [k for k, (_c, parts) in enumerate(chapters)
                if any(len(part_cache(i, g)[5]) < len(g) for i, g in parts)]
        for k in range(len(chapters) if series_out else max(todo, default=0)):
            chapter, parts = chapters[k]
            memories.append(_v64_update_memory(pool, memories[-1], chapter,
                                               _v64_chapter_events([b for _i, g in parts for b in g]),
                                               registry_text, memory_dir))
    tails = {}      # chapter index -> the end of its narration (continuity for the next chapter)
    unfinished = []  # parts whose fragments failed every repair this run (asked afresh on the resume)

    def chapter_start(k):
        """The end of the chapter before: written, or cached (several workers: maybe not yet)."""
        if k == 0:
            return ""
        if k - 1 in tails:
            return tails[k - 1]
        last_i, last_g = chapters[k - 1][1][-1]
        ids, _c, _f, _u, _s, ready = part_cache(last_i, last_g)
        return " ".join(ready[x] for x in ids)[-2200:] if len(ready) == len(ids) else ""

    def write_chapter(k, tail):
        block = _v64_memory_block(memories[min(k, len(memories) - 1)]) if STORY_MEMORY_ON else ""
        written, failed = [], []
        for part_i, group in chapters[k][1]:
            try:
                with _block_log():
                    units = write_part(part_i, group, tail, block)
            except RuntimeError as exc:
                # V6.4: such a part is asked afresh on the resume. The chapter goes on, so one resume retries
                # every such part instead of one resume per part (flash-lite writing, 2026-10-02). A Gemini
                # outage still stops at once.
                raise_if_terminal(exc)
                if "after targeted repairs" not in str(exc):
                    raise
                failed.append(str(exc).splitlines()[0][:160])
                continue
            written.append((group, units))
            tail = " ".join(units[str(b["beat_id"])] for b in group)[-2200:]
        return written, tail, failed

    def finish_chapter(k, result):
        written, tails[k], failed = result
        unfinished.extend(failed)
        for group, units in written:
            for b in group:
                all_units.append((b, units[str(b["beat_id"])]))

    _v64_run_in_order(len(chapters), chapter_start, write_chapter, finish_chapter, workers,
                      _v64_worker_keys(pool, workers))
    if unfinished:
        raise RuntimeError(f"story writer: {len(unfinished)} part(s) still missing beats after targeted repairs "
                           f"(asked afresh on the resume): {' | '.join(unfinished[:3])}")

    if series_out and STORY_MEMORY_ON:     # Studio "Same series": the next file starts from this memory
        final = memories[-1]
        if _v64_memory_text(final):
            source = str(beats[0].get("source_file") or "") if beats else ""
            if Path(source).stem.lower() in ("", "source"):       # the Studio's short alias: name the work folder
                folder = Path(series_out).parent
                source = folder.parent.name if folder.name.startswith("lang_") else folder.name
            save_json(series_out, {**{k: v for k, v in final.items() if k != "carried_from"}, "source": source,
                                   "made": time.strftime("%Y-%m-%d %H:%M")})
            print(f"[STORY MEMORY] kept for the next file -> {series_out}", flush=True)

    sync_blocks, story_parts = [], []
    for i, (b, txt) in enumerate(all_units, start=1):
        txt = str(txt or "").strip()
        if not txt:
            continue
        story_parts.append(txt)
        sync_blocks.append({
            "sync_block_id": b.get("_v67_block_id", f"B{i:04d}"),
            **({"recap_scene_id": b["recap_scene_id"]} if "recap_scene_id" in b else {}),
            "unit_kind": "GEMINI_" + str(b.get("kind") or "beat").upper(),
            "anchor_id": b["beat_id"],
            "source_file": b["source_file"],
            "source_start_sec": float(b["file_start_sec"]),
            "source_end_sec": float(b["file_end_sec"]),
            "source_duration": max(0.03, float(b["file_end_sec"]) - float(b["file_start_sec"])),
            "story_item_ids": [b["beat_id"]],
            "narration_text": txt,
            "preserve_story_text": True,
            "gemini_only_timeline_v60": True,
        })
    return " ".join(story_parts).strip(), sync_blocks


def _v6_output_dir(args, base_dir):
    """Studio passes --output-dir so every source file gets its own recap folder."""
    custom = str(getattr(args, "output_dir", "") or "").strip()
    return Path(custom).expanduser().resolve() if custom else Path(base_dir) / "recap_output_v6_gemini"


sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def _v67_recap_target(beats):
    """This video's recap length in minutes (RECAP_MINUTES, also the story cache tag and the render's +10% check):
    N minutes or N% of the video, never longer than the video itself (2026-10-25)."""
    global RECAP_MINUTES
    import recap_selection
    target, source = recap_selection.target_seconds(beats, RECAP_MINUTES, RECAP_PERCENT)
    asked = f"{RECAP_PERCENT:g}% of the video" if RECAP_PERCENT else f"{RECAP_MINUTES:g} min"
    if not RECAP_PERCENT and target < RECAP_MINUTES * 60:
        asked += " (longer than the video: its own length is used)"
    RECAP_MINUTES = round(target / 60, 2)
    print(f"[RECAP LENGTH] {asked} -> target {RECAP_MINUTES:g} min of a {source / 60:.1f} min video", flush=True)
    return RECAP_MINUTES


def _apply_tts_overrides(args):
    """--tts-voice / --tts-rate replace the V4.4 Edge TTS defaults for this run.

    The block TTS cache token already includes voice + rate, so changing either
    regenerates narration audio instead of reusing the old voice.
    """
    global EDGE_TTS_VOICE_V44, EDGE_TTS_RATE_V44, TTS_PROVIDER, VOXCPM_CONFIG, NARRATION_STYLE, OUTPUT_LANGUAGE
    global SLOW_STYLE, FREEZE_BELOW, ANALYSIS_SPEED, RECAP_MINUTES, RECAP_PERCENT, TTS_PAUSE_SEC, NARRATION_LENGTH, STORY_MEMORY_ON, SMOOTH_MOTION, SMOOTH_BELOW_SPEED, CAST_PASS_ON
    SLOW_STYLE = str(getattr(args, "slow_style", "rife"))
    FREEZE_BELOW = float(getattr(args, "freeze_below", 0.6))
    if SLOW_STYLE not in ("rife", "freeze", "mix") or not 0.1 <= FREEZE_BELOW <= 1.0:
        raise SystemExit("--slow-style must be rife/freeze/mix; --freeze-below must be 0.1..1.0")
    ANALYSIS_SPEED = int(getattr(args, "analysis_speed", 1))
    if ANALYSIS_SPEED not in (1, 2):
        raise SystemExit("--analysis-speed must be 1 or 2")
    STORY_MEMORY_ON = not getattr(args, "no_story_memory", False)
    CAST_PASS_ON = not getattr(args, "no_cast_pass", False)
    SMOOTH_MOTION = bool(getattr(args, "smooth_motion", False))
    below = getattr(args, "smooth_below", None)
    if below is not None and not 0.1 <= float(below) <= 1.0:
        raise SystemExit(f"--smooth-below must be 0.1..1.0, got: {below}")
    SMOOTH_BELOW_SPEED = 0.9 if below is None else float(below)
    length = str(getattr(args, "narration_length", "") or "full").strip().lower()
    if length not in WRITER_LENGTH_RULES:
        raise SystemExit(f"--narration-length must be one of {', '.join(WRITER_LENGTH_RULES)}, got: {length}")
    NARRATION_LENGTH = length
    RECAP_MINUTES = float(getattr(args, "recap_minutes", 12.0))
    if not math.isfinite(RECAP_MINUTES) or not 1 <= RECAP_MINUTES <= 600:
        raise SystemExit("--recap-minutes must be 1..600")
    RECAP_PERCENT = float(getattr(args, "recap_percent", 0.0) or 0.0)
    if not math.isfinite(RECAP_PERCENT) or not (RECAP_PERCENT == 0 or 1 <= RECAP_PERCENT <= 100):
        raise SystemExit("--recap-percent must be 1..100")
    pause = getattr(args, "tts_pause", None)
    if pause is not None and not 0.0 <= float(pause) <= 2.0:
        raise SystemExit(f"--tts-pause must be 0..2 seconds, got: {pause}")
    TTS_PAUSE_SEC = None if pause is None else float(pause)
    style = str(getattr(args, "narration_style", "") or "classic").strip().lower()
    if style not in ("classic", "flow"):
        raise SystemExit(f"--narration-style must be classic or flow, got: {style}")
    NARRATION_STYLE = style
    language = str(getattr(args, "narration_language", "") or "my").strip().lower()
    if language not in _languages().LANGUAGES:
        raise SystemExit(f"--narration-language must be one of {', '.join(_languages().LANGUAGES)}, got: {language}")
    if language not in _languages().enabled_codes():
        raise SystemExit("Original to Recap currently supports Burmese output only; other languages are temporarily disabled.")
    OUTPUT_LANGUAGE = language
    voice = str(getattr(args, "tts_voice", "") or "").strip()
    rate = str(getattr(args, "tts_rate", "") or "").strip()
    if voice:
        EDGE_TTS_VOICE_V44 = voice
    if rate:
        if not re.fullmatch(r"[+-]\d{1,3}%", rate):
            raise SystemExit(f"--tts-rate must look like +25% or -10%, got: {rate}")
        EDGE_TTS_RATE_V44 = rate
    provider = str(getattr(args, "tts_provider", "") or "edge").strip().lower()
    if provider not in ("edge", "voxcpm"):
        raise SystemExit(f"--tts-provider must be edge or voxcpm, got: {provider}")
    TTS_PROVIDER = provider
    if provider == "voxcpm":
        # Re-read on every start: the Studio rewrites it before each auto-resume, so a
        # replaced Colab link is picked up without restarting the batch.
        path = str(getattr(args, "voxcpm_config", "") or "").strip()
        try:
            cfg = json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception as exc:
            raise_if_terminal(exc)
            raise SystemExit(f"--tts-provider voxcpm needs a readable --voxcpm-config JSON ({path}): {exc}")
        vox_voice = str(cfg.get("voice") or "").strip()
        speed = str(cfg.get("speed") or "+0%").strip()
        links = [
            {"n": int(link.get("n") or i), "url": str(link.get("url") or "").strip(), "type": str(link.get("type") or "")}
            for i, link in enumerate(cfg.get("links") or [], start=1)
            if isinstance(link, dict) and str(link.get("url") or "").strip()
        ]
        if not vox_voice:
            raise SystemExit("VoxCPM voice is empty: Test a Colab link in the Studio and pick a voice")
        if not links:
            raise SystemExit("VoxCPM needs at least one Colab link URL")
        if not re.fullmatch(r"[+-]\d{1,3}%", speed) or not (-50 <= int(speed[:-1]) <= 100):
            raise SystemExit(f"VoxCPM speed must look like +10% (-50..+100), got: {speed}")
        VOXCPM_CONFIG = {"voice": vox_voice, "speed": speed, "links": links,
                         "per_link": max(1, int(cfg.get("per_link") or 300))}


def run_video_recap_v6_gemini_only(args, files, base_dir, completed_files):
    """V6: original video -> Gemini transcript+visual/VFX timestamps -> Gemini writer -> video-only retime."""
    import os
    try:
        from google.genai import types
    except ImportError as exc:
        raise RuntimeError("V6 Gemini-only pipeline requires google-genai. Install: pip install -U google-genai") from exc

    proxy = ""  # OS network / external VPN
    if proxy:
        os.environ["HTTP_PROXY"] = proxy; os.environ["HTTPS_PROXY"] = proxy
        print(f"[V6] Gemini proxy: {proxy}")

    keys = _collect_gemini_keys(getattr(args, "gemini_env_file", None))
    models = [x.strip() for x in getattr(args, "gemini_models", DEFAULT_GEMINI_MODELS).split(",") if x.strip()]
    pool = GeminiKeyPool(keys, models, timeout_ms=getattr(args, "gemini_timeout_ms", 90000))

    out = _v6_output_dir(args, base_dir)
    clip_root = out / ("_analysis_clips" if ANALYSIS_SPEED == 1 else "_analysis_clips_2x")
    # Studio: other languages reuse the first run's Gemini analysis (it is language-free)
    custom_cache = str(getattr(args, "timeline_cache_dir", "") or "").strip()
    timeline_cache = Path(custom_cache).expanduser().resolve() if custom_cache else out / "gemini_timeline_cache"
    if ANALYSIS_SPEED != 1:
        timeline_cache = timeline_cache / "analysis_2x"
    story_cache = out / "storytelling_cache_v6"
    # Studio: one registry file can be shared by every part of a series (same names across parts).
    registry_path = Path(args.registry_path) if getattr(args, "registry_path", "") else out / "CHARACTER_REGISTRY.json"
    for p in (out, clip_root, timeline_cache, story_cache, registry_path.parent): p.mkdir(parents=True, exist_ok=True)

    if getattr(args, "video_fresh", False):
        clear_path(timeline_cache); clear_path(story_cache); clear_path(out / "smart_sync_thiha_28")
        clear_path(registry_path)
        timeline_cache.mkdir(parents=True, exist_ok=True); story_cache.mkdir(parents=True, exist_ok=True)

    try:
        registry = load_json(registry_path) if registry_path.exists() else {}
    except Exception:
        registry = {}

    completed_map = {item["src"].resolve(): item for item in completed_files}
    all_beats = []
    previous_tail = []
    global_offset = 0.0
    clip_seconds = max(15.0, float(getattr(args, "video_clip_seconds", 55.0)))
    overlap = max(0.0, min(float(getattr(args, "video_clip_overlap", 5.0)), clip_seconds - 1.0))
    if ANALYSIS_SPEED != 1:
        clip_seconds *= ANALYSIS_SPEED
        overlap *= ANALYSIS_SPEED
    step = max(1.0, clip_seconds - overlap)
    video_fps = max(1.0, float(getattr(args, "video_fps", 4.0)))
    test_clips = max(0, int(getattr(args, "video_test_clips", 0)))
    seen = 0
    whisper_on = bool(getattr(args, "whisper_check", False))
    whisper_off = ""          # why the check could not run (reported in TIMELINE_REVIEW.txt)
    review = []               # clips Whisper still disagrees with
    whisper_words = {}        # source file -> Whisper's words (repeated lines are checked against them)
    clip_people = {}          # V6.6: "file|clip index" -> the people that clip's own answer describes (cast pass)
    workers = max(1, int(getattr(args, "gemini_workers", GEMINI_WORKERS) or 1))
    writer_workers = max(1, int(getattr(args, "writer_workers", WRITER_WORKERS) or 1))

    print("\n" + "="*78)
    print("MANJU V6.0 — GEMINI-ONLY TRANSCRIPT + VISUAL/VFX TIMELINE")
    print("="*78)
    if whisper_on:
        print(f"Whisper       : timing check only ({getattr(args, 'model', 'medium')}) — clips whose dialogue "
              f"times disagree are asked again")
    else:
        print("Whisper       : OFF (not loaded, not used for timestamps or transcript)")
    print("Gemini owns   : dialogue transcript + dialogue timing + visual/VFX timing + story writing")
    print("Smart Sync    : Gemini timestamp block -> own TTS -> own retimed video -> concat")
    print(f"Gemini models : {', '.join(models)}")
    print(f"Gemini keys   : {len(keys)}")
    print(f"Gemini workers: {workers} video clip(s) and {writer_workers} story chapter(s) at once")
    print(f"Output        : {out}")
    print("="*78)

    for file_i, src0 in enumerate(files, start=1):
        src = src0.resolve()
        item = completed_map.get(src)
        duration = float((item or {}).get("duration") or ffprobe_duration(src))
        starts=[]; pos=0.0
        while pos < duration - 0.05:
            starts.append(pos); pos += step
        file_cache = timeline_cache / src.stem; file_clips = clip_root / src.stem
        file_cache.mkdir(parents=True, exist_ok=True); file_clips.mkdir(parents=True, exist_ok=True)
        print(f"\n[V6 FILE {file_i}/{len(files)}] {src.name} | {len(starts)} Gemini clip(s)")
        whisper = WhisperReference(src, file_cache, getattr(args, "model", "medium"), getattr(args, "device", "cuda"),
                                   getattr(args, "compute_type", "int8_float16")) if whisper_on else None

        keep = getattr(args, "keep_video_clips", False)
        clips = []
        for ci, clip_start in enumerate(starts):
            if test_clips and seen >= test_clips: break
            seen += 1
            clips.append((ci, clip_start, min(clip_seconds, duration - clip_start)))

        def prepare(k):
            # one worker: as before, the live registry and the previous beats in the prompt. Several:
            # a copy of the registry so far and no previous beats (the clip before may not be done yet;
            # V6.3 halves are asked without them too).
            return (registry, previous_tail[-10:]) if workers == 1 else (copy.deepcopy(registry), [])

        def work(k, prepared):
            reg, context = prepared
            ci, clip_start, clip_dur = clips[k]
            with _block_log():
                return _v64_clip_timeline(pool, types, src, file_cache, file_clips, ci, len(starts), clip_start,
                                          clip_dur, reg, context, whisper, review, video_fps, clip_seconds, keep,
                                          getattr(args, "video_fresh", False))

        def finish(k, data):
            nonlocal previous_tail
            ci, clip_start, clip_dur = clips[k]
            data = _v64_reconcile_clip(file_cache / f"clip_{ci:04d}_v60.json", data, registry, src.name, clip_start)
            save_json(registry_path, registry)
            clip_people[f"{src.name}|{ci}"] = data.get("characters") or []
            local_tail=[]
            for raw in data.get("beats") or []:
                s=max(0.0,min(max(0.0, clip_dur-0.03),float(raw.get("start_sec") or 0.0)))
                e=min(clip_dur,max(s+0.03,float(raw.get("end_sec") or s+0.03)))
                if e <= s: continue
                row=dict(raw)
                row["source_file"]=src.name
                row["file_start_sec"]=clip_start+s; row["file_end_sec"]=clip_start+e
                row["global_start_sec"]=global_offset+clip_start+s; row["global_end_sec"]=global_offset+clip_start+e
                row["analysis_clip_index"]=ci; row["analysis_clip_start_sec"]=clip_start; row["analysis_clip_duration_sec"]=clip_dur
                all_beats.append(row)
                local_tail.append({
                    "source_file": row.get("source_file"),
                    "file_start_sec": round(row["file_start_sec"],3), "file_end_sec": round(row["file_end_sec"],3),
                    "kind": row.get("kind"), "speaker": row.get("speaker"),
                    "source_dialogue": row.get("source_dialogue"), "visual_action": row.get("visual_action"),
                })
            previous_tail.extend(local_tail); previous_tail=previous_tail[-16:]

        _v64_run_in_order(len(clips), prepare, work, finish, workers, _v64_worker_keys(pool, workers))
        if whisper is not None:
            if whisper.off_reason:
                whisper_off = whisper_off or whisper.off_reason
                print(f"  [WHISPER CHECK] off for {src.name}: {whisper.off_reason}", flush=True)
            whisper.close()        # frees the GPU before TTS / render
            whisper_words[src.name] = _v64_file_words(file_cache)
        global_offset += duration
        if test_clips and seen >= test_clips: break

    beats = _dedupe_gemini_beats_v60(all_beats)
    beats = _filter_gemini_beats_v60(beats)
    if whisper_words:
        beats = _v64_drop_repeated_lines(beats, whisper_words)
    beats.sort(key=lambda x:(float(x.get("global_start_sec") or 0.0), float(x.get("global_end_sec") or 0.0)))
    for i,b in enumerate(beats,start=1): b["beat_id"]=f"G{i:06d}"

    save_json(out / "GEMINI_STORY_TIMELINE.json", beats)
    _write_gemini_transcript_v60(beats, out / "GEMINI_TRANSCRIPT.txt")
    save_json(registry_path, registry)

    if test_clips:
        print(f"[V6 TEST] Timeline saved with {len(beats)} beat(s); final story/video skipped.")
        return
    if not beats:
        raise RuntimeError("V6 Gemini-only pipeline produced no story-relevant beats")

    series = getattr(args, "series_memory", False)
    cast = None
    story_beats = beats
    if CAST_PASS_ON:            # V6.6: who each clip's IDs really are, before names are given out
        cast, story_beats = _v66_cast_pass(pool, beats, clip_people, registry, out,
                                           registry_path.parent / CAST_FILE if series else None, OUTPUT_LANGUAGE)
        if cast:
            save_json(out / "GEMINI_STORY_TIMELINE_CAST.json", story_beats)
    story_registry = cast or registry
    glossary = _v64_name_glossary(pool, story_beats, story_registry, registry_path.parent / NAME_GLOSSARY_FILE,
                                  OUTPUT_LANGUAGE, cast_checked=bool(cast))
    if NARRATION_LENGTH in ("skip", "fit", "recap"):        # V6.5 Studio "Story length"
        scores = _v65_beat_importance(pool, story_beats, json.dumps(_compact_registry(story_registry), ensure_ascii=False),
                                      story_cache / "importance")
        story_beats = [dict(b, importance=scores.get(str(b["beat_id"]), 3)) for b in story_beats]
        if NARRATION_LENGTH == "skip":
            story_beats = _v65_skip_minor(story_beats, out / "SKIPPED_BEATS.txt")
        elif NARRATION_LENGTH == "recap":
            import recap_selection
            rate_factor = max(0.5, 1 + int(EDGE_TTS_RATE_V44[:-1]) / 100) / 1.25
            scenes = recap_selection.group_scenes(story_beats, NARRATOR_LETTERS_PER_SEC * rate_factor)
            _v67_recap_target(story_beats)
            important = {cid for cid, c in (cast or {}).items() if str(c.get("importance")) in ("main", "supporting")}
            recurring = recap_selection.recurring_people(scenes, important)
            kept = recap_selection.choose_scenes(scenes, RECAP_MINUTES * 60, recurring)
            story_beats = recap_selection.kept_beats(scenes, kept, out / "KEPT_SCENES.txt", RECAP_MINUTES * 60, recurring)
            intro_kept = sum(1 for sid, _w in recurring.values() if sid in kept)
            print(f"[RECAP] kept {len(kept)}/{len(scenes)} scenes; {intro_kept}/{len(recurring)} recurring people "
                  f"keep their first scene, the rest are introduced in one line", flush=True)
        else:
            fit = sum(1 for b in story_beats if int(b["importance"]) <= 3)
            print(f"[STORY LENGTH] fit: {fit}/{len(story_beats)} ordinary beats told within "
                  f"{FIT_FACTOR}x their footage; key beats in full", flush=True)
    style = _v66_style_from_file(getattr(args, "story_style_file", ""))
    if style:
        print(f"[TELLING STYLE] {style.splitlines()[0][:120]}", flush=True)
    labels = _v66_people_labels(cast, glossary) if cast else None
    preview = float(getattr(args, "style_preview", 0) or 0)
    if preview > 0:          # Studio "Preview style": a sample of the story only, nothing else is changed
        path = _v66_style_preview(pool, story_beats, story_registry, story_cache,
                                  _v64_glossary_text(glossary, cast_checked=bool(cast)), labels, style, out, preview)
        print(f"✅ STYLE PREVIEW: {path}", flush=True)
        return
    story, sync_blocks = _build_story_from_gemini_beats_v60(
        pool, story_beats, story_registry, story_cache, _v64_glossary_text(glossary, cast_checked=bool(cast)),
        memory=_v64_load_memory(getattr(args, "story_memory_in", "")) if STORY_MEMORY_ON else None,
        series_out=out / STORY_MEMORY_FILE if series else None, workers=writer_workers,
        labels=labels, style=style)
    import script_edits
    story, sync_blocks = script_edits.apply_edits(
        sync_blocks, out, _story_text_unicode_issues, _story_local_style_issues)
    (out / "FULL_STORYTELLING_BURMESE.txt").write_text(story + "\n", encoding="utf-8-sig")
    save_json(out / "SYNC_NARRATION_BLOCKS.json", sync_blocks)
    if getattr(args, "script_only", False):          # Studio "Script only": no TTS, no render
        script, script_timed = _v64_write_script(sync_blocks, out)
        if whisper_on:
            _v64_write_review(review, out, whisper_off, video=False)
        print(f"Script (timed)    : {script_timed}")
        print(f"✅ SCRIPT READY: {script}")
        return
    def adjust_recap(blocks, durations):
        nonlocal kept, story_beats
        new_kept = recap_selection.drop_over_target(scenes, kept, blocks, durations, RECAP_MINUTES * 60, recurring)
        if new_kept == kept:
            raise RuntimeError("Recap exceeds target +10%; opening/ending scenes alone are too long. Choose a larger target.")
        kept = new_kept
        story_beats = recap_selection.kept_beats(scenes, kept, out / "KEPT_SCENES.txt", RECAP_MINUTES * 60, recurring)
        rewritten, revised = _build_story_from_gemini_beats_v60(
            pool, story_beats, story_registry, story_cache, _v64_glossary_text(glossary, cast_checked=bool(cast)),
            memory=_v64_load_memory(getattr(args, "story_memory_in", "")) if STORY_MEMORY_ON else None,
            workers=writer_workers, labels=labels, style=style)
        rewritten, revised = script_edits.apply_edits(revised, out, _story_text_unicode_issues, _story_local_style_issues)
        (out / "FULL_STORYTELLING_BURMESE.txt").write_text(rewritten + "\n", encoding="utf-8-sig")
        save_json(out / "SYNC_NARRATION_BLOCKS.json", revised)
        return rewritten, revised
    final_video, report = _render_thiha28_smart_sync(sync_blocks, completed_files, out, pool, beats,
        canonical_story_text=story, recap_adjust=adjust_recap if NARRATION_LENGTH == "recap" else None)
    if whisper_on:
        review_path = _v64_write_review(review, out, whisper_off)
        if whisper_off:
            print(f"[WHISPER CHECK] off: {whisper_off}")
        elif review:
            print(f"[WHISPER CHECK] {len(review)} clip(s) still disagree with Whisper — see {review_path}")
        else:
            print("[WHISPER CHECK] every clip agrees with Whisper")

    print("\n" + "="*78)
    print("V6.1 GEMINI-ONLY + V4.1-STYLE BLOCK SMART SYNC DONE")
    print("="*78)
    print(f"Gemini transcript : {out / 'GEMINI_TRANSCRIPT.txt'}")
    print(f"Gemini timeline   : {out / 'GEMINI_STORY_TIMELINE.json'}")
    print(f"Story             : {out / 'FULL_STORYTELLING_BURMESE.txt'}")
    print(f"Smart Sync report : {out / 'smart_sync_thiha_28' / 'SMART_SYNC_REPORT.json'}")
    print(f"FINAL VIDEO       : {final_video}")
    print("="*78)


def main():
    parser = argparse.ArgumentParser(description="Manju V6 Gemini-only video storytelling (legacy Whisper available with --legacy-whisper)")
    parser.add_argument("input", nargs="?", default=".", help="Input video/audio file or folder")
    parser.add_argument("--model", default="medium")
    parser.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    parser.add_argument("--compute-type", default="int8_float16")
    parser.add_argument("--language", default="zh")
    parser.add_argument("--beam-size", type=int, default=5)
    parser.add_argument("--chunk-minutes", type=float, default=10.0)
    parser.add_argument("--vad", action="store_true", help="Enable Silero VAD")
    parser.add_argument("--keep-audio", action="store_true",
                        help="Keep temporary 16 kHz WAV cache (off by default)")
    parser.add_argument("--no-audio-reference", action="store_true",
                        help="Do not create compact MP3 audio references for Gemini")
    parser.add_argument("--no-combined-audio-reference", action="store_true",
                        help="Keep per-file MP3 references but skip COMBINED_AUDIO_REFERENCE.mp3")
    parser.add_argument("--audio-reference-bitrate", default="64k",
                        help="MP3 bitrate for speaker-reference audio (default: 64k)")
    parser.add_argument("--fresh", action="store_true")
    parser.add_argument("--legacy-whisper", action="store_true", help="Use the old Whisper-first pipeline. Default is V6 Gemini-only video transcript/timestamps.")
    parser.add_argument("--no-video-recap", action="store_true", help="Run only the original V3.1 transcription stage")
    parser.add_argument("--gemini-env-file", default=DEFAULT_GEMINI_ENV_FILE, help=f".env key pool (default: {DEFAULT_GEMINI_ENV_FILE})")
    parser.add_argument("--gemini-models", default=DEFAULT_GEMINI_MODELS,
                        help="Comma-separated Gemini model fallback list")
    parser.add_argument("--gemini-timeout-ms", type=int, default=90000)
    parser.add_argument("--proxy", default=DEFAULT_GEMINI_PROXY, help=f"HTTP/HTTPS proxy (default: {DEFAULT_GEMINI_PROXY})")
    parser.add_argument("--video-clip-seconds", type=float, default=55.0, help="Short video evidence window (default 55s)")
    parser.add_argument("--video-clip-overlap", type=float, default=5.0, help="Overlap between evidence clips (default 5s)")
    parser.add_argument("--video-fps", type=float, default=4.0, help="Gemini inline video sampling FPS (default 4)")
    parser.add_argument("--video-fresh", action="store_true", help="Clear V4 scene/recap cache and analyze video again")
    parser.add_argument("--keep-video-clips", action="store_true", help="Keep temporary compressed Gemini analysis clips")
    parser.add_argument("--no-verify-uncertain", dest="verify_uncertain", action="store_false",
                        help="Disable second-pass recheck for uncertain/low-confidence visual events")
    parser.set_defaults(verify_uncertain=True)
    parser.add_argument("--video-test-clips", type=int, default=0,
                        help="Analyze only first N video clips and skip final recap; useful for testing")
    parser.add_argument("--output-dir", default="",
                        help="V6: write the recap into this folder (default: <input folder>/recap_output_v6_gemini)")
    parser.add_argument("--registry-path", default="",
                        help="V6: character registry JSON to use/update; share one file across parts of a series")
    parser.add_argument("--tts-voice", default="", help=f"Edge TTS voice (default: {EDGE_TTS_VOICE_V44})")
    parser.add_argument("--tts-rate", default="",
                        help=f"Edge TTS rate such as +25%% (default: {EDGE_TTS_RATE_V44.replace('%', '%%')})")
    parser.add_argument("--tts-provider", default="edge", choices=["edge", "voxcpm"],
                        help="Block TTS: edge (default) or voxcpm (Colab links from --voxcpm-config)")
    parser.add_argument("--narration-language", default="my", choices=_languages().enabled_codes(),
                        help="enabled narration language code from app/languages.py (my = Burmese)")
    parser.add_argument("--timeline-cache-dir", default="",
                        help="Gemini timeline cache folder to use (share one analysis between languages)")
    parser.add_argument("--narration-style", default="classic", choices=["classic", "flow"],
                        help="classic = one TTS per block (V6.2); flow = one continuous voice-over, "
                             "consecutive blocks voiced together and cut at word boundaries")
    parser.add_argument("--voxcpm-config", default="",
                        help='VoxCPM JSON: {"voice": ..., "speed": "+0%%", "links": [{"n", "url", "type"}]}')
    parser.add_argument("--script-only", action="store_true",
                        help="stop after the story: write NARRATOR_SCRIPT.txt (+ _TIMED) instead of voice and video")
    parser.add_argument("--slow-style", choices=("rife", "freeze", "mix"), default="rife", help="Experimental slow-beat rendering")
    parser.add_argument("--freeze-below", type=float, default=0.6, help="Freeze below this video speed")
    parser.add_argument("--analysis-speed", type=int, choices=(1, 2), default=1, help="Experimental accelerated analysis, source-time verification")
    parser.add_argument("--recap-minutes", type=float, default=12.0, help="Whole-scene recap target in minutes")
    parser.add_argument("--recap-percent", type=float, default=0.0,
                        help="Whole-scene recap target as a percent of the video (overrides --recap-minutes)")
    parser.add_argument("--narration-length", default="full", choices=sorted(WRITER_LENGTH_RULES),
                        help="full = LENGTH IS ALLOWED (V6.2); short = each fragment fits its beat; short_steady = "
                             "short + at least 0.8x its beat, picture never over 1.25x (a pause after the line)")
    parser.add_argument("--tts-pause", type=float, default=None,
                        help="classic Edge TTS: cut each block's own silence and end it with this pause (seconds)")
    parser.add_argument("--smooth-below", type=float, default=None,
                        help="with --smooth-motion: only blocks slower than this get RIFE (default 0.9; 0.5 = faster render)")
    parser.add_argument("--smooth-motion", action="store_true",
                        help=f"slowed blocks (under {SMOOTH_BELOW_SPEED}x) get RIFE AI in-between frames instead of "
                             "repeated frames (GPU, slower render)")
    parser.add_argument("--gemini-workers", type=int, default=GEMINI_WORKERS,
                        help=f"video clips asked at once, each on its own key (default {GEMINI_WORKERS}; 1 = one at a "
                             "time with the previous beats in each clip prompt, as before)")
    parser.add_argument("--writer-workers", type=int, default=WRITER_WORKERS,
                        help=f"15-minute story chapters written at once (default {WRITER_WORKERS}; 1 = in order)")
    parser.add_argument("--series-memory", action="store_true",
                        help="Studio 'Same series': keep this file's story memory in <output-dir>/STORY_MEMORY.json "
                             "for the next file")
    parser.add_argument("--story-memory-in", default="",
                        help="start from the previous file's STORY_MEMORY.json (the story so far)")
    parser.add_argument("--style-preview", type=float, default=0,
                        help="V6.6: write only ~N seconds of the story in the chosen style (STYLE_PREVIEW.txt) and stop")
    parser.add_argument("--story-style-file", default="",
                        help="V6.6: TELLING_STYLE.json (preset light/calm/gripping/humor, notes, sample) - how the story is told")
    parser.add_argument("--no-cast-pass", action="store_true",
                        help="V6.6: skip the cast pass (who each clip's character IDs are); the writer gets the registry as before")
    parser.add_argument("--no-story-memory", action="store_true",
                        help="write without the 15-minute chapter memory (as before 2026-10-02)")
    parser.add_argument("--whisper-check", action="store_true",
                        help="V6.4: Whisper (--model, GPU) listens to each Gemini clip; clips whose dialogue times "
                             "disagree are asked again, the rest are listed in TIMELINE_REVIEW.txt")
    args = parser.parse_args()
    _apply_tts_overrides(args)

    if not command_exists("ffmpeg") or not command_exists("ffprobe"):
        print("ERROR: ffmpeg/ffprobe not found in PATH.")
        sys.exit(1)

    input_path = Path(args.input).expanduser().resolve()
    if not input_path.exists():
        print(f"ERROR: Input does not exist: {input_path}")
        sys.exit(1)

    if input_path.is_file():
        files = [input_path]
        base_dir = input_path.parent
    else:
        files = sorted(
            [p for p in input_path.iterdir() if p.is_file() and p.suffix.lower() in SUPPORTED_EXTS],
            key=natural_sort_key,
        )
        base_dir = input_path

    if not files:
        print("No supported video/audio files found.")
        sys.exit(0)

    # V6 DEFAULT: Gemini owns transcript + dialogue timestamps + visual/VFX timestamps.
    # Whisper is not loaded at all unless --legacy-whisper or --no-video-recap is explicitly requested.
    if not getattr(args, "legacy_whisper", False) and not getattr(args, "no_video_recap", False):
        overall_start = time.time()
        completed_files = []
        for src in files:
            completed_files.append({
                "src": src.resolve(),
                "duration": ffprobe_duration(src),
                "segments": [],
                "audio_reference": None,
            })
        run_video_recap_v6_gemini_only(args, files, base_dir, completed_files)
        print("\n" + "=" * 78)
        print("ALL DONE - V6.0 GEMINI ONLY")
        print("=" * 78)
        print("Whisper       : " + ("timing check only" if getattr(args, "whisper_check", False) else "NOT USED"))
        print(f"Output        : {_v6_output_dir(args, base_dir)}")
        print(f"Total runtime : {(time.time() - overall_start) / 60:.1f} min")
        print("If interrupted, run the SAME command again to resume Gemini clip/story caches.")
        print("=" * 78)
        return

    # Only legacy transcription mode needs faster-whisper/CTranslate2.
    if ctranslate2 is None or WhisperModel is None:
        print("ERROR: legacy Whisper mode requested but faster-whisper is not installed.")
        print("Run: pip install -U faster-whisper")
        sys.exit(1)

    out_dir = base_dir / "transcript_output_v3_1"
    cache_root = out_dir / "_chunk_cache"
    audio_root = out_dir / "_audio_cache"
    retry_tmp = out_dir / "_retry_tmp"
    audio_reference_root = out_dir / "audio_reference"

    previous_manual_review = out_dir / "MANUAL_REVIEW.txt"
    previous_review_ranges = (
        {} if args.fresh else load_previous_manual_review_ranges(previous_manual_review)
    )

    if args.fresh:
        clear_path(cache_root)
        clear_path(audio_root)
        clear_path(retry_tmp)
        clear_path(audio_reference_root)

    out_dir.mkdir(parents=True, exist_ok=True)
    cache_root.mkdir(parents=True, exist_ok=True)
    audio_root.mkdir(parents=True, exist_ok=True)
    retry_tmp.mkdir(parents=True, exist_ok=True)
    if not args.no_audio_reference:
        audio_reference_root.mkdir(parents=True, exist_ok=True)

    print("=" * 78)
    print("MANJU WHISPER TRANSCRIBER V3.1 — NATURAL SORT + VAD RETRY 2")
    print("=" * 78)
    print(f"Input        : {input_path}")
    print(f"Files        : {len(files)}")
    print(f"Model        : {args.model}")
    print(f"Device       : {args.device}")
    print(f"Compute type : {args.compute_type}")
    print(f"Chunk size   : {args.chunk_minutes:g} minute(s)")
    print(f"VAD          : {'ON' if args.vad else 'OFF'}")
    print(f"Output       : {out_dir}")
    print(f"Audio ref    : {'OFF' if args.no_audio_reference else 'MP3 ' + args.audio_reference_bitrate}")
    print("=" * 78)
    print("FILE ORDER:")
    for i, p in enumerate(files, start=1):
        print(f"  {i:02d}. {p.name}")
    print("=" * 78)
    if previous_review_ranges:
        total_old_reviews = sum(len(v) for v in previous_review_ranges.values())
        print(f"PREVIOUS MANUAL REVIEW: {total_old_reviews} unresolved range(s) found.")
        print("Affected cached chunk(s) will be re-transcribed automatically with VAD Retry 2.")
        print("=" * 78)

    try:
        supported = ctranslate2.get_supported_compute_types(args.device)
        print(f"Supported compute types on {args.device}: {sorted(supported)}")
        if args.compute_type not in supported:
            print(f"[WARN] {args.compute_type!r} is not reported as supported on {args.device}.")
    except Exception as exc:
        raise_if_terminal(exc)
        print(f"[WARN] Could not query supported compute types: {exc}")

    print(f"\nLoading faster-whisper model '{args.model}'...")
    print("First V3.1 run may download the CTranslate2 model once.")
    try:
        model = WhisperModel(args.model, device=args.device, compute_type=args.compute_type)
    except Exception as exc:
        raise_if_terminal(exc)
        print("\nERROR: Could not load faster-whisper model:")
        print(exc)
        print("\nIf VRAM-related, retry with: --compute-type int8")
        print("If CUDA/cuDNN/cuBLAS-related, install the runtime libraries required by CTranslate2.")
        sys.exit(1)

    retry_log_lines = []
    manual_review_lines = []
    completed_files = []
    chunk_seconds = max(60.0, args.chunk_minutes * 60.0)
    overall_start = time.time()

    for file_index, src in enumerate(files, start=1):
        print("\n" + "#" * 78)
        print(f"[FILE {file_index}/{len(files)}] {src.name}")
        print("#" * 78)

        full_wav = audio_root / f"{src.stem}.wav"
        file_cache_dir = cache_root / src.stem
        file_retry_tmp = retry_tmp / src.stem
        file_cache_dir.mkdir(parents=True, exist_ok=True)
        file_retry_tmp.mkdir(parents=True, exist_ok=True)

        audio_reference = None
        if not args.no_audio_reference:
            audio_reference = audio_reference_root / f"{src.stem}.mp3"
            if not audio_reference.exists():
                print(f"\nCreating compact speaker-reference audio ({args.audio_reference_bitrate} MP3)...")
                extract_reference_audio(src, audio_reference, args.audio_reference_bitrate)
                print(f"  [OK] Audio reference: {audio_reference.name}")
            else:
                print(f"\nUsing existing audio reference: {audio_reference.name}")

        if not full_wav.exists():
            print("\nExtracting 16 kHz mono audio...")
            extract_full_audio(src, full_wav)
        else:
            print("\nUsing cached extracted audio.")

        file_duration = ffprobe_duration(full_wav)
        total_chunks = int((file_duration + chunk_seconds - 1) // chunk_seconds)
        all_file_segments = []
        file_wall_start = time.time()

        for ci in range(total_chunks):
            chunk_start = ci * chunk_seconds
            chunk_dur = min(chunk_seconds, file_duration - chunk_start)
            cache_json = file_cache_dir / f"chunk_{ci:04d}.json"

            print(
                f"\n--- Chunk {ci + 1}/{total_chunks} "
                f"[{srt_time(chunk_start)} -> {srt_time(chunk_start + chunk_dur)}] ---"
            )

            chunk_segments = None
            chunk_end = chunk_start + chunk_dur
            old_review_overlap = any(
                ranges_overlap(chunk_start, chunk_end, r_start, r_end)
                for r_start, r_end in previous_review_ranges.get(src.name, [])
            )

            if old_review_overlap:
                print("  [RECHECK] Previous MANUAL_REVIEW overlaps this chunk.")
                print("            Re-transcribing this chunk so Retry 2 (VAD) can run.")
            elif cache_json.exists():
                try:
                    cached = load_json(cache_json)
                    chunk_segments = cached["segments"]
                    print(f"  [RESUME] loaded cached chunk ({len(chunk_segments)} segments)")
                except Exception:
                    print("  [WARN] Cache unreadable; transcribing this chunk again.")
                    try:
                        cache_json.unlink()
                    except Exception:
                        pass

            if chunk_segments is None:
                chunk_wav = file_cache_dir / f"chunk_{ci:04d}.wav"
                extract_chunk(full_wav, chunk_wav, chunk_start, chunk_dur, speech_clean=False)
                print("  Transcribing with faster-whisper...")
                started = time.time()

                try:
                    chunk_segments, _ = transcribe_audio(
                        model, chunk_wav, args.language, args.beam_size, args.vad,
                        duration_hint=chunk_dur, show_progress=True,
                    )
                except Exception as exc:
                    raise_if_terminal(exc)
                    print("\nTRANSCRIPTION ERROR:")
                    print(exc)
                    print("Finished chunks remain cached. Re-run the same command after fixing the issue.")
                    raise

                print(
                    f"  Initial pass: {len(chunk_segments)} segments "
                    f"in {(time.time() - started) / 60:.1f} min"
                )

                chunk_segments = repair_repetitions(
                    model, src.name, chunk_segments, full_wav, chunk_start,
                    file_duration, file_retry_tmp, args.language, args.beam_size,
                    retry_log_lines, manual_review_lines,
                )

                save_json(cache_json, {
                    "source": src.name,
                    "chunk_index": ci,
                    "chunk_start": chunk_start,
                    "chunk_duration": chunk_dur,
                    "model": args.model,
                    "compute_type": args.compute_type,
                    "segments": chunk_segments,
                })

                try:
                    chunk_wav.unlink()
                except Exception:
                    pass
                print("  [OK] Chunk saved to resume cache.")
            else:
                # Upgrade old resume caches in place: if a cached chunk still contains
                # a suspicious repetition loop, retry only that window rather than
                # forcing a full --fresh transcription.
                cached_blocks = detect_repetition_blocks(chunk_segments)
                if cached_blocks:
                    print(f"  [CACHE CHECK] {len(cached_blocks)} suspicious repetition block(s) remain; repairing only those window(s)...")
                    chunk_segments = repair_repetitions(
                        model, src.name, chunk_segments, full_wav, chunk_start,
                        file_duration, file_retry_tmp, args.language, args.beam_size,
                        retry_log_lines, manual_review_lines,
                    )
                    save_json(cache_json, {
                        "source": src.name,
                        "chunk_index": ci,
                        "chunk_start": chunk_start,
                        "chunk_duration": chunk_dur,
                        "model": args.model,
                        "compute_type": args.compute_type,
                        "segments": chunk_segments,
                    })
                    print("  [OK] Updated old resume cache after repetition repair.")

            for seg in chunk_segments:
                item = dict(seg)
                item["start"] = float(seg["start"]) + chunk_start
                item["end"] = float(seg["end"]) + chunk_start
                all_file_segments.append(item)

        all_file_segments.sort(key=lambda s: (float(s["start"]), float(s["end"])))
        file_srt = out_dir / f"{src.stem}.srt"
        file_txt = out_dir / f"{src.stem}.txt"
        write_srt(all_file_segments, file_srt)
        write_txt(all_file_segments, file_txt)

        completed_files.append({"src": src, "duration": file_duration, "segments": all_file_segments, "audio_reference": audio_reference})
        print(f"\n[OK] Finished file: {src.name}")
        print(f"  SRT     : {file_srt.name}")
        print(f"  TXT     : {file_txt.name}")
        print(f"  Runtime : {(time.time() - file_wall_start) / 60:.1f} min for {file_duration / 60:.1f} min audio")

        if not args.keep_audio:
            try:
                full_wav.unlink()
            except Exception:
                pass

    combined_txt = out_dir / "COMBINED_TRANSCRIPT.txt"
    combined_srt = out_dir / "COMBINED_TRANSCRIPT.srt"
    global_offset = 0.0
    srt_index = 1

    with combined_txt.open("w", encoding="utf-8-sig") as txt_f, combined_srt.open("w", encoding="utf-8-sig") as srt_f:
        for item in completed_files:
            src = item["src"]
            segments = item["segments"]
            txt_f.write("\n" + "=" * 84 + "\n")
            txt_f.write(f"FILE: {src.name}\n")
            txt_f.write("=" * 84 + "\n\n")
            for seg in segments:
                text = (seg.get("text") or "").strip()
                if text:
                    txt_f.write(f"[{srt_time(seg['start'])}] {text}\n")
            srt_index = append_combined_srt(srt_f, segments, global_offset, srt_index)
            global_offset += float(item["duration"])

    retry_log = out_dir / "HALLUCINATION_RETRY_LOG.txt"
    retry_log.write_text(
        ("\n".join(retry_log_lines) + "\n") if retry_log_lines
        else "No automatic repetition/hallucination retry was triggered.\n",
        encoding="utf-8-sig",
    )

    manual_review = out_dir / "MANUAL_REVIEW.txt"
    if manual_review_lines:
        body = "Only the sections below still need manual review.\n\n" + ("\n" + "-" * 72 + "\n").join(manual_review_lines)
    else:
        body = "No unrepaired repetition/hallucination sections remain.\n"
    manual_review.write_text(body, encoding="utf-8-sig")

    shutil.rmtree(retry_tmp, ignore_errors=True)

    combined_audio = out_dir / "COMBINED_AUDIO_REFERENCE.mp3"
    audio_map = out_dir / "AUDIO_REFERENCE_MAP.txt"
    upload_guide = out_dir / "GEMINI_UPLOAD_GUIDE.txt"
    combined_audio_created = False

    if not args.no_audio_reference:
        write_audio_reference_map(completed_files, audio_map, combined_audio.name)
        if not args.no_combined_audio_reference:
            refs = [item.get("audio_reference") for item in completed_files if item.get("audio_reference")]
            try:
                combined_audio_created = create_combined_audio_reference(refs, combined_audio)
                if combined_audio_created:
                    write_gemini_upload_guide(upload_guide, combined_audio, audio_map)
            except Exception as exc:
                raise_if_terminal(exc)
                print(f"[WARN] Could not create combined audio reference: {exc}")
                print("       Per-file files in audio_reference/ are still usable.")

    # V4: after the proven V3.1 transcript is complete, analyze the actual video.
    run_video_recap_v4(args, files, base_dir, completed_files)

    print("\n" + "=" * 78)
    print("ALL DONE - V3.1")
    print("=" * 78)
    print(f"Output        : {out_dir}")
    print(f"Combined TXT  : {combined_txt}")
    print(f"Combined SRT  : {combined_srt}")
    print(f"Retry log     : {retry_log}")
    print(f"Manual review : {manual_review}")
    if not args.no_audio_reference:
        print(f"Audio refs    : {audio_reference_root}")
        print(f"Audio map     : {audio_map}")
        if combined_audio_created:
            print(f"Combined audio: {combined_audio}")
            print(f"Gemini guide  : {upload_guide}")
    print(f"Total runtime : {(time.time() - overall_start) / 60:.1f} min")
    print("If interrupted, run the SAME command again to resume cached chunks.")
    print("=" * 78)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nStopped by user. Finished chunks are cached; run the same command again to resume.")
        sys.exit(130)
