"""Hybrid Demucs worker. Only the child process imports torch/torchaudio."""
from __future__ import annotations
import json
import subprocess
import sys
from pathlib import Path
import numpy as np
SR = 44100
MODEL = "HDEMUCS_HIGH_MUSDB_PLUS"
_VERSION = 1
CHUNK_SECONDS = 10.0
OVERLAP_SECONDS = 1.0
def _signature(source: Path) -> dict:
    stat = Path(source).stat()
    return {"v": _VERSION, "model": MODEL, "source": [str(Path(source).resolve()), stat.st_size, stat.st_mtime_ns]}


def _is_ready(out: Path, meta: Path, signature: dict) -> bool:
    try:
        return out.is_file() and json.loads(meta.read_text(encoding="utf-8")).get("signature") == signature
    except (OSError, ValueError):
        return False


def _separate_here(source: Path, folder: Path, ffmpeg: str, log=print) -> Path:
    """Child process: the separation itself (only torch's cuDNN is loaded here)."""
    import warnings

    warnings.filterwarnings("ignore", category=FutureWarning)
    import soundfile as sf
    import torch
    import torchaudio

    folder = Path(folder)
    out, meta = folder / "background_44k.wav", folder / "background.json"
    mixture = folder / "background_source_44k.wav"
    signature = _signature(Path(source))
    try:
        tmp = mixture.with_name(mixture.stem + ".part.wav")
        subprocess.run([ffmpeg, "-hide_banner", "-nostdin", "-y", "-v", "error", "-i", str(source), "-vn",
                        "-ac", "2", "-ar", str(SR), "-c:a", "pcm_s16le", str(tmp)], check=True)
        tmp.replace(mixture)

        # The model expects the mixture normalized by the whole track's mono mean/std.
        total = total_sq = 0.0
        count = 0
        with sf.SoundFile(str(mixture)) as reader:
            if reader.frames < SR // 2:
                raise ValueError("source audio is shorter than half a second")
            for block in reader.blocks(blocksize=SR * 30, dtype="float32", always_2d=True):
                mono = block.mean(axis=1, dtype=np.float64)
                total += float(mono.sum())
                total_sq += float((mono ** 2).sum())
                count += mono.size
        mean = total / max(1, count)
        std = max(1e-5, (total_sq / max(1, count) - mean * mean) ** 0.5)

        devices = ["cuda", "cpu"] if torch.cuda.is_available() else ["cpu"]
        for device in devices:
            try:
                names = _run_model(torchaudio, torch, sf, device, mixture, out, mean, std)
                break
            except RuntimeError as exc:  # torch.cuda.OutOfMemoryError is a RuntimeError
                if device == "cuda" and "out of memory" in str(exc).lower():
                    log("GPU memory is full; separating on the CPU instead (slower)")
                    torch.cuda.empty_cache()
                    continue
                raise
        meta.write_text(json.dumps({"signature": signature, "sources": names, "device": device}), encoding="utf-8")
        log(f"music/effects track ready on {device} (original voices removed)")
        return out
    finally:
        mixture.unlink(missing_ok=True)


def _run_model(torchaudio, torch, sf, device, mixture: Path, out: Path, mean: float, std: float) -> list[str]:
    model = getattr(torchaudio.pipelines, MODEL).get_model().to(device).eval()
    names = list(getattr(model, "sources", ["drums", "bass", "other", "vocals"]))
    keep = [i for i, name in enumerate(names) if name != "vocals"]
    hop, overlap = int(SR * CHUNK_SECONDS), int(SR * OVERLAP_SECONDS)
    part = out.with_name(out.stem + ".part.wav")
    with sf.SoundFile(str(mixture)) as reader, \
            sf.SoundFile(str(part), "w", samplerate=SR, channels=2, subtype="PCM_16") as writer:
        frames = reader.frames
        position, tail = 0, None
        while position < frames:
            reader.seek(position)
            chunk = reader.read(hop + overlap, dtype="float32", always_2d=True)
            wave = torch.from_numpy(((chunk.T - mean) / std).copy()).unsqueeze(0).to(device)
            with torch.inference_mode():
                stems = model(wave)[0]  # (sources, channels, time)
            background = (stems[keep].sum(0) * std + mean * len(keep)).cpu().numpy()  # (2, time)
            if tail is not None:
                k = min(overlap, background.shape[1], tail.shape[1])
                ramp = np.linspace(0.0, 1.0, k, dtype=np.float32)
                background[:, :k] = background[:, :k] * ramp + tail[:, :k] * (1.0 - ramp)
            if frames - position <= hop + overlap:  # the rest fits: last chunk
                writer.write(np.clip(background.T, -1.0, 1.0))
                break
            writer.write(np.clip(background[:, :hop].T, -1.0, 1.0))
            tail = background[:, hop:hop + overlap]
            position += hop
    part.replace(out)
    return names


def main(argv=None) -> int:
    """python -m dubber.background SOURCE JOB_FOLDER [FFMPEG]: the child process of separate_background."""
    args = list(sys.argv[1:] if argv is None else argv)
    _separate_here(Path(args[0]), Path(args[1]), args[2] if len(args) > 2 else "ffmpeg",
                   log=lambda message: print("BG:", message, flush=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
