"""RIFE 4.25 network (HolyWu/vs-rife, MIT, see LICENSE) used by smooth_motion.py."""
