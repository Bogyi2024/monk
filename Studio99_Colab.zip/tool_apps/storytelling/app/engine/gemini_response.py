"""Classify Gemini replies without logging source text, response bodies or API keys."""
import re


ATTENTION = 'GEMINI_NEEDS_ATTENTION'


class GeminiReplyError(RuntimeError):
    def __init__(self, kind, detail, *, retry_keys=False, terminal=False):
        self.kind, self.retry_keys, self.terminal = kind, retry_keys, terminal
        super().__init__((ATTENTION + ': ' if terminal else '') + detail)


def raise_if_terminal(error):
    if isinstance(error, GeminiReplyError) and error.terminal:
        raise error


def field(value, name, default=None):
    return value.get(name, default) if isinstance(value, dict) else getattr(value, name, default)


def enum_name(value):
    name = str(getattr(value, 'value', value) or 'UNSPECIFIED').rsplit('.', 1)[-1].upper()
    return name if re.fullmatch(r'[A-Z][A-Z0-9_]{0,63}', name) else 'UNKNOWN'


def safe_error(error, keys=()):
    text = str(error)
    for key in sorted((str(key) for key in keys if key), key=len, reverse=True):
        text = text.replace(key, '[redacted]')
    text = re.sub(r'AIza[\w-]{12,}', '[redacted]', text)
    return text[:600]


def transport_json_error(error):
    raw = str(getattr(error, 'doc', '') or '').lstrip()
    kind = 'empty HTTP body' if not raw else 'HTML HTTP body' if raw.startswith('<') else 'non-JSON HTTP body'
    return GeminiReplyError('transport_json', f'API/connection reply: {kind}; SDK could not decode it (check network/proxy/service).', retry_keys=True)


def response_text(response):
    candidates = field(response, 'candidates') or []
    feedback = field(response, 'prompt_feedback')
    blocked = enum_name(field(feedback, 'block_reason'))
    finish = enum_name(field(candidates[0], 'finish_reason')) if candidates else 'UNSPECIFIED'
    usage = field(response, 'usage_metadata')
    counts = []
    for name in ('candidates_token_count', 'thoughts_token_count'):
        value = field(usage, name)
        if isinstance(value, int):
            counts.append(f'{name}={value}')
    detail = f'finish={finish}, prompt_block={blocked}, candidates={len(candidates)}'
    if counts:
        detail += ', ' + ', '.join(counts)
    if blocked not in {'UNSPECIFIED', 'BLOCK_REASON_UNSPECIFIED', 'NONE'} or finish in {
        'SAFETY', 'RECITATION', 'BLOCKLIST', 'PROHIBITED_CONTENT', 'SPII', 'IMAGE_SAFETY',
        'IMAGE_PROHIBITED_CONTENT', 'MODEL_ARMOR',
    }:
        raise GeminiReplyError('blocked', 'Gemini က အဖြေကို ပိတ်ထားပါတယ်။ ' + detail,
                               terminal=True)
    # Do not repair/publish a partial timeline just because its JSON can be closed.
    if finish in {'MAX_TOKENS', 'CONTINUATION'}:
        raise GeminiReplyError('truncated', 'Gemini အဖြေက token limit ကြောင့် ဖြတ်တောက်သွားပါတယ်။ ' + detail)
    text = field(response, 'text') or ''
    if not isinstance(text, str) or not text.strip():
        parsed = field(response, 'parsed')
        if isinstance(parsed, (dict, list)) and parsed:
            return '', detail
        raise GeminiReplyError('empty_reply', 'Gemini က အဖြေဗလာ ပြန်ပေးပါတယ်။ ' + detail, retry_keys=True)
    return text, detail


def response_json(response, schema, parse_text):
    text, detail = response_text(response)
    data = field(response, 'parsed')
    if hasattr(data, 'model_dump'):
        data = data.model_dump()
    if data is None:
        try:
            data = parse_text(text)
        except (ValueError, TypeError):
            raise GeminiReplyError('malformed_json', f'Gemini JSON ပုံစံ မမှန်ပါ။ {detail}, text_chars={len(text)}') from None
    expected = enum_name(field(schema, 'type'))
    if expected == 'OBJECT' and not isinstance(data, dict):
        raise GeminiReplyError('malformed_json', 'Gemini JSON object မဟုတ်ပါ။ ' + detail)
    required = field(schema, 'required') or []
    if isinstance(data, dict) and any(name not in data for name in required):
        raise GeminiReplyError('malformed_json', 'Gemini JSON မှာ လိုအပ်တဲ့ field တွေ မပြည့်ပါ။ ' + detail)
    return data
