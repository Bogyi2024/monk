"""Smooth slow motion (2026-10-10): a slowed picture gets real in-between frames from RIFE 4.25
(AI frame interpolation) instead of the same frame shown again and again.

The timing is not touched: output frame i shows exactly the source time the ffmpeg path shows
(i * step from the slice start), and the part has exactly the same frame count. Only how that
moment is drawn changes:
  * held copies (animation drawn on twos/threes) are skipped, so motion is spread over the real
    image changes;
  * a long still is kept still; only its last 3 source frames move into the next image;
  * a scene cut is never blended (same frame switch as ffmpeg's fps filter).

Motion is found on a half-size copy (1080p: ~23 RIFE passes/s on an RTX 3050 Laptop instead of ~8)
and the full-size pictures are moved with it, so the picture stays sharp. One RIFE pass per pair of
images (at the middle moment) serves every output frame between them: the motion is scaled to each
frame's moment (straight-line motion). A 0.3x block has 4-8 output frames per pair: on 12 speed-test
blocks 1486 passes became 441 and the render ~2x faster (2026-10-10), median 42.6 dB PSNR against one
pass per frame (a fast zoom can be a little softer for a frame). 2-3 passes per pair (PAIR_SPLITS)
were only slightly closer and 1.7-2x slower. Decoding and encoding run in their own threads so the
GPU never waits for the pipes.

torch runs in its own process (`python smooth_motion.py --serve`): the caller never imports
torch/CUDA (faster-whisper's older cudnn in the same process crashed torch in DUB, 2026-10-07),
and a GPU failure only ends that process; the caller then renders the part the old way.

Model: rife425/flownet_v4.25.pkl (24.6 MB, github.com/HolyWu/vs-rife releases, MIT) with its
network code rife425/IFNet_HDv3_v4_25.py + warplayer.py from the same repo.
"""
from __future__ import annotations

import json
import math
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable

HERE = Path(__file__).resolve().parent
MODEL = HERE / "rife425" / "flownet_v4.25.pkl"
TAG = "rife425"                 # goes into part cache keys when a part was drawn this way
HOLD_DIFF = 0.6                 # mean |diff| (0-255, quarter-size) below this = the same drawing held
CUT_DIFF = 45.0                 # mean |diff| above this = scene cut / whip pan: no in-between
CUT_HIST = 0.30                 # colour histogram change above this = scene cut (motion keeps colours)
MAX_GAP_FRAMES = 3              # in-betweens span at most the last 3 source frames before a new image
PAIR_SPLITS = 1                 # RIFE passes per pair of images, at moments 1/(K+1) .. K/(K+1)
# Where the two moved pictures still disagree (mean |diff| 0-1 over a small area) RIFE did not find the
# motion: a sword swung across the frame faded in and out (2026-10-11). There the nearest real frame is
# shown instead of a 50/50 mix (solid, steps like before); GUARD_LO..GUARD_HI fades between the two.
GUARD_LO, GUARD_HI = 0.06, 0.14
# YUV->RGB->YUV with the default scaler made the picture ~1/255 darker than the normal parts;
# accurate rounding + full chroma gives the source values back exactly.
SWS = "bicubic+accurate_rnd+full_chroma_int"
CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def source_info(ffprobe: str, src: str | Path) -> dict[str, Any]:
    """Size, frame rate and colour of a source; the RGB round trip must use the source's own matrix."""
    cmd = [ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries",
           "stream=width,height,r_frame_rate,avg_frame_rate,color_range,color_space,color_transfer,color_primaries",
           "-of", "json", str(src)]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       creationflags=CREATE_NO_WINDOW)
    st = (json.loads(r.stdout or "{}").get("streams") or [{}])[0]

    def rate(text: str) -> float:
        num, _, den = str(text or "0/1").partition("/")
        try:
            return float(num) / float(den or 1)
        except (ValueError, ZeroDivisionError):
            return 0.0

    fps = rate(st.get("avg_frame_rate")) or rate(st.get("r_frame_rate")) or 30.0
    space = str(st.get("color_space") or "")
    tags = []
    for opt, key in (("-colorspace", "color_space"), ("-color_primaries", "color_primaries"),
                     ("-color_trc", "color_transfer"), ("-color_range", "color_range")):
        value = str(st.get(key) or "")
        if value and value != "unknown":
            tags += [opt, value]
    return {
        "width": int(st.get("width") or 0), "height": int(st.get("height") or 0),
        "fps": max(1.0, min(120.0, fps)),
        "matrix": "bt709" if space == "bt709" else "bt601",
        "range": "pc" if str(st.get("color_range") or "") == "pc" else "tv",
        "tags": tags,
    }


def wanted_down(width: int, height: int) -> int:
    """Half size for 1080p, quarter for 4K, full size for 720p and below."""
    return max(1, int(round(min(width, height) / 540.0)))


# --------------------------------------------------------------------------------------------
# Client side (no torch here)
# --------------------------------------------------------------------------------------------
class SmoothMotion:
    """One RIFE process for a whole render; render() calls from several threads are serialised."""

    def __init__(self, python: str | None = None, log: Callable[[str], None] = print):
        self.python = python or sys.executable
        self.log = log
        self.proc: subprocess.Popen | None = None
        self.device = ""
        self.lock = threading.Lock()

    def start(self, timeout: float = 180.0) -> bool:
        if not MODEL.is_file():
            self.log(f"⚠️ Smooth motion OFF: model not found ({MODEL})")
            return False
        try:
            self.proc = subprocess.Popen(
                [self.python, "-X", "utf8", "-u", str(Path(__file__).resolve()), "--serve"],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                text=True, encoding="utf-8", creationflags=CREATE_NO_WINDOW)
        except OSError as exc:
            self.log(f"⚠️ Smooth motion OFF: {exc}")
            return False
        reply = self._read(timeout)
        if not reply or not reply.get("ready"):
            self.log(f"⚠️ Smooth motion OFF: {(reply or {}).get('error') or 'the RIFE process did not start'}"
                     " — normal render")
            self.close()
            return False
        self.device = str(reply.get("device") or "")
        return True

    def _read(self, timeout: float) -> dict | None:
        box: list[str] = []
        reader = threading.Thread(target=lambda: box.append(self.proc.stdout.readline()), daemon=True)
        reader.start()
        reader.join(timeout)
        if not box or not box[0].strip():
            return None
        try:
            return json.loads(box[0])
        except ValueError:
            return {"ok": False, "error": box[0].strip()[:300]}

    def render(self, job: dict[str, Any]) -> dict[str, Any]:
        """Draw one part. Raises RuntimeError when the part could not be drawn."""
        with self.lock:
            if self.proc is None or self.proc.poll() is not None:
                raise RuntimeError("RIFE process is not running")
            self.proc.stdin.write(json.dumps(job, ensure_ascii=False) + "\n")
            self.proc.stdin.flush()
            # ~1 s per 20 frames; a generous ceiling so a stuck GPU can't hang the render
            reply = self._read(120.0 + 2.0 * int(job.get("nf") or 0))
        if reply is None:
            self.close()
            raise RuntimeError("RIFE process stopped answering")
        if not reply.get("ok"):
            raise RuntimeError(str(reply.get("error") or "RIFE part failed"))
        return reply

    def close(self) -> None:
        proc, self.proc = self.proc, None
        if proc is None:
            return
        try:
            proc.stdin.close()
            proc.wait(timeout=10)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass


def part_job(*, ffmpeg: str, src: str | Path, start: float, dur: float, info: dict[str, Any],
             width: int, height: int, nf: int, step: float, out: str | Path, out_fps: str,
             enc: list[str], vf_in: str = "", vf_out: str = "") -> dict[str, Any]:
    """Output frame i shows source time min(i * step, dur - 1 ms) after the slice start.

    vf_in runs on the decoded source (e.g. Storytelling's scale/pad to the canvas) and must give
    width x height; vf_out runs on the drawn RGB frames before the final yuv420p conversion.
    """
    return {
        "ffmpeg": ffmpeg, "src": str(src), "start": float(start), "dur": float(dur),
        "src_fps": float(info["fps"]), "matrix": info["matrix"], "range": info["range"],
        "tags": list(info["tags"]), "width": int(width), "height": int(height), "nf": int(nf),
        "step": float(step), "tmax": max(0.0, float(dur) - 0.001), "out": str(out), "out_fps": str(out_fps),
        "enc": list(enc), "vf_in": vf_in, "vf_out": vf_out,
    }


# --------------------------------------------------------------------------------------------
# Server side (torch, own process)
# --------------------------------------------------------------------------------------------
def _serve() -> None:
    import numpy as np
    import torch
    import torch.nn.functional as F

    sys.path.insert(0, str(HERE))
    from rife425.IFNet_HDv3_v4_25 import Head, IFNet
    from rife425.warplayer import warp

    def say(obj: dict) -> None:
        sys.stdout.write(json.dumps(obj) + "\n")
        sys.stdout.flush()

    try:
        if not torch.cuda.is_available():
            raise RuntimeError("torch has no CUDA GPU here")
        dev = torch.device("cuda")
        torch.backends.cudnn.benchmark = True
        sd = torch.load(MODEL, map_location="cpu", weights_only=True)
        sd = {k.replace("module.", ""): v for k, v in sd.items() if "module." in k}
        net = IFNet(1.0, False)
        net.load_state_dict(sd, strict=False)
        net.eval().to(dev, torch.half)
        head = Head()
        head.load_state_dict({k.replace("encode.", ""): v for k, v in sd.items() if "encode." in k})
        head.eval().to(dev, torch.half)
    except Exception as exc:   # no torch / no GPU / bad model: the caller renders the old way
        say({"ready": False, "error": f"{type(exc).__name__}: {exc}"})
        return
    say({"ready": True, "device": torch.cuda.get_device_name(0)})
    dt = torch.half
    grids: dict[tuple[int, int], tuple] = {}

    def grid(pw: int, ph: int):
        if (pw, ph) not in grids:
            div = torch.tensor([(pw - 1.0) / 2.0, (ph - 1.0) / 2.0], dtype=torch.float, device=dev)
            hor = torch.linspace(-1.0, 1.0, pw, device=dev).view(1, 1, 1, pw).expand(-1, -1, ph, -1)
            ver = torch.linspace(-1.0, 1.0, ph, device=dev).view(1, 1, ph, 1).expand(-1, -1, -1, pw)
            grids[(pw, ph)] = (div, torch.cat([hor, ver], 1))
        return grids[(pw, ph)]

    def hist(small):
        n = small.shape[0] * small.shape[1]
        return torch.stack([torch.histc(small[..., c], bins=32, min=0, max=255) for c in range(3)]) / n

    @torch.inference_mode()
    def run_job(job: dict) -> dict:
        t_start = time.time()
        w, h, nf = int(job["width"]), int(job["height"]), int(job["nf"])
        down = wanted_down(w, h)
        pw, ph = math.ceil(w / down / 64) * 64, math.ceil(h / down / 64) * 64
        fw, fh = pw * down, ph * down
        div, grd = grid(pw, ph)
        fdiv, fgrd = grid(fw, fh)
        m, rng = job["matrix"], job["range"]

        def prep(rgb):
            full = torch.from_numpy(rgb.copy()).to(dev).permute(2, 0, 1).unsqueeze(0).to(dt) / 255.0
            full = F.pad(full, (0, fw - w, 0, fh - h))
            small = full if down == 1 else F.interpolate(full, scale_factor=1.0 / down, mode="bilinear",
                                                         antialias=True)
            return full, small, head(small)

        def pair_motion(a, b, tr):
            """RIFE at moment tr -> full-size motion to a, to b, a's blend weight, tr."""
            img0, img1, f0, f1 = a[1].clamp(0, 1), b[1].clamp(0, 1), a[2], b[2]
            ts = torch.full([1, 1, ph, pw], tr, dtype=dt, device=dev)
            blocks = [net.block0, net.block1, net.block2, net.block3, net.block4]
            flow = mask = feat = None
            w0, w1 = img0, img1
            for i, blk in enumerate(blocks):      # IFNet.forward, keeping the final flow and mask
                if flow is None:
                    flow, mask, feat = blk(torch.cat((img0, img1, f0, f1, ts), 1), None, scale=net.scale_list[i])
                else:
                    wf0 = warp(f0, flow[:, :2], div, grd)
                    wf1 = warp(f1, flow[:, 2:4], div, grd)
                    fd, mask, feat = blk(torch.cat((w0, w1, wf0, wf1, ts, mask, feat), 1), flow,
                                         scale=net.scale_list[i])
                    flow = flow + fd
                if i < 4:
                    w0 = warp(img0, flow[:, :2], div, grd)
                    w1 = warp(img1, flow[:, 2:4], div, grd)
            mk = torch.sigmoid(mask)
            if down > 1:
                flow = F.interpolate(flow, scale_factor=down, mode="bilinear") * down
                mk = F.interpolate(mk, scale_factor=down, mode="bilinear")
            flow = torch.cat([flow[:, 0:1] / fdiv[0], flow[:, 1:2] / fdiv[1],      # grid units, float32:
                              flow[:, 2:3] / fdiv[0], flow[:, 3:4] / fdiv[1]], 1).float()  # half would be ~0.5 px off
            return flow, mk.float(), tr

        def from_pair(a, b, pm, t):
            """The moment t between a and b, from the pass at tr (t == tr is exactly RIFE's own answer)."""
            flow, mk, tr = pm
            w0 = F.grid_sample(a[0].float(), (fgrd + flow[:, :2] * (t / tr)).permute(0, 2, 3, 1), mode="bilinear",
                               padding_mode="border", align_corners=True)
            w1 = F.grid_sample(b[0].float(), (fgrd + flow[:, 2:4] * ((1.0 - t) / (1.0 - tr))).permute(0, 2, 3, 1),
                               mode="bilinear", padding_mode="border", align_corners=True)
            k0, k1 = mk * ((1.0 - t) / (1.0 - tr)), (1.0 - mk) * (t / tr)
            mix = (k0 * w0 + k1 * w1) / (k0 + k1 + 1e-3)
            d = F.avg_pool2d((w0 - w1).abs().mean(1, keepdim=True), 2)          # half size is enough here
            d = F.avg_pool2d(F.max_pool2d(d, 5, 1, 2), 7, 1, 3)                 # widen to the whole object
            guard = F.interpolate(((d - GUARD_LO) / (GUARD_HI - GUARD_LO)).clamp(0, 1), size=mix.shape[-2:],
                                  mode="bilinear")
            near = (a[0] if t < 0.5 else b[0]).float()
            return (mix + (near - mix) * guard)[:, :, :h, :w]

        vf_in = ",".join(x for x in (job.get("vf_in") or "", f"scale=in_color_matrix={m}:in_range={rng}:flags={SWS}",
                                     "format=rgb24") if x)
        dec = subprocess.Popen(
            [job["ffmpeg"], "-hide_banner", "-loglevel", "error", "-ss", f"{job['start']:.6f}",
             "-t", f"{job['dur']:.6f}", "-i", job["src"], "-an", "-vf", vf_in,
             "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=CREATE_NO_WINDOW)
        vf_out = ",".join(x for x in (job.get("vf_out") or "", f"scale=out_color_matrix={m}:out_range={rng}:flags={SWS}",
                                      "format=yuv420p") if x)
        out = Path(job["out"])
        enc = subprocess.Popen(
            [job["ffmpeg"], "-y", "-hide_banner", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24",
             "-s", f"{w}x{h}", "-r", job["out_fps"], "-i", "-", "-vf", vf_out, "-frames:v", str(nf),
             "-r", job["out_fps"], *job["enc"], "-pix_fmt", "yuv420p", *job["tags"],
             "-movflags", "+faststart", str(out)],
            stdin=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=CREATE_NO_WINDOW)
        size = w * h * 3
        stop = threading.Event()
        frames_in: queue.Queue = queue.Queue(maxsize=6)      # decoded frames, read ahead of the GPU
        frames_out: queue.Queue = queue.Queue(maxsize=8)     # drawn frames, written behind the GPU
        write_error: list[BaseException] = []

        def read_ahead():
            try:
                while not stop.is_set():
                    buf = dec.stdout.read(size)
                    item = buf if len(buf) == size else None
                    while not stop.is_set():
                        try:
                            frames_in.put(item, timeout=0.2)
                            break
                        except queue.Full:
                            pass
                    if item is None:
                        return
            except (OSError, ValueError):
                try:
                    frames_in.put_nowait(None)
                except queue.Full:
                    pass

        def write_behind():
            item = None
            try:
                while (item := frames_out.get()) is not None:
                    enc.stdin.write(item)
            except (OSError, ValueError) as exc:
                write_error.append(exc)
                while item is not None:                   # keep taking frames so the GPU loop never blocks
                    item = frames_out.get()

        reader = threading.Thread(target=read_ahead, daemon=True)
        writer = threading.Thread(target=write_behind, daemon=True)
        reader.start()
        writer.start()

        def drawings():
            """(time, tensors, is_cut) for each new drawing; held copies are skipped."""
            last = last_h = None
            k = 0
            while True:
                buf = frames_in.get()
                if buf is None:
                    return
                rgb = np.frombuffer(buf, np.uint8).reshape(h, w, 3)
                small = torch.from_numpy(rgb[::4, ::4].copy()).to(dev).float()
                if last is None:
                    last, last_h = small, hist(small)
                    yield k / job["src_fps"], prep(rgb), False
                else:
                    diff = float((small - last).abs().mean())
                    if diff >= HOLD_DIFF:
                        hs = hist(small)
                        cut = diff > CUT_DIFF or float((hs - last_h).abs().sum(1).mean()) > CUT_HIST
                        last, last_h = small, hs
                        yield k / job["src_fps"], prep(rgb), cut
                k += 1

        made = passes = 0
        pm = pm_key = None
        splits = max(1, int(job.get("pair_splits") or PAIR_SPLITS))
        moments = [(j + 1) / (splits + 1) for j in range(splits)]
        try:
            gen = drawings()
            a = next(gen, None)
            if a is None:
                raise RuntimeError("no frames decoded from the source slice")
            b = next(gen, None)
            max_gap = MAX_GAP_FRAMES / job["src_fps"]
            half = 0.5 / job["src_fps"]
            for i in range(nf):
                s = min(i * job["step"], job["tmax"])
                # a cut switches half a source frame early, like ffmpeg's fps filter (round=near)
                while b is not None and (b[0] <= s or (b[2] and b[0] - half <= s)):
                    a, b = b, next(gen, None)
                img = a[1][0][:, :, :h, :w]          # full-size picture of drawing a
                if b is not None and not b[2]:
                    ta = max(a[0], b[0] - max_gap)
                    if s > ta:
                        t = (s - ta) / (b[0] - ta)
                        if t > 0.02:
                            t = min(t, 0.98)
                            tr = min(moments, key=lambda x: abs(x - t))
                            if pm_key != (a[0], b[0], tr):
                                pm, pm_key = pair_motion(a[1], b[1], tr), (a[0], b[0], tr)
                                passes += 1
                            img = from_pair(a[1], b[1], pm, t)
                            made += 1
                rgb = (img[0].clamp(0, 1) * 255.0).round().byte().permute(1, 2, 0).contiguous().cpu().numpy()
                frames_out.put(rgb.tobytes())
                if write_error:
                    break
        finally:
            frames_out.put(None)
            writer.join()
            try:
                enc.stdin.close()
            except OSError:
                pass
            stop.set()
            dec.kill()
            reader.join(5)
            dec.stdout.close()
            dec.wait()
        err = enc.stderr.read().decode("utf-8", "replace")
        if enc.wait() != 0 or write_error:
            raise RuntimeError(f"encode failed: {err[-1500:] or write_error}")
        return {"ok": True, "frames": nf, "inbetween": made, "rife_passes": passes,
                "sec": round(time.time() - t_start, 2)}

    for line in sys.stdin:
        if not line.strip():
            continue
        try:
            say(run_job(json.loads(line)))
        except Exception as exc:
            if "out of memory" in str(exc).lower():
                torch.cuda.empty_cache()
            say({"ok": False, "error": f"{type(exc).__name__}: {exc}"[-1500:]})


if __name__ == "__main__" and "--serve" in sys.argv:
    _serve()
