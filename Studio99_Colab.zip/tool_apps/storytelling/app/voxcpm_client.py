"""VoxCPM on Google Colab (Gradio / LocalTunnel links) for Storytelling Recap Studio.

Same Colab API as VOXCPM_LOCAL_RECAP-V2: /voices -> voice names, /generate(text, voice) ->
one audio file. Connection handling is ported from V2 (LocalTunnel bypass header, three
connect attempts, reconnect + retry on a failed /generate).

Scheduling differs from V2's fixed ranges: every link pulls the next block from one shared
queue (at most BLOCKS_PER_LINK per run, V2's per-link budget). A link that dies hands its
unfinished block back, so the other links carry on and a run only stops when every link is
gone. Finished blocks are files on disk, so START again resumes after a link is replaced.
"""
from __future__ import annotations

import inspect
import math
import shutil
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any, Callable

LINK_GRADIO = "Gradio"
LINK_LOCALTUNNEL = "LocalTunnel"
LINK_TYPES = (LINK_GRADIO, LINK_LOCALTUNNEL)
BLOCKS_PER_LINK = 300
LOCALTUNNEL_HEADERS = {"Bypass-Tunnel-Reminder": "true", "User-Agent": "gradio-client"}

Emit = Callable[[dict], None]


def _noop(_msg: str) -> None:
    pass


def required_links(block_count: int, per_link: int = BLOCKS_PER_LINK) -> int:
    count = max(0, int(block_count))
    return int(math.ceil(count / max(1, int(per_link)))) if count else 0


def normalize_url(url: str) -> str:
    text = str(url or "").strip().rstrip("/")
    if not text:
        raise ValueError("Colab link URL is empty")
    if not text.startswith(("http://", "https://")):
        text = "https://" + text
    return text


def normalize_link_type(value: str | None, url: str = "") -> str:
    text = str(value or "").strip().lower()
    if text in {"localtunnel", "local tunnel", "local_tunnel", "loca.lt", "lt"}:
        return LINK_LOCALTUNNEL
    if text in {"gradio", "gradio.live", "normal", "default"}:
        return LINK_GRADIO
    return LINK_LOCALTUNNEL if ".loca.lt" in str(url or "").lower() else LINK_GRADIO


def detail(exc: BaseException | None) -> str:
    if exc is None:
        return "unknown error"
    message = str(exc).strip()
    return f"{type(exc).__name__}: {message}" if message else repr(exc)


def voice_names(value: Any) -> list[str]:
    """/voices may answer with a list, {"voices": [...]} or nested Gradio values."""
    if isinstance(value, dict):
        for key in ("voices", "value", "data", "items"):
            if key in value:
                return voice_names(value[key])
        out: list[str] = []
        for item in value.values():
            out.extend(voice_names(item))
        return list(dict.fromkeys(x for x in out if x))
    if isinstance(value, (list, tuple)):
        out = []
        for item in value:
            out.extend([item.strip()] if isinstance(item, str) and item.strip() else voice_names(item))
        return list(dict.fromkeys(out))
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return []


def result_path(value: Any) -> Path:
    """Local path of the audio file gradio_client downloaded for /generate."""
    if isinstance(value, Path):
        return value
    if isinstance(value, str):
        return Path(value)
    if isinstance(value, dict):
        for key in ("path", "name", "value", "file"):
            if key in value:
                try:
                    return result_path(value[key])
                except Exception:
                    pass
    if isinstance(value, (list, tuple)):
        for item in value:
            try:
                return result_path(item)
            except Exception:
                pass
    path_attr = getattr(value, "path", None)
    if path_attr:
        return Path(str(path_attr))
    raise RuntimeError(f"/generate returned no audio file ({type(value).__name__})")


def connect(url: str, link_type: str | None = None, download_dir: Path | None = None, log=_noop):
    """gradio_client.Client for one Colab link.

    Attempts 1-2 connect directly (Colab tunnels do not need Gemini's proxy); attempt 3
    uses the environment's proxy, if any, in case the direct route is blocked.
    """
    try:
        from gradio_client import Client
    except Exception as exc:
        raise RuntimeError("gradio_client is not installed: pip install -U gradio_client") from exc
    normalized = normalize_url(url)
    mode = normalize_link_type(link_type, normalized)
    try:
        params = inspect.signature(Client).parameters
    except Exception:
        params = {}
    open_kwargs = any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values())
    accepts = lambda name: not params or open_kwargs or name in params
    last: BaseException | None = None
    for attempt in range(1, 4):
        kwargs: dict[str, Any] = {"verbose": False}
        if accepts("httpx_kwargs"):
            kwargs["httpx_kwargs"] = {"timeout": 30.0, "trust_env": attempt == 3}
        if mode == LINK_LOCALTUNNEL and accepts("headers"):
            kwargs["headers"] = dict(LOCALTUNNEL_HEADERS)
        if download_dir is not None and accepts("download_files"):
            Path(download_dir).mkdir(parents=True, exist_ok=True)
            kwargs["download_files"] = str(download_dir)
        try:
            return Client(normalized, **kwargs)
        except TypeError as exc:      # very old gradio_client without these keywords
            last = exc
            if attempt == 1:
                try:
                    return Client(normalized, verbose=False)
                except TypeError:
                    return Client(normalized)
        except Exception as exc:
            last = exc
        log(f"⚠️ connect attempt {attempt}/3 ({'proxy' if attempt == 3 else 'direct'}) failed: {detail(last)}")
        if attempt < 3:
            time.sleep(1.5 * attempt)
    raise RuntimeError(f"cannot reach {normalized} — Colab link closed? Replace it with a new URL. Last error: {detail(last)}")


def fetch_voices(url: str, link_type: str | None = None, log=_noop, client_factory=None) -> list[str]:
    client = (client_factory or connect)(url, link_type, None, log)
    names = voice_names(client.predict(api_name="/voices"))
    if not names:
        raise RuntimeError("/voices returned no voice names (is api_name='voices' in the Colab code?)")
    return names


def generate_to(client, text: str, voice: str, dest: Path) -> Path:
    """One /generate call; the downloaded file is moved to dest (the temp copy is removed)."""
    produced = result_path(client.predict(text, voice, api_name="/generate")).expanduser()
    if not produced.is_file():
        raise RuntimeError(f"downloaded audio not found: {produced}")
    if produced.stat().st_size < 1000:
        raise RuntimeError(f"audio file is empty ({produced.stat().st_size} bytes)")
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_name(dest.name + ".part")
    shutil.copyfile(produced, part)
    part.replace(dest)
    try:
        produced.unlink()
        produced.parent.rmdir()      # gradio_client puts every download in its own folder
    except OSError:
        pass
    return dest


def generate_blocks(jobs: list[tuple[str, str, Path]], links: list[dict], voice: str, download_root: Path,
                    emit: Emit, per_link: int = BLOCKS_PER_LINK, client_factory=None,
                    retry_wait: float = 1.5) -> None:
    """Voice every (block_id, text, dest) job over all links at once.

    links: [{"n": row number in the UI, "url": ..., "type": Gradio|LocalTunnel}].
    emit gets {"link": n, "status": ...}, {"link": n, "log": ...} and
    {"done": block_id, "count": k, "total": len(jobs), "link": n}.
    Raises RuntimeError naming the unfinished blocks and the failed links.
    """
    factory = client_factory or connect
    pending = deque(jobs)
    cond = threading.Condition()
    state = {"in_flight": 0, "finished": 0}
    link_errors: dict[int, str] = {}

    def run_link(link: dict) -> None:
        n = int(link["n"])
        url, mode = link["url"], normalize_link_type(link.get("type"), link["url"])
        log = lambda msg: emit({"link": n, "log": str(msg)})
        download_dir = Path(download_root) / f"link_{n:02d}_downloads"
        emit({"link": n, "status": "Connecting…"})
        try:
            client = factory(url, mode, download_dir, log)
            names = voice_names(client.predict(api_name="/voices"))
            if voice not in names:
                raise RuntimeError(f"voice '{voice}' is not on this link (it has: {', '.join(names[:8]) or 'none'})")
        except Exception as exc:
            link_errors[n] = detail(exc)
            log(f"❌ FAILED to connect: {detail(exc)}")
            emit({"link": n, "status": "FAILED"})
            with cond:
                cond.notify_all()
            return
        log(f"READY [{mode}] voice={voice}")
        emit({"link": n, "status": "READY"})
        taken = 0
        while taken < per_link:
            with cond:
                while not pending and state["in_flight"] > 0:
                    cond.wait(1.0)       # a busy link may still fail and hand its block back
                if not pending:
                    break
                job = pending.popleft()
                state["in_flight"] += 1
            taken += 1
            bid, text, dest = job
            emit({"link": n, "status": f"Working {taken}"})
            last: BaseException | None = None
            for attempt in range(1, 4):
                try:
                    generate_to(client, text, voice, dest)
                    last = None
                    break
                except Exception as exc:
                    last = exc
                    log(f"⚠️ {bid} attempt {attempt}/3 failed: {detail(exc)}")
                    if attempt < 3:
                        time.sleep(retry_wait * attempt)
                        try:
                            client = factory(url, mode, download_dir, log)
                        except Exception as rexc:
                            last = rexc
            if last is not None:
                with cond:
                    pending.appendleft(job)
                    state["in_flight"] -= 1
                    cond.notify_all()
                link_errors[n] = f"{bid}: {detail(last)}"
                log(f"❌ FAILED at {bid} — handed back to the other links. {detail(last)}")
                emit({"link": n, "status": "FAILED"})
                return
            with cond:
                state["in_flight"] -= 1
                state["finished"] += 1
                count = state["finished"]
                cond.notify_all()
            log(f"✅ {bid} ({taken})")
            emit({"done": bid, "count": count, "total": len(jobs), "link": n})
        log(f"DONE — {taken} block(s)" + (f" (per-link budget {per_link} reached)" if taken >= per_link else ""))
        emit({"link": n, "status": f"DONE {taken}"})

    threads = [threading.Thread(target=run_link, args=(link,), daemon=True, name=f"voxcpm-link-{link['n']}")
               for link in links]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    if pending:
        failed = "; ".join(f"Link {n}: {err}" for n, err in sorted(link_errors.items())) or "no link left"
        need = required_links(len(pending), per_link)
        raise RuntimeError(
            f"VoxCPM: {len(pending)} block(s) still need audio (≈{need} more link(s) at {per_link}/link). "
            f"Replace the failed Colab link(s) and START again; finished blocks are kept. {failed}"
        )
