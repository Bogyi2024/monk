"""Output languages for Storytelling Recap Studio (UI, engine writer, TTS voices, subtitles).

The Gemini timeline is language-free (English), so one analysis serves every language; only
the storyteller text, its checks, the Edge TTS voice and the subtitle font depend on this table.
Burmese ("my") is the original pipeline and stays the default.

Why these languages: the biggest YouTube manhwa/drama-recap audiences are English, Spanish
(Latin America), Portuguese (Brazil), Indonesian, Vietnamese, Thai, Filipino, Hindi and Arabic;
the highest ad revenue per view (RPM) comes from English, German, French, Japanese and Korean
viewers. Burmese stays first.
"""
from __future__ import annotations

LATIN = [(0x00C0, 0x024F), (0x1E00, 0x1EFF)]          # accented Latin, Vietnamese letters
ROMANIZED = "keep the character names exactly as the registry romanizes them (for example Li Yi)"

LANGUAGES: dict[str, dict] = {
    "my": {
        "label": "Burmese", "native": "မြန်မာ", "tag": "",
        "voices": ["my-MM-ThihaNeural", "my-MM-NilarNeural"], "rate": 25,
        "fonts": ["Myanmar Text", "Pyidaungsu", "Noto Sans Myanmar", "Padauk"],
        "script": [(0x1000, 0x109F), (0xAA60, 0xAA7F), (0xA9E0, 0xA9FF)], "spaced": True, "char_w": 0.72,
        "sample": "ဒီအသံ၊ ဒီအမြန်နှုန်းနဲ့ ဇာတ်လမ်းကို ပြန်ပြောပြသွားမှာပါ။",
        "names": "write names in Burmese script",
    },
    "en": {
        "label": "English", "native": "English", "tag": "highest RPM · biggest manhwa audience",
        "voices": ["en-US-AndrewNeural", "en-US-BrianNeural", "en-US-ChristopherNeural", "en-US-GuyNeural",
                   "en-US-AvaNeural", "en-US-EmmaNeural", "en-US-JennyNeural", "en-GB-RyanNeural"], "rate": 10,
        "fonts": ["Arial", "Segoe UI", "Calibri", "Verdana", "Tahoma", "Trebuchet MS", "Impact"],
        "script": LATIN, "spaced": True, "char_w": 0.52,
        "sample": "With this voice and speed, I will tell you the whole story.",
        "names": ROMANIZED,
    },
    "es": {
        "label": "Spanish", "native": "Español", "tag": "big manhwa audience (Latin America)",
        "voices": ["es-MX-JorgeNeural", "es-MX-DaliaNeural", "es-ES-AlvaroNeural", "es-ES-ElviraNeural"], "rate": 10,
        "fonts": ["Arial", "Segoe UI", "Calibri", "Verdana", "Tahoma"], "script": LATIN, "spaced": True, "char_w": 0.52,
        "sample": "Con esta voz y esta velocidad, te contaré toda la historia.",
        "names": ROMANIZED,
    },
    "pt": {
        "label": "Portuguese", "native": "Português", "tag": "big manhwa audience (Brazil)",
        "voices": ["pt-BR-AntonioNeural", "pt-BR-FranciscaNeural", "pt-BR-ThalitaMultilingualNeural"], "rate": 10,
        "fonts": ["Arial", "Segoe UI", "Calibri", "Verdana", "Tahoma"], "script": LATIN, "spaced": True, "char_w": 0.52,
        "sample": "Com esta voz e esta velocidade, vou te contar toda a história.",
        "names": ROMANIZED,
    },
    "id": {
        "label": "Indonesian", "native": "Bahasa Indonesia", "tag": "big manhwa audience",
        "voices": ["id-ID-ArdiNeural", "id-ID-GadisNeural"], "rate": 10,
        "fonts": ["Arial", "Segoe UI", "Calibri", "Verdana", "Tahoma"], "script": LATIN, "spaced": True, "char_w": 0.52,
        "sample": "Dengan suara dan kecepatan ini, aku akan menceritakan seluruh kisahnya.",
        "names": ROMANIZED,
    },
    "vi": {
        "label": "Vietnamese", "native": "Tiếng Việt", "tag": "big manhwa audience",
        "voices": ["vi-VN-NamMinhNeural", "vi-VN-HoaiMyNeural"], "rate": 10,
        "fonts": ["Arial", "Segoe UI", "Calibri", "Tahoma"], "script": LATIN, "spaced": True, "char_w": 0.52,
        "sample": "Với giọng đọc và tốc độ này, tôi sẽ kể lại toàn bộ câu chuyện.",
        "names": "write names the way Vietnamese recap channels do (Sino-Vietnamese readings for Chinese names, e.g. Lý Dịch)",
    },
    "th": {
        "label": "Thai", "native": "ไทย", "tag": "big manhwa audience",
        "voices": ["th-TH-NiwatNeural", "th-TH-PremwadeeNeural"], "rate": 10,
        "fonts": ["Leelawadee UI", "Leelawadee", "Tahoma"],
        "script": [(0x0E00, 0x0E7F)], "spaced": False, "char_w": 0.55,
        "sample": "ด้วยเสียงและความเร็วนี้ ผมจะเล่าเรื่องทั้งหมดให้ฟัง",
        "names": "write names in Thai script (transliterate), the same way every time",
    },
    "fil": {
        "label": "Filipino", "native": "Filipino", "tag": "big manhwa audience",
        "voices": ["fil-PH-AngeloNeural", "fil-PH-BlessicaNeural"], "rate": 10,
        "fonts": ["Arial", "Segoe UI", "Calibri", "Verdana", "Tahoma"], "script": LATIN, "spaced": True, "char_w": 0.52,
        "sample": "Sa boses at bilis na ito, ikukuwento ko ang buong istorya.",
        "names": ROMANIZED,
    },
    "hi": {
        "label": "Hindi", "native": "हिन्दी", "tag": "huge audience, low RPM",
        "voices": ["hi-IN-MadhurNeural", "hi-IN-SwaraNeural"], "rate": 10,
        "fonts": ["Nirmala UI"], "script": [(0x0900, 0x097F), (0xA8E0, 0xA8FF)], "spaced": True, "char_w": 0.6,
        "sample": "इसी आवाज़ और रफ़्तार से मैं आपको पूरी कहानी सुनाऊँगा।",
        "names": "write names in Devanagari (transliterate), the same way every time",
    },
    "ar": {
        "label": "Arabic", "native": "العربية", "tag": "big audience, good Gulf RPM",
        "voices": ["ar-SA-HamedNeural", "ar-EG-ShakirNeural", "ar-SA-ZariyahNeural"], "rate": 5,
        "fonts": ["Segoe UI", "Arial", "Tahoma"],
        "script": [(0x0600, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF), (0xFB50, 0xFDFF), (0xFE70, 0xFEFF)],
        "spaced": True, "char_w": 0.5, "rtl": True,
        "sample": "بهذا الصوت وهذه السرعة سأروي لكم القصة كاملة.",
        "names": "write names in Arabic script (transliterate), the same way every time",
    },
    "de": {
        "label": "German", "native": "Deutsch", "tag": "high RPM",
        "voices": ["de-DE-ConradNeural", "de-DE-KillianNeural", "de-DE-FlorianMultilingualNeural", "de-DE-KatjaNeural"],
        "rate": 10, "fonts": ["Arial", "Segoe UI", "Calibri", "Verdana", "Tahoma"], "script": LATIN, "spaced": True,
        "char_w": 0.54, "sample": "Mit dieser Stimme und diesem Tempo erzähle ich dir die ganze Geschichte.",
        "names": ROMANIZED,
    },
    "fr": {
        "label": "French", "native": "Français", "tag": "high RPM",
        "voices": ["fr-FR-HenriNeural", "fr-FR-RemyMultilingualNeural", "fr-FR-DeniseNeural"], "rate": 10,
        "fonts": ["Arial", "Segoe UI", "Calibri", "Verdana", "Tahoma"], "script": LATIN, "spaced": True, "char_w": 0.52,
        "sample": "Avec cette voix et ce rythme, je vais te raconter toute l'histoire.",
        "names": ROMANIZED,
    },
    "ja": {
        "label": "Japanese", "native": "日本語", "tag": "high RPM",
        "voices": ["ja-JP-KeitaNeural", "ja-JP-NanamiNeural"], "rate": 10,
        "fonts": ["Yu Gothic", "MS Gothic"],
        "script": [(0x3040, 0x30FF), (0x31F0, 0x31FF), (0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0x3000, 0x303F), (0xFF00, 0xFFEF)],
        "spaced": False, "char_w": 1.0,
        "sample": "この声とスピードで、物語をすべてお話しします。",
        "names": "write names in katakana or the usual Japanese kanji reading, the same way every time",
    },
    "ko": {
        "label": "Korean", "native": "한국어", "tag": "manhwa home market, high RPM",
        "voices": ["ko-KR-InJoonNeural", "ko-KR-HyunsuMultilingualNeural", "ko-KR-SunHiNeural"], "rate": 10,
        "fonts": ["Malgun Gothic"], "script": [(0xAC00, 0xD7AF), (0x1100, 0x11FF), (0x3130, 0x318F), (0x3000, 0x303F)],
        "spaced": True, "char_w": 0.95,
        "sample": "이 목소리와 속도로 이야기 전체를 들려드릴게요.",
        "names": "write names in Hangul (Korean readings for Chinese names, e.g. 이역), the same way every time",
    },
    "tr": {
        "label": "Turkish", "native": "Türkçe", "tag": "growing manhwa audience",
        "voices": ["tr-TR-AhmetNeural", "tr-TR-EmelNeural"], "rate": 10,
        "fonts": ["Arial", "Segoe UI", "Calibri", "Verdana", "Tahoma"], "script": LATIN, "spaced": True, "char_w": 0.52,
        "sample": "Bu ses ve bu hızla sana bütün hikâyeyi anlatacağım.",
        "names": ROMANIZED,
    },
}

DEFAULT = "my"
# Temporary Desktop product switch. Keep every language implementation above so
# multilingual output can be restored by enabling this one flag.
MULTILINGUAL_OUTPUT_ENABLED = False
SENTENCE_MARKS = "။.!?。！？؟।"


def enabled_codes() -> tuple[str, ...]:
    return tuple(LANGUAGES) if MULTILINGUAL_OUTPUT_ENABLED else (DEFAULT,)


def output_code(code: str | None) -> str:
    code = str(code or DEFAULT).strip().lower()
    return code if code in enabled_codes() else DEFAULT


def restrict_output(settings: dict) -> dict:
    """Migrate saved foreign-language jobs/voices while the Desktop switch is off."""
    settings = dict(settings)
    settings["language"] = output_code(settings.get("language"))
    if not MULTILINGUAL_OUTPUT_ENABLED:
        lang = LANGUAGES[DEFAULT]
        if settings.get("tts_voice") not in lang["voices"]:
            settings["tts_voice"] = lang["voices"][0]
            settings["tts_rate_percent"] = lang["rate"]
    return settings


def get(code: str | None) -> dict:
    return LANGUAGES.get(str(code or DEFAULT), LANGUAGES[DEFAULT])


def code_of(label: str) -> str:
    """UI label ('English — highest RPM ...') -> code."""
    for code, lang in LANGUAGES.items():
        if label == display(code):
            return code
    return DEFAULT


def display(code: str) -> str:
    lang = get(code)
    name = lang["label"] if lang["native"] == lang["label"] else f"{lang['label']} ({lang['native']})"
    return f"{name} — {lang['tag']}" if lang["tag"] else name


def suffix(code: str) -> str:
    """Folder / FINALS suffix: '' for Burmese (the original layout), '_EN' etc. otherwise."""
    return "" if str(code or DEFAULT) == DEFAULT else f"_{code.upper()}"


def in_script(ch: str, code: str) -> bool:
    cp = ord(ch)
    return any(lo <= cp <= hi for lo, hi in get(code)["script"])
