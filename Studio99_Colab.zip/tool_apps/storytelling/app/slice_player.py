"""Script Review picture (2026-10-24, user: "show the part's picture so I can watch it and fix the line"):
plays one block's own beat slice of the source video inside the Script window. FFmpeg decodes the slice to
small RGB frames in a thread (Tk is only touched from the window's own after() loop); ffplay plays its sound
without a window. Nothing here writes to the work folder."""
from __future__ import annotations

import queue
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
import tkinter as tk
from tkinter import ttk

from PIL import Image, ImageTk

NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0     # CREATE_NO_WINDOW: no console for ffmpeg / ffplay
PLAY_FPS = 15
STILL_AT = 0.2               # the still shown on select: this far into the slice (half of a shorter one)


def frame_cmd(ffmpeg: str, video: Path, start: float, end: float, width: int, height: int,
              fps: int = PLAY_FPS, frames: int | None = None) -> list[str]:
    """Raw RGB frames of video[start:end], fitted into width x height with black bars."""
    fit = (f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
           f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=black,fps={fps}")
    cmd = [ffmpeg, "-v", "error", "-nostdin", "-ss", f"{max(0.0, start):.3f}", "-t", f"{max(0.05, end - start):.3f}",
           "-i", str(video), "-an", "-vf", fit]
    if frames:
        cmd += ["-frames:v", str(frames)]
    return cmd + ["-pix_fmt", "rgb24", "-f", "rawvideo", "-"]


def sound_cmd(ffplay: str, video: Path, start: float, end: float) -> list[str]:
    return [ffplay, "-v", "error", "-nodisp", "-autoexit", "-ss", f"{max(0.0, start):.3f}",
            "-t", f"{max(0.05, end - start):.3f}", str(video)]


def find_ffplay(ffmpeg: str) -> str | None:
    """ffplay beside the ffmpeg the Studio uses, else on PATH."""
    beside = Path(ffmpeg).with_name("ffplay.exe" if sys.platform == "win32" else "ffplay")
    return str(beside) if beside.is_file() else shutil.which("ffplay")


class SlicePlayer(ttk.Frame):
    def __init__(self, master, ffmpeg: str = "ffmpeg", width: int = 512, height: int = 288):
        super().__init__(master)
        self.ffmpeg, self.ffplay = ffmpeg, find_ffplay(ffmpeg)
        self.w, self.h = width, height
        self.video: Path | None = None
        self.start = self.end = 0.0
        self.gen = 0                       # every load / play / stop starts a new generation; old threads stop
        self.procs: list[subprocess.Popen] = []
        self.frames: queue.Queue = queue.Queue(maxsize=90)
        self.photo = None
        self.screen = tk.Label(self, bg="black", width=width, height=height, bd=0)
        self.screen.pack()
        self.blank()
        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=(4, 0))
        self.play_btn = ttk.Button(bar, text="▶ Play", command=self.toggle, width=9)
        self.play_btn.pack(side="left")
        self.sound = tk.BooleanVar(value=bool(self.ffplay))
        ttk.Checkbutton(bar, text="🔊 Sound" if self.ffplay else "🔇 (ffplay not found)", variable=self.sound,
                        state="normal" if self.ffplay else "disabled").pack(side="left", padx=8)
        self.auto = tk.BooleanVar(value=True)
        ttk.Checkbutton(bar, text="Play when a line is picked", variable=self.auto).pack(side="left")
        self.clock = tk.StringVar()
        ttk.Label(bar, textvariable=self.clock).pack(side="right")
        self.bind("<Destroy>", lambda e: self.stop() if e.widget is self else None)

    # ---------------------------------------------------------------- frames in
    def _reader(self, gen: int, cmd: list[str], out: queue.Queue) -> None:
        size = self.w * self.h * 3
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)
        except OSError:
            out.put(None)
            return
        self.procs.append(proc)
        try:
            while gen == self.gen:
                data = proc.stdout.read(size)
                if len(data) < size:
                    break
                while gen == self.gen:
                    try:
                        out.put(Image.frombytes("RGB", (self.w, self.h), data), timeout=0.2)
                        break
                    except queue.Full:
                        continue
        finally:
            if gen == self.gen:
                out.put(None)               # end of the slice
            proc.kill()
            proc.stdout.close()
            proc.wait()

    def _show(self, img: Image.Image) -> None:
        self.photo = ImageTk.PhotoImage(img)
        self.screen.configure(image=self.photo)

    def blank(self) -> None:
        self._show(Image.new("RGB", (self.w, self.h), "black"))

    # ---------------------------------------------------------------- controls
    def load(self, video: Path | None, start: float, end: float) -> None:
        """A new line was picked: its still, then play it when 'Play when a line is picked' is on."""
        self.stop()
        self.video, self.start, self.end = (Path(video) if video else None), float(start), float(end)
        if not self.video or not self.video.is_file():
            self.blank()
            self.clock.set("source video not found")
            return
        self.clock.set(f"0.0 / {self.end - self.start:.1f} s")
        if self.auto.get():
            self.play()
            return
        gen, out = self.gen, queue.Queue()
        at = self.start + min(STILL_AT, (self.end - self.start) / 2)
        cmd = frame_cmd(self.ffmpeg, self.video, at, self.end, self.w, self.h, frames=1)
        threading.Thread(target=self._reader, args=(gen, cmd, out), daemon=True).start()
        self._wait_still(gen, out)

    def _wait_still(self, gen: int, out: queue.Queue) -> None:
        if gen != self.gen:
            return
        try:
            img = out.get_nowait()
        except queue.Empty:
            self.after(40, self._wait_still, gen, out)
            return
        if img is not None:
            self._show(img)

    def toggle(self) -> None:
        if self.play_btn.cget("text").startswith("■"):
            self.stop()
        else:
            self.play()

    def play(self) -> None:
        if not self.video or not self.video.is_file():
            return
        self.stop()
        gen = self.gen
        self.frames = queue.Queue(maxsize=90)
        cmd = frame_cmd(self.ffmpeg, self.video, self.start, self.end, self.w, self.h)
        threading.Thread(target=self._reader, args=(gen, cmd, self.frames), daemon=True).start()
        self.play_btn.configure(text="■ Stop")
        self._tick(gen, None, 0)

    def _tick(self, gen: int, t0: float | None, shown: int) -> None:
        if gen != self.gen:
            return
        if t0 is None:                      # wait for the first frame, then start the clock and the sound together
            try:
                img = self.frames.get_nowait()
            except queue.Empty:
                self.after(15, self._tick, gen, None, 0)
                return
            if img is None:
                self.stop()
                return
            self._show(img)
            if self.sound.get() and self.ffplay:
                try:
                    self.procs.append(subprocess.Popen(sound_cmd(self.ffplay, self.video, self.start, self.end),
                                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                                       creationflags=NO_WINDOW))
                except OSError:
                    pass
            self.after(15, self._tick, gen, time.monotonic(), 1)
            return
        due = int((time.monotonic() - t0) * PLAY_FPS) + 1
        img, ended = None, False
        while shown < due:
            try:
                nxt = self.frames.get_nowait()
            except queue.Empty:
                break
            if nxt is None:
                ended = True
                break
            img, shown = nxt, shown + 1
        if img is not None:
            self._show(img)
        self.clock.set(f"{min(shown / PLAY_FPS, self.end - self.start):.1f} / {self.end - self.start:.1f} s")
        if ended:
            self.gen += 1
            self.play_btn.configure(text="▶ Play")
            return
        self.after(15, self._tick, gen, t0, shown)

    def stop(self) -> None:
        self.gen += 1
        for proc in self.procs:
            try:
                proc.kill()
            except OSError:
                pass
        self.procs = []
        try:
            self.play_btn.configure(text="▶ Play")
        except tk.TclError:
            pass
