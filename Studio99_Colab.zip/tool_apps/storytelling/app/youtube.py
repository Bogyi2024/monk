"""Links in the Studio queue: look a video (or a playlist) up, then download it with yt-dlp.

Direct networking first (Gemini's proxy is not needed for YouTube here). On YouTube's anti-bot
challenge the signed-in Firefox profile's cookies are used, as movie_review does; a dropped
connection is retried through the Studio's proxy.
"""
from __future__ import annotations

from pathlib import Path

ANTIBOT_MARKERS = ("confirm you’re not a bot", "confirm you're not a bot", "sign in to confirm",
                   "--cookies-from-browser")
TRANSPORT_MARKERS = ("unable to connect to proxy", "proxyerror", "remote disconnected", "remotedisconnected",
                     "connection reset", "connection aborted", "connection refused", "timed out", "timeout",
                     "getaddrinfo failed", "network is unreachable")
FORMAT = "bv*[height<=1080]+ba/b[height<=1080]/bv*+ba/b"     # sound is needed: Gemini and Whisper listen


def is_link(text: str) -> bool:
    t = str(text or "").strip().lower()
    return t.startswith(("http://", "https://")) and " " not in t


def _extract(url: str, opts: dict, download: bool, proxy: str = "", log=None) -> tuple[dict, object]:
    """yt-dlp extract_info, direct; Firefox cookies on anti-bot; the proxy on a dropped connection."""
    try:
        from yt_dlp import YoutubeDL
    except ImportError:
        raise RuntimeError("yt-dlp is not installed: python -m pip install -U yt-dlp yt-dlp-ejs") from None
    base = {"quiet": True, "no_warnings": True, "noprogress": True, "noplaylist": True, "proxy": "",
            "socket_timeout": 35, "retries": 4, "fragment_retries": 4, "extractor_retries": 3}
    attempts, errors = [{}], []
    while attempts:
        extra = attempts.pop(0)
        try:
            with YoutubeDL({**base, **opts, **extra}) as ydl:
                return ydl.extract_info(url, download=download), ydl
        except Exception as exc:
            errors.append(exc)
            message = str(exc).casefold()
            if "cancel" in type(exc).__name__.casefold():
                raise
            if any(m in message for m in ANTIBOT_MARKERS) and "cookiesfrombrowser" not in extra:
                if log:
                    log("YouTube asks to sign in: retrying with Firefox cookies")
                attempts.append({**extra, "cookiesfrombrowser": ("firefox",)})
            elif any(m in message for m in TRANSPORT_MARKERS) and proxy and extra.get("proxy") != proxy:
                if log:
                    log("connection dropped: retrying through the proxy")
                attempts.append({**extra, "proxy": proxy})
    raise RuntimeError(f"cannot open {url}: {str(errors[-1]).splitlines()[0][:300]}")


def lookup(url: str, proxy: str = "", log=None) -> list[dict]:
    """[{"url", "id", "title", "duration"}]: one entry for a video, every video of a playlist."""
    info, _ = _extract(url, {"skip_download": True, "extract_flat": "in_playlist"}, False, proxy, log)
    entries = info.get("entries") if info.get("_type") == "playlist" else [info]
    out = []
    for e in entries or []:
        if not e:
            continue
        link = e.get("webpage_url") or e.get("url") or url
        if e.get("_type") == "url" and e.get("id") and "youtube" in str(e.get("ie_key") or "").lower():
            link = f"https://www.youtube.com/watch?v={e['id']}"
        out.append({"url": link, "id": str(e.get("id") or ""), "title": str(e.get("title") or e.get("id") or "video"),
                    "duration": float(e.get("duration") or 0) or None})
    return out


def download(url: str, folder: Path, stem: str, ffmpeg: str = "", proxy: str = "", progress=None,
             cancelled=None, log=None) -> Path:
    """Download to folder/<stem>.mp4 (video up to 1080p + sound) and return the file."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    done = folder / f"{stem}.mp4"
    if done.is_file() and done.stat().st_size > 1_000_000:
        return done

    def hook(d: dict) -> None:
        if cancelled and cancelled():
            from yt_dlp.utils import DownloadCancelled
            raise DownloadCancelled("stopped")
        if progress and d.get("status") == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            progress(min(1.0, float(d.get("downloaded_bytes") or 0) / total) if total else 0.0)

    opts = {"outtmpl": str(folder / f"{stem}.%(ext)s"), "format": FORMAT, "merge_output_format": "mp4",
            "progress_hooks": [hook]}
    if ffmpeg:
        opts["ffmpeg_location"] = str(Path(ffmpeg).parent if Path(ffmpeg).is_file() else ffmpeg)
    info, ydl = _extract(url, opts, True, proxy, log)
    found = [Path(d["filepath"]) for d in info.get("requested_downloads") or [] if d.get("filepath")]
    found += [done, Path(ydl.prepare_filename(info)).with_suffix(".mp4")]
    for f in found:
        if f.is_file():
            if f != done:
                f.replace(done)
            return done
    raise RuntimeError(f"yt-dlp finished but {done.name} is missing")
