"""Post-production effects for Storytelling Recap Studio: preview + final render.

Geometry rules (all coordinates are 0..1 fractions of a frame):
- Blur boxes live in SOURCE space. They hide the source's own watermark or subtitles,
  so they stay on that content when Flip / Zoom / Output ratio change.
- Title, logo, extra text and subtitles live in OUTPUT space: the final canvas after
  Flip + Zoom + Output ratio (Original = the source frame, 9:16 = 1080x1920).

The effects pass runs once on the engine's finished video: picture filters only, the
audio stream is copied, so the Smart Sync timing is untouched.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Callable

LogFn = Callable[[str], None]

DEFAULT_EDITOR: dict = {
    "mirror": False,
    "zoom": 1.0,
    "blur_boxes": [],            # [{"x", "y", "w", "h"}] in source space
    "blur_strength": 18,
    "title_text": "",
    "title_size": 54,
    "title_pos": [0.50, 0.12],   # center, output space
    "logo_enabled": False,
    "logo_path": "",
    "logo_width_frac": 0.18,
    "logo_opacity": 0.65,
    "logo_pos": [0.78, 0.04],    # top-left corner, output space
    "extra_text": "",
    "extra_size": 42,
    "extra_opacity": 0.85,
    "extra_pos": [0.50, 0.86],   # center, output space
    "subs_enabled": True,        # burned-in Myanmar narration subtitles
    "subs_font": "Myanmar Text",
    "subs_size": 76,
    "subs_style": "box",         # box | outline
    "subs_pos_y": 0.76,          # centre of the subtitle, output space
    "original_sound_percent": 0,
    "original_sound_source": "original",
    "volume": 1.0,               # narration volume (1.0 = unchanged, audio copied)
    "ratio": "Original",         # Original | 9:16
    "fill": "blur",              # 9:16 only: blur (blurred copy behind) | black | crop
    "frame_pos": [0.5, 0.5],     # 9:16 only: where the picture sits in its free room / crop window
}

ZOOM_MAX = 1.35
MIN_BOX = 0.012
OUTPUT_RATIOS = ("Original", "9:16")
FILL_MODES = ("blur", "black", "crop")
CANVAS_9_16 = (1080, 1920)
BG_BLUR_DIV = 4                  # blurred background is built at 1/4 size (fast) and scaled up


def _clamp(value, lo: float, hi: float, default: float) -> float:
    try:
        v = float(value)
    except Exception:
        return default
    if v != v:  # NaN
        return default
    return max(lo, min(hi, v))


def _pos(value, default: list[float]) -> list[float]:
    try:
        return [_clamp(value[0], 0.0, 1.0, default[0]), _clamp(value[1], 0.0, 1.0, default[1])]
    except Exception:
        return list(default)


def normalized_editor(raw: dict | None) -> dict:
    """Defaults + clamped values, so a hand-edited config.json cannot break a render."""
    raw = dict(raw or {})
    ed = dict(DEFAULT_EDITOR)
    ed.update({k: v for k, v in raw.items() if k in DEFAULT_EDITOR})
    ed["mirror"] = bool(ed["mirror"])
    ed["zoom"] = _clamp(ed["zoom"], 1.0, ZOOM_MAX, 1.0)
    boxes = []
    for b in raw.get("blur_boxes") or []:
        if not isinstance(b, dict):
            continue
        x = _clamp(b.get("x"), 0.0, 1.0 - MIN_BOX, 0.0)
        y = _clamp(b.get("y"), 0.0, 1.0 - MIN_BOX, 0.0)
        w = _clamp(b.get("w"), MIN_BOX, 1.0 - x, 0.1)
        h = _clamp(b.get("h"), MIN_BOX, 1.0 - y, 0.1)
        boxes.append({"x": x, "y": y, "w": w, "h": h})
    ed["blur_boxes"] = boxes
    ed["blur_strength"] = int(_clamp(ed["blur_strength"], 2, 40, 18))
    ed["title_text"] = str(ed["title_text"] or "").strip()
    ed["title_size"] = int(_clamp(ed["title_size"], 18, 140, 54))
    ed["title_pos"] = _pos(ed["title_pos"], DEFAULT_EDITOR["title_pos"])
    ed["logo_enabled"] = bool(ed["logo_enabled"])
    ed["logo_path"] = str(ed["logo_path"] or "").strip()
    ed["logo_width_frac"] = _clamp(ed["logo_width_frac"], 0.04, 0.60, 0.18)
    ed["logo_opacity"] = _clamp(ed["logo_opacity"], 0.05, 1.0, 0.65)
    ed["logo_pos"] = _pos(ed["logo_pos"], DEFAULT_EDITOR["logo_pos"])
    ed["extra_text"] = str(ed["extra_text"] or "").strip()
    ed["extra_size"] = int(_clamp(ed["extra_size"], 14, 120, 42))
    ed["extra_opacity"] = _clamp(ed["extra_opacity"], 0.05, 1.0, 0.85)
    ed["extra_pos"] = _pos(ed["extra_pos"], DEFAULT_EDITOR["extra_pos"])
    ed["subs_enabled"] = bool(ed["subs_enabled"])
    ed["subs_font"] = str(ed["subs_font"] or "Myanmar Text").strip() or "Myanmar Text"
    ed["subs_size"] = int(_clamp(ed["subs_size"], 24, 160, 76))
    ed["subs_style"] = ed["subs_style"] if ed["subs_style"] in ("box", "outline") else "box"
    ed["subs_pos_y"] = _clamp(ed["subs_pos_y"], 0.05, 0.95, 0.76)
    ed["original_sound_percent"] = int(_clamp(ed["original_sound_percent"], 0, 100, 0))
    ed["original_sound_source"] = "background" if ed["original_sound_source"] == "background" else "original"
    ed["volume"] = _clamp(ed["volume"], 0.3, 3.0, 1.0)
    ed["ratio"] = ed["ratio"] if ed["ratio"] in OUTPUT_RATIOS else "Original"
    ed["fill"] = ed["fill"] if ed["fill"] in FILL_MODES else "blur"
    ed["frame_pos"] = _pos(ed["frame_pos"], DEFAULT_EDITOR["frame_pos"])
    return ed


def subtitle_style(ed: dict, video_width: int, video_height: int | None = None) -> dict:
    """subs_size is set for a 1080p frame (short side 1080): vertical 1080x1920 and landscape
    1280x720 get the same look relative to the picture."""
    short_side = min(video_width, video_height or video_width)
    size = max(12, int(round(ed["subs_size"] * short_side / 1080.0)))
    return {"font": ed["subs_font"], "size": size, "style": ed["subs_style"], "pos_y": ed["subs_pos_y"]}


def volume_changed(ed: dict) -> bool:
    return abs(ed["volume"] - 1.0) > 0.005


def logo_active(ed: dict) -> bool:
    return bool(ed.get("logo_enabled")) and bool(ed.get("logo_path")) and Path(ed["logo_path"]).is_file()


def has_picture_effects(ed: dict) -> bool:
    return bool(
        ed["mirror"] or ed["zoom"] > 1.0005 or ed["blur_boxes"]
        or ed["title_text"] or ed["extra_text"] or logo_active(ed)
        or ed["ratio"] != "Original"
    )


def has_effects(ed: dict) -> bool:
    """Anything to render besides burned subtitles (those come as an ASS file)."""
    return has_picture_effects(ed) or volume_changed(ed) or bool(ed["original_sound_percent"])


# ---------------------------------------------------------------- geometry ----------

def source_to_output_rect(rect: dict, mirror: bool, zoom: float) -> dict:
    """Map a source-space box to output space (Flip first, then centered Zoom)."""
    x1, x2 = rect["x"], rect["x"] + rect["w"]
    if mirror:
        x1, x2 = 1.0 - x2, 1.0 - x1
    y1, y2 = rect["y"], rect["y"] + rect["h"]
    z = max(1.0, float(zoom))
    ox1, ox2 = 0.5 + (x1 - 0.5) * z, 0.5 + (x2 - 0.5) * z
    oy1, oy2 = 0.5 + (y1 - 0.5) * z, 0.5 + (y2 - 0.5) * z
    return {"x": ox1, "y": oy1, "w": ox2 - ox1, "h": oy2 - oy1}


def output_to_source_rect(rect: dict, mirror: bool, zoom: float) -> dict:
    """Inverse of source_to_output_rect."""
    z = max(1.0, float(zoom))
    x1 = 0.5 + (rect["x"] - 0.5) / z
    x2 = 0.5 + (rect["x"] + rect["w"] - 0.5) / z
    y1 = 0.5 + (rect["y"] - 0.5) / z
    y2 = 0.5 + (rect["y"] + rect["h"] - 0.5) / z
    if mirror:
        x1, x2 = 1.0 - x2, 1.0 - x1
    return {"x": x1, "y": y1, "w": x2 - x1, "h": y2 - y1}


def _even(value: float) -> int:
    return int(round(value / 2.0)) * 2


def output_size(ed: dict, width: int, height: int) -> tuple[int, int]:
    """Final canvas size: the source frame (Original) or 1080x1920 (9:16)."""
    return CANVAS_9_16 if ed.get("ratio") == "9:16" else (int(width), int(height))


def picture_placement(ed: dict, width: int, height: int) -> dict:
    """Where the flipped/zoomed picture lands on the canvas, in canvas pixels.

    fit (blur / black): the whole picture is visible, scaled to fit, with free room around it.
    crop: the picture covers the canvas and the overflow is cut off.
    frame_pos picks the spot inside the free room (fit) or the crop window (crop):
    ox = (canvas_w - picture_w) * pos_x, the same formula for both.
    """
    cw, ch = output_size(ed, width, height)
    if ed.get("ratio") != "9:16":
        return {"cw": cw, "ch": ch, "sw": cw, "sh": ch, "ox": 0, "oy": 0}
    w, h = max(2, int(width)), max(2, int(height))
    if ed.get("fill") == "crop":
        scale = max(cw / w, ch / h)
        sw, sh = max(cw, _even(w * scale)), max(ch, _even(h * scale))
    else:
        scale = min(cw / w, ch / h)
        sw, sh = min(cw, max(2, _even(w * scale))), min(ch, max(2, _even(h * scale)))
    px, py = _pos(ed.get("frame_pos"), DEFAULT_EDITOR["frame_pos"])
    return {"cw": cw, "ch": ch, "sw": sw, "sh": sh, "ox": _even((cw - sw) * px), "oy": _even((ch - sh) * py)}


def picture_to_canvas_rect(rect: dict, pl: dict) -> dict:
    return {"x": (pl["ox"] + rect["x"] * pl["sw"]) / pl["cw"], "y": (pl["oy"] + rect["y"] * pl["sh"]) / pl["ch"],
            "w": rect["w"] * pl["sw"] / pl["cw"], "h": rect["h"] * pl["sh"] / pl["ch"]}


def canvas_to_picture_rect(rect: dict, pl: dict) -> dict:
    return {"x": (rect["x"] * pl["cw"] - pl["ox"]) / pl["sw"], "y": (rect["y"] * pl["ch"] - pl["oy"]) / pl["sh"],
            "w": rect["w"] * pl["cw"] / pl["sw"], "h": rect["h"] * pl["ch"] / pl["sh"]}


def source_to_canvas_rect(rect: dict, ed: dict, width: int, height: int) -> dict:
    """Source-space box -> final canvas (Flip, Zoom, then the Output ratio placement)."""
    return picture_to_canvas_rect(source_to_output_rect(rect, ed["mirror"], ed["zoom"]),
                                  picture_placement(ed, width, height))


def canvas_to_source_rect(rect: dict, ed: dict, width: int, height: int) -> dict:
    return output_to_source_rect(canvas_to_picture_rect(rect, picture_placement(ed, width, height)),
                                 ed["mirror"], ed["zoom"])


def clamp_box(rect: dict) -> dict | None:
    x1 = max(0.0, min(1.0, rect["x"]))
    y1 = max(0.0, min(1.0, rect["y"]))
    x2 = max(0.0, min(1.0, rect["x"] + rect["w"]))
    y2 = max(0.0, min(1.0, rect["y"] + rect["h"]))
    if x2 - x1 < MIN_BOX or y2 - y1 < MIN_BOX:
        return None
    return {"x": x1, "y": y1, "w": x2 - x1, "h": y2 - y1}


def blur_radii(w_px: int, h_px: int, strength: int) -> tuple[int, int]:
    """boxblur radius must fit the box: luma <= min/2, yuv420p chroma planes are half size."""
    short = max(2, min(int(w_px), int(h_px)))
    luma = max(1, min(int(strength), short // 2 - 1))
    chroma = max(1, min(luma, short // 4 - 1, 9))
    return luma, chroma


def box_pixels(box: dict, width: int, height: int) -> tuple[int, int, int, int]:
    x = int(round(box["x"] * width)) // 2 * 2
    y = int(round(box["y"] * height)) // 2 * 2
    w = max(8, int(round(box["w"] * width)) // 2 * 2)
    h = max(8, int(round(box["h"] * height)) // 2 * 2)
    w = min(w, width - x)
    h = min(h, height - y)
    return x, y, w, h


# ---------------------------------------------------------------- probing -----------

def probe_video(ffprobe: str, path: str | Path) -> dict:
    p = subprocess.run(
        [ffprobe, "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height,duration:format=duration",
         "-of", "default=noprint_wrappers=1", str(path)],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if p.returncode != 0:
        raise RuntimeError((p.stderr or "ffprobe failed")[-800:])
    info: dict = {}
    for line in p.stdout.splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        try:
            val = float(value)
        except ValueError:
            continue
        if key in ("width", "height"):
            info[key] = int(val)
        elif key == "duration" and val > 0:
            info["duration"] = max(info.get("duration", 0.0), val)
    if "width" not in info or "height" not in info:
        raise RuntimeError(f"No video stream: {path}")
    info.setdefault("duration", 0.0)
    return info


def extract_frame(ffmpeg: str, source: str | Path, timestamp: float, output: Path, width: int, height: int) -> Path:
    """Raw source frame (no effects) at preview size; effects are composed in the UI."""
    output.parent.mkdir(parents=True, exist_ok=True)
    p = subprocess.run(
        [ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
         "-ss", f"{max(0.0, float(timestamp)):.3f}", "-i", str(source),
         "-frames:v", "1", "-vf", f"scale={int(width)}:{int(height)}", str(output)],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if p.returncode != 0 or not output.is_file():
        raise RuntimeError((p.stderr or "preview frame failed")[-1200:])
    return output


# ---------------------------------------------------------------- text PNGs ---------

def title_png_config(size: int, video_width: int) -> dict:
    size = int(size)
    return {
        "font_size": size,
        "min_title_font_size": max(16, int(round(size * 0.62))),
        "panel_width": max(320, int(round(video_width * 0.92))),
        "video_title_panel_height": max(90, int(round(size * 2 * 1.30 + 44))),
        "max_title_lines": 2,
        "panel_bg_alpha": 0.57,
        "panel_radius": 26,
        "title_horizontal_padding": 38,
        "title_vertical_padding": 16,
        "stroke_px": 1.6,
        "font_weight": 700,
    }


def extra_png_config(size: int, video_width: int) -> dict:
    size = int(size)
    return {
        "font_size": size,
        "min_title_font_size": max(14, int(round(size * 0.62))),
        "panel_width": max(280, int(round(video_width * 0.84))),
        "video_title_panel_height": max(90, min(420, int(round(size * 4.2)))),
        "max_title_lines": 3,
        "panel_bg_alpha": 0.18,
        "panel_radius": 22,
        "title_horizontal_padding": 34,
        "title_vertical_padding": 14,
        "stroke_px": 1.4,
        "font_weight": 700,
    }


def render_text_png(text: str, output: Path, cfg: dict) -> Path:
    """Myanmar-safe text PNG through the Chromium renderer (same path as the Recap tools)."""
    from text_overlay_service import make_video_title_png
    output.parent.mkdir(parents=True, exist_ok=True)
    return make_video_title_png(str(text), output, cfg)


# ---------------------------------------------------------------- final render ------

def reframe_filters(ed: dict, width: int, height: int, cur: str) -> tuple[list[str], str]:
    """Picture (source size) -> 9:16 canvas: fit on a blurred copy / black bars, or crop to fill."""
    pl = picture_placement(ed, width, height)
    cw, ch, sw, sh, ox, oy = pl["cw"], pl["ch"], pl["sw"], pl["sh"], pl["ox"], pl["oy"]
    if ed["fill"] == "crop":
        return [f"{cur}scale={sw}:{sh},crop={cw}:{ch}:{-ox}:{-oy},setsar=1[rv]"], "[rv]"
    if ed["fill"] == "black":
        return [f"{cur}scale={sw}:{sh},pad={cw}:{ch}:{ox}:{oy}:color=black,setsar=1[rv]"], "[rv]"
    bw, bh = _even(cw / BG_BLUR_DIV), _even(ch / BG_BLUR_DIV)
    luma, chroma = blur_radii(bw, bh, 14)
    return [
        f"{cur}split=2[rfg0][rbg0]",
        f"[rbg0]scale={bw}:{bh}:force_original_aspect_ratio=increase,crop={bw}:{bh},"
        f"boxblur=luma_radius={luma}:luma_power=2:chroma_radius={chroma}:chroma_power=1,"
        f"scale={cw}:{ch},eq=brightness=-0.06:saturation=0.85,setsar=1[rbg]",
        f"[rfg0]scale={sw}:{sh},setsar=1[rfg]",
        f"[rbg][rfg]overlay={ox}:{oy}[rv]",
    ], "[rv]"


def build_filter_graph(ed: dict, width: int, height: int,
                       title_idx: int | None = None, logo_idx: int | None = None,
                       extra_idx: int | None = None, ass_name: str | None = None) -> str:
    """Blur (source space) -> Flip -> Zoom -> Output ratio -> title / logo / extra text -> subtitles (canvas)."""
    graph: list[str] = []
    cur = "[0:v]"
    for i, box in enumerate(ed["blur_boxes"]):
        x, y, w, h = box_pixels(box, width, height)
        if w < 8 or h < 8:
            continue
        luma, chroma = blur_radii(w, h, ed["blur_strength"])
        graph.append(f"{cur}split=2[bb{i}][bc{i}]")
        graph.append(
            f"[bc{i}]crop={w}:{h}:{x}:{y},"
            f"boxblur=luma_radius={luma}:luma_power=2:chroma_radius={chroma}:chroma_power=1[bl{i}]"
        )
        graph.append(f"[bb{i}][bl{i}]overlay={x}:{y}[bv{i}]")
        cur = f"[bv{i}]"

    picture: list[str] = []
    if ed["mirror"]:
        picture.append("hflip")
    if ed["zoom"] > 1.0005:
        cw = int(round(width / ed["zoom"] / 2.0)) * 2
        ch = int(round(height / ed["zoom"] / 2.0)) * 2
        picture.append(f"crop={cw}:{ch}:{(width - cw) // 2}:{(height - ch) // 2},scale={width}:{height}")
    picture.append("setsar=1")
    graph.append(f"{cur}{','.join(picture)}[pv]")
    cur = "[pv]"
    if ed["ratio"] != "Original":
        chain, cur = reframe_filters(ed, width, height, cur)
        graph += chain
    canvas_w, _canvas_h = output_size(ed, width, height)

    if title_idx is not None:
        tx, ty = ed["title_pos"]
        graph.append(f"{cur}[{title_idx}:v]overlay=x='W*{tx:.6f}-w/2':y='H*{ty:.6f}-h/2':eof_action=repeat[tv]")
        cur = "[tv]"
    if logo_idx is not None:
        lx, ly = ed["logo_pos"]
        lw = max(16, int(round(canvas_w * ed["logo_width_frac"] / 2.0)) * 2)
        graph.append(f"[{logo_idx}:v]scale={lw}:-2,format=rgba,colorchannelmixer=aa={ed['logo_opacity']:.3f}[lg]")
        graph.append(f"{cur}[lg]overlay=x='W*{lx:.6f}':y='H*{ly:.6f}':eof_action=repeat[lv]")
        cur = "[lv]"
    if extra_idx is not None:
        ex, ey = ed["extra_pos"]
        graph.append(f"[{extra_idx}:v]format=rgba,colorchannelmixer=aa={ed['extra_opacity']:.3f}[et]")
        graph.append(f"{cur}[et]overlay=x='W*{ex:.6f}-w/2':y='H*{ey:.6f}-h/2':eof_action=repeat[ev]")
        cur = "[ev]"
    if ass_name:
        # relative name: ffmpeg runs inside the ASS folder (no drive-letter escaping in the filter)
        graph.append(f"{cur}ass={ass_name}[sv]")
        cur = "[sv]"
    graph.append(f"{cur}format=yuv420p[vout]")
    return ";".join(graph)


def audio_args(ed: dict) -> list[str]:
    if not volume_changed(ed):
        return ["-c:a", "copy"]
    chain = f"volume={ed['volume']:.3f}"
    if ed["volume"] > 1.0:
        chain += ",alimiter=limit=0.97:level=0"   # louder without clipping
    return ["-af", chain, "-c:a", "aac", "-b:a", "192k"]


def _encoder_args(encoder: str) -> list[str]:
    """auto = NVENC (several times faster on long videos), libx264 when the GPU cannot."""
    if encoder in ("h264_nvenc", "auto"):
        return ["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", "19", "-b:v", "0"]
    return ["-c:v", "libx264", "-preset", "medium", "-crf", "18"]


def apply_effects(
    ffmpeg: str,
    ffprobe: str,
    source_video: Path,
    output_video: Path,
    editor: dict,
    work_dir: Path,
    encoder: str = "libx264",
    log: LogFn = lambda _m: None,
    progress: Callable[[float], None] = lambda _f: None,
    proc_holder: dict | None = None,
    subtitle_ass: Path | None = None,
    source_map: dict | None = None,
) -> Path:
    """Render the edited final.

    No effects -> plain copy. Only the volume changed -> video stream copied, audio re-encoded.
    """
    ed = normalized_editor(editor)
    output_video.parent.mkdir(parents=True, exist_ok=True)
    picture = has_picture_effects(ed) or subtitle_ass is not None
    mix = bool(ed["original_sound_percent"])
    if not picture and not volume_changed(ed) and not mix:
        shutil.copy2(source_video, output_video)
        progress(1.0)
        return output_video

    info = probe_video(ffprobe, source_video)
    width, height, duration = info["width"], info["height"], max(0.1, info["duration"])
    canvas_w, _canvas_h = output_size(ed, width, height)
    cmd = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-nostats", "-i", str(source_video)]
    tmp = output_video.with_name(output_video.stem + ".part.mp4")
    background = None
    if mix:
        import json
        import background_audio
        report = json.loads((work_dir / "smart_sync_thiha_28/SMART_SYNC_REPORT.json").read_text(encoding="utf-8-sig"))
        sources = source_map or background_audio.work_source_map(work_dir, report)
        background = background_audio.build_track(ffmpeg, report, sources, work_dir, duration,
                        ed["original_sound_source"], log, proc_holder)
    audio_tail = ["-map", "0:a?"] + audio_args(ed)
    if not picture:
        if mix:
            cmd += ["-i", str(background), "-filter_complex", background_audio.mix_filter(1, ed["original_sound_percent"], ed["volume"])]
            audio_tail = ["-map", "[aout]", "-c:a", "aac", "-b:a", "192k"]
        full = (cmd + ["-map", "0:v", "-c:v", "copy"] + audio_tail + ["-movflags", "+faststart", str(tmp)]) if mix else (
            cmd + ["-map", "0:v", "-map", "0:a?", "-c:v", "copy"] + audio_args(ed) + ["-movflags", "+faststart", str(tmp)])
        p = subprocess.run(full, capture_output=True, text=True, encoding="utf-8", errors="replace",
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if p.returncode != 0 or not tmp.is_file():
            raise RuntimeError("Volume pass failed: " + (p.stderr or "")[-2500:])
        tmp.replace(output_video)
        progress(1.0)
        return output_video
    idx = 1
    title_idx = logo_idx = extra_idx = None
    if ed["title_text"]:
        png = render_text_png(ed["title_text"], work_dir / "title_overlay.png", title_png_config(ed["title_size"], canvas_w))
        cmd += ["-i", str(png)]
        title_idx, idx = idx, idx + 1
    if logo_active(ed):
        cmd += ["-i", ed["logo_path"]]
        logo_idx, idx = idx, idx + 1
    if ed["extra_text"]:
        png = render_text_png(ed["extra_text"], work_dir / "extra_text_overlay.png", extra_png_config(ed["extra_size"], canvas_w))
        cmd += ["-i", str(png)]
        extra_idx, idx = idx, idx + 1

    ass_name = subtitle_ass.name if subtitle_ass is not None else None
    graph = build_filter_graph(ed, width, height, title_idx, logo_idx, extra_idx, ass_name)
    if mix:
        cmd += ["-i", str(background)]
        graph += ";" + background_audio.mix_filter(idx, ed["original_sound_percent"], ed["volume"])
        audio_tail = ["-map", "[aout]", "-c:a", "aac", "-b:a", "192k"]
    tail = audio_tail + ["-movflags", "+faststart", "-progress", "pipe:1", str(tmp)]

    def run(enc: str) -> tuple[int, str]:
        full = cmd + ["-filter_complex", graph, "-map", "[vout]"] + _encoder_args(enc) + ["-pix_fmt", "yuv420p"] + tail
        with subprocess.Popen(
            full, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            encoding="utf-8", errors="replace", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            cwd=str(subtitle_ass.parent) if subtitle_ass is not None else None,
        ) as proc:
            if proc_holder is not None:
                proc_holder["proc"] = proc
            for line in proc.stdout:
                if line.startswith("out_time_us=") or line.startswith("out_time_ms="):
                    try:
                        progress(min(1.0, int(line.split("=", 1)[1]) / 1_000_000.0 / duration))
                    except ValueError:
                        pass
            err = proc.stderr.read()
            rc = proc.wait()
        if proc_holder is not None:
            proc_holder["proc"] = None
        return rc, err

    rc, err = run(encoder)
    if rc != 0 and encoder in ("h264_nvenc", "auto"):
        log("⚠️ NVENC failed for the effects pass — libx264 fallback")
        rc, err = run("libx264")
    if rc != 0 or not tmp.is_file() or tmp.stat().st_size < 5000:
        raise RuntimeError("Effects render failed: " + (err or "")[-2500:])
    tmp.replace(output_video)
    progress(1.0)
    return output_video
