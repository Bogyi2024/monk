"""User narration overrides, kept separately from Gemini's recoverable story cache."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

EDITS_NAME = "SCRIPT_EDITS.json"
ORIGINALS_NAME = "ORIGINAL_SYNC_NARRATION_BLOCKS.json"


def read_edits(work: Path) -> dict[str, str]:
    path = Path(work) / EDITS_NAME
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict) or any(not isinstance(v, str) for v in data.values()):
        raise ValueError(f"{path}: expected block ID → narration text")
    return {str(k): v.strip() for k, v in data.items()}


def write_edits(work: Path, edits: dict[str, str]) -> None:
    path = Path(work) / EDITS_NAME
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(edits, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def edits_hash(work: Path) -> str | None:
    edits = read_edits(work)
    return hashlib.sha256(json.dumps(edits, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest() if edits else None


def apply_edits(blocks: list[dict], work: Path, check_unicode, check_style, log=print) -> tuple[str, list[dict]]:
    """Preserve the generated originals, then rebuild BOTH blocks and canonical story."""
    originals = Path(work) / ORIGINALS_NAME
    originals.write_text(json.dumps(blocks, ensure_ascii=False, indent=2), encoding="utf-8")
    edits = read_edits(work)
    result = [dict(b) for b in blocks]
    known = {str(b["sync_block_id"]) for b in result}
    for bid in edits.keys() - known:
        log(f"[SCRIPT EDIT] {bid}: absent from this story/length; override kept for later")
    for b in result:
        bid = str(b["sync_block_id"])
        if bid in edits and edits[bid] != b["narration_text"]:
            b["original_narration_text"] = b["narration_text"]
            b["narration_text"] = edits[bid]
            issues = list(check_unicode(edits[bid])) + list(check_style(edits[bid]))
            if issues:
                log(f"[SCRIPT EDIT WARNING] {bid}: {'; '.join(issues)} (user text kept)")
    return " ".join(str(b["narration_text"]).strip() for b in result).strip(), result
