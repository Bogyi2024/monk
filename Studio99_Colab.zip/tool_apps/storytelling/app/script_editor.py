"""Chronological narration editor with native Myanmar shaping and separate overrides.

Script Review (2026-10-24, user: like Studio99's Recap, plus the part's picture): the window also plays each
block's own beat slice (`slice_player.SlicePlayer`), exports the edited script, rewrites the story in another
telling style and hands the file on to voice + video. Those three buttons are callbacks from the Studio; the
window itself never starts the engine."""
from __future__ import annotations

import importlib.util
import json
import shutil
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk

from native_text import NativeTextBox
from script_edits import ORIGINALS_NAME, read_edits, write_edits

BLOCKS_NAME = "SYNC_NARRATION_BLOCKS.json"
RELOAD_MS = 2000            # a rewritten / newly finished script is read in on its own


def letters(text: str) -> int:
    """The engine's speech-length unit: code points without spaces (NARRATOR_LETTERS_PER_SEC)."""
    return len("".join(str(text).split()))


class ScriptEditor(tk.Toplevel):
    def __init__(self, master, work: Path, on_saved=None, video: Path | None = None, ffmpeg: str = "ffmpeg",
                 script_out: Path | None = None, style_var: tk.StringVar | None = None, style_values=(),
                 on_style_changed=None, on_style_notes=None, on_rewrite=None, on_continue=None):
        super().__init__(master)
        self.work, self.on_saved = Path(work), on_saved
        self.video, self.script_out = (Path(video) if video else None), (Path(script_out) if script_out else None)
        self.on_rewrite, self.on_continue = on_rewrite, on_continue
        spec = importlib.util.spec_from_file_location("script_editor_checks", Path(__file__).parent / "engine/manju_v62_engine.py")
        self.checks = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.checks)
        self.index = None
        self.loaded = ""
        self.stamp = None
        self._read()
        self.title(f"📜 Script — {work.name}")
        self.geometry("1240x880")
        self.minsize(900, 640)
        self.protocol("WM_DELETE_WINDOW", self.close)
        nav = ttk.Frame(self, padding=8)
        nav.pack(fill="x")
        self.search = tk.StringVar()
        ttk.Entry(nav, textvariable=self.search, width=32).pack(side="left")
        ttk.Button(nav, text="Search", command=self.find).pack(side="left", padx=4)
        ttk.Button(nav, text="◀ Problem", command=lambda: self.problem(-1)).pack(side="left", padx=4)
        ttk.Button(nav, text="Problem ▶", command=lambda: self.problem(1)).pack(side="left")
        flow = ttk.Frame(self, padding=(8, 0, 8, 8))
        flow.pack(side="bottom", fill="x")
        if style_var is not None:
            ttk.Label(flow, text="ရေးဟန် (style)").pack(side="left")
            pick = ttk.Combobox(flow, textvariable=style_var, state="readonly", width=28, values=list(style_values))
            pick.pack(side="left", padx=(6, 0))
            if on_style_changed:
                pick.bind("<<ComboboxSelected>>", lambda _e: on_style_changed())
            if on_style_notes:
                ttk.Button(flow, text="✎ Notes / sample", command=on_style_notes).pack(side="left", padx=(6, 0))
            if on_rewrite:
                ttk.Button(flow, text="↻ ဒီ style နဲ့ ပြန်ရေးမယ်", command=self.rewrite).pack(side="left", padx=(6, 0))
        if on_continue:
            ttk.Button(flow, text="▶ အသံ + Video ဆက်လုပ်မယ်", command=self.go_on).pack(side="right")
        actions = ttk.Frame(self, padding=8)
        actions.pack(side="bottom", fill="x")
        ttk.Button(actions, text="Save", command=self.save).pack(side="left")
        ttk.Button(actions, text="Revert to original", command=self.revert).pack(side="left", padx=8)
        ttk.Button(actions, text="📄 Script ထုတ်", command=self.export).pack(side="left")
        ttk.Label(actions, text="Save ပြီး ▶ / START — ပြင်ထားတဲ့စာကြောင်းကိုပဲ အသံပြန်ထုတ်မယ်။").pack(side="left", padx=8)
        ttk.Button(actions, text="Close", command=self.close).pack(side="right")
        self.status = tk.StringVar()
        ttk.Label(self, textvariable=self.status, wraplength=1200).pack(side="bottom", fill="x", padx=8)
        body = ttk.Panedwindow(self, orient="horizontal")
        body.pack(fill="both", expand=True, padx=8, pady=8)
        left, right = ttk.Frame(body), ttk.Frame(body)
        body.add(left, weight=1)
        body.add(right, weight=3)
        self.tree = ttk.Treeview(left, columns=("time", "text"), show="headings", selectmode="browse")
        self.tree.heading("time", text="Source time")
        self.tree.heading("text", text="Narration")
        self.tree.column("time", width=100, stretch=False)
        self.tree.column("text", width=180)
        scroll = ttk.Scrollbar(left, command=self.tree.yview)
        scroll.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(fill="both", expand=True)
        self._fill_tree()
        self.tree.bind("<<TreeviewSelect>>", self.select)
        self.player = None
        if self.video is not None:
            from slice_player import SlicePlayer
            self.player = SlicePlayer(right, ffmpeg=ffmpeg)
            self.player.pack(anchor="w", pady=(0, 6))
        self.info = tk.StringVar()
        ttk.Label(right, textvariable=self.info).pack(fill="x")
        ttk.Label(right, text="Source dialogue / meaning (read-only)").pack(anchor="w", pady=4)
        self.source = tk.Text(right, height=5, wrap="word", font=("Myanmar Text", 12))
        self.source.pack(fill="x")
        ttk.Label(right, text="Narration (editable)").pack(anchor="w", pady=6)
        holder = tk.Frame(right, bg="#151922")
        holder.pack(fill="both", expand=True)
        self.native = None
        try:
            self.native = NativeTextBox(holder, font="Myanmar Text", size_pt=14, bg="#151922", fg="#e7eaf0")
        except (OSError, AttributeError):
            self.box = tk.Text(holder, wrap="word", font=("Myanmar Text", 14), undo=True)
            self.box.pack(fill="both", expand=True)
        self.tree.selection_set("0") if self.blocks else None
        self.after(RELOAD_MS, self._watch)

    # ---------------------------------------------------------------- the script on disk
    def _blocks_stamp(self):
        path = self.work / BLOCKS_NAME
        return path.stat().st_mtime_ns if path.exists() else None

    def _read(self) -> None:
        """Blocks (generated originals), the user's edits and the analysis lines behind each block."""
        self.edits = read_edits(self.work)
        self.stamp = self._blocks_stamp()
        original = self.work / ORIGINALS_NAME
        if not original.exists():
            original.write_bytes((self.work / BLOCKS_NAME).read_bytes())
        self.blocks = sorted(json.loads(original.read_text(encoding="utf-8-sig")),
                             key=lambda b: (b.get("source_file", ""), float(b["source_start_sec"])))
        self.sources = {}
        timeline = next((self.work / n for n in ("GEMINI_STORY_TIMELINE_CAST.json", "GEMINI_STORY_TIMELINE.json")
                         if (self.work / n).exists()), None)
        if timeline:
            rows = json.loads(timeline.read_text(encoding="utf-8-sig"))
            if isinstance(rows, dict):
                rows = rows.get("beats", [])
            self.sources = {str(b.get("beat_id")): b for b in rows}
        self.voiced = {}
        report = self.work / "smart_sync_thiha_28" / "SMART_SYNC_REPORT.json"
        if report.exists():
            try:
                for b in json.loads(report.read_text(encoding="utf-8-sig")).get("blocks", []):
                    self.voiced[str(b.get("sync_block_id"))] = (str(b.get("narration_text") or ""),
                                                                float(b.get("audio_duration") or 0.0))
            except (ValueError, OSError):
                self.voiced = {}

    def _fill_tree(self) -> None:
        self.tree.delete(*self.tree.get_children())
        for i, b in enumerate(self.blocks):
            self.tree.insert("", "end", iid=str(i), values=(self.clock(b["source_start_sec"]), self.text(i)))

    def _watch(self) -> None:
        """Read a rewritten script in (↻ style, or the batch finished this file) when no line is half-edited."""
        if not self.winfo_exists():
            return
        if self._blocks_stamp() != self.stamp:
            if self.index is not None and self.current() != self.loaded:
                self.status.set("📜 A new script is ready — Save or Revert this line to see it.")
            else:
                keep = self.index or 0
                self._read()
                self.index, self.loaded = None, ""
                self._fill_tree()
                if self.blocks:
                    pick = str(min(keep, len(self.blocks) - 1))
                    self.tree.selection_set(pick)
                    self.tree.see(pick)
                self.status.set(f"📜 New script read in ({len(self.blocks)} lines).")
        self.after(RELOAD_MS, self._watch)

    @staticmethod
    def clock(seconds):
        m, s = divmod(float(seconds), 60)
        return f"{int(m):02d}:{s:05.2f}"

    def text(self, i):
        b = self.blocks[i]
        return self.edits.get(str(b["sync_block_id"]), b["narration_text"])

    def current(self):
        return (self.native.get() if self.native else self.box.get("1.0", "end-1c")).strip()

    def leave(self):
        if self.index is None or self.current() == self.loaded:
            return True
        choice = messagebox.askyesnocancel("Unsaved script", "Save this line before leaving?", parent=self)
        return self.save() if choice else choice is False

    def timing(self, i) -> str:
        """Picture length against the narration (estimated, or the real voice once it was made)."""
        b = self.blocks[i]
        picture = max(0.01, float(b["source_end_sec"]) - float(b["source_start_sec"]))
        text = self.text(i)
        voiced = self.voiced.get(str(b["sync_block_id"]))
        if voiced and voiced[0].strip() == text.strip() and voiced[1] > 0:
            speech, how = voiced[1], "voice"
        else:
            speech, how = letters(text) / float(self.checks.NARRATOR_LETTERS_PER_SEC), "voice ~"
        speed = picture / max(0.01, speech)
        feel = "slowed" if speed < 0.97 else ("faster" if speed > 1.03 else "same speed")
        return f"picture {picture:.1f} s · {how}{speech:.1f} s → picture ×{speed:.2f} ({feel})"

    def select(self, _event=None):
        picked = self.tree.selection()
        if not picked or int(picked[0]) == self.index:
            return
        i = int(picked[0])
        if not self.leave():
            self.tree.selection_set(str(self.index))
            return
        self.index = i
        b = self.blocks[i]
        self.loaded = self.text(i)
        if self.native:
            self.native.set(self.loaded)
        else:
            self.box.delete("1.0", "end")
            self.box.insert("1.0", self.loaded)
        self.info.set(f"{b['sync_block_id']}   {self.clock(b['source_start_sec'])} → {self.clock(b['source_end_sec'])}"
                      f"   |   {self.timing(i)}")
        source = [self.sources.get(str(bid), {}) for bid in b.get("story_item_ids", [])]
        self.source.configure(state="normal")
        self.source.delete("1.0", "end")
        self.source.insert("1.0", "\n\n".join("\n".join(str(r.get(k) or "") for k in
                           ("source_dialogue", "dialogue_meaning", "visual_action")) for r in source))
        self.source.configure(state="disabled")
        self.status.set("; ".join(self.issues(self.loaded)))
        if self.player is not None:
            self.player.load(self.video, float(b["source_start_sec"]), float(b["source_end_sec"]))

    def issues(self, text):
        return self.checks._story_text_unicode_issues(text) + self.checks._story_local_style_issues(text)

    def save(self):
        if self.index is None:
            return True
        b = self.blocks[self.index]
        text = self.current()
        bid = str(b["sync_block_id"])
        if text == b["narration_text"]:
            self.edits.pop(bid, None)
        else:
            self.edits[bid] = text
        write_edits(self.work, self.edits)
        self.loaded = text
        self.tree.set(str(self.index), "text", text)
        self.info.set(self.info.get().split("   |   ")[0] + f"   |   {self.timing(self.index)}")
        self.status.set("Saved. " + "; ".join(self.issues(text)))
        if self.on_saved:
            self.on_saved()
        return True

    def revert(self):
        if self.index is None:
            return
        self.edits.pop(str(self.blocks[self.index]["sync_block_id"]), None)
        write_edits(self.work, self.edits)
        i, self.index, self.loaded = self.index, None, ""
        self.tree.selection_set(str(i))
        self.select()
        self.tree.set(str(i), "text", self.text(i))
        if self.on_saved:
            self.on_saved()

    def find(self):
        query = self.search.get().casefold().strip()
        start = (self.index or 0) + 1
        for i in list(range(start, len(self.blocks))) + list(range(start)):
            b = self.blocks[i]
            evidence = [self.sources.get(str(k), {}) for k in b.get("story_item_ids", [])]
            if query in (self.text(i) + json.dumps(evidence, ensure_ascii=False)).casefold():
                self.tree.selection_set(str(i))
                self.tree.see(str(i))
                return
        self.status.set("No matching line.")

    def problem(self, direction):
        for step in range(1, len(self.blocks) + 1):
            i = ((self.index or 0) + direction * step) % len(self.blocks)
            if self.issues(self.text(i)):
                self.tree.selection_set(str(i))
                self.tree.see(str(i))
                return
        self.status.set("No problem lines found.")

    def edited_blocks(self) -> list[dict]:
        return [dict(b, narration_text=self.text(i)) for i, b in enumerate(self.blocks)]

    def export(self):
        """The script as it is now (with the edits): NARRATOR_SCRIPT(.txt / _TIMED.txt) in the work folder and
        the Studio's SCRIPTS copy."""
        if not self.leave():
            return
        script, timed = self.checks._v64_write_script(self.edited_blocks(), self.work)
        where = [script]
        if self.script_out is not None:
            self.script_out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(script, self.script_out)
            shutil.copy2(timed, self.script_out.with_name(self.script_out.stem + "_TIMED.txt"))
            where = [self.script_out]
        self.status.set(f"📄 Script → {where[0]}  (+ _TIMED.txt with the source times)")

    def rewrite(self):
        if not self.leave():
            return
        kept = len(self.edits)
        note = (f"\n\nYour {kept} edited line(s) stay as you wrote them (Revert a line to take the new text)."
                if kept else "")
        if messagebox.askyesno("Rewrite the story",
                               "Gemini ပြန်ရေးမယ် — ဒီ file ရဲ့ story တစ်ခုလုံးကို ရွေးထားတဲ့ style နဲ့ "
                               "(story အပိုင်းတစ်ပိုင်းကို request တစ်ခုလောက်; အရင် style ရဲ့ cache ကျန်ပါတယ်)။"
                               + note, parent=self):
            self.status.set("↻ " + self.on_rewrite())

    def go_on(self):
        if not self.leave():
            return
        self.status.set("▶ " + self.on_continue())

    def close(self):
        if self.leave():
            if self.player is not None:
                self.player.stop()
            self.destroy()
