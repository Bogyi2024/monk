"""Accelerated analysis uses clip time at the API boundary, source time everywhere else."""
from __future__ import annotations

import copy


def scale_timeline(data, speed):
    if speed == 1:
        return data
    result = copy.deepcopy(data)
    for beat in result.get("beats", []):
        for key in ("start_sec", "end_sec"):
            if key in beat:
                beat[key] = float(beat[key]) * speed
    return result


def timeline_prompt(original, speed, duration):
    if speed == 1:
        return original
    return (original + f"\n\nANALYSIS PLAYBACK: {speed:g}x. The actual uploaded clip lasts "
            f"{duration / speed:.3f} seconds and covers {duration:.3f} seconds of source footage. "
            f"For this accelerated clip, ALL start_sec/end_sec values must be in uploaded CLIP TIME, "
            f"between 0 and {duration / speed:.3f}, overriding the source-duration references above. "
            "Do not scale times yourself; Python converts clip time to source time after your answer.")
