"""Source sound follows Smart Sync slices and the cumulative video frame clock."""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import wave
from fractions import Fraction
from pathlib import Path

SR = 48000
CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def atempo(speed):
    parts = []
    while speed < 0.5:
        parts.append("atempo=0.5")
        speed *= 2
    while speed > 2:
        parts.append("atempo=2.0")
        speed /= 2
    parts.append(f"atempo={speed:.12f}")
    return ",".join(parts)


def run_child(cmd, proc_holder=None, log=lambda _m: None):
    with subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                          encoding="utf-8", errors="replace", creationflags=CREATE_NO_WINDOW) as proc:
        if proc_holder is not None:
            proc_holder["proc"] = proc
        lines = []
        for line in proc.stdout:
            lines.append(line)
            if line.startswith("BG:"):
                log(line.rstrip())
        rc = proc.wait()
    if proc_holder is not None:
        proc_holder["proc"] = None
    if rc:
        raise RuntimeError("".join(lines)[-2000:])


def separated_source(source, work, ffmpeg, log, proc_holder=None):
    """Demucs stays in its own process. Unavailable dependencies/model → original sound."""
    folder = Path(work)
    target = folder / "background_44k.wav"
    stat = Path(source).stat()
    stamp = [str(Path(source).resolve()), stat.st_size, stat.st_mtime_ns]
    try:
        meta = json.loads((folder / "background.json").read_text(encoding="utf-8"))
        if target.exists() and meta.get("signature", {}).get("source") == stamp:
            return target
    except (OSError, ValueError):
        pass
    try:
        log("Original sound: removing voices in a child process (first use downloads Demucs).")
        run_child([sys.executable, "-X", "utf8", str(Path(__file__).parent / "engine/background.py"),
                   str(source), str(folder), ffmpeg], proc_holder, log)
        if not target.is_file():
            raise RuntimeError("Demucs did not create a track")
        return target
    except Exception as exc:
        log(f"Background only unavailable ({str(exc)[-200:]}): using original sound.")
        return Path(source)


def sample_plan(report, seconds=None):
    fps = Fraction(str(report.get("fps") or "30/1"))
    cursor = frames = 0
    rows = []
    final_samples = round(float(seconds) * SR) if seconds is not None else None
    for block in report["blocks"]:
        frames += int(block["frames"])
        end = round(Fraction(frames * SR, 1) / fps)
        if final_samples is not None:
            end = min(end, final_samples)
        samples = max(0, end - cursor)
        source_duration = float(block.get("source_duration") or
                                (float(block["source_end_sec"]) - float(block["source_start_sec"]) -
                                 float(block.get("footage_cut_sec") or 0)))
        rows.append({"block": block, "start_sample": cursor, "samples": samples,
                     "source_duration": source_duration})
        cursor = end
    return rows


def slice_filter(row):
    """Below 0.5×: play naturally, fade out, pad with silence. Freeze holds get silence too."""
    block, samples, duration = row["block"], row["samples"], row["source_duration"]
    target = samples / SR
    motion = float(block.get("freeze_motion_sec") or target)
    speed = duration / max(0.001, motion)
    if speed < 0.5:
        chain = f"afade=t=out:st={max(0, duration - 0.12):.6f}:d=0.12"
    else:
        chain = atempo(speed)
        if float(block.get("freeze_seconds") or 0) > 0:
            chain += f",afade=t=out:st={max(0, motion - 0.12):.6f}:d=0.12"
    return chain + f",aresample={SR},apad,atrim=end_sample={samples},asetpts=PTS-STARTPTS"


def build_track(ffmpeg, report, source_map, work, seconds=None, mode="original", log=lambda _m: None,
                proc_holder=None, separator=separated_source):
    work = Path(work)
    rows = sample_plan(report, seconds)
    sources = {}
    for name, source in source_map.items():
        source = Path(source)
        folder = work if len(source_map) == 1 else work / ("background_" + hashlib.sha1(name.encode()).hexdigest()[:8])
        folder.mkdir(parents=True, exist_ok=True)
        sources[name] = separator(source, folder, ffmpeg, log, proc_holder) if mode == "background" else source
    signature = {"version": 1, "mode": mode, "rows": rows,
                 "sources": {k: [str(p.resolve()), p.stat().st_size, p.stat().st_mtime_ns] for k, p in sources.items()}}
    digest = hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest()
    output, meta = work / "background_track.wav", work / "background_track.json"
    try:
        if output.is_file() and json.loads(meta.read_text()) == digest:
            return output
    except (OSError, ValueError):
        pass
    scratch = work / "background_slices"
    scratch.mkdir(exist_ok=True)
    tmp = output.with_suffix(".part.wav")
    with wave.open(str(tmp), "wb") as joined:
        joined.setparams((2, 2, SR, 0, "NONE", "not compressed"))
        for i, row in enumerate(rows):
            if not row["samples"]:
                continue
            b = row["block"]
            source = sources[b["source_file"]]
            part = scratch / f"{i:05d}.wav"
            cmd = [ffmpeg, "-y", "-v", "error", "-ss", f"{float(b['source_start_sec']):.6f}",
                   "-t", f"{row['source_duration']:.6f}", "-i", str(source), "-vn", "-af", slice_filter(row),
                   "-ar", str(SR), "-ac", "2", "-c:a", "pcm_s16le", str(part)]
            try:
                run_child(cmd, proc_holder)
                with wave.open(str(part), "rb") as reader:
                    pcm = reader.readframes(row["samples"])
                need = row["samples"] * 4
                joined.writeframesraw(pcm[:need] + bytes(max(0, need - len(pcm))))
            except RuntimeError as exc:
                # Silent source videos are valid; other failures need review rather than an unnoticed empty track.
                if "does not contain any stream" not in str(exc) and "matches no streams" not in str(exc):
                    raise
                log(f"{b['sync_block_id']}: source has no audio; silence used.")
                joined.writeframesraw(bytes(row["samples"] * 4))
            finally:
                part.unlink(missing_ok=True)
    tmp.replace(output)
    meta.write_text(json.dumps(digest), encoding="utf-8")
    log("Original sound: track follows each beat's rendered frames; <0.5× blocks fade to silence.")
    return output


def work_source_map(work, report):
    folder = Path(work)
    marker = folder / "source.json"
    if not marker.exists() and folder.name.startswith("lang_"):
        marker = folder.parent / "source.json"
    source = Path(json.loads(marker.read_text(encoding="utf-8"))["source"])
    names = {b["source_file"] for b in report["blocks"]}
    if len(names) != 1:
        raise ValueError("Multiple source files: pass a source_map for original sound")
    return {name: source for name in names}


def mix_filter(index, percent, voice_volume):
    return (f"[0:a]volume={voice_volume:.3f}[voice];[{index}:a]volume={percent / 100:.3f}[bg];"
            "[voice][bg]amix=inputs=2:duration=first:normalize=0,"
            "alimiter=limit=0.97:level=0:latency=1[aout]")
