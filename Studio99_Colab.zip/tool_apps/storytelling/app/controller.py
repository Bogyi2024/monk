"""Storytelling Recap Studio — batch UI for the Manju V6.2 storytelling engine.

Queue files or whole folders -> each file runs through the engine (Gemini timeline ->
Burmese storyteller narration -> Edge TTS or VoxCPM (Colab links) -> block-native Smart
Sync) in its own output folder -> one effects pass (Flip / Zoom / Output ratio / Blur /
Title / Logo / Extra text / subtitles) -> FINALS/<name>.mp4.
"""
from __future__ import annotations

import hashlib
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from scroll_page import ScrollPage

from PIL import Image, ImageEnhance, ImageFilter, ImageOps, ImageTk

import effects
import script_edits
import languages
import subtitles
import voxcpm_client
import youtube

# Edge TTS in this process (voice test, subtitle timing) must connect directly; the engine
# subprocess gets Gemini's proxy through --proxy.


ROOT_DIR = Path(__file__).resolve().parents[1]
APP_DIR = Path(__file__).resolve().parent
ENGINE = APP_DIR / "engine" / "manju_v62_engine.py"
CONFIG_PATH = ROOT_DIR / "config.json"
LOGS_DIR = ROOT_DIR / "logs"
PREVIEW_DIR = LOGS_DIR / "preview"
ENGINE_FINAL_NAME = "FINAL_STORYTELLING_THIHA_28.mp4"     # what the engine writes
ENGINE_RAW_NAME = "engine_output_NO_EFFECTS.mp4"           # renamed so nobody mistakes it for the final
STATE_NAME = "studio_state.json"
SCRIPT_STATE_NAME = "studio_state_script.json"   # Script Review: what the script was written with (video: STATE_NAME)
FINALS_DIR_NAME = "FINALS"
SCRIPTS_DIR_NAME = "SCRIPTS"              # "Script only" results: <Output>/SCRIPTS/<name>.txt
ENGINE_SCRIPT_NAME = "NARRATOR_SCRIPT.txt"
DOWNLOADS_DIR_NAME = "_downloads"         # queue links are downloaded here
STORY_MEMORY_NAME = "STORY_MEMORY.json"   # "Same series": a file's story so far, read by the next file
ENGINE_DEFAULT_VOICE = ("my-MM-ThihaNeural", "+25%")        # what runs before studio_state.json existed
VIDEO_EXTS = {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v", ".ts"}
DEFAULT_MODELS = "gemini-3-flash-preview,gemini-3.5-flash,gemini-3.5-flash-lite"   # see DEFAULT_GEMINI_MODELS in the engine (2026-10-02 benchmark)
CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
# Smooth slow motion: which slowed blocks get RIFE (engine --smooth-below)
# Story length (engine --narration-length, 2026-10-11): Gemini scores each beat 1-5 first;
# skip = beats scored 1-2 are left out, fit = beats scored 1-3 are told within 1.5x their footage.
# Story length (2026-10-12, user): the story as before, or the same story told to the point so the picture is
# hardly slowed (engine "short"). skip / fit stay in the engine (--narration-length) but not in the list.
# 2026-10-13 (user): "short_steady" = short, but every line at least 0.8x its footage and the picture never faster
# than 1.25x (a pause after the line); A/B on 10 min: no picture over 1.27x (short: 2.69x, 14% over 1.5x), but
# 61% of the screen time under 0.9x (short: 46%), so the user keeps both.
STORY_LENGTH_LABELS = {"short": "Short — to the point", "short_steady": "Short — steady picture (≤1.25x)",
                       "medium": "Medium — in between (≤1.4x)", "full": "Full story (as before)",
                       "recap": "Recap — my length (min or % of video)"}
RECAP_UNITS = {"min": "min", "percent": "% of video"}   # never longer than the video itself (2026-10-25)
SMOOTH_BELOW_LABELS = {0.9: "under 0.9x (smoothest)", 0.5: "under 0.5x (faster render)"}
# Telling style (2026-10-24, the user's plan): how the story is told - a preset, the user's own notes and a sample
# paragraph whose way of telling (not its content) is copied. Saved per file as <work>/TELLING_STYLE.json (engine
# --story-style-file); another style is another story, so a finished file is made again.
TELLING_STYLE_LABELS = {"default": "Default (as before)", "light": "Light — like telling a friend",
                        "calm": "Calm — clear explainer", "gripping": "Gripping — tense", "humor": "A little humor"}
TELLING_STYLE_NAME = "TELLING_STYLE.json"
STYLE_PREVIEW_SEC = 60

BG = "#0d0f14"
PANEL = "#151922"
FIELD = "#0a0c10"
BORDER = "#303744"
FG = "#e7eaf0"
MUTED = "#9da7b6"
ACCENT = "#5b8cff"
ACCENT_HOVER = "#739dff"
SUCCESS = "#55d187"
WARN = "#ffd166"
DANGER = "#ff6b6b"
BLUR_COLOR = "#48d7ff"
PREVIEW_MAX_W = 600
PREVIEW_MAX_H = 540
FRAME_MAX = 960                # preview source frame: long side in pixels (composed down to the canvas)
FILL_LABELS = {"blur": "Blurred background", "black": "Black bars", "crop": "Crop to fill"}
PROVIDERS = {"edge": "Edge TTS", "voxcpm": "VoxCPM (Colab links)"}

STATUS_TEXT = {
    "queued": "Queued",
    "running": "Running…",
    "effects": "Effects…",
    "done": "Done ✓",
    "failed": "Failed ✗",
    "stopped": "Stopped",
}

DEFAULT_CONFIG = {
    "gemini_env_path": r"",
    "proxy": "",
    "gemini_models": DEFAULT_MODELS,
    "gemini_timeout_sec": 180,
    "tts_voice": "my-MM-ThihaNeural",
    "tts_rate_percent": 25,
    "language": languages.DEFAULT,
    "narration_style": "classic",
    "story_length": "full",
    "recap_minutes": 12,
    "recap_unit": "min",
    "analysis_speed": 1,
    "slow_style": "freeze",       # 2026-10-26: the user chose Freeze + zoom over RIFE / Mix after the A/B
    "freeze_below": 0.6,
    "story_style": "default",
    "story_style_notes": "",
    "story_style_sample": "",
    "tts_provider": "edge",
    "voxcpm_links": [{"url": "", "type": voxcpm_client.LINK_GRADIO}],
    "voxcpm_voice": "",
    "voxcpm_rate_percent": 0,
    "output_root": "",
    "share_registry": True,
    "skip_finished": True,
    "whisper_check": True,
    "short_pauses": True,
    "smooth_motion": True,
    "smooth_below": 0.9,
    "output_mode": "video",
    "encoder": "auto",
    "ffmpeg_path": "",
    "ffprobe_path": "",
    "queue": [],
    "editor": dict(effects.DEFAULT_EDITOR),
}

RX_CLIPS = re.compile(r"\[V6 FILE \d+/\d+\].*\|\s*(\d+) Gemini clip")
RX_CLIP = re.compile(r"^\s*Clip (\d+)/(\d+)")
RX_STORY = re.compile(r"\[V6 STORY (?:PASS|RESUME)\] part (\d+)/(\d+)")
RX_TTS = re.compile(r"\[(\d+)/(\d+)\] B\d+ generate block TTS")
RX_RENDER = re.compile(r"✅ \[(\d+)/(\d+)\] B\d+")
RX_FINAL = re.compile(r"FINAL READY: (.+)$")


def load_config() -> dict:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    try:
        saved = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if isinstance(saved, dict):
            cfg.update(saved)
    except Exception:
        pass
    cfg["proxy"] = ""  # migrate old local-proxy defaults: use the external VPN / OS network
    cfg["editor"] = effects.normalized_editor(cfg.get("editor"))
    return languages.restrict_output(cfg)


_config_lock = threading.Lock()


def save_config(cfg: dict) -> None:
    # Unique temporary names avoid collisions; retry briefly while Windows
    # readers/scanners hold the destination open without delete sharing.
    with _config_lock:
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=CONFIG_PATH.parent,
                                             prefix=".story_config_", suffix=".tmp", delete=False) as stream:
                temporary = Path(stream.name)
                json.dump(cfg, stream, ensure_ascii=False, indent=2)
            for attempt in range(6):
                try:
                    temporary.replace(CONFIG_PATH)
                    break
                except PermissionError:
                    if attempt == 5:
                        raise
                    time.sleep(0.05 * (attempt + 1))
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)


def find_tool(configured: str, name: str) -> str:
    if configured and Path(configured).is_file():
        return configured
    found = shutil.which(name)
    if found:
        return found
    fallback = Path(r"C:\ffmpeg\bin") / f"{name}.exe"
    return str(fallback) if fallback.is_file() else name


def natural_key(path: Path) -> list:
    return [int(p) if p.isdigit() else p.casefold() for p in re.split(r"(\d+)", path.name)]


def safe_name(text: str) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", str(text)).strip(" ._")
    return cleaned[:90] or "video"


def same_path(a: Path | str, b: Path | str) -> bool:
    return os.path.normcase(os.path.abspath(str(a))) == os.path.normcase(os.path.abspath(str(b)))


def work_dir_for(root: Path, src: Path) -> Path:
    """<output>/<file name>/ — a second file with the same name gets a short hash suffix."""
    base = root / safe_name(src.stem)
    marker = base / "source.json"
    if marker.is_file():
        try:
            owner = json.loads(marker.read_text(encoding="utf-8")).get("source", "")
            if owner and not same_path(owner, src):
                digest = hashlib.sha1(os.path.normcase(os.path.abspath(str(src))).encode("utf-8")).hexdigest()[:6]
                base = root / f"{safe_name(src.stem)}_{digest}"
        except Exception:
            pass
    return base


def lang_work_dir(root: Path, src: Path, code: str) -> Path:
    """Burmese keeps <output>/<name>/; another language works in <output>/<name>/lang_<code>/
    and reuses the Gemini analysis in <output>/<name>/gemini_timeline_cache."""
    base = work_dir_for(root, src)
    return base if code == languages.DEFAULT else base / f"lang_{code}"


def finals_dir(root: Path, code: str) -> Path:
    """<output>/FINALS for Burmese, <output>/FINALS_EN, FINALS_TH, ... for the other languages."""
    return Path(root) / (FINALS_DIR_NAME + languages.suffix(code))


def final_video(root: Path, src: Path, code: str) -> Path:
    return finals_dir(root, code) / f"{work_dir_for(Path(root), src).name}.mp4"


def scripts_dir(root: Path, code: str) -> Path:
    """<output>/SCRIPTS for Burmese, SCRIPTS_EN, SCRIPTS_TH, ... for the other languages."""
    return Path(root) / (SCRIPTS_DIR_NAME + languages.suffix(code))


def final_script(root: Path, src: Path, code: str) -> Path:
    return scripts_dir(root, code) / f"{work_dir_for(Path(root), src).name}.txt"


def final_output(root: Path, src: Path, code: str, mode: str) -> Path:
    """What a finished job leaves: the script ("Script only") or the FINALS video."""
    return final_script(root, src, code) if mode == "script" else final_video(root, src, code)


def link_stem(info: dict) -> str:
    """"<title> [<id>]": the title is cut to 70 letters so the work folder name (90 at most) keeps the id."""
    title = safe_name(info["title"])
    return f"{title[:70].rstrip(' ._')} [{info['id']}]" if info.get("id") else title


def telling_style(s: dict) -> dict | None:
    """The chosen telling style, None for the built-in one (nothing is passed to the engine then)."""
    preset = str(s.get("story_style") or "default")
    preset = preset if preset in TELLING_STYLE_LABELS else "default"
    notes, sample = str(s.get("story_style_notes") or "").strip(), str(s.get("story_style_sample") or "").strip()
    if preset == "default" and not notes and not sample:
        return None
    return {"preset": preset, "notes": notes, "sample": sample}


def write_telling_style(work: Path, s: dict) -> Path | None:
    """<work>/TELLING_STYLE.json for the engine (kept with the file, like the rest of its work folder)."""
    style = telling_style(s)
    if not style:
        return None
    work.mkdir(parents=True, exist_ok=True)
    path = work / TELLING_STYLE_NAME
    path.write_text(json.dumps(style, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def link_file(root: Path, item: dict) -> Path | None:
    """Where a queue link is downloaded: <output>/_downloads/<title> [<id>].mp4 (None until looked up)."""
    if not item.get("stem"):
        return None
    return Path(root) / DOWNLOADS_DIR_NAME / f"{item['stem']}.mp4"


SHORT_PAUSE_SEC = 0.25     # "Short pauses": Edge TTS silence around each line cut to this (A/B "B", 2026-10-01)


def short_pause(s: dict) -> float | None:
    """The engine's --tts-pause for these settings: only classic Edge narration has per-line silence."""
    if s.get("short_pauses", True) and s.get("tts_provider", "edge") == "edge" and s.get("narration_style") != "flow":
        return SHORT_PAUSE_SEC
    return None


def raw_video(work: Path) -> Path | None:
    """Engine output without effects (older folders still have the engine's own name)."""
    raw, engine_final = work / ENGINE_RAW_NAME, work / ENGINE_FINAL_NAME
    if engine_final.is_file():
        engine_final.replace(raw)
    return raw if raw.is_file() else None


def read_state(work: Path, script: bool = False) -> dict:
    """What the file was made with. A script keeps its own state, so a script rewritten in another style never
    marks the old video as up to date; a script made before 2026-10-24 has only studio_state.json."""
    name = SCRIPT_STATE_NAME if script and (work / SCRIPT_STATE_NAME).exists() else STATE_NAME
    try:
        return json.loads((work / name).read_text(encoding="utf-8"))
    except Exception:
        return {"tts_voice": ENGINE_DEFAULT_VOICE[0], "tts_rate": ENGINE_DEFAULT_VOICE[1]}


def engine_input(src: Path, work: Path) -> Path:
    """Short path handed to the engine.

    Long Chinese file names push the engine's cache paths past Windows' 260-character
    limit, so new jobs get a hardlink named source.mp4 inside the work folder (no extra
    disk space). Jobs that already have caches under the original name keep using it.
    """
    if (work / "gemini_timeline_cache" / src.stem).is_dir():
        return src
    alias = work / f"source{src.suffix.lower()}"
    if alias.exists():
        try:
            if os.path.samefile(alias, src):
                return alias
        except OSError:
            pass
        alias.unlink()
    try:
        os.link(src, alias)
        return alias
    except OSError:
        pass
    if len(str(work)) + 2 * len(src.stem) + 60 < 250:
        return src
    shutil.copy2(src, alias)   # other drive and a long name: a copy is the safe option
    return alias


def keep_awake(on: bool) -> None:
    """Stop Windows from sleeping while a batch runs (per-thread; cleared when the thread ends)."""
    try:
        import ctypes
        es_continuous, es_system_required = 0x80000000, 0x00000001
        ctypes.windll.kernel32.SetThreadExecutionState(es_continuous | (es_system_required if on else 0))
    except Exception:
        pass


def progress_marker(work: Path, timeline_dir: Path | None = None) -> int:
    """How much the engine has cached so far (clips, story parts, TTS, rendered parts)."""
    total = 0
    folders = [work / sub for sub in ("gemini_timeline_cache", "storytelling_cache_v6", "smart_sync_thiha_28/block_tts_v61",
                                      "smart_sync_thiha_28/block_audio_v61", "smart_sync_thiha_28/block_video_v62")]
    if timeline_dir is not None:
        folders.append(timeline_dir)          # another language reuses the Burmese folder's analysis
    for folder in folders:
        if folder.is_dir():
            total += sum(len(files) for _root, _dirs, files in os.walk(folder))
    return total


def kill_tree(proc: subprocess.Popen | None) -> None:
    if proc is None or proc.poll() is not None:
        return
    try:
        subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                       capture_output=True, creationflags=CREATE_NO_WINDOW)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Storytelling Recap Studio — Manju V6.2 | Batch + Edge TTS / VoxCPM + 9:16 / Blur / Logo")
        self.geometry("1560x960")
        self.minsize(640, 360)
        self.configure(bg=BG)
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        PREVIEW_DIR.mkdir(parents=True, exist_ok=True)

        self.cfg = load_config()
        self.ffmpeg = find_tool(str(self.cfg.get("ffmpeg_path") or ""), "ffmpeg")
        self.ffprobe = find_tool(str(self.cfg.get("ffprobe_path") or ""), "ffprobe")
        self.msgq: queue.Queue[tuple[str, object]] = queue.Queue()
        self.stop_event = threading.Event()
        self.worker: threading.Thread | None = None
        self.proc_holder: dict = {"proc": None}
        self.items: dict[str, dict] = {}
        self._iid_counter = 0
        self._last_engine_error = ""
        self._engine_needs_attention = False

        # settings
        self.env_path = tk.StringVar(value=str(self.cfg["gemini_env_path"]))
        self.proxy = tk.StringVar(value=str(self.cfg["proxy"]))
        self.models = tk.StringVar(value=str(self.cfg["gemini_models"]))
        self.timeout_sec = tk.IntVar(value=int(self.cfg["gemini_timeout_sec"]))
        self.voice = tk.StringVar(value=str(self.cfg["tts_voice"]))
        self.tts_rate = tk.IntVar(value=int(self.cfg["tts_rate_percent"]))
        self.output_root = tk.StringVar(value=str(self.cfg["output_root"]))
        self.share_registry = tk.BooleanVar(value=bool(self.cfg["share_registry"]))
        self.skip_finished = tk.BooleanVar(value=bool(self.cfg["skip_finished"]))
        self.whisper_check = tk.BooleanVar(value=bool(self.cfg.get("whisper_check", True)))
        self.short_pauses = tk.BooleanVar(value=bool(self.cfg.get("short_pauses", True)))
        self.smooth_motion = tk.BooleanVar(value=bool(self.cfg.get("smooth_motion", True)))
        below = float(self.cfg.get("smooth_below", 0.9) or 0.9)
        self.smooth_below = tk.StringVar(value=SMOOTH_BELOW_LABELS[0.5 if below <= 0.5 else 0.9])
        mode = str(self.cfg.get("output_mode") or "video")
        self.output_mode = tk.StringVar(value=mode if mode in ("video", "script") else "video")
        self.encoder = tk.StringVar(value=str(self.cfg["encoder"]))
        code = str(self.cfg.get("language") or languages.DEFAULT)
        self.lang_code = languages.output_code(code)
        self.language = tk.StringVar(value=languages.display(self.lang_code))
        style = str(self.cfg.get("narration_style") or "classic")
        self.narration_style = tk.StringVar(value=style if style in ("classic", "flow") else "classic")
        self.story_length = tk.StringVar(value=STORY_LENGTH_LABELS.get(str(self.cfg.get("story_length") or "full"),
                                                                      STORY_LENGTH_LABELS["full"]))
        self.story_style = tk.StringVar(value=TELLING_STYLE_LABELS.get(str(self.cfg.get("story_style") or "default"),
                                                                      TELLING_STYLE_LABELS["default"]))
        self.style_notes = str(self.cfg.get("story_style_notes") or "")
        self.style_sample = str(self.cfg.get("story_style_sample") or "")
        self.slow_style = tk.StringVar(value={"rife": "AI in-between frames (as now)", "freeze": "Freeze + zoom", "mix": "Mix (freeze + RIFE)"}.get(self.cfg.get("slow_style"), "AI in-between frames (as now)"))
        self.freeze_below = tk.DoubleVar(value=float(self.cfg.get("freeze_below", 0.6)))
        self.analysis_2x = tk.BooleanVar(value=int(self.cfg.get("analysis_speed", 1)) == 2)
        self.recap_minutes = tk.IntVar(value=int(self.cfg.get("recap_minutes", 12)))
        self.recap_unit = tk.StringVar(value=RECAP_UNITS.get(str(self.cfg.get("recap_unit") or "min"), "min"))
        self.style_win = None
        self.script_wins: dict[str, tk.Toplevel] = {}   # queue item → its open 📜 Script window
        self.after_batch: list[str] = []               # ▶ / ↻ pressed in a Script window while a batch ran
        provider = str(self.cfg.get("tts_provider") or "edge")
        self.tts_provider = tk.StringVar(value=provider if provider in PROVIDERS else "edge")
        self.vox_voice = tk.StringVar(value=str(self.cfg.get("voxcpm_voice") or ""))
        self.vox_rate = tk.IntVar(value=int(self.cfg.get("voxcpm_rate_percent") or 0))
        self.vox_need = tk.StringVar(value=f"{voxcpm_client.BLOCKS_PER_LINK} blocks per link  ·  a 5-min video is ~60 blocks = 1 link")
        self.vox_rows: list[dict] = []           # {"url", "type", "status": StringVar, "widgets": [...]}
        self._vox_lock = threading.Lock()
        self._vox_live: list[dict] = []          # links as the worker thread should use them next
        self.link_logboxes: dict[int, tk.Text] = {}

        # editor
        ed = self.cfg["editor"]
        self.mirror = tk.BooleanVar(value=ed["mirror"])
        self.zoom = tk.DoubleVar(value=ed["zoom"])
        self.blur_strength = tk.IntVar(value=ed["blur_strength"])
        self.title_text = tk.StringVar(value=ed["title_text"])
        self.title_size = tk.IntVar(value=ed["title_size"])
        self.logo_enabled = tk.BooleanVar(value=ed["logo_enabled"])
        self.logo_path = tk.StringVar(value=ed["logo_path"])
        self.logo_width = tk.DoubleVar(value=ed["logo_width_frac"])
        self.logo_opacity = tk.DoubleVar(value=ed["logo_opacity"])
        self.extra_text = tk.StringVar(value=ed["extra_text"])
        self.extra_size = tk.IntVar(value=ed["extra_size"])
        self.extra_opacity = tk.DoubleVar(value=ed["extra_opacity"])
        self.subs_enabled = tk.BooleanVar(value=ed["subs_enabled"])
        self.mm_fonts = subtitles.installed_fonts(self.lang_code)
        self.subs_font = tk.StringVar(value=ed["subs_font"] if ed["subs_font"] in self.mm_fonts else self.mm_fonts[0])
        self.subs_size = tk.IntVar(value=ed["subs_size"])
        self.subs_style = tk.StringVar(value=ed["subs_style"])
        self.original_sound_percent = tk.StringVar(value=str(ed["original_sound_percent"]))
        self.original_sound_source = tk.StringVar(value="Background only (voices removed)" if ed["original_sound_source"] == "background" else "Original sound")
        self.volume = tk.DoubleVar(value=ed["volume"])
        self.blur_boxes: list[dict] = [dict(b) for b in ed["blur_boxes"]]
        self.title_pos = list(ed["title_pos"])
        self.logo_pos = list(ed["logo_pos"])
        self.extra_pos = list(ed["extra_pos"])
        self.subs_pos_y = float(ed["subs_pos_y"])
        self.ratio = tk.StringVar(value=ed["ratio"])
        self.fill_label = tk.StringVar(value=FILL_LABELS[ed["fill"]])
        self.frame_pos = list(ed["frame_pos"])
        self.selected_blur: int | None = None

        # preview state
        self.preview_src: Path | None = None
        self.preview_info: dict | None = None
        self.pw, self.ph = 338, 540
        self.frame_img: Image.Image | None = None
        self._composed: tuple[tuple, Image.Image] | None = None
        self.preview_time = tk.DoubleVar(value=0.0)
        self._photos: dict[str, ImageTk.PhotoImage] = {}
        self._text_cache: dict[tuple, Image.Image] = {}
        self._text_pending: set[tuple] = set()
        self._text_jobs: queue.Queue = queue.Queue()
        threading.Thread(target=self._text_render_loop, daemon=True).start()
        self._draw_mode = False
        self._drag: dict | None = None
        self._save_after: str | None = None

        self.status = tk.StringVar(value="READY")
        self.stage = tk.StringVar(value="Add videos or a folder, then START")

        self._theme()
        self._build()
        self._restore_queue()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(120, self._pump)

    # ------------------------------------------------------------------ theme / layout
    def _theme(self) -> None:
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure(".", background=BG, foreground=FG, font=("Segoe UI", 10))
        s.configure("TFrame", background=BG)
        s.configure("TLabel", background=BG, foreground=FG)
        s.configure("Muted.TLabel", background=BG, foreground=MUTED)
        s.configure("Status.TLabel", background=BG, foreground=SUCCESS, font=("Segoe UI Semibold", 10))
        s.configure("Head.TLabel", background=BG, foreground=FG, font=("Segoe UI Semibold", 10))
        s.configure("TLabelframe", background=BG, foreground=FG, bordercolor=BORDER, relief="solid")
        s.configure("TLabelframe.Label", background=BG, foreground=FG, font=("Segoe UI Semibold", 10))
        s.configure("TEntry", fieldbackground=FIELD, foreground=FG, insertcolor=FG, bordercolor=BORDER)
        s.configure("TSpinbox", fieldbackground=FIELD, foreground=FG, arrowcolor=FG, bordercolor=BORDER)
        s.configure("TCombobox", fieldbackground=FIELD, foreground=FG, background=PANEL, arrowcolor=FG, bordercolor=BORDER)
        s.map("TCombobox", fieldbackground=[("readonly", FIELD)], foreground=[("readonly", FG)])
        s.configure("TButton", background="#252b36", foreground=FG, bordercolor=BORDER, padding=(10, 5))
        s.map("TButton", background=[("active", "#333b49"), ("disabled", PANEL)], foreground=[("disabled", "#657080")])
        s.configure("Compact.TButton", background="#252b36", foreground=FG, bordercolor=BORDER, padding=(6, 2))
        s.map("Compact.TButton", background=[("active", "#333b49")])
        s.configure("Accent.TButton", background=ACCENT, foreground="#ffffff", bordercolor=ACCENT, padding=(14, 7), font=("Segoe UI Semibold", 10))
        s.map("Accent.TButton", background=[("active", ACCENT_HOVER), ("disabled", "#33445f")], foreground=[("disabled", "#8892a0")])
        s.configure("Danger.TButton", background="#4a252a", foreground="#ffd9dc", bordercolor="#6a3038", padding=(10, 6))
        s.map("Danger.TButton", background=[("active", "#653039"), ("disabled", PANEL)])
        s.configure("TCheckbutton", background=BG, foreground=FG)
        s.map("TCheckbutton", background=[("active", BG)])
        s.configure("Treeview", background=FIELD, fieldbackground=FIELD, foreground=FG, bordercolor=BORDER, rowheight=24)
        s.map("Treeview", background=[("selected", "#27406e")])
        s.configure("Treeview.Heading", background=PANEL, foreground=FG, bordercolor=BORDER)
        s.configure("Horizontal.TProgressbar", troughcolor=FIELD, background=ACCENT, bordercolor=FIELD)
        s.configure("TNotebook", background=BG, bordercolor=BORDER, tabmargins=(0, 0, 0, 0))
        s.configure("TNotebook.Tab", background=PANEL, foreground=MUTED, bordercolor=BORDER, padding=(12, 3))
        s.map("TNotebook.Tab", background=[("selected", "#27406e")], foreground=[("selected", "#ffffff")])
        s.configure("TRadiobutton", background=BG, foreground=FG)
        s.map("TRadiobutton", background=[("active", BG)])
        self.option_add("*TCombobox*Listbox.background", FIELD)
        self.option_add("*TCombobox*Listbox.foreground", FG)

    def _build(self) -> None:
        self.scroll_page = ScrollPage(self, background=BG)
        self.scroll_page.pack(fill="both", expand=True)
        outer = ttk.Frame(self.scroll_page.content, padding=12)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=3, minsize=440)
        outer.columnconfigure(1, weight=4)
        outer.columnconfigure(2, weight=2, minsize=330)
        outer.rowconfigure(1, weight=1)

        head = tk.Frame(outer, bg=BG)
        head.grid(row=0, column=0, columnspan=3, sticky="ew", pady=(0, 8))
        tk.Label(head, text="Storytelling Recap Studio", bg=BG, fg=FG, font=("Segoe UI Semibold", 18)).pack(side="left")
        language_hint = "Burmese + 14 languages" if languages.MULTILINGUAL_OUTPUT_ENABLED else "မြန်မာ"
        tk.Label(head, text=f"   Original video → storytelling recap ({language_hint})  |  Gemini timeline + V6.2 Smart Sync  |  "
                            "Edge TTS / VoxCPM  |  Flip · Zoom · 9:16 · Blur · Title · Logo",
                 bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(side="left", pady=(6, 0))

        left = ttk.Frame(outer)
        left.grid(row=1, column=0, sticky="nsew", padx=(0, 8))
        left.rowconfigure(0, weight=1)
        left.columnconfigure(0, weight=1)
        self._build_queue(left)
        self._build_settings(left)

        self._build_preview(outer)
        self._build_tools(outer)

        # Main log + one tab per VoxCPM Colab link (created when a link is used), like VoxCPM V2.
        self.log_notebook = ttk.Notebook(outer)
        self.log_notebook.grid(row=2, column=0, columnspan=3, sticky="nsew", pady=(8, 6))
        self.logbox = self._create_log_tab("Log")

        controls = ttk.Frame(outer)
        controls.grid(row=3, column=0, columnspan=3, sticky="ew")
        controls.columnconfigure(0, weight=1)
        row = ttk.Frame(controls)
        row.grid(row=0, column=0, sticky="ew")
        self.start_btn = ttk.Button(row, text="▶  START ALL", style="Accent.TButton", command=self._start)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(row, text="■  STOP", style="Danger.TButton", command=self._stop, state="disabled")
        self.stop_btn.pack(side="left", padx=8)
        self.reapply_btn = ttk.Button(row, text="✨ Re-apply Effects (finished files)", command=self._reapply_effects)
        self.reapply_btn.pack(side="left")
        self.folder_btn = ttk.Button(row, text="📂 FINALS Folder", command=self._open_output)
        self.folder_btn.pack(side="left", padx=8)
        self.play_btn = ttk.Button(row, text="▶ Play Selected Final", command=self._play_selected)
        self.play_btn.pack(side="left")
        self._update_output_hint()      # the two buttons above follow Make: Video / Script only
        ttk.Label(row, textvariable=self.status, style="Status.TLabel").pack(side="right")
        ttk.Label(row, textvariable=self.stage, style="Muted.TLabel").pack(side="right", padx=(0, 14))
        bars = ttk.Frame(controls)
        bars.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        bars.columnconfigure(1, weight=1)
        bars.columnconfigure(3, weight=1)
        ttk.Label(bars, text="File", style="Muted.TLabel").grid(row=0, column=0, padx=(0, 6))
        self.file_bar = ttk.Progressbar(bars, mode="determinate", maximum=1000)
        self.file_bar.grid(row=0, column=1, sticky="ew", padx=(0, 14))
        ttk.Label(bars, text="All", style="Muted.TLabel").grid(row=0, column=2, padx=(0, 6))
        self.all_bar = ttk.Progressbar(bars, mode="determinate", maximum=1000)
        self.all_bar.grid(row=0, column=3, sticky="ew")

    def _create_log_tab(self, title: str) -> tk.Text:
        frame = ttk.Frame(self.log_notebook, padding=2)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        box = tk.Text(frame, height=8, bg=FIELD, fg=FG, insertbackground=FG, relief="flat",
                      font=("Consolas", 9), wrap="none")
        box.grid(row=0, column=0, sticky="nsew")
        sb = ttk.Scrollbar(frame, orient="vertical", command=box.yview)
        sb.grid(row=0, column=1, sticky="ns")
        box.configure(yscrollcommand=sb.set)
        self.log_notebook.add(frame, text=title)
        return box

    def _link_log(self, n: int, text: str) -> None:
        box = self.link_logboxes.get(n)
        if box is None:
            box = self.link_logboxes[n] = self._create_log_tab(f"Link {n}")
        box.insert("end", f"[{datetime.now():%H:%M:%S}] {text}\n")
        if int(box.index("end-1c").split(".")[0]) > 3000:
            box.delete("1.0", "1000.0")
        box.see("end")

    def _build_queue(self, parent: ttk.Frame) -> None:
        box = ttk.LabelFrame(parent, text="Batch Queue — one output folder per file", padding=6)
        box.grid(row=0, column=0, sticky="nsew")
        box.rowconfigure(1, weight=1)
        box.columnconfigure(0, weight=1)
        btns = ttk.Frame(box)
        btns.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        ttk.Button(btns, text="+ Files", style="Compact.TButton", command=self._add_files).pack(side="left")
        ttk.Button(btns, text="+ Folder", style="Compact.TButton", command=self._add_folder).pack(side="left", padx=5)
        ttk.Button(btns, text="+ Link", style="Compact.TButton", command=self._add_links).pack(side="left", padx=(0, 5))
        ttk.Button(btns, text="Remove", style="Compact.TButton", command=self._remove_selected).pack(side="left")
        ttk.Button(btns, text="Clear", style="Compact.TButton", command=self._clear_queue).pack(side="left", padx=5)
        ttk.Button(btns, text="Reset Status", style="Compact.TButton", command=self._reset_selected).pack(side="left")
        self.script_btn = ttk.Button(btns, text="📜 Script", style="Compact.TButton",
                                     command=self._edit_script, state="disabled")
        self.script_btn.pack(side="left", padx=4)
        self.tree = ttk.Treeview(box, columns=("name", "length", "status"), show="headings", selectmode="extended", height=9)
        self.tree.heading("name", text="Video")
        self.tree.heading("length", text="Length")
        self.tree.heading("status", text="Status")
        self.tree.column("name", width=250, anchor="w")
        self.tree.column("length", width=62, anchor="center", stretch=False)
        self.tree.column("status", width=96, anchor="center", stretch=False)
        self.tree.grid(row=1, column=0, sticky="nsew")
        tsb = ttk.Scrollbar(box, orient="vertical", command=self.tree.yview)
        tsb.grid(row=1, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=tsb.set)
        self.tree.tag_configure("done", foreground=SUCCESS)
        self.tree.tag_configure("failed", foreground=DANGER)
        self.tree.tag_configure("running", foreground=WARN)
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self._on_select())
        self.tree.bind("<Double-1>", lambda _e: self._play_selected())

        out = ttk.Frame(box)
        out.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        out.columnconfigure(1, weight=1)
        ttk.Label(out, text="Output").grid(row=0, column=0, padx=(0, 6))
        ttk.Entry(out, textvariable=self.output_root).grid(row=0, column=1, sticky="ew")
        ttk.Button(out, text="Browse", style="Compact.TButton", command=self._browse_output).grid(row=0, column=2, padx=(6, 0))
        make = ttk.Frame(box)
        make.grid(row=3, column=0, columnspan=2, sticky="w", pady=(4, 0))
        ttk.Label(make, text="Make").pack(side="left")
        for key, label in (("video", "Auto (voice + video)"), ("script", "Script Review (📜 check first)")):
            ttk.Radiobutton(make, text=label, value=key, variable=self.output_mode,
                            command=self._output_mode_changed).pack(side="left", padx=(8, 0))
        self.output_hint = ttk.Label(box, style="Muted.TLabel")
        self.output_hint.grid(row=4, column=0, columnspan=2, sticky="w", pady=(3, 0))
        self._update_output_hint()

    def _build_settings(self, parent: ttk.Frame) -> None:
        box = ttk.LabelFrame(parent, text="Engine Settings", padding=6)
        box.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        box.columnconfigure(1, weight=1)
        ttk.Label(box, text="Gemini .env").grid(row=0, column=0, sticky="w", pady=2)
        ttk.Entry(box, textvariable=self.env_path).grid(row=0, column=1, sticky="ew", pady=2)
        ttk.Button(box, text="Browse", style="Compact.TButton", command=self._browse_env).grid(row=0, column=2, padx=(6, 0))
        ttk.Label(box, text="Proxy").grid(row=1, column=0, sticky="w", pady=2)
        ttk.Label(box, text="System network / external VPN").grid(row=1, column=1, columnspan=2, sticky="ew", pady=2)
        ttk.Label(box, text="Models").grid(row=2, column=0, sticky="w", pady=2)
        ttk.Entry(box, textvariable=self.models).grid(row=2, column=1, columnspan=2, sticky="ew", pady=2)
        ttk.Label(box, text="Language").grid(row=3, column=0, sticky="w", pady=2)
        lc = ttk.Combobox(box, textvariable=self.language, state="readonly",
                          values=[languages.display(c) for c in languages.enabled_codes()])
        self.language_combo = lc
        lc.grid(row=3, column=1, columnspan=2, sticky="ew", pady=2)
        lc.bind("<<ComboboxSelected>>", lambda _e: self._language_changed())
        row = ttk.Frame(box)
        row.grid(row=4, column=0, columnspan=3, sticky="ew", pady=2)
        ttk.Label(row, text="Timeout (s)").pack(side="left")
        ttk.Spinbox(row, from_=60, to=600, increment=30, textvariable=self.timeout_sec, width=6).pack(side="left", padx=(6, 16))
        ttk.Label(row, text="TTS").pack(side="left")
        for key, label in PROVIDERS.items():
            ttk.Radiobutton(row, text=label, value=key, variable=self.tts_provider,
                            command=self._provider_changed).pack(side="left", padx=(8, 0))
        holder = ttk.Frame(box)
        holder.grid(row=5, column=0, columnspan=3, sticky="ew", pady=2)
        nrow = ttk.Frame(holder)
        nrow.pack(fill="x")
        ttk.Label(nrow, text="Narration").pack(side="left")
        for key, label in (("classic", "Classic (one TTS per line)"), ("flow", "Flow (smooth, one voice-over)")):
            ttk.Radiobutton(nrow, text=label, value=key, variable=self.narration_style,
                            command=self._persist_soon).pack(side="left", padx=(8, 0))
        # Classic + Edge: each line's own TTS silence (0.85 s) cut to a 0.25 s pause, ~8% shorter (A/B "B")
        ttk.Checkbutton(nrow, text="Short pauses", variable=self.short_pauses,
                        command=self._persist_soon).pack(side="left", padx=(12, 0))
        # Length on its own line (2026-10-25): beside Narration the Recap number and unit were cut off
        lrow = ttk.Frame(holder)
        lrow.pack(fill="x", pady=(4, 0))
        ttk.Label(lrow, text="Length").pack(side="left")
        length_pick = ttk.Combobox(lrow, textvariable=self.story_length, state="readonly", width=36,
                                   values=list(STORY_LENGTH_LABELS.values()))
        length_pick.pack(side="left", padx=(6, 0))
        length_pick.bind("<<ComboboxSelected>>", lambda _e: self._persist_soon())
        ttk.Label(lrow, text="Recap").pack(side="left", padx=(12, 0))
        ttk.Spinbox(lrow, from_=1, to=600, textvariable=self.recap_minutes, width=4,
                    command=self._persist_soon).pack(side="left", padx=(6, 0))
        unit_pick = ttk.Combobox(lrow, textvariable=self.recap_unit, state="readonly", width=10,
                                 values=list(RECAP_UNITS.values()))
        unit_pick.pack(side="left", padx=(4, 0))
        unit_pick.bind("<<ComboboxSelected>>", lambda _e: self._persist_soon())
        ttk.Label(lrow, text="(never longer than the video)", style="Muted.TLabel").pack(side="left", padx=(6, 0))

        # Edge TTS: voice + speed + test (unchanged)
        self.edge_frame = edge = ttk.Frame(box)
        edge.grid(row=6, column=0, columnspan=3, sticky="ew", pady=2)
        edge.columnconfigure(1, weight=1)
        ttk.Label(edge, text="Voice").grid(row=0, column=0, sticky="w")
        self.voice_combo = ttk.Combobox(edge, textvariable=self.voice, values=languages.get(self.lang_code)["voices"],
                                        state="readonly", width=30)
        self.voice_combo.grid(row=0, column=1, sticky="w", padx=6, pady=(0, 2))
        ttk.Label(edge, text="Edge TTS speed").grid(row=1, column=0, sticky="w")
        ttk.Scale(edge, from_=-50, to=100, orient="horizontal", variable=self.tts_rate).grid(row=1, column=1, sticky="ew", padx=6)
        self.tts_rate_label = ttk.Label(edge, text=f"{self.tts_rate.get():+d}%", width=6)
        self.tts_rate_label.grid(row=1, column=2)
        self.tts_rate.trace_add("write", lambda *_a: self.tts_rate_label.configure(text=f"{self._int(self.tts_rate, 25):+d}%"))
        self.test_voice_btn = ttk.Button(edge, text="▶ Test", style="Compact.TButton", command=self._test_voice)
        self.test_voice_btn.grid(row=1, column=3, padx=(6, 0))
        ttk.Label(edge, text="နှေး ← → မြန်   (changing voice/speed: START re-voices finished files; Gemini is reused)",
                  style="Muted.TLabel").grid(row=2, column=0, columnspan=4, sticky="w")

        # VoxCPM on Colab: one row per link (Gradio / LocalTunnel), like VoxCPM V2
        self.vox_frame = vox = ttk.Frame(box)
        vox.grid(row=7, column=0, columnspan=3, sticky="ew", pady=2)
        vox.columnconfigure(0, weight=1)
        head = ttk.Frame(vox)
        head.grid(row=0, column=0, sticky="ew")
        ttk.Label(head, text="Colab links", style="Head.TLabel").pack(side="left")
        ttk.Button(head, text="+ Add Link", style="Compact.TButton", command=self._add_vox_row).pack(side="right")
        self.vox_rows_frame = ttk.Frame(vox)
        self.vox_rows_frame.grid(row=1, column=0, sticky="ew", pady=(2, 0))
        self.vox_rows_frame.columnconfigure(2, weight=1)
        ttk.Label(vox, textvariable=self.vox_need, style="Muted.TLabel").grid(row=2, column=0, sticky="w")
        vr = ttk.Frame(vox)
        vr.grid(row=3, column=0, sticky="ew", pady=(4, 0))
        vr.columnconfigure(1, weight=1)
        ttk.Label(vr, text="Voice").grid(row=0, column=0, sticky="w")
        saved_voice = self.vox_voice.get()
        self.vox_voice_combo = ttk.Combobox(vr, textvariable=self.vox_voice, values=[saved_voice] if saved_voice else [],
                                            state="readonly")
        self.vox_voice_combo.grid(row=0, column=1, sticky="ew", padx=6, pady=(0, 2))
        self.vox_voice_combo.bind("<<ComboboxSelected>>", lambda _e: self._persist_soon())
        ttk.Button(vr, text="↻ Reload", style="Compact.TButton",
                   command=lambda: self._test_vox_row(self._first_vox_row())).grid(row=0, column=2, columnspan=2, sticky="w")
        ttk.Label(vr, text="VoxCPM speed").grid(row=1, column=0, sticky="w")
        ttk.Scale(vr, from_=-30, to=60, orient="horizontal", variable=self.vox_rate,
                  command=lambda _v: self._persist_soon()).grid(row=1, column=1, sticky="ew", padx=6)
        self.vox_rate_label = ttk.Label(vr, text=f"{self._int(self.vox_rate, 0):+d}%", width=6)
        self.vox_rate_label.grid(row=1, column=2)
        self.vox_rate.trace_add("write", lambda *_a: self.vox_rate_label.configure(text=f"{self._int(self.vox_rate, 0):+d}%"))
        self.vox_test_btn = ttk.Button(vr, text="▶ Test", style="Compact.TButton", command=self._test_voice)
        self.vox_test_btn.grid(row=1, column=3, padx=(6, 0))
        ttk.Label(vr, text="Test a link to load its voices. All links share the blocks; a failed link's work "
                           "moves to the others. Replace a dead link any time — the next resume uses it.",
                  style="Muted.TLabel", wraplength=430).grid(row=2, column=0, columnspan=4, sticky="w")
        for link in self.cfg.get("voxcpm_links") or [{}]:
            if isinstance(link, dict):
                self._add_vox_row(str(link.get("url") or ""), str(link.get("type") or ""), persist=False)
        if not self.vox_rows:
            self._add_vox_row(persist=False)

        ttk.Checkbutton(box, text="Same series — the next file keeps the characters, names and story so far",
                        variable=self.share_registry).grid(row=8, column=0, columnspan=3, sticky="w")
        ttk.Checkbutton(box, text="Skip files that are already finished (FINALS video / SCRIPTS text)",
                        variable=self.skip_finished).grid(row=9, column=0, columnspan=3, sticky="w")
        ttk.Checkbutton(box, text="Whisper timing check — ask Gemini again where the dialogue times are off (GPU, ~5 min/hour)",
                        variable=self.whisper_check, command=self._persist_soon).grid(row=10, column=0, columnspan=3, sticky="w")
        # Slowed blocks get RIFE in-between frames instead of one frame repeated (2026-10-10);
        # "under 0.5x" = only the slowest blocks, for long videos (2026-10-11)
        smooth_row = ttk.Frame(box)
        smooth_row.grid(row=11, column=0, columnspan=3, sticky="w")
        ttk.Checkbutton(smooth_row, text="Smooth slow motion — AI in-between frames (GPU, slower render) for blocks",
                        variable=self.smooth_motion, command=self._persist_soon).pack(side="left")
        smooth_pick = ttk.Combobox(smooth_row, textvariable=self.smooth_below, state="readonly", width=24,
                                   values=list(SMOOTH_BELOW_LABELS.values()))
        smooth_pick.pack(side="left", padx=(6, 0))
        smooth_pick.bind("<<ComboboxSelected>>", lambda _e: self._persist_soon())
        style_row = ttk.Frame(box)
        style_row.grid(row=12, column=0, columnspan=3, sticky="w", pady=(2, 0))
        ttk.Label(style_row, text="Telling style").pack(side="left")
        style_pick = ttk.Combobox(style_row, textvariable=self.story_style, state="readonly", width=28,
                                  values=list(TELLING_STYLE_LABELS.values()))
        style_pick.pack(side="left", padx=(6, 0))
        style_pick.bind("<<ComboboxSelected>>", lambda _e: self._persist_soon())
        ttk.Button(style_row, text="✎ Notes, sample & preview", style="Compact.TButton",
                   command=self._style_dialog).pack(side="left", padx=(8, 0))
        ttk.Checkbutton(box, text="AI ဆီ 2× ပို့မယ် (experimental — timing check uses original sound)",
                        variable=self.analysis_2x, command=self._persist_soon).grid(row=13, column=0, columnspan=3, sticky="w")
        slow_row = ttk.Frame(box)
        slow_row.grid(row=14, column=0, columnspan=3, sticky="w", pady=2)
        ttk.Label(slow_row, text="Slow parts").pack(side="left")
        slow_pick = ttk.Combobox(slow_row, textvariable=self.slow_style, state="readonly", width=31,
            values=("AI in-between frames (as now)", "Freeze + zoom", "Mix (freeze + RIFE)"))
        slow_pick.pack(side="left", padx=6)
        slow_pick.bind("<<ComboboxSelected>>", lambda _e: self._persist_soon())
        ttk.Label(slow_row, text="Freeze below").pack(side="left")
        ttk.Spinbox(slow_row, from_=0.1, to=1.0, increment=0.1, textvariable=self.freeze_below, width=5,
                    command=self._persist_soon).pack(side="left", padx=4)
        self._provider_changed(persist=False)

    def _build_preview(self, parent: ttk.Frame) -> None:
        box = ttk.LabelFrame(parent, text="Preview — drag Title / Logo / Text, draw Blur boxes", padding=6)
        box.grid(row=1, column=1, sticky="nsew", padx=(0, 8))
        box.columnconfigure(0, weight=1)
        box.rowconfigure(0, weight=1)
        holder = tk.Frame(box, bg=BG, width=PREVIEW_MAX_W + 4, height=PREVIEW_MAX_H + 4)
        holder.grid(row=0, column=0, sticky="nsew")
        self.canvas = tk.Canvas(holder, width=self.pw, height=self.ph, bg="#05070a", highlightthickness=1,
                                highlightbackground=BORDER, cursor="arrow")
        self.canvas.place(relx=0.5, rely=0.5, anchor="center")
        self.canvas.bind("<ButtonPress-1>", self._press)
        self.canvas.bind("<B1-Motion>", self._motion)
        self.canvas.bind("<ButtonRelease-1>", self._release)
        self.canvas.bind("<Motion>", self._hover)
        self.canvas.bind("<Delete>", lambda _e: self._delete_blur())
        seek = ttk.Frame(box)
        seek.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        seek.columnconfigure(0, weight=1)
        self.seek = ttk.Scale(seek, from_=0.0, to=1.0, orient="horizontal", variable=self.preview_time,
                              command=lambda _v: self.seek_label.configure(text=self._fmt_time(self.preview_time.get())))
        self.seek.grid(row=0, column=0, sticky="ew")
        self.seek.bind("<ButtonRelease-1>", lambda _e: self._load_frame())
        self.seek_label = ttk.Label(seek, text="00:00", width=7)
        self.seek_label.grid(row=0, column=1, padx=6)
        ttk.Button(seek, text="Refresh", style="Compact.TButton", command=self._load_frame).grid(row=0, column=2)
        self.preview_note = ttk.Label(box, text="Select a video in the queue to preview it.", style="Muted.TLabel")
        self.preview_note.grid(row=2, column=0, sticky="w", pady=(4, 0))

    def _build_tools(self, parent: ttk.Frame) -> None:
        host = ttk.LabelFrame(parent, text="Production Tools (applied to every file)", padding=3)
        host.grid(row=1, column=2, sticky="nsew")
        host.rowconfigure(0, weight=1)
        host.columnconfigure(0, weight=1)
        cv = tk.Canvas(host, bg=BG, highlightthickness=0, width=320)
        cv.grid(row=0, column=0, sticky="nsew")
        vs = ttk.Scrollbar(host, orient="vertical", command=cv.yview)
        vs.grid(row=0, column=1, sticky="ns")
        cv.configure(yscrollcommand=vs.set)
        t = ttk.Frame(cv, padding=8)
        win = cv.create_window((0, 0), window=t, anchor="nw")
        t.bind("<Configure>", lambda _e: cv.configure(scrollregion=cv.bbox("all")))
        cv.bind("<Configure>", lambda e: cv.itemconfigure(win, width=e.width))
        self.production_canvas = cv  # ScrollPage routes the wheel to this panel before the whole page.
        t.columnconfigure(0, weight=1)
        r = 0

        def sep() -> None:
            nonlocal r
            ttk.Separator(t).grid(row=r, column=0, sticky="ew", pady=8)
            r += 1

        def slider(var, lo, hi, fmt, on_change) -> ttk.Label:
            nonlocal r
            fr = ttk.Frame(t)
            fr.grid(row=r, column=0, sticky="ew", pady=(2, 2))
            fr.columnconfigure(0, weight=1)
            lab = ttk.Label(fr, text=fmt(var.get()), width=7)
            var.trace_add("write", lambda *_a: lab.configure(text=fmt(var.get())))
            ttk.Scale(fr, from_=lo, to=hi, orient="horizontal", variable=var,
                      command=lambda _v: on_change()).grid(row=0, column=0, sticky="ew")
            lab.grid(row=0, column=1, padx=(6, 0))
            r += 1
            return lab

        ttk.Label(t, text="Picture", style="Head.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        ttk.Checkbutton(t, text="Flip (mirror left ↔ right)", variable=self.mirror, command=self._editor_changed).grid(row=r, column=0, sticky="w", pady=2); r += 1
        ttk.Label(t, text="Zoom (crop edges)", style="Muted.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        slider(self.zoom, 1.0, effects.ZOOM_MAX, lambda v: f"{float(v):.2f}x", self._editor_changed)
        ttk.Label(t, text="Output ratio", style="Muted.TLabel").grid(row=r, column=0, sticky="w", pady=(6, 0)); r += 1
        rr = ttk.Frame(t)
        rr.grid(row=r, column=0, sticky="ew", pady=(2, 2)); r += 1
        rc = ttk.Combobox(rr, textvariable=self.ratio, values=effects.OUTPUT_RATIOS, state="readonly", width=9)
        rc.pack(side="left")
        rc.bind("<<ComboboxSelected>>", lambda _e: self._ratio_changed())
        self.fill_combo = ttk.Combobox(rr, textvariable=self.fill_label, values=list(FILL_LABELS.values()),
                                       state="readonly", width=18)
        self.fill_combo.pack(side="left", padx=(6, 0))
        self.fill_combo.bind("<<ComboboxSelected>>", lambda _e: self._ratio_changed())
        self.center_btn = ttk.Button(t, text="Center picture", style="Compact.TButton", command=self._center_picture)
        self.center_btn.grid(row=r, column=0, sticky="w", pady=(2, 2)); r += 1
        ttk.Label(t, text="9:16 = 1080x1920 for Reels / TikTok. Drag the picture on the preview to move it "
                          "up/down (left/right with Crop). Original keeps the source shape.",
                  style="Muted.TLabel", wraplength=290).grid(row=r, column=0, sticky="w"); r += 1
        sep()

        ttk.Label(t, text="Blur (hide source watermark / subtitles)", style="Head.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        br = ttk.Frame(t)
        br.grid(row=r, column=0, sticky="ew", pady=(4, 2)); r += 1
        ttk.Button(br, text="+ Draw Blur Box", style="Compact.TButton", command=self._begin_blur).pack(side="left")
        ttk.Button(br, text="Delete", style="Compact.TButton", command=self._delete_blur).pack(side="left", padx=6)
        self.blur_count = ttk.Label(br, text="0 box", style="Muted.TLabel")
        self.blur_count.pack(side="left")
        ttk.Label(t, text="Blur strength", style="Muted.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        slider(self.blur_strength, 2, 40, lambda v: f"{int(float(v))}", self._editor_changed)
        ttk.Label(t, text="Drag inside a box to move it, drag its corner square to resize, Delete key removes the "
                          "selected box. Boxes stick to the source content, even with Flip/Zoom.",
                  style="Muted.TLabel", wraplength=290).grid(row=r, column=0, sticky="w"); r += 1
        sep()

        ttk.Label(t, text="Title", style="Head.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        te = ttk.Entry(t, textvariable=self.title_text)
        te.grid(row=r, column=0, sticky="ew", pady=(4, 2)); r += 1
        te.bind("<KeyRelease>", lambda _e: self._editor_changed())
        tr = ttk.Frame(t)
        tr.grid(row=r, column=0, sticky="ew"); r += 1
        ttk.Label(tr, text="Size").pack(side="left")
        ts = ttk.Spinbox(tr, from_=18, to=140, textvariable=self.title_size, width=6, command=self._editor_changed)
        ts.pack(side="left", padx=6)
        ts.bind("<KeyRelease>", lambda _e: self._editor_changed())
        ttk.Label(tr, text="drag on preview", style="Muted.TLabel").pack(side="left")
        sep()

        lh = ttk.Frame(t)
        lh.grid(row=r, column=0, sticky="ew"); r += 1
        lh.columnconfigure(0, weight=1)
        ttk.Label(lh, text="Logo / Watermark", style="Head.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(lh, text="On", variable=self.logo_enabled, command=self._editor_changed).grid(row=0, column=1)
        lr = ttk.Frame(t)
        lr.grid(row=r, column=0, sticky="ew", pady=(4, 2)); r += 1
        lr.columnconfigure(0, weight=1)
        ttk.Entry(lr, textvariable=self.logo_path).grid(row=0, column=0, sticky="ew")
        ttk.Button(lr, text="Browse", style="Compact.TButton", command=self._browse_logo).grid(row=0, column=1, padx=(6, 0))
        ttk.Label(t, text="Size", style="Muted.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        slider(self.logo_width, 0.04, 0.60, lambda v: f"{float(v) * 100:.0f}%", self._editor_changed)
        ttk.Label(t, text="Opacity", style="Muted.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        slider(self.logo_opacity, 0.05, 1.0, lambda v: f"{float(v) * 100:.0f}%", self._editor_changed)
        sep()

        ttk.Label(t, text="Extra Text", style="Head.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        ee = ttk.Entry(t, textvariable=self.extra_text)
        ee.grid(row=r, column=0, sticky="ew", pady=(4, 2)); r += 1
        ee.bind("<KeyRelease>", lambda _e: self._editor_changed())
        er = ttk.Frame(t)
        er.grid(row=r, column=0, sticky="ew"); r += 1
        ttk.Label(er, text="Size").pack(side="left")
        es = ttk.Spinbox(er, from_=14, to=120, textvariable=self.extra_size, width=6, command=self._editor_changed)
        es.pack(side="left", padx=6)
        es.bind("<KeyRelease>", lambda _e: self._editor_changed())
        ttk.Label(t, text="Opacity", style="Muted.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        slider(self.extra_opacity, 0.05, 1.0, lambda v: f"{float(v) * 100:.0f}%", self._editor_changed)
        sep()

        sh = ttk.Frame(t)
        sh.grid(row=r, column=0, sticky="ew"); r += 1
        sh.columnconfigure(0, weight=1)
        ttk.Label(sh, text="Subtitles (narration)", style="Head.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(sh, text="On", variable=self.subs_enabled, command=self._editor_changed).grid(row=0, column=1)
        sf = ttk.Frame(t)
        sf.grid(row=r, column=0, sticky="ew", pady=(4, 2)); r += 1
        sf.columnconfigure(1, weight=1)
        ttk.Label(sf, text="Font").grid(row=0, column=0, sticky="w")
        self.font_combo = fc = ttk.Combobox(sf, textvariable=self.subs_font, values=self.mm_fonts, state="readonly", width=18)
        fc.grid(row=0, column=1, sticky="ew", padx=(6, 0))
        fc.bind("<<ComboboxSelected>>", lambda _e: self._editor_changed())
        ss = ttk.Frame(t)
        ss.grid(row=r, column=0, sticky="ew", pady=2); r += 1
        ttk.Label(ss, text="Size (1080p)").pack(side="left")
        sp = ttk.Spinbox(ss, from_=24, to=160, increment=2, textvariable=self.subs_size, width=6, command=self._editor_changed)
        sp.pack(side="left", padx=6)
        sp.bind("<KeyRelease>", lambda _e: self._editor_changed())
        ttk.Label(ss, text="Style").pack(side="left", padx=(8, 0))
        stc = ttk.Combobox(ss, textvariable=self.subs_style, values=("box", "outline"), state="readonly", width=8)
        stc.pack(side="left", padx=6)
        stc.bind("<<ComboboxSelected>>", lambda _e: self._editor_changed())
        ttk.Label(t, text="Timed to the narration word by word (Edge TTS timing). Drag it up/down on the preview. "
                          "An .srt copy is saved in FINALS/SRT_for_upload (not next to the video, so players do not show it twice).",
                  style="Muted.TLabel", wraplength=290).grid(row=r, column=0, sticky="w"); r += 1
        sep()

        ttk.Label(t, text="Audio", style="Head.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        ttk.Label(t, text="Narration volume (100% = unchanged)", style="Muted.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        slider(self.volume, 0.3, 2.5, lambda v: f"{float(v) * 100:.0f}%", self._persist_soon)
        ttk.Label(t, text="မူရင်းအသံ (%)").grid(row=r, column=0, sticky="w"); r += 1
        sound = ttk.Combobox(t, textvariable=self.original_sound_percent, values=("0", "8", "12", "20"), state="readonly", width=8)
        sound.grid(row=r, column=0, sticky="w"); r += 1
        sound.bind("<<ComboboxSelected>>", lambda _e: self._persist_soon())
        source_pick = ttk.Combobox(t, textvariable=self.original_sound_source,
            values=("Original sound", "Background only (voices removed)"), state="readonly", width=31)
        source_pick.grid(row=r, column=0, sticky="w", pady=3); r += 1
        source_pick.bind("<<ComboboxSelected>>", lambda _e: self._persist_soon())
        ttk.Label(t, text="အသံ % ပြောင်းရင် Re-apply Effects နှိပ်ပါ။", style="Muted.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        sep()

        ttk.Label(t, text="Encoder", style="Head.TLabel").grid(row=r, column=0, sticky="w"); r += 1
        ttk.Combobox(t, textvariable=self.encoder, values=("auto", "h264_nvenc", "libx264"), state="readonly", width=14).grid(row=r, column=0, sticky="w", pady=(4, 2)); r += 1
        ttk.Label(t, text="Effects are one extra pass over the finished video; the narration audio is copied untouched.",
                  style="Muted.TLabel", wraplength=290).grid(row=r, column=0, sticky="w", pady=(4, 0)); r += 1
        self._ratio_controls_state()

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _fmt_time(seconds: float) -> str:
        s = max(0, int(seconds))
        return f"{s // 60:02d}:{s % 60:02d}"

    def _log(self, text: str) -> None:
        self.msgq.put(("log", str(text)))

    def _append_log(self, text: str) -> None:
        stamp = datetime.now().strftime("%H:%M:%S")
        self.logbox.insert("end", f"[{stamp}] {text}\n")
        if int(self.logbox.index("end-1c").split(".")[0]) > 4000:
            self.logbox.delete("1.0", "1000.0")
        self.logbox.see("end")
        try:
            with (LOGS_DIR / "latest.log").open("a", encoding="utf-8") as f:
                f.write(f"[{stamp}] {text}\n")
        except Exception:
            pass

    def _editor(self) -> dict:
        return effects.normalized_editor({
            "mirror": self.mirror.get(),
            "zoom": self.zoom.get(),
            "blur_boxes": self.blur_boxes,
            "blur_strength": self.blur_strength.get(),
            "title_text": self.title_text.get(),
            "title_size": self._int(self.title_size, 54),
            "title_pos": self.title_pos,
            "logo_enabled": self.logo_enabled.get(),
            "logo_path": self.logo_path.get(),
            "logo_width_frac": self.logo_width.get(),
            "logo_opacity": self.logo_opacity.get(),
            "logo_pos": self.logo_pos,
            "extra_text": self.extra_text.get(),
            "extra_size": self._int(self.extra_size, 42),
            "extra_opacity": self.extra_opacity.get(),
            "extra_pos": self.extra_pos,
            "subs_enabled": self.subs_enabled.get(),
            "subs_font": self.subs_font.get(),
            "subs_size": self._int(self.subs_size, 76),
            "subs_style": self.subs_style.get(),
            "subs_pos_y": self.subs_pos_y,
            "original_sound_percent": self._int(self.original_sound_percent, 0),
            "original_sound_source": "background" if self.original_sound_source.get().startswith("Background") else "original",
            "volume": self.volume.get(),
            "ratio": self.ratio.get(),
            "fill": next((k for k, v in FILL_LABELS.items() if v == self.fill_label.get()), "blur"),
            "frame_pos": self.frame_pos,
        })

    @staticmethod
    def _int(var: tk.Variable, default: int) -> int:
        try:
            return int(var.get())
        except Exception:
            return default

    def _settings(self) -> dict:
        settings = {
            "gemini_env_path": self.env_path.get().strip(),
            "proxy": self.proxy.get().strip(),
            "gemini_models": self.models.get().strip() or DEFAULT_MODELS,
            "gemini_timeout_sec": max(30, self._int(self.timeout_sec, 180)),
            "tts_voice": self.voice.get().strip() or languages.get(self.lang_code)["voices"][0],
            "tts_rate_percent": int(round(float(self.tts_rate.get()))),
            "language": self.lang_code,
            "narration_style": self.narration_style.get() if self.narration_style.get() in ("classic", "flow") else "classic",
            "analysis_speed": 2 if self.analysis_2x.get() else 1,
            "slow_style": {"Freeze + zoom": "freeze", "Mix (freeze + RIFE)": "mix"}.get(self.slow_style.get(), "rife"),
            "freeze_below": max(0.1, min(1.0, float(self.freeze_below.get()))),
            "recap_unit": next((k for k, v in RECAP_UNITS.items() if v == self.recap_unit.get()), "min"),
            "recap_minutes": max(1, min(100 if self.recap_unit.get() == RECAP_UNITS["percent"] else 600,
                                        self._int(self.recap_minutes, 12))),
            "story_length": next((k for k, v in STORY_LENGTH_LABELS.items() if v == self.story_length.get()), "full"),
            "story_style": next((k for k, v in TELLING_STYLE_LABELS.items() if v == self.story_style.get()), "default"),
            "story_style_notes": self.style_notes,
            "story_style_sample": self.style_sample,
            "tts_provider": self.tts_provider.get() if self.tts_provider.get() in PROVIDERS else "edge",
            "voxcpm_links": [{"url": r["url"].get().strip(), "type": r["type"].get()} for r in self.vox_rows],
            "voxcpm_voice": self.vox_voice.get().strip(),
            "voxcpm_rate_percent": self._int(self.vox_rate, 0),
            "output_root": self.output_root.get().strip(),
            "share_registry": bool(self.share_registry.get()),
            "skip_finished": bool(self.skip_finished.get()),
            "whisper_check": bool(self.whisper_check.get()),
            "short_pauses": bool(self.short_pauses.get()),
            "smooth_motion": bool(self.smooth_motion.get()),
            "smooth_below": next((k for k, v in SMOOTH_BELOW_LABELS.items() if v == self.smooth_below.get()), 0.9),
            "output_mode": self.output_mode.get() if self.output_mode.get() in ("video", "script") else "video",
            "encoder": self.encoder.get() or "libx264",
        }
        return languages.restrict_output(settings)

    def _persist(self) -> None:
        self._save_after = None
        self.cfg.update(self._settings())
        self.cfg["editor"] = self._editor()
        self.cfg["queue"] = [it.get("url") or str(it["path"]) for it in self._ordered_items()]
        try:
            save_config(self.cfg)
        except Exception as exc:
            self._append_log(f"⚠️ Could not save config.json: {exc}")

    def _persist_soon(self) -> None:
        if self._save_after:
            self.after_cancel(self._save_after)
        self._save_after = self.after(700, self._persist)

    def _editor_changed(self) -> None:
        self._redraw()
        self._persist_soon()

    # ------------------------------------------------------------------ output ratio
    def _ratio_controls_state(self) -> None:
        vertical = self.ratio.get() == "9:16"
        self.fill_combo.configure(state="readonly" if vertical else "disabled")
        self.center_btn.configure(state="normal" if vertical else "disabled")

    def _ratio_changed(self) -> None:
        self._ratio_controls_state()
        self._layout_preview()
        self._editor_changed()

    def _center_picture(self) -> None:
        self.frame_pos = [0.5, 0.5]
        self._editor_changed()

    # ------------------------------------------------------------------ narration language
    def _language_changed(self) -> None:
        """Voices, speed, subtitle fonts and the FINALS folder follow the narration language."""
        code = languages.output_code(languages.code_of(self.language.get()))
        self.language.set(languages.display(code))
        if code == self.lang_code:
            return
        self.lang_code = code
        lang = languages.get(code)
        self.voice_combo["values"] = lang["voices"]
        if self.voice.get() not in lang["voices"]:
            self.voice.set(lang["voices"][0])
            self.tts_rate.set(lang["rate"])
        self.mm_fonts = subtitles.installed_fonts(code)
        self.font_combo["values"] = self.mm_fonts
        if self.subs_font.get() not in self.mm_fonts:
            self.subs_font.set(self.mm_fonts[0])
        for item in self.items.values():          # "done" means a FINALS video in THIS language
            if item["status"] == "done":
                item["status"] = "queued"
            self._refresh_item_status(item)
        root = self.output_root.get().strip()
        where = finals_dir(Path(root), code) if root else Path(FINALS_DIR_NAME + languages.suffix(code))
        self._append_log(f"Language: {lang['label']} — voice {self.voice.get()} {self._int(self.tts_rate, 10):+d}%, "
                         f"subtitle font {self.subs_font.get()}, finished videos -> {where}")
        self._editor_changed()

    def _sample_text(self) -> str:
        return subtitles.SAMPLE_TEXT if self.lang_code == languages.DEFAULT else languages.get(self.lang_code)["sample"]

    # ------------------------------------------------------------------ TTS provider / VoxCPM links
    def _provider_changed(self, persist: bool = True) -> None:
        vox = self.tts_provider.get() == "voxcpm"
        if vox:
            self.edge_frame.grid_remove()
            self.vox_frame.grid()
        else:
            self.vox_frame.grid_remove()
            self.edge_frame.grid()
        if persist:
            self._persist_soon()

    def _add_vox_row(self, url: str = "", link_type: str = "", persist: bool = True) -> None:
        row = {"url": tk.StringVar(value=url),
               "type": tk.StringVar(value=voxcpm_client.normalize_link_type(link_type or None, url)),
               "status": tk.StringVar(value="Not tested")}
        f = self.vox_rows_frame
        combo = ttk.Combobox(f, textvariable=row["type"], values=voxcpm_client.LINK_TYPES, state="readonly", width=11)
        entry = ttk.Entry(f, textvariable=row["url"], width=16)
        combo.bind("<<ComboboxSelected>>", lambda _e, r=row: self._vox_row_edited(r))
        entry.bind("<KeyRelease>", lambda _e, r=row: self._vox_row_edited(r))
        row["label"] = ttk.Label(f, width=7)
        row["entry"] = entry
        row["widgets"] = [
            row["label"], combo, entry,
            ttk.Label(f, textvariable=row["status"], width=11, style="Muted.TLabel"),
            ttk.Button(f, text="Test", style="Compact.TButton", width=5, command=lambda r=row: self._test_vox_row(r)),
            ttk.Button(f, text="Replace", style="Compact.TButton", width=8, command=lambda r=row: self._replace_vox_row(r)),
            ttk.Button(f, text="✕", style="Compact.TButton", width=2, command=lambda r=row: self._remove_vox_row(r)),
        ]
        self.vox_rows.append(row)
        self._grid_vox_rows()
        self._vox_links_changed(persist)

    def _grid_vox_rows(self) -> None:
        for i, row in enumerate(self.vox_rows):
            row["label"].configure(text=f"Link {i + 1}")
            for col, w in enumerate(row["widgets"]):
                w.grid(row=i, column=col, sticky="ew" if col == 2 else "w", padx=(0, 4), pady=1)

    def _remove_vox_row(self, row: dict) -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("Running", "Links can be replaced while a batch runs, but not removed.\n"
                                           "Use Replace, or stop the batch first.")
            return
        if len(self.vox_rows) == 1:
            row["url"].set("")
            row["status"].set("Not tested")
        else:
            for w in row["widgets"]:
                w.destroy()
            self.vox_rows.remove(row)
            self._grid_vox_rows()
        self._vox_links_changed()

    def _replace_vox_row(self, row: dict) -> None:
        row["url"].set("")
        row["status"].set("REPLACE URL")
        row["entry"].focus_set()
        self._vox_links_changed()

    def _vox_row_edited(self, row: dict) -> None:
        row["status"].set("Not tested")
        self._vox_links_changed()

    def _vox_links_changed(self, persist: bool = True) -> None:
        """Snapshot for the worker thread: an auto-resume after a link died uses the replaced URL."""
        live = [{"n": i, "url": r["url"].get().strip(), "type": r["type"].get()}
                for i, r in enumerate(self.vox_rows, start=1) if r["url"].get().strip()]
        with self._vox_lock:
            self._vox_live = live
        if persist:
            self._persist_soon()

    def _first_vox_row(self) -> dict | None:
        with_url = [r for r in self.vox_rows if r["url"].get().strip()]
        ready = [r for r in with_url if r["status"].get().startswith(("Ready", "READY", "DONE", "Working"))]
        return (ready or with_url or self.vox_rows or [None])[0]

    def _test_vox_row(self, row: dict | None) -> None:
        """/voices on one link (background thread); the first answer fills the Voice list."""
        if row is None or not row["url"].get().strip():
            messagebox.showinfo("Colab link", "Paste the Colab Gradio / LocalTunnel URL first, then press Test.")
            return
        url, link_type, n = row["url"].get().strip(), row["type"].get(), self.vox_rows.index(row) + 1
        row["status"].set("Testing…")

        def work() -> None:
            try:
                names = voxcpm_client.fetch_voices(url, link_type, log=lambda m: self.msgq.put(("vox", {"link": n, "log": m})))
                self.msgq.put(("vox_test", (row, n, names, "")))
            except Exception as exc:
                self.msgq.put(("vox_test", (row, n, [], voxcpm_client.detail(exc))))
        threading.Thread(target=work, daemon=True).start()

    def _vox_test_result(self, row: dict, n: int, names: list[str], err: str) -> None:
        if row not in self.vox_rows:
            return
        if err:
            row["status"].set("Failed")
            self._link_log(n, f"❌ Test failed: {err}")
            self._append_log(f"❌ Colab Link {n} test failed: {err[:300]}")
            messagebox.showerror("Colab link", f"Link {n} failed:\n\n{err[:600]}\n\nReplace it with a new URL.")
            return
        row["status"].set(f"Ready ({len(names)})")
        self._link_log(n, f"✅ READY — {len(names)} voices: {', '.join(names[:12])}")
        self._append_log(f"✅ Colab Link {n} READY — {len(names)} voice(s)")
        self.vox_voice_combo["values"] = names
        if self.vox_voice.get() not in names:
            self.vox_voice.set(names[0])
        self._persist_soon()

    def _vox_event(self, ev: dict) -> None:
        """@@VOX@@ events from the engine (and link tests): per-link log tab, status, link count."""
        n = int(ev.get("link") or 0)
        if n and "log" in ev:
            self._link_log(n, str(ev["log"]))
        if n and "status" in ev:
            status = str(ev["status"])
            if 1 <= n <= len(self.vox_rows):
                self.vox_rows[n - 1]["status"].set(status)
            if status in ("READY", "FAILED") or status.startswith("DONE"):
                self._append_log(f"🔗 Colab Link {n}: {status}" + (f" — details in the Link {n} tab" if status == "FAILED" else ""))
        if "need" in ev:
            self.vox_need.set(f"This file: {ev.get('blocks')} block(s) to voice → {ev['need']} link(s) needed "
                              f"({voxcpm_client.BLOCKS_PER_LINK} per link)")

    def _write_vox_config(self, work: Path, s: dict) -> Path:
        """voxcpm_run.json for the engine, rewritten before every (re)start with the links shown now."""
        with self._vox_lock:
            links = [dict(link) for link in self._vox_live]
        if not links:
            links = [{"n": i, "url": link["url"], "type": link["type"]}
                     for i, link in enumerate(s["voxcpm_links"], start=1) if link["url"]]
        path = work / "voxcpm_run.json"
        path.write_text(json.dumps({"voice": s["voxcpm_voice"], "speed": f"{int(s['voxcpm_rate_percent']):+d}%",
                                    "links": links, "per_link": voxcpm_client.BLOCKS_PER_LINK},
                                   ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    @staticmethod
    def _voice_state(s: dict, work: Path | None = None) -> dict:
        """What a finished file was voiced with (studio_state.json). Edge keeps its original two keys."""
        if s.get("tts_provider") == "voxcpm":
            state = {"tts_provider": "voxcpm", "tts_voice": s["voxcpm_voice"],
                     "tts_rate": f"{int(s['voxcpm_rate_percent']):+d}%"}
        else:
            state = {"tts_voice": s["tts_voice"], "tts_rate": f"{int(s['tts_rate_percent']):+d}%"}
        if s.get("narration_style") == "flow":      # a new style rewrites the story, so it re-voices too
            state["narration_style"] = "flow"
        if s.get("story_length", "full") != "full":  # another story length is another story
            state["story_length"] = s["story_length"]
        if s.get("analysis_speed", 1) != 1:
            state["analysis_speed"] = int(s["analysis_speed"])
        if s.get("story_length") == "recap":
            if s.get("recap_unit") == "percent":
                state["recap_percent"] = float(s.get("recap_minutes", 75))
            else:
                state["recap_minutes"] = float(s.get("recap_minutes", 12))
        style = telling_style(s)
        if style:                                    # another telling style too
            state["telling_style"] = hashlib.sha1(json.dumps(style, sort_keys=True).encode("utf-8")).hexdigest()[:10]
        if short_pause(s) is not None:              # other pauses = other audio: re-voice
            state["tts_pause"] = short_pause(s)
        if s.get("slow_style", "rife") != "rife":
            state["slow_style"] = s["slow_style"]
            state["freeze_below"] = float(s.get("freeze_below", 0.6))
        if work is not None:
            digest = script_edits.edits_hash(work)
            if digest:
                state["script_edits"] = digest
        return state

    # ------------------------------------------------------------------ queue
    def _ordered_items(self) -> list[dict]:
        return [self.items[iid] for iid in self.tree.get_children() if iid in self.items]

    def _add_paths(self, paths: list[Path]) -> None:
        known = {os.path.normcase(os.path.abspath(str(it["path"]))) for it in self.items.values() if not it.get("url")}
        added = []
        for p in paths:
            key = os.path.normcase(os.path.abspath(str(p)))
            if key in known or not p.is_file():
                continue
            known.add(key)
            self._iid_counter += 1
            iid = f"f{self._iid_counter}"
            item = {"iid": iid, "path": p, "duration": None, "status": "queued"}
            self.items[iid] = item
            self.tree.insert("", "end", iid=iid, values=(p.name, "…", STATUS_TEXT["queued"]))
            added.append(item)
        if added and not self.output_root.get().strip():
            self.output_root.set(str(added[0]["path"].parent / "storytelling_output"))
        for item in added:
            self._refresh_item_status(item)
        if added:
            threading.Thread(target=self._probe_durations, args=(added,), daemon=True).start()
            if not self.tree.selection():
                self.tree.selection_set(added[0]["iid"])
            self._persist_soon()
        self.status.set(f"{len(self.items)} file(s) in queue")

    def _probe_durations(self, items: list[dict]) -> None:
        for item in items:
            try:
                info = effects.probe_video(self.ffprobe, item["path"])
                self.msgq.put(("duration", (item["iid"], info["duration"])))
            except Exception as exc:
                self.msgq.put(("log", f"⚠️ Cannot read {item['path'].name}: {exc}"))

    def _refresh_item_status(self, item: dict) -> None:
        root = self.output_root.get().strip()
        if item.get("url") and root:
            item["path"] = link_file(Path(root), item)     # follows a new Output folder
        if item.get("path") and root:
            final = final_output(Path(root), item["path"], self.lang_code, self.output_mode.get())
            finished = final.is_file() and final.stat().st_size > (100 if self.output_mode.get() == "script" else 10000)
            if item["status"] in ("queued", "stopped", "failed") and finished:
                item["status"] = "done"
            elif item["status"] == "done" and not finished:     # the other output mode was finished
                item["status"] = "queued"
        self._show_item(item)

    def _item_name(self, item: dict) -> str:
        if item.get("url"):
            return "🔗 " + (item.get("title") or item["url"])
        return item["path"].name

    def _show_item(self, item: dict) -> None:
        if not self.tree.exists(item["iid"]):
            return
        length = self._fmt_time(item["duration"]) if item.get("duration") else "…"
        tag = {"done": "done", "failed": "failed", "running": "running", "effects": "running"}.get(item["status"], "")
        text = STATUS_TEXT.get(item["status"], item["status"])
        if item["status"] == "done" and self.output_mode.get() == "script":
            root = self.output_root.get().strip()
            made = root and item.get("path") and final_video(Path(root), item["path"], self.lang_code).is_file()
            text = "Done ✓ (video)" if made else "📜 Script ready"
        self.tree.item(item["iid"], values=(self._item_name(item), length, text),
                       tags=(tag,) if tag else ())

    def _restore_queue(self) -> None:
        restored = 0
        for entry in self.cfg.get("queue") or []:
            if youtube.is_link(entry):
                self._add_urls([entry])
                restored += 1
            elif Path(entry).is_file():
                self._add_paths([Path(entry)])
                restored += 1
        if restored:
            self._append_log(f"Restored {restored} queued item(s) from last session.")
        else:
            self._append_log("Ready. Add videos (+ Files / + Folder / + Link), set the look on the preview, then START ALL.")

    # ------------------------------------------------------------------ links (YouTube and other yt-dlp sites)
    def _add_links(self) -> None:
        """A small window to paste one or more links (one per line); a playlist adds every video."""
        win = tk.Toplevel(self)
        win.title("Add links")
        win.configure(bg=BG)
        win.transient(self)
        ttk.Label(win, text="Paste YouTube links, one per line (a playlist link adds all its videos):").pack(
            anchor="w", padx=10, pady=(10, 4))
        text = tk.Text(win, width=70, height=8, bg=PANEL, fg=FG, insertbackground=FG, relief="flat")
        text.pack(fill="both", expand=True, padx=10)
        try:
            clip = self.clipboard_get()
            if youtube.is_link(clip.strip().splitlines()[0] if clip.strip() else ""):
                text.insert("1.0", clip.strip() + "\n")
        except (tk.TclError, IndexError):
            pass

        def add() -> None:
            links = [x.strip() for x in text.get("1.0", "end").splitlines() if youtube.is_link(x.strip())]
            win.destroy()
            if links:
                self._add_urls(links)
            else:
                messagebox.showinfo("Links", "No link found. A link starts with https://")

        row = ttk.Frame(win)
        row.pack(fill="x", padx=10, pady=10)
        ttk.Button(row, text="Add", command=add).pack(side="right")
        ttk.Button(row, text="Cancel", command=win.destroy).pack(side="right", padx=6)
        text.focus_set()
        win.grab_set()

    def _add_urls(self, urls: list[str], infos: list[dict] | None = None) -> None:
        """Queue links; ones without known title/id (infos) are looked up in the background."""
        known = {it["url"] for it in self.items.values() if it.get("url")}
        if not self.output_root.get().strip():
            self.output_root.set(str(Path.home() / "Desktop" / "storytelling_output"))
        unknown = []
        for n, url in enumerate(urls):
            if url in known:
                continue
            known.add(url)
            self._iid_counter += 1
            iid = f"f{self._iid_counter}"
            item = {"iid": iid, "url": url, "path": None, "title": "", "stem": "", "duration": None, "status": "queued"}
            self.items[iid] = item
            self.tree.insert("", "end", iid=iid, values=(self._item_name(item), "…", STATUS_TEXT["queued"]))
            info = infos[n] if infos and n < len(infos) else None
            if info and info.get("id"):
                self._fill_link(item, info)
            else:
                unknown.append(item)
        if unknown:
            threading.Thread(target=self._lookup_links, args=(unknown, self.proxy.get().strip()), daemon=True).start()
        self._persist_soon()
        self.status.set(f"{len(self.items)} item(s) in queue")

    def _fill_link(self, item: dict, info: dict) -> None:
        item["title"], item["duration"] = info["title"], info.get("duration")
        item["stem"] = link_stem(info)
        self._refresh_item_status(item)

    def _lookup_links(self, items: list[dict], proxy: str) -> None:
        for item in items:
            try:
                self.msgq.put(("link_info", (item["iid"], youtube.lookup(item["url"], proxy, log=None))))
            except Exception as exc:
                self.msgq.put(("log", f"⚠️ Link: {exc}"))

    def _link_info(self, iid: str, entries: list[dict]) -> None:
        """Lookup result: fill the item in, or replace a playlist item with its videos."""
        item = self.items.get(iid)
        if not item or not entries:
            return
        if len(entries) > 1:
            self.tree.delete(iid)
            self.items.pop(iid, None)
            self._add_urls([e["url"] for e in entries], entries)
            self._append_log(f"🔗 Playlist: {len(entries)} video(s) added")
            return
        url = entries[0].get("url") or item["url"]     # a one-video playlist link -> that video's own link
        if url != item["url"] and any(it.get("url") == url for it in self.items.values()):
            self.tree.delete(iid)                        # the same video is already queued
            self.items.pop(iid, None)
            self._persist_soon()
            return
        item["url"] = url
        self._fill_link(item, entries[0])
        self._persist_soon()

    def _output_mode_changed(self) -> None:
        self._update_output_hint()
        for item in self.items.values():
            self._refresh_item_status(item)
        self._persist_soon()

    def _update_output_hint(self) -> None:
        script = self.output_mode.get() == "script"
        if script:
            text = ("Script Review: stops after the story; 📜 Script shows every line with its picture → ▶ voice + "
                    "video.   Script → <Output>\\SCRIPTS\\<name>.txt + _TIMED.txt")
        else:
            text = "Finished video → <Output>\\FINALS\\<name>.mp4"
            if languages.MULTILINGUAL_OUTPUT_ENABLED:
                text += "   (other languages: FINALS_EN …)"
        self.output_hint.configure(text=text)
        if getattr(self, "folder_btn", None):       # built after the queue
            self.folder_btn.configure(text="📂 SCRIPTS Folder" if script else "📂 FINALS Folder")
            self.play_btn.configure(text="▶ Open Selected Script" if script else "▶ Play Selected Final")

    def _add_files(self) -> None:
        picked = filedialog.askopenfilenames(title="Select videos",
                                             filetypes=[("Video", "*.mp4 *.mkv *.mov *.webm *.avi *.m4v *.ts"), ("All", "*.*")])
        if picked:
            self._add_paths(sorted((Path(p) for p in picked), key=natural_key))

    def _add_folder(self) -> None:
        folder = filedialog.askdirectory(title="Select a folder of videos")
        if not folder:
            return
        vids = sorted((p for p in Path(folder).iterdir() if p.is_file() and p.suffix.lower() in VIDEO_EXTS), key=natural_key)
        if not vids:
            messagebox.showinfo("No videos", "No video files directly inside that folder.")
            return
        self._add_paths(vids)

    def _remove_selected(self) -> None:
        if self._busy():
            return
        for iid in self.tree.selection():
            self.tree.delete(iid)
            self.items.pop(iid, None)
        self._persist_soon()
        self.status.set(f"{len(self.items)} file(s) in queue")

    def _clear_queue(self) -> None:
        if self._busy() or not self.items:
            return
        if messagebox.askyesno("Clear queue", "Remove every file from the queue? (Output files stay on disk.)"):
            self.tree.delete(*self.tree.get_children())
            self.items.clear()
            self._persist_soon()

    def _reset_selected(self) -> None:
        if self._busy():
            return
        for iid in self.tree.selection():
            item = self.items.get(iid)
            if item:
                item["status"] = "queued"
                self._show_item(item)

    def _busy(self) -> bool:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("Running", "Stop the batch first.")
            return True
        return False

    def _selected_item(self) -> dict | None:
        sel = self.tree.selection()
        return self.items.get(sel[0]) if sel else None

    def _final_path(self, item: dict) -> Path | None:
        root = self.output_root.get().strip()
        if not root or not item.get("path"):
            return None
        return final_output(Path(root), item["path"], self.lang_code, self.output_mode.get())

    # ------------------------------------------------------------------ browse
    def _browse_output(self) -> None:
        d = filedialog.askdirectory(title="Output folder")
        if d:
            self.output_root.set(d)
            for item in self.items.values():
                self._refresh_item_status(item)
            self._persist_soon()

    def _browse_env(self) -> None:
        p = filedialog.askopenfilename(title="Gemini .env", filetypes=[(".env", "*.env"), ("All", "*.*")])
        if p:
            self.env_path.set(p)
            self._persist_soon()

    def _browse_logo(self) -> None:
        p = filedialog.askopenfilename(title="Logo image", filetypes=[("Image", "*.png *.webp *.jpg *.jpeg"), ("All", "*.*")])
        if p:
            self.logo_path.set(p)
            self.logo_enabled.set(True)
            self._editor_changed()

    def _open_output(self) -> None:
        root = self.output_root.get().strip()
        where = scripts_dir if self.output_mode.get() == "script" else finals_dir
        finals = where(Path(root), self.lang_code) if root else None
        if finals and finals.is_dir():
            os.startfile(str(finals))
        elif root and Path(root).is_dir():
            os.startfile(root)
        else:
            messagebox.showinfo("Output", "Output folder does not exist yet.")

    def _test_voice(self) -> None:
        """Speak a short sample with the chosen voice + speed and play it."""
        if self.tts_provider.get() == "voxcpm":
            self._test_vox_voice()
            return
        voice = self.voice.get().strip() or languages.get(self.lang_code)["voices"][0]
        rate = f"{self._int(self.tts_rate, 25):+d}%"
        out = LOGS_DIR / f"tts_test_{voice}_{rate.replace('%', 'pct').replace('+', 'p').replace('-', 'm')}.mp3"
        self.test_voice_btn.configure(state="disabled")
        self.status.set(f"TTS test: {voice} {rate}")
        sample = languages.get(self.lang_code)["sample"]

        def work() -> None:
            import asyncio
            import edge_tts
            try:
                if not out.is_file():
                    asyncio.run(edge_tts.Communicate(sample, voice, rate=rate).save(str(out)))
                os.startfile(str(out))
                self.msgq.put(("log", f"▶ TTS test: {voice} {rate}"))
            except Exception as exc:
                self.msgq.put(("log", f"⚠️ TTS test failed: {exc}"))
            self.msgq.put(("test_voice_done", None))
        threading.Thread(target=work, daemon=True).start()

    def _test_vox_voice(self) -> None:
        """One /generate on the first working Colab link, VoxCPM speed applied the engine's way."""
        row = self._first_vox_row()
        voice = self.vox_voice.get().strip()
        if row is None or not row["url"].get().strip() or not voice:
            messagebox.showinfo("VoxCPM", "Add a Colab link and press Test on it to load the voices first.")
            return
        url, link_type = row["url"].get().strip(), row["type"].get()
        rate = self._int(self.vox_rate, 0)
        self.vox_test_btn.configure(state="disabled")
        self.status.set(f"VoxCPM test: {voice} {rate:+d}%")
        sample = languages.get(self.lang_code)["sample"]

        def work() -> None:
            try:
                client = voxcpm_client.connect(url, link_type, PREVIEW_DIR / "voxcpm_test")
                raw = voxcpm_client.generate_to(client, sample, voice, PREVIEW_DIR / "voxcpm_test_raw.wav")
                out = LOGS_DIR / f"voxcpm_test_{int(time.time())}.wav"   # a playing test file stays locked
                tempo = ["-af", f"atempo={1 + rate / 100.0:.4f}"] if rate else []
                subprocess.run([self.ffmpeg, "-y", "-v", "error", "-i", str(raw), *tempo, str(out)],
                               check=True, capture_output=True, creationflags=CREATE_NO_WINDOW)
                os.startfile(str(out))
                self.msgq.put(("log", f"▶ VoxCPM test: {voice} {rate:+d}%"))
            except Exception as exc:
                self.msgq.put(("log", f"⚠️ VoxCPM test failed: {voxcpm_client.detail(exc)}"))
            self.msgq.put(("test_voice_done", None))
        threading.Thread(target=work, daemon=True).start()

    def _play_selected(self) -> None:
        item = self._selected_item()
        final = self._final_path(item) if item else None
        if final and final.is_file():
            os.startfile(str(final))
        else:
            messagebox.showinfo("Not finished", "This item has no " +
                                ("script" if self.output_mode.get() == "script" else "FINALS video") + " yet.")

    def _script_button_state(self) -> None:
        item = self._selected_item()
        root = self.output_root.get().strip()
        work = lang_work_dir(Path(root), item["path"], self.lang_code) if root and item and item.get("path") else None
        ready = work is not None and (work / "SYNC_NARRATION_BLOCKS.json").is_file()
        running = item is not None and item.get("status") in ("running", "effects")   # other files: open while a batch runs
        self.script_btn.configure(state="normal" if ready and not running else "disabled")

    def _edit_script(self, item: dict | None = None) -> None:
        item = item or self._selected_item()
        if not item or not item.get("path") or not self.output_root.get().strip():
            return
        win = self.script_wins.get(item["iid"])
        if win is not None and win.winfo_exists():
            win.lift()
            return
        from script_editor import ScriptEditor
        root = Path(self.output_root.get())
        work = lang_work_dir(root, item["path"], self.lang_code)
        def saved():
            if item["status"] not in ("running", "effects"):
                item["status"] = "queued"
            self._show_item(item)
        try:
            self.script_wins[item["iid"]] = ScriptEditor(
                self, work, on_saved=saved, video=item["path"], ffmpeg=self.ffmpeg,
                script_out=final_script(root, item["path"], self.lang_code),
                style_var=self.story_style, style_values=list(TELLING_STYLE_LABELS.values()),
                on_style_changed=self._persist_soon, on_style_notes=self._style_dialog,
                on_rewrite=lambda: self._run_one(item, "script"), on_continue=lambda: self._run_one(item, "video"))
        except Exception as exc:
            messagebox.showerror("Script", str(exc), parent=self)

    def _run_one(self, item: dict, mode: str) -> str:
        """📜 window: ▶ voice + video ("video") or ↻ the story again in the chosen style ("script") for this file
        only, whatever the Make choice; behind a running batch it goes next. Returns the window's status line."""
        item["make"] = mode
        if self.worker and self.worker.is_alive():
            if item["iid"] not in self.after_batch:
                self.after_batch.append(item["iid"])
            return "the batch is still running — this file goes next, right after it."
        if not self._start(only=[item]):
            item.pop("make", None)
            return "not started (see the message)."
        return ("voice + video started — the story is reused, edited lines are voiced again." if mode == "video"
                else "writing the story again in the chosen style…")

    def _script_ready(self, iid: str) -> None:
        """Script Review: the first finished script opens its 📜 window (an open window reads its file again)."""
        item = self.items.get(str(iid))
        if not item or any(w.winfo_exists() for w in self.script_wins.values()):
            return
        if self.tree.exists(item["iid"]):
            self.tree.selection_set(item["iid"])
        self._edit_script(item)

    def _start_waiting(self, waiting: list[dict], tries: int = 20) -> None:
        if self.worker and self.worker.is_alive():      # the batch thread is still finishing
            if tries:
                self.after(250, self._start_waiting, waiting, tries - 1)
            return
        self._start(only=waiting)

    # ------------------------------------------------------------------ preview
    def _on_select(self) -> None:
        self._script_button_state()
        item = self._selected_item()
        if item and item.get("url") and not (item.get("path") and item["path"].is_file()):
            self.preview_note.configure(text=f"🔗 {item.get('title') or item['url']}  —  downloads when the batch starts")
            return
        if not item or (self.preview_src and same_path(self.preview_src, item["path"])):
            return
        try:
            info = effects.probe_video(self.ffprobe, item["path"])
        except Exception as exc:
            self._append_log(f"⚠️ Preview: {exc}")
            return
        self.preview_src = item["path"]
        self.preview_info = info
        self._layout_preview()
        self.seek.configure(to=max(0.1, info["duration"]))
        if self.preview_time.get() <= 0 or self.preview_time.get() > info["duration"]:
            self.preview_time.set(round(info["duration"] * 0.2, 2))
        name = item["path"].name
        if len(name) > 46:      # a long file name would widen the preview column and squeeze the others
            name = name[:30] + "…" + name[-12:]
        self.preview_note.configure(text=f"{name}  —  {info['width']}x{info['height']}, {self._fmt_time(info['duration'])}")
        self._load_frame()

    def _src_dims(self) -> tuple[int, int]:
        return int(self.preview_info["width"]), int(self.preview_info["height"])

    def _canvas_dims(self, ed: dict | None = None) -> tuple[int, int]:
        """Final frame size: the source (Original) or 1080x1920 (9:16)."""
        return effects.output_size(ed or self._editor(), *self._src_dims())

    def _layout_preview(self) -> None:
        """Preview canvas = the final frame scaled into the preview area."""
        if not self.preview_info:
            return
        cw, ch = self._canvas_dims()
        scale = min(PREVIEW_MAX_W / cw, PREVIEW_MAX_H / ch)
        self.pw, self.ph = max(120, int(cw * scale)), max(120, int(ch * scale))
        self.canvas.configure(width=self.pw, height=self.ph)
        self._composed = None

    def _load_frame(self) -> None:
        if not self.preview_src or not self.preview_info:
            return
        out = PREVIEW_DIR / "frame.png"
        w, h = self._src_dims()
        k = min(1.0, FRAME_MAX / float(max(w, h)))      # composed down to the canvas later
        try:
            effects.extract_frame(self.ffmpeg, self.preview_src, self.preview_time.get(), out,
                                  max(2, int(w * k) // 2 * 2), max(2, int(h * k) // 2 * 2))
            with Image.open(out) as im:
                self.frame_img = im.convert("RGB")
        except Exception as exc:
            self._append_log(f"⚠️ Preview frame: {exc}")
            return
        self._composed = None
        self.seek_label.configure(text=self._fmt_time(self.preview_time.get()))
        self._redraw()

    def _compose_frame(self, ed: dict) -> Image.Image:
        """Blur (source space) -> Flip -> Zoom -> Output ratio, like the final effects pass."""
        key = (id(self.frame_img), self.pw, self.ph, ed["mirror"], ed["zoom"], ed["blur_strength"],
               tuple(tuple(sorted(b.items())) for b in ed["blur_boxes"]), ed["ratio"], ed["fill"], tuple(ed["frame_pos"]))
        if self._composed and self._composed[0] == key:
            return self._composed[1]
        img = self.frame_img.copy()
        fw, fh = img.size
        src_w, src_h = self._src_dims()
        for b in ed["blur_boxes"]:
            x1, y1 = int(b["x"] * fw), int(b["y"] * fh)
            x2, y2 = int((b["x"] + b["w"]) * fw), int((b["y"] + b["h"]) * fh)
            if x2 - x1 < 2 or y2 - y1 < 2:
                continue
            region = img.crop((x1, y1, x2, y2))
            radius = max(1, int(round(ed["blur_strength"] * fw / float(src_w))))
            region = region.filter(ImageFilter.BoxBlur(radius)).filter(ImageFilter.BoxBlur(radius))
            img.paste(region, (x1, y1))
        if ed["mirror"]:
            img = ImageOps.mirror(img)
        if ed["zoom"] > 1.0005:
            cw, ch = fw / ed["zoom"], fh / ed["zoom"]
            left, top = (fw - cw) / 2.0, (fh - ch) / 2.0
            img = img.crop((int(left), int(top), int(left + cw), int(top + ch))).resize((fw, fh), Image.LANCZOS)
        pl = effects.picture_placement(ed, src_w, src_h)
        k = self.pw / float(pl["cw"])
        pic = img.resize((max(2, round(pl["sw"] * k)), max(2, round(pl["sh"] * k))), Image.LANCZOS)
        if ed["ratio"] == "Original":
            out = pic if pic.size == (self.pw, self.ph) else pic.resize((self.pw, self.ph), Image.LANCZOS)
        else:
            if ed["fill"] == "blur":
                cover = max(self.pw / pic.width, self.ph / pic.height)
                bg = pic.resize((max(1, round(pic.width * cover)), max(1, round(pic.height * cover))), Image.BILINEAR)
                left, top = (bg.width - self.pw) // 2, (bg.height - self.ph) // 2
                bg = bg.crop((left, top, left + self.pw, top + self.ph)).filter(ImageFilter.GaussianBlur(max(2.0, self.pw / 30.0)))
                out = ImageEnhance.Brightness(ImageEnhance.Color(bg).enhance(0.85)).enhance(0.88)
            else:
                out = Image.new("RGB", (self.pw, self.ph), (0, 0, 0))
            out.paste(pic, (round(pl["ox"] * k), round(pl["oy"] * k)))
        self._composed = (key, out)
        return out

    def _redraw(self) -> None:
        c = self.canvas
        c.delete("all")
        ed = self._editor()
        self.blur_count.configure(text=f"{len(ed['blur_boxes'])} box" + ("es" if len(ed["blur_boxes"]) != 1 else ""))
        if self.frame_img is None or not self.preview_info:
            c.create_text(self.pw / 2, self.ph / 2, text="Select a video\nin the queue", fill=MUTED,
                          font=("Segoe UI", 12), justify="center")
            return
        self._photos["frame"] = ImageTk.PhotoImage(self._compose_frame(ed))
        c.create_image(0, 0, image=self._photos["frame"], anchor="nw", tags=("frame",))
        scale = self.pw / float(self._canvas_dims(ed)[0])

        for i in range(len(ed["blur_boxes"])):
            x1, y1, x2, y2 = self._box_px(ed, i)
            color = WARN if i == self.selected_blur else BLUR_COLOR
            c.create_rectangle(x1, y1, x2, y2, outline=color, width=2, dash=(6, 4), tags=("blur", f"blur_{i}"))
            c.create_text(x1 + 4, y1 + 3, text=f"BLUR {i + 1}", fill=color, anchor="nw", font=("Segoe UI Semibold", 8), tags=(f"blur_{i}",))
            c.create_rectangle(x2 - 6, y2 - 6, x2 + 6, y2 + 6, fill=color, outline="#111111", tags=(f"handle_{i}",))

        if ed["title_text"]:
            self._draw_text_item("title", ed["title_text"], ed["title_size"], ed["title_pos"], 1.0, scale)
        if effects.logo_active(ed):
            try:
                logo = self._logo_image(ed["logo_path"], ed["logo_width_frac"], ed["logo_opacity"])
                self._photos["logo"] = ImageTk.PhotoImage(logo)
                c.create_image(ed["logo_pos"][0] * self.pw, ed["logo_pos"][1] * self.ph,
                               image=self._photos["logo"], anchor="nw", tags=("logo",))
            except Exception as exc:
                self._append_log(f"⚠️ Logo preview: {exc}")
        if ed["extra_text"]:
            self._draw_text_item("extra", ed["extra_text"], ed["extra_size"], ed["extra_pos"], ed["extra_opacity"], scale)
        if ed["subs_enabled"]:
            self._draw_subs(ed)

    def _subs_sample_text(self, ed: dict) -> str:
        """First narration phrases of the selected file (after it has run), else a sample line."""
        item = self._selected_item()
        root = self.output_root.get().strip()
        if item and root:
            try:
                work = lang_work_dir(Path(root), item["path"], self.lang_code)
                blocks = json.loads((work / "SYNC_NARRATION_BLOCKS.json").read_text(encoding="utf-8"))
                cw, ch = self._canvas_dims(ed)
                size = effects.subtitle_style(ed, cw, ch)["size"]
                lang = languages.get(self.lang_code)
                limit = subtitles.line_capacity(cw, size, lang["char_w"]) * 2 - 4
                text = subtitles.clean_text(blocks[0]["narration_text"])
                if not lang["spaced"]:          # Thai / Japanese: no spaces to cut at
                    return "".join(subtitles.clusters(text)[:limit])
                out, size = [], 0
                for phrase in text.split(" "):
                    n = len(subtitles.clusters(phrase)) + (1 if out else 0)
                    if out and size + n > limit:
                        break
                    out.append(phrase)
                    size += n
                if out:
                    return " ".join(out)
            except Exception:
                pass
        return self._sample_text()

    def _draw_subs(self, ed: dict) -> None:
        """Sample subtitle exactly as libass burns it; appears as soon as the render is ready."""
        text = self._subs_sample_text(ed)
        cw, ch = self._canvas_dims(ed)
        style = effects.subtitle_style(ed, cw, ch)
        key = ("subs", text, style["font"], style["size"], style["style"], int(cw), int(ch), self.pw, self.ph,
               languages.get(self.lang_code)["char_w"])
        entry = self._text_cache.get(key)
        if entry is not None:
            img, (left, top) = entry
            self._photos["subs"] = ImageTk.PhotoImage(img)
            top = top + (ed["subs_pos_y"] - 0.5) * self.ph      # rendered centred at 0.5
            self.canvas.create_image(left, top, image=self._photos["subs"], anchor="nw", tags=("subs",))
        elif key not in self._text_pending:
            self._text_pending.add(key)
            self._text_jobs.put(key)

    def _logo_image(self, path: str, width_frac: float, opacity: float) -> Image.Image:
        with Image.open(path) as im:
            logo = im.convert("RGBA")
        w = max(8, int(round(self.pw * width_frac)))
        h = max(4, int(round(logo.height * w / logo.width)))
        logo = logo.resize((w, h), Image.LANCZOS)
        if opacity < 0.999:
            alpha = logo.getchannel("A").point(lambda a: int(a * opacity))
            logo.putalpha(alpha)
        return logo

    def _text_key(self, kind: str, text: str, size: int) -> tuple:
        return (kind, text, int(size), int(self._canvas_dims()[0]))

    def _draw_text_item(self, kind: str, text: str, size: int, pos: list[float], opacity: float, scale: float) -> None:
        key = self._text_key(kind, text, size)
        x, y = pos[0] * self.pw, pos[1] * self.ph
        img = self._text_cache.get(key)
        if img is not None:
            shown = img.resize((max(4, int(img.width * scale)), max(4, int(img.height * scale))), Image.LANCZOS)
            if opacity < 0.999:
                shown.putalpha(shown.getchannel("A").point(lambda a: int(a * opacity)))
            self._photos[kind] = ImageTk.PhotoImage(shown)
            self.canvas.create_image(x, y, image=self._photos[kind], anchor="center", tags=(kind,))
            return
        # Placeholder until the exact Chromium-rendered PNG is ready.
        fs = max(8, int(size * scale))
        self.canvas.create_text(x + 1, y + 1, text=text, fill="#000000", font=("Myanmar Text", fs, "bold"),
                                width=int(self.pw * 0.9), anchor="center", tags=(kind,))
        self.canvas.create_text(x, y, text=text, fill="#ffffff", font=("Myanmar Text", fs, "bold"),
                                width=int(self.pw * 0.9), anchor="center", tags=(kind,))
        if key not in self._text_pending:
            self._text_pending.add(key)
            self._text_jobs.put(key)

    def _text_render_loop(self) -> None:
        while True:
            key = self._text_jobs.get()
            if key[0] == "subs":
                _kind, text, font, size, style, width, height, pw, ph, char_w = key
                try:
                    entry = subtitles.render_preview_png(
                        text, width, height, {"font": font, "size": size, "style": style, "pos_y": 0.5, "char_w": char_w},
                        pw, ph, PREVIEW_DIR / "subs", self.ffmpeg)
                    if entry[0] is None:
                        raise RuntimeError("libass rendered nothing (font missing?)")
                    self.msgq.put(("text_ready", (key, entry)))
                except Exception as exc:
                    self.msgq.put(("text_failed", (key, str(exc))))
                continue
            kind, text, size, width = key
            try:
                cfg = effects.title_png_config(size, width) if kind == "title" else effects.extra_png_config(size, width)
                name = hashlib.sha1(repr(key).encode("utf-8")).hexdigest()[:12]
                png = effects.render_text_png(text, PREVIEW_DIR / f"{kind}_{name}.png", cfg)
                with Image.open(png) as im:
                    self.msgq.put(("text_ready", (key, im.convert("RGBA"))))
            except Exception as exc:
                self.msgq.put(("text_failed", (key, str(exc))))

    # ------------------------------------------------------------------ mouse editing
    def _begin_blur(self) -> None:
        if not self.frame_img:
            messagebox.showinfo("Preview", "Select a video first.")
            return
        self._draw_mode = True
        self.selected_blur = None
        self.canvas.configure(cursor="crosshair")
        self.status.set("DRAW BLUR BOX — drag on the preview")

    def _delete_blur(self) -> None:
        if self.selected_blur is not None and 0 <= self.selected_blur < len(self.blur_boxes):
            self.blur_boxes.pop(self.selected_blur)
            self.selected_blur = None
            self._editor_changed()

    def _box_px(self, ed: dict, i: int) -> tuple[float, float, float, float]:
        r = effects.source_to_canvas_rect(ed["blur_boxes"][i], ed, *self._src_dims())
        return r["x"] * self.pw, r["y"] * self.ph, (r["x"] + r["w"]) * self.pw, (r["y"] + r["h"]) * self.ph

    def _picture_movable(self, ed: dict) -> bool:
        """9:16 with free room (fit) or overflow (crop): the picture can be dragged."""
        if ed["ratio"] != "9:16":
            return False
        pl = effects.picture_placement(ed, *self._src_dims())
        return abs(pl["cw"] - pl["sw"]) >= 2 or abs(pl["ch"] - pl["sh"]) >= 2

    def _hit(self, x: float, y: float) -> tuple[str, int | None]:
        """Corner square -> resize, title/logo/text -> drag, inside a blur box -> move,
        subtitle next (it is large and easy to grab elsewhere), then the picture itself (9:16).

        Blur boxes are hit-tested by area: a Tk rectangle without fill only reacts on
        its thin outline, which made boxes hard to grab.
        """
        ed = self._editor()
        topmost_first = range(len(ed["blur_boxes"]) - 1, -1, -1)
        for i in topmost_first:
            _x1, _y1, x2, y2 = self._box_px(ed, i)
            if abs(x - x2) <= 8 and abs(y - y2) <= 8:
                return "resize", i
        under = [self.canvas.gettags(item) for item in reversed(self.canvas.find_overlapping(x - 2, y - 2, x + 2, y + 2))]
        for tags in under:
            for kind in ("title", "logo", "extra"):
                if kind in tags:
                    return kind, None
        for i in topmost_first:
            x1, y1, x2, y2 = self._box_px(ed, i)
            if x1 - 3 <= x <= x2 + 3 and y1 - 3 <= y <= y2 + 3:
                return "move", i
        if any("subs" in tags for tags in under):
            return "subs", None
        if self._picture_movable(ed):
            return "frame", None
        return "", None

    def _hover(self, e) -> None:
        if self._drag or not self.frame_img:
            return
        if self._draw_mode:
            cursor = "crosshair"
        else:
            kind, _ = self._hit(e.x, e.y)
            cursor = {"resize": "size_nw_se", "move": "fleur", "title": "hand2", "logo": "hand2", "extra": "hand2",
                      "subs": "sb_v_double_arrow", "frame": "fleur"}.get(kind, "arrow")
        if self.canvas.cget("cursor") != cursor:
            self.canvas.configure(cursor=cursor)

    def _press(self, e) -> None:
        if not self.frame_img:
            return
        self.canvas.focus_set()  # Delete key removes the selected blur box
        x, y = max(0.0, min(e.x, self.pw)), max(0.0, min(e.y, self.ph))
        if self._draw_mode:
            self._drag = {"kind": "draw", "start": (x, y),
                          "rect": self.canvas.create_rectangle(x, y, x, y, outline=BLUR_COLOR, width=2, dash=(6, 4))}
            return
        kind, idx = self._hit(x, y)
        ed = self._editor()
        self._drag = {"kind": kind, "idx": idx, "start": (x, y)}
        if kind in ("move", "resize"):
            self.selected_blur = idx
            self._drag["rect"] = effects.source_to_canvas_rect(self.blur_boxes[idx], ed, *self._src_dims())
        elif kind == "frame":
            self._drag["orig"] = list(self.frame_pos)
            self.selected_blur = None
        elif kind == "logo":
            self._drag["orig"] = list(self.logo_pos)
        elif kind == "subs":
            self._drag["orig"] = self.subs_pos_y
        elif kind in ("title", "extra"):
            self._drag["orig"] = list(self.title_pos if kind == "title" else self.extra_pos)
        else:
            self.selected_blur = None
        self._redraw()

    def _motion(self, e) -> None:
        if not self._drag:
            return
        x, y = max(0.0, min(e.x, self.pw)), max(0.0, min(e.y, self.ph))
        d = self._drag
        if d["kind"] == "draw":
            self.canvas.coords(d["rect"], d["start"][0], d["start"][1], x, y)
            return
        dx, dy = (x - d["start"][0]) / self.pw, (y - d["start"][1]) / self.ph
        ed = self._editor()
        if d["kind"] == "logo":
            self.logo_pos = [min(0.98, max(0.0, d["orig"][0] + dx)), min(0.98, max(0.0, d["orig"][1] + dy))]
        elif d["kind"] == "subs":
            self.subs_pos_y = min(0.95, max(0.05, d["orig"] + dy))
        elif d["kind"] == "title":
            self.title_pos = [min(1.0, max(0.0, d["orig"][0] + dx)), min(1.0, max(0.0, d["orig"][1] + dy))]
        elif d["kind"] == "extra":
            self.extra_pos = [min(1.0, max(0.0, d["orig"][0] + dx)), min(1.0, max(0.0, d["orig"][1] + dy))]
        elif d["kind"] == "frame":
            # ox = (canvas_w - picture_w) * pos_x, so a drag of dx canvas moves pos by dx*cw/(cw-sw)
            pl = effects.picture_placement(ed, *self._src_dims())
            nx, ny = d["orig"]
            if abs(pl["cw"] - pl["sw"]) >= 2:
                nx = min(1.0, max(0.0, d["orig"][0] + dx * pl["cw"] / (pl["cw"] - pl["sw"])))
            if abs(pl["ch"] - pl["sh"]) >= 2:
                ny = min(1.0, max(0.0, d["orig"][1] + dy * pl["ch"] / (pl["ch"] - pl["sh"])))
            self.frame_pos = [nx, ny]
        elif d["kind"] in ("move", "resize") and d["idx"] is not None:
            r = dict(d["rect"])
            if d["kind"] == "move":
                r["x"] += dx
                r["y"] += dy
            else:
                r["w"] = max(0.02, r["w"] + dx)
                r["h"] = max(0.02, r["h"] + dy)
            src = effects.canvas_to_source_rect(r, ed, *self._src_dims())
            if d["kind"] == "move":
                src["x"] = min(max(0.0, src["x"]), 1.0 - src["w"])
                src["y"] = min(max(0.0, src["y"]), 1.0 - src["h"])
                self.blur_boxes[d["idx"]] = src
            else:
                fixed = effects.clamp_box(src)
                if fixed:
                    self.blur_boxes[d["idx"]] = fixed
        else:
            return
        self._redraw()

    def _release(self, e) -> None:
        d, self._drag = self._drag, None
        if not d:
            return
        if d["kind"] == "draw":
            x, y = max(0.0, min(e.x, self.pw)), max(0.0, min(e.y, self.ph))
            (x1, y1), (x2, y2) = d["start"], (x, y)
            self._draw_mode = False
            self.canvas.configure(cursor="arrow")
            self.status.set("READY")
            if abs(x2 - x1) >= 8 and abs(y2 - y1) >= 8:
                ed = self._editor()
                out_rect = {"x": min(x1, x2) / self.pw, "y": min(y1, y2) / self.ph,
                            "w": abs(x2 - x1) / self.pw, "h": abs(y2 - y1) / self.ph}
                box = effects.clamp_box(effects.canvas_to_source_rect(out_rect, ed, *self._src_dims()))
                if box:
                    self.blur_boxes.append(box)
                    self.selected_blur = len(self.blur_boxes) - 1
        self._editor_changed()

    # ------------------------------------------------------------------ batch run
    def _check_ready(self, need_engine: bool, mode: str | None = None) -> dict | None:
        s = self._settings()
        if not s["output_root"]:
            messagebox.showwarning("Output", "Choose an output folder first.")
            return None
        if need_engine:
            if not ENGINE.is_file():
                messagebox.showerror("Engine missing", f"Engine not found:\n{ENGINE}")
                return None
            if s["gemini_env_path"] and not Path(s["gemini_env_path"]).is_file():
                if not messagebox.askyesno("Gemini .env", "The .env file was not found. Continue with GEMINI_API_KEY from the environment?"):
                    return None
            if s["tts_provider"] == "voxcpm" and (mode or s.get("output_mode")) != "script":   # a script needs no voice
                if not any(link["url"] for link in s["voxcpm_links"]):
                    messagebox.showwarning("VoxCPM", "Add at least one Colab link (Gradio or LocalTunnel URL).")
                    return None
                if not s["voxcpm_voice"]:
                    messagebox.showwarning("VoxCPM", "Press Test on a Colab link to load its voices, then pick a voice.")
                    return None
                try:
                    import gradio_client  # noqa: F401
                except ImportError:
                    messagebox.showerror("VoxCPM", "gradio_client is not installed.\nRun: pip install -U gradio_client")
                    return None
        ed = self._editor()
        if ed["logo_enabled"] and ed["logo_path"] and not Path(ed["logo_path"]).is_file():
            messagebox.showwarning("Logo", "Logo is ON but the image file does not exist.")
            return None
        return s

    def _start(self, only: list[dict] | None = None) -> bool:
        """START ALL, or (`only`) the files a 📜 window sent on; those carry item["make"] = "video" / "script"."""
        if self.worker and self.worker.is_alive():
            return False
        if any(it.get("make") == "video" for it in only or []):
            s = self._check_ready(True, "video")
        else:
            s = self._check_ready(need_engine=True)
        if not s:
            return False
        order = self._ordered_items()
        jobs = list(only or [])
        script = s.get("output_mode") == "script"
        for it in ([] if only else order):
            work = lang_work_dir(Path(s["output_root"]), it["path"], s["language"]) if it.get("path") else None
            changed = False
            if work is not None:
                now = self._voice_state(s, work)
                if (work / STATE_NAME).exists() or (script and (work / SCRIPT_STATE_NAME).exists()):
                    changed = read_state(work, script) != now
                else:
                    # A queue item marked done before state files existed keeps that status.
                    changed = bool(script_edits.edits_hash(work)) or any(
                        k in now for k in ("analysis_speed", "slow_style", "telling_style", "story_length"))
            if not (s["skip_finished"] and it["status"] == "done") or changed:
                jobs.append(it)
        # "Same series": each file starts from the story memory of the file above it in the queue
        s["series_prev"] = {it["iid"]: prev["iid"] for prev, it in zip(order, order[1:])} if s["share_registry"] else {}
        if not jobs:
            messagebox.showinfo("Nothing to do", "Every file in the queue is already finished.\n"
                                "Untick 'Skip files that are already finished' or use Reset Status to run again.")
            return False
        self._persist()
        self._launch(self._batch_worker, jobs, s, self._editor())
        return True

    def _reapply_effects(self) -> None:
        if self.worker and self.worker.is_alive():
            return
        s = self._check_ready(need_engine=False)
        if not s:
            return
        root = Path(s["output_root"])
        jobs = [it for it in self._ordered_items()
                if it.get("path") and raw_video(lang_work_dir(root, it["path"], s["language"]))]
        if not jobs:
            messagebox.showinfo("Nothing to re-apply", "No file has a finished engine video yet.")
            return
        self._persist()
        self._launch(self._effects_worker, jobs, s, self._editor())

    def _launch(self, target, jobs: list[dict], s: dict, ed: dict) -> None:
        self.stop_event.clear()
        self._script_button_state()
        self.start_btn.configure(state="disabled")
        self.reapply_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.status.set("RUNNING")
        self.msgq.put(("progress", (0.0, 0.0)))

        def run() -> None:
            keep_awake(True)   # long batches run for hours; do not let Windows sleep
            try:
                target(jobs, s, ed)
            except Exception as exc:
                self.msgq.put(("finished", f"Batch stopped by an error: {exc}"))
            finally:
                keep_awake(False)
        self.worker = threading.Thread(target=run, daemon=True)
        self.worker.start()

    def _stop(self) -> None:
        self.stop_event.set()
        kill_tree(self.proc_holder.get("proc"))
        self.status.set("STOPPING…")

    def _set_item(self, item: dict, status: str) -> None:
        item["status"] = status
        self.msgq.put(("item", item["iid"]))

    def _progress(self, done: int, total: int, frac: float) -> None:
        self.msgq.put(("progress", (frac, (done + frac) / max(1, total))))

    def _download_link(self, item: dict, root: Path, s: dict, n: int, total: int) -> Path | None:
        """The link's video file, downloaded into <output>/_downloads first if needed (None = failed)."""
        if not item.get("stem"):          # not looked up yet (this runs in the batch thread: no tree calls)
            try:
                entries = youtube.lookup(item["url"], s["proxy"])
            except Exception as exc:
                self._log(f"❌ {item['url']}: {exc}")
                return None
            if len(entries) != 1:
                self._log(f"❌ {item['url']}: a playlist — add it while no batch runs so its videos are listed")
                return None
            e = entries[0]
            item["url"] = e.get("url") or item["url"]
            item["title"], item["duration"] = e["title"], e.get("duration")
            item["stem"] = link_stem(e)
            self.msgq.put(("item", item["iid"]))
        target = link_file(root, item)
        item["path"] = target
        if target.is_file() and target.stat().st_size > 1_000_000:
            return target
        name = item.get("title") or item["url"]
        self._set_item(item, "running")
        self._log(f"⬇️ Downloading {name}")

        def progress(frac: float) -> None:
            self.msgq.put(("stage", f"{name} — downloading {int(frac * 100)}%"))
            self._progress(n, total, 0.02 * frac)
        try:
            path = youtube.download(item["url"], target.parent, item["stem"], ffmpeg=self.ffmpeg, proxy=s["proxy"],
                                    progress=progress, cancelled=self.stop_event.is_set, log=self._log)
        except Exception as exc:
            if not self.stop_event.is_set():
                self._log(f"❌ {name}: download failed — {exc}")
            return None
        self._log(f"✓ Downloaded → {path}")
        return path

    def _batch_worker(self, jobs: list[dict], s: dict, ed: dict) -> None:
        root = Path(s["output_root"])
        code = s["language"]
        batch_s, ok, failed = s, 0, 0
        for n, item in enumerate(jobs):
            if self.stop_event.is_set():
                break
            # a 📜 window's ▶ / ↻ runs this file as video / script whatever the Make choice
            s = dict(batch_s, output_mode=item.pop("make")) if item.get("make") else batch_s
            script_mode = s.get("output_mode") == "script"
            (scripts_dir if script_mode else finals_dir)(root, code).mkdir(parents=True, exist_ok=True)
            if item.get("url"):
                src = self._download_link(item, root, s, n, len(jobs))
                if src is None:
                    if self.stop_event.is_set():
                        self._set_item(item, "stopped")
                        break
                    self._set_item(item, "failed")
                    failed += 1
                    continue
            else:
                src = item["path"]
            base = work_dir_for(root, src)            # source link + Gemini analysis (shared by all languages)
            work = lang_work_dir(root, src, code)     # this language's story, TTS, render
            final = final_output(root, src, code, s.get("output_mode", "video"))
            voice_now = self._voice_state(s, work)
            done_before = final.is_file() and final.stat().st_size > (100 if script_mode else 10000)
            if s["skip_finished"] and done_before:
                if read_state(work, script_mode) == voice_now or (
                        script_mode and not (work / STATE_NAME).exists() and not (work / SCRIPT_STATE_NAME).exists()
                        and not script_edits.edits_hash(work)):
                    self._set_item(item, "done")
                    self._log(f"⏭️ {src.name}: already in {final.parent.name}, skipped")
                    continue
                self._log(f"🔁 {src.name}: voice/speed changed → re-voicing (Gemini timeline + story reused)")
            self._set_item(item, "running")
            self._log(f"━━━ [{n + 1}/{len(jobs)}] {src.name} → {work}")
            work.mkdir(parents=True, exist_ok=True)
            (base / "source.json").write_text(json.dumps({"source": str(src.resolve())}, ensure_ascii=False, indent=2), encoding="utf-8")
            prev = self.items.get(s.get("series_prev", {}).get(item["iid"], ""))
            memory_in = lang_work_dir(root, prev["path"], code) / STORY_MEMORY_NAME if prev and prev.get("path") else None
            engine_ok = self._run_engine_with_resume(engine_input(src, base), src.name, work, root, s, n, len(jobs),
                                                     memory_in=memory_in)
            if self.stop_event.is_set():
                self._set_item(item, "stopped")
                break
            if script_mode:
                script = work / ENGINE_SCRIPT_NAME
                if not engine_ok or not script.is_file():
                    self._set_item(item, "failed")
                    failed += 1
                    self._log(f"❌ {src.name}: engine failed — see {work / 'run.log'}")
                    continue
                (work / SCRIPT_STATE_NAME).write_text(json.dumps(voice_now, ensure_ascii=False), encoding="utf-8")
                shutil.copy2(script, final)
                timed = work / ENGINE_SCRIPT_NAME.replace(".txt", "_TIMED.txt")
                if timed.is_file():
                    shutil.copy2(timed, final.with_name(final.stem + "_TIMED.txt"))
                self._set_item(item, "done")
                self._log(f"✅ {src.name} → {final}")
                self.msgq.put(("script_ready", item["iid"]))
                ok += 1
                continue
            if not engine_ok or not (work / ENGINE_FINAL_NAME).is_file():
                self._set_item(item, "failed")
                failed += 1
                self._log(f"❌ {src.name}: engine failed — see {work / 'run.log'}")
                continue
            raw = raw_video(work)
            (work / STATE_NAME).write_text(json.dumps(voice_now, ensure_ascii=False), encoding="utf-8")
            if self._effects_step(item, raw, final, work, s, ed, n, len(jobs)):
                ok += 1
            else:
                failed += 1
        self.msgq.put(("finished", f"Batch finished: {ok} done, {failed} failed" + (" (stopped)" if self.stop_event.is_set() else "")))

    def _effects_worker(self, jobs: list[dict], s: dict, ed: dict) -> None:
        root = Path(s["output_root"])
        ok = failed = 0
        for n, item in enumerate(jobs):
            if self.stop_event.is_set():
                break
            work = lang_work_dir(root, item["path"], s["language"])
            final = final_video(root, item["path"], s["language"])
            raw = raw_video(work)
            if raw and self._effects_step(item, raw, final, work, s, ed, n, len(jobs)):
                ok += 1
            else:
                failed += 1
        self.msgq.put(("finished", f"Effects re-applied: {ok} done, {failed} failed"))

    def _build_subtitles(self, raw: Path, final: Path, work: Path, ed: dict) -> Path:
        """Narration subtitles: Edge TTS word timing -> cues -> text check (per language) -> ASS (+ .srt)."""
        from concurrent.futures import ThreadPoolExecutor

        info = effects.probe_video(self.ffprobe, raw)
        cw, ch = effects.output_size(ed, info["width"], info["height"])     # subtitles live on the final canvas
        blocks, report = subtitles.block_timeline(work)
        code = str(report.get("language") or languages.DEFAULT)
        lang = languages.get(code)
        spans = None
        if report.get("tts_provider") == "voxcpm":
            # VoxCPM gives no word timing: Edge TTS word positions, stretched onto each block's speech.
            voice, rate = ENGINE_DEFAULT_VOICE if code == languages.DEFAULT else (lang["voices"][0], f"{lang['rate']:+d}%")
            spans = {}
            for row in report.get("blocks") or []:
                try:
                    span = subtitles.speech_span(Path(row["audio_file"]))
                except Exception:
                    span = None
                if span:
                    spans[row["sync_block_id"]] = span
        else:
            voice, rate = report.get("voice") or ENGINE_DEFAULT_VOICE[0], report.get("rate") or ENGINE_DEFAULT_VOICE[1]
        cache = work / "subtitle_cache"

        def prefetch(block: dict) -> None:
            try:
                subtitles.word_boundaries(block["text"], voice, rate, cache)
            except Exception:
                pass    # build_cues logs it and falls back to proportional timing
        with ThreadPoolExecutor(max_workers=6) as pool:   # flow blocks already carry their word timing
            list(pool.map(prefetch, [b for b in blocks if b["text"] and not b.get("words")]))
        style = {**effects.subtitle_style(ed, cw, ch), "char_w": lang["char_w"]}
        cues = subtitles.build_cues(blocks, voice, rate, cache, subtitles.line_capacity(cw, style["size"], lang["char_w"]),
                                    log=self._log, spans=spans, spaced=lang["spaced"])
        report_lines = []
        for c in cues:
            for issue in subtitles.text_issues(c["text"], code):
                report_lines.append(f"{c['bid']} {c['start']:.2f}s: {issue} | {c['text']}")
        (work / "subtitle_check.txt").write_text("\n".join(report_lines) or f"No {lang['label']} text problems found.",
                                                 encoding="utf-8")
        if report_lines:
            self._log(f"⚠️ {lang['label']} text check: {len(report_lines)} problem(s) — see {work / 'subtitle_check.txt'}")
        else:
            self._log(f"✓ {lang['label']} text check: {len(cues)} subtitle lines OK (no foreign/control characters"
                      + (", Unicode order OK)" if code == languages.DEFAULT else ")"))
        extents = subtitles.measure_extents([c["text"] for c in cues], cw, ch, style, work, self.ffmpeg,
                                            [c.get("breaks") for c in cues]) if style["style"] == "box" else None
        # The subtitles are burned in, so the .srt copy goes to FINALS\SRT_for_upload\: next to the video, players
        # (VLC, PotPlayer, MX Player) load a same-name .srt by themselves and every line showed twice (2026-10-12).
        srt = final.parent / "SRT_for_upload" / final.with_suffix(".srt").name
        srt.parent.mkdir(parents=True, exist_ok=True)
        subtitles.write_srt(cues, srt)
        final.with_suffix(".srt").unlink(missing_ok=True)
        return subtitles.write_ass(cues, work / "subtitles_mm.ass", cw, ch, style, extents)

    def _effects_step(self, item: dict, raw: Path, final: Path, work: Path, s: dict, ed: dict, n: int, total: int) -> bool:
        self._set_item(item, "effects")
        name = item["path"].name
        try:
            ass = None
            if ed["subs_enabled"]:
                self.msgq.put(("stage", f"{name} — Myanmar subtitles"))
                ass = self._build_subtitles(raw, final, work, ed)
            self.msgq.put(("stage", f"{name} — effects"))
            effects.apply_effects(
                self.ffmpeg, self.ffprobe, raw, final, ed, work, encoder=s["encoder"], log=self._log,
                progress=lambda f: self._progress(n, total, 0.92 + 0.08 * f), proc_holder=self.proc_holder,
                subtitle_ass=ass,
            )
        except Exception as exc:
            if self.stop_event.is_set():
                self._set_item(item, "stopped")
                return False
            self._set_item(item, "failed")
            self._log(f"❌ {item['path'].name}: effects failed — {exc}")
            return False
        self._set_item(item, "done")
        self._log(f"✅ {item['path'].name} → {final}   (watch this file; the work folder copy has NO effects)")
        review = work / "TIMELINE_REVIEW.txt"
        try:
            first = review.read_text(encoding="utf-8").splitlines()[0] if review.is_file() else ""
        except (OSError, IndexError):
            first = ""
        if "still disagree" in first:
            self._log(f"⚠️ {first} — see {review}")
        return True

    RESUME_WAITS = (120, 300, 600, 900, 900)   # seconds before each automatic resume

    def _run_engine_with_resume(self, engine_src: Path, name: str, work: Path, root: Path, s: dict,
                                n: int, total: int, memory_in: Path | None = None) -> bool:
        """Gemini overload or Edge TTS throttling stops the engine; its caches let it continue.

        Wait and resume up to len(RESUME_WAITS) times; a run that got further resets the count,
        so a long video can ride out several separate outages unattended.
        """
        tries = 0
        shared = work.parent / "gemini_timeline_cache" if (s.get("language") or languages.DEFAULT) != languages.DEFAULT else None
        while True:
            before = progress_marker(work, shared)
            if self._run_engine(engine_src, work, root, s, n, total, display_name=name, memory_in=memory_in):
                return True
            if self.stop_event.is_set():
                return False
            if getattr(self, "_engine_needs_attention", False):
                self._log(f"❌ {name}: {self._last_engine_error} (caches are kept; no automatic retry)")
                self.msgq.put(("stage", f"{name} — ရပ်ထားပါတယ်။ Gemini error ကို log မှာ ကြည့်ပေးပါ။"))
                return False
            if progress_marker(work, shared) > before:
                tries = 0
            if tries >= len(self.RESUME_WAITS):
                self._log(f"❌ {name}: engine still failing after {tries} automatic resumes")
                return False
            wait = self.RESUME_WAITS[tries]
            tries += 1
            self._log(f"⏳ {name}: engine stopped ({self._last_engine_error or 'see run.log'}) — "
                      f"auto-resume {tries}/{len(self.RESUME_WAITS)} in {wait // 60} min (caches are kept)")
            end = time.time() + wait
            while time.time() < end:
                if self.stop_event.wait(1.0):
                    return False
                left = int(end - time.time())
                self.msgq.put(("stage", f"{name} — waiting {left // 60}:{left % 60:02d} before auto-resume {tries}"))

    def _run_engine(self, src: Path, work: Path, root: Path, s: dict, n: int, total: int,
                    display_name: str = "", memory_in: Path | None = None) -> bool:
        from membership_access import require_vip
        require_vip("Original → Recap")
        cmd = App._engine_cmd(self, src, work, root, s, memory_in)       # (tests call these with a stand-in self)
        env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
        return App._run_engine_cmd(self, cmd, src, work, n, total, display_name, env)

    def _engine_cmd(self, src: Path, work: Path, root: Path, s: dict, memory_in: Path | None = None) -> list[str]:
        cmd = [
            sys.executable, "-X", "utf8", "-u", str(ENGINE), str(src),
            "--output-dir", str(work),
            "--gemini-env-file", s["gemini_env_path"],
            "--proxy", "",
            "--gemini-models", s["gemini_models"],
            "--gemini-timeout-ms", str(int(s["gemini_timeout_sec"]) * 1000),
            "--tts-voice", s["tts_voice"],
            "--tts-rate", f"{int(s['tts_rate_percent']):+d}%",
        ]
        if s["share_registry"]:      # one Output folder = one series: names, spellings and the story so far
            cmd += ["--registry-path", str(root / "CHARACTER_REGISTRY.json"), "--series-memory"]
            if memory_in:
                cmd += ["--story-memory-in", str(memory_in)]
        script_mode = s.get("output_mode") == "script"
        if script_mode:
            cmd += ["--script-only"]
        elif s.get("tts_provider") == "voxcpm":
            cmd += ["--tts-provider", "voxcpm", "--voxcpm-config", str(self._write_vox_config(work, s))]
        code = s.get("language") or languages.DEFAULT
        if code != languages.DEFAULT:     # lang_<code> folder: the Gemini analysis lives one level up
            cmd += ["--narration-language", code, "--timeline-cache-dir", str(work.parent / "gemini_timeline_cache")]
        if s.get("narration_style") == "flow":
            cmd += ["--narration-style", "flow"]
        if s.get("story_length", "full") in ("skip", "fit", "short", "short_steady", "medium", "recap"):
            cmd += ["--narration-length", s["story_length"]]
            if s["story_length"] == "recap":
                if s.get("recap_unit") == "percent":
                    cmd += ["--recap-percent", str(s.get("recap_minutes", 75))]
                else:
                    cmd += ["--recap-minutes", str(s.get("recap_minutes", 12))]
        if s.get("whisper_check", True):
            cmd += ["--whisper-check"]
        if short_pause(s) is not None and not script_mode:
            cmd += ["--tts-pause", f"{short_pause(s):.2f}"]
        if s.get("smooth_motion", True) and not script_mode:
            cmd += ["--smooth-motion"]
            if float(s.get("smooth_below", 0.9) or 0.9) < 0.9:
                cmd += ["--smooth-below", f"{float(s['smooth_below']):g}"]
        if s.get("slow_style", "rife") != "rife" and not script_mode:
            cmd += ["--slow-style", s["slow_style"], "--freeze-below", str(s.get("freeze_below", 0.6))]
        if s.get("analysis_speed", 1) != 1:
            cmd += ["--analysis-speed", str(s["analysis_speed"])]
        style_file = write_telling_style(work, s)
        if style_file:
            cmd += ["--story-style-file", str(style_file)]
        return cmd

    def _run_engine_cmd(self, cmd: list[str], src: Path, work: Path, n: int, total: int, display_name: str,
                        env: dict) -> bool:
        run_log = work / "run.log"
        self._last_engine_error = ""
        self._engine_needs_attention = False
        state = {"clips": 1}
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                                    errors="replace", bufsize=1, env=env, cwd=str(work), creationflags=CREATE_NO_WINDOW)
        except Exception as exc:
            self._log(f"❌ Cannot start engine: {exc}")
            return False
        self.proc_holder["proc"] = proc
        with run_log.open("a", encoding="utf-8", buffering=1) as log_f:
            log_f.write(f"\n===== {datetime.now():%Y-%m-%d %H:%M:%S} =====\n{' '.join(cmd)}\n")
            for line in proc.stdout:
                line = line.rstrip("\n")
                log_f.write(line + "\n")
                if "GEMINI_NEEDS_ATTENTION" in line:
                    self._engine_needs_attention = True
                    self._last_engine_error = line.strip()[:600]
                elif ("Error" in line or "failed" in line) and not line.startswith("@@VOX@@") and not self._engine_needs_attention:
                    self._last_engine_error = line.strip()[:600]
                self._engine_line(line, display_name or src.name, state, n, total)
        rc = proc.wait()
        self.proc_holder["proc"] = None
        return rc == 0

    # ------------------------------------------------------------------ telling style
    def _style_dialog(self) -> None:
        """Own notes + a sample paragraph for the telling style, and a preview of ~1 min of the selected file."""
        if self.style_win is not None and self.style_win.winfo_exists():
            self.style_win.lift()
            return
        win = self.style_win = tk.Toplevel(self)
        win.title("Telling style — notes, sample, preview")
        win.configure(bg=BG)
        win.geometry("900x760")
        win.columnconfigure(0, weight=1)
        ttk.Label(win, text="Your notes (how to tell it — e.g. like telling a friend, short sentences, calm in sad "
                            "parts; no ဗျာ / ခင်ဗျာ):").grid(row=0, column=0, sticky="w", padx=8, pady=(8, 2))
        notes = tk.Text(win, height=6, wrap="word", bg=FIELD, fg=FG, insertbackground=FG, font=("Myanmar Text", 11))
        notes.grid(row=1, column=0, sticky="nsew", padx=8)
        notes.insert("1.0", self.style_notes)
        ttk.Label(win, text="Sample paragraph you like (only its way of telling is copied, never its people or "
                            "events):").grid(row=2, column=0, sticky="w", padx=8, pady=(8, 2))
        sample = tk.Text(win, height=7, wrap="word", bg=FIELD, fg=FG, insertbackground=FG, font=("Myanmar Text", 11))
        sample.grid(row=3, column=0, sticky="nsew", padx=8)
        sample.insert("1.0", self.style_sample)
        bar = ttk.Frame(win)
        bar.grid(row=4, column=0, sticky="ew", padx=8, pady=6)
        status = tk.StringVar(value="Preview: select a file in the queue that already has its Gemini analysis "
                                    "(after a Script only or Video run).")
        ttk.Label(win, textvariable=status, style="Muted.TLabel", wraplength=860).grid(row=5, column=0, sticky="w", padx=8)
        out = tk.Text(win, height=14, wrap="word", bg=FIELD, fg=FG, font=("Myanmar Text", 11))
        out.grid(row=6, column=0, sticky="nsew", padx=8, pady=(4, 8))
        win.rowconfigure(6, weight=1)

        def save() -> None:
            self.style_notes = notes.get("1.0", "end").strip()
            self.style_sample = sample.get("1.0", "end").strip()
            self._persist_soon()
            status.set("Saved. The next START writes the stories in this style (finished files are made again).")

        def preview() -> None:
            save()
            self._preview_style(status, out)

        ttk.Button(bar, text="Save", command=save).pack(side="left")
        ttk.Button(bar, text=f"▶ Preview ~{STYLE_PREVIEW_SEC} s of the selected file", command=preview).pack(side="left", padx=8)
        ttk.Button(bar, text="Close", command=lambda: (save(), win.destroy())).pack(side="right")

    def _preview_style(self, status: tk.StringVar, out: tk.Text) -> None:
        if self.worker and self.worker.is_alive():
            status.set("A batch is running — preview after it.")
            return
        item = self._selected_item()
        s = self._settings()
        root = Path(s["output_root"]) if s["output_root"] else None
        path = item.get("path") if item else None
        if not item or not root or not path:
            status.set("Select a file in the queue first (and set the Output folder).")
            return
        work = lang_work_dir(root, Path(path), s.get("language") or languages.DEFAULT)
        if not (work / "GEMINI_STORY_TIMELINE.json").exists():
            status.set("This file has no Gemini analysis yet: run it once (Script only is enough), then preview.")
            return
        cmd = self._engine_cmd(Path(path), work, root, s) + ["--style-preview", str(STYLE_PREVIEW_SEC)]
        status.set("Writing the preview (a few Gemini requests)…")

        def run() -> None:
            env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
            try:
                p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", env=env,
                                   cwd=str(work), creationflags=CREATE_NO_WINDOW)
                text = (work / "STYLE_PREVIEW.txt").read_text(encoding="utf-8") if p.returncode == 0 else ""
                msg = "Preview ready." if text else "Preview failed: " + (p.stdout + p.stderr).strip()[-300:]
            except Exception as exc:
                text, msg = "", f"Preview failed: {exc}"

            def show() -> None:
                status.set(msg)
                out.delete("1.0", "end")
                out.insert("1.0", text)
            self.after(0, show)
        threading.Thread(target=run, daemon=True).start()

    def _engine_line(self, line: str, name: str, state: dict, n: int, total: int) -> None:
        stripped = line.strip()
        if not stripped or "automatic function calling" in stripped:
            return
        if stripped.startswith("[Gemini try]"):
            self.msgq.put(("stage", f"{name} — {stripped}"))
            return
        if stripped.startswith("@@VOX@@"):       # VoxCPM link events -> Link tabs / status (not the main log)
            try:
                self.msgq.put(("vox", json.loads(stripped[len("@@VOX@@"):])))
            except ValueError:
                pass
            return
        self._log(stripped)
        frac = None
        stage = None
        m = RX_CLIPS.search(line)
        if m:
            state["clips"] = max(1, int(m.group(1)))
        m = RX_CLIP.search(line)
        if m:
            i, k = int(m.group(1)), int(m.group(2))
            frac, stage = 0.02 + 0.46 * (i - 1) / max(1, k), f"Gemini clip {i}/{k}"
        m = RX_STORY.search(line)
        if m:
            i, k = int(m.group(1)), int(m.group(2))
            frac, stage = 0.48 + 0.14 * i / max(1, k), f"Story {i}/{k}"
        m = RX_TTS.search(line)
        if m:
            i, k = int(m.group(1)), int(m.group(2))
            frac, stage = 0.62 + 0.10 * i / max(1, k), f"TTS {i}/{k}"
        m = RX_RENDER.search(line)
        if m:
            i, k = int(m.group(1)), int(m.group(2))
            frac, stage = 0.72 + 0.20 * i / max(1, k), f"Render {i}/{k}"
        if RX_FINAL.search(line):
            frac, stage = 0.92, "Engine done"
        if "SCRIPT READY" in line:
            frac, stage = 0.98, "Script done"
        if stage:
            self.msgq.put(("stage", f"{name} — {stage}"))
        if frac is not None:
            self._progress(n, total, frac)

    # ------------------------------------------------------------------ message pump
    def _pump(self) -> None:
        try:
            while True:
                kind, payload = self.msgq.get_nowait()
                if kind == "log":
                    self._append_log(str(payload))
                elif kind == "item":
                    item = self.items.get(str(payload))
                    if item:
                        self._show_item(item)
                        self._script_button_state()
                elif kind == "script_ready":
                    self._script_ready(str(payload))
                elif kind == "duration":
                    iid, dur = payload
                    if iid in self.items:
                        self.items[iid]["duration"] = dur
                        self._show_item(self.items[iid])
                elif kind == "link_info":
                    self._link_info(*payload)
                elif kind == "stage":
                    self.stage.set(str(payload))
                elif kind == "progress":
                    file_frac, all_frac = payload
                    self.file_bar["value"] = int(1000 * max(0.0, min(1.0, file_frac)))
                    self.all_bar["value"] = int(1000 * max(0.0, min(1.0, all_frac)))
                elif kind == "text_ready":
                    key, img = payload
                    self._text_cache[key] = img
                    self._text_pending.discard(key)
                    self._redraw()
                elif kind == "test_voice_done":
                    self.test_voice_btn.configure(state="normal")
                    self.vox_test_btn.configure(state="normal")
                    self.status.set("READY")
                elif kind == "vox":
                    self._vox_event(payload)
                elif kind == "vox_test":
                    self._vox_test_result(*payload)
                elif kind == "text_failed":
                    key, err = payload
                    self._text_pending.discard(key)
                    self._append_log(f"⚠️ Text render (Chromium) failed, preview shows plain text: {err[:300]}")
                elif kind == "finished":
                    self._append_log(str(payload))
                    self.status.set("READY")
                    self.stage.set(str(payload))
                    self.start_btn.configure(state="normal")
                    self.reapply_btn.configure(state="normal")
                    self.stop_btn.configure(state="disabled")
                    for item in self.items.values():
                        if item["status"] in ("running", "effects"):
                            item["status"] = "stopped"
                            self._show_item(item)
                    self._script_button_state()
                    waiting = [self.items[i] for i in self.after_batch if i in self.items]
                    self.after_batch = []
                    if waiting and not self.stop_event.is_set():
                        self._start_waiting(waiting)
        except queue.Empty:
            pass
        self.after(120, self._pump)

    def _on_close(self) -> None:
        if self.worker and self.worker.is_alive():
            if not messagebox.askyesno("Quit", "A batch is running. Stop it and quit?\n(The engine resumes from its caches next time.)"):
                return
            self._stop()
        self._persist()
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
