No font files are bundled.

Windows normally has "Myanmar Text". If you want another font, install it on Windows
(e.g. Noto Sans Myanmar) and change the CSS font-family in templates/thumbnail.html.
