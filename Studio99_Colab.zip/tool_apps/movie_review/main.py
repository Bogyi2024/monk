from __future__ import annotations

import argparse
import sys
from pathlib import Path

from app.config import load_settings
from movie_review_profiles import accepts_genres
from app.pipeline import run_pipeline
from app.state import MovieRegistry
from app.tmdb import TMDBClient


def _configure_windows_console() -> None:
    """Keep Burmese progress/output safe under redirected Windows consoles."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure:
            reconfigure(encoding="utf-8", errors="backslashreplace")


def parse_args():
    p = argparse.ArgumentParser(
        description="Research movie reviews, write an original Burmese review, render a thumbnail, and optionally build a Reel."
    )
    p.add_argument("title", nargs="?", help='Movie title, e.g. "The Matrix"')
    p.add_argument("--auto", action="store_true", help="Pick the first unprocessed quality movie from TMDB trending/popular.")
    p.add_argument("--profile", choices=["movie_general", "movie_horror_thriller"], default=None)
    p.add_argument("--force", action="store_true", help="Allow regenerating a movie already recorded in the duplicate registry.")
    p.add_argument("--year", type=int, default=None)
    p.add_argument("--platform", default="facebook", choices=["facebook", "youtube", "tiktok", "web"])
    p.add_argument("--style", default="cinematic")
    p.add_argument("--spoilers", action="store_true")
    p.add_argument("--fal", action="store_true", help="Use fal multi-reference image editing before Chromium render.")
    p.add_argument("--require-fal", action="store_true", help="Fail instead of silently falling back when fal fails.")
    p.add_argument("--video", action="store_true", help="Also build a review Reel MP4.")
    p.add_argument("--media-dir", default=None, help="Folder containing extra/local video files.")
    p.add_argument("--voice", default=None, help="Optional WAV/MP3 narration file. If omitted, Edge TTS or TTS_COMMAND is used.")
    p.add_argument("--youtube-url", default=None, help="Public YouTube trailer URL for Reel visuals.")
    p.add_argument("--auto-trailer", action="store_true", help="Automatically find/select an official trailer and use it for Reel visuals.")
    return p.parse_args()


def main():
    _configure_windows_console()
    args = parse_args()
    settings = load_settings(profile=args.profile)

    missing = []
    if not settings.gemini_writer_api_key:
        missing.append("GEMINI_WRITER_API_KEY or GEMINI_API_KEY")
    if not settings.tmdb_bearer_token and not __import__("os").environ.get("STUDIO99_TMDB_PROXY"):  # Studio99
        missing.append("TMDB_BEARER_TOKEN")
    if missing:
        print("Missing .env values: " + ", ".join(missing), file=sys.stderr)
        print("Copy .env.example to .env and fill the keys.", file=sys.stderr)
        raise SystemExit(2)

    if not args.title and not args.auto:
        print("Provide a movie title or use --auto.", file=sys.stderr)
        raise SystemExit(2)

    registry = MovieRegistry(settings.state_dir / "processed_movies.json")
    imported = registry.import_existing_outputs(settings.output_dir)
    if imported:
        print(f"[Duplicate registry] imported {imported} existing output(s).")
    tmdb = TMDBClient(settings.tmdb_bearer_token)
    if args.auto:
        selected = None
        candidates = tmdb.discover_movies()
        for candidate in candidates:
            if args.force or not registry.is_processed(candidate["tmdb_id"], candidate["title"], candidate["year"]):
                candidate_meta = tmdb.get_movie(candidate["tmdb_id"], candidate["title"], candidate["year"])
                if not accepts_genres(settings.movie_review_profile, candidate_meta.genres):
                    continue
                selected = candidate
                break
        if not selected:
            raise RuntimeError("TMDB auto-selection found no unprocessed movie candidates.")
        meta = candidate_meta
        print(f"[Auto movie] {meta.title} ({meta.year or 'unknown'}) | TMDB {meta.tmdb_id} | {selected['source']}")
    else:
        meta = tmdb.find_movie(args.title, args.year)

    if not accepts_genres(settings.movie_review_profile, meta.genres):
        raise RuntimeError("Movie does not match Horror / Thriller profile: TMDB must list Horror, Thriller or Mystery.")

    if registry.is_processed(meta.tmdb_id, meta.title, meta.year) and not args.force:
        raise RuntimeError(
            f"Duplicate blocked: {meta.title} ({meta.year or 'unknown'}) / TMDB {meta.tmdb_id}. "
            "Use --force only for an intentional regeneration."
        )

    registry.claim(meta)

    try:
        work_dir = run_pipeline(
            settings=settings,
            title=meta.title,
            year=meta.year,
            platform=args.platform,
            style=args.style,
            spoilers=args.spoilers,
            use_fal=args.fal or args.require_fal,
            make_video=args.video,
            media_dir=Path(args.media_dir) if args.media_dir else None,
            voice_path=Path(args.voice) if args.voice else None,
            youtube_url=args.youtube_url,
            auto_trailer=args.auto_trailer,
            movie_meta=meta,
            require_fal=args.require_fal,
        )
        registry.mark_generated(meta, work_dir / "manifest.json")
    except Exception as exc:
        registry.mark_failed(meta, str(exc))
        raise


if __name__ == "__main__":
    main()
