from __future__ import annotations

import asyncio
import shutil
import subprocess
from pathlib import Path

import edge_tts

from .models import VideoBeat


async def _synth(text: str, output: Path, voice: str, rate: str, volume: str):
    await edge_tts.Communicate(text=text, voice=voice, rate=rate, volume=volume).save(str(output))


def _need_bin(name: str) -> str:
    path = shutil.which(name)
    if not path:
        raise RuntimeError(f"{name} not found in PATH.")
    return path


def probe_audio_duration(path: Path) -> float:
    ffprobe = _need_bin("ffprobe")
    proc = subprocess.run(
        [
            ffprobe, "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            str(path),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=30,
    )
    try:
        return max(0.0, float(proc.stdout.strip()))
    except Exception:
        return 0.0


def synthesize_edge_tts(
    text_path: Path,
    output_path: Path,
    voice: str = "my-MM-ThihaNeural",
    rate: str = "+0%",
    volume: str = "+0%",
) -> Path:
    text = text_path.read_text(encoding="utf-8").strip()
    if not text:
        raise RuntimeError("voiceover.txt is empty")
    asyncio.run(_synth(text, output_path, voice, rate, volume))
    if not output_path.exists():
        raise RuntimeError("Edge TTS did not create audio")
    return output_path


def synthesize_edge_tts_beats(
    beats: list[VideoBeat],
    work_dir: Path,
    output_path: Path,
    voice: str = "my-MM-ThihaNeural",
    rate: str = "+0%",
    volume: str = "+0%",
) -> tuple[Path, list[float]]:
    """Synthesize each narration beat separately so visual durations can use real audio timing."""
    parts_dir = work_dir / "tts_parts"
    parts_dir.mkdir(parents=True, exist_ok=True)

    part_paths: list[Path] = []
    durations: list[float] = []

    async def _run_all():
        for i, beat in enumerate(beats):
            text = (beat.narration or "").strip()
            if not text:
                text = "..."
            part = parts_dir / f"beat_{i:02d}.mp3"
            print(f"[video] TTS beat {i+1}/{len(beats)}...")
            await _synth(text, part, voice, rate, volume)
            part_paths.append(part)

    asyncio.run(_run_all())

    for p in part_paths:
        d = probe_audio_duration(p)
        durations.append(max(0.25, d))

    ffmpeg = _need_bin("ffmpeg")
    list_file = parts_dir / "concat_audio.txt"
    list_file.write_text(
        "\n".join(f"file '{p.as_posix()}'" for p in part_paths) + "\n",
        encoding="utf-8",
    )

    proc = subprocess.run(
        [
            ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
            "-f", "concat", "-safe", "0", "-i", str(list_file),
            "-c:a", "libmp3lame", "-b:a", "128k", str(output_path),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=180,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr[-4000:])
    if not output_path.exists():
        raise RuntimeError("Edge TTS beat concat did not create narration audio")

    final_duration = probe_audio_duration(output_path)
    sum_parts = sum(durations)
    if final_duration > 0 and sum_parts > 0:
        # Small MP3 padding/encoder differences are distributed across all beats.
        ratio = final_duration / sum_parts
        durations = [max(0.25, d * ratio) for d in durations]

    return output_path, durations
