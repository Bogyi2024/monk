from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Any

from .models import MovieMeta, ReviewPackage


def _to_file_uri(path_str: str | None) -> str | None:
    if not path_str:
        return None
    try:
        p = Path(path_str).expanduser().resolve()
        return p.as_uri()
    except Exception:
        return None


async def _download(url: str, dest: Path) -> Path:
    import httpx

    async with httpx.AsyncClient(timeout=60, follow_redirects=True) as client:
        r = await client.get(url)
        r.raise_for_status()
        dest.write_bytes(r.content)
    return dest


def _safe_error(exc: BaseException) -> str:
    return " ".join(str(exc).split())[:300]


def _write_render_source_artifact(
    work_dir: Path,
    source_audit: dict[str, Any],
    poster_sources: list[dict[str, str]],
) -> Path:
    payload = {**source_audit, "poster_sources": poster_sources}
    path = work_dir / "thumbnail_render_source.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


async def _resolve_background(
    meta: MovieMeta,
    ai_background_url: str | None,
    images_dir: Path,
) -> tuple[str, dict[str, Any]]:
    """Download the first usable truthful source, or use the local CSS gradient."""
    candidates: list[tuple[str, str, str]] = []
    if ai_background_url:
        candidates.append(("fal_composite", ai_background_url, "ai_background.png"))
    candidates.extend(
        ("tmdb_backdrop", url, f"backdrop_{idx + 1}.jpg")
        for idx, url in enumerate(meta.backdrop_urls[:3])
    )
    candidates.extend(
        ("tmdb_poster", url, f"background_poster_{idx + 1}.jpg")
        for idx, url in enumerate(meta.poster_urls[:3])
    )

    errors: list[dict[str, str]] = []
    for kind, url, filename in candidates:
        try:
            path = await _download(url, images_dir / filename)
            return path.resolve().as_uri(), {
                "schema_version": 1,
                "background_kind": kind,
                "background_url": url,
                "local_background": str(path.resolve()),
                "download_errors": errors,
            }
        except Exception as exc:
            errors.append({"kind": kind, "url": url, "error": _safe_error(exc)})

    return "", {
        "schema_version": 1,
        "background_kind": "local_gradient",
        "background_url": "",
        "local_background": "",
        "download_errors": errors,
    }


async def render_thumbnail(
    template_dir: Path,
    work_dir: Path,
    meta: MovieMeta,
    review: ReviewPackage,
    ai_background_url: str | None = None,
    width: int = 1280,
    height: int = 720,
) -> Path:
    work_dir.mkdir(parents=True, exist_ok=True)
    images_dir = work_dir / "images"
    images_dir.mkdir(exist_ok=True)

    background, source_audit = await _resolve_background(meta, ai_background_url, images_dir)

    posters: list[str] = []
    poster_sources: list[dict[str, str]] = []
    for idx, url in enumerate(meta.poster_urls[:3]):
        try:
            p = await _download(url, images_dir / f"poster_{idx+1}.jpg")
            posters.append(p.resolve().as_uri())
            poster_sources.append({"url": url, "local_path": str(p.resolve())})
        except Exception as exc:
            poster_sources.append({"url": url, "error": _safe_error(exc)})

    _write_render_source_artifact(work_dir, source_audit, poster_sources)

    title_font_family = os.getenv("TITLE_FONT_FAMILY", "KoZ 036 Uni").strip() or "KoZ 036 Uni"
    body_font_family = os.getenv("BODY_FONT_FAMILY", "Burma-020 Thin").strip() or "Burma-020 Thin"
    title_font_uri = _to_file_uri(os.getenv("TITLE_FONT_PATH", r"C:\Users\MYOSI\AppData\Local\Microsoft\Windows\Fonts\KOZ036UNI-REGULAR.TTF").strip() or None)
    body_font_uri = _to_file_uri(os.getenv("BODY_FONT_PATH", "").strip() or None)

    from jinja2 import Environment, FileSystemLoader, select_autoescape
    from playwright.async_api import async_playwright

    env = Environment(
        loader=FileSystemLoader(str(template_dir)),
        autoescape=select_autoescape(["html", "xml"]),
    )
    template = env.get_template("thumbnail.html")
    html = template.render(
        width=width,
        height=height,
        background=background,
        posters=posters,
        movie_title=meta.title,
        year=meta.year or "",
        thumbnail_title=review.thumbnail_title,
        thumbnail_kicker=review.thumbnail_kicker,
        thumbnail_badge=review.thumbnail_badge,
        rating=review.rating_text,
        title_font_family=title_font_family,
        body_font_family=body_font_family,
        title_font_uri=title_font_uri,
        body_font_uri=body_font_uri,
    )

    html_path = work_dir / "thumbnail.html"
    html_path.write_text(html, encoding="utf-8")
    output_path = work_dir / "thumbnail.png"

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": width, "height": height}, device_scale_factor=1)
        await page.goto(html_path.resolve().as_uri(), wait_until="load")
        try:
            await page.wait_for_function("() => document.fonts ? document.fonts.status === 'loaded' : true", timeout=5000)
        except Exception:
            pass
        await page.wait_for_timeout(350)
        await page.screenshot(path=str(output_path), full_page=False)
        await browser.close()

    return output_path


def render_thumbnail_sync(*args, **kwargs) -> Path:
    return asyncio.run(render_thumbnail(*args, **kwargs))
