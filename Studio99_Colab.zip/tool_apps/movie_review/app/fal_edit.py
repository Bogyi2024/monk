from __future__ import annotations

import json
import os
from collections.abc import Iterable
from pathlib import Path
from typing import Any, Callable


class FalContentPolicyError(RuntimeError):
    """All safe reference-image retries were rejected by fal's content policy."""

    def __init__(self, message: str, attempts: list[dict[str, Any]]):
        super().__init__(message)
        self.attempts = attempts


def _walk_payload(value: Any) -> Iterable[Any]:
    """Yield nested exception payload values without relying on a fal SDK type."""
    yield value
    if isinstance(value, dict):
        for nested in value.values():
            yield from _walk_payload(nested)
    elif isinstance(value, (list, tuple)):
        for nested in value:
            yield from _walk_payload(nested)


def is_content_policy_violation(exc: BaseException) -> bool:
    markers = (
        "content_policy_violation",
        "content policy",
        "content checker",
        "safety checker",
        "flagged by a content",
    )
    values: list[Any] = [exc, *getattr(exc, "args", ())]
    return any(
        marker in str(value).lower()
        for value in values
        for marker in markers
    )


def _flagged_reference_indices(exc: BaseException, image_urls: list[str]) -> set[int]:
    """Extract only explicit per-image policy locations; never guess from body input."""
    flagged: set[int] = set()
    payloads: list[Any] = [*getattr(exc, "args", ())]
    for payload in payloads:
        for value in _walk_payload(payload):
            if not isinstance(value, dict):
                continue
            loc = value.get("loc")
            if isinstance(loc, (list, tuple)) and "image_urls" in loc:
                for item in loc[loc.index("image_urls") + 1 :]:
                    if isinstance(item, int) and 0 <= item < len(image_urls):
                        flagged.add(item)
            for key in ("flagged_index", "image_index"):
                item = value.get(key)
                if isinstance(item, int) and 0 <= item < len(image_urls):
                    flagged.add(item)
            for key in ("flagged_indices", "image_indices"):
                items = value.get(key)
                if isinstance(items, (list, tuple)):
                    flagged.update(
                        item for item in items if isinstance(item, int) and 0 <= item < len(image_urls)
                    )
    return flagged


def _safe_error(exc: BaseException) -> str:
    """Keep diagnostics useful while preventing huge request bodies in artifacts."""
    message = " ".join(str(exc).split())
    return message[:500]


def _write_audit(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def create_cinematic_composite(
    image_urls: list[str],
    movie_title: str,
    model_id: str,
    fal_key: str,
    attempt_audit: list[dict[str, Any]] | None = None,
    subscribe_fn: Callable[..., Any] | None = None,
) -> str:
    """
    Generate an OPTIONAL text-free cinematic composite from up to 4 source images.
    Burmese text is added later by Chromium, not by the image model.
    """
    if not fal_key:
        raise RuntimeError("FAL_KEY is missing.")
    refs = list(dict.fromkeys(url for url in image_urls[:4] if url))
    if not refs:
        raise RuntimeError("No images available for fal composition.")

    os.environ["FAL_KEY"] = fal_key
    if subscribe_fn is None:
        try:
            import fal_client
        except ImportError as exc:
            raise RuntimeError("fal-client is not installed.") from exc
        subscribe_fn = fal_client.subscribe

    prompt = f"""
Create a cinematic 16:9 movie-review thumbnail background for "{movie_title}" by
rearranging only the visual material present in the supplied reference images.
Do not invent or add characters, costumes, locations, actions, story events, props,
logos, or plot details that are not visible in those references. Editorial layout,
cropping, color grading, contrast, and lighting adjustments are allowed. Use one
dominant focal subject, layered secondary imagery, and clean negative space on the
left/bottom for later typography. NO text, NO letters, NO new logos, NO badges.
"""

    audit = attempt_audit if attempt_audit is not None else []
    candidates: list[list[str]] = [refs]
    attempted: set[tuple[str, ...]] = set()
    policy_seen = False

    while candidates:
        candidate = candidates.pop(0)
        key = tuple(candidate)
        if not candidate or key in attempted:
            continue
        attempted.add(key)
        record: dict[str, Any] = {
            "attempt": len(audit) + 1,
            "reference_count": len(candidate),
            "reference_urls": candidate,
        }
        try:
            result = subscribe_fn(
                model_id,
                arguments={
                    "prompt": prompt,
                    "image_urls": candidate,
                    "image_size": {"width": 1280, "height": 720},
                    "num_images": 1,
                    "output_format": "png",
                    "enable_safety_checker": True,
                },
                with_logs=False,
            )
            images = result.get("images") or []
            if not images or not images[0].get("url"):
                raise RuntimeError("fal returned no image.")
            record["status"] = "succeeded"
            audit.append(record)
            return images[0]["url"]
        except Exception as exc:
            if not is_content_policy_violation(exc):
                record.update({"status": "failed", "reason": type(exc).__name__, "error": _safe_error(exc)})
                audit.append(record)
                if not policy_seen:
                    raise
                continue

            policy_seen = True
            flagged = _flagged_reference_indices(exc, candidate)
            record.update(
                {
                    "status": "blocked",
                    "reason": "content_policy_violation",
                    "explicit_flagged_indices": sorted(flagged),
                    "error": _safe_error(exc),
                }
            )
            audit.append(record)

            # Prefer a precise removal when the API identifies a per-image index.
            # A field-level error (the common 422 shape) is ambiguous, so isolate
            # references one at a time instead of bypassing or weakening safety.
            reduced = [url for idx, url in enumerate(candidate) if idx not in flagged]
            if flagged and reduced:
                candidates.insert(0, reduced)
            for url in refs:
                if url not in {candidate[idx] for idx in flagged}:
                    candidates.append([url])

    if policy_seen:
        raise FalContentPolicyError(
            "fal content policy blocked every safe reference-image retry.",
            audit,
        )
    raise RuntimeError("fal returned no usable image after retry attempts.")


def resolve_fal_background(
    settings: Any,
    meta: Any,
    work_dir: Path,
    require_fal: bool,
) -> tuple[str | None, bool]:
    """Create an optional composite while treating policy rejection as a safe fallback."""
    refs = (meta.backdrop_urls[:1] + meta.poster_urls[:3])[:4]
    attempts: list[dict[str, Any]] = []
    audit: dict[str, Any] = {
        "schema_version": 1,
        "model": settings.fal_image_model,
        "safety_checker_enabled": True,
        "source_reference_urls": refs,
        "attempts": attempts,
    }
    try:
        background_url = create_cinematic_composite(
            refs,
            meta.title,
            settings.fal_image_model,
            settings.fal_key,
            attempt_audit=attempts,
        )
    except FalContentPolicyError as exc:
        # A policy block is not an invitation to disable safety. The thumbnail
        # renderer will use a downloaded TMDB source or its local CSS gradient.
        if exc.attempts is not attempts:
            audit["attempts"] = exc.attempts
        audit.update(
            {
                "outcome": "fallback",
                "fallback_reason": "content_policy_violation",
                "message": str(exc),
            }
        )
        _write_audit(work_dir / "fal_generation_attempts.json", audit)
        print("[4/5] fal policy blocked the references; using truthful TMDB/local composition.")
        return None, False
    except Exception as exc:
        audit.update(
            {
                "outcome": "failed",
                "fallback_reason": type(exc).__name__,
                "message": _safe_error(exc),
            }
        )
        _write_audit(work_dir / "fal_generation_attempts.json", audit)
        if require_fal:
            raise RuntimeError(f"Required fal model failed: {exc}") from exc
        print(f"[4/5] fal failed; fallback to normal composition: {exc}")
        return None, False

    audit.update({"outcome": "generated", "generated_url": background_url})
    _write_audit(work_dir / "fal_generation_attempts.json", audit)
    (work_dir / "fal_background_url.txt").write_text(background_url, encoding="utf-8")
    return background_url, True
