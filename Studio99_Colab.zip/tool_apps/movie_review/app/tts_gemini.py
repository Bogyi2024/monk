from __future__ import annotations

import base64
import os
import shutil
import subprocess
import wave
from pathlib import Path
from typing import Any

from google import genai
from google.genai import types


def _audio_bytes(response: Any) -> bytes:
    for candidate in getattr(response, "candidates", None) or []:
        content = getattr(candidate, "content", None)
        for part in getattr(content, "parts", None) or []:
            inline = getattr(part, "inline_data", None)
            data = getattr(inline, "data", None) if inline is not None else None
            if not data:
                continue
            if isinstance(data, str):
                data = base64.b64decode(data)
            raw = bytes(data)
            if len(raw) >= 1000:
                return raw
    raise RuntimeError("Gemini TTS returned no usable audio payload")


def _write_wav(path: Path, audio: bytes, sample_rate: int = 24000) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if audio[:4] == b"RIFF":
        path.write_bytes(audio)
        return
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        wav.writeframes(audio)


def _ffmpeg() -> str:
    configured = str(os.getenv("FFMPEG_PATH") or "").strip()
    for candidate in (configured, r"C:\ffmpeg\bin\ffmpeg.exe"):
        if candidate and Path(candidate).is_file():
            return str(Path(candidate).resolve())
    found = shutil.which("ffmpeg")
    if found:
        return found
    raise FileNotFoundError("ffmpeg not found for Gemini TTS speed adjustment")


def synthesize_gemini_tts(
    text: str,
    output_path: Path,
    *,
    api_keys: list[str],
    key_aliases: list[str] | None = None,
    model: str = "gemini-3.1-flash-tts-preview",
    voice: str = "Kore",
    speed: float = 1.08,
    sample_rate: int = 24000,
) -> Path:
    script = str(text or "").strip()
    if not script:
        raise RuntimeError("Movie Review Gemini TTS script is empty")
    if not api_keys:
        raise RuntimeError("Movie Review Gemini TTS has no Google AI Studio API key")

    aliases = list(key_aliases or [])
    failures: list[str] = []
    prompt = f"""
Read ONLY the Burmese movie-review script below.

VOICE DIRECTION:
- Use one consistent adult Burmese narrator for the entire recording.
- Sound crystal-clear, bright, confident, energetic, and engaging, like a modern movie-page presenter.
- Use a slightly brisk natural pace. Do not sound slow, sleepy, gloomy, breathy, robotic, or over-dramatic.
- Keep Burmese consonants crisp and every sentence easy to understand.
- Use short natural pauses between paragraphs; avoid long dramatic pauses.
- Do not read labels, directions, or add any words not present in the script.

SCRIPT:
{script}
""".strip()

    raw_path = output_path.with_name(output_path.stem + "_raw.wav")
    for index, key in enumerate(api_keys):
        alias = aliases[index] if index < len(aliases) else f"key_{index + 1}"
        try:
            print(f"[video] Google AI Studio TTS -> {alias} | model={model} | voice={voice}")
            client = genai.Client(api_key=key, http_options=types.HttpOptions(timeout=180000))
            response = client.models.generate_content(
                model=model,
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_modalities=["AUDIO"],
                    speech_config=types.SpeechConfig(
                        voice_config=types.VoiceConfig(
                            prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name=voice)
                        )
                    ),
                ),
            )
            _write_wav(raw_path, _audio_bytes(response), sample_rate=sample_rate)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            pace = max(0.75, min(1.35, float(speed)))
            if abs(pace - 1.0) < 0.005:
                os.replace(raw_path, output_path)
            else:
                result = subprocess.run(
                    [_ffmpeg(), "-y", "-i", str(raw_path), "-filter:a", f"atempo={pace:.3f}", str(output_path)],
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                )
                if result.returncode != 0 or not output_path.exists() or output_path.stat().st_size < 1000:
                    raise RuntimeError(f"Gemini TTS speed adjustment failed: {result.stderr[-1200:]}")
                raw_path.unlink(missing_ok=True)
            print(f"[video] Google AI Studio TTS ready -> {output_path.name} | voice={voice} | speed={pace:.2f}x")
            return output_path
        except Exception as exc:
            failures.append(f"{alias}: {str(exc)[-800:]}")
            raw_path.unlink(missing_ok=True)
            output_path.unlink(missing_ok=True)
            print(f"[video] Gemini TTS {alias} unavailable; rotating to next key")
    raise RuntimeError("Movie Review Gemini TTS key pool exhausted: " + " | ".join(failures[-len(api_keys):]))

