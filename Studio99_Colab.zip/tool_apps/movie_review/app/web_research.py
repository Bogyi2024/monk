from __future__ import annotations

from dataclasses import dataclass, asdict
import re
from typing import Iterable
from urllib.parse import unquote, urlsplit, urlunsplit

import httpx
from ddgs import DDGS

from .models import MovieMeta


@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str
    score: float = 0.0
    backend: str = ""
    query: str = ""
    raw_content: str = ""
    relevance_score: float = 0.0
    source_kind: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


class HybridMovieSearch:
    """Tavily-first movie-review search with DDGS fallback.

    This module performs web search only. It does not call Gemini Search Grounding.
    Gemini receives the returned snippets later as plain text context.
    """

    TAVILY_URL = "https://api.tavily.com/search"
    DEFAULT_SOURCES = [
        "reddit.com",
        "letterboxd.com",
        "rogerebert.com",
        "deepfocusreview.com",
        "rottentomatoes.com",
        "variety.com",
        "hollywoodreporter.com",
        "indiewire.com",
    ]

    def __init__(
        self,
        tavily_api_key: str | None,
        search_depth: str = "basic",
        max_total_results: int = 20,
        timeout_seconds: float = 30.0,
        preferred_sources: list[str] | None = None,
        min_relevant_sources: int = 3,
        min_distinct_domains: int = 2,
        max_source_chars: int = 5000,
    ):
        self.tavily_api_key = (tavily_api_key or "").strip()
        self.search_depth = search_depth if search_depth in {"basic", "advanced"} else "basic"
        self.max_total_results = max(5, int(max_total_results))
        self.preferred_sources = self._clean_domains(preferred_sources or self.DEFAULT_SOURCES)
        self.min_relevant_sources = max(2, int(min_relevant_sources))
        self.min_distinct_domains = max(1, int(min_distinct_domains))
        self.max_source_chars = max(1000, int(max_source_chars))
        self.http = httpx.Client(timeout=timeout_seconds, follow_redirects=True)

    @staticmethod
    def _clean_domains(domains: Iterable[str]) -> list[str]:
        cleaned: list[str] = []
        for raw in domains:
            value = str(raw or "").strip().lower()
            if "://" in value:
                value = urlsplit(value).hostname or ""
            value = value.removeprefix("www.").strip(" ./")
            if value and value not in cleaned:
                cleaned.append(value)
        return cleaned

    @staticmethod
    def _canonical_url(value: str) -> str:
        try:
            parsed = urlsplit((value or "").strip())
            host = (parsed.hostname or "").lower().removeprefix("www.")
            path = re.sub(r"/{2,}", "/", unquote(parsed.path or "/")).rstrip("/") or "/"
            return urlunsplit(("https", host, path, "", "")) if host else ""
        except Exception:
            return ""

    @staticmethod
    def _normalized_text(value: str) -> str:
        return " ".join(re.sub(r"[^a-z0-9]+", " ", unquote(value or "").casefold()).split())

    @staticmethod
    def _host(value: str) -> str:
        try:
            return (urlsplit(value).hostname or "").lower().removeprefix("www.")
        except Exception:
            return ""

    def _focus_article_content(self, raw: str, meta: MovieMeta) -> str:
        """Pick the most article-like window around the exact film title.

        Publisher raw markdown often starts with a large navigation/homepage block.
        Sending the first N characters can therefore describe unrelated stories.
        """
        raw = self._clean_extracted_content(raw)
        if len(raw) <= self.max_source_chars:
            return raw
        occurrences: list[int] = []
        for title in (meta.title, meta.original_title):
            title = str(title or "").strip()
            if not title:
                continue
            occurrences.extend(match.start() for match in re.finditer(re.escape(title), raw, re.I))
        if not occurrences:
            return raw[: self.max_source_chars]

        terms = ("review", "film", "movie", "director", "performance", "acting", "story", "cinematography", "verdict")
        candidates: list[tuple[float, str]] = []
        for index in sorted(set(occurrences)):
            start = max(0, index - 700)
            end = min(len(raw), start + self.max_source_chars)
            start = max(0, end - self.max_source_chars)
            window = raw[start:end]
            normalized = window.casefold()
            paragraph_signal = sum(min(len(line.strip()), 500) for line in window.splitlines() if len(line.strip()) >= 80)
            score = sum(normalized.count(term) * 20 for term in terms) + paragraph_signal / 100
            candidates.append((score, window))
        return max(candidates, key=lambda row: row[0])[1].strip()

    @staticmethod
    def _clean_extracted_content(raw: str) -> str:
        """Remove common publisher navigation/markdown noise while retaining prose."""
        text = (raw or "").replace("\x00", "")
        text = re.sub(r"!\[[^\]]*\]\([^\)]*\)", "", text)
        text = re.sub(r"\[([^\]]+)\]\([^\)]*\)", r"\1", text)
        nav_terms = (
            "sign up", "subscribe", "search icon", "privacy policy", "cookie policy",
            "video interviews", "weekend box office", "weekly ketchup", "what to watch",
            "follow us", "all rights reserved", "skip to content",
        )
        kept: list[str] = []
        for raw_line in text.splitlines():
            line = raw_line.strip()
            lowered = line.casefold()
            if not line:
                if kept and kept[-1] != "":
                    kept.append("")
                continue
            if len(line) < 220 and any(term in lowered for term in nav_terms):
                continue
            if len(line) < 160 and raw_line.lstrip().startswith(("* ", "- ")):
                continue
            if line.count("http://") + line.count("https://") >= 2:
                continue
            kept.append(line)
        return "\n".join(kept).strip()

    @staticmethod
    def _dedupe(items: Iterable[SearchResult], limit: int) -> list[SearchResult]:
        out: list[SearchResult] = []
        seen: set[str] = set()
        for item in items:
            url = (item.url or "").strip()
            canonical = HybridMovieSearch._canonical_url(url)
            if not canonical or canonical in seen:
                continue
            seen.add(canonical)
            out.append(item)
            if len(out) >= limit:
                break
        return out

    def _tavily_search(
        self,
        query: str,
        max_results: int,
        include_domains: list[str] | None = None,
    ) -> list[SearchResult]:
        if not self.tavily_api_key:
            raise RuntimeError("TAVILY_API_KEY is not configured")

        payload: dict = {
            "query": query,
            "search_depth": self.search_depth,
            "topic": "general",
            "max_results": max_results,
            "include_answer": False,
            # Tavily extracts readable article content for the writer. We still
            # truncate locally before sending it to Gemini.
            "include_raw_content": True,
        }
        if include_domains:
            payload["include_domains"] = include_domains

        response = self.http.post(
            self.TAVILY_URL,
            headers={
                "Authorization": f"Bearer {self.tavily_api_key}",
                "Content-Type": "application/json",
            },
            json=payload,
        )
        response.raise_for_status()
        data = response.json()

        results: list[SearchResult] = []
        for item in data.get("results") or []:
            url = (item.get("url") or "").strip()
            if not url:
                continue
            results.append(
                SearchResult(
                    title=(item.get("title") or url).strip(),
                    url=url,
                    snippet=(item.get("content") or "").strip(),
                    score=float(item.get("score") or 0.0),
                    backend="tavily",
                    query=query,
                    raw_content=(item.get("raw_content") or "").strip(),
                )
            )
        return results

    def _ddgs_search(self, query: str, max_results: int) -> list[SearchResult]:
        try:
            with DDGS() as ddgs:
                raw = list(ddgs.text(query, max_results=max_results))
        except Exception as exc:
            print(f"[DDGS fallback] search failed: {query} -> {exc}")
            return []

        results: list[SearchResult] = []
        for item in raw:
            url = (item.get("href") or item.get("url") or "").strip()
            if not url:
                continue
            results.append(
                SearchResult(
                    title=(item.get("title") or url).strip(),
                    url=url,
                    snippet=(item.get("body") or item.get("snippet") or "").strip(),
                    score=0.0,
                    backend="ddgs",
                    query=query,
                )
            )
        return results

    def _run_spec(
        self,
        query: str,
        max_results: int,
        domains: list[str] | None,
    ) -> list[SearchResult]:
        if self.tavily_api_key:
            try:
                rows = self._tavily_search(query, max_results=max_results, include_domains=domains)
                if rows:
                    return rows
            except Exception as exc:
                # Provider exceptions can embed credentials; log only their type.
                print(f"[Tavily] failed; using DDGS fallback ({type(exc).__name__})")

        # DDGS has no include_domains argument, so express domain scope in the query.
        if domains:
            domain_query = " OR ".join(f"site:{d}" for d in domains)
            ddgs_query = f"{query} ({domain_query})"
        else:
            ddgs_query = query
        return self._ddgs_search(ddgs_query, max_results=max_results)

    def _relevance(self, item: SearchResult, meta: MovieMeta) -> float:
        titles = [meta.title, meta.original_title]
        normalized_titles = [self._normalized_text(x) for x in titles if self._normalized_text(x)]
        source_title = self._normalized_text(item.title)
        source_url = self._normalized_text(item.url)
        snippet = self._normalized_text(item.snippet[:2500])
        raw = self._normalized_text(item.raw_content[: self.max_source_chars])
        year = str(meta.year or "")
        host = self._host(item.url)

        exact_in_title = any(title in source_title for title in normalized_titles)
        exact_in_url = any(title in source_url for title in normalized_titles)
        exact_in_snippet = any(title in snippet for title in normalized_titles)
        exact_in_raw = any(title in raw for title in normalized_titles)
        # Snippets/raw text can contain unrelated recommendation/navigation links.
        # The actual result title or canonical URL must identify this film.
        if not (exact_in_title or exact_in_url):
            return -100.0

        # Very short/generic film names need a year identity signal as well.
        shortest = min((len(x.replace(" ", "")) for x in normalized_titles), default=99)
        year_present = bool(year and year in f"{source_title} {source_url} {snippet} {raw}")
        if shortest <= 3 and year and not year_present:
            return -100.0

        title_url = f"{source_title} {source_url}"
        snippet_text = snippet
        negative_promo = ("trailer", "poster", "first image", "first look", "casting", "joins cast")
        review_markers = ("review", "analysis", "criticism", "discussion", "audience review", "opinion", "verdict")
        trusted_review_hosts = {"rogerebert.com", "deepfocusreview.com", "rottentomatoes.com", "letterboxd.com"}
        if any(term in title_url for term in negative_promo) and not any(term in title_url for term in review_markers):
            return -100.0
        if host == "reddit.com":
            if not any(term in f"{title_url} {snippet_text}" for term in review_markers):
                return -100.0
            item.source_kind = "community_discussion"
        elif host in trusted_review_hosts:
            item.source_kind = "review_platform"
        else:
            # Editorial publishers also return casting/news/trailer pages. Only
            # their explicit review/analysis URLs are valid review evidence.
            if not any(term in title_url for term in review_markers):
                return -100.0
            item.source_kind = "editorial_review"

        score = float(item.score or 0.0)
        if exact_in_title:
            score += 8.0
        if exact_in_url:
            score += 4.0
        if exact_in_snippet:
            score += 3.0
        if exact_in_raw:
            score += 1.0
        if year_present:
            score += 2.0
        if any(term in f"{source_title} {snippet}" for term in ("review", "analysis", "criticism", "discussion")):
            score += 1.0
        if item.raw_content:
            score += 1.0
        return score

    def _filter_relevant(self, items: Iterable[SearchResult], meta: MovieMeta) -> list[SearchResult]:
        allowed = set(self.preferred_sources)
        scored: list[SearchResult] = []
        for item in items:
            host = self._host(item.url)
            if allowed and not any(host == domain or host.endswith("." + domain) for domain in allowed):
                continue
            item.raw_content = self._focus_article_content(item.raw_content, meta)
            item.relevance_score = self._relevance(item, meta)
            if item.relevance_score < 0:
                continue
            scored.append(item)
        scored.sort(key=lambda row: row.relevance_score, reverse=True)

        # Keep source diversity and stop one review/audience page from crowding
        # out independent critics with pagination or tracking variants.
        selected: list[SearchResult] = []
        per_domain: dict[str, int] = {}
        for item in self._dedupe(scored, len(scored) or 1):
            host = self._host(item.url)
            if per_domain.get(host, 0) >= 4:
                continue
            per_domain[host] = per_domain.get(host, 0) + 1
            selected.append(item)
            if len(selected) >= self.max_total_results:
                break
        return selected

    def research_movie(self, meta: MovieMeta) -> list[SearchResult]:
        year = str(meta.year or "").strip()
        base = f'"{meta.title}" {year}'.strip()

        # Three focused searches give better source diversity than one giant query.
        community = [x for x in self.preferred_sources if x in {"reddit.com", "letterboxd.com"}]
        editorial = [x for x in self.preferred_sources if x not in set(community)]
        specs = [
            (
                f"{base} movie review analysis themes acting cinematography strengths weaknesses",
                8,
                self.preferred_sources,
            ),
            (
                f"{base} movie discussion interpretation audience opinions review",
                7,
                community or self.preferred_sources,
            ),
            (
                f"{base} film review criticism themes performances direction",
                7,
                editorial or self.preferred_sources,
            ),
        ]

        gathered: list[SearchResult] = []
        for query, max_results, domains in specs:
            rows = self._run_spec(query, max_results=max_results, domains=domains)
            gathered.extend(rows)

        # If narrow searches were sparse, do one broad fallback search.
        unique = self._filter_relevant(gathered, meta)
        if len(unique) < 6:
            broad = self._run_spec(
                f"{base} movie review analysis",
                max_results=8,
                domains=self.preferred_sources,
            )
            gathered.extend(broad)
            unique = self._filter_relevant(gathered, meta)

        distinct_domains = {self._host(item.url) for item in unique}

        # Prefer independent publishers and try two supplemental searches before
        # considering the bounded single-domain fallback below.
        needs_recovery = (
            len(unique) < self.min_relevant_sources
            or len(distinct_domains) < self.min_distinct_domains
        )
        if needs_recovery:
            missing_domains = [
                domain
                for domain in self.preferred_sources
                if domain not in distinct_domains
            ]
            recovery_domains = missing_domains or self.preferred_sources
            print(
                "[Research recovery] quality gate not met; searching additional "
                f"independent domains (relevant={len(unique)}/{self.min_relevant_sources}, "
                f"domains={len(distinct_domains)}/{self.min_distinct_domains})"
            )

            recovery_specs = [
                (f"{base} review film criticism performance direction", 10),
                (f"{base} movie review verdict analysis", 10),
            ]

            for recovery_index, (query, max_results) in enumerate(recovery_specs, start=1):
                rows = self._run_spec(
                    query,
                    max_results=max_results,
                    domains=recovery_domains,
                )
                gathered.extend(rows)
                unique = self._filter_relevant(gathered, meta)
                distinct_domains = {self._host(item.url) for item in unique}

                print(
                    f"[Research recovery] pass {recovery_index}: "
                    f"{len(unique)} relevant source(s), "
                    f"{len(distinct_domains)} domain(s)"
                )

                if (
                    len(unique) >= self.min_relevant_sources
                    and len(distinct_domains) >= self.min_distinct_domains
                ):
                    break

                missing_domains = [
                    domain
                    for domain in self.preferred_sources
                    if domain not in distinct_domains
                ]
                recovery_domains = missing_domains or self.preferred_sources

        if len(unique) < self.min_relevant_sources or len(distinct_domains) < self.min_distinct_domains:
            # Adaptive fallback after both recovery passes. Two independent
            # domains remain the preferred route. When Tavily/DDGS cannot reach a
            # second publisher, three distinct, relevant review pages from one
            # configured domain are still sufficient for a low-stakes movie
            # review, provided their combined usable text is substantive.
            usable_rows = [
                item
                for item in unique
                if len((item.raw_content or item.snippet or "").strip()) >= 120
            ]
            cross_domain_ok = (
                len(unique) >= 2
                and len(distinct_domains) >= 2
                and len(usable_rows) >= 2
            )
            combined_usable_chars = sum(
                len((item.raw_content or item.snippet or "").strip())
                for item in unique
            )
            single_domain_ok = (
                len(unique) >= 3
                and len(distinct_domains) == 1
                and combined_usable_chars >= 300
                and all(item.source_kind for item in unique[:3])
            )

            if cross_domain_ok or single_domain_ok:
                mode = "cross-domain" if cross_domain_ok else "single-domain degraded"
                print(
                    "[Research quality] adaptive fallback accepted after recovery: "
                    f"{len(unique)} relevant source(s), "
                    f"{len(distinct_domains)} independent domain(s); "
                    f"mode={mode}, usable_chars={combined_usable_chars}."
                )
            else:
                raise RuntimeError(
                    "Research quality gate failed after cross-domain recovery: "
                    f"relevant_sources={len(unique)}/{self.min_relevant_sources}, "
                    f"distinct_domains={len(distinct_domains)}/{self.min_distinct_domains}. "
                    "No review will be generated from sparse or off-topic evidence."
                )

        print(
            f"[Research quality] {len(unique)} relevant source(s), "
            f"{len(distinct_domains)} domain(s), raw-content sources="
            f"{sum(1 for item in unique if item.raw_content)}"
        )

        return unique
