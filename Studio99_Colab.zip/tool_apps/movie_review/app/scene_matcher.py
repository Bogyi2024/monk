from __future__ import annotations

import json
import queue
import re
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Callable, TypeVar

from pydantic import BaseModel, Field

from .models import SceneCatalog, SceneItem, SceneMatchBundle, VideoBeat


class _SceneVision(BaseModel):
    description: str = Field(description="Short plain-English description of the frame.")
    keywords: list[str] = Field(description="6-12 short English keywords or tags.")


_T = TypeVar("_T")


class _HardVisionTimeout(TimeoutError):
    pass


def _call_with_hard_timeout(call: Callable[[], _T], timeout_seconds: float) -> _T:
    """Bound an SDK call even when its transport ignores the configured timeout."""
    result_queue: queue.Queue[tuple[bool, object]] = queue.Queue(maxsize=1)

    def run() -> None:
        try:
            result_queue.put((True, call()))
        except BaseException as exc:
            result_queue.put((False, exc))

    worker = threading.Thread(target=run, name="movie-review-vision", daemon=True)
    worker.start()
    worker.join(max(0.1, float(timeout_seconds)))
    if worker.is_alive():
        raise _HardVisionTimeout(f"vision request exceeded hard timeout of {timeout_seconds:g}s")
    succeeded, value = result_queue.get_nowait()
    if succeeded:
        return value  # type: ignore[return-value]
    raise value  # type: ignore[misc]


def _need_bin(name: str) -> str:
    path = shutil.which(name)
    if not path:
        raise RuntimeError(f"{name} not found in PATH.")
    return path


def _probe_duration(path: Path) -> float:
    ffprobe = _need_bin("ffprobe")
    proc = subprocess.run(
        [
            ffprobe, "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            str(path),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    try:
        return max(0.0, float(proc.stdout.strip()))
    except Exception:
        return 0.0


def _extract_scene_change_times(source_video: Path, threshold: float = 0.28) -> list[float]:
    ffmpeg = _need_bin("ffmpeg")
    proc = subprocess.run(
        [
            ffmpeg,
            "-hide_banner",
            "-i", str(source_video),
            "-filter:v", f"select='gt(scene,{threshold})',showinfo",
            "-an",
            "-f", "null",
            "-",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    text = proc.stderr
    times: list[float] = []
    for m in re.finditer(r"pts_time:([0-9]+(?:\.[0-9]+)?)", text):
        t = float(m.group(1))
        if not times or abs(t - times[-1]) > 0.75:
            times.append(t)
    return times


def _extract_frame(source_video: Path, timestamp: float, dest: Path) -> None:
    ffmpeg = _need_bin("ffmpeg")
    subprocess.run(
        [
            ffmpeg, "-y", "-ss", f"{timestamp:.3f}", "-i", str(source_video),
            "-frames:v", "1", str(dest),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=True,
    )


def build_scene_catalog(
    source_video: Path,
    out_dir: Path,
    threshold: float = 0.28,
    max_scenes: int = 24,
) -> SceneCatalog:
    out_dir.mkdir(parents=True, exist_ok=True)
    total = _probe_duration(source_video)
    if total <= 0:
        raise RuntimeError("Could not read source video duration.")

    change_times = _extract_scene_change_times(source_video, threshold=threshold)
    boundaries = [0.0]
    for t in change_times:
        if 0.8 < t < total - 0.8:
            boundaries.append(t)
    boundaries.append(total)
    boundaries = sorted(set(round(x, 3) for x in boundaries))

    scenes: list[SceneItem] = []
    for i in range(len(boundaries) - 1):
        start = boundaries[i]
        end = boundaries[i + 1]
        if end - start < 0.8:
            continue
        mid = (start + end) / 2.0
        scene_id = f"scene_{len(scenes)+1:03d}"
        frame_path = out_dir / f"{scene_id}.jpg"
        try:
            _extract_frame(source_video, mid, frame_path)
        except Exception:
            continue
        scenes.append(
            SceneItem(
                scene_id=scene_id,
                start_seconds=start,
                end_seconds=end,
                midpoint_seconds=mid,
                frame_path=str(frame_path),
            )
        )
        if len(scenes) >= max_scenes:
            break

    if not scenes:
        # fallback: sample a few evenly spaced frames
        steps = min(max_scenes, max(3, int(total // 5)))
        for i in range(steps):
            start = (total / steps) * i
            end = min(total, start + max(2.0, total / steps))
            mid = min(total - 0.1, (start + end) / 2.0)
            scene_id = f"scene_{len(scenes)+1:03d}"
            frame_path = out_dir / f"{scene_id}.jpg"
            try:
                _extract_frame(source_video, mid, frame_path)
            except Exception:
                continue
            scenes.append(
                SceneItem(
                    scene_id=scene_id,
                    start_seconds=start,
                    end_seconds=end,
                    midpoint_seconds=mid,
                    frame_path=str(frame_path),
                )
            )

    return SceneCatalog(
        source_video=str(source_video),
        duration_seconds=total,
        scenes=scenes,
    )


def describe_scene_catalog(
    llm,
    catalog: SceneCatalog,
    *,
    vision_timeout_seconds: float = 45.0,
) -> SceneCatalog:
    updated: list[SceneItem] = []
    total_scenes = len(catalog.scenes)
    consecutive_failures = 0
    vision_circuit_open = False
    for scene_index, scene in enumerate(catalog.scenes, start=1):
        frame = Path(scene.frame_path)
        if not frame.exists():
            updated.append(scene)
            continue
        if vision_circuit_open:
            scene.description = scene.description or "movie scene"
            scene.keywords = scene.keywords or ["movie", "scene"]
            updated.append(scene)
            continue
        prompt = """
Describe this single movie-trailer frame for later clip matching.
Return JSON with:
- description: one short plain-English sentence
- keywords: 6 to 12 short English keywords
Focus on visible things only: shot type, number of people, action, setting, mood, lighting, color, and atmosphere.
Avoid guessing exact character names or plot details unless visually obvious.
""".strip()
        try:
            print(f"[Gemini vision] frame {scene_index}/{total_scenes}: {scene.scene_id} using {getattr(llm, 'active_vision_model', 'vision model')}")
            if hasattr(llm, "generate_vision_structured"):
                parsed = _call_with_hard_timeout(
                    lambda: llm.generate_vision_structured(prompt, frame, _SceneVision),
                    vision_timeout_seconds,
                )
            else:
                from google.genai import types
                parsed = _call_with_hard_timeout(
                    lambda: llm.generate_structured_contents(
                        [
                            prompt,
                            types.Part.from_bytes(data=frame.read_bytes(), mime_type="image/jpeg"),
                        ],
                        _SceneVision,
                    ),
                    vision_timeout_seconds,
                )
            scene.description = parsed.description.strip()
            scene.keywords = [x.strip() for x in parsed.keywords if str(x).strip()][:12]
            consecutive_failures = 0
        except Exception as exc:
            scene.description = scene.description or "movie scene"
            scene.keywords = scene.keywords or ["movie", "scene"]
            consecutive_failures += 1
            print(
                f"[Gemini vision] {scene.scene_id} unavailable "
                f"({type(exc).__name__}: {exc}); using local fallback."
            )
            failure_limit = 1 if isinstance(exc, _HardVisionTimeout) else 2
            if consecutive_failures >= failure_limit:
                vision_circuit_open = True
                remaining = total_scenes - scene_index
                reason = "hard timeout" if isinstance(exc, _HardVisionTimeout) else "2 consecutive failures"
                print(
                    f"[Gemini vision] circuit opened after {reason}; "
                    f"skipping remote analysis for {remaining} remaining frame(s)."
                )
        updated.append(scene)
    catalog.scenes = updated
    return catalog


def match_beats_to_scenes(
    llm,
    beats: list[VideoBeat],
    catalog: SceneCatalog,
) -> SceneMatchBundle:
    scene_lines = []
    for sc in catalog.scenes:
        scene_lines.append(
            f"{sc.scene_id} | {sc.start_seconds:.1f}-{sc.end_seconds:.1f}s | {sc.description} | keywords: {', '.join(sc.keywords)}"
        )
    beat_lines = []
    for beat in beats:
        beat_lines.append(
            f"{beat.beat_id} | kind={beat.kind} | duration={beat.duration_seconds:.1f}s | visual_hint={beat.visual_hint} | narration={beat.narration}"
        )

    prompt = f"""
You are matching Burmese review narration beats to candidate trailer scenes.
Choose the visually best-fitting scene for each beat.

Rules:
- Match by meaning, mood, and visible content, not exact plot chronology.
- Prefer variety; avoid reusing the same scene over and over if several scenes fit.
- If no scene is a reasonable fit, set scene_id to an empty string and use_still_fallback=true.
- confidence should be 0.0 to 1.0.
- reason must be short.

CANDIDATE SCENES
{chr(10).join(scene_lines)}

VIDEO BEATS
{chr(10).join(beat_lines)}
"""

    return llm.generate_structured(prompt, SceneMatchBundle)
