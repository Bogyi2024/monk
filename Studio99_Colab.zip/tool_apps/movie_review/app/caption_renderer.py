from __future__ import annotations

import asyncio
import os
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape
from playwright.async_api import async_playwright

from .models import VideoBeat
from .utils import trim


def _to_file_uri(path_str: str | None) -> str | None:
    if not path_str:
        return None
    try:
        p = Path(path_str).expanduser().resolve()
        return p.as_uri()
    except Exception:
        return None


async def render_reel_caption_overlays(
    template_dir: Path,
    work_dir: Path,
    beats: list[VideoBeat],
    width: int = 1080,
    height: int = 1920,
) -> list[Path]:
    out_dir = work_dir / "caption_overlays"
    out_dir.mkdir(parents=True, exist_ok=True)

    title_font_family = os.getenv("TITLE_FONT_FAMILY", "KoZ 036 Uni").strip() or "KoZ 036 Uni"
    body_font_family = os.getenv("BODY_FONT_FAMILY", "Burma-020 Thin").strip() or "Burma-020 Thin"
    title_font_uri = _to_file_uri(os.getenv("TITLE_FONT_PATH", r"C:\Users\MYOSI\AppData\Local\Microsoft\Windows\Fonts\KOZ036UNI-REGULAR.TTF").strip() or None)
    body_font_uri = _to_file_uri(os.getenv("BODY_FONT_PATH", "").strip() or None)

    env = Environment(
        loader=FileSystemLoader(str(template_dir)),
        autoescape=select_autoescape(["html", "xml"]),
    )
    template = env.get_template("reel_caption.html")

    paths: list[Path] = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": width, "height": height}, device_scale_factor=1)

        for i, beat in enumerate(beats):
            # Subtitle must follow the actual narration, not the short on-screen label.
            display_text = (beat.narration or "").strip()
            if not display_text:
                display_text = (beat.on_screen_text or "").strip()
            display_text = trim(display_text, 180)

            text_len = len(display_text)
            if text_len <= 45:
                caption_font_size = 54
            elif text_len <= 80:
                caption_font_size = 48
            elif text_len <= 120:
                caption_font_size = 42
            else:
                caption_font_size = 36

            html = template.render(
                width=width,
                height=height,
                line1=display_text,
                line2="",
                title_font_family=title_font_family,
                body_font_family=body_font_family,
                title_font_uri=title_font_uri,
                body_font_uri=body_font_uri,
                caption_font_size=caption_font_size,
            )
            html_path = out_dir / f"overlay_{i:02d}.html"
            png_path = out_dir / f"overlay_{i:02d}.png"
            html_path.write_text(html, encoding="utf-8")

            await page.goto(html_path.resolve().as_uri(), wait_until="load")
            try:
                await page.wait_for_function("() => document.fonts ? document.fonts.status === 'loaded' : true", timeout=5000)
            except Exception:
                pass
            await page.wait_for_timeout(180)
            await page.screenshot(path=str(png_path), full_page=False, omit_background=True)
            if not png_path.exists() or png_path.stat().st_size < 1000:
                raise RuntimeError(f"Chromium subtitle overlay was not rendered: {png_path}")
            paths.append(png_path)

        await browser.close()

    return paths


def render_reel_caption_overlays_sync(*args, **kwargs) -> list[Path]:
    return asyncio.run(render_reel_caption_overlays(*args, **kwargs))
