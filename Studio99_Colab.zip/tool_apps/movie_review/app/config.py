from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
import yaml
import sys

BASE_DIR = Path(__file__).resolve().parent.parent
SHARED_ENV_PATH = BASE_DIR.parent / "recap_personal" / ".env"
sys.path.append(str(SHARED_ENV_PATH.parent))
from tavily_live import read_live_key
from movie_review_profiles import normalize_profile, normalize_domain, profile_sources


def _unquote(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        return value[1:-1]
    return value


def _load_simple_env(path: Path, *, overwrite: bool = True) -> None:
    """Windows-friendly .env loader that ignores stray/non-key lines."""
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.lower().startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if not key or not key.replace("_", "").isalnum() or key[0].isdigit():
            continue
        if overwrite or key not in os.environ:
            os.environ[key] = _unquote(value)


# Keep Movie Review-specific settings compatible with old installs, then let the
# shared TT Master environment win for credentials that exist in both places.
_load_simple_env(BASE_DIR / ".env", overwrite=False)
_load_simple_env(SHARED_ENV_PATH, overwrite=True)


def _gemini_key_pool() -> tuple[list[str], list[str]]:
    """Return a de-duplicated rotating pool without ever logging key values."""
    ranked: list[tuple[int, str, str]] = []
    for name, value in os.environ.items():
        value = str(value or "").strip()
        if not value:
            continue
        match = re.match(r"^GEMINI_IMAGE_PROJECT_(\d+)_KEY$", name, re.I)
        if match:
            ranked.append((100 + int(match.group(1)), name, value))
    for order, name in enumerate(("GEMINI_TEXT_FREE_KEY", "GEMINI_WRITER_API_KEY")):
        value = str(os.getenv(name) or "").strip()
        if value:
            ranked.append((order, name, value))
    # The machine-level GEMINI_API_KEY may be a paid key. Use it only as a
    # legacy fallback when no explicit/free rotating pool exists.
    if not ranked:
        value = str(os.getenv("GEMINI_API_KEY") or "").strip()
        if value:
            ranked.append((9999, "GEMINI_API_KEY", value))
    ranked.sort(key=lambda row: row[0])

    keys: list[str] = []
    aliases: list[str] = []
    seen: set[str] = set()
    for _, alias, value in ranked:
        if value in seen:
            continue
        seen.add(value)
        keys.append(value)
        aliases.append(alias)
    return keys, aliases


def _preferred_sources_with_tt(base_sources: list[str]) -> list[str]:
    # MOVIE_REVIEW_TT_SOURCES_BRIDGE_V1: retain config + child-env source merging.
    """Merge Movie Review config sources with enabled TT Master UI sources."""
    merged: list[str] = []

    def add(value: str) -> None:
        item = normalize_domain(value)
        if item and item not in merged:
            merged.append(item)

    for value in base_sources:
        add(value)

    extra_raw = str(os.getenv("MOVIE_REVIEW_TT_SOURCE_DOMAINS") or "")
    extra = [x for x in re.split(r"[;,\n\r]+", extra_raw) if x.strip()]
    for value in extra:
        add(value)

    if extra:
        active_extra = [x for x in merged if x not in {
            str(v or "").strip().lower().removeprefix("www.").strip(" ./")
            for v in base_sources
        }]
        print(
            "[Movie Review] preferred research domains: "
            f"{len(merged)} total ({len(active_extra)} from TT Master UI)"
        )
    return merged


@dataclass
class Settings:
    gemini_api_key: str
    gemini_writer_api_key: str
    gemini_writer_api_keys: list[str]
    gemini_key_aliases: list[str]
    gemini_writer_model: str
    gemini_writer_fallback_model: str
    gemini_vision_model: str
    gemini_vision_fallback_model: str
    gemini_request_timeout_seconds: float
    tavily_api_key: str | None
    tavily_search_depth: str
    search_max_results: int
    preferred_sources: list[str]
    research_min_sources: int
    research_min_domains: int
    research_source_chars: int
    tmdb_bearer_token: str
    fal_key: str | None
    fal_image_model: str
    output_dir: Path
    raw: dict
    tts_command: str | None
    edge_tts_voice: str
    edge_tts_rate: str
    edge_tts_volume: str
    gemini_tts_model: str
    gemini_tts_voice: str
    gemini_tts_speed: float
    title_font_family: str
    title_font_path: str | None
    body_font_family: str
    body_font_path: str | None
    state_dir: Path
    shared_env_path: Path
    movie_review_profile: str = "movie_general"


def load_settings(profile: str | None = None) -> Settings:
    selected_profile = normalize_profile(profile or os.getenv("MOVIE_REVIEW_PROFILE"))
    config_path = BASE_DIR / "config.yaml"
    raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    research_cfg = raw.get("research") or {}
    video_cfg = raw.get("video") or {}

    output = Path(os.getenv("OUTPUT_DIR", raw.get("output_dir", "output")))
    if not output.is_absolute():
        output = BASE_DIR / output
    output.mkdir(parents=True, exist_ok=True)

    state_dir = Path(os.getenv("MOVIE_REVIEW_STATE_DIR", "state"))
    if not state_dir.is_absolute():
        state_dir = BASE_DIR / state_dir
    state_dir.mkdir(parents=True, exist_ok=True)

    gemini_keys, gemini_aliases = _gemini_key_pool()
    primary_key = gemini_keys[0] if gemini_keys else ""

    return Settings(
        gemini_api_key=primary_key,
        gemini_writer_api_key=primary_key,
        gemini_writer_api_keys=gemini_keys,
        gemini_key_aliases=gemini_aliases,
        gemini_writer_model=os.getenv("GEMINI_WRITER_MODEL", "gemini-3.6-flash").strip(),
        gemini_writer_fallback_model=os.getenv("GEMINI_WRITER_FALLBACK_MODEL", "gemini-3.5-flash").strip(),
        gemini_vision_model=os.getenv("GEMINI_VISION_MODEL", "gemini-3.5-flash").strip(),
        gemini_vision_fallback_model=os.getenv("GEMINI_VISION_FALLBACK_MODEL", "gemini-3.6-flash").strip(),
        gemini_request_timeout_seconds=max(
            15.0,
            min(300.0, float(os.getenv("MOVIE_REVIEW_GEMINI_TIMEOUT_SECONDS", "120"))),
        ),
        tavily_api_key=read_live_key() or None,
        tavily_search_depth=os.getenv("TAVILY_SEARCH_DEPTH", "basic").strip().lower(),
        search_max_results=int(os.getenv("SEARCH_MAX_RESULTS", "20")),
        preferred_sources=_preferred_sources_with_tt(profile_sources(selected_profile) + [
            str(x).strip().lower()
            for x in ((raw.get("research") or {}).get("preferred_sources") or [])
            if str(x).strip()
        ]),
        research_min_sources=max(2, int(os.getenv("RESEARCH_MIN_SOURCES", str(research_cfg.get("min_relevant_sources", 3))))),
        research_min_domains=max(1, int(os.getenv("RESEARCH_MIN_DOMAINS", str(research_cfg.get("min_distinct_domains", 2))))),
        research_source_chars=max(1000, int(os.getenv("RESEARCH_SOURCE_CHARS", str(research_cfg.get("max_source_chars", 5000))))),
        tmdb_bearer_token=os.getenv("TMDB_BEARER_TOKEN", "").strip(),
        fal_key=os.getenv("FAL_KEY", "").strip() or None,
        fal_image_model=os.getenv("FAL_IMAGE_MODEL", "fal-ai/flux-2/flash/edit").strip(),
        output_dir=output,
        raw=raw,
        tts_command=os.getenv("TTS_COMMAND", "").strip() or None,
        edge_tts_voice=os.getenv("EDGE_TTS_VOICE", "my-MM-ThihaNeural").strip(),
        edge_tts_rate=os.getenv("EDGE_TTS_RATE", "+0%").strip(),
        edge_tts_volume=os.getenv("EDGE_TTS_VOLUME", "+0%").strip(),
        gemini_tts_model=os.getenv("MOVIE_REVIEW_TTS_MODEL", str(video_cfg.get("tts_model") or "gemini-3.1-flash-tts-preview")).strip(),
        gemini_tts_voice=os.getenv("MOVIE_REVIEW_TTS_VOICE", str(video_cfg.get("tts_voice") or "Kore")).strip(),
        gemini_tts_speed=max(0.75, min(1.35, float(os.getenv("MOVIE_REVIEW_TTS_SPEED", str(video_cfg.get("tts_speed") or "1.08"))))),
        title_font_family=os.getenv("TITLE_FONT_FAMILY", "KoZ 036 Uni").strip() or "KoZ 036 Uni",
        title_font_path=os.getenv("TITLE_FONT_PATH", r"C:\Users\MYOSI\AppData\Local\Microsoft\Windows\Fonts\KOZ036UNI-REGULAR.TTF").strip() or None,
        body_font_family=os.getenv("BODY_FONT_FAMILY", "Burma-020 Thin").strip() or "Burma-020 Thin",
        body_font_path=os.getenv("BODY_FONT_PATH", "").strip() or None,
        state_dir=state_dir,
        shared_env_path=SHARED_ENV_PATH,
        movie_review_profile=selected_profile,
    )
