from __future__ import annotations

from pydantic import BaseModel, Field


class MovieMeta(BaseModel):
    tmdb_id: int
    title: str
    original_title: str = ""
    year: int | None = None
    overview: str = ""
    genres: list[str] = []
    vote_average: float | None = None
    poster_urls: list[str] = []
    backdrop_urls: list[str] = []


class Citation(BaseModel):
    title: str
    url: str


class ResearchBrief(BaseModel):
    text: str
    citations: list[Citation] = []


class ReviewPackage(BaseModel):
    movie_title: str
    burmese_title: str = Field(description="Natural display title in Burmese if useful; otherwise original title.")
    headline: str = Field(description="Short high-impact Burmese headline for the post.")
    hook: str = Field(description="1-2 sentence Burmese opening hook.")
    review_body: str = Field(description="Original Burmese review. Multi-paragraph.")
    verdict: str = Field(description="Short Burmese verdict.")
    rating_text: str = Field(description="Example: 8/10 or 'ကြည့်သင့်'.")
    spoiler_note: str = Field(description="Short spoiler note or empty string.")
    thumbnail_title: str = Field(description="Very short Burmese thumbnail text.")
    thumbnail_kicker: str = Field(description="Short supporting line for the thumbnail.")
    thumbnail_badge: str = Field(description="Tiny badge text, e.g. REVIEW / ကြည့်သင့်?")
    short_caption: str = Field(description="Short caption for TikTok/Reels/Facebook short post.")
    hashtags: list[str] = Field(description="Relevant hashtags without #.")


class ThumbnailHookPack(BaseModel):
    candidates: list[str] = Field(description="6 to 8 short high-curiosity Burmese thumbnail title candidates.")
    kicker: str = Field(description="One short supporting Burmese line; clearer than the hook title.")
    badge: str = Field(description="Very short badge such as RETRO REVIEW / MUST WATCH / SCI-FI CLASSIC.")


class PipelineManifest(BaseModel):
    schema_version: int = 2
    content_id: str
    tmdb_id: int
    title: str
    year: int | None = None
    review_json: str
    facebook_post: str
    short_post: str
    sources_file: str
    thumbnail: str
    video: str = ""
    voiceover: str = ""
    used_fal: bool
    fal_model: str = ""
    destinations: dict = Field(default_factory=dict)


class TrailerRef(BaseModel):
    name: str
    site: str
    key: str
    type: str = ""
    official: bool = False
    published_at: str = ""
    url: str = ""


class VideoSegment(BaseModel):
    narration: str = Field(description="Natural Burmese voice-over for this segment.")
    visual_hint: str = Field(description="What visual would fit this segment.")
    on_screen_text: str = Field(description="Very short Burmese on-screen text or empty string.")
    duration_seconds: float = Field(default=6.0, ge=2.0, le=15.0)


class VideoPlan(BaseModel):
    title: str
    opening_hook: str
    segments: list[VideoSegment]
    closing_line: str
    total_target_seconds: int = 60


class VideoBeat(BaseModel):
    beat_id: str
    narration: str
    visual_hint: str
    on_screen_text: str = ""
    duration_seconds: float = Field(default=6.0, ge=1.5, le=20.0)
    kind: str = Field(default="body", description="hook/body/closing")


class SceneItem(BaseModel):
    scene_id: str
    start_seconds: float
    end_seconds: float
    midpoint_seconds: float
    frame_path: str = ""
    description: str = ""
    keywords: list[str] = []


class SceneCatalog(BaseModel):
    source_video: str
    duration_seconds: float
    scenes: list[SceneItem] = []


class SceneMatch(BaseModel):
    beat_id: str
    scene_id: str = ""
    confidence: float = 0.0
    reason: str = ""
    use_still_fallback: bool = False


class SceneMatchBundle(BaseModel):
    matches: list[SceneMatch] = []
