from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from yt_dlp import YoutubeDL

from .models import TrailerRef


@dataclass
class YouTubeCandidate:
    title: str
    url: str
    channel: str = ""
    duration: float | None = None
    score: int = 0


def _is_youtube_antibot_error(exc: Exception | str) -> bool:
    message = str(exc or "").casefold()
    return any(marker in message for marker in (
        "sign in to confirm you’re not a bot",
        "sign in to confirm you're not a bot",
        "confirm you’re not a bot",
        "confirm you're not a bot",
        "use --cookies-from-browser",
        "use --cookies-from-browser or --cookies",
    ))


def _is_youtube_transport_error(exc: Exception | str) -> bool:
    message = str(exc or "").casefold()
    return any(marker in message for marker in (
        "unable to connect to proxy",
        "proxyerror",
        "remote disconnected",
        "remotedisconnected",
        "remote end closed connection",
        "server disconnected",
        "connection reset",
        "connection aborted",
        "connection unexpectedly closed",
        "peer closed connection",
        "timed out",
        "timeout",
    ))


def _youtube_direct_opts(opts: dict) -> dict:
    # Keep the process-level Gemini proxy untouched; bypass it only for yt-dlp.
    direct = dict(opts)
    direct["proxy"] = ""
    direct.setdefault("socket_timeout", 35)
    direct.setdefault("retries", 4)
    direct.setdefault("fragment_retries", 4)
    direct.setdefault("extractor_retries", 3)
    return direct


def _extract_with_firefox_fallback(
    url: str,
    opts: dict,
    *,
    download: bool,
    purpose: str,
) -> tuple[dict, YoutubeDL]:
    """Use direct YouTube networking; add Firefox cookies only on anti-bot."""
    public_opts = _youtube_direct_opts(opts)

    try:
        with YoutubeDL(public_opts) as ydl:
            return ydl.extract_info(url, download=download), ydl
    except Exception as first:
        if not _is_youtube_antibot_error(first):
            raise

    print(
        f"[YouTube] anti-bot challenge during {purpose}; "
        "retrying direct with Firefox cookies..."
    )

    fallback = _youtube_direct_opts(opts)
    fallback["cookiesfrombrowser"] = ("firefox",)

    try:
        with YoutubeDL(fallback) as ydl:
            info = ydl.extract_info(url, download=download)
            print(f"[YouTube] Firefox cookie fallback {purpose} succeeded")
            return info, ydl
    except Exception as firefox_error:
        if not _is_youtube_transport_error(firefox_error):
            raise RuntimeError(
                f"YouTube anti-bot challenge during {purpose}; "
                f"Firefox cookie fallback also failed: {firefox_error}"
            ) from firefox_error

        print(
            f"[YouTube] Firefox-cookie {purpose} transport dropped; "
            "reconnecting direct once..."
        )

    try:
        with YoutubeDL(fallback) as ydl:
            info = ydl.extract_info(url, download=download)
            print(f"[YouTube] Firefox-cookie direct reconnect {purpose} succeeded")
            return info, ydl
    except Exception as retry_error:
        raise RuntimeError(
            f"YouTube {purpose} failed after direct Firefox-cookie reconnect: "
            f"{retry_error}"
        ) from retry_error


def _watch_url(info: dict) -> str:
    url = info.get("webpage_url") or info.get("original_url")
    if url:
        return url
    vid = info.get("id")
    return f"https://www.youtube.com/watch?v={vid}" if vid else ""


def _score_candidate(info: dict, movie_title: str, year: int | None) -> int:
    title = (info.get("title") or "").lower()
    channel = (info.get("channel") or info.get("uploader") or "").lower()
    score = 0
    if movie_title.lower() in title:
        score += 6
    if "official trailer" in title:
        score += 8
    elif "official" in title and "trailer" in title:
        score += 6
    elif "trailer" in title:
        score += 3
    if year and str(year) in title:
        score += 2
    if any(w in channel for w in ("pictures", "studios", "entertainment", "films", "movie", "official")):
        score += 2
    if any(w in title for w in ("reaction", "review", "breakdown", "fan trailer", "concept trailer", "compilation")):
        score -= 8
    duration = info.get("duration")
    if isinstance(duration, (int, float)):
        if 30 <= duration <= 300:
            score += 2
        elif duration > 900:
            score -= 3
    return score


def tmdb_youtube_candidate_urls(refs: Iterable[TrailerRef]) -> list[str]:
    """Return distinct TMDB YouTube references in safe visual-source order."""
    type_priority = {
        "trailer": 4,
        "teaser": 3,
        "clip": 2,
        "featurette": 1,
    }
    items = [
        ref for ref in refs
        if (ref.site or "").casefold() == "youtube" and ref.url
    ]
    items.sort(
        key=lambda ref: (
            type_priority.get((ref.type or "").casefold(), 0),
            1 if ref.official else 0,
            ref.published_at or "",
        ),
        reverse=True,
    )
    urls: list[str] = []
    seen: set[str] = set()
    for ref in items:
        if ref.url in seen:
            continue
        seen.add(ref.url)
        urls.append(ref.url)
    return urls


def tmdb_official_youtube_url(refs: Iterable[TrailerRef]) -> str | None:
    """Backward-compatible accessor for callers that only need the first URL."""
    urls = tmdb_youtube_candidate_urls(refs)
    return urls[0] if urls else None


def search_official_trailer(movie_title: str, year: int | None = None, max_results: int = 5) -> tuple[str, list[YouTubeCandidate]]:
    query = f'{movie_title} {year or ""} official trailer'.strip()
    opts = {
        "quiet": True,
        "skip_download": True,
        "noplaylist": True,
        "extract_flat": False,
        # One removed/private search result must not discard other candidates.
        "ignoreerrors": True,
    }
    data, _ydl = _extract_with_firefox_fallback(
        f"ytsearch{max_results}:{query}", opts, download=False, purpose="trailer search"
    )
    candidates: list[YouTubeCandidate] = []
    for item in (data or {}).get("entries") or []:
        if not item:
            continue
        url = _watch_url(item)
        if not url:
            continue
        candidates.append(YouTubeCandidate(
            title=item.get("title") or "",
            url=url,
            channel=item.get("channel") or item.get("uploader") or "",
            duration=item.get("duration"),
            score=_score_candidate(item, movie_title, year),
        ))
    candidates.sort(key=lambda x: x.score, reverse=True)
    if not candidates:
        raise RuntimeError(f"No public YouTube trailer result found for: {query}")
    return candidates[0].url, candidates


def download_public_youtube_video(url: str, output_dir: Path, max_height: int = 1080) -> Path:
    """Download public video; use the signed-in Firefox profile only on anti-bot."""
    output_dir.mkdir(parents=True, exist_ok=True)
    opts = {
        "outtmpl": str(output_dir / "youtube_source.%(ext)s"),
        "format": f"bv*[height<=?{max_height}]/b[height<=?{max_height}]",
        "noplaylist": True,
        "quiet": False,
        "restrictfilenames": True,
    }
    info, ydl = _extract_with_firefox_fallback(
        url, opts, download=True, purpose="trailer download"
    )
    candidates = []
    for item in info.get("requested_downloads") or []:
        if item.get("filepath"):
            candidates.append(Path(item["filepath"]))
    if info.get("_filename"):
        candidates.append(Path(info["_filename"]))
    candidates.append(Path(ydl.prepare_filename(info)))
    for fp in candidates:
        if fp.exists():
            return fp
    found = sorted(output_dir.glob("youtube_source.*"), key=lambda x: x.stat().st_mtime, reverse=True)
    if found:
        return found[0]
    raise RuntimeError("yt-dlp completed but source file was not found.")


def download_first_available_youtube_video(
    urls: Iterable[str],
    output_dir: Path,
    max_height: int = 1080,
) -> tuple[Path | None, str | None, list[dict[str, str | bool]]]:
    """Try candidates independently so a removed video cannot abort the Reel."""
    attempts: list[dict[str, str | bool]] = []
    seen: set[str] = set()
    for index, raw_url in enumerate(urls, start=1):
        url = str(raw_url or "").strip()
        if not url or url in seen:
            continue
        seen.add(url)
        candidate_dir = output_dir / f"candidate_{index:02d}"
        try:
            video = download_public_youtube_video(url, candidate_dir, max_height=max_height)
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            attempts.append({"url": url, "success": False, "error": error})
            print(f"[YouTube] candidate unavailable; trying next: {url} ({error})")
            continue
        attempts.append({"url": url, "success": True, "path": str(video)})
        return video, url, attempts
    return None, None, attempts
