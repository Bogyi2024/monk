from __future__ import annotations

from pathlib import Path
import os

from .config import Settings
from .fal_edit import resolve_fal_background
from .gemini_research import GeminiResearchWriter
from .models import MovieMeta, PipelineManifest, ResearchBrief, ReviewPackage, VideoPlan
from .renderer import render_thumbnail_sync
from .tmdb import TMDBClient
from .utils import slugify, trim, write_json
from .video_plan import create_video_plan, build_voiceover_text, build_video_beats
from .video_renderer import render_review_video, run_tts_command
from .youtube_source import (
    download_first_available_youtube_video,
    search_official_trailer,
    tmdb_youtube_candidate_urls,
)
from .tts_edge import probe_audio_duration
from .tts_gemini import synthesize_gemini_tts
from .scene_matcher import build_scene_catalog, describe_scene_catalog, match_beats_to_scenes
from .caption_renderer import render_reel_caption_overlays_sync
from .web_research import HybridMovieSearch
from .video_sync import align_beats_to_audio_pauses, fit_beats_to_total_audio


def record_own_narration(work_dir: Path, beats) -> Path:
    """Collect complete script-bound narration before any TTS/provider request."""
    import sys
    import array
    studio_app = Path(__file__).resolve().parents[3] / "app"
    if str(studio_app) not in sys.path:
        sys.path.append(str(studio_app))
    from own_voice import VoiceStore, read_pcm, write_pcm, duration as own_duration
    from own_voice_editor import open_standalone
    rows = [{"id": str(b.beat_id), "text": b.narration} for b in beats]
    store = VoiceStore(work_dir)
    if not open_standalone(work_dir, rows, title="Movie Review · ကိုယ်ပိုင်အသံ"):
        if not store.read().get("enabled"):
            raise RuntimeError("AI အသံနဲ့လုပ်ဖို့ ကိုယ်ပိုင်အသံ အမှန်ခြစ်ကို ဖြုတ်ပြီး ပြန်စပါ။ Script ကို ပြန်သုံးပေးမယ်။")
        raise RuntimeError("ကိုယ်ပိုင်အသံသွင်းတာ မပြီးသေးပါ။ ပြန်စရင် script ကို ပြန်သုံးပေးမယ်။")
    recorded = store.resolve(rows)
    if recorded is None:
        raise RuntimeError("ကိုယ်ပိုင်အသံ မရွေးထားပါ")
    combined = array.array("h")
    for beat, path in zip(beats, recorded):
        beat.duration_seconds = own_duration(path)
        combined.extend(read_pcm(path))
    return write_pcm(work_dir / "voiceover_own.wav", combined)


def _facebook_post(review) -> str:
    hashtags = " ".join(f"#{h.lstrip('#')}" for h in review.hashtags)
    parts = [
        review.headline,
        "",
        review.hook,
        "",
        review.review_body,
        "",
        f"Rating — {review.rating_text}",
        "",
        f"ကျနော့်အမြင်ကတော့ {review.verdict}",
    ]
    parts += ["", hashtags]
    return "\n".join(p for p in parts if p is not None).strip() + "\n"


def _short_post(review) -> str:
    hashtags = " ".join(f"#{h.lstrip('#')}" for h in review.hashtags[:8])
    return f"{review.short_caption}\n\n{hashtags}\n"


def _load_review_checkpoint(work_dir: Path, meta: MovieMeta) -> dict | None:
    """Load only a complete, identity-matching pre-video checkpoint."""
    paths = {
        "review_json": work_dir / "review.json",
        "research_file": work_dir / "research_brief.txt",
        "sources_file": work_dir / "sources.md",
        "facebook_file": work_dir / "post_facebook.txt",
        "short_file": work_dir / "post_short.txt",
        "thumbnail": work_dir / "thumbnail.png",
    }
    if any(not path.is_file() or path.stat().st_size <= 0 for path in paths.values()):
        return None
    try:
        review = ReviewPackage.model_validate_json(
            paths["review_json"].read_text(encoding="utf-8-sig")
        )
        research_text = paths["research_file"].read_text(encoding="utf-8-sig").strip()
    except (OSError, ValueError):
        return None

    expected = " ".join(meta.title.casefold().split())
    actual = " ".join(review.movie_title.casefold().split())
    if not research_text or actual != expected:
        return None

    fal_url_file = work_dir / "fal_background_url.txt"
    fal_image = work_dir / "images" / "ai_background.png"
    used_fal = (
        fal_url_file.is_file()
        and bool(fal_url_file.read_text(encoding="utf-8-sig").strip())
        and fal_image.is_file()
        and fal_image.stat().st_size > 0
    )
    return {
        **paths,
        "review": review,
        "research": ResearchBrief(text=research_text, citations=[]),
        "used_fal": used_fal,
    }


def _load_video_plan_checkpoint(path: Path) -> VideoPlan | None:
    if not path.is_file() or path.stat().st_size <= 0:
        return None
    try:
        return VideoPlan.model_validate_json(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return None


def run_pipeline(
    settings: Settings,
    title: str,
    year: int | None,
    platform: str,
    style: str,
    spoilers: bool,
    use_fal: bool,
    make_video: bool = False,
    media_dir: Path | None = None,
    voice_path: Path | None = None,
    youtube_url: str | None = None,
    auto_trailer: bool = False,
    movie_meta: MovieMeta | None = None,
    require_fal: bool = False,
) -> Path:
    from tavily_live import start_search_job
    from movie_review_profiles import accepts_genres, normalize_profile
    # A long-lived caller may reuse Settings; refresh the live switch per job.
    settings.tavily_api_key = start_search_job() or None
    profile = normalize_profile(getattr(settings, "movie_review_profile", "movie_general"))
    tmdb = TMDBClient(settings.tmdb_bearer_token)
    searcher = HybridMovieSearch(
        tavily_api_key=settings.tavily_api_key,
        search_depth=settings.tavily_search_depth,
        max_total_results=settings.search_max_results,
        preferred_sources=settings.preferred_sources,
        min_relevant_sources=settings.research_min_sources,
        min_distinct_domains=settings.research_min_domains,
        max_source_chars=settings.research_source_chars,
    )
    llm = GeminiResearchWriter(
        api_key=settings.gemini_writer_api_key,
        api_keys=settings.gemini_writer_api_keys,
        key_aliases=settings.gemini_key_aliases,
        writer_model=settings.gemini_writer_model,
        writer_fallback_model=settings.gemini_writer_fallback_model,
        vision_model=settings.gemini_vision_model,
        vision_fallback_model=settings.gemini_vision_fallback_model,
        request_timeout_seconds=settings.gemini_request_timeout_seconds,
    )

    search_label = "Tavily -> DDGS fallback" if settings.tavily_api_key else "DDGS primary"
    print(f"[Search] {search_label}")
    print(f"[Writer] Gemini Interactions API: {settings.gemini_writer_model} | rotating keys={len(settings.gemini_writer_api_keys)}")
    print(f"[Vision] Gemini trailer-frame model: {settings.gemini_vision_model}")

    print("[1/5] Finding movie metadata + images via TMDB...")
    meta = movie_meta or tmdb.find_movie(title, year)
    if not accepts_genres(profile, meta.genres):
        raise RuntimeError("Movie rejected: TMDB genre does not match Horror / Thriller profile.")
    print(f"[Movie Review profile] {profile}")

    slug = slugify(f"{meta.title}-{meta.year or ''}")
    work_dir = settings.output_dir / slug
    work_dir.mkdir(parents=True, exist_ok=True)
    checkpoint = _load_review_checkpoint(work_dir, meta) if make_video else None
    if checkpoint:
        print(
            "[Resume] valid review + research + thumbnail checkpoint found; "
            "continuing from Reel generation"
        )
        review = checkpoint["review"]
        research = checkpoint["research"]
        review_json = checkpoint["review_json"]
        research_file = checkpoint["research_file"]
        sources_file = checkpoint["sources_file"]
        facebook_file = checkpoint["facebook_file"]
        short_file = checkpoint["short_file"]
        thumbnail = checkpoint["thumbnail"]
        used_fal = bool(checkpoint["used_fal"])
    else:
        print("[2/5] Researching reviews/opinions with Tavily/DDGS (NO Gemini Search Grounding)...")
        research = llm.research(meta, searcher, spoilers=spoilers)
        write_json(work_dir / "web_search_results.json", [x.to_dict() for x in llm.last_search_results])

        print("[3/5] Writing original Burmese review with Gemini...")
        review = llm.write_review(meta, research, platform, style, spoilers)
        if llm.last_thumbnail_candidates:
            write_json(work_dir / "thumbnail_hook_candidates.json", llm.last_thumbnail_candidates)

        thumb_cfg = settings.raw.get("thumbnail", {})
        review.thumbnail_title = trim(review.thumbnail_title, int(thumb_cfg.get("headline_max_chars", 42)))
        review.thumbnail_kicker = trim(review.thumbnail_kicker, int(thumb_cfg.get("kicker_max_chars", 55)))

        review_json = work_dir / "review.json"
        write_json(review_json, review.model_dump())

        research_file = work_dir / "research_brief.txt"
        research_file.write_text(research.text, encoding="utf-8")

        sources_file = work_dir / "sources.md"
        source_lines = [f"# Sources for {meta.title}", ""]
        source_lines += [f"- [{c.title}]({c.url})" for c in research.citations]
        sources_file.write_text("\n".join(source_lines) + "\n", encoding="utf-8")

        facebook_file = work_dir / "post_facebook.txt"
        facebook_file.write_text(_facebook_post(review), encoding="utf-8")

        short_file = work_dir / "post_short.txt"
        short_file.write_text(_short_post(review), encoding="utf-8")

        ai_background_url = None
        used_fal = False
        if use_fal:
            if not settings.fal_key:
                print("[4/5] FAL requested but FAL_KEY is missing; using normal Chromium composition.")
            else:
                print("[4/5] Creating optional AI cinematic composite with fal...")
                ai_background_url, used_fal = resolve_fal_background(
                    settings,
                    meta,
                    work_dir,
                    require_fal,
                )
        else:
            print("[4/5] FAL disabled; using TMDB artwork + Chromium composition.")

        print("[5/5] Rendering Burmese thumbnail with Chromium...")
        thumbnail = render_thumbnail_sync(
            Path(__file__).resolve().parent.parent / "templates",
            work_dir,
            meta,
            review,
            ai_background_url=ai_background_url,
            width=int(thumb_cfg.get("width", 1280)),
            height=int(thumb_cfg.get("height", 720)),
        )

    video_out: Path | None = None
    voiceover_txt: Path | None = None
    if make_video:
        print("[video] Discovering trailer references via TMDB...")
        trailer_refs = tmdb.get_video_refs(meta.tmdb_id)
        write_json(work_dir / "trailer_references.json", [x.model_dump() for x in trailer_refs])

        print("[video] Building Burmese Reel storyboard + narration with Gemini...")
        video_cfg = settings.raw.get("video", {})
        video_plan_path = work_dir / "video_storyboard.json"
        plan = _load_video_plan_checkpoint(video_plan_path)
        if plan:
            print("[Resume] valid Reel storyboard checkpoint found; reusing it")
        else:
            plan = create_video_plan(
                llm,
                meta,
                research,
                review,
                target_seconds=int(video_cfg.get("target_seconds", 60)),
            )
            write_json(video_plan_path, plan.model_dump())
        beats = build_video_beats(plan)
        write_json(work_dir / "video_beats.json", [x.model_dump() for x in beats])

        voiceover_txt = work_dir / "voiceover.txt"
        voiceover_txt.write_text(build_voiceover_text(plan), encoding="utf-8")

        resolved_voice = voice_path
        if os.environ.get("STUDIO99_OWN_VOICE") == "1":
            resolved_voice = record_own_narration(work_dir, beats)
            audio_duration = probe_audio_duration(resolved_voice)
        elif resolved_voice is None and settings.tts_command:
            print("[video] Running custom TTS command...")
            resolved_voice = run_tts_command(settings.tts_command, voiceover_txt, work_dir / "voiceover.wav")
            audio_duration = probe_audio_duration(resolved_voice)
            beats = fit_beats_to_total_audio(beats, audio_duration)
        elif resolved_voice is None:
            print(
                f"[video] Google AI Studio Gemini TTS: {settings.gemini_tts_voice} "
                f"| speed={settings.gemini_tts_speed:.2f}x"
            )
            # Keep one Google TTS request for the whole script so voice tone,
            # pitch and delivery cannot reset between subtitle paragraphs.
            resolved_voice = synthesize_gemini_tts(
                build_voiceover_text(plan),
                work_dir / "voiceover_gemini.wav",
                api_keys=settings.gemini_writer_api_keys,
                key_aliases=settings.gemini_key_aliases,
                model=settings.gemini_tts_model,
                voice=settings.gemini_tts_voice,
                speed=settings.gemini_tts_speed,
            )
            audio_duration = probe_audio_duration(resolved_voice)
            beats = align_beats_to_audio_pauses(beats, resolved_voice, audio_duration)
        else:
            audio_duration = probe_audio_duration(resolved_voice)
            beats = fit_beats_to_total_audio(beats, audio_duration)

        narration_duration = probe_audio_duration(resolved_voice) if resolved_voice else 0.0
        visual_duration = sum(float(b.duration_seconds) for b in beats)
        print(f"[video] Synced beat timing: visuals={visual_duration:.2f}s narration={narration_duration:.2f}s")
        write_json(work_dir / "video_beats_synced.json", [x.model_dump() for x in beats])

        print("[video] Rendering FULL Burmese narration subtitles with Chromium...")
        caption_overlays = render_reel_caption_overlays_sync(
            Path(__file__).resolve().parent.parent / "templates",
            work_dir,
            beats,
            width=int(video_cfg.get("width", 1080)),
            height=int(video_cfg.get("height", 1920)),
        )

        source_video = None
        selected_url = None
        youtube_attempts: list[dict] = []
        youtube_max_height = int(video_cfg.get("youtube_max_height", 1080))

        if youtube_url:
            primary_urls = [youtube_url]
            print("[video] Trying the requested YouTube visual source...")
        elif auto_trailer:
            # A TMDB record may retain a removed trailer while another official
            # trailer/teaser is still public. Try a bounded ordered set first.
            primary_urls = tmdb_youtube_candidate_urls(trailer_refs)[:5]
            if primary_urls:
                print(f"[video] Trying {len(primary_urls)} TMDB YouTube visual candidate(s)...")
            else:
                print("[video] TMDB has no YouTube visual references.")
        else:
            primary_urls = []

        if primary_urls:
            source_video, selected_url, attempts = download_first_available_youtube_video(
                primary_urls,
                work_dir / "youtube" / "tmdb",
                max_height=youtube_max_height,
            )
            youtube_attempts.extend(attempts)

        # Search only after every TMDB candidate fails. This is the missing
        # fallback that previously let one removed trailer terminate the job.
        if auto_trailer and not youtube_url and source_video is None:
            print("[video] TMDB candidates unavailable; searching YouTube for alternatives...")
            try:
                _best_url, search_candidates = search_official_trailer(
                    meta.title,
                    meta.year,
                    max_results=int(video_cfg.get("trailer_search_results", 5)),
                )
                write_json(
                    work_dir / "youtube_search_candidates.json",
                    [candidate.__dict__ for candidate in search_candidates],
                )
                source_video, selected_url, attempts = download_first_available_youtube_video(
                    [candidate.url for candidate in search_candidates],
                    work_dir / "youtube" / "search",
                    max_height=youtube_max_height,
                )
                youtube_attempts.extend(attempts)
            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"
                youtube_attempts.append({"phase": "search", "success": False, "error": error})
                print(f"[video] YouTube alternative search unavailable ({error}).")

        write_json(work_dir / "youtube_download_attempts.json", youtube_attempts)
        selected_url_file = work_dir / "selected_youtube_url.txt"
        selected_url_file.write_text(
            (selected_url + "\n") if selected_url else "",
            encoding="utf-8",
        )
        if source_video:
            print(f"[video] YouTube visual source ready: {selected_url}")
        elif primary_urls or auto_trailer:
            print("[video] No downloadable YouTube candidate; continuing with TMDB/local still visuals.")

        if media_dir is None:
            default_media = Path(video_cfg.get("authorized_media_dir", "media"))
            if not default_media.is_absolute():
                default_media = Path(__file__).resolve().parent.parent / default_media
            media_dir = default_media

        scene_catalog = None
        scene_matches = None
        if source_video and source_video.exists():
            print("[video] Building trailer scene library...")
            scene_catalog = build_scene_catalog(
                source_video,
                work_dir / "scene_frames",
                threshold=float(video_cfg.get("scene_threshold", 0.28)),
                max_scenes=int(video_cfg.get("max_scene_candidates", 24)),
            )
            scene_catalog = describe_scene_catalog(llm, scene_catalog)
            write_json(work_dir / "scene_catalog.json", scene_catalog.model_dump())

            print("[video] Matching narration beats to trailer scenes with Gemini...")
            try:
                scene_matches = match_beats_to_scenes(llm, beats, scene_catalog)
                write_json(work_dir / "scene_matches.json", scene_matches.model_dump())
            except Exception as exc:
                # Semantic matching improves scene choice, but it must never hold
                # up an otherwise complete Reel. The renderer has a deterministic
                # moving-video fallback using the downloaded trailer.
                print(f"[video] Gemini scene matching unavailable ({type(exc).__name__}: {exc}); using trailer-video fallback.")
                scene_matches = None

        print("[video] Rendering 1080x1920 Reel; original source audio is discarded...")
        video_out = render_review_video(
            meta=meta,
            beats=beats,
            work_dir=work_dir,
            media_dir=media_dir,
            voice_path=resolved_voice,
            source_file=source_video,
            width=int(video_cfg.get("width", 1080)),
            height=int(video_cfg.get("height", 1920)),
            fps=int(video_cfg.get("fps", 30)),
            scene_catalog=scene_catalog,
            scene_matches=scene_matches,
            min_confidence=float(video_cfg.get("match_min_confidence", 0.45)),
            caption_overlays=caption_overlays,
            recorded_narration=os.environ.get("STUDIO99_OWN_VOICE") == "1",
        )
        (work_dir / "video_output_path.txt").write_text(str(video_out), encoding="utf-8")

    manifest = PipelineManifest(
        content_id=f"movie_review:tmdb:{meta.tmdb_id}",
        tmdb_id=meta.tmdb_id,
        title=meta.title,
        year=meta.year,
        review_json=str(review_json),
        facebook_post=str(facebook_file),
        short_post=str(short_file),
        sources_file=str(sources_file),
        thumbnail=str(thumbnail),
        video=str(video_out.resolve()) if video_out else "",
        voiceover=str(voiceover_txt.resolve()) if voiceover_txt else "",
        used_fal=used_fal,
        fal_model=settings.fal_image_model if used_fal else "",
        destinations={
            "facebook_post": {"text": str(facebook_file.resolve()), "image": str(thumbnail.resolve())},
            "facebook_reel": {"caption": str(short_file.resolve()), "video": str(video_out.resolve()) if video_out else ""},
            "tiktok_reel": {"caption": str(short_file.resolve()), "video": str(video_out.resolve()) if video_out else ""},
        },
    )
    manifest_data = manifest.model_dump()
    manifest_data["movie_review_profile"] = profile
    manifest_data["movie_genres"] = list(meta.genres)
    manifest_data["tt_route_key"] = os.getenv("MOVIE_REVIEW_TT_ROUTE_KEY", "")
    write_json(work_dir / "manifest.json", manifest_data)

    print(f"\nDONE -> {work_dir}")
    return work_dir
