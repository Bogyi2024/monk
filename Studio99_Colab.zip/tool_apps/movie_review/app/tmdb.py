from __future__ import annotations

from datetime import date
import httpx

from .models import MovieMeta, TrailerRef


class TMDBClient:
    BASE = "https://api.themoviedb.org/3"
    IMAGE_BASE = "https://image.tmdb.org/t/p"

    def __init__(self, bearer_token: str):
        import os                                    # Studio99: the server holds the TMDB token
        proxy = os.environ.get("STUDIO99_TMDB_PROXY", "").strip()
        if proxy:
            self.BASE = proxy.rstrip("/")
            bearer_token = os.environ.get("STUDIO99_TOKEN", "")
        if not bearer_token:
            raise RuntimeError("TMDB_BEARER_TOKEN is missing in .env")
        self.client = httpx.Client(
            timeout=30,
            headers={
                "Authorization": bearer_token if proxy else f"Bearer {bearer_token}",
                "accept": "application/json",
                "User-Agent": "MovieReviewAuto/1.0",
            },
        )

    def _get(self, path: str, params: dict | None = None) -> dict:
        r = self.client.get(f"{self.BASE}{path}", params=params)
        r.raise_for_status()
        return r.json()

    def find_movie(self, title: str, year: int | None = None) -> MovieMeta:
        params = {"query": title, "include_adult": "false", "language": "en-US"}
        if year:
            params["year"] = str(year)

        search = self._get("/search/movie", params=params)
        results = search.get("results") or []
        if not results:
            raise RuntimeError(f"TMDB: movie not found: {title} {year or ''}".strip())

        return self.get_movie(int(results[0]["id"]), fallback_title=title, fallback_year=year)

    def get_movie(self, movie_id: int, fallback_title: str = "", fallback_year: int | None = None) -> MovieMeta:
        details = self._get(f"/movie/{int(movie_id)}", {"language": "en-US"})

        images = self._get(
            f"/movie/{movie_id}/images",
            {"include_image_language": "en,null"},
        )

        posters = sorted(images.get("posters") or [], key=lambda x: x.get("vote_average", 0), reverse=True)
        backdrops = sorted(images.get("backdrops") or [], key=lambda x: x.get("vote_average", 0), reverse=True)

        poster_urls = [f"{self.IMAGE_BASE}/w780{x['file_path']}" for x in posters[:6]]
        backdrop_urls = [f"{self.IMAGE_BASE}/w1280{x['file_path']}" for x in backdrops[:6]]

        if not poster_urls and details.get("poster_path"):
            poster_urls = [f"{self.IMAGE_BASE}/w780{details['poster_path']}"]
        if not backdrop_urls and details.get("backdrop_path"):
            backdrop_urls = [f"{self.IMAGE_BASE}/w1280{details['backdrop_path']}"]

        release_date = details.get("release_date") or ""
        parsed_year = None
        if len(release_date) >= 4 and release_date[:4].isdigit():
            parsed_year = int(release_date[:4])

        return MovieMeta(
            tmdb_id=movie_id,
            title=details.get("title") or fallback_title,
            original_title=details.get("original_title") or "",
            year=parsed_year or fallback_year,
            overview=details.get("overview") or "",
            genres=[g.get("name", "") for g in details.get("genres") or [] if g.get("name")],
            vote_average=details.get("vote_average"),
            poster_urls=poster_urls,
            backdrop_urls=backdrop_urls,
        )

    def discover_movies(self, pages_per_source: int = 5) -> list[dict]:
        """Return a broad current quality pool instead of exhausting two TMDB pages."""
        candidates: list[dict] = []
        seen: set[int] = set()
        today = date.today().isoformat()
        sources = (
            ("/trending/movie/week", {}),
            ("/movie/now_playing", {}),
            ("/movie/popular", {}),
            ("/movie/top_rated", {}),
            ("/discover/movie", {
                "sort_by": "popularity.desc",
                "include_adult": "false",
                "include_video": "false",
                "primary_release_date.lte": today,
                "vote_count.gte": "40",
            }),
        )
        for path, extra_params in sources:
            for page in range(1, max(1, pages_per_source) + 1):
                params = {"language": "en-US", "page": page, **extra_params}
                data = self._get(path, params)
                for item in data.get("results") or []:
                    movie_id = int(item.get("id") or 0)
                    release_date = str(item.get("release_date") or "")
                    if not movie_id or movie_id in seen or item.get("adult"):
                        continue
                    if release_date and release_date > today:
                        continue
                    if int(item.get("vote_count") or 0) < 40:
                        continue
                    if float(item.get("vote_average") or 0) < 5.2:
                        continue
                    seen.add(movie_id)
                    year = int(release_date[:4]) if len(release_date) >= 4 and release_date[:4].isdigit() else None
                    candidates.append({
                        "tmdb_id": movie_id,
                        "title": str(item.get("title") or item.get("original_title") or "").strip(),
                        "year": year,
                        "vote_average": float(item.get("vote_average") or 0),
                        "vote_count": int(item.get("vote_count") or 0),
                        "source": path,
                    })
        return candidates



def _video_url(site: str, key: str) -> str:
    s = (site or "").lower()
    if s == "youtube":
        return f"https://www.youtube.com/watch?v={key}"
    if s == "vimeo":
        return f"https://vimeo.com/{key}"
    return ""


def _video_sort_key(item: dict):
    return (
        1 if item.get("official") else 0,
        1 if (item.get("type") or "").lower() == "trailer" else 0,
        item.get("published_at") or "",
    )


def _get_video_refs(self, movie_id: int) -> list[TrailerRef]:
    data = self._get(f"/movie/{movie_id}/videos", {"language": "en-US"})
    results = sorted(data.get("results") or [], key=_video_sort_key, reverse=True)
    refs: list[TrailerRef] = []
    for item in results:
        site = item.get("site") or ""
        key = item.get("key") or ""
        if not key:
            continue
        refs.append(
            TrailerRef(
                name=item.get("name") or "Trailer",
                site=site,
                key=key,
                type=item.get("type") or "",
                official=bool(item.get("official")),
                published_at=item.get("published_at") or "",
                url=_video_url(site, key),
            )
        )
    return refs


TMDBClient.get_video_refs = _get_video_refs
