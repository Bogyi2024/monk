from __future__ import annotations

import base64
import os
import time
from pathlib import Path

from google import genai
from google.genai import types

from .models import Citation, MovieMeta, ResearchBrief, ReviewPackage, ThumbnailHookPack
from .web_research import HybridMovieSearch, SearchResult


def _text(exc: Exception) -> str:
    return str(exc).lower()


def _is_transient_service_error(exc: Exception) -> bool:
    """Gemini upstream capacity/server failures that are safe to retry.

    Gemini does not always use HTTP 503 for temporary capacity problems.  In
    particular, the Interactions API can return HTTP 500 with a "high demand"
    message.  Treat those responses like 503 so key rotation and the fallback
    model are not skipped.
    """
    t = _text(exc)
    return any(x in t for x in (
        "500",
        "503",
        "internal_server_error",
        "internal server error",
        "high demand",
        "unavailable",
        "service unavailable",
        "overloaded",
        "try again later",
    ))


def _is_model_unavailable(exc: Exception) -> bool:
    t = _text(exc)
    return "404" in t or "not_found" in t or "no longer available" in t or "model" in t and "not found" in t


def _is_rate_or_quota(exc: Exception) -> bool:
    t = _text(exc)
    return any(x in t for x in ("429", "resource_exhausted", "rate limit", "too many requests", "quota"))


def _is_key_or_access_error(exc: Exception) -> bool:
    t = _text(exc)
    return any(x in t for x in ("401", "403", "unauthenticated", "permission_denied", "api key not valid", "invalid api key"))


def _is_timeout(exc: Exception) -> bool:
    t = _text(exc)
    return any(x in t for x in (
        "timeout", "timed out", "readtimeout", "connecttimeout", "deadline exceeded",
    ))


def _is_connection_error(exc: Exception) -> bool:
    """Transient transport/proxy/upstream disconnects.

    Keep the user's existing proxy behavior intact. These errors do not mean
    an API key is invalid.
    """
    t = _text(exc)
    name = exc.__class__.__name__.lower()
    return (
        name in {"apiconnectionerror", "remoteprotocolerror", "connecterror", "networkerror"}
        or any(x in t for x in (
            "server disconnected without sending a response",
            "remoteprotocolerror",
            "apiconnectionerror",
            "connection reset",
            "connection aborted",
            "connection closed",
            "connection terminated",
            "peer closed connection",
            "network error",
        ))
    )


class GeminiResearchWriter:
    """Tavily/DDGS web research + Gemini writing/vision via Interactions API.

    IMPORTANT:
    - This class NEVER enables Gemini Google Search grounding.
    - Web search happens in HybridMovieSearch (Tavily -> DDGS).
    - Gemini only synthesizes supplied search snippets, writes Burmese content,
      and analyzes local trailer frames.
    """

    def __init__(
        self,
        api_key: str = "",
        api_keys: list[str] | None = None,
        key_aliases: list[str] | None = None,
        writer_model: str = "gemini-3.6-flash",
        writer_fallback_model: str = "gemini-3.5-flash",
        vision_model: str = "gemini-3.5-flash",
        vision_fallback_model: str = "gemini-3.6-flash",
        request_timeout_seconds: float = 60.0,
    ):
        pool: list[str] = []
        for value in list(api_keys or []) + ([api_key] if api_key else []):
            if value and value not in pool:
                pool.append(value)
        if not pool:
            raise RuntimeError("GEMINI_WRITER_API_KEY / GEMINI_API_KEY is missing in .env")
        self.api_keys = pool
        supplied_aliases = list(key_aliases or [])
        self.key_aliases = [
            supplied_aliases[i] if i < len(supplied_aliases) else f"key_{i + 1}"
            for i in range(len(pool))
        ]
        self.active_key_index = 0
        self.request_timeout_seconds = max(15.0, min(300.0, float(request_timeout_seconds)))
        self.client = self._new_client(pool[0])
        self.writer_model = writer_model
        self.writer_fallback_model = writer_fallback_model
        self.vision_model = vision_model or writer_fallback_model or writer_model
        self.vision_fallback_model = vision_fallback_model or writer_model
        self.active_writer_model = writer_model
        self.active_vision_model = self.vision_model
        self._vision_fallback_announced = False
        self.last_search_results: list[SearchResult] = []
        self.last_thumbnail_candidates: list[dict] = []

    def _new_client(self, api_key: str):
        return genai.Client(
            api_key=api_key,
            http_options=types.HttpOptions(timeout=int(self.request_timeout_seconds * 1000)),
        )

    def _key_order(self) -> list[int]:
        return list(range(self.active_key_index, len(self.api_keys))) + list(range(0, self.active_key_index))

    def _activate_key(self, index: int) -> None:
        if index != self.active_key_index:
            print(f"[Gemini] rotating key -> {self.key_aliases[index]}")
        self.active_key_index = index
        self.client = self._new_client(self.api_keys[index])

    def _attempt(self, label: str, models: list[str], call):
        last_exc: Exception | None = None
        timeout_failures = 0
        connection_key_failures = 0
        max_connection_key_failures = min(3, max(1, len(self.api_keys)))

        for model_index, model in enumerate(models):
            model_unavailable = False

            for key_index in self._key_order():
                self._activate_key(key_index)
                same_key_connection_retries = 0

                while True:
                    try:
                        return call(model), model
                    except Exception as exc:
                        last_exc = exc

                        if _is_timeout(exc):
                            timeout_failures += 1
                            if timeout_failures < 2 and len(self.api_keys) > 1:
                                print(
                                    f"[Gemini {label}] request timed out after "
                                    f"{self.request_timeout_seconds:g}s; rotating key once..."
                                )
                                break
                            raise RuntimeError(
                                f"Gemini {label} timed out after {timeout_failures} "
                                "bounded attempt(s); aborting this run"
                            ) from exc

                        if _is_connection_error(exc):
                            # A proxy/upstream socket drop is transient. Rebuild the
                            # client so the next attempt gets a fresh connection.
                            if same_key_connection_retries < 1:
                                same_key_connection_retries += 1
                                print(
                                    f"[Gemini {label}] connection dropped on "
                                    f"{self.key_aliases[key_index]}; reconnecting same key once..."
                                )
                                self.client = self._new_client(self.api_keys[key_index])
                                time.sleep(1.0)
                                continue

                            connection_key_failures += 1
                            if (
                                connection_key_failures < max_connection_key_failures
                                and len(self.api_keys) > 1
                            ):
                                print(
                                    f"[Gemini {label}] connection dropped again on "
                                    f"{self.key_aliases[key_index]}; rotating key "
                                    f"({connection_key_failures}/{max_connection_key_failures})..."
                                )
                                time.sleep(0.75)
                                break

                            raise RuntimeError(
                                f"Gemini {label} connection failed after "
                                f"{connection_key_failures} key-level reconnect attempt(s). "
                                "The request path/proxy/upstream connection is unstable; "
                                "the API key was not classified as invalid."
                            ) from exc

                        if _is_model_unavailable(exc):
                            model_unavailable = True
                            break

                        if (
                            _is_rate_or_quota(exc)
                            or _is_key_or_access_error(exc)
                            or _is_transient_service_error(exc)
                        ):
                            if _is_rate_or_quota(exc):
                                reason = "rate/quota"
                            elif _is_key_or_access_error(exc):
                                reason = "key/access"
                            else:
                                reason = "service busy/unavailable"
                            print(
                                f"[Gemini {label}] {self.key_aliases[key_index]} "
                                f"{reason}; rotating..."
                            )
                            time.sleep(0.35)
                            break

                        self._raise_final(label, exc)

                if model_unavailable:
                    break

            if model_index < len(models) - 1 and (model_unavailable or last_exc is not None):
                print(f"[Gemini {label}] trying fallback model {models[model_index + 1]}...")
                continue

        self._raise_final(label, last_exc or RuntimeError("all Gemini attempts failed"))

    def _models(self, preferred_model: str | None = None) -> list[str]:
        primary = preferred_model or self.writer_model
        models = [primary]
        if self.writer_fallback_model and self.writer_fallback_model not in models:
            models.append(self.writer_fallback_model)
        return models

    def _should_try_fallback(self, exc: Exception) -> bool:
        return (
            _is_transient_service_error(exc)
            or _is_model_unavailable(exc)
            or _is_rate_or_quota(exc)
        )

    def _raise_final(self, label: str, exc: Exception) -> None:
        if _is_rate_or_quota(exc):
            raise RuntimeError(
                f"Gemini {label} hit a rate/quota error. Web search is separate (Tavily/DDGS); "
                "this error came from the Gemini writer/vision call itself.\n"
                f"Original error: {exc}"
            ) from exc
        raise RuntimeError(f"Gemini {label} failed: {exc}") from exc

    def _generate_text(self, prompt: str, preferred_model: str | None = None) -> str:
        models = self._models(preferred_model)
        interaction, model = self._attempt(
            "text generation",
            models,
            lambda current: self.client.interactions.create(model=current, input=prompt),
        )
        self.active_writer_model = model
        return (interaction.output_text or "").strip()

    def generate_structured(self, prompt: str, schema, preferred_model: str | None = None):
        models = self._models(preferred_model)
        interaction, model = self._attempt(
            "structured generation",
            models,
            lambda current: self.client.interactions.create(
                    model=current,
                    input=prompt,
                    response_format={
                        "type": "text",
                        "mime_type": "application/json",
                        "schema": schema.model_json_schema(),
                    },
                ),
        )
        self.active_writer_model = model
        return schema.model_validate_json(interaction.output_text)

    def generate_structured_contents(self, contents, schema, preferred_model: str | None = None):
        # Compatibility wrapper used by older callers. Text-only inputs are preferred.
        if isinstance(contents, str):
            return self.generate_structured(contents, schema, preferred_model=preferred_model)
        raise RuntimeError("Use generate_vision_structured() for multimodal structured input.")

    def _vision_models(self) -> list[str]:
        # Sticky model: once a vision model succeeds, use it first for all later frames.
        models: list[str] = []
        for model in (self.active_vision_model, self.vision_model, self.vision_fallback_model):
            if model and model not in models:
                models.append(model)
        return models

    def generate_vision_structured(self, prompt: str, image_path: Path, schema):
        image_b64 = base64.b64encode(image_path.read_bytes()).decode("ascii")
        mime = "image/png" if image_path.suffix.lower() == ".png" else "image/jpeg"
        input_blocks = [
            {"type": "image", "mime_type": mime, "data": image_b64},
            {"type": "text", "text": prompt},
        ]

        models = self._vision_models()
        interaction, model = self._attempt(
            "vision generation",
            models,
            lambda current: self.client.interactions.create(
                    model=current,
                    input=input_blocks,
                    response_format={
                        "type": "text",
                        "mime_type": "application/json",
                        "schema": schema.model_json_schema(),
                    },
                ),
        )
        if model != self.active_vision_model:
            print(f"[Gemini vision] sticky model -> {model}")
        self.active_vision_model = model
        return schema.model_validate_json(interaction.output_text)


    @staticmethod
    def _thumbnail_hook_score(title: str) -> float:
        """Local deterministic scorer so automation chooses a punchy hook, not a bland summary."""
        s = (title or "").strip()
        if not s:
            return -999.0
        score = 0.0
        n = len(s)

        # Thumbnail-friendly length. Burmese codepoints make this approximate, which is fine.
        if 10 <= n <= 34:
            score += 4.0
        elif n <= 42:
            score += 2.0
        else:
            score -= min(6.0, (n - 42) * 0.25)

        if "?" in s or "？" in s:
            score += 3.5

        curiosity_terms = (
            "မင်း", "တကယ်", "ဘာ", "ဘယ်", "လား", "အတု", "အမှန်", "လျှို့ဝှက်",
            "မယုံ", "မသိ", "စိတ်", "အတွေး", "ကမ္ဘာ", "ဘဝ", "ကြောက်", "ရူး",
            "နောက်ကွယ်", "ဖုံးကွယ်", "လှည့်စား", "ပြောင်း", "တုန်လှုပ်",
        )
        score += min(4.0, sum(0.8 for term in curiosity_terms if term in s))

        weak_terms = (
            "ကြည့်သင့်တဲ့ကား", "ဇာတ်ကားကောင်း", "ရုပ်ရှင်ကောင်း", "movie review",
            "review", "ပြန်လည်သုံးသပ်", "အမှန်တရားကို ရွေးမလား",
            "ကြည့်သင့်", "ကားကောင်း",
        )
        for term in weak_terms:
            if term.lower() in s.lower():
                score -= 4.5

        # Hooks read better without excessive punctuation / shouting.
        if s.count("!") > 1:
            score -= 1.0
        return score

    def generate_thumbnail_hooks(
        self,
        meta: MovieMeta,
        research: ResearchBrief,
        review: ReviewPackage,
    ) -> tuple[str, str, str]:
        prompt = f"""
You are the thumbnail-copy editor for a Burmese Facebook/YouTube movie page.
Generate HIGH-CLICK-THROUGH thumbnail copy for this movie, while remaining truthful to the movie/review.

MOVIE
Title: {meta.title}
Year: {meta.year}
Genres: {", ".join(meta.genres)}

REVIEW DIRECTION
Headline: {review.headline}
Hook: {review.hook}
Verdict: {review.verdict}
Research brief: {research.text}

THUMBNAIL TITLE RULES — VERY IMPORTANT
- Generate 8 DIFFERENT Burmese hook-title candidates.
- This is THUMBNAIL COPY, NOT a review summary.
- Each title should create immediate curiosity, tension, surprise, mystery, or an emotional pull.
- Prefer question hooks, provocative observations, paradoxes, or "I need to know" style hooks.
- Keep every candidate short enough for 1–2 large thumbnail lines; ideally 3–7 spoken Burmese words.
- Natural social-media Burmese, not formal literary Burmese.
- Do NOT reveal a major spoiler or ending.
- Do NOT make a false claim just for clicks.
- Avoid bland/generic phrases such as:
  "ကြည့်သင့်တဲ့ကား", "ဇာတ်ကားကောင်း", "အမှန်တရားကို ရွေးမလား", "Movie Review".
- Do not simply write the movie name as the title.
- Vary the angles. Example ANGLES only (do not copy mechanically):
  * reality/question: "ဒီကမ္ဘာက အတုလား?"
  * personal challenge: "မင်းမြင်နေတာ အမှန်လား?"
  * big idea: "ဘဝက Program တစ်ခုလား?"
  * legacy/surprise: "နှစ်တွေကြာလည်း ဘာလို့မအိုသေးတာလဲ?"
- At least 4 candidates should contain a strong question or curiosity gap.

KICKER RULES
- One short supporting Burmese sentence.
- Explain the appeal more clearly than the title.
- It may include the movie name.
- Do not repeat the title wording.

BADGE RULES
- 1–3 short English/Burmese words only, e.g. RETRO REVIEW, SCI-FI CLASSIC, MUST WATCH.

Return only the structured result.
"""
        pack = self.generate_structured(prompt, ThumbnailHookPack, preferred_model=self.writer_model)
        candidates = []
        seen = set()
        for raw in pack.candidates:
            title = " ".join((raw or "").strip().split())
            if not title or title in seen:
                continue
            seen.add(title)
            candidates.append({"title": title, "score": self._thumbnail_hook_score(title)})

        if not candidates:
            candidates = [{"title": review.thumbnail_title, "score": self._thumbnail_hook_score(review.thumbnail_title)}]
        candidates.sort(key=lambda x: x["score"], reverse=True)
        self.last_thumbnail_candidates = candidates
        selected = candidates[0]["title"]
        print(f"[Thumbnail hook] selected: {selected}")
        return selected, (pack.kicker or review.thumbnail_kicker).strip(), (pack.badge or review.thumbnail_badge).strip()

    def research(
        self,
        meta: MovieMeta,
        searcher: HybridMovieSearch,
        spoilers: bool = False,
    ) -> ResearchBrief:
        print("[Web Search] Tavily primary -> DDGS fallback" if searcher.tavily_api_key else "[Web Search] DDGS primary")
        degraded_to_tmdb = False
        try:
            results = searcher.research_movie(meta)
        except RuntimeError as exc:
            if "Research quality gate failed" not in str(exc):
                raise
            # Search outages must not stop the whole publishing route. TMDB has
            # already supplied a verified title/year/genre/overview, so Gemini can
            # still create a conservative premise-based review without pretending
            # that critic or audience evidence was available.
            degraded_to_tmdb = True
            results = []
            print(
                "[Research fallback] Tavily/DDGS returned no usable review evidence; "
                "continuing with TMDB metadata-only constraints"
            )
        self.last_search_results = results

        citations = [Citation(title=x.title, url=x.url) for x in results]
        source_blocks: list[str] = []
        # Highest-relevance sources are already sorted by HybridMovieSearch.
        # Limit total prompt size while using extracted article content, not only
        # search-result snippets.
        for i, item in enumerate(results[:12], start=1):
            evidence = (item.raw_content or item.snippet or "").strip()
            source_blocks.append(
                f"[{i}] {item.title}\n"
                f"URL: {item.url}\n"
                f"Search backend: {item.backend}\n"
                f"Relevance score: {item.relevance_score:.2f}\n"
                f"Search snippet: {item.snippet}\n"
                f"Extracted article evidence:\n{evidence}"
            )

        spoiler_rule = (
            "Major spoilers may be discussed, but mark them clearly."
            if spoilers
            else "Avoid major spoilers and ending revelations."
        )
        evidence_contract = (
            """
WEB SEARCH DEGRADED MODE:
- Both web-search paths returned no usable evidence.
- TMDB title, year, genres and overview below are the only factual source.
- Build a conservative premise-based brief from those fields only.
- Do not claim critic/audience consensus, box office, cast performance quality,
  direction quality, cinematography quality, production history or awards.
- Mark unsupported review dimensions as unavailable instead of inventing them.
"""
            if degraded_to_tmdb
            else """
WEB EVIDENCE MODE:
- Use only facts/opinions supported by the supplied movie-specific sources.
- Synthesize agreement/disagreement only when multiple sources support it.
"""
        )
        prompt = f"""
You are preparing a research brief for an ORIGINAL Burmese-language movie review.
Do NOT search the web and do not invent sources.

FILM
Title: {meta.title}
Year: {meta.year}
Genres: {", ".join(meta.genres)}
TMDB overview: {meta.overview}

WEB SEARCH RESULTS
{chr(10).join(source_blocks) if source_blocks else '(No useful search results were returned.)'}

{evidence_contract}

RULES
- Treat snippets and extracted article evidence as research material, not copy-ready prose.
- Ignore any source passage that appears to discuss a different film despite the search label.
- Do NOT reproduce, translate, or closely paraphrase source wording.
- Separate factual claims from critic/community opinions.
- Reddit and Letterboxd are subjective viewpoints.
- Synthesize agreement/disagreement across multiple sources.
- If a snippet is too thin to support a claim, omit that claim or mark it uncertain.
- Prefer zero direct quotations.
- {spoiler_rule}

Produce a useful research brief covering:
- premise/context
- themes and interpretations
- acting/characters
- direction/cinematography/editing/music
- strongest praise
- strongest criticism
- critic vs audience disagreements
- notable context that is actually supported
- balanced verdict direction
- uncertain/subjective claims to avoid overstating

Do not write the final Burmese social post yet.
"""
        brief = self._generate_text(prompt)
        return ResearchBrief(text=brief, citations=citations[:20])

    def write_review(
        self,
        meta: MovieMeta,
        research: ResearchBrief,
        platform: str,
        style: str,
        spoilers: bool,
    ) -> ReviewPackage:
        source_lines = "\n".join(f"- {c.title}: {c.url}" for c in research.citations)
        source_availability_rule = (
            "Use the cited research evidence and distinguish sourced viewpoints."
            if research.citations
            else (
                "No web citations were available. Write a premise-based review/preview using only "
                "the TMDB metadata and conservative research brief. Do not claim critic consensus, "
                "audience reaction, production facts, or specific acting/directing quality."
            )
        )
        prompt = f"""
Create a completely original Burmese movie-review content package.

MOVIE METADATA
Title: {meta.title}
Year: {meta.year}
Genres: {", ".join(meta.genres)}
Overview: {meta.overview}

RESEARCH BRIEF
{research.text}

SOURCE URLS USED IN RESEARCH
{source_lines or '(None — web search unavailable)'}

TARGET
Platform: {platform}
Visual/content style: {style}
Spoilers allowed: {spoilers}

WRITING RULES
- {source_availability_rule}
- Write natural modern Burmese; English film terms may be mixed in only where natural.
- Do not translate any source sentence-by-sentence.
- Do not imitate a specific critic's voice.
- Use multiple viewpoints and your own synthesis.
- Do not claim subjective community opinions as objective facts.
- Do not invent production facts.
- If research is uncertain, omit the uncertain claim.
- No copied quotations.
- Make the opening strong but not misleading clickbait.
- Keep the main review readable for a social-media movie page.
- Make verdict a concise first-person final opinion that reads naturally after the Burmese prefix "ကျနော့်အမြင်ကတော့".
- Set spoiler_note to an empty string; the published post must not contain a spoiler disclaimer paragraph.
- Thumbnail fields in this first pass may be provisional; a dedicated thumbnail-hook pass will optimize them.
- Hashtags should be useful, not spammy.
"""
        review = self.generate_structured(prompt, ReviewPackage, preferred_model=self.writer_model)
        title, kicker, badge = self.generate_thumbnail_hooks(meta, research, review)
        review.thumbnail_title = title
        review.thumbnail_kicker = kicker
        review.thumbnail_badge = badge
        return review
