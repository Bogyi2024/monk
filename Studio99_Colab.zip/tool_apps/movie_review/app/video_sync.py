from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path

from .models import VideoBeat


def apply_exact_beat_durations(beats: list[VideoBeat], durations: list[float]) -> list[VideoBeat]:
    if len(beats) != len(durations):
        raise ValueError("Beat/audio duration count mismatch")
    for beat, duration in zip(beats, durations):
        beat.duration_seconds = max(0.25, float(duration))
    return beats


def fit_beats_to_total_audio(beats: list[VideoBeat], audio_duration: float) -> list[VideoBeat]:
    """For a single external narration file, scale planned beat durations to its real length."""
    if not beats or audio_duration <= 0:
        return beats
    planned = [max(0.25, float(b.duration_seconds)) for b in beats]
    total = sum(planned)
    if total <= 0:
        each = audio_duration / len(beats)
        for b in beats:
            b.duration_seconds = each
        return beats

    ratio = audio_duration / total
    for beat, d in zip(beats, planned):
        beat.duration_seconds = max(0.25, d * ratio)

    # Correct floating point drift on the last beat so the sum is exact.
    drift = audio_duration - sum(float(b.duration_seconds) for b in beats)
    beats[-1].duration_seconds = max(0.25, float(beats[-1].duration_seconds) + drift)
    return beats


def _ffmpeg_path() -> str:
    configured = str(os.getenv("FFMPEG_PATH") or "").strip()
    for candidate in (configured, r"C:\ffmpeg\bin\ffmpeg.exe"):
        if candidate and Path(candidate).is_file():
            return str(Path(candidate).resolve())
    found = shutil.which("ffmpeg")
    if found:
        return found
    raise FileNotFoundError("ffmpeg not found for Movie Review subtitle pause alignment")


def _speech_weight(text: str) -> float:
    # Character weight is a substantially better Burmese speech-length estimate
    # than the storyboard's hand-planned 4/7/8 second slots.
    spoken = re.sub(r"\s+", "", str(text or ""))
    return float(max(1, len(spoken)))


def _detect_paragraph_pauses(audio_path: Path) -> list[tuple[float, float]]:
    proc = subprocess.run(
        [
            _ffmpeg_path(), "-hide_banner", "-i", str(audio_path),
            "-af", "silencedetect=noise=-35dB:d=0.45",
            "-f", "null", "-",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=60,
    )
    text = f"{proc.stdout}\n{proc.stderr}"
    starts = [float(x) for x in re.findall(r"silence_start:\s*([0-9]+(?:\.[0-9]+)?)", text)]
    ends = [float(x) for x in re.findall(r"silence_end:\s*([0-9]+(?:\.[0-9]+)?)", text)]
    return [(start, end) for start, end in zip(starts, ends) if end > start]


def _estimated_boundaries(beats: list[VideoBeat], audio_duration: float) -> list[float]:
    weights = [_speech_weight(beat.narration) for beat in beats]
    total = sum(weights)
    elapsed = 0.0
    boundaries: list[float] = []
    for weight in weights[:-1]:
        elapsed += weight
        boundaries.append(audio_duration * elapsed / total)
    return boundaries


def _choose_pause_boundaries(
    pauses: list[tuple[float, float]],
    estimates: list[float],
    audio_duration: float,
) -> list[float]:
    # Paragraph breaks created by the double-newline narration script are long
    # (~0.7-0.9s in Gemini output). Internal speech pauses are filtered out by
    # the 0.45s threshold. Use silence_end so the new subtitle appears exactly
    # when the next spoken paragraph begins.
    candidates = [
        end for start, end in pauses
        if start > 0.30 and end < max(0.0, audio_duration - 0.30)
    ]
    if len(candidates) == len(estimates):
        return candidates

    chosen: list[float] = []
    remaining = list(candidates)
    for index, estimate in enumerate(estimates):
        lower = chosen[-1] + 0.35 if chosen else 0.35
        slots_left = len(estimates) - index - 1
        upper = audio_duration - 0.35 * (slots_left + 1)
        viable = [x for x in remaining if lower < x < upper and abs(x - estimate) <= 4.0]
        if viable:
            boundary = min(viable, key=lambda x: abs(x - estimate))
            remaining.remove(boundary)
        else:
            boundary = min(max(estimate, lower), upper)
        chosen.append(boundary)
    return chosen


def align_beats_to_audio_pauses(
    beats: list[VideoBeat],
    audio_path: str | Path,
    audio_duration: float,
) -> list[VideoBeat]:
    """Align subtitle beats to paragraph pauses in one continuous TTS file."""
    if not beats or audio_duration <= 0:
        return beats
    estimates = _estimated_boundaries(beats, audio_duration)
    try:
        pauses = _detect_paragraph_pauses(Path(audio_path))
        boundaries = _choose_pause_boundaries(pauses, estimates, audio_duration)
    except Exception as exc:
        print(f"[video] Audio pause detection unavailable ({exc}); using text-weight timing.")
        pauses = []
        boundaries = estimates

    points = [0.0, *boundaries, float(audio_duration)]
    durations = [max(0.25, points[i + 1] - points[i]) for i in range(len(beats))]
    # Preserve an exact total even after the defensive minimum duration.
    durations[-1] += audio_duration - sum(durations)
    apply_exact_beat_durations(beats, durations)
    print(
        f"[video] Continuous-voice subtitle alignment: beats={len(beats)} | "
        f"paragraph_pauses={len(pauses)} | boundaries={len(boundaries)}"
    )
    return beats
