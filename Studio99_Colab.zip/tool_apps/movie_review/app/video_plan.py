from __future__ import annotations

from .models import MovieMeta, ResearchBrief, ReviewPackage, VideoBeat, VideoPlan


def create_video_plan(
    llm,
    meta: MovieMeta,
    research: ResearchBrief,
    review: ReviewPackage,
    target_seconds: int = 60,
) -> VideoPlan:
    prompt = f"""
Create a short-form Burmese movie review VIDEO STORYBOARD.

Movie: {meta.title} ({meta.year})
Genres: {", ".join(meta.genres)}
Main written review:
{review.review_body}

Verdict:
{review.verdict}

Research summary:
{research.text}

Target duration: about {target_seconds} seconds.

Rules:
- This is criticism/commentary, not a trailer re-upload.
- Write completely original Burmese narration.
- Do not quote or translate source reviews.
- Keep narration tight and spoken-language natural.
- Avoid major spoilers unless the written review already clearly contains them.
- Each segment must have a practical visual_hint such as:
  "lead actor close-up", "city establishing shot", "dark action moment", "poster/backdrop".
- visual_hint should describe shot type/mood, not claim an exact shot exists.
- on_screen_text must be very short.
- Build a hook, 6-10 body segments, and a closing verdict.
"""
    return llm.generate_structured(prompt, VideoPlan)


def build_video_beats(plan: VideoPlan) -> list[VideoBeat]:
    beats: list[VideoBeat] = []
    if plan.opening_hook and plan.opening_hook.strip():
        beats.append(
            VideoBeat(
                beat_id="beat_00_hook",
                kind="hook",
                narration=plan.opening_hook.strip(),
                visual_hint="opening hook, strongest mood image, title-card-friendly shot",
                on_screen_text="",
                duration_seconds=3.5,
            )
        )

    for i, seg in enumerate(plan.segments, start=1):
        beats.append(
            VideoBeat(
                beat_id=f"beat_{i:02d}",
                kind="body",
                narration=seg.narration.strip(),
                visual_hint=seg.visual_hint.strip(),
                on_screen_text=(seg.on_screen_text or "").strip(),
                duration_seconds=float(seg.duration_seconds),
            )
        )

    if plan.closing_line and plan.closing_line.strip():
        beats.append(
            VideoBeat(
                beat_id=f"beat_{len(beats):02d}_closing",
                kind="closing",
                narration=plan.closing_line.strip(),
                visual_hint="final verdict, poster shot, ending-card-friendly visual",
                on_screen_text="",
                duration_seconds=4.0,
            )
        )
    return beats


def build_voiceover_text(plan: VideoPlan) -> str:
    parts = [plan.opening_hook]
    parts.extend(seg.narration for seg in plan.segments)
    parts.append(plan.closing_line)
    return "\n\n".join(x.strip() for x in parts if x and x.strip()) + "\n"
