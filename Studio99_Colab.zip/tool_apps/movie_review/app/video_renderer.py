from __future__ import annotations

import shutil
import subprocess
import time
from functools import lru_cache
from pathlib import Path

import httpx

from .models import MovieMeta, SceneCatalog, SceneMatchBundle, VideoBeat


VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".webm", ".m4v"}


def _need_bin(name: str) -> str:
    path = shutil.which(name)
    if not path:
        raise RuntimeError(
            f"{name} was not found in PATH. Install FFmpeg and make sure ffmpeg/ffprobe are available."
        )
    return path


def _run(cmd: list[str], *, timeout: int = 180) -> None:
    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"FFmpeg timed out after {timeout}s. Last command stage did not finish."
        ) from exc
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr[-5000:])


def _probe_duration(path: Path) -> float:
    ffprobe = _need_bin("ffprobe")
    proc = subprocess.run(
        [
            ffprobe, "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            str(path),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=30,
    )
    try:
        return max(0.0, float(proc.stdout.strip()))
    except Exception:
        return 0.0


def _probe_dimensions(path: Path) -> tuple[int, int]:
    ffprobe = _need_bin("ffprobe")
    proc = subprocess.run(
        [
            ffprobe, "-v", "error",
            "-select_streams", "v:0",
            "-show_entries", "stream=width,height",
            "-of", "csv=s=x:p=0",
            str(path),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=30,
    )
    raw = proc.stdout.strip().lower()
    try:
        w, h = raw.split("x", 1)
        return int(w), int(h)
    except Exception:
        return 0, 0


def _download(url: str, dest: Path) -> Path:
    r = httpx.get(url, timeout=60, follow_redirects=True)
    r.raise_for_status()
    dest.write_bytes(r.content)
    return dest


def _collect_authorized_media(media_dir: Path | None) -> list[Path]:
    if not media_dir or not media_dir.exists():
        return []
    return sorted(
        p for p in media_dir.rglob("*")
        if p.is_file() and p.suffix.lower() in VIDEO_EXTS
    )


def _crop_scale_filter(src: Path, width: int, height: int, fps: int) -> str:
    """Crop first, then scale. This avoids a huge 3414x1920 intermediate for 16:9 -> 9:16."""
    sw, sh = _probe_dimensions(src)
    if sw <= 0 or sh <= 0:
        return (
            f"scale={width}:{height}:force_original_aspect_ratio=increase,"
            f"crop={width}:{height},fps={fps},format=yuv420p"
        )

    target_ar = width / height
    src_ar = sw / sh

    if src_ar > target_ar:
        crop_h = sh
        crop_w = max(2, int(round(sh * target_ar)))
        crop_w -= crop_w % 2
        x = max(0, (sw - crop_w) // 2)
        y = 0
    else:
        crop_w = sw
        crop_h = max(2, int(round(sw / target_ar)))
        crop_h -= crop_h % 2
        x = 0
        y = max(0, (sh - crop_h) // 2)

    return (
        f"crop={crop_w}:{crop_h}:{x}:{y},"
        f"scale={width}:{height}:flags=bilinear,"
        f"fps={fps},format=yuv420p"
    )


def _encoder_args(name: str) -> list[str]:
    if name == "h264_amf":
        return ["-c:v", "h264_amf", "-quality", "speed", "-b:v", "6M", "-maxrate", "8M", "-bufsize", "12M"]
    if name == "h264_nvenc":
        return ["-c:v", "h264_nvenc", "-preset", "p4", "-rc", "vbr", "-cq", "24", "-b:v", "5M", "-maxrate", "8M"]
    if name == "h264_qsv":
        return ["-c:v", "h264_qsv", "-preset", "veryfast", "-global_quality", "24"]
    return ["-c:v", "libx264", "-preset", "ultrafast", "-crf", "24"]


def _encoder_works(name: str) -> bool:
    ffmpeg = _need_bin("ffmpeg")
    cmd = [
        ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
        "-f", "lavfi", "-i", "color=c=black:s=128x128:r=30",
        "-t", "0.2", *_encoder_args(name),
        "-f", "null", "-",
    ]
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
        return proc.returncode == 0
    except Exception:
        return False


@lru_cache(maxsize=1)
def _select_encoder() -> str:
    # Prefer hardware encoders when the local FFmpeg + driver can actually open them.
    for name in ("h264_amf", "h264_nvenc", "h264_qsv"):
        if _encoder_works(name):
            return name
    return "libx264"


def _encode_video_window(
    src: Path,
    dest: Path,
    start: float,
    duration: float,
    width: int,
    height: int,
    fps: int,
    overlay_png: Path | None = None,
) -> None:
    ffmpeg = _need_bin("ffmpeg")
    total = _probe_duration(src)
    start = max(0.0, min(float(start), max(0.0, total - duration)))
    base_filter = _crop_scale_filter(src, width, height, fps)
    encoder = _select_encoder()

    cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{start:.3f}", "-i", str(src)]

    if overlay_png and overlay_png.exists():
        cmd += ["-loop", "1", "-framerate", str(fps), "-i", str(overlay_png)]
        cmd += [
            "-filter_complex",
            f"[0:v]{base_filter}[base];[base][1:v]overlay=0:0:format=auto,format=yuv420p[outv]",
            "-map", "[outv]",
        ]
    else:
        cmd += ["-vf", base_filter]

    cmd += [
        "-t", f"{duration:.3f}",
        "-an",
        *_encoder_args(encoder),
        "-pix_fmt", "yuv420p",
        "-movflags", "+faststart",
        str(dest),
    ]
    _run(cmd, timeout=max(120, int(duration * 20)))



def _encode_video_scene(
    src: Path,
    dest: Path,
    scene_start: float,
    scene_end: float,
    target_duration: float,
    width: int,
    height: int,
    fps: int,
    overlay_png: Path | None = None,
    min_playback_speed: float = 0.72,
    max_playback_speed: float = 1.35,
) -> float:
    """Render a matched scene to the narration duration by gently slowing/speeding the visual."""
    ffmpeg = _need_bin("ffmpeg")
    total = _probe_duration(src)
    scene_start = max(0.0, float(scene_start))
    scene_end = min(total, max(scene_start + 0.1, float(scene_end)))
    midpoint = (scene_start + scene_end) / 2.0
    scene_len = max(0.1, scene_end - scene_start)

    # Keep playback changes natural by expanding/trimming around the matched scene.
    wanted_source_len = min(max(scene_len, target_duration * min_playback_speed), target_duration * max_playback_speed)
    wanted_source_len = min(total, max(0.25, wanted_source_len))
    start = midpoint - wanted_source_len / 2.0
    start = max(0.0, min(start, max(0.0, total - wanted_source_len)))
    source_len = min(wanted_source_len, max(0.1, total - start))

    # playback_speed <1 = slowed down, >1 = sped up.
    playback_speed = source_len / max(0.1, target_duration)
    setpts_factor = target_duration / source_len
    base_filter = _crop_scale_filter(src, width, height, fps)
    encoder = _select_encoder()

    cmd = [
        ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
        "-ss", f"{start:.3f}", "-t", f"{source_len:.3f}", "-i", str(src),
    ]

    retimed_filter = f"setpts={setpts_factor:.8f}*PTS,{base_filter}"
    if overlay_png and overlay_png.exists():
        cmd += ["-loop", "1", "-framerate", str(fps), "-i", str(overlay_png)]
        cmd += [
            "-filter_complex",
            f"[0:v]{retimed_filter}[base];[base][1:v]overlay=0:0:format=auto,format=yuv420p[outv]",
            "-map", "[outv]",
        ]
    else:
        cmd += ["-vf", retimed_filter]

    cmd += [
        "-t", f"{target_duration:.3f}",
        "-an",
        *_encoder_args(encoder),
        "-pix_fmt", "yuv420p",
        "-movflags", "+faststart",
        str(dest),
    ]
    _run(cmd, timeout=max(120, int(target_duration * 20)))
    return playback_speed


def _encode_image(
    src: Path,
    dest: Path,
    duration: float,
    width: int,
    height: int,
    fps: int,
    overlay_png: Path | None = None,
) -> None:
    ffmpeg = _need_bin("ffmpeg")
    base_filter = _crop_scale_filter(src, width, height, fps)
    encoder = _select_encoder()

    cmd = [
        ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
        "-loop", "1", "-framerate", str(fps), "-i", str(src),
    ]

    if overlay_png and overlay_png.exists():
        cmd += ["-loop", "1", "-framerate", str(fps), "-i", str(overlay_png)]
        cmd += [
            "-filter_complex",
            f"[0:v]{base_filter}[base];[base][1:v]overlay=0:0:format=auto,format=yuv420p[outv]",
            "-map", "[outv]",
        ]
    else:
        cmd += ["-vf", base_filter]

    cmd += [
        "-t", f"{duration:.3f}",
        "-an",
        *_encoder_args(encoder),
        "-pix_fmt", "yuv420p",
        "-movflags", "+faststart",
        str(dest),
    ]
    _run(cmd, timeout=max(120, int(duration * 20)))


def _make_clip_from_video(
    src: Path,
    dest: Path,
    duration: float,
    index: int,
    width: int,
    height: int,
    fps: int,
    overlay_png: Path | None = None,
) -> None:
    total = _probe_duration(src)
    if total <= duration + 0.5:
        start = 0.0
    else:
        slots = max(1, int(total // max(duration, 1)))
        start = min(total - duration, (index % slots) * duration)
    _encode_video_window(src, dest, start, duration, width, height, fps, overlay_png)


def _concat_segments(segment_paths: list[Path], dest: Path):
    ffmpeg = _need_bin("ffmpeg")
    list_file = dest.parent / "concat.txt"
    list_file.write_text(
        "\n".join(f"file '{p.as_posix()}'" for p in segment_paths) + "\n",
        encoding="utf-8",
    )
    _run([
        ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
        "-f", "concat", "-safe", "0", "-i", str(list_file),
        "-c", "copy", str(dest),
    ], timeout=120)



def _retime_video_to_duration(src: Path, dest: Path, target_duration: float, fps: int) -> Path:
    """Final safety correction so video track length exactly follows narration length."""
    current = _probe_duration(src)
    if current <= 0 or target_duration <= 0:
        return src
    drift = target_duration - current
    if abs(drift) <= 0.12:
        return src

    ffmpeg = _need_bin("ffmpeg")
    encoder = _select_encoder()
    factor = target_duration / current
    speed = current / target_duration
    print(
        f"[video] Final A/V sync: visual {current:.2f}s -> narration {target_duration:.2f}s "
        f"(visual speed {speed:.3f}x)"
    )
    _run([
        ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
        "-i", str(src),
        "-vf", f"setpts={factor:.10f}*PTS,fps={fps},format=yuv420p",
        "-an", *_encoder_args(encoder), "-pix_fmt", "yuv420p",
        "-t", f"{target_duration:.3f}", "-movflags", "+faststart", str(dest),
    ], timeout=max(180, int(target_duration * 8)))
    return dest


def _mux_voice(video: Path, voice: Path, dest: Path):
    ffmpeg = _need_bin("ffmpeg")
    _run([
        ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
        "-i", str(video), "-i", str(voice),
        "-map", "0:v:0", "-map", "1:a:0",
        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
        "-shortest", "-movflags", "+faststart", str(dest),
    ], timeout=120)


def render_review_video(
    meta: MovieMeta,
    beats: list[VideoBeat],
    work_dir: Path,
    media_dir: Path | None,
    voice_path: Path | None,
    source_file: Path | None = None,
    width: int = 1080,
    height: int = 1920,
    fps: int = 30,
    scene_catalog: SceneCatalog | None = None,
    scene_matches: SceneMatchBundle | None = None,
    min_confidence: float = 0.45,
    caption_overlays: list[Path] | None = None,
    recorded_narration: bool = False,
) -> Path:
    render_dir = work_dir / "video_render"
    render_dir.mkdir(parents=True, exist_ok=True)

    fallback_videos: list[Path] = []
    if source_file and source_file.exists():
        fallback_videos.append(source_file)
    fallback_videos.extend(p for p in _collect_authorized_media(media_dir) if p not in fallback_videos)

    still_urls = list(meta.backdrop_urls[:5]) + list(meta.poster_urls[:4])
    still_files: list[Path] = []
    for i, url in enumerate(still_urls):
        try:
            p = render_dir / f"still_{i:02d}.jpg"
            if not p.exists():
                _download(url, p)
            still_files.append(p)
        except Exception:
            pass

    if not fallback_videos and not still_files:
        raise RuntimeError("No video or still fallback sources available.")

    scene_map = {s.scene_id: s for s in (scene_catalog.scenes if scene_catalog else [])}
    match_map = {m.beat_id: m for m in (scene_matches.matches if scene_matches else [])}
    encoder = _select_encoder()
    print(f"[video] FFmpeg encoder: {encoder}")
    if caption_overlays:
        existing_overlays = sum(1 for p in caption_overlays if p.exists())
        print(f"[video] Chromium subtitles: {existing_overlays}/{len(beats)} overlays ready")
        if existing_overlays < len(beats):
            raise RuntimeError("Some Chromium subtitle overlays are missing; stopping instead of exporting a subtitle-less Reel.")
    else:
        raise RuntimeError("No Chromium subtitle overlays were supplied; stopping instead of exporting a subtitle-less Reel.")

    segment_paths: list[Path] = []
    total_beats = len(beats)
    recorded_cursor, recorded_frames = 0.0, 0

    for i, beat in enumerate(beats):
        t0 = time.perf_counter()
        duration = max(1.5, float(beat.duration_seconds))
        if recorded_narration:
            # Match each recording, including short hooks. Allocate frames from
            # cumulative audio time so rounding cannot accumulate across parts.
            recorded_cursor += float(beat.duration_seconds)
            end_frame = max(recorded_frames + 1, round(recorded_cursor * fps))
            duration = (end_frame - recorded_frames) / fps
            recorded_frames = end_frame
        out = render_dir / f"seg_{i:02d}.mp4"
        overlay = caption_overlays[i] if caption_overlays and i < len(caption_overlays) else None
        chosen = False
        source_label = ""

        if source_file and source_file.exists() and beat.beat_id in match_map:
            match = match_map[beat.beat_id]
            sc = scene_map.get(match.scene_id)
            if sc and not match.use_still_fallback and float(match.confidence) >= min_confidence:
                start = max(0.0, sc.midpoint_seconds - duration / 2.0)
                try:
                    source_label = f"{sc.scene_id} score={float(match.confidence):.2f}"
                    print(f"[video] Segment {i+1}/{total_beats}: {duration:.1f}s <- {source_label}")
                    speed = _encode_video_scene(
                        source_file, out, sc.start_seconds, sc.end_seconds, duration,
                        width, height, fps, overlay,
                    )
                    print(f"[video] Segment {i+1}: visual playback {speed:.2f}x")
                    chosen = True
                except Exception as exc:
                    print(f"[video] Segment {i+1}: matched scene failed ({exc}); using fallback.")
                    chosen = False

        # If semantic scene matching is unavailable or low-confidence, keep the
        # Reel moving by taking a real window from the downloaded trailer.  The
        # old order preferred poster JPGs here, which produced an all-slideshow
        # Reel even though a valid trailer MP4 had already been downloaded.
        if not chosen and fallback_videos:
            try:
                src = fallback_videos[i % len(fallback_videos)]
                source_label = f"video fallback {src.name}"
                print(f"[video] Segment {i+1}/{total_beats}: {duration:.1f}s <- {source_label}")
                _make_clip_from_video(src, out, duration, i, width, height, fps, overlay)
                chosen = True
            except Exception as exc:
                print(f"[video] Segment {i+1}: video fallback failed ({exc}); trying still fallback.")
                chosen = False

        if not chosen and still_files:
            try:
                src = still_files[i % len(still_files)]
                source_label = f"still {src.name}"
                print(f"[video] Segment {i+1}/{total_beats}: {duration:.1f}s <- {source_label}")
                _encode_image(src, out, duration, width, height, fps, overlay)
                chosen = True
            except Exception as exc:
                print(f"[video] Segment {i+1}: still fallback failed ({exc}).")
                chosen = False

        if not chosen:
            raise RuntimeError(f"Could not render segment {i}.")

        elapsed = time.perf_counter() - t0
        print(f"[video] Segment {i+1}/{total_beats} done in {elapsed:.1f}s")
        segment_paths.append(out)

    print("[video] Joining rendered segments...")
    silent = work_dir / "video_silent.mp4"
    _concat_segments(segment_paths, silent)

    if voice_path and voice_path.exists():
        voice_duration = _probe_duration(voice_path)
        synced_silent = work_dir / "video_silent_synced.mp4"
        visual_for_mux = _retime_video_to_duration(silent, synced_silent, voice_duration, fps)
        print(
            f"[video] Duration check: video={_probe_duration(visual_for_mux):.2f}s, "
            f"narration={voice_duration:.2f}s"
        )
        print("[video] Muxing Burmese narration...")
        final = work_dir / "video_final.mp4"
        _mux_voice(visual_for_mux, voice_path, final)
        return final

    return silent


def run_tts_command(command_template: str, text_path: Path, output_path: Path) -> Path:
    command = command_template.format(text=str(text_path), output=str(output_path))
    proc = subprocess.run(command, shell=True)
    if proc.returncode != 0 or not output_path.exists():
        raise RuntimeError("TTS_COMMAND failed to produce audio.")
    return output_path
