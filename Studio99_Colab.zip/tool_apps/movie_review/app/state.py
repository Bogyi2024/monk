from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .models import MovieMeta


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class MovieRegistry:
    """Durable TMDB-ID registry used by standalone generation and TT uploads."""

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"version": 1, "movies": {}}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8-sig"))
        except (OSError, json.JSONDecodeError):
            return {"version": 1, "movies": {}}
        if not isinstance(data, dict):
            return {"version": 1, "movies": {}}
        data.setdefault("version", 1)
        data.setdefault("movies", {})
        return data

    def _save(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, self.path)

    @staticmethod
    def content_id(tmdb_id: int) -> str:
        return f"movie_review:tmdb:{int(tmdb_id)}"

    def get(self, tmdb_id: int) -> dict[str, Any] | None:
        return self._load()["movies"].get(str(int(tmdb_id)))

    def import_existing_outputs(self, output_dir: Path) -> int:
        """Seed legacy title/year manifests so old rendered films are not selected again."""
        data = self._load()
        added = 0
        for manifest_path in output_dir.glob("*/manifest.json"):
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
            except (OSError, json.JSONDecodeError):
                continue
            title = str(manifest.get("title") or "").strip()
            if not title:
                continue
            year = manifest.get("year")
            tmdb_id = int(manifest.get("tmdb_id") or 0)
            key = str(tmdb_id) if tmdb_id else f"legacy:{' '.join(title.lower().split())}:{year or ''}"
            if key in data["movies"]:
                continue
            data["movies"][key] = {
                "content_id": f"movie_review:tmdb:{tmdb_id}" if tmdb_id else key,
                "tmdb_id": tmdb_id or None,
                "title": title,
                "year": year,
                "status": "generated",
                "generated_at": datetime.fromtimestamp(manifest_path.stat().st_mtime, timezone.utc).isoformat(),
                "manifest": str(manifest_path.resolve()),
                "destinations": {},
                "imported_legacy": not bool(tmdb_id),
            }
            added += 1
        if added:
            self._save(data)
        return added

    def is_processed(self, tmdb_id: int, title: str = "", year: int | None = None) -> bool:
        data = self._load()
        row = data["movies"].get(str(int(tmdb_id)))
        if row and row.get("status") in {"claimed", "generated", "posted"}:
            return True
        normalized = " ".join(title.lower().split())
        for existing in data["movies"].values():
            if existing.get("status") not in {"claimed", "generated", "posted"}:
                continue
            if normalized and " ".join(str(existing.get("title") or "").lower().split()) == normalized:
                if not year or not existing.get("year") or int(existing["year"]) == int(year):
                    return True
        return False

    def claim(self, meta: MovieMeta) -> None:
        data = self._load()
        key = str(meta.tmdb_id)
        previous = data["movies"].get(key) or {}
        data["movies"][key] = {
            **previous,
            "content_id": self.content_id(meta.tmdb_id),
            "tmdb_id": meta.tmdb_id,
            "title": meta.title,
            "year": meta.year,
            "status": "claimed",
            "claimed_at": _now(),
            "last_error": "",
            "destinations": previous.get("destinations") or {},
        }
        self._save(data)

    def mark_generated(self, meta: MovieMeta, manifest_path: Path) -> None:
        data = self._load()
        key = str(meta.tmdb_id)
        row = data["movies"].setdefault(key, {})
        row.update({
            "content_id": self.content_id(meta.tmdb_id),
            "tmdb_id": meta.tmdb_id,
            "title": meta.title,
            "year": meta.year,
            "status": "generated",
            "generated_at": _now(),
            "manifest": str(manifest_path.resolve()),
            "last_error": "",
        })
        row.setdefault("destinations", {})
        self._save(data)

    def mark_failed(self, meta: MovieMeta, error: str) -> None:
        data = self._load()
        key = str(meta.tmdb_id)
        row = data["movies"].setdefault(key, {})
        row.update({
            "content_id": self.content_id(meta.tmdb_id),
            "tmdb_id": meta.tmdb_id,
            "title": meta.title,
            "year": meta.year,
            "status": "failed",
            "failed_at": _now(),
            "last_error": str(error)[-2000:],
        })
        self._save(data)

    def invalidate(self, tmdb_id: int, reason: str) -> bool:
        """Prevent an old artifact from posting while allowing a clean regeneration."""
        data = self._load()
        row = data["movies"].get(str(int(tmdb_id)))
        if not isinstance(row, dict):
            return False
        row["status"] = "invalidated"
        row["invalidated_at"] = _now()
        row["invalidation_reason"] = str(reason)
        self._save(data)
        return True

    def mark_destination(self, tmdb_id: int, destination: str, receipt: dict[str, Any]) -> None:
        data = self._load()
        row = data["movies"].setdefault(str(int(tmdb_id)), {"tmdb_id": int(tmdb_id)})
        destinations = row.setdefault("destinations", {})
        destinations[destination] = {"completed_at": _now(), **receipt}
        required = {"facebook_post", "facebook_reel", "tiktok_reel"}
        if required.issubset(destinations):
            row["status"] = "posted"
            row["posted_at"] = _now()
        self._save(data)
