from __future__ import annotations

import json
import math
import os
from pathlib import Path
import shutil
import wave

SR = 24000


class Media:
    def __init__(self, control):
        self.control = control
        self.ffmpeg = os.getenv("FFMPEG_PATH") or shutil.which("ffmpeg")
        self.ffprobe = os.getenv("FFPROBE_PATH") or shutil.which("ffprobe")
        if not self.ffmpeg or not self.ffprobe:
            raise RuntimeError("FFmpeg/ffprobe ကို PATH မှာထည့်ပါ။")

    def ff(self, args):
        return self.control.run([self.ffmpeg, "-hide_banner", "-nostdin", "-y", *args])

    def probe(self, path):
        out, _ = self.control.run([self.ffprobe, "-v", "error", "-show_format",
                                   "-show_streams", "-of", "json", path], timeout=120)
        return json.loads(out)

    def duration(self, path):
        raw = (self.probe(path).get("format") or {}).get("duration")
        if raw in (None, "", "N/A"):
            raise ValueError(f"Media has no duration (empty/0-stream file): {Path(path).name}")
        n = float(raw)
        if not math.isfinite(n) or n <= 0:
            raise ValueError("Invalid media duration")
        return n

    def wav(self, source, output):
        tmp = Path(output).with_suffix(".part.wav")
        self.ff(["-v", "error", "-i", source, "-vn", "-ac", "1", "-ar", str(SR),
                 "-c:a", "pcm_s16le", tmp])
        wav_duration(tmp)
        os.replace(tmp, output)


def wav_duration(path):
    with wave.open(str(path), "rb") as f:
        if f.getnchannels() != 1 or f.getsampwidth() != 2 or f.getframerate() != SR or not f.getnframes():
            raise ValueError("Expected nonempty mono 24kHz PCM16 WAV")
        return f.getnframes() / SR


def write_wav(path, samples):
    import numpy as np
    with wave.open(str(path), "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(SR)
        f.writeframes(np.asarray(samples, dtype="<i2").tobytes())


def trim_boundary_silence(source, output, guard_ms=25):
    """Remove provider padding at the two edges without touching pauses in speech."""
    import numpy as np

    with wave.open(str(source), "rb") as f:
        if f.getnchannels() != 1 or f.getsampwidth() != 2 or f.getframerate() != SR:
            raise ValueError("Expected mono 24kHz PCM16 WAV")
        samples = np.frombuffer(f.readframes(f.getnframes()), dtype="<i2").copy()
    if not len(samples):
        raise ValueError("Empty TTS audio")

    absolute = np.abs(samples.astype(np.int32))
    peak = int(absolute.max())
    # A low, signal-relative gate avoids clipping quiet syllable onsets. The
    # guard retains a short natural breath at joins while long provider padding
    # is removed. Silence inside the utterance is never inspected or changed.
    threshold = max(12, min(240, round(peak * .012)))
    active = np.flatnonzero(absolute >= threshold)
    if not len(active):
        raise ValueError("TTS audio contains no audible signal")
    guard = round(SR * guard_ms / 1000)
    first = max(0, int(active[0]) - guard)
    last = min(len(samples), int(active[-1]) + guard + 1)
    trimmed = samples[first:last]
    write_wav(output, trimmed)
    return {"leading_removed_seconds": first / SR,
            "trailing_removed_seconds": (len(samples) - last) / SR,
            "guard_ms": guard_ms}
