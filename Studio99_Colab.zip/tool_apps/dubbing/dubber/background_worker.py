"""Absolute child entry point: frozen runtimes do not inherit Python's PYTHONPATH behavior."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dubber.background import main

if __name__ == "__main__":
    raise SystemExit(main())
