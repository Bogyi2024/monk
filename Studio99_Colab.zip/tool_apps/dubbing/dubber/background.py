"""Keep the original music and sound effects under the dub (approved 2026-10-07).

The source audio is split into voices / everything else with torchaudio's Hybrid Demucs
(HDEMUCS_HIGH_MUSDB_PLUS: drums, bass, other, vocals; on the GPU when there is one) and the
"everything else" (drums + bass + other) is kept as <job>/background_44k.wav.

render.render_motion_safe then lays it under the dub part by part, cut at the same source times
as the picture: gaps keep 1.0x like the picture; speech parts are stretched/squeezed (pitch kept)
to the rendered part length, the same factor the picture got, so effects stay on their frames.
Part lengths are counted cumulatively like the frame lock, so nothing drifts by the end.
If requested separation fails, the job stops resumably rather than exporting a soundtrack without it.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import wave
from dataclasses import is_dataclass, replace
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from .runtime import Cancelled

SR = 44100
MODEL = "HDEMUCS_HIGH_MUSDB_PLUS"
_VERSION = 1
CHUNK_SECONDS = 10.0   # new audio per model call
OVERLAP_SECONDS = 1.0  # cross-faded with the next chunk
EDGE_FADE_SECONDS = 0.003


class BackgroundUnavailable(RuntimeError):
    pass


class _GPUStartupTimeout(RuntimeError):
    pass


def _signature(source: Path) -> dict:
    stat = Path(source).stat()
    return {"v": _VERSION, "model": MODEL, "source": [str(Path(source).resolve()), stat.st_size, stat.st_mtime_ns]}


def _is_ready(out: Path, meta: Path, signature: dict) -> bool:
    try:
        if not out.is_file() or json.loads(meta.read_text(encoding="utf-8")).get("signature") != signature:
            return False
        with wave.open(str(out), "rb") as audio:
            if audio.getframerate() != SR or audio.getnchannels() != 2 or audio.getsampwidth() != 2 or audio.getnframes() < 1:
                return False
            audio.setpos(audio.getnframes() - 1)
            return len(audio.readframes(1)) == 4
    except (OSError, ValueError, EOFError, wave.Error):
        return False


def separate_background(media, source, folder, control, device="auto") -> Path:
    """<job>/background_44k.wav, cached; a requested soundtrack is never silently omitted.

    The model runs in its own Python process: the UI process has already loaded faster-whisper,
    whose ctranslate2 ships an older cudnn64_9.dll; torch then binds to it, misses
    cudnnGetLibConfig and the whole UI dies (2026-10-07). A separate process loads only
    torch's cuDNN. A failure remains resumable after the model/runtime is available.
    """
    folder = Path(folder)
    out, meta = folder / "background_44k.wav", folder / "background.json"
    log = getattr(control, "log", print)
    try:
        signature = _signature(Path(source))
        if _is_ready(out, meta, signature):
            log("Background sounds: reusing the separated music/effects track")
            return out
        log("Background sounds: removing the original voices in a separate process "
            "(the first use downloads the model once)")
        env = dict(os.environ)
        root = str(Path(__file__).resolve().parent.parent)
        env["PYTHONPATH"] = root + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
        env["PYTHONUTF8"] = "1"
        worker = Path(__file__).with_name("background_worker.py")
        progress_file = folder / "background_progress.json"
        state = {"signature": None, "since": 0.0}

        def watch(elapsed):
            try:
                status = json.loads(progress_file.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                return
            signature = (status.get("stage"), status.get("device"), status.get("completed_seconds"))
            if signature != state["signature"]:
                state.update(signature=signature, since=elapsed)
                stage = status.get("stage", "working")
                done, total = status.get("completed_seconds"), status.get("total_seconds")
                detail = f" {done:.1f}/{total:.1f}s" if done is not None and total else ""
                log(f"Background sounds: {stage} ({status.get('device', '')}){detail}")
            if (status.get("stage") == "placing_model" and status.get("device") == "cuda"
                    and elapsed - state["since"] >= 45):
                raise _GPUStartupTimeout("GPU model initialization did not finish within 45 seconds")

        def run_worker(requested):
            progress_file.unlink(missing_ok=True)
            state.update(signature=None, since=0.0)
            return control.run([sys.executable, "-X", "utf8", str(worker), str(source), str(folder),
                                str(getattr(media, "ffmpeg", "ffmpeg")), requested],
                               timeout=6 * 3600, env=env, on_tick=watch)

        try:
            output, _ = run_worker(device if device in {"cpu", "cuda"} else "auto")
        except _GPUStartupTimeout:
            # Control.run terminates its own stalled child before this fresh CPU process starts.
            log("Background sounds: GPU initialization stalled; retrying on CPU (slower).")
            output, _ = run_worker("cpu")
        for line in output.splitlines():
            if line.startswith("BG:"):
                log("Background sounds: " + line[3:].strip())
        if not _is_ready(out, meta, signature):
            raise RuntimeError("the separation finished without a track")
        return out
    except Cancelled:
        raise
    except Exception as exc:
        detail = ' '.join(str(exc).split())[-400:]
        raise BackgroundUnavailable(
            "နောက်ခံ music/effects ခွဲထုတ်မရပါ။ ပြီးထားတဲ့ translation / အသံတွေ သိမ်းထားပါတယ်။\n"
            "Studio99 ရဲ့ AI download ပြီးအောင်စောင့်ပြီး၊ model ဒေါင်းဖို့ Internet ရှိချိန် START / RESUME ပြန်နှိပ်ပါ။ "
            "နောက်ခံအသံ မလိုရင် Keep background sounds ကို ပိတ်ပြီး ဆက်လုပ်နိုင်ပါတယ်။\n"
            f"Background separation error: {detail}"
        ) from exc


def _separate_here(source: Path, folder: Path, ffmpeg: str, log=print, device="auto") -> Path:
    """Child process: the separation itself (only torch's cuDNN is loaded here)."""
    import warnings

    warnings.filterwarnings("ignore", category=FutureWarning)
    import soundfile as sf
    import torch
    import torchaudio

    folder = Path(folder)
    out, meta = folder / "background_44k.wav", folder / "background.json"
    mixture = folder / "background_source_44k.wav"
    signature = _signature(Path(source))
    try:
        tmp = mixture.with_name(mixture.stem + ".part.wav")
        subprocess.run([ffmpeg, "-hide_banner", "-nostdin", "-y", "-v", "error", "-i", str(source), "-vn",
                        "-ac", "2", "-ar", str(SR), "-c:a", "pcm_s16le", str(tmp)], check=True)
        tmp.replace(mixture)

        # The model expects the mixture normalized by the whole track's mono mean/std.
        total = total_sq = 0.0
        count = 0
        with sf.SoundFile(str(mixture)) as reader:
            if reader.frames < SR // 2:
                raise ValueError("source audio is shorter than half a second")
            for block in reader.blocks(blocksize=SR * 30, dtype="float32", always_2d=True):
                mono = block.mean(axis=1, dtype=np.float64)
                total += float(mono.sum())
                total_sq += float((mono ** 2).sum())
                count += mono.size
        mean = total / max(1, count)
        std = max(1e-5, (total_sq / max(1, count) - mean * mean) ** 0.5)

        devices = ["cuda", "cpu"] if device != "cpu" and torch.cuda.is_available() else ["cpu"]
        for device in devices:
            try:
                names = _run_model(torchaudio, torch, sf, device, mixture, out, mean, std)
                break
            except RuntimeError as exc:  # torch.cuda.OutOfMemoryError is a RuntimeError
                if device == "cuda" and "out of memory" in str(exc).lower():
                    log("GPU memory is full; separating on the CPU instead (slower)")
                    torch.cuda.empty_cache()
                    continue
                raise
        meta.write_text(json.dumps({"signature": signature, "sources": names, "device": device}), encoding="utf-8")
        log(f"music/effects track ready on {device} (original voices removed)")
        return out
    finally:
        mixture.unlink(missing_ok=True)


def _run_model(torchaudio, torch, sf, device, mixture: Path, out: Path, mean: float, std: float) -> list[str]:
    from .runtime import atomic_json
    status_file = out.parent / "background_progress.json"
    atomic_json(status_file, {"stage": "loading_model", "device": device})
    model = getattr(torchaudio.pipelines, MODEL).get_model().eval()
    atomic_json(status_file, {"stage": "placing_model", "device": device})
    model = model.to(device)
    names = list(getattr(model, "sources", ["drums", "bass", "other", "vocals"]))
    keep = [i for i, name in enumerate(names) if name != "vocals"]
    hop, overlap = int(SR * CHUNK_SECONDS), int(SR * OVERLAP_SECONDS)
    part = out.with_name(out.stem + ".part.wav")
    with sf.SoundFile(str(mixture)) as reader, \
            sf.SoundFile(str(part), "w", samplerate=SR, channels=2, subtype="PCM_16") as writer:
        frames = reader.frames
        position, tail = 0, None
        while position < frames:
            atomic_json(status_file, {"stage": "separating", "device": device,
                                      "completed_seconds": position / SR, "total_seconds": frames / SR})
            reader.seek(position)
            chunk = reader.read(hop + overlap, dtype="float32", always_2d=True)
            wave = torch.from_numpy(((chunk.T - mean) / std).copy()).unsqueeze(0).to(device)
            with torch.inference_mode():
                stems = model(wave)[0]  # (sources, channels, time)
            background = (stems[keep].sum(0) * std + mean * len(keep)).cpu().numpy()  # (2, time)
            if tail is not None:
                k = min(overlap, background.shape[1], tail.shape[1])
                ramp = np.linspace(0.0, 1.0, k, dtype=np.float32)
                background[:, :k] = background[:, :k] * ramp + tail[:, :k] * (1.0 - ramp)
            if frames - position <= hop + overlap:  # the rest fits: last chunk
                writer.write(np.clip(background.T, -1.0, 1.0))
                break
            writer.write(np.clip(background[:, :hop].T, -1.0, 1.0))
            tail = background[:, hop:hop + overlap]
            position += hop
    part.replace(out)
    atomic_json(status_file, {"stage": "ready", "device": device,
                              "completed_seconds": frames / SR, "total_seconds": frames / SR})
    return names


def _fit(piece: np.ndarray, target: int, stretch: bool) -> np.ndarray:
    """(target, channels): a gap is padded/trimmed (1.0x); a speech part is time-stretched, pitch kept."""
    channels = piece.shape[1] if piece.ndim == 2 else 2
    if piece.size == 0 or target <= 0:
        return np.zeros((max(0, target), channels), dtype=np.float32)
    length = piece.shape[0]
    if stretch and abs(length / target - 1.0) > 0.02:
        if length < 4096 or target < 4096:
            # Too short for a phase vocoder: plain resampling of a few milliseconds.
            x = np.linspace(0.0, length - 1.0, target)
            piece = np.stack([np.interp(x, np.arange(length), piece[:, c]) for c in range(channels)], axis=1)
        else:
            import librosa
            piece = librosa.effects.time_stretch(np.ascontiguousarray(piece.T), rate=length / target).T
    piece = piece[:target]
    if piece.shape[0] < target:
        piece = np.concatenate([piece, np.zeros((target - piece.shape[0], channels), dtype=piece.dtype)])
    return piece.astype(np.float32)


def build_track(background: Path, units: list[dict], part_durations: list[float], output: Path,
                control=None) -> Path:
    """The background laid out like the rendered picture: same cuts, gaps 1.0x, speech stretched."""
    import soundfile as sf

    output = Path(output)
    part = output.with_name(output.stem + ".part.wav")
    with sf.SoundFile(str(background)) as reader, \
            sf.SoundFile(str(part), "w", samplerate=reader.samplerate, channels=reader.channels,
                         subtype="PCM_16") as writer:
        rate = reader.samplerate
        fade = max(1, int(rate * EDGE_FADE_SECONDS))
        written, elapsed = 0, 0.0
        for unit, duration in zip(units, part_durations):
            if control is not None:
                control.check()
            elapsed += float(duration)
            target = max(1, int(round(elapsed * rate)) - written)  # cumulative, like the frame lock
            first = min(reader.frames, max(0, int(round(float(unit["source_start"]) * rate))))
            last = min(reader.frames, max(first, int(round(float(unit["source_end"]) * rate))))
            reader.seek(first)
            piece = reader.read(last - first, dtype="float32", always_2d=True)
            piece = _fit(piece, target, stretch=unit.get("type") == "speech")
            k = min(fade, target // 2)
            if k:
                ramp = np.linspace(0.0, 1.0, k, dtype=np.float32)[:, None]
                piece[:k] *= ramp
                piece[-k:] *= ramp[::-1]
            writer.write(np.clip(piece, -1.0, 1.0))
            written += target
    part.replace(output)
    return output


def mix_with_voice(media, narration: Path, track: Path, output: Path, voice_percent: int,
                   background_percent: int) -> Path:
    """Stereo 48 kHz: the dub voice (its own volume) over the background (its own volume), limited."""
    output = Path(output)
    part = output.with_name(output.stem + ".part.wav")
    voice, back = max(0, int(voice_percent)) / 100.0, max(0, int(background_percent)) / 100.0
    media.ff([
        "-v", "error", "-i", str(narration), "-i", str(track), "-filter_complex",
        f"[0:a]aresample=48000,pan=stereo|c0=c0|c1=c0,volume={voice:.3f}[v];"
        f"[1:a]aresample=48000,aformat=channel_layouts=stereo,volume={back:.3f}[b];"
        "[v][b]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95:level=disabled[a]",
        "-map", "[a]", "-c:a", "pcm_s16le", part])
    part.replace(output)
    return output


def with_voice_volume(cfg, percent: int):
    """cfg with another voice volume (the mix already applied it), for dataclass or simple configs."""
    if is_dataclass(cfg):
        return replace(cfg, voice_volume_percent=percent)
    clone = SimpleNamespace(**vars(cfg))
    clone.voice_volume_percent = percent
    return clone


def main(argv=None) -> int:
    """python -m dubber.background SOURCE JOB_FOLDER [FFMPEG]: the child process of separate_background."""
    args = list(sys.argv[1:] if argv is None else argv)
    _separate_here(Path(args[0]), Path(args[1]), args[2] if len(args) > 2 else "ffmpeg",
                   log=lambda message: print("BG:", message, flush=True),
                   device=args[3] if len(args) > 3 else "auto")
    return 0


if __name__ == "__main__":
    sys.exit(main())
