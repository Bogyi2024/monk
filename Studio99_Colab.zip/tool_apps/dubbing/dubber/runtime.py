from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import threading
import time


class Cancelled(InterruptedError):
    pass


class Control:
    def __init__(self, stop_file=None, event=None, log=None):
        self.event = event or threading.Event()
        self.stop_file = Path(stop_file) if stop_file else None
        self.log = log or (lambda message: None)

    def check(self):
        if self.event.is_set() or (self.stop_file and self.stop_file.exists()):
            raise Cancelled("Cancelled; completed checkpoints ကို resume လုပ်နိုင်ပါတယ်။")

    def sleep(self, seconds):
        until = time.monotonic() + seconds
        while time.monotonic() < until:
            self.check()
            self.event.wait(min(.1, max(0, until - time.monotonic())))

    def run(self, argv, timeout=36000, env=None, on_tick=None):
        self.check()
        # Files prevent pipe deadlocks and bound memory for multi-hour FFmpeg logs.
        with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
            p = subprocess.Popen([str(x) for x in argv], stdout=stdout, stderr=stderr,
                                 stdin=subprocess.DEVNULL,
                                 env=env,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            started = time.monotonic()
            try:
                while p.poll() is None:
                    self.sleep(.1)
                    if on_tick is not None:
                        on_tick(time.monotonic() - started)
                    if time.monotonic() - started > timeout:
                        raise TimeoutError(f"{Path(str(argv[0])).name} timed out")
                stdout.seek(0)
                output = stdout.read().decode("utf-8", "replace")
                if p.returncode:
                    stderr.seek(0, 2)
                    size = stderr.tell()
                    stderr.seek(max(0, size - 4000))
                    raise RuntimeError(f"{Path(str(argv[0])).name} failed ({p.returncode}): "
                                       + stderr.read().decode("utf-8", "replace"))
                stderr.seek(0)
                return output, stderr.read().decode("utf-8", "replace")
            finally:
                if p.poll() is None:
                    p.terminate()
                    try:
                        p.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        p.kill()
                        p.wait()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     allow_nan=False).encode("utf-8")).hexdigest()


def file_hash(path, control=None):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        while block := f.read(4 * 1024 * 1024):
            if control:
                control.check()
            h.update(block)
    return h.hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


class Cache:
    def __init__(self, root, control, resume=True):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.control, self.resume = control, resume
        self.hits = self.writes = 0

    def path(self, stage, key, suffix=".json"):
        folder = self.root / stage
        folder.mkdir(exist_ok=True)
        return folder / (digest(key) + suffix)

    def get(self, stage, key):
        if not self.resume:
            return None
        p = self.path(stage, key)
        try:
            value = json.loads(p.read_text(encoding="utf-8"))
            if value["key"] != digest(key):
                return None
            for item in value["files"]:
                f = self.root / item["path"]
                if not f.is_relative_to(self.root) or file_hash(f, self.control) != item["sha256"]:
                    return None
            self.hits += 1
            return value["data"]
        except Cancelled:
            raise
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def put(self, stage, key, data, files=()):
        records = [{"path": str(Path(f).relative_to(self.root)),
                    "sha256": file_hash(f, self.control)} for f in files]
        atomic_json(self.path(stage, key), {"key": digest(key), "data": data, "files": records})
        self.writes += 1
        return data


class JobLock:
    """OS-held lock releases even after a worker crash; never deletes other runs."""
    def __init__(self, folder):
        self.path = Path(folder) / ".lock"

    def __enter__(self):
        self.file = self.path.open("a+b")
        try:
            if self.path.stat().st_size == 0:
                self.file.write(b"0")
                self.file.flush()
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.file.close()
            raise RuntimeError("ဒီ job ကို worker တစ်ခု run နေပြီးပါပြီ။") from None
        return self

    def __exit__(self, *args):
        self.file.close()
