"""The original Dubbing font ships with the app; no system-font install or admin rights are needed."""
from functools import lru_cache
import os
from pathlib import Path

DEFAULT_FONT = "bundled:burma020-thin"
PREVIEW_FONT_FAMILY = "Burma- 020 Thin"
FONT_SHA256 = "1f756f827435c021e139e08ee9053cda856fe394568cacf2bbaabe30fd0ec937"


def bundled_font() -> Path:
    return Path(__file__).resolve().parents[3] / "app/fonts/Burma020-Thin.ttf"


@lru_cache(maxsize=1)
def register_preview_font() -> bool:
    """Register only in this process (FR_PRIVATE); never write Windows font settings."""
    font = bundled_font()
    if os.name != "nt" or not font.is_file():
        return False
    import ctypes
    add = ctypes.windll.gdi32.AddFontResourceExW
    add.argtypes = [ctypes.c_wchar_p, ctypes.c_uint, ctypes.c_void_p]
    add.restype = ctypes.c_int
    return add(str(font), 0x10, None) > 0
