"""Output languages of the dub (UI checkboxes, translation, Edge voices, subtitles, file names).

Burmese ("my") keeps its exact VoxCPM Bundle(7) translation; every other language goes through
the batch translator. Voices, scripts and subtitle widths follow STORYTELLING_RECAP_STUDIO's
app/languages.py so both tools speak the same way. "my" and "en" keep their old defaults
(+35% / 0% Edge rate, Burmese.mp4 / English.mp4).
"""
from __future__ import annotations

LATIN = [(0x0041, 0x005A), (0x0061, 0x007A), (0x00C0, 0x024F), (0x1E00, 0x1EFF)]

LANGUAGES: dict[str, dict] = {
    "my": {"label": "Burmese", "native": "မြန်မာ", "edge": "my-",
           "voices": ["my-MM-ThihaNeural", "my-MM-NilarNeural"],
           "male": "my-MM-ThihaNeural", "female": "my-MM-NilarNeural", "rate": 35,
           "script": [(0x1000, 0x109F), (0xAA60, 0xAA7F), (0xA9E0, 0xA9FF)], "char_w": 0.72, "spaced": True},
    "en": {"label": "English", "native": "English", "edge": "en-",
           "voices": ["en-US-GuyNeural", "en-US-AndrewNeural", "en-US-BrianNeural", "en-US-ChristopherNeural",
                      "en-GB-RyanNeural", "en-US-JennyNeural", "en-US-AvaNeural", "en-US-EmmaNeural",
                      "en-GB-SoniaNeural"],
           "male": "en-US-GuyNeural", "female": "en-US-JennyNeural", "rate": 0,
           "script": LATIN, "char_w": 0.54, "spaced": True},
    "th": {"label": "Thai", "native": "ไทย", "edge": "th-",
           "voices": ["th-TH-NiwatNeural", "th-TH-PremwadeeNeural"],
           "male": "th-TH-NiwatNeural", "female": "th-TH-PremwadeeNeural", "rate": 10,
           "script": [(0x0E00, 0x0E7F)], "char_w": 0.55, "spaced": False},
    "es": {"label": "Spanish", "native": "Español", "edge": "es-",
           "voices": ["es-MX-JorgeNeural", "es-ES-AlvaroNeural", "es-MX-DaliaNeural", "es-ES-ElviraNeural"],
           "male": "es-MX-JorgeNeural", "female": "es-MX-DaliaNeural", "rate": 10,
           "script": LATIN, "char_w": 0.52, "spaced": True},
    "pt": {"label": "Portuguese (Brazil)", "native": "Português", "edge": "pt-BR",
           "voices": ["pt-BR-AntonioNeural", "pt-BR-FranciscaNeural", "pt-BR-ThalitaMultilingualNeural"],
           "male": "pt-BR-AntonioNeural", "female": "pt-BR-FranciscaNeural", "rate": 10,
           "script": LATIN, "char_w": 0.52, "spaced": True, "file": "Portuguese"},
    "hi": {"label": "Hindi", "native": "हिन्दी", "edge": "hi-",
           "voices": ["hi-IN-MadhurNeural", "hi-IN-SwaraNeural"],
           "male": "hi-IN-MadhurNeural", "female": "hi-IN-SwaraNeural", "rate": 10,
           "script": [(0x0900, 0x097F), (0xA8E0, 0xA8FF)], "char_w": 0.60, "spaced": True},
    "id": {"label": "Indonesian", "native": "Indonesia", "edge": "id-",
           "voices": ["id-ID-ArdiNeural", "id-ID-GadisNeural"],
           "male": "id-ID-ArdiNeural", "female": "id-ID-GadisNeural", "rate": 10,
           "script": LATIN, "char_w": 0.52, "spaced": True},
    "vi": {"label": "Vietnamese", "native": "Tiếng Việt", "edge": "vi-",
           "voices": ["vi-VN-NamMinhNeural", "vi-VN-HoaiMyNeural"],
           "male": "vi-VN-NamMinhNeural", "female": "vi-VN-HoaiMyNeural", "rate": 10,
           "script": LATIN, "char_w": 0.52, "spaced": True},
    "fil": {"label": "Filipino", "native": "Filipino", "edge": "fil-",
            "voices": ["fil-PH-AngeloNeural", "fil-PH-BlessicaNeural"],
            "male": "fil-PH-AngeloNeural", "female": "fil-PH-BlessicaNeural", "rate": 10,
            "script": LATIN, "char_w": 0.52, "spaced": True},
    "ko": {"label": "Korean", "native": "한국어", "edge": "ko-",
           "voices": ["ko-KR-InJoonNeural", "ko-KR-HyunsuMultilingualNeural", "ko-KR-SunHiNeural"],
           "male": "ko-KR-InJoonNeural", "female": "ko-KR-SunHiNeural", "rate": 10,
           "script": [(0xAC00, 0xD7AF), (0x1100, 0x11FF), (0x3130, 0x318F)], "char_w": 0.95, "spaced": True},
    "ja": {"label": "Japanese", "native": "日本語", "edge": "ja-",
           "voices": ["ja-JP-KeitaNeural", "ja-JP-NanamiNeural"],
           "male": "ja-JP-KeitaNeural", "female": "ja-JP-NanamiNeural", "rate": 10,
           "script": [(0x3040, 0x30FF), (0x31F0, 0x31FF), (0x3400, 0x4DBF), (0x4E00, 0x9FFF)],
           "char_w": 1.0, "spaced": False},
    "zh": {"label": "Chinese", "native": "中文", "edge": "zh-CN",
           "voices": ["zh-CN-YunxiNeural", "zh-CN-YunjianNeural", "zh-CN-XiaoxiaoNeural", "zh-CN-XiaoyiNeural"],
           "male": "zh-CN-YunxiNeural", "female": "zh-CN-XiaoxiaoNeural", "rate": 10,
           "script": [(0x3400, 0x4DBF), (0x4E00, 0x9FFF)], "char_w": 1.0, "spaced": False},
    "ar": {"label": "Arabic", "native": "العربية", "edge": "ar-",
           "voices": ["ar-SA-HamedNeural", "ar-EG-ShakirNeural", "ar-SA-ZariyahNeural"],
           "male": "ar-SA-HamedNeural", "female": "ar-SA-ZariyahNeural", "rate": 5,
           "script": [(0x0600, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF), (0xFB50, 0xFDFF), (0xFE70, 0xFEFF)],
           "char_w": 0.50, "spaced": True},
    "fr": {"label": "French", "native": "Français", "edge": "fr-",
           "voices": ["fr-FR-HenriNeural", "fr-FR-RemyMultilingualNeural", "fr-FR-DeniseNeural"],
           "male": "fr-FR-HenriNeural", "female": "fr-FR-DeniseNeural", "rate": 10,
           "script": LATIN, "char_w": 0.52, "spaced": True},
    "de": {"label": "German", "native": "Deutsch", "edge": "de-",
           "voices": ["de-DE-ConradNeural", "de-DE-KillianNeural", "de-DE-FlorianMultilingualNeural",
                      "de-DE-KatjaNeural"],
           "male": "de-DE-ConradNeural", "female": "de-DE-KatjaNeural", "rate": 10,
           "script": LATIN, "char_w": 0.54, "spaced": True},
    "tr": {"label": "Turkish", "native": "Türkçe", "edge": "tr-",
           "voices": ["tr-TR-AhmetNeural", "tr-TR-EmelNeural"],
           "male": "tr-TR-AhmetNeural", "female": "tr-TR-EmelNeural", "rate": 10,
           "script": LATIN, "char_w": 0.52, "spaced": True},
}

ORDER = list(LANGUAGES)


def get(code: str) -> dict:
    if code not in LANGUAGES:
        raise ValueError(f"Unknown output language: {code}")
    return LANGUAGES[code]


def label(code: str) -> str:
    return LANGUAGES.get(code, {}).get("label", code)


def file_label(code: str) -> str:
    """Output file name without extension: Burmese.mp4, English.mp4, Thai.mp4, Portuguese.mp4 ..."""
    info = LANGUAGES.get(code, {})
    return info.get("file") or info.get("label", code)


def edge_voice_ok(code: str, voice: str) -> bool:
    prefix = LANGUAGES.get(code, {}).get("edge", "")
    return bool(prefix) and str(voice or "").startswith(prefix)


def script_share(text: str, code: str) -> float:
    """Share of the letters in `text` that belong to the language's own script (1.0 = all)."""
    ranges = LANGUAGES.get(code, {}).get("script") or []
    letters = [ch for ch in str(text or "") if ch.isalpha()]
    if not letters or not ranges:
        return 1.0
    own = sum(1 for ch in letters if any(lo <= ord(ch) <= hi for lo, hi in ranges))
    return own / len(letters)
