from __future__ import annotations

import math
import os
from pathlib import Path
import re
import wave
import unicodedata

from .media import SR, wav_duration
from .chromium_subtitles import (
    render_brand_text_png, render_subtitle_pngs, subtitle_band_geometry, subtitle_overlay_geometry,
    resolve_font, visible_brand_png, font_identity,
)
from .runtime import digest


VOXCPM_MAX_VIDEO_SPEED = 1.25
VOXCPM_MAX_VIDEO_SLOW = 1.35
BRANDING_RENDER_VERSION = 3


def _subtitle_clusters(text: str):
    """Small Unicode grapheme-ish clusters without adding a regex dependency."""
    out = []
    current = ""
    for ch in str(text or ""):
        cat = unicodedata.category(ch)
        attach = bool(current) and (cat in {"Mn", "Mc", "Me"} or ch in {"\u200c", "\u200d", "\ufe0f"})
        if not current:
            current = ch
        elif attach:
            current += ch
        else:
            out.append(current)
            current = ch
    if current:
        out.append(current)
    return out


def _subtitle_cluster_len(text: str) -> int:
    return sum(1 for c in _subtitle_clusters(text) if not c.isspace())


def _subtitle_line_capacity(language: str, width: int, font_size: int) -> int:
    """Conservative visual capacity for one rendered line."""
    usable_px = max(120.0, float(width) * 0.88 - float(font_size) * 1.45)
    lang = str(language or "").lower()
    from .languages import LANGUAGES
    info = LANGUAGES.get(lang) if lang not in ("en", "") else None
    if lang.startswith("my"):
        avg_em = 0.72
        lo, hi = 12, 24
    elif info:
        avg_em = float(info.get("char_w", 0.54))
        if avg_em >= 0.9:          # CJK: one character is about one em wide
            lo, hi = 8, 22
        elif not info.get("spaced", True) or avg_em > 0.56:
            lo, hi = 12, 30        # Thai, Hindi
        else:
            lo, hi = 20, 42
    else:
        avg_em = 0.54
        lo, hi = 20, 42
    cap = int(usable_px / max(1.0, float(font_size) * avg_em))
    return max(lo, min(hi, cap))


def _wrap_subtitle_lines(text: str, language: str, width: int, font_size: int):
    """Wrap translated text into short display lines while preserving all text."""
    normalized = " ".join(str(text or "").replace("\n", " ").split()).strip()
    if not normalized:
        return []
    cap = _subtitle_line_capacity(language, width, font_size)
    clusters = _subtitle_clusters(normalized)
    lines = []
    start = 0
    n = len(clusters)
    strong_break = set("။!?…。！？।؟")
    soft_break = set("၊,;:—- ，、")
    while start < n:
        while start < n and clusters[start].isspace():
            start += 1
        if start >= n:
            break
        visible = 0
        end = start
        best_strong = None
        best_soft = None
        while end < n:
            c = clusters[end]
            if not c.isspace():
                visible += 1
            if any(ch in strong_break for ch in c):
                best_strong = end + 1
            elif c.isspace() or any(ch in soft_break for ch in c):
                best_soft = end + 1
            end += 1
            if visible >= cap:
                candidate = None
                floor = max(start + 1, start + int((end - start) * 0.55))
                if best_strong is not None and best_strong >= floor:
                    candidate = best_strong
                elif best_soft is not None and best_soft >= floor:
                    candidate = best_soft
                end = candidate or end
                break
        piece = "".join(clusters[start:end]).strip()
        if piece:
            lines.append(piece)
        start = end
    return lines


def _subtitle_display_cues(text: str, language: str, width: int, font_size: int, max_lines: int = 2):
    """Split only visual subtitles; TTS, Smart Sync and speaker routing stay unchanged."""
    lines = _wrap_subtitle_lines(text, language, width, font_size)
    max_lines = max(1, min(3, int(max_lines)))
    return ["\n".join(lines[i:i + max_lines]) for i in range(0, len(lines), max_lines)]


def _subtitle_event_slices(start: float, end: float, cues):
    """Distribute one TTS unit's display time across its visual-only cues."""
    cues = [str(x or "").strip() for x in cues if str(x or "").strip()]
    if not cues or end <= start:
        return []
    weights = [max(1, _subtitle_cluster_len(x)) for x in cues]
    total = float(sum(weights))
    duration = float(end) - float(start)
    out = []
    acc = 0.0
    for i, (cue, weight) in enumerate(zip(cues, weights)):
        st = float(start) + duration * (acc / total)
        acc += float(weight)
        en = float(end) if i == len(cues) - 1 else float(start) + duration * (acc / total)
        out.append((st, en, cue))
    return out


def _encoder_args(cfg, encoder, nvenc_preset=None):
    preset, crf = {"fast": ("veryfast", "24"), "balanced": ("medium", "20"),
                   "high": ("slow", "17")}[cfg.quality]
    if encoder == "h264_nvenc":
        args = ["-c:v", encoder]
        if nvenc_preset:
            args += ["-preset", nvenc_preset]
        args += ["-cq", crf, "-b:v", "0", "-pix_fmt", "yuv420p"]
        return args
    return ["-c:v", "libx264", "-preset", preset, "-crf", crf, "-pix_fmt", "yuv420p"]


def _nvenc_error_summary(exc):
    lines = [line.strip() for line in str(exc).replace("\r", "\n").splitlines() if line.strip()]
    if not lines:
        return "unknown FFmpeg/NVENC error"
    preferred = (
        "cannot load", "minimum required", "driver", "no capable devices",
        "openencodesession", "initializeencoder", "unsupported", "not supported",
        "nvenc", "cuda", "nvidia",
    )
    for line in reversed(lines):
        low = line.lower()
        if "terminating thread" in low:
            continue
        if any(word in low for word in preferred):
            return line[-500:]
    for line in reversed(lines):
        if "terminating thread" not in line.lower():
            return line[-500:]
    return lines[-1][-500:]


def _choose_encoder(cfg, media, work_dir):
    if cfg.device == "cpu":
        media.control.log("Render encoder: CPU libx264 (device=cpu)")
        return "libx264", None
    try:
        out, err = media.control.run([media.ffmpeg, "-hide_banner", "-encoders"], timeout=60)
        encoders = (out or "") + "\n" + (err or "")
    except Exception as exc:
        encoders = ""
        media.control.log(f"NVENC capability query failed: {_nvenc_error_summary(exc)}")
    if "h264_nvenc" not in encoders:
        media.control.log("NVENC unavailable: FFmpeg does not list h264_nvenc; render uses CPU libx264")
        return "libx264", None
    probe = Path(work_dir) / "nvenc_probe.mp4"
    candidates = [("p4", "modern p4"), ("fast", "legacy fast"), (None, "default preset")]
    last_error = None
    for preset, label in candidates:
        try:
            args = ["-v", "error", "-f", "lavfi", "-i", "color=size=640x360:rate=30",
                    "-frames:v", "3", "-an", "-pix_fmt", "yuv420p", "-c:v", "h264_nvenc"]
            if preset:
                args += ["-preset", preset]
            args += ["-cq", "24", "-b:v", "0", probe]
            media.ff(args)
            probe.unlink(missing_ok=True)
            media.control.log("Render encoder: NVIDIA NVENC (h264_nvenc" +
                              (f", preset={preset}" if preset else ", default preset") + ")")
            return "h264_nvenc", preset
        except RuntimeError as exc:
            probe.unlink(missing_ok=True)
            last_error = _nvenc_error_summary(exc)
            if label != candidates[-1][1]:
                media.control.log(f"NVENC {label} probe failed: {last_error}; trying next compatibility mode")
    media.control.log(f"NVENC probes failed: {last_error or 'unknown error'}; render uses CPU libx264")
    return "libx264", None


def _voxcpm_sync_filter(source_duration: float, target_duration: float,
                        max_video_speed: float = VOXCPM_MAX_VIDEO_SPEED,
                        max_video_slow: float = VOXCPM_MAX_VIDEO_SLOW):
    """Copied from the user's working VoxCPM Bundle(7) _sync_filter logic.

    Auto-freeze is intentionally OFF, matching that bundle's production config.
    The max slow value therefore does not clamp long narration: long TTS gets exact
    setpts stretch, exactly like the working VoxCPM path.
    """
    if source_duration <= 0.01 or target_duration <= 0.01:
        raise ValueError("Smart Sync duration invalid")
    max_speed = max(1.0, float(max_video_speed))
    max_slow = max(1.0, float(max_video_slow))
    desired = target_duration / source_duration
    min_factor = 1.0 / max_speed

    if desired < min_factor:
        applied = min_factor
        return (
            f"trim=duration={source_duration:.6f},setpts={applied:.9f}*(PTS-STARTPTS),"
            f"trim=duration={target_duration:.6f},setpts=PTS-STARTPTS,fps=30",
            {"desired_factor": desired, "applied_factor": applied,
             "source_duration": source_duration, "target_duration": target_duration,
             "mode": "VOXCPM_SPEED_CAP_THEN_TRIM"},
        )

    # This is the exact Bundle(7) behaviour when smooth_freeze_fallback=False.
    applied = desired
    return (
        f"trim=duration={source_duration:.6f},setpts={applied:.9f}*(PTS-STARTPTS),fps=30",
        {"desired_factor": desired, "applied_factor": applied,
         "source_duration": source_duration, "target_duration": target_duration,
         "mode": "VOXCPM_EXACT_SETPTS"},
    )


def _timeline(rows, source_duration):
    """Speech uses its REAL Whisper timestamp; everything between timestamps is a gap.

    Unlike the recap planner's midpoint full-coverage windows, gaps are not assigned
    to neighbouring narration. They remain untouched 1.0x source scenes.
    """
    ordered = [dict(r) for r in sorted(rows, key=lambda r: (float(r["source_start"]), float(r["source_end"])))]
    if not ordered:
        raise ValueError("No timestamped TTS rows")
    duration = float(source_duration)
    units = []
    cursor = 0.0
    for row in ordered:
        start = max(0.0, min(duration, float(row["source_start"])))
        end = max(start, min(duration, float(row["source_end"])))
        overlap_trim = max(0.0, cursor - start)
        # Whisper/word timestamp boundaries can overlap slightly after sentence-lock
        # (e.g. 100-200 ms). Duplicating that source video would break the DUB
        # timeline, while aborting the whole render is unnecessarily strict.
        # For small boundary overlaps, keep the previous unit intact and trim only
        # the later unit's source start to the previous end. Larger overlaps still
        # fail loudly because they usually indicate a genuinely bad timestamp plan.
        # Accept up to 0.500 s of boundary overlap. Some Whisper/sentence-lock
        # plans land around 0.40 s even when chronology is otherwise healthy.
        # We still fail above 0.50 s so genuinely bad timestamp plans stay visible.
        if overlap_trim > 0.500:
            raise ValueError(
                f"Overlapping timestamp units near {row['id']}: "
                f"{start:.3f} < {cursor:.3f} (overlap={overlap_trim:.3f}s)"
            )
        start = max(start, cursor)
        if start > cursor + 0.001:
            units.append({"type": "gap", "source_start": cursor, "source_end": start,
                          "source_duration": start - cursor, "row": None})
        if end > start + 0.01:
            units.append({"type": "speech", "source_start": start, "source_end": end,
                          "source_duration": end - start, "row": row,
                          "overlap_trimmed": overlap_trim})
            cursor = end
        else:
            cursor = max(cursor, start)
    # A sub-0.25 s tail after the last narration is usually past the final video
    # frame (container duration comes from the longer audio stream). Seeking there
    # yields a 0-stream MP4 and the render dies with KeyError 'duration'. Drop it.
    if cursor < duration - 0.25:
        units.append({"type": "gap", "source_start": cursor, "source_end": duration,
                      "source_duration": duration - cursor, "row": None})
    return units


def _visual_graph(base_chain, cfg):
    """Per-part visual graph only.

    Custom subtitles are intentionally NOT overlaid here.  Bundle(10)'s proven
    strategy is used later: Chromium PNGs -> one alpha subtitle track -> one
    final overlay pass.  Keeping subtitle images out of every Smart-Sync part
    avoids repeated looping-image FFmpeg work and the memory/time blow-up.
    """
    chain = base_chain
    if cfg.mirror_video:
        chain += ",hflip"
    boxes = []
    if cfg.blur_original_subtitles:
        for b in (getattr(cfg, "blur_box", None), getattr(cfg, "blur_box2", None)):
            if b: boxes.append([float(v) for v in b])
    parts = [f"[0:v]{chain}[v0]"]
    current = "v0"
    for i, (x,y,w,h) in enumerate(boxes, 1):
        parts.append(f"[{current}]split=2[vb{i}][vt{i}]")
        parts.append(f"[vt{i}]crop=w='max(2,iw*{w:.10f})':h='max(2,ih*{h:.10f})':x='iw*{x:.10f}':y='ih*{y:.10f}',boxblur=luma_radius=18:luma_power=2:chroma_radius=9:chroma_power=2[vbl{i}]")
        parts.append(f"[vb{i}][vbl{i}]overlay=x='main_w*{x:.10f}':y='main_h*{y:.10f}'[vo{i}]")
        current=f"vo{i}"
    parts.append(f"[{current}]pad=ceil(iw/2)*2:ceil(ih/2)*2:(ow-iw)/2:(oh-ih)/2,format=yuv420p[vout]")
    return ";".join(parts), True

def _render_part(cfg, media, unit, output, encoder, nvenc_preset):
    source_duration = float(unit["source_duration"])
    if unit["type"] == "speech":
        target = wav_duration(unit["row"]["audio"])
        sync_chain, metrics = _voxcpm_sync_filter(source_duration, target)
        # Frame-lock guard only: it does not change the VoxCPM timing decision.
        # It prevents the last CFR frame from ending a few ms before the narration.
        stream_target = target + (1.0 / 30.0)
        base_chain = sync_chain + f",tpad=stop_mode=clone:stop_duration=0.08,trim=duration={stream_target:.6f},setpts=PTS-STARTPTS"
    else:
        target = source_duration
        metrics = {"desired_factor": 1.0, "applied_factor": 1.0,
                   "source_duration": source_duration, "target_duration": target,
                   "mode": "GAP_KEEP_1X"}
        stream_target = target + (1.0 / 30.0)
        base_chain = f"trim=duration={source_duration:.6f},setpts=PTS-STARTPTS,fps=30,tpad=stop_mode=clone:stop_duration=0.08,trim=duration={stream_target:.6f},setpts=PTS-STARTPTS"

    graph, _ = _visual_graph(base_chain, cfg)
    args = ["-v", "error", "-ss", f"{float(unit['source_start']):.6f}",
            "-t", f"{source_duration:.6f}", "-i", cfg.input,
            "-an", "-filter_complex", graph, "-map", "[vout]",
            "-t", f"{stream_target:.6f}",
            *_encoder_args(cfg, encoder, nvenc_preset), "-movflags", "+faststart", output]
    media.ff(args)
    actual = media.duration(output)
    metrics["rendered_duration"] = actual
    return metrics


def _concat_video(media, parts, output, work):
    listing = Path(work) / "video_parts.txt"
    lines = []
    for p in parts:
        q = str(Path(p).resolve()).replace("\\", "/").replace("'", "'\\''")
        lines.append(f"file '{q}'")
    listing.write_text("\n".join(lines) + "\n", encoding="utf-8")
    media.ff(["-v", "error", "-f", "concat", "-safe", "0", "-i", listing,
              "-c", "copy", "-movflags", "+faststart", output])


def _ffconcat_escape_name(name: str) -> str:
    return str(name).replace("'", "'\\''")


def _create_blank_rgba_png(media, out: Path, width: int, height: int) -> None:
    media.ff([
        "-v", "error", "-f", "lavfi", "-i",
        f"color=c=black@0.0:s={int(width)}x{int(height)},format=rgba",
        "-frames:v", "1", str(out),
    ])


def _build_subtitle_track(media, events, duration: float, fps: int, work: Path,
                          width: int, height: int):
    """Bundle(10) subtitle architecture: many PNG cues -> ONE alpha MOV track.

    The track is transparent during gaps and contains only the Chromium-rendered
    subtitle bands during cue intervals.  Final video gets exactly one overlay.
    """
    if not events:
        return None
    duration = max(0.1, float(duration))
    work.mkdir(parents=True, exist_ok=True)
    track = work / "subtitle_track.mov"

    # Safe resume: this work directory is render-key specific. Reuse only a sane,
    # complete track; a cancelled/partial file is deleted and rebuilt.
    if track.is_file() and track.stat().st_size > 4096:
        try:
            td = float(media.duration(track))
            if abs(td - duration) <= 0.20:
                media.control.log(f"Subtitle track reused · ONE alpha stream · {td:.2f}s")
                return track
        except Exception:
            pass
        track.unlink(missing_ok=True)

    blank = work / "blank.png"
    if not blank.is_file():
        _create_blank_rgba_png(media, blank, width, height)

    timeline = []
    cursor = 0.0
    for i, ev in enumerate(sorted(events, key=lambda x: float(x.get("start", 0.0)))):
        st = max(0.0, min(duration, float(ev.get("start", 0.0))))
        en = max(st, min(duration, float(ev.get("end", st))))
        if st > cursor + 0.001:
            timeline.append((blank, st - cursor))
            cursor = st
        if en <= cursor + 0.01:
            continue
        copied = work / f"sub_{i:04d}.png"
        src = Path(ev["png"])
        if (not copied.is_file()) or copied.stat().st_size != src.stat().st_size:
            import shutil
            shutil.copy2(src, copied)
        timeline.append((copied, en - cursor))
        cursor = en
    if cursor < duration - 0.001:
        timeline.append((blank, duration - cursor))
    if not timeline:
        timeline = [(blank, duration)]

    concat_file = work / "subtitles.ffconcat"
    lines = ["ffconcat version 1.0\n"]
    for path, dur in timeline:
        lines.append(f"file '{_ffconcat_escape_name(path.name)}'\n")
        lines.append(f"duration {max(0.01, float(dur)):.6f}\n")
    lines.append(f"file '{_ffconcat_escape_name(timeline[-1][0].name)}'\n")
    concat_file.write_text("".join(lines), encoding="utf-8")

    media.control.log(
        f"Subtitle track build · {len(events)} cue(s) -> ONE alpha stream · qtrle · {width}x{height}"
    )
    media.ff([
        "-v", "error", "-f", "concat", "-safe", "0", "-i", str(concat_file),
        "-vf", f"fps={int(fps)},format=argb", "-t", f"{duration:.3f}",
        "-an", "-c:v", "qtrle", str(track),
    ])
    media.control.log(f"Subtitle track ready · ONE alpha stream · {media.duration(track):.2f}s")
    return track


def _normalized_overlay_xy(x_fraction: float, y_fraction: float):
    """FFmpeg overlay expressions for normalized CENTER coordinates, clamped on-frame."""
    x = max(0.0, min(1.0, float(x_fraction)))
    y = max(0.0, min(1.0, float(y_fraction)))
    return (
        f"max(0,min(main_w-overlay_w,main_w*{x:.10f}-overlay_w/2))",
        f"max(0,min(main_h-overlay_h,main_h*{y:.10f}-overlay_h/2))",
    )


def _branding_title_text(cfg) -> str:
    base = str(getattr(cfg, "title_base", "") or "").strip()
    if not base:
        return ""
    index = max(0, int(getattr(cfg, "title_index", 0) or 0))
    return f"{base} {index}" if index > 0 else base


def _prepare_branding_assets(cfg, media, work: Path, frame_w: int, frame_h: int):
    """Prepare optional logo/watermark/title overlays; empty fields simply skip."""
    assets = []
    brand_dir = Path(work) / "branding_assets_v1"
    brand_dir.mkdir(parents=True, exist_ok=True)
    font = None
    if str(getattr(cfg, "title_base", "") or "").strip() or str(getattr(cfg, "watermark_text", "") or "").strip():
        font = resolve_font(getattr(cfg, "subtitle_font_path", ""))
        media.control.log(f"Branding font: {font.name}")

    logo_raw = str(getattr(cfg, "logo_path", "") or "").strip()
    if logo_raw:
        logo = Path(os.path.expandvars(logo_raw)).expanduser()
        if logo.is_file():
            assets.append({
                "kind": "logo", "path": logo,
                "width": max(24, int(round(frame_w * float(getattr(cfg, "logo_size_fraction", .12))))),
                "opacity": max(0.0, min(1.0, float(getattr(cfg, "logo_opacity", 1.0)))),
                "x": float(getattr(cfg, "logo_x_fraction", .90)),
                "y": float(getattr(cfg, "logo_y_fraction", .10)),
                "duration": 0.0,
            })

    watermark = str(getattr(cfg, "watermark_text", "") or "").strip()
    if watermark and float(getattr(cfg, "watermark_opacity", .34)) > 0:
        wm_key = digest({
            "v": BRANDING_RENDER_VERSION, "text": watermark, "frame": [frame_w, frame_h],
            "font": font_identity(str(font)),
            "size": int(getattr(cfg, "watermark_font_size", 34)),
            "opacity": float(getattr(cfg, "watermark_opacity", .34)),
        })[:20]
        wm_png = brand_dir / f"watermark_{wm_key}.png"
        if not visible_brand_png(wm_png):
            render_brand_text_png(
                watermark, max(240, int(frame_w * .72)), frame_h, wm_png,
                str(font), int(getattr(cfg, "watermark_font_size", 34)),
                float(getattr(cfg, "watermark_opacity", .34)), plate=False,
            )
        if not visible_brand_png(wm_png):
            raise RuntimeError("Watermark ပုံဖိုင် အလွတ်ဖြစ်နေပါသည်။ START / RESUME ပြန်နှိပ်ပါ။")
        if wm_png.is_file():
            assets.append({
                "kind": "watermark", "path": wm_png, "width": None, "opacity": 1.0,
                "x": float(getattr(cfg, "watermark_x_fraction", .86)),
                "y": float(getattr(cfg, "watermark_y_fraction", .92)),
                "duration": 0.0,
            })

    title = _branding_title_text(cfg)
    if title:
        title_key = digest({
            "v": BRANDING_RENDER_VERSION, "text": title, "frame": [frame_w, frame_h],
            "font": font_identity(str(font)),
            "size": int(getattr(cfg, "title_font_size", 64)),
        })[:20]
        title_png = brand_dir / f"title_{title_key}.png"
        if not visible_brand_png(title_png):
            render_brand_text_png(
                title, max(320, int(frame_w * .90)), frame_h, title_png,
                str(font), int(getattr(cfg, "title_font_size", 64)),
                1.0, plate=True,
            )
        if not visible_brand_png(title_png):
            raise RuntimeError("Title ပုံဖိုင် အလွတ်ဖြစ်နေပါသည်။ START / RESUME ပြန်နှိပ်ပါ။")
        media.control.log(f"Title ready: {title!r} · {float(getattr(cfg, 'title_duration_seconds', 5.0)):g}s (0 = whole video)")
        if title_png.is_file():
            assets.append({
                "kind": "title", "path": title_png, "width": None, "opacity": 1.0,
                "x": float(getattr(cfg, "title_x_fraction", .50)),
                "y": float(getattr(cfg, "title_y_fraction", .12)),
                "duration": max(0.0, float(getattr(cfg, "title_duration_seconds", 5.0))),
            })

    if assets:
        media.control.log("Branding: " + " + ".join(x["kind"] for x in assets) + " · final overlay pass")
    else:
        media.control.log("Branding: empty · logo/watermark/title skipped")
    return assets


def _voice_volume_args(cfg):
    """Narration gain for the final mux; the limiter keeps a raised voice from clipping."""
    percent = int(getattr(cfg, "voice_volume_percent", 100) or 100)
    if percent == 100:
        return []
    return ["-af", f"volume={percent / 100.0:.3f},alimiter=limit=0.95:level=disabled"]


def _mux_with_optional_subtitle_track(cfg, media, silent_video, narration, output,
                                      audio_duration, encoder, nvenc_preset,
                                      subtitle_track=None, subtitle_x=0, subtitle_y=0,
                                      branding=None):
    branding = list(branding or [])
    if not subtitle_track and not branding:
        media.ff([
            "-v", "error", "-i", silent_video, "-i", narration,
            "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy",
            *_voice_volume_args(cfg),
            "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2",
            "-movflags", "+faststart", output,
        ])
        return

    media.control.log(
        f"Final overlay · ONE pass only · encoder={encoder} · subtitle={bool(subtitle_track)} · branding={len(branding)}"
    )
    args = ["-v", "error", "-i", silent_video, "-i", narration]
    input_index = 2
    subtitle_index = None
    if subtitle_track:
        subtitle_index = input_index
        args += ["-i", subtitle_track]
        input_index += 1

    brand_inputs = []
    for item in branding:
        idx = input_index
        args += ["-loop", "1", "-framerate", "30", "-i", str(item["path"])]
        brand_inputs.append((idx, item))
        input_index += 1

    filters = []
    current = "0:v"
    serial = 0
    if subtitle_index is not None:
        serial += 1
        out_label = f"ov{serial}"
        filters.append(
            f"[{current}][{subtitle_index}:v]overlay={int(subtitle_x)}:{int(subtitle_y)}:shortest=0:eof_action=pass[{out_label}]"
        )
        current = out_label

    for idx, item in brand_inputs:
        serial += 1
        prep = f"brand{serial}"
        chain = f"[{idx}:v]"
        width = item.get("width")
        if width:
            chain += f"scale={int(width)}:-1:flags=lanczos,"
        chain += "format=rgba"
        opacity = float(item.get("opacity", 1.0))
        if opacity < .999:
            chain += f",colorchannelmixer=aa={max(0.0,min(1.0,opacity)):.6f}"
        chain += f"[{prep}]"
        filters.append(chain)

        xexpr, yexpr = _normalized_overlay_xy(item.get("x", .5), item.get("y", .5))
        out_label = f"ov{serial}"
        enable = ""
        duration = float(item.get("duration", 0.0) or 0.0)
        if duration > 0.0:
            enable = f":enable='between(t,0,{duration:.6f})'"
        filters.append(
            f"[{current}][{prep}]overlay=x='{xexpr}':y='{yexpr}':shortest=0:eof_action=repeat{enable}[{out_label}]"
        )
        current = out_label

    filters.append(f"[{current}]format=yuv420p[vout]")
    args += [
        "-filter_complex", ";".join(filters), "-map", "[vout]", "-map", "1:a:0",
        "-t", f"{float(audio_duration):.6f}",
        *_encoder_args(cfg, encoder, nvenc_preset),
        *_voice_volume_args(cfg),
        "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2",
        "-movflags", "+faststart", output,
    ]
    media.ff(args)


def _write_silence(dst, frames):
    chunk = b"\x00\x00" * min(65536, max(1, int(frames)))
    chunk_frames = len(chunk) // 2
    remaining = int(frames)
    while remaining > 0:
        n = min(remaining, chunk_frames)
        dst.writeframesraw(chunk[:n * 2])
        remaining -= n


def _build_audio_from_rendered_units(units, part_durations, output):
    """Audio follows the rendered part durations, eliminating cumulative part rounding drift."""
    output = Path(output)
    temp = output.with_suffix(".part.wav")
    rows_out = []
    cursor_frames = 0
    with wave.open(str(temp), "wb") as dst:
        dst.setnchannels(1); dst.setsampwidth(2); dst.setframerate(SR)
        for idx, (unit, part_duration) in enumerate(zip(units, part_durations)):
            target_frames = max(1, round(float(part_duration) * SR))
            start = cursor_frames / SR
            if unit["type"] == "gap":
                _write_silence(dst, target_frames)
                cursor_frames += target_frames
                continue

            row = dict(unit["row"])
            with wave.open(str(row["audio"]), "rb") as src:
                if (src.getnchannels(), src.getsampwidth(), src.getframerate()) != (1, 2, SR):
                    raise ValueError("Narration WAV format mismatch")
                tts_frames = src.getnframes()
                if tts_frames > target_frames + round(0.04 * SR):
                    raise ValueError(
                        f"Rendered video part shorter than TTS after frame-lock guard: {row['id']} "
                        f"video={target_frames/SR:.3f}s tts={tts_frames/SR:.3f}s"
                    )
                data = src.readframes(tts_frames)
                dst.writeframesraw(data)
                if target_frames > tts_frames:
                    _write_silence(dst, target_frames - tts_frames)
                elif tts_frames > target_frames:
                    # <= ~one frame only. Keep narration intact and let audio define this
                    # part by the tiny overage; final validation reports it explicitly.
                    target_frames = tts_frames
            end_speech = start + tts_frames / SR
            cursor_frames += target_frames
            row.update({
                "start": start,
                "end": end_speech,
                "output_start": start,
                "output_end": end_speech,
                "output_window_end": cursor_frames / SR,
                "tts_duration": tts_frames / SR,
                "source_window_start": unit["source_start"],
                "source_window_end": unit["source_end"],
                "source_window_duration": unit["source_duration"],
                "audio_tempo": 1.0,
            })
            rows_out.append(row)
    os.replace(temp, output)
    return rows_out, cursor_frames / SR


def _cached_part_metrics(media, unit, part):
    """Recover Smart Sync metrics for an already-rendered resumable part."""
    source_duration = float(unit["source_duration"])
    if unit["type"] == "speech":
        target = wav_duration(unit["row"]["audio"])
        _chain, metrics = _voxcpm_sync_filter(source_duration, target)
    else:
        target = source_duration
        metrics = {"desired_factor": 1.0, "applied_factor": 1.0,
                   "source_duration": source_duration, "target_duration": target,
                   "mode": "GAP_KEEP_1X"}
    metrics["rendered_duration"] = float(media.duration(part))
    return metrics


def render_motion_safe(cfg, media, cache, rows, source_duration, source_hash, output, background=None):
    """VoxCPM Bundle(7) Smart Sync + ONE dub-only change: preserve timestamp gaps.

    background: the source audio without its voices (dubber/background.py); when given it is laid
    under the dub with the same cuts as the picture (gaps 1.0x, speech parts stretched like it).
    """
    motion_key = {
        "v": 2, "source": source_hash, "quality": cfg.quality, "device": cfg.device,
        "mirror": bool(cfg.mirror_video), "blur": bool(cfg.blur_original_subtitles),
        "blur_box": getattr(cfg, "blur_box", None), "blur_box2": getattr(cfg, "blur_box2", None),
        "rows": [
            (str(r.get("id")), str(r.get("language", "")), float(r.get("source_start", 0.0)),
             float(r.get("source_end", 0.0)), str(r.get("audio", "")), round(wav_duration(r["audio"]), 6))
            for r in rows
        ],
    }
    # Overlay-only changes (subtitle shade/logo/watermark/title) reuse completed Smart-Sync parts.
    work = Path(cache.root) / "motion_work" / digest(motion_key)[:24]
    work.mkdir(parents=True, exist_ok=True)
    encoder, nvenc_preset = _choose_encoder(cfg, media, work)
    units = _timeline(rows, source_duration)
    speech_count = sum(1 for x in units if x["type"] == "speech")
    gap_count = sum(1 for x in units if x["type"] == "gap")
    media.control.log(
        f"VoxCPM EXACT Smart Sync: {speech_count} timestamp parts + {gap_count} untouched gaps · encoder={encoder}"
    )
    trimmed = [(x.get("row", {}).get("id"), float(x.get("overlap_trimmed", 0.0)))
               for x in units if x.get("type") == "speech" and float(x.get("overlap_trimmed", 0.0)) > 0.0005]
    if trimmed:
        detail = ", ".join(f"{sid}={sec:.3f}s" for sid, sec in trimmed)
        media.control.log(f"Timestamp overlap cleanup: trimmed later source-start only · {detail}")

    probe = media.probe(cfg.input)
    vstream = next((x for x in probe.get("streams", []) if x.get("codec_type") == "video"), {})
    frame_w, frame_h = int(vstream.get("width") or 0), int(vstream.get("height") or 0)
    subtitle_style_key = digest({
        "v": "readable_2line_dark64_v2",
        "font": font_identity(getattr(cfg, "subtitle_font_path", "")),
        "size": int(getattr(cfg, "subtitle_font_size", 64)),
        "x": float(getattr(cfg, "subtitle_x_fraction", .50)),
        "y": float(getattr(cfg, "subtitle_y_fraction", .82)),
        "width": float(getattr(cfg, "subtitle_width_fraction", .90)),
        "texts": [(str(r.get("id")), str(r.get("text", ""))) for r in rows],
    })[:20]
    subtitle_dir = work / f"chromium_subtitles_{subtitle_style_key}"
    subtitle_cues_by_id = {}
    subtitle_x = 0
    subtitle_y = 0
    subtitle_band_w = frame_w
    subtitle_band_h = 0
    if getattr(cfg, "burn_custom_subtitles", False):
        subtitle_dir.mkdir(parents=True, exist_ok=True)
        subtitle_band_w, subtitle_band_h, subtitle_x, subtitle_y = subtitle_overlay_geometry(
            frame_w, frame_h, cfg.subtitle_font_size,
            getattr(cfg, "subtitle_x_fraction", 0.50), cfg.subtitle_y_fraction,
            getattr(cfg, "subtitle_width_fraction", 0.90),
        )
        subtitle_jobs = []
        speech_units = 0
        for idx, unit in enumerate(units, 1):
            if unit["type"] != "speech":
                continue
            speech_units += 1
            row = unit["row"]
            row_id = str(row["id"])
            language = str(row.get("language") or "")
            cues = _subtitle_display_cues(
                row.get("text", ""), language, subtitle_band_w, cfg.subtitle_font_size, max_lines=2
            ) or [str(row.get("text", "") or "")]
            cue_items = []
            for cue_index, cue_text in enumerate(cues, 1):
                out_png = subtitle_dir / f"sub_{idx:05d}_{cue_index:03d}.png"
                subtitle_jobs.append((cue_text, out_png))
                cue_items.append({"text": cue_text, "png": out_png})
            subtitle_cues_by_id[row_id] = cue_items
        missing = sum(1 for _text, p in subtitle_jobs if not Path(p).is_file())
        media.control.log(
            f"Readable subtitles: {speech_units} speech unit(s) -> {len(subtitle_jobs)} cue(s) · max 2 lines/cue"
        )
        if missing:
            media.control.log(
                f"Chromium subtitles ON · batch render {missing} missing cue(s) · {resolve_font(cfg.subtitle_font_path).name}"
            )
        else:
            media.control.log("Chromium subtitles ON · all readable subtitle PNG bands reused from cache")
        render_subtitle_pngs(
            subtitle_jobs, subtitle_band_w, frame_h, cfg.subtitle_font_path,
            cfg.subtitle_font_size, cfg.subtitle_y_fraction
        )
        media.control.log(
            f"Chromium subtitle batch ready · {len(subtitle_jobs)} readable cue(s) · font={cfg.subtitle_font_size}px · pos=({getattr(cfg, 'subtitle_x_fraction', .50):.2f},{cfg.subtitle_y_fraction:.2f}) · next: ONE alpha track"
        )
    else:
        media.control.log("Chromium subtitles OFF · subtitle render skipped for faster output")

    parts = []
    part_durations = []
    sync_units = []
    reused_parts = 0
    for idx, unit in enumerate(units, 1):
        media.control.check()
        part = work / f"part_{idx:05d}.mp4"
        # Safe-stop/resume optimization: the render cache key already includes every
        # visual/TTS setting, so a completed part in this work directory is reusable.
        if part.is_file() and part.stat().st_size > 4096:
            try:
                metrics = _cached_part_metrics(media, unit, part)
                if metrics["rendered_duration"] <= 0.01:
                    raise ValueError("empty rendered part")
                reused_parts += 1
            except Exception:
                part.unlink(missing_ok=True)
                metrics = _render_part(cfg, media, unit, part, encoder, nvenc_preset)
        else:
            metrics = _render_part(cfg, media, unit, part, encoder, nvenc_preset)

        actual = float(metrics["rendered_duration"])
        parts.append(part)
        part_durations.append(actual)
        if unit["type"] == "gap":
            if unit["source_duration"] >= 0.10:
                media.control.log(
                    f"GAP KEEP 1.0x · {unit['source_start']:.2f}–{unit['source_end']:.2f}s · {unit['source_duration']:.2f}s"
                )
        else:
            row = unit["row"]
            media.control.log(
                f"{row['language']}/{row['id']}: {metrics['mode']} · source={unit['source_duration']:.2f}s · "
                f"TTS={wav_duration(row['audio']):.2f}s · setpts={metrics['applied_factor']:.3f}"
            )
        sync_units.append({
            "type": unit["type"], "source_start": unit["source_start"],
            "source_end": unit["source_end"], "source_duration": unit["source_duration"],
            "rendered_duration": actual, **{k: v for k, v in metrics.items() if k != "rendered_duration"},
        })
    if reused_parts:
        media.control.log(f"Render resume: reused {reused_parts}/{len(units)} completed video part(s)")

    silent_video = work / "video_concat.mp4"
    _concat_video(media, parts, silent_video, work)
    narration = work / "narration_with_gaps.wav"
    output_rows, audio_duration = _build_audio_from_rendered_units(units, part_durations, narration)
    video_duration = media.duration(silent_video)
    media.control.log(
        f"VoxCPM parts concat: video={video_duration:.3f}s · audio-with-gaps={audio_duration:.3f}s · "
        f"delta={abs(video_duration-audio_duration):.3f}s"
    )

    subtitle_track = None
    if getattr(cfg, "burn_custom_subtitles", False):
        events = []
        for row in output_rows:
            cue_items = subtitle_cues_by_id.get(str(row.get("id", ""))) or []
            slices = _subtitle_event_slices(float(row["start"]), float(row["end"]),
                                             [x["text"] for x in cue_items])
            for cue_item, (cue_start, cue_end, _cue_text) in zip(cue_items, slices):
                events.append({
                    "start": cue_start,
                    "end": cue_end,
                    "png": str(cue_item["png"]),
                })
        track_work = work / f"subtitle_track_{subtitle_style_key}"
        subtitle_track = _build_subtitle_track(
            media, events, audio_duration, 30, track_work, subtitle_band_w, subtitle_band_h
        )

    branding = _prepare_branding_assets(cfg, media, work, frame_w, frame_h)

    soundtrack, mux_cfg = narration, cfg
    if background:
        from .background import build_track, mix_with_voice, with_voice_volume
        bg_stat = Path(background).stat()
        track_key = {"parts": part_durations, "bg": [str(background), bg_stat.st_size, bg_stat.st_mtime_ns]}
        track = work / f"background_track_{digest(track_key)[:16]}.wav"
        if not track.is_file():
            build_track(background, units, part_durations, track, media.control)
        soundtrack = work / "narration_with_background.wav"
        mix_with_voice(media, narration, track, soundtrack, int(getattr(cfg, "voice_volume_percent", 100) or 100),
                       int(getattr(cfg, "background_volume_percent", 100)))
        mux_cfg = with_voice_volume(cfg, 100)  # the voice volume is already in the mix
        media.control.log(f"Background sounds kept under the dub · volume {int(getattr(cfg, 'background_volume_percent', 100))}%")

    temp = Path(output).with_suffix(".part.mp4")
    _mux_with_optional_subtitle_track(
        mux_cfg, media, silent_video, soundtrack, temp, audio_duration,
        encoder, nvenc_preset, subtitle_track, subtitle_x, subtitle_y, branding
    )
    return temp, {
        "schema": "dub.voxcpm_bundle7_exact_plus_gap_keep.subtitle_track.branding_v2",
        "source_duration": float(source_duration),
        "output_duration": float(audio_duration),
        "policy": "VOXCPM_EXACT_ON_TIMESTAMPS__GAPS_KEEP_1X",
        "source_audio": "BACKGROUND_ONLY" if background else "OFF",
        "branding": [{"kind": item["kind"], "duration": item["duration"]} for item in branding],
        "mirror_video": bool(cfg.mirror_video),
        "blur_original_subtitles": bool(cfg.blur_original_subtitles),
        "units": sync_units,
    }, output_rows, encoder


def validate_output(media, path, expected, rows, expected_aspect=None, *_unused):
    p = media.probe(path)
    streams = p.get("streams", [])
    video = next((s for s in streams if s["codec_type"] == "video"), None)
    audio = next((s for s in streams if s["codec_type"] == "audio"), None)
    if not video or not audio:
        raise ValueError("Output must contain video and audio streams")
    actual = float(p["format"]["duration"])
    vstart, astart = float(video.get("start_time", 0) or 0), float(audio.get("start_time", 0) or 0)
    vd, ad = float(video.get("duration", actual) or actual), float(audio.get("duration", actual) or actual)
    out_w, out_h = int(video.get("width") or 0), int(video.get("height") or 0)
    if expected_aspect and out_w > 0 and out_h > 0:
        expected_ratio = float(expected_aspect)
        actual_ratio = out_w / out_h
        if abs(actual_ratio - expected_ratio) / max(expected_ratio, 1e-9) > 0.003:
            raise ValueError(
                f"Output aspect ratio changed: source={expected_ratio:.6f}, output={out_w}x{out_h} ({actual_ratio:.6f})"
            )
    # Part-based CFR has container/sample quantization; 0.35s is strict enough to
    # catch real drift while not rejecting a healthy 10-minute concat for metadata noise.
    tolerance = 0.35
    errors = []
    for name, delta in (("container_duration", abs(actual - expected)),
                        ("audio_duration", abs(ad - expected)),
                        ("video_duration", abs(vd - expected)),
                        ("av_start", abs(vstart - astart)),
                        ("av_end", abs(vstart + vd - astart - ad))):
        if not math.isfinite(delta) or delta > tolerance:
            errors.append(name)
    previous_start = -1.0
    for r in rows:
        if r["start"] < -0.001 or r["end"] <= r["start"] or r["start"] + tolerance < previous_start:
            errors.append(f"alignment:{r['id']}")
        previous_start = r["start"]
    media.control.log(
        f"Validation: expected={expected:.3f}s · container={actual:.3f}s · video={vd:.3f}s · "
        f"audio={ad:.3f}s · A/V end delta={abs(vstart+vd-astart-ad):.3f}s"
    )
    media.ff(["-v", "error", "-xerror", "-i", path,
              "-map", "0:v:0", "-map", "0:a:0", "-f", "null", "-"])
    if errors:
        raise ValueError("Automated output validation failed: " + ", ".join(errors))
    return {"passed": True, "duration": actual, "expected_duration": expected,
            "video_duration": vd, "audio_duration": ad,
            "av_start_delta": abs(vstart - astart),
            "av_end_delta": abs(vstart + vd - astart - ad),
            "video_width": out_w, "video_height": out_h,
            "video_aspect": (out_w / out_h if out_h else None),
            "semantic_accuracy": "VoxCPM exact planner output; human listening review still recommended"}


def srt_timestamp(seconds):
    ms = round(seconds * 1000)
    h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def write_srt(path, rows):
    chunks = []
    for i, r in enumerate(rows, 1):
        text = " ".join(r["text"].split())
        chunks.append(f"{i}\n{srt_timestamp(r['start'])} --> {srt_timestamp(r['end'])}\n{text}\n")
    Path(path).write_text("\n".join(chunks), encoding="utf-8-sig")


def validate_srt(path, rows, duration):
    content = Path(path).read_text(encoding="utf-8-sig").strip()
    blocks = re.split(r"\n\s*\n", content) if content else []
    if len(blocks) != len(rows):
        raise ValueError("Subtitle cue count mismatch")
    return {"passed": True, "cues": len(rows), "encoding": "utf-8-sig"}
