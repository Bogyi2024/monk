"""DUB MASTER: batch Gemini translation + bilingual TTS + dub-safe Smart Sync."""
__version__ = "1.0.0"
