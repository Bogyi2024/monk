from __future__ import annotations

from dataclasses import asdict, replace
import json
import os
from pathlib import Path
import queue
import re
import shutil
import subprocess
import tempfile
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import languages as LANG_TABLE
from .config import Config, VoiceConfig, find_default_env, gemini_key_names
from .pipeline import Pipeline
from .providers import GEMINI_VOICES, list_voices
from .runtime import Cancelled, Control
from .storage_cleanup import start_monitor
from .fonts import PREVIEW_FONT_FAMILY, register_preview_font

# This module is loaded before launch creates Tk, so its font lookup sees the private bundled face.
register_preview_font()

ROOT = Path(__file__).resolve().parent.parent
PROVIDERS = {"Edge TTS": "edge", "Gemini TTS": "gemini", "VoxCPM": "voxcpm"}
LANGS = {"Chinese": "zh", "English": "en", "Thai": "th", "Auto": "auto", "Korean": "ko", "Japanese": "ja"}


VIDEO_EXTENSIONS = {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v"}


def natural_video_sort_key(path):
    """Natural filename order: 1, 2, ... 9, 10, 11 instead of 1, 10, 11, 2."""
    name = Path(path).name.casefold()
    return tuple(int(part) if part.isdigit() else part for part in re.split(r"(\d+)", name))


def collect_batch_videos(folder):
    """Top-level videos only, in stable natural numeric filename order."""
    folder = Path(folder)
    if not folder.is_dir():
        return []
    items = [
        p for p in folder.iterdir()
        if p.is_file() and p.suffix.casefold() in VIDEO_EXTENSIONS
    ]
    return sorted(items, key=natural_video_sort_key)

DARK = {
    "bg": "#11161d",
    "panel": "#18202a",
    "field": "#0d131a",
    "fg": "#e8edf3",
    "muted": "#9aa7b5",
    "accent": "#4f8cff",
    "accent2": "#ffcc00",
    "border": "#2b3745",
}


def apply_dark_theme(root):
    """Compact dark theme for Tk/ttk without external theme packages."""
    root.configure(bg=DARK["bg"])
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    root.option_add("*Font", ("Segoe UI", 9))
    root.option_add("*TCombobox*Listbox.background", DARK["field"])
    root.option_add("*TCombobox*Listbox.foreground", DARK["fg"])
    root.option_add("*TCombobox*Listbox.selectBackground", DARK["accent"])
    root.option_add("*TCombobox*Listbox.selectForeground", "#ffffff")

    style.configure(".", background=DARK["bg"], foreground=DARK["fg"], fieldbackground=DARK["field"])
    style.configure("TFrame", background=DARK["bg"])
    style.configure("TLabel", background=DARK["bg"], foreground=DARK["fg"])
    style.configure("TLabelframe", background=DARK["bg"], foreground=DARK["fg"], bordercolor=DARK["border"], relief="solid")
    style.configure("TLabelframe.Label", background=DARK["bg"], foreground=DARK["fg"])
    style.configure("TButton", background=DARK["panel"], foreground=DARK["fg"], bordercolor=DARK["border"], padding=(9, 5))
    style.map("TButton", background=[("active", "#253243"), ("pressed", "#0d131a")])
    style.configure("TCheckbutton", background=DARK["bg"], foreground=DARK["fg"])
    style.map("TCheckbutton", background=[("active", DARK["bg"])], foreground=[("disabled", "#687584")])
    style.configure("TEntry", fieldbackground=DARK["field"], foreground=DARK["fg"], insertcolor=DARK["fg"], bordercolor=DARK["border"])
    style.configure("TCombobox", fieldbackground=DARK["field"], background=DARK["panel"], foreground=DARK["fg"], arrowcolor=DARK["fg"], bordercolor=DARK["border"])
    style.map("TCombobox", fieldbackground=[("readonly", DARK["field"])], foreground=[("readonly", DARK["fg"])])
    style.configure("Horizontal.TProgressbar", background=DARK["accent"], troughcolor=DARK["field"], bordercolor=DARK["border"])
    style.configure("Horizontal.TScale", background=DARK["bg"], troughcolor=DARK["field"])
    style.configure("TPanedwindow", background=DARK["bg"])
    style.configure("Muted.TLabel", background=DARK["bg"], foreground=DARK["muted"])
    style.configure("Accent.TButton", background=DARK["accent"], foreground="#ffffff", padding=(14, 6))
    style.map("Accent.TButton", background=[("disabled", DARK["panel"]), ("active", "#3c78ea")])
    style.configure("Toolbutton", background=DARK["panel"], foreground=DARK["fg"], padding=(9, 4))
    style.map("Toolbutton", background=[("selected", DARK["accent"]), ("active", "#253243")],
              foreground=[("selected", "#ffffff")])
    style.configure("TRadiobutton", background=DARK["bg"], foreground=DARK["fg"])
    style.configure("TSpinbox", fieldbackground=DARK["field"], foreground=DARK["fg"], arrowcolor=DARK["fg"],
                    bordercolor=DARK["border"])
    style.configure("Vertical.TScrollbar", background=DARK["panel"], troughcolor=DARK["bg"], arrowcolor=DARK["fg"])


class VoicePanel(ttk.LabelFrame):
    """Voice settings of one output language (any language in dubber/languages.py)."""

    def __init__(self, parent, language: str, app):
        info = LANG_TABLE.get(language)
        super().__init__(parent, text=f"{info['label']} · {info['native']}", padding=(8, 4))
        self.language, self.app, self.info = language, app, info
        self.columnconfigure(1, weight=1)
        self.columnconfigure(3, weight=1)
        self.provider = tk.StringVar(value="Edge TTS")
        self.voice = tk.StringVar(value=info["male"])
        self.rate = tk.IntVar(value=int(info["rate"]))
        self.api_url = tk.StringVar()
        self.gender_split = tk.BooleanVar(value=True)
        self.female_voice = tk.StringVar(value=info["female"])

        self.provider_box = ttk.Combobox(self, textvariable=self.provider, values=list(PROVIDERS),
                                         state="readonly", width=11)
        self.provider_box.grid(row=0, column=0, sticky="w", pady=2)
        self.provider_box.bind("<<ComboboxSelected>>", lambda _e: self.provider_changed())
        self.voice_box = ttk.Combobox(self, textvariable=self.voice, state="readonly")
        self.voice_box.grid(row=0, column=1, columnspan=3, sticky="ew", padx=(6, 0), pady=2)
        self.speed_label = ttk.Label(self, text="Speed %")
        self.speed_label.grid(row=0, column=4, padx=(8, 3))
        self.speed_box = ttk.Spinbox(self, from_=-50, to=100, increment=5, width=5, textvariable=self.rate)
        self.speed_box.grid(row=0, column=5, pady=2)

        ttk.Checkbutton(self, text="Auto male/female", variable=self.gender_split,
                        command=self._split_changed).grid(row=1, column=0, sticky="w", pady=2)
        ttk.Label(self, text="Female", style="Muted.TLabel").grid(row=1, column=1, sticky="e", padx=(6, 4))
        self.female_box = ttk.Combobox(self, textvariable=self.female_voice, state="readonly")
        self.female_box.grid(row=1, column=2, columnspan=4, sticky="ew", pady=2)

        self.url_label = ttk.Label(self, text="VoxCPM URL")
        self.url_entry = ttk.Entry(self, textvariable=self.api_url)
        self.load_btn = ttk.Button(self, text="Load voices", command=self.fetch_voices)
        self.provider_changed(reset=False)

    def provider_changed(self, reset=True):
        provider = PROVIDERS[self.provider.get()]
        if provider == "edge":
            values = list(self.info["voices"])
            self.voice_box.configure(values=values, state="readonly")
            if reset or self.voice.get() not in values:
                self.voice.set(self.info["male"])
            self.url_label.grid_remove(); self.url_entry.grid_remove(); self.load_btn.grid_remove()
            self.speed_label.grid(); self.speed_box.grid()
            self._set_female_choices(values, self.info["female"], reset)
        elif provider == "gemini":
            self.voice_box.configure(values=GEMINI_VOICES, state="readonly")
            if reset or self.voice.get() not in GEMINI_VOICES:
                self.voice.set("Charon" if "Charon" in GEMINI_VOICES else GEMINI_VOICES[0])
            self.url_label.grid_remove(); self.url_entry.grid_remove(); self.load_btn.grid_remove()
            self.speed_label.grid_remove(); self.speed_box.grid_remove()
            self._set_female_choices(GEMINI_VOICES, "Kore", reset)
        else:
            self.voice_box.configure(values=[], state="normal")
            if reset:
                self.voice.set("")
            self.url_label.grid(row=2, column=0, sticky="w", pady=2)
            self.url_entry.grid(row=2, column=1, columnspan=3, sticky="ew", padx=(6, 0), pady=2)
            self.load_btn.grid(row=2, column=4, columnspan=2, sticky="e", padx=(6, 0), pady=2)
            self.speed_label.grid_remove(); self.speed_box.grid_remove()
            self._set_female_choices([], "", reset, editable=True)
        self._split_changed()

    def _set_female_choices(self, values, default, reset, editable=False):
        self._female_editable = editable
        self.female_box.configure(values=list(values))
        if reset or (values and self.female_voice.get() not in values) or not self.female_voice.get():
            self.female_voice.set(default)

    def _split_changed(self):
        if not self.gender_split.get():
            self.female_box.configure(state="disabled")
        else:
            self.female_box.configure(state="normal" if getattr(self, "_female_editable", False) else "readonly")

    def fetch_voices(self):
        try:
            vc = self.read()
            if vc.provider != "voxcpm":
                return
            ctl = Control(log=lambda text: self.app.events.put(("log", text)))
            def worker():
                try:
                    voices = list_voices(vc, self.language, ctl, ROOT / ".ui_requests")
                    self.app.events.put(("voices", (self, voices)))
                except Exception as exc:
                    self.app.events.put(("error", f"VoxCPM voices: {exc}"))
            threading.Thread(target=worker, daemon=True).start()
        except Exception as exc:
            messagebox.showerror("VoxCPM", str(exc))

    def read(self):
        provider = PROVIDERS[self.provider.get()]
        try:
            rate = int(float(self.rate.get()))
        except (tk.TclError, ValueError):
            rate = int(self.info["rate"])
        return VoiceConfig(
            provider=provider,
            voice=self.voice.get().strip(),
            api_url=self.api_url.get().strip(),
            model="gemini-3.1-flash-tts-preview",
            rate_percent=max(-50, min(100, rate)),
            gender_split=bool(self.gender_split.get()),
            female_voice=self.female_voice.get().strip(),
        )

    def set(self, vc: VoiceConfig):
        name = next((k for k, v in PROVIDERS.items() if v == vc.provider), "Edge TTS")
        self.provider.set(name)
        self.api_url.set(vc.api_url)
        self.provider_changed(reset=False)
        self.voice.set(vc.voice)
        self.rate.set(int(getattr(vc, "rate_percent", self.info["rate"])))
        self.gender_split.set(bool(getattr(vc, "gender_split", False)))
        if getattr(vc, "female_voice", ""):
            self.female_voice.set(vc.female_voice)
        self._split_changed()


class App:
    def __init__(self, root):
        self.root = root
        root.title("DUB MASTER STABLE — Batch + Branding + Readable Subtitle + Telegram")
        root.geometry("1400x900")
        root.minsize(1120, 720)
        self.events = queue.Queue()
        start_monitor(ROOT / 'outputs', lambda message: self.events.put(('log', message)))
        self.control = Control()
        self.running = False
        self.preview_photo = None
        self.preview_base = None
        self.preview_display = None
        self.preview_bounds = None  # canvas x0,y0,w,h
        self.drag_start = None
        self.drag_rect_id = None
        self.blur_box = None
        self.blur_box2 = None
        self.active_blur_slot = 1
        self.drag_mode = "blur1"
        self.subtitle_x_fraction = 0.50
        self.subtitle_y_fraction = 0.82
        self.logo_x_fraction = 0.90
        self.logo_y_fraction = 0.10
        self.watermark_x_fraction = 0.86
        self.watermark_y_fraction = 0.92
        self.title_x_fraction = 0.50
        self.title_y_fraction = 0.12
        self.logo_preview_photo = None
        self.video_duration = 0.0
        self.video_width = 0
        self.video_height = 0
        self.video_aspect = ""

        self.input = tk.StringVar()
        self.output = tk.StringVar(value=str((ROOT / "outputs").resolve()))
        self.env_file = tk.StringVar(value=find_default_env(ROOT))
        self.env_status = tk.StringVar(value="")
        self.source_language = tk.StringVar(value="Chinese")
        self.mirror = tk.BooleanVar(value=False)
        self.voice_volume = tk.IntVar(value=100)
        self.blur = tk.BooleanVar(value=False)
        self.custom_subtitles = tk.BooleanVar(value=True)
        self.telegram_auto_send = tk.BooleanVar(value=False)
        self.subtitle_font_size = tk.IntVar(value=64)
        self.logo_path = tk.StringVar(value="")
        self.logo_size_percent = tk.IntVar(value=12)
        self.logo_opacity_percent = tk.IntVar(value=100)
        self.watermark_text = tk.StringVar(value="")
        self.watermark_font_size = tk.IntVar(value=34)
        self.watermark_opacity_percent = tk.IntVar(value=34)
        self.title_base = tk.StringVar(value="")
        self.title_font_size = tk.IntVar(value=64)
        self.title_duration_seconds = tk.DoubleVar(value=5.0)
        self.preview_time = tk.DoubleVar(value=1.0)
        self.status = tk.StringVar(value="Ready")
        # Output languages (dubber/languages.py) and their voices; panels exist for ticked ones.
        self.lang_vars = {code: tk.BooleanVar(value=code in ("my", "en")) for code in LANG_TABLE.ORDER}
        self.voice_panels: dict = {}
        self.voice_store: dict = {}
        self.keep_background = tk.BooleanVar(value=True)
        self.background_volume = tk.IntVar(value=100)
        self.drag_choice = tk.StringVar(value="blur1")

        self._build()
        self._load_last()
        root.bind("<FocusIn>", lambda _event: self.refresh_env_status(), add="+")
        self.refresh_env_status()
        self.root.after(100, self.poll)
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def _build(self):
        outer = ttk.Frame(self.root, padding=(10, 8, 10, 8))
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(0, weight=1)
        self.main_pane = ttk.Panedwindow(outer, orient="horizontal")
        self.main_pane.grid(row=0, column=0, sticky="nsew")

        # ---------------- left: settings (scrolls)
        left = ttk.Frame(self.main_pane)
        scroll_canvas = tk.Canvas(left, bg=DARK["bg"], highlightthickness=0, width=600)
        scrollbar = ttk.Scrollbar(left, orient="vertical", command=scroll_canvas.yview)
        scroll_canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        scroll_canvas.pack(side="left", fill="both", expand=True)
        settings = ttk.Frame(scroll_canvas, padding=(0, 0, 10, 0))
        window = scroll_canvas.create_window((0, 0), window=settings, anchor="nw")
        settings.bind("<Configure>", lambda _e: scroll_canvas.configure(scrollregion=scroll_canvas.bbox("all")))
        scroll_canvas.bind("<Configure>", lambda e: scroll_canvas.itemconfigure(window, width=e.width))

        def wheel(event):
            scroll_canvas.yview_scroll(int(-event.delta / 120), "units")
        left.bind("<Enter>", lambda _e: self.root.bind_all("<MouseWheel>", wheel))
        left.bind("<Leave>", lambda _e: self.root.unbind_all("<MouseWheel>"))
        settings.columnconfigure(0, weight=1)
        self.main_pane.add(left, weight=2)

        def section(row, title):
            box = ttk.LabelFrame(settings, text=title, padding=(10, 6))
            box.grid(row=row, column=0, sticky="ew", pady=(0, 8))
            box.columnconfigure(1, weight=1)
            return box

        # 1. Input / output
        paths = section(0, "Input & output")
        ttk.Label(paths, text="Video / Folder").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=3)
        ttk.Entry(paths, textvariable=self.input).grid(row=0, column=1, sticky="ew", pady=3)
        buttons = ttk.Frame(paths)
        buttons.grid(row=0, column=2, padx=(6, 0))
        ttk.Button(buttons, text="File", command=self.choose_video).pack(side="left")
        ttk.Button(buttons, text="Folder", command=self.choose_folder).pack(side="left", padx=(4, 0))
        self._path_row(paths, 1, "Output", self.output, self.choose_output)
        self._path_row(paths, 2, ".env", self.env_file, self.choose_env)
        ttk.Label(paths, text="Source language").grid(row=3, column=0, sticky="w", pady=3)
        ttk.Combobox(paths, textvariable=self.source_language, values=list(LANGS), state="readonly",
                     width=16).grid(row=3, column=1, sticky="w", pady=3)
        ttk.Label(paths, textvariable=self.env_status, style="Muted.TLabel").grid(
            row=4, column=0, columnspan=3, sticky="w", pady=(2, 0))

        # 2. Output languages + their voices
        langs = section(1, "Output languages — one video per ticked language")
        grid = ttk.Frame(langs)
        grid.grid(row=0, column=0, columnspan=3, sticky="ew")
        for index, code in enumerate(LANG_TABLE.ORDER):
            info = LANG_TABLE.get(code)
            ttk.Checkbutton(grid, text=f"{info['label']} · {info['native']}", variable=self.lang_vars[code],
                            command=self._refresh_voice_panels).grid(
                row=index // 3, column=index % 3, sticky="w", padx=(0, 14), pady=1)
        ttk.Label(langs, text="Burmese keeps the exact VoxCPM translation · the others are translated by Gemini",
                  style="Muted.TLabel").grid(row=1, column=0, columnspan=3, sticky="w", pady=(4, 6))
        self.voice_host = ttk.Frame(langs)
        self.voice_host.grid(row=2, column=0, columnspan=3, sticky="ew")
        self.voice_host.columnconfigure(0, weight=1)
        ttk.Label(langs, text="Male/Female split: Gemini listens to every original line (pitch if it cannot)",
                  style="Muted.TLabel").grid(row=3, column=0, columnspan=3, sticky="w", pady=(2, 0))

        # 3. Sound
        sound = section(2, "Sound")
        ttk.Label(sound, text="Voice volume").grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.voice_volume_scale = ttk.Scale(sound, from_=50, to=300, orient="horizontal",
                                            command=lambda v: self._voice_volume_changed(v))
        self.voice_volume_scale.grid(row=0, column=1, sticky="ew")
        self.voice_volume_label = ttk.Label(sound, text="100% (+0.0 dB)", width=14)
        self.voice_volume_label.grid(row=0, column=2, padx=(8, 0))
        self.voice_volume_scale.set(100)
        ttk.Checkbutton(sound, text="Keep background sounds (music, effects) — only the original voices are removed",
                        variable=self.keep_background, command=self._background_toggled).grid(
            row=1, column=0, columnspan=3, sticky="w", pady=(6, 2))
        ttk.Label(sound, text="Background volume").grid(row=2, column=0, sticky="w", padx=(0, 8))
        self.background_scale = ttk.Scale(sound, from_=0, to=200, orient="horizontal",
                                          command=lambda v: self._background_volume_changed(v))
        self.background_scale.grid(row=2, column=1, sticky="ew")
        self.background_label = ttk.Label(sound, text="100%", width=14)
        self.background_label.grid(row=2, column=2, padx=(8, 0))
        self.background_scale.set(100)

        # 4. Video & subtitles
        video = section(3, "Video & subtitles")
        ttk.Checkbutton(video, text="Flip (mirror left ↔ right)", variable=self.mirror,
                        command=self.refresh_preview).grid(row=0, column=0, columnspan=3, sticky="w", pady=2)
        ttk.Checkbutton(video, text="Blur original subtitles (draw Blur 1 / Blur 2 on the preview)",
                        variable=self.blur, command=self._blur_toggled).grid(row=1, column=0, columnspan=3, sticky="w", pady=2)
        sub_row = ttk.Frame(video)
        sub_row.grid(row=2, column=0, columnspan=3, sticky="w", pady=2)
        ttk.Checkbutton(sub_row, text="Own subtitles", variable=self.custom_subtitles,
                        command=self._draw_preview).pack(side="left")
        ttk.Label(sub_row, text="Font size").pack(side="left", padx=(16, 4))
        self.subtitle_size_spin = ttk.Spinbox(sub_row, from_=24, to=140, increment=2, width=6,
                                              textvariable=self.subtitle_font_size, command=self._subtitle_size_changed)
        self.subtitle_size_spin.pack(side="left")
        self.subtitle_size_spin.bind("<Return>", lambda _e: self._subtitle_size_changed())
        self.subtitle_size_spin.bind("<FocusOut>", lambda _e: self._subtitle_size_changed())
        ttk.Label(sub_row, text="px · max 2 lines", style="Muted.TLabel").pack(side="left", padx=(6, 0))

        # 5. Branding
        branding = section(4, "Branding — empty = not shown")
        ttk.Label(branding, text="Logo").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=2)
        ttk.Entry(branding, textvariable=self.logo_path).grid(row=0, column=1, sticky="ew", pady=2)
        ttk.Button(branding, text="Browse", command=self.choose_logo).grid(row=0, column=2, padx=(6, 0), pady=2)
        logo_row = ttk.Frame(branding)
        logo_row.grid(row=1, column=1, columnspan=2, sticky="w", pady=(0, 4))
        ttk.Label(logo_row, text="Size %").pack(side="left")
        ttk.Spinbox(logo_row, from_=2, to=50, width=5, textvariable=self.logo_size_percent,
                    command=self._brand_changed).pack(side="left", padx=(4, 12))
        ttk.Label(logo_row, text="Opacity %").pack(side="left")
        ttk.Spinbox(logo_row, from_=0, to=100, width=5, textvariable=self.logo_opacity_percent,
                    command=self._brand_changed).pack(side="left", padx=(4, 0))

        ttk.Label(branding, text="Watermark").grid(row=2, column=0, sticky="w", padx=(0, 8), pady=2)
        wm_entry = ttk.Entry(branding, textvariable=self.watermark_text)
        wm_entry.grid(row=2, column=1, columnspan=2, sticky="ew", pady=2)
        wm_entry.bind("<KeyRelease>", lambda _e: self._draw_preview())
        wm_row = ttk.Frame(branding)
        wm_row.grid(row=3, column=1, columnspan=2, sticky="w", pady=(0, 4))
        ttk.Label(wm_row, text="Size").pack(side="left")
        ttk.Spinbox(wm_row, from_=12, to=140, width=5, textvariable=self.watermark_font_size,
                    command=self._brand_changed).pack(side="left", padx=(4, 12))
        ttk.Label(wm_row, text="Opacity %").pack(side="left")
        ttk.Spinbox(wm_row, from_=0, to=100, width=5, textvariable=self.watermark_opacity_percent,
                    command=self._brand_changed).pack(side="left", padx=(4, 0))

        ttk.Label(branding, text="Title").grid(row=4, column=0, sticky="w", padx=(0, 8), pady=2)
        title_entry = ttk.Entry(branding, textvariable=self.title_base)
        title_entry.grid(row=4, column=1, columnspan=2, sticky="ew", pady=2)
        title_entry.bind("<KeyRelease>", lambda _e: self._draw_preview())
        title_row = ttk.Frame(branding)
        title_row.grid(row=5, column=1, columnspan=2, sticky="w")
        ttk.Label(title_row, text="Size").pack(side="left")
        ttk.Spinbox(title_row, from_=12, to=180, width=5, textvariable=self.title_font_size,
                    command=self._brand_changed).pack(side="left", padx=(4, 12))
        ttk.Label(title_row, text="Seconds").pack(side="left")
        ttk.Spinbox(title_row, from_=0, to=36000, increment=.5, width=6, textvariable=self.title_duration_seconds,
                    command=self._brand_changed).pack(side="left", padx=(4, 0))
        ttk.Label(branding, text="Folder mode: Title + 1, 2, 3… · 0 sec = whole video · drag them on the preview",
                  style="Muted.TLabel").grid(row=6, column=0, columnspan=3, sticky="w", pady=(4, 0))

        # 6. Delivery
        delivery = section(5, "Delivery")
        ttk.Checkbutton(delivery, variable=self.telegram_auto_send,
                        text="Telegram auto-send — every finished language goes to the group").grid(
            row=0, column=0, columnspan=3, sticky="w")

        # ---------------- right: preview over log
        self.right_pane = ttk.Panedwindow(self.main_pane, orient="vertical")
        self.main_pane.add(self.right_pane, weight=3)
        preview_frame = ttk.LabelFrame(self.right_pane, text="Preview", padding=6)
        log_frame = ttk.LabelFrame(self.right_pane, text="Log", padding=6)
        self.right_pane.add(preview_frame, weight=4)
        self.right_pane.add(log_frame, weight=1)

        tools = ttk.Frame(preview_frame)
        tools.pack(fill="x", pady=(0, 4))
        ttk.Label(tools, text="Drag:").pack(side="left", padx=(0, 4))
        for text, value in (("Blur 1", "blur1"), ("Blur 2", "blur2"), ("Subtitle", "subtitle"),
                            ("Logo", "logo"), ("Watermark", "watermark"), ("Title", "title")):
            ttk.Radiobutton(tools, text=text, value=value, variable=self.drag_choice, style="Toolbutton",
                            command=self._drag_choice_changed).pack(side="left", padx=1)
        ttk.Button(tools, text="Clear blurs", command=self.clear_blur).pack(side="left", padx=(10, 0))
        timeline = ttk.Frame(preview_frame)
        timeline.pack(fill="x", pady=(0, 4))
        ttk.Label(timeline, text="Time").pack(side="left")
        self.time_scale = ttk.Scale(timeline, variable=self.preview_time, from_=0, to=10, orient="horizontal")
        self.time_scale.pack(side="left", fill="x", expand=True, padx=(6, 6))
        self.time_scale.bind("<ButtonRelease-1>", lambda _e: self.refresh_preview())
        ttk.Button(timeline, text="Refresh", command=self.refresh_preview).pack(side="left")

        self.canvas = tk.Canvas(preview_frame, width=640, height=420, bg=DARK["field"], highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<ButtonPress-1>", self.drag_begin)
        self.canvas.bind("<B1-Motion>", self.drag_move)
        self.canvas.bind("<ButtonRelease-1>", self.drag_end)
        self.canvas.bind("<Configure>", lambda _e: self._draw_preview())

        log_scroll = ttk.Scrollbar(log_frame, orient="vertical")
        log_scroll.pack(side="right", fill="y")
        self.log = tk.Text(log_frame, height=8, wrap="word", state="disabled", bg=DARK["field"], fg=DARK["fg"],
                           insertbackground=DARK["fg"], selectbackground=DARK["accent"], selectforeground="#ffffff",
                           relief="flat", padx=7, pady=6, yscrollcommand=log_scroll.set)
        self.log.pack(fill="both", expand=True)
        log_scroll.configure(command=self.log.yview)

        # ---------------- bottom bar (always visible)
        actions = ttk.Frame(outer)
        actions.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        actions.columnconfigure(3, weight=1)
        self.start_btn = ttk.Button(actions, text="▶  Start / Resume", style="Accent.TButton", command=self.start)
        self.start_btn.grid(row=0, column=0)
        self.stop_btn = ttk.Button(actions, text="Stop", command=self.stop, state="disabled")
        self.stop_btn.grid(row=0, column=1, padx=(6, 0))
        ttk.Button(actions, text="Open Output", command=self.open_output).grid(row=0, column=2, padx=(6, 12))
        self.progress = ttk.Progressbar(actions, maximum=100)
        self.progress.grid(row=0, column=3, sticky="ew")
        ttk.Label(actions, textvariable=self.status, width=48, anchor="w").grid(row=0, column=4, padx=(10, 0))

        self._refresh_voice_panels()
        self.root.after(200, self._restore_layout)

    def _refresh_voice_panels(self):
        """One voice panel per ticked language, in the table's order; unticked ones keep their settings."""
        row = 0
        for code in LANG_TABLE.ORDER:
            panel = self.voice_panels.get(code)
            if self.lang_vars[code].get():
                if panel is None:
                    panel = VoicePanel(self.voice_host, code, self)
                    stored = self.voice_store.get(code)
                    if stored is not None:
                        panel.set(stored)
                    self.voice_panels[code] = panel
                panel.grid(row=row, column=0, sticky="ew", pady=(0, 6))
                row += 1
            elif panel is not None:
                panel.grid_remove()

    def _drag_choice_changed(self):
        choice = self.drag_choice.get()
        if choice.startswith("blur"):
            self._select_blur_slot(int(choice[-1]))
        elif choice == "subtitle":
            self._select_subtitle_position()
        else:
            self._select_overlay_position(choice)

    def _background_toggled(self):
        state = "normal" if self.keep_background.get() else "disabled"
        self.background_scale.state(["!disabled"] if state == "normal" else ["disabled"])

    def _background_volume_changed(self, value):
        percent = int(round(float(value) / 5.0) * 5)
        self.background_volume.set(percent)
        self.background_label.configure(text=f"{percent}%")

    def _restore_layout(self, attempt=0):
        self.root.update_idletasks()
        width, height = self.main_pane.winfo_width(), self.right_pane.winfo_height()
        if (width < 400 or height < 300) and attempt < 50:
            # Loading the last video can delay the first paint; place the dividers once the window has its size.
            self.root.after(100, lambda: self._restore_layout(attempt + 1))
            return
        data = {}
        try:
            data = json.loads((ROOT / "ui_layout.json").read_text(encoding="utf-8"))
        except Exception:
            pass
        try:
            main = int(data.get("main", 0) or 0)
            right = int(data.get("right", 0) or 0)
            self.main_pane.sashpos(0, main if 300 <= main <= width - 300 else int(width * 0.43))
            self.right_pane.sashpos(0, right if 200 <= right <= height - 80 else int(height * 0.74))
        except Exception:
            pass

    def _save_layout(self):
        try:
            (ROOT / "ui_layout.json").write_text(json.dumps({
                "main": self.main_pane.sashpos(0), "right": self.right_pane.sashpos(0),
                "geometry": self.root.geometry()}), encoding="utf-8")
        except Exception:
            pass

    def _path_row(self, parent, row, label, var, command):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=3)
        ttk.Entry(parent, textvariable=var).grid(row=row, column=1, sticky="ew", pady=3)
        ttk.Button(parent, text="Browse", command=command).grid(row=row, column=2, padx=(8, 0), pady=3)

    def choose_video(self):
        p = filedialog.askopenfilename(filetypes=[("Video", "*.mp4 *.mkv *.mov *.webm *.avi *.m4v"), ("All", "*.*")])
        if p:
            self.input.set(p)
            self._probe_duration()
            self.refresh_preview()

    def choose_logo(self):
        initial = self.logo_path.get().strip()
        initialdir = str(Path(initial).parent) if initial else str(ROOT)
        p = filedialog.askopenfilename(
            initialdir=initialdir,
            filetypes=[("Logo image", "*.png *.webp *.jpg *.jpeg"), ("All", "*.*")],
        )
        if p:
            self.logo_path.set(p)
            self._draw_preview()

    def choose_folder(self):
        initial = self.input.get().strip()
        initialdir = initial if initial and Path(initial).is_dir() else (str(Path(initial).parent) if initial else str(ROOT))
        p = filedialog.askdirectory(initialdir=initialdir)
        if not p:
            return
        videos = collect_batch_videos(p)
        if not videos:
            messagebox.showerror("Batch Folder", "ဒီ folder ထဲမှာ supported video file မတွေ့ပါ။")
            return
        self.input.set(p)
        self._probe_duration()
        self.refresh_preview()
        preview = ", ".join(v.name for v in videos[:8])
        if len(videos) > 8:
            preview += f", … (+{len(videos)-8})"
        self.status.set(f"Batch folder · {len(videos)} video(s) · natural order: {preview}")

    def _resolved_preview_input(self):
        raw = self.input.get().strip()
        if not raw:
            return None
        p = Path(raw)
        if p.is_file():
            return p
        if p.is_dir():
            videos = collect_batch_videos(p)
            return videos[0] if videos else None
        return None

    def _resolve_run_inputs(self, raw):
        p = Path(raw)
        if p.is_file():
            if p.suffix.casefold() not in VIDEO_EXTENSIONS:
                raise ValueError("Input video format မထောက်ပံ့ပါ။")
            return [p], False
        if p.is_dir():
            videos = collect_batch_videos(p)
            if not videos:
                raise ValueError("ရွေးထားတဲ့ folder ထဲမှာ supported video file မတွေ့ပါ။")
            return videos, True
        raise ValueError("Input video / folder မတွေ့ပါ။")

    def choose_output(self):
        p = filedialog.askdirectory()
        if p: self.output.set(p)

    def choose_env(self):
        initial = Path(self.env_file.get()).parent if self.env_file.get() else ROOT.parent
        p = filedialog.askopenfilename(initialdir=initial, initialfile=".env",
                                       filetypes=[("Environment", "*.env"), ("All", "*.*")])
        if p:
            self.env_file.set(p); self.refresh_env_status()

    def refresh_env_status(self):
        try:
            names = gemini_key_names(self.env_file.get().strip()) if self.env_file.get().strip() else []
            self.env_status.set(f"Gemini FREE rotation: {len(names)} eligible key(s) · aliases only · paid fallback OFF")
        except Exception as exc:
            self.env_status.set(str(exc))

    def _probe_duration(self):
        preview_input = self._resolved_preview_input()
        p = str(preview_input) if preview_input else ""
        ffprobe = shutil.which("ffprobe")
        if not p or not ffprobe:
            return
        try:
            raw = subprocess.check_output([
                ffprobe, "-v", "error", "-select_streams", "v:0",
                "-show_entries", "format=duration:stream=width,height,sample_aspect_ratio,display_aspect_ratio:stream_tags=rotate:stream_side_data=rotation",
                "-of", "json", p
            ], text=True, encoding="utf-8", errors="replace")
            import json
            data = json.loads(raw)
            self.video_duration = max(.1, float(data.get("format", {}).get("duration") or 0.1))
            stream = (data.get("streams") or [{}])[0]
            w, h = int(stream.get("width") or 0), int(stream.get("height") or 0)
            rotation = 0
            for sd in stream.get("side_data_list") or []:
                if "rotation" in sd:
                    try: rotation = int(round(float(sd["rotation"])))
                    except Exception: pass
            if not rotation:
                try: rotation = int(round(float((stream.get("tags") or {}).get("rotate", 0))))
                except Exception: rotation = 0
            if abs(rotation) % 180 == 90:
                w, h = h, w
            self.video_width, self.video_height = w, h
            if w > 0 and h > 0:
                from math import gcd
                g = gcd(w, h)
                self.video_aspect = f"{w//g}:{h//g}"
            else:
                self.video_aspect = str(stream.get("display_aspect_ratio") or "")
            self.time_scale.configure(to=max(.1, self.video_duration - .05))
            self.preview_time.set(min(max(1.0, self.video_duration * .15), self.video_duration - .05))
            if w and h:
                self.status.set(f"Input {w}×{h} · aspect {self.video_aspect} · output keeps source ratio")
        except Exception:
            self.video_duration = 0.0
            self.video_width = self.video_height = 0
            self.video_aspect = ""

    def refresh_preview(self):
        preview_input = self._resolved_preview_input()
        p = str(preview_input) if preview_input else ""
        if not p or not Path(p).is_file():
            return
        try:
            from PIL import Image
        except ImportError:
            messagebox.showerror("Preview", "Pillow မရှိပါ။ pip install Pillow လုပ်ပါ။")
            return
        if self.video_duration <= 0:
            self._probe_duration()
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            messagebox.showerror("Preview", "ffmpeg PATH မှာမတွေ့ပါ။")
            return
        try:
            with tempfile.TemporaryDirectory(prefix="recap_preview_") as d:
                image_path = Path(d) / "preview.png"
                t = min(max(0.0, float(self.preview_time.get())), max(.0, self.video_duration - .05))
                subprocess.run([ffmpeg, "-hide_banner", "-loglevel", "error", "-ss", f"{t:.3f}",
                                "-i", p, "-frames:v", "1", "-an", str(image_path)], check=True)
                image = Image.open(image_path).convert("RGB").copy()
            if self.mirror.get():
                image = image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            self.preview_base = image
            self._draw_preview()
            self.status.set(f"Preview {float(self.preview_time.get()):.1f}s · {image.width}×{image.height} · source aspect kept · Move Subtitle = drag/drop position")
        except Exception as exc:
            messagebox.showerror("Preview", str(exc))

    def _preview_image_with_blur(self):
        if self.preview_base is None:
            return None
        image = self.preview_base.copy()
        if self.blur.get():
            from PIL import ImageFilter
            iw, ih = image.size
            for b in (self.blur_box, self.blur_box2):
                if not b: continue
                x, y, w, h = b
                box = (max(0, round(x*iw)), max(0, round(y*ih)),
                       min(iw, round((x+w)*iw)), min(ih, round((y+h)*ih)))
                if box[2] > box[0] and box[3] > box[1]:
                    region = image.crop(box).filter(ImageFilter.GaussianBlur(radius=14))
                    image.paste(region, box)
        return image

    def _draw_preview(self):
        if self.preview_base is None or self.canvas.winfo_width() < 20:
            return
        from PIL import Image, ImageTk
        image = self._preview_image_with_blur()
        cw, ch = self.canvas.winfo_width(), self.canvas.winfo_height()
        scale = min(cw / image.width, ch / image.height)
        dw, dh = max(1, round(image.width * scale)), max(1, round(image.height * scale))
        shown = image.resize((dw, dh), Image.Resampling.LANCZOS)
        self.preview_photo = ImageTk.PhotoImage(shown)
        x0, y0 = (cw - dw)//2, (ch - dh)//2
        self.preview_bounds = (x0, y0, dw, dh)
        self.canvas.delete("all")
        self.canvas.create_image(x0, y0, anchor="nw", image=self.preview_photo)
        for idx, b in enumerate((self.blur_box, self.blur_box2), 1):
            if not b: continue
            x, y, w, h = b
            self.canvas.create_rectangle(x0+x*dw, y0+y*dh, x0+(x+w)*dw, y0+(y+h)*dh,
                                         outline=("#ffcc00" if idx == 1 else "#4f8cff"), width=2)

        # Subtitle placement preview. Output uses Chromium; this canvas overlay is a
        # lightweight placement/size guide so the user can drag it directly.
        if self.custom_subtitles.get():
            try:
                fs = max(24, min(140, int(self.subtitle_font_size.get())))
            except Exception:
                fs = 64
            display_fs = max(9, int(round(fs * scale)))
            cx = x0 + self.subtitle_x_fraction * dw
            cy = y0 + self.subtitle_y_fraction * dh
            max_text_w = max(80, int(dw * 0.80))
            text_id = self.canvas.create_text(
                cx, cy, text="စာတန်း နမူနာ  •  Subtitle Preview", fill="#ffffff",
                font=(PREVIEW_FONT_FAMILY, display_fs), width=max_text_w, justify="center",
                tags=("subtitle_preview",)
            )
            bbox = self.canvas.bbox(text_id)
            if bbox:
                pad_x = max(8, int(display_fs * .55)); pad_y = max(5, int(display_fs * .28))
                rx0, ry0, rx1, ry1 = bbox[0]-pad_x, bbox[1]-pad_y, bbox[2]+pad_x, bbox[3]+pad_y
                bg = self.canvas.create_rectangle(
                    rx0, ry0, rx1, ry1, fill="#101010", outline="#606060", width=1,
                    tags=("subtitle_preview_bg",)
                )
                self.canvas.tag_lower(bg, text_id)
            # Accent marker makes the selected drop position obvious.
            self.canvas.create_oval(cx-4, cy-4, cx+4, cy+4, fill=DARK["accent2"], outline="", tags=("subtitle_preview",))

        # Branding placement preview. Real output text is rendered by Chromium for Burmese shaping.
        logo_value = self.logo_path.get().strip()
        self.logo_preview_photo = None
        if logo_value and Path(logo_value).is_file():
            try:
                logo = Image.open(logo_value).convert("RGBA")
                pct = max(2, min(50, int(self.logo_size_percent.get()))) / 100.0
                target_w = max(12, int(round(dw * pct)))
                target_h = max(1, int(round(logo.height * target_w / max(1, logo.width))))
                logo = logo.resize((target_w, target_h), Image.Resampling.LANCZOS)
                opacity = max(0, min(100, int(self.logo_opacity_percent.get()))) / 100.0
                if opacity < .999:
                    alpha = logo.getchannel("A").point(lambda a: int(a * opacity))
                    logo.putalpha(alpha)
                self.logo_preview_photo = ImageTk.PhotoImage(logo)
                cx = x0 + self.logo_x_fraction * dw
                cy = y0 + self.logo_y_fraction * dh
                self.canvas.create_image(cx, cy, image=self.logo_preview_photo, tags=("logo_preview",))
                self.canvas.create_rectangle(cx-target_w/2, cy-target_h/2, cx+target_w/2, cy+target_h/2,
                                             outline="#66ddff", width=1, tags=("logo_preview",))
            except Exception:
                pass

        wm = self.watermark_text.get().strip()
        if wm:
            try: wm_fs = max(12, min(140, int(self.watermark_font_size.get())))
            except Exception: wm_fs = 34
            display_fs = max(8, int(round(wm_fs * scale)))
            opacity = max(0, min(100, int(self.watermark_opacity_percent.get()))) / 100.0
            level = max(90, min(255, int(round(90 + 165 * opacity))))
            color = f"#{level:02x}{level:02x}{level:02x}"
            cx = x0 + self.watermark_x_fraction * dw
            cy = y0 + self.watermark_y_fraction * dh
            self.canvas.create_text(cx, cy, text=wm, fill=color,
                                    font=(PREVIEW_FONT_FAMILY, display_fs), justify="center",
                                    tags=("watermark_preview",))

        title = self.title_base.get().strip()
        if title:
            try: title_fs = max(12, min(180, int(self.title_font_size.get())))
            except Exception: title_fs = 64
            display_fs = max(9, int(round(title_fs * scale)))
            cx = x0 + self.title_x_fraction * dw
            cy = y0 + self.title_y_fraction * dh
            tid = self.canvas.create_text(cx, cy, text=title + " 1", fill="#ffffff",
                                          font=(PREVIEW_FONT_FAMILY, display_fs), width=max(100, int(dw*.86)),
                                          justify="center", tags=("title_preview",))
            bbox = self.canvas.bbox(tid)
            if bbox:
                pad_x = max(8, int(display_fs*.45)); pad_y = max(5, int(display_fs*.24))
                bg = self.canvas.create_rectangle(bbox[0]-pad_x, bbox[1]-pad_y, bbox[2]+pad_x, bbox[3]+pad_y,
                                                  fill="#111111", outline="#555555", width=1,
                                                  tags=("title_preview_bg",))
                self.canvas.tag_lower(bg, tid)

    def _clip_canvas_point(self, x, y):
        if not self.preview_bounds:
            return None
        x0, y0, w, h = self.preview_bounds
        return (min(max(x, x0), x0+w), min(max(y, y0), y0+h))

    def _set_overlay_from_canvas(self, kind, x, y):
        if not self.preview_bounds:
            return
        pt = self._clip_canvas_point(x, y)
        if not pt:
            return
        x0, y0, w, h = self.preview_bounds
        xf = max(0.0, min(1.0, (pt[0] - x0) / max(1, w)))
        yf = max(0.0, min(1.0, (pt[1] - y0) / max(1, h)))
        if kind == "subtitle":
            self.subtitle_x_fraction, self.subtitle_y_fraction = xf, yf
        elif kind == "logo":
            self.logo_x_fraction, self.logo_y_fraction = xf, yf
        elif kind == "watermark":
            self.watermark_x_fraction, self.watermark_y_fraction = xf, yf
        elif kind == "title":
            self.title_x_fraction, self.title_y_fraction = xf, yf

    def drag_begin(self, event):
        if self.preview_base is None:
            return
        if self.drag_mode in {"subtitle", "logo", "watermark", "title"}:
            self._set_overlay_from_canvas(self.drag_mode, event.x, event.y)
            self.drag_start = (event.x, event.y)
            self._draw_preview()
            return
        pt = self._clip_canvas_point(event.x, event.y)
        if pt:
            self.drag_start = pt
            self.drag_rect_id = self.canvas.create_rectangle(*pt, *pt, outline="#ffcc00", width=2)

    def drag_move(self, event):
        if self.drag_mode in {"subtitle", "logo", "watermark", "title"} and self.drag_start:
            self._set_overlay_from_canvas(self.drag_mode, event.x, event.y)
            self._draw_preview()
            return
        if not self.drag_start or not self.drag_rect_id:
            return
        pt = self._clip_canvas_point(event.x, event.y)
        if pt:
            self.canvas.coords(self.drag_rect_id, *self.drag_start, *pt)

    def drag_end(self, event):
        if self.drag_mode in {"subtitle", "logo", "watermark", "title"}:
            if self.drag_start:
                kind = self.drag_mode
                self._set_overlay_from_canvas(kind, event.x, event.y)
                self.drag_start = None
                self._draw_preview()
                if kind == "subtitle":
                    self.status.set(f"Subtitle position set · x={self.subtitle_x_fraction:.2f} y={self.subtitle_y_fraction:.2f}")
                else:
                    xf = getattr(self, f"{kind}_x_fraction")
                    yf = getattr(self, f"{kind}_y_fraction")
                    self.status.set(f"{kind.title()} position set · x={xf:.2f} y={yf:.2f}")
            return
        if not self.drag_start or not self.preview_bounds:
            return
        end = self._clip_canvas_point(event.x, event.y)
        x0, y0, w, h = self.preview_bounds
        sx, sy = self.drag_start
        ex, ey = end
        left, top, right, bottom = min(sx, ex), min(sy, ey), max(sx, ex), max(sy, ey)
        self.drag_start = None; self.drag_rect_id = None
        if right-left < 5 or bottom-top < 5:
            self._draw_preview(); return
        box = [(left-x0)/w, (top-y0)/h, (right-left)/w, (bottom-top)/h]
        if self.active_blur_slot == 2:
            self.blur_box2 = box
        else:
            self.blur_box = box
        self.blur.set(True)
        self._draw_preview()
        self.status.set(f"Subtitle blur {self.active_blur_slot} set")

    def _select_blur_slot(self, slot):
        self.drag_choice.set(f"blur{slot}")
        self.active_blur_slot = int(slot)
        self.drag_mode = f"blur{slot}"
        self.blur.set(True)
        self.status.set(f"Draw Blur {slot}: preview ပေါ်မှာ area ကို drag ဆွဲပါ။")

    def _select_subtitle_position(self):
        self.drag_choice.set("subtitle")
        self.drag_mode = "subtitle"
        self.custom_subtitles.set(True)
        self._draw_preview()
        self.status.set("Move Subtitle: preview ပေါ်က စာတန်းကို လိုတဲ့နေရာ drag/drop လုပ်ပါ။")

    def _select_overlay_position(self, kind):
        self.drag_choice.set(str(kind))
        self.drag_mode = str(kind)
        self._draw_preview()
        self.status.set(f"Move {kind.title()}: preview ပေါ်မှာ လိုတဲ့နေရာကို drag/drop လုပ်ပါ။")

    def _brand_changed(self):
        self._draw_preview()

    def _subtitle_size_changed(self):
        try:
            n = int(float(self.subtitle_font_size.get()))
        except Exception:
            n = 64
        self.subtitle_font_size.set(max(24, min(140, n)))
        self._draw_preview()

    def _voice_volume_changed(self, value):
        import math
        percent = int(round(float(value) / 5.0) * 5)  # 5% steps
        self.voice_volume.set(percent)
        db = 20 * math.log10(percent / 100.0)
        self.voice_volume_label.configure(text=f"{percent}% ({db:+.1f} dB)")

    def clear_blur(self):
        self.blur_box = None; self.blur_box2 = None; self.blur.set(False); self._draw_preview()

    def _blur_toggled(self):
        if self.blur.get() and not self.blur_box:
            self.status.set("Preview ပေါ်မှာ original subtitle နေရာကို drag ဆွဲပါ။")
        self._draw_preview()

    def config(self):
        for code, panel in self.voice_panels.items():
            self.voice_store[code] = panel.read()
        chosen = [code for code in LANG_TABLE.ORDER if self.lang_vars[code].get()]
        defaults = Config()
        cfg = Config(
            input=self.input.get().strip(),
            output=self.output.get().strip() or str(ROOT / "outputs"),
            source_language=LANGS[self.source_language.get()],
            my=self.voice_store.get("my") or defaults.my, en=self.voice_store.get("en") or defaults.en,
            voices={code: vc for code, vc in self.voice_store.items() if code not in ("my", "en")},
            output_langs=chosen,
            keep_background=bool(self.keep_background.get()),
            background_volume_percent=int(self.background_volume.get()),
            env_file=self.env_file.get().strip(),
            env_key="",
            mirror_video=self.mirror.get(),
            voice_volume_percent=int(self.voice_volume.get()),
            blur_original_subtitles=self.blur.get(),
            blur_box=list(self.blur_box) if self.blur_box else None,
            blur_box2=list(self.blur_box2) if self.blur_box2 else None,
            burn_custom_subtitles=self.custom_subtitles.get(),
            subtitle_font_size=int(self.subtitle_font_size.get()),
            subtitle_x_fraction=float(self.subtitle_x_fraction),
            subtitle_y_fraction=float(self.subtitle_y_fraction),
            subtitle_width_fraction=0.90,
            logo_path=self.logo_path.get().strip(),
            logo_size_fraction=max(2, min(50, int(self.logo_size_percent.get()))) / 100.0,
            logo_opacity=max(0, min(100, int(self.logo_opacity_percent.get()))) / 100.0,
            logo_x_fraction=float(self.logo_x_fraction), logo_y_fraction=float(self.logo_y_fraction),
            watermark_text=self.watermark_text.get().strip(),
            watermark_font_size=int(self.watermark_font_size.get()),
            watermark_opacity=max(0, min(100, int(self.watermark_opacity_percent.get()))) / 100.0,
            watermark_x_fraction=float(self.watermark_x_fraction), watermark_y_fraction=float(self.watermark_y_fraction),
            title_base=self.title_base.get().strip(), title_index=0,
            title_font_size=int(self.title_font_size.get()),
            title_duration_seconds=float(self.title_duration_seconds.get()),
            title_x_fraction=float(self.title_x_fraction), title_y_fraction=float(self.title_y_fraction),
            telegram_auto_send=bool(self.telegram_auto_send.get()),
            # Final integrated DUB defaults:
            quality="balanced", device="cuda", whisper_model="medium",
            whisper_compute_type="int8_float16", whisper_chunk_minutes=10.0,
            translation_batch_max_items=40, translation_batch_max_chars=16000,
            story_context_enabled=True, story_context_batch_max_items=80,
            edge_tts_workers=4, gemini_tts_workers=1, voxcpm_tts_workers=1,
            subtitles=False, resume=True,
        )
        return cfg

    def apply_config(self, cfg):
        self.input.set(cfg.input); self.output.set(cfg.output)
        self.env_file.set(cfg.env_file or find_default_env(ROOT))
        self.source_language.set(next((k for k,v in LANGS.items() if v == cfg.source_language), "Chinese"))
        self.mirror.set(bool(cfg.mirror_video)); self.blur.set(bool(cfg.blur_original_subtitles))
        self.voice_volume_scale.set(int(getattr(cfg, "voice_volume_percent", 100) or 100))
        self.keep_background.set(bool(getattr(cfg, "keep_background", True)))
        self.background_scale.set(int(getattr(cfg, "background_volume_percent", 100)))
        self._background_toggled()
        self.custom_subtitles.set(bool(getattr(cfg, "burn_custom_subtitles", True)))
        self.telegram_auto_send.set(bool(getattr(cfg, "telegram_auto_send", False)))
        self.subtitle_font_size.set(int(getattr(cfg, "subtitle_font_size", 64)))
        self.subtitle_x_fraction = float(getattr(cfg, "subtitle_x_fraction", 0.50))
        self.subtitle_y_fraction = float(getattr(cfg, "subtitle_y_fraction", 0.82))
        self.logo_path.set(str(getattr(cfg, "logo_path", "") or ""))
        self.logo_size_percent.set(int(round(float(getattr(cfg, "logo_size_fraction", .12)) * 100)))
        self.logo_opacity_percent.set(int(round(float(getattr(cfg, "logo_opacity", 1.0)) * 100)))
        self.logo_x_fraction = float(getattr(cfg, "logo_x_fraction", .90)); self.logo_y_fraction = float(getattr(cfg, "logo_y_fraction", .10))
        self.watermark_text.set(str(getattr(cfg, "watermark_text", "") or ""))
        self.watermark_font_size.set(int(getattr(cfg, "watermark_font_size", 34)))
        self.watermark_opacity_percent.set(int(round(float(getattr(cfg, "watermark_opacity", .34)) * 100)))
        self.watermark_x_fraction = float(getattr(cfg, "watermark_x_fraction", .86)); self.watermark_y_fraction = float(getattr(cfg, "watermark_y_fraction", .92))
        self.title_base.set(str(getattr(cfg, "title_base", "") or ""))
        self.title_font_size.set(int(getattr(cfg, "title_font_size", 64)))
        self.title_duration_seconds.set(float(getattr(cfg, "title_duration_seconds", 5.0)))
        self.title_x_fraction = float(getattr(cfg, "title_x_fraction", .50)); self.title_y_fraction = float(getattr(cfg, "title_y_fraction", .12))
        self.blur_box = list(cfg.blur_box) if cfg.blur_box else None
        self.blur_box2 = list(cfg.blur_box2) if getattr(cfg, "blur_box2", None) else None
        chosen = set(cfg.output_languages())
        self.voice_store = {"my": cfg.my, "en": cfg.en, **dict(getattr(cfg, "voices", {}) or {})}
        for code in LANG_TABLE.ORDER:
            self.lang_vars[code].set(code in chosen)
            if code in self.voice_panels:
                self.voice_panels[code].set(cfg.voice(code))
        self._refresh_voice_panels()
        self.refresh_env_status()
        if self.input.get() and (Path(self.input.get()).is_file() or Path(self.input.get()).is_dir()):
            self._probe_duration(); self.refresh_preview()

    def _load_last(self):
        path = ROOT / "last_config.json"
        if path.is_file():
            try:
                self.apply_config(Config.load(path))
            except Exception:
                pass

    def start(self):
        if self.running:
            return
        try:
            base_cfg = self.config()
            inputs, is_batch = self._resolve_run_inputs(base_cfg.input)

            # Validate all non-input settings using the first real video.
            probe_cfg = replace(base_cfg, input=str(inputs[0]))
            probe_cfg.validate()

            # Keep the selected folder/file itself in last_config.json.
            base_cfg.save(ROOT / "last_config.json")
        except Exception as exc:
            messagebox.showerror("Settings", str(exc)); return

        self.running = True
        self.control = Control(log=lambda text: self.events.put(("log", text)))
        self.start_btn.configure(state="disabled"); self.stop_btn.configure(state="normal")
        self.progress["value"] = 0
        self.status.set("Batch running…" if is_batch else "Running…")
        self.append_log("Start / Resume — stable VoxCPM sync + batch + darker readable subtitles + optional branding + Telegram")

        if is_batch:
            self.append_log(f"BATCH: {len(inputs)} video(s) · sequential natural filename order")
            self.append_log("BATCH ORDER: " + " → ".join(p.name for p in inputs))

        def work():
            reports = []
            failures = []
            total = len(inputs)
            try:
                for index, video in enumerate(inputs, 1):
                    self.control.check()
                    cfg = replace(base_cfg, input=str(video), title_index=(index if is_batch and base_cfg.title_base.strip() else 0))
                    prefix = f"[BATCH {index}/{total}] " if is_batch else ""
                    self.events.put(("log", f"{prefix}START → {video.name}"))

                    def mapped_progress(n, label, idx=index):
                        if is_batch:
                            overall = ((idx - 1) + max(0.0, min(100.0, float(n))) / 100.0) / total * 100.0
                            text = f"[{idx}/{total}] {video.name} · {label}"
                            self.events.put(("progress", (overall, text)))
                        else:
                            self.events.put(("progress", (n, label)))

                    try:
                        report = Pipeline(cfg, self.control, mapped_progress).run()
                        reports.append({"file": str(video), "status": "complete", "report": report})
                        self.events.put(("log", f"{prefix}COMPLETE ✅ → {video.name}"))
                    except Cancelled:
                        raise
                    except Exception as exc:
                        failures.append({"file": str(video), "error": str(exc)})
                        reports.append({"file": str(video), "status": "failed", "error": str(exc)})
                        self.events.put(("log", f"{prefix}FAILED ⚠️ → {video.name} · {exc}"))
                        # Folder mode intentionally continues with the next file.
                        if not is_batch:
                            raise

                self.events.put(("done", {
                    "batch": is_batch,
                    "total": total,
                    "ok": total - len(failures),
                    "failed": failures,
                    "reports": reports,
                }))
            except Cancelled as exc:
                self.events.put(("stopped", str(exc)))
            except Exception as exc:
                self.events.put(("failed", str(exc)))

        threading.Thread(target=work, daemon=True).start()

    def stop(self):
        if self.running:
            self.control.event.set(); self.status.set("Stopping safely… cached work stays resumable")

    def poll(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "log": self.append_log(value)
                elif kind == "progress":
                    n, text = value; self.progress["value"] = n; self.status.set(text)
                elif kind == "voices":
                    panel, voices = value
                    panel.voice_box.configure(values=voices, state="readonly" if voices else "normal")
                    if voices: panel.voice.set(voices[0])
                    panel._set_female_choices(voices, panel.female_voice.get() if panel.female_voice.get() in voices else "", False, editable=not voices)
                    panel._split_changed()
                    self.append_log(f"VoxCPM voices loaded: {len(voices)}")
                elif kind == "error": messagebox.showerror("Error", value)
                elif kind == "done":
                    self.running = False; self.progress["value"] = 100
                    if isinstance(value, dict) and value.get("batch"):
                        total = int(value.get("total", 0))
                        ok = int(value.get("ok", 0))
                        failed = list(value.get("failed") or [])
                        self.status.set(f"Batch complete — {ok}/{total} file(s) OK")
                        self.append_log(f"BATCH DONE ✅ · OK={ok}/{total} · FAILED={len(failed)}")
                        for item in failed:
                            self.append_log(f"BATCH FAILED: {Path(item['file']).name} · {item['error']}")
                    else:
                        self.status.set("Complete — " + " + ".join(
                            LANG_TABLE.label(c) for c in LANG_TABLE.ORDER if self.lang_vars[c].get()))
                        self.append_log("DONE")
                    self.start_btn.configure(state="normal"); self.stop_btn.configure(state="disabled")
                elif kind in ("failed", "stopped"):
                    self.running = False; self.status.set(value); self.append_log(value)
                    self.start_btn.configure(state="normal"); self.stop_btn.configure(state="disabled")
        except queue.Empty:
            pass
        self.root.after(100, self.poll)

    def append_log(self, text):
        self.log.configure(state="normal")
        self.log.insert("end", f"[{time.strftime('%H:%M:%S')}] {text}\n")
        self.log.see("end"); self.log.configure(state="disabled")

    def open_output(self):
        path = Path(self.output.get().strip() or ROOT / "outputs")
        path.mkdir(parents=True, exist_ok=True)
        try:
            if os.name == "nt": os.startfile(path)
            else: subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc: messagebox.showerror("Output", str(exc))

    def close(self):
        if self.running:
            self.control.event.set(); self.status.set("Stopping…")
            self.root.after(250, self.close)
        else:
            self._save_layout()
            self.root.destroy()


def launch():
    root = tk.Tk()
    apply_dark_theme(root)
    App(root)
    root.mainloop()
