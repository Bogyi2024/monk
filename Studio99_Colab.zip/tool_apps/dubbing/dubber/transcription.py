from __future__ import annotations

import re
import sys
import os
import queue
import subprocess
import shutil
import threading
import time
from pathlib import Path


def _parse_time(value: str) -> float:
    hh, mm, rest = value.strip().replace('.', ',').split(':')
    ss, ms = rest.split(',')
    return int(hh) * 3600 + int(mm) * 60 + int(ss) + int(ms[:3].ljust(3, '0')) / 1000.0


def _parse_srt(path: Path):
    text = path.read_text(encoding='utf-8-sig', errors='replace').strip()
    if not text:
        return []
    segments = []
    blocks = re.split(r'\r?\n\s*\r?\n', text)
    for block in blocks:
        lines = [x.rstrip() for x in block.splitlines()]
        if len(lines) < 3 or '-->' not in lines[1]:
            continue
        left, right = [x.strip() for x in lines[1].split('-->', 1)]
        start, end = _parse_time(left), _parse_time(right)
        content = ' '.join(x.strip() for x in lines[2:] if x.strip()).strip()
        if content and end > start:
            segments.append({'id': f's{len(segments)+1:06d}', 'start': start, 'end': end,
                             'text': content})
    return segments


def _sanitize_to_media_bounds(segments, duration, log=None):
    """Clamp harmless Whisper tail overshoot to the real media duration.

    faster-whisper/repair windows can occasionally emit a final timestamp a little
    beyond the source duration.  The dubbed renderer must never address frames
    past EOF, so keep in-range speech, clamp only the tail, and discard segments
    that begin at/after EOF.
    """
    duration = max(0.0, float(duration))
    cleaned = []
    for raw in segments:
        seg = dict(raw)
        start = max(0.0, float(seg['start']))
        end = float(seg['end'])
        if start >= duration:
            if log:
                log(f"Whisper EOF cleanup: drop {seg['id']} start={start:.3f}s >= media={duration:.3f}s")
            continue
        if end > duration:
            if log:
                log(f"Whisper EOF cleanup: clamp {seg['id']} end {end:.3f}s -> {duration:.3f}s")
            end = duration
        if end <= start + 0.001:
            if log:
                log(f"Whisper EOF cleanup: drop zero-length {seg['id']} ({start:.3f}-{end:.3f}s)")
            continue
        seg['start'] = start
        seg['end'] = end
        cleaned.append(seg)
    return cleaned


def _validate(segments, duration):
    prev = -1.0
    for seg in segments:
        if seg['start'] < 0 or seg['end'] <= seg['start'] or seg['end'] > duration + 0.050:
            raise ValueError(
                f"Whisper timestamp မမှန်ပါ: {seg['id']} "
                f"({seg['start']:.3f}-{seg['end']:.3f}s, media={duration:.3f}s)"
            )
        if seg['start'] + .05 < prev:
            raise ValueError(
                f"Whisper segment order မမှန်ပါ: {seg['id']} "
                f"(start={seg['start']:.3f}s, previous={prev:.3f}s)"
            )
        prev = seg['start']



def _run_legacy_streaming(argv, control, progress):
    """Run the proven legacy Whisper engine while keeping the UI responsive."""
    creationflags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    child_env = os.environ.copy()
    # Windows redirected stdout may otherwise default to cp1252.
    # Whisper diagnostics can contain Chinese/Burmese text, so force UTF-8.
    child_env['PYTHONUTF8'] = '1'
    child_env['PYTHONIOENCODING'] = 'utf-8'
    proc = subprocess.Popen([str(x) for x in argv], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            stdin=subprocess.DEVNULL, text=True, encoding='utf-8', errors='replace',
                            bufsize=1, creationflags=creationflags, env=child_env)
    lines = queue.Queue()
    def reader():
        try:
            for line in proc.stdout:
                lines.put(line.rstrip())
        finally:
            lines.put(None)
    threading.Thread(target=reader, daemon=True).start()
    started = time.monotonic()
    try:
        reader_done = False
        while proc.poll() is None or not reader_done:
            control.check()
            if time.monotonic() - started > 24 * 3600:
                raise TimeoutError('Whisper V3.1 timed out')
            try:
                item = lines.get(timeout=.1)
            except queue.Empty:
                continue
            if item is None:
                reader_done = True
                continue
            if item.strip():
                control.log(item)
                m = re.search(r'--- Chunk (\d+)/(\d+)', item)
                if m:
                    n, total = map(int, m.groups())
                    progress(5 + 20 * (n-1) / max(1, total), f'Whisper chunk {n}/{total}')
        code = proc.wait()
        if code:
            raise RuntimeError(f'Whisper V3.1 failed with exit code {code}')
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill(); proc.wait()


def transcribe(cfg, cache, control, media, duration, source_hash, progress):
    """Use the user's proven Manju Whisper V3.1 engine, not a reimplemented ASR path."""
    if cfg.dry_run:
        points = [(duration * .08, duration * .36), (duration * .53, duration * .86)]
        return {'language': 'en', 'synthetic': True, 'engine': 'dry_run', 'segments': [
            {'id': f's{i:06d}', 'start': a, 'end': b, 'text': f'Offline sample segment {i}.'}
            for i, (a, b) in enumerate(points, 1)]}

    key = {
        'v': 31, 'source': source_hash, 'engine': 'manju_whisper_v3_1_natural_sort_vad2',
        'model': cfg.whisper_model, 'device': cfg.device,
        'compute_type': cfg.whisper_compute_type, 'language': cfg.source_language,
        'chunk_minutes': cfg.whisper_chunk_minutes,
    }
    cached = cache.get('legacy_transcript', key)
    if cached is not None:
        control.log(f"Whisper resume cache: {len(cached['segments'])} segments")
        progress(25, f"Whisper cache: {len(cached['segments'])} segments")
        return cached

    script = Path(__file__).resolve().parent.parent / 'legacy' / 'manju_whisper_transcribe_v3.1_natural_sort_vad2.py'
    if not script.is_file():
        raise RuntimeError('Legacy Whisper V3.1 engine file missing')

    source = Path(cfg.input).resolve()
    job_dir = cache.root.parent
    whisper_dir = job_dir / 'whisper_v3_1'
    # One-time adoption of the old source-side V3.1 cache. This lets an existing
    # Desktop run resume, but every NEW file/cache from this version stays in the job folder.
    legacy_source_dir = source.parent / 'transcript_output_v3_1'
    if not whisper_dir.exists() and legacy_source_dir.is_dir():
        try:
            control.log(f"Whisper cache migration: {legacy_source_dir} → {whisper_dir}")
            shutil.copytree(legacy_source_dir, whisper_dir, dirs_exist_ok=True)
        except OSError as exc:
            control.log(f"Whisper cache migration skipped: {exc}")

    device = 'cuda' if cfg.device in ('auto', 'cuda') else 'cpu'
    argv = [sys.executable, script, cfg.input,
            '--model', cfg.whisper_model,
            '--device', device,
            '--compute-type', cfg.whisper_compute_type,
            '--beam-size', '5',
            '--chunk-minutes', str(cfg.whisper_chunk_minutes),
            '--output-dir', str(whisper_dir)]
    if cfg.source_language != 'auto':
        argv += ['--language', cfg.source_language]

    control.log(
        f"Whisper V3.1: model={cfg.whisper_model} · device={device} · "
        f"compute={cfg.whisper_compute_type} · chunk={cfg.whisper_chunk_minutes:g}min")
    control.log(f'Whisper V3.1 workspace: {whisper_dir}')
    control.log('Existing V3.1 chunk cache will be reused/migrated automatically when available.')
    progress(5, 'Whisper V3.1 transcription / resume')
    _run_legacy_streaming(argv, control, progress)

    srt = whisper_dir / f'{source.stem}.srt'
    if not srt.is_file():
        raise RuntimeError(f'Whisper completed but SRT not found: {srt}')
    segments = _parse_srt(srt)
    segments = _sanitize_to_media_bounds(segments, duration, log=control.log)
    _validate(segments, duration)
    result = {
        'language': cfg.source_language if cfg.source_language != 'auto' else 'auto',
        'engine': 'manju_whisper_transcribe_v3.1_natural_sort_vad2.py',
        'model': cfg.whisper_model, 'device': device,
        'compute_type': cfg.whisper_compute_type,
        'source_srt': str(srt), 'segments': segments,
    }
    control.log(f"Whisper V3.1 ready: {len(segments)} segments")
    progress(25, f"Whisper: {len(segments)} segments")
    return cache.put('legacy_transcript', key, result)
