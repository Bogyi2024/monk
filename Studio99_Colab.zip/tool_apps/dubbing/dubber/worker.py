"""Isolated optional providers: parent can cancel model loads and network waits."""
from __future__ import annotations

import asyncio
import base64
import json
import os
from pathlib import Path
import re
import shutil
import sys
import wave

_CUDA_DLL_HANDLES = []


def safe_local_error(exc):
    """Keep useful local CUDA diagnostics while excluding multiline/path noise."""
    message = " ".join(str(exc).split())
    message = re.sub(r"[A-Za-z]:[\\/][^ ]+", "<local-path>", message)
    return f"{type(exc).__name__}: {message}"[:300]


def configure_cuda_dll_paths():
    """Discover CUDA/cuDNN installed after the parent UI process was started."""
    if os.name != "nt":
        return []
    candidates = []
    def extend_glob(root, pattern):
        try:
            candidates.extend(list(root.glob(pattern)))
        except OSError:
            pass
    for name in ("CUDA_PATH", "CUDA_HOME"):
        if os.getenv(name):
            candidates.append(Path(os.environ[name]) / "bin")
    program_files = Path(os.getenv("ProgramFiles", r"C:\Program Files"))
    cuda_root = program_files / "NVIDIA GPU Computing Toolkit" / "CUDA"
    try:
        candidates.extend(sorted(cuda_root.glob("v12*/bin"), reverse=True))
    except OSError:
        pass
    cudnn_root = program_files / "NVIDIA" / "CUDNN"
    try:
        if cudnn_root.is_dir():
            candidates.extend(path.parent for path in cudnn_root.rglob("cudnn64_9.dll"))
    except OSError:
        pass
    # A regular Python + CUDA-enabled PyTorch install already carries compatible
    # CUDA runtime DLLs.  The desktop launcher may run from an isolated venv, so
    # discover the user's other Python installations instead of assuming that
    # the venv and the shell use the same interpreter.
    local_python = Path(os.getenv("LOCALAPPDATA", "")) / "Programs" / "Python"
    extend_glob(local_python, "Python*/Lib/site-packages/torch/lib")
    roaming_python = Path(os.getenv("APPDATA", "")) / "Python"
    extend_glob(roaming_python, "Python*/site-packages/torch/lib")
    site_packages = Path(sys.prefix) / "Lib" / "site-packages" / "nvidia"
    extend_glob(site_packages, "*/bin")
    added = []
    for path in candidates:
        try:
            path = path.resolve()
            if not path.is_dir() or str(path).lower() in {x.lower() for x in added}:
                continue
            _CUDA_DLL_HANDLES.append(os.add_dll_directory(str(path)))
            added.append(str(path))
        except (OSError, AttributeError):
            continue
    if added:
        os.environ["PATH"] = os.pathsep.join(added + [os.environ.get("PATH", "")])
    return added


def gpu_check():
    paths = configure_cuda_dll_paths()
    import ctranslate2
    count = ctranslate2.get_cuda_device_count()
    if not count:
        return {"ready": False, "device_count": 0,
                "reason": "NVIDIA CUDA device was not detected"}
    if os.name == "nt":
        import ctypes
        missing = []
        for library in ("cublas64_12.dll", "cudnn64_9.dll"):
            try:
                handle = ctypes.WinDLL(library)
                del handle
            except OSError:
                missing.append(library)
        if missing:
            suffix = (f"; searched {len(paths)} discovered CUDA/cuDNN bin folder(s)"
                      if paths else "; no CUDA 12 bin folder was discovered")
            return {"ready": False, "device_count": count,
                    "reason": "CUDA 12/cuDNN 9 runtime missing: " + ", ".join(missing) + suffix,
                    "dll_paths": paths}
    return {"ready": True, "device_count": count,
            "reason": "CUDA device and cuBLAS runtime detected", "dll_paths": paths}


def gemini_client(timeout):
    from google import genai
    from google.genai import types
    key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not key:
        raise ValueError("GEMINI_API_KEY is missing")
    return genai.Client(api_key=key, http_options=types.HttpOptions(timeout=timeout * 1000))


def gradio_client(request):
    from gradio_client import Client
    return Client(request["voice"]["api_url"], verbose=False,
                  download_files=request["download_dir"],
                  httpx_kwargs={"timeout": min(60, request["timeout"])})


def normalize_voices(value):
    if isinstance(value, str):
        try:
            return normalize_voices(json.loads(value))
        except ValueError:
            return [value] if value.strip() else []
    if isinstance(value, dict):
        if "choices" in value:
            return normalize_voices(value["choices"])
        if "voices" in value:
            return normalize_voices(value["voices"])
        return list(value)
    if isinstance(value, (list, tuple)):
        return list(dict.fromkeys(str(v[-1] if isinstance(v, (list, tuple)) else v)
                                 for v in value if v))
    return []


def find_audio(value):
    if isinstance(value, (str, Path)):
        p = Path(value)
        if p.is_file() and p.suffix.lower() in (".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac"):
            return p
    if isinstance(value, dict):
        for name in ("path", "name", "audio", "value"):
            if name in value:
                result = find_audio(value[name])
                if result:
                    return result
    if isinstance(value, (tuple, list)):
        for item in value:
            result = find_audio(item)
            if result:
                return result
    return None


def transcribe(r):
    configure_cuda_dll_paths()
    from faster_whisper import WhisperModel
    import ctranslate2
    device = r["device"]
    if device == "auto":
        device = "cuda" if ctranslate2.get_cuda_device_count() else "cpu"
    fallback = False
    fallback_reason = ""
    for trial in range(2):
        try:
            model = WhisperModel(r["model"], device=device,
                                 compute_type="int8_float16" if device == "cuda" else "int8",
                                 download_root=r["model_dir"])
            stream, info = model.transcribe(r["audio"], language=r["language"],
                                           word_timestamps=True, vad_filter=True, beam_size=5,
                                           condition_on_previous_text=True)
            segments = []
            for s in stream:
                if s.text.strip():
                    words = [{"start": w.start, "end": w.end, "text": w.word}
                             for w in (s.words or []) if w.word.strip()]
                    # Never invent word timestamps for a nonempty untimed result.
                    if not words:
                        raise ValueError("ASR returned text without word timestamps")
                    segments.append({"start": s.start, "end": s.end,
                                     "text": s.text, "words": words})
            return {"segments": segments, "language": info.language,
                    "device": device, "cpu_fallback": fallback,
                    "gpu_fallback_reason": fallback_reason}
        except (RuntimeError, OSError) as exc:
            if device == "cpu" or trial:
                raise
            fallback_reason = safe_local_error(exc)
            device, fallback = "cpu", True


def translate(r):
    from google.genai import types
    with gemini_client(r["timeout"]) as client:
        result = client.models.generate_content(
            model=r["model"], contents=r["prompt"],
            config=types.GenerateContentConfig(response_mime_type="application/json"))
        if not result.text:
            raise ValueError("Translation response is empty")
        return json.loads(result.text)


def audio_json(r):
    """Gemini listens to an audio file and answers in JSON (male/female voice per line)."""
    from google.genai import types
    data = Path(r["audio"]).read_bytes()
    with gemini_client(r["timeout"]) as client:
        result = client.models.generate_content(
            model=r["model"],
            contents=[types.Part.from_bytes(data=data, mime_type=r.get("mime_type") or "audio/mp3"), r["prompt"]],
            config=types.GenerateContentConfig(response_mime_type="application/json"))
        if not result.text:
            raise ValueError("Audio answer is empty")
        return json.loads(result.text)


def tts(r):
    voice, output = r["voice"], Path(r["output"])
    if voice["provider"] == "edge":
        import edge_tts
        async def save():
            fixed_rate = int(voice.get("rate_percent", 35))
            await edge_tts.Communicate(
                r["text"], voice["voice"], rate=f"{fixed_rate:+d}%"
            ).save(str(output))
        asyncio.run(save())
    elif voice["provider"] == "voxcpm":
        if str(voice.get("api_url") or "").startswith("local://voxcpm2"):
            app_dir = Path(__file__).resolve().parents[3] / "app"
            if str(app_dir) not in sys.path:
                sys.path.insert(0, str(app_dir))
            ref_audio = str(voice.get("api_url") or "")[len("local://voxcpm2"):].lstrip("|").strip()
            voice_name = str(voice.get("voice") or "voxcpm2:male_narrator").strip()
            if voice_name.lower().startswith("voxcpm2_gguf:"):
                import local_tts_engines
                local_tts_engines.synthesize_voxcpm2_gguf(
                    r["text"],
                    voice_name,
                    output,
                    ref_audio=ref_audio,
                    design=str(voice.get("style") or ""),
                    work_dir=output.parent,
                )
            else:
                import voxcpm2_local
                voxcpm2_local.synthesize(
                    r["text"],
                    voice_name,
                    output,
                    ref_audio=ref_audio,
                    design=str(voice.get("style") or ""),
                    work_dir=output.parent,
                )
            return {"output": str(output)}
        client = gradio_client(r)
        job = client.submit(r["text"], voice["voice"], api_name=voice["api_name"])
        try:
            result = job.result(timeout=r["timeout"])
        except BaseException:
            job.cancel()
            raise
        source = find_audio(result)
        if not source:
            raise ValueError("VoxCPM did not return a downloaded audio file")
        shutil.copyfile(source, output)
    else:
        from google.genai import types
        with gemini_client(r["timeout"]) as client:
            result = client.models.generate_content(
                model=voice["model"],
                contents=f"Read exactly the text below in "
                         f"{r.get('language_name') or ('Burmese' if r['language'] == 'my' else 'English')}. "
                         "Keep one steady narrator pace across every segment in this video; do not speed up or slow down "
                         f"to fit a time window. Do not add, translate or omit words. {voice['style']}\nTEXT:\n{r['text']}",
                config=types.GenerateContentConfig(
                    response_modalities=["AUDIO"],
                    speech_config=types.SpeechConfig(voice_config=types.VoiceConfig(
                        prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name=voice["voice"])))))
            chunks, rate = [], None
            for candidate in (result.candidates or [])[:1]:
                for part in (candidate.content.parts or []):
                    inline = part.inline_data
                    if not inline or not inline.data:
                        continue
                    mime = inline.mime_type or ""
                    if not ("L16" in mime or "pcm" in mime.lower()):
                        raise ValueError("Unexpected Gemini audio format")
                    match = re.search(r"rate=(\d+)", mime)
                    current = int(match.group(1)) if match else 24000
                    if rate and rate != current:
                        raise ValueError("Gemini audio sample rate changed")
                    rate = current
                    data = inline.data
                    if isinstance(data, str):
                        data = base64.b64decode(data)
                    chunks.append(bytes(data))
            pcm = b"".join(chunks)
            if not pcm or len(pcm) % 2:
                raise ValueError("Gemini returned empty/invalid PCM audio")
            with wave.open(str(output), "wb") as f:
                f.setnchannels(1)
                f.setsampwidth(2)
                f.setframerate(rate)
                f.writeframes(pcm)
    return {"output": str(output)}


def dispatch(r):
    if r["action"] == "asr":
        return transcribe(r)
    if r["action"] == "gpu_check":
        return gpu_check()
    if r["action"] == "translate":
        return translate(r)
    if r["action"] == "audio_json":
        return audio_json(r)
    if r["action"] == "tts":
        return tts(r)
    if r["action"] == "voices":
        if r["voice"]["provider"] == "edge":
            import edge_tts
            return [x["ShortName"] for x in asyncio.run(edge_tts.list_voices())
                    if x["Locale"].startswith(r["language"] + "-")]
        client = gradio_client(r)
        return normalize_voices(client.submit(api_name=r["voice"]["voices_api"]).result(timeout=r["timeout"]))
    raise ValueError("Unknown worker action")


def classify_error(exc, action):
    """Return a credential-free error record used for retries and UI diagnostics."""
    error_type = type(exc).__name__
    raw = f"{error_type} {exc}".lower()
    status = None
    for attribute in ("status_code", "code"):
        value = getattr(exc, attribute, None)
        if callable(value):
            try:
                value = value()
            except Exception:
                value = None
        value = getattr(value, "value", value)
        try:
            number = int(value)
        except (TypeError, ValueError):
            continue
        if 100 <= number <= 599:
            status = number
            break
    if status is None:
        match = re.search(r"(?<!\d)(400|401|403|404|408|409|429|500|502|503|504)(?!\d)", raw)
        status = int(match.group(1)) if match else None
    if isinstance(exc, ModuleNotFoundError):
        return {"type": error_type, "category": "dependency",
                "message": f"missing package: {exc.name}", "retryable": False,
                "rotate_key": False}
    # Model/tier availability errors are not bad keys. Skip only this model and preserve the key pool.
    model_markers = (
        "model not found", "model is not found", "unknown model", "unsupported model",
        "model is not supported", "not supported for generatecontent", "not available for this",
        "is not available", "model does not exist", "models/"
    )
    if status in (400, 404) and any(word in raw for word in model_markers):
        return {"type": error_type, "category": "model_unavailable", "status": status,
                "message": "Gemini model is unavailable/unsupported for this account or API",
                "retryable": False, "rotate_key": False}
    if status == 403 and any(word in raw for word in (
            "model", "not available", "not supported", "permission denied on resource")):
        return {"type": error_type, "category": "model_unavailable", "status": status,
                "message": "Gemini model is unavailable for this account/tier",
                "retryable": False, "rotate_key": False}
    if status in (401, 403) or any(word in raw for word in (
            "unauthenticated", "permissiondenied", "permission denied", "api key not valid",
            "invalid api key")):
        return {"type": error_type, "category": "auth", "message": "API key was rejected",
                "retryable": False, "rotate_key": True}
    # Gemini 429 can mean either a per-day project/model quota (rotate key)
    # or a short RPM/TPM throttle (wait and keep the key). Parse the provider
    # detail instead of treating every 429 as a dead key.
    if status == 429 or (status is None and any(word in raw for word in (
            "resourceexhausted", "resource exhausted", "quota", "rate limit"))):
        original = f"{error_type} {exc}"
        quota_match = re.search(
            r"quota(?:id|Id)['\"]?\s*[:=]\s*['\"]([^'\"},]+)",
            original, re.IGNORECASE)
        quota_id = quota_match.group(1).strip() if quota_match else ""
        qlow = quota_id.lower()
        retry_after = None
        for pattern in (
            r"retryDelay['\"]?\s*[:=]\s*['\"]?([0-9]+(?:\.[0-9]+)?)s",
            r"retry\s+in\s+([0-9]+(?:\.[0-9]+)?)s",
        ):
            match = re.search(pattern, original, re.IGNORECASE)
            if match:
                try:
                    retry_after = float(match.group(1))
                except ValueError:
                    retry_after = None
                break

        daily = (
            "perday" in qlow or "requestsperday" in qlow
            or "per day per project per model" in raw
            or "requests per day" in raw
        )
        temporary = (
            "perminute" in qlow or "requestsperminute" in qlow
            or "tokensperminute" in qlow or "rpm" in raw or "tpm" in raw
        )
        if daily:
            return {"type": error_type, "category": "quota_daily",
                    "status": status or 429, "quota_scope": "daily",
                    "quota_id": quota_id or None, "retry_after": retry_after,
                    "message": "daily project/model request quota was reached",
                    "retryable": False, "rotate_key": True}
        # Unknown 429s are treated conservatively as temporary first. This
        # avoids burning unused project keys when the backend is merely rate
        # limiting or under load. Translator will move models if retries fail.
        return {"type": error_type, "category": "rate_limit",
                "status": status or 429, "quota_scope": "minute" if temporary else "unknown",
                "quota_id": quota_id or None, "retry_after": retry_after,
                "message": "temporary API rate limit was reached",
                "retryable": True, "rotate_key": False}
    # 503/high-demand is provider/model pressure, NOT a bad API key. Keep the key
    # and let the parent apply exponential backoff + model fallback.
    high_demand_markers = ("high demand", "overloaded", "model is overloaded",
                           "temporarily unavailable", "serviceunavailable")
    if status == 503 or (status is None and any(word in raw for word in high_demand_markers)):
        return {"type": error_type, "category": "high_demand", "status": status or 503,
                "message": "Gemini model is temporarily busy/high demand", "retryable": True,
                "rotate_key": False}
    if status in (500, 502, 504) or any(word in raw for word in (
            "servererror", "internalservererror")):
        return {"type": error_type, "category": "server", "status": status,
                "message": "provider server is temporarily unavailable", "retryable": True,
                "rotate_key": False}
    if isinstance(exc, (TimeoutError, ConnectionError)) or any(word in raw for word in (
            "clientconnectorerror", "connecterror", "connectionerror", "remoteprotocolerror",
            "readtimeout", "connecttimeout", "name or service not known", "getaddrinfo")):
        message = ("provider network connection was denied by Windows/firewall"
                   if "access is denied" in raw or "winerror 5" in raw
                   else "provider network connection failed")
        return {"type": error_type, "category": "network",
                "message": message, "retryable": True,
                "rotate_key": False}
    if status == 400:
        return {"type": error_type, "category": "request",
                "message": "provider rejected the model or request", "retryable": False,
                "rotate_key": False}
    if action in ("asr", "gpu_check"):
        return {"type": error_type, "category": "local", "message": safe_local_error(exc),
                "retryable": False, "rotate_key": False}
    return {"type": error_type, "category": "response",
            "message": "provider returned an invalid response", "retryable": False,
            "rotate_key": False}


def main():
    request = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    # Provider logs/errors can contain URLs or credentials; never forward them.
    from contextlib import redirect_stdout, redirect_stderr
    try:
        with open(os.devnull, "w") as null, redirect_stdout(null), redirect_stderr(null):
            data = dispatch(request)
        Path(sys.argv[2]).write_text(json.dumps({"ok": True, "data": data}, ensure_ascii=False), encoding="utf-8")
    except Exception as exc:
        detail = classify_error(exc, request.get("action", "unknown"))
        Path(sys.argv[2]).write_text(
            json.dumps({"ok": False, "error": detail}, ensure_ascii=False), encoding="utf-8")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
