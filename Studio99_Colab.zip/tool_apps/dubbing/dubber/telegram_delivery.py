from __future__ import annotations
from datetime import datetime, timezone
import re
import math
import os
from pathlib import Path

import requests
from dotenv import dotenv_values

# Official cloud Bot API accepts multipart uploads up to 50 MB. 47 MB leaves
# room for container/multipart variation and avoids edge-of-limit failures.
_CLOUD_SAFE_BYTES = 47 * 1024 * 1024


def _settings(env_file: str) -> dict:
    values = dotenv_values(env_file) if env_file and Path(env_file).is_file() else {}

    raw_token = str(
        values.get("DUB_TELEGRAM_BOT_TOKEN")
        or os.getenv("DUB_TELEGRAM_BOT_TOKEN")
        or ""
    )

    # Telegram token ထဲက quote/BOM/zero-width/hidden chars အကုန်ဖယ်
    token = re.sub(r"[^0-9A-Za-z:_-]", "", raw_token)

    chat_id = str(
        values.get("DUB_TELEGRAM_CHAT_ID")
        or os.getenv("DUB_TELEGRAM_CHAT_ID")
        or ""
    ).strip()

    thread_id = str(
        values.get("DUB_TELEGRAM_THREAD_ID")
        or os.getenv("DUB_TELEGRAM_THREAD_ID")
        or ""
    ).strip()

    api_base = str(
        values.get("DUB_TELEGRAM_BOT_API_BASE")
        or os.getenv("DUB_TELEGRAM_BOT_API_BASE")
        or "https://api.telegram.org"
    ).strip().rstrip("/")

    return {
        "token": token,
        "chat_id": chat_id,
        "thread_id": thread_id,
        "api_base": api_base,
    }


def validate_telegram_env(env_file: str) -> None:
    s = _settings(env_file)

    if not s["token"]:
        raise ValueError(
            "Telegram auto-send ဖွင့်ထားပေမယ့် .env ထဲ DUB_TELEGRAM_BOT_TOKEN မရှိပါ။"
        )

    if not s["chat_id"]:
        raise ValueError(
            "Telegram auto-send ဖွင့်ထားပေမယ့် .env ထဲ DUB_TELEGRAM_CHAT_ID မရှိပါ။"
        )


def _is_official_cloud(api_base: str) -> bool:
    normalized = api_base.lower().rstrip("/")
    return normalized in ("https://api.telegram.org", "http://api.telegram.org")


def _compress_for_cloud(source: Path, lang: str, folder: Path, media, control) -> Path:
    """Create a Telegram-only upload copy under the cloud Bot API size cap.

    The original rendered DUB is never modified. NVENC is preferred and the
    existing FFmpeg stack is reused; libx264 is only a fallback.
    """
    source = Path(source)
    if source.stat().st_size <= _CLOUD_SAFE_BYTES:
        return source

    duration = float(media.duration(str(source)))
    if not math.isfinite(duration) or duration <= 0:
        raise RuntimeError("Telegram share-copy duration မမှန်ပါ။")

    tg_dir = Path(folder) / "telegram_uploads"
    tg_dir.mkdir(parents=True, exist_ok=True)
    target = tg_dir / f"{source.stem}_TG.mp4"

    # Aim below 47 MB. AAC 96k, with conservative overhead headroom.
    target_bytes = 44 * 1024 * 1024
    total_bps = max(450_000, int(target_bytes * 8 / duration * 0.96))
    audio_bps = 96_000
    video_bps = max(300_000, total_bps - audio_bps)

    def encode(codec: str, bitrate: int):
        tmp = target.with_name(target.name + ".part.mp4")
        tmp.unlink(missing_ok=True)
        if codec == "h264_nvenc":
            video_args = [
                "-c:v", "h264_nvenc", "-preset", "p4", "-rc", "vbr",
                "-b:v", str(bitrate), "-maxrate", str(bitrate),
                "-bufsize", str(max(bitrate * 2, 1_000_000)),
            ]
        else:
            video_args = [
                "-c:v", "libx264", "-preset", "veryfast",
                "-b:v", str(bitrate), "-maxrate", str(bitrate),
                "-bufsize", str(max(bitrate * 2, 1_000_000)),
            ]
        media.ff([
            "-v", "error", "-i", str(source),
            "-map", "0:v:0", "-map", "0:a:0?",
            *video_args,
            "-c:a", "aac", "-b:a", "96k",
            "-movflags", "+faststart",
            str(tmp),
        ])
        os.replace(tmp, target)

    control.log(
        f"Telegram: {lang} output {source.stat().st_size / (1024*1024):.1f} MB > cloud limit; "
        "creating NVENC share copy (original stays untouched)")
    try:
        encode("h264_nvenc", video_bps)
    except Exception:
        control.log("Telegram: NVENC share-copy fallback → libx264")
        encode("libx264", video_bps)

    # VBR can overshoot. One conservative retry is enough for this delivery copy.
    if target.stat().st_size > _CLOUD_SAFE_BYTES:
        control.log("Telegram: share copy still large; retrying with lower bitrate")
        encode("h264_nvenc", max(250_000, int(video_bps * 0.78)))

    if target.stat().st_size > _CLOUD_SAFE_BYTES:
        raise RuntimeError(
            f"Telegram upload copy is still {target.stat().st_size / (1024*1024):.1f} MB; "
            "cloud Bot API requires <50 MB. Set DUB_TELEGRAM_BOT_API_BASE to a local Bot API server for large originals."
        )
    return target


def send_output(*, cfg, media, control, folder: Path, video: str, lang: str, source_title: str) -> dict:
    """Send one completed output to the configured Telegram group.

    Telegram failure is intentionally reported to the caller instead of touching
    render/TTS/cache state. Secrets are never placed in logs or reports.
    """
    s = _settings(cfg.env_file)
    validate_telegram_env(cfg.env_file)
    source = Path(video)
    upload = source
    cloud = _is_official_cloud(s["api_base"])
    if cloud:
        upload = _compress_for_cloud(source, lang, Path(folder), media, control)

    from .languages import label as language_label
    label = language_label(lang)
    caption = f"{source_title} · {label} DUB"
    data = {
        "chat_id": s["chat_id"],
        "caption": caption[:1024],
        "supports_streaming": "true",
    }
    if s["thread_id"]:
        data["message_thread_id"] = s["thread_id"]

    endpoint = f"{s['api_base']}/bot{s['token']}/sendVideo"
    control.log(
        f"Telegram: sending {label} → group ({upload.stat().st_size / (1024*1024):.1f} MB)"
    )
    control.check()
    try:
        with upload.open("rb") as handle:
            response = requests.post(
                endpoint,
                data=data,
                files={"video": (upload.name, handle, "video/mp4")},
                timeout=(30, 1800),
            )
    except requests.RequestException as exc:
        # Never include the requests URL because it contains the bot token.
        raise RuntimeError(f"Telegram network error ({type(exc).__name__})") from None

    try:
        payload = response.json()
    except ValueError:
        payload = {}
    if not response.ok or not payload.get("ok"):
        description = str(payload.get("description") or f"HTTP {response.status_code}")
        raise RuntimeError(f"Telegram send failed: {description}")

    result = payload.get("result") or {}
    control.log(f"Telegram: {label} sent ✅")
    return {
        "status": "sent",
        "sent_at": datetime.now(timezone.utc).isoformat(),
        "message_id": result.get("message_id"),
        "used_share_copy": str(upload) != str(source),
        "upload_file": str(upload),
        "upload_bytes": upload.stat().st_size,
    }
