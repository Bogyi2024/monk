from __future__ import annotations

import html
import base64
import math
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from .fonts import DEFAULT_FONT, bundled_font


def _expand(path: str) -> Path:
    return Path(os.path.expandvars(path)).expanduser()


def resolve_font(font_path: str) -> Path:
    """Keep an available custom font; defaults/old missing font paths use bundled Burma 020."""
    if font_path == DEFAULT_FONT and bundled_font().is_file():
        return bundled_font()
    requested = _expand(font_path)
    if requested.is_file():
        return requested
    root = Path(__file__).resolve().parents[3]
    for relative in ("app/fonts/Burma020-Thin.ttf", "app/fonts/Studio99Myanmar-Regular.ttf", "app/web/fonts/NotoSansMyanmar.ttf"):
        bundled = root / relative
        if bundled.is_file():
            return bundled
    raise RuntimeError(f"Myanmar font မတွေ့ပါ: {requested}. Studio99 ကို ပြန် install လုပ်ပေးပါ။")


def font_identity(font_path: str):
    """Invalidate saved overlays when the effective font changes, including legacy-path fallbacks."""
    path = resolve_font(font_path)
    stat = path.stat()
    return [str(path.resolve()), stat.st_size, stat.st_mtime_ns]


def visible_brand_png(path) -> bool:
    """A partial or transparent cached asset must not silently remove requested branding."""
    try:
        from PIL import Image
        with Image.open(path) as image:
            return image.convert("RGBA").getchannel("A").getbbox() is not None
    except (OSError, ValueError):
        return False


def find_chromium() -> str:
    for name in ("msedge", "chrome", "chromium", "chromium-browser"):
        found = shutil.which(name)
        if found:
            return found
    candidates = []
    for base in (os.getenv("PROGRAMFILES"), os.getenv("PROGRAMFILES(X86)"), os.getenv("LOCALAPPDATA")):
        if not base:
            continue
        candidates += [
            Path(base) / "Microsoft/Edge/Application/msedge.exe",
            Path(base) / "Google/Chrome/Application/chrome.exe",
            Path(base) / "Chromium/Application/chrome.exe",
        ]
    for p in candidates:
        if p.is_file():
            return str(p)
    raise RuntimeError("Chromium renderer မတွေ့ပါ။ Microsoft Edge/Google Chrome install ကိုစစ်ပါ။")


def subtitle_band_geometry(frame_height: int, font_size: int, y_fraction: float):
    """Return (band_height, overlay_y) for a compact transparent subtitle strip.

    The old renderer screenshotted a full video frame once per subtitle. This keeps
    the exact visual placement but screenshots only a narrow band, allowing many
    subtitles to be rendered in one Chromium launch.
    """
    h = max(1, int(frame_height))
    band_h = min(h, max(240, int(round(float(font_size) * 6.0))))
    center = max(0, min(h - 1, int(round(h * float(y_fraction)))))
    y = max(0, min(h - band_h, center - band_h // 2))
    return band_h, y


def subtitle_overlay_geometry(frame_width: int, frame_height: int, font_size: int,
                              x_fraction: float, y_fraction: float, width_fraction: float = 0.90):
    """Return (band_width, band_height, overlay_x, overlay_y).

    x/y are normalized CENTER coordinates chosen in the UI preview.  The subtitle
    plate is kept inside the output frame even when dropped near an edge.
    """
    fw, fh = max(1, int(frame_width)), max(1, int(frame_height))
    wf = max(0.40, min(1.0, float(width_fraction)))
    band_w = max(160, min(fw, int(round(fw * wf))))
    band_h, _ = subtitle_band_geometry(fh, font_size, y_fraction)
    cx = int(round(fw * max(0.0, min(1.0, float(x_fraction)))))
    cy = int(round(fh * max(0.0, min(1.0, float(y_fraction)))))
    x = max(0, min(fw - band_w, cx - band_w // 2))
    y = max(0, min(fh - band_h, cy - band_h // 2))
    return band_w, band_h, x, y


def _page_html(texts, width: int, band_h: int, font_uri: str, font_size: int):
    cells = []
    for text in texts:
        safe = html.escape(" ".join((text or "").split()))
        cells.append(f"<div class='cell'><div class='sub'>{safe}</div></div>")
    return """<!doctype html><html><head><meta charset='utf-8'><style>
@font-face {{ font-family:'DubBurma'; src:url('{font_uri}') format('truetype'); font-display:block; }}
html,body {{ margin:0; padding:0; width:{w}px; background:transparent; overflow:hidden; }}
.cell {{ position:relative; display:flex; align-items:center; justify-content:center; width:{w}px; height:{bh}px; overflow:hidden; background:transparent; }}
.sub {{ display:inline-block; max-width:88%; box-sizing:border-box; text-align:center;
color:#fff; font-family:'DubBurma','Segoe UI','Leelawadee UI','Nirmala UI','Yu Gothic','Malgun Gothic','Microsoft YaHei',sans-serif; font-size:{fs}px; line-height:1.42;
padding:0.24em 0.58em 0.34em; font-weight:500; letter-spacing:0;
background:rgba(0,0,0,.64); border-radius:0.34em;
box-shadow:0 0 18px 9px rgba(0,0,0,.28), 0 3px 8px rgba(0,0,0,.50);
-webkit-text-stroke:0.7px rgba(0,0,0,.78);
text-shadow:0 2px 3px rgba(0,0,0,.92); white-space:normal; overflow:visible; }}
</style></head><body>{cells}<script>(async()=>{{ await document.fonts.ready; document.body.dataset.fonts='ready'; }})();</script></body></html>""".format(
        font_uri=font_uri, w=int(width), bh=int(band_h), fs=int(font_size), cells="".join(cells)
    )


def render_subtitle_pngs(items, width: int, height: int, font_path: str,
                          font_size: int = 64, y_fraction: float = 0.82,
                          max_sheet_height: int = 6000):
    """Render many subtitle PNG bands with a few Chromium launches.

    items: iterable of (text, output_path). Returns {str(output_path): overlay_y}.
    One browser launch handles as many subtitle rows as safely fit under
    max_sheet_height, instead of launching Chromium once per sentence.
    """
    items = [(str(text or ""), Path(out)) for text, out in items]
    if not items:
        return {}
    if int(width) <= 0 or int(height) <= 0:
        raise RuntimeError(f"Subtitle frame size invalid: {width}x{height}")
    font = resolve_font(font_path)
    try:
        from PIL import Image
    except ImportError:
        raise RuntimeError("Chromium subtitle batch crop အတွက် Pillow လိုပါတယ်။ pip install Pillow") from None

    for _, out in items:
        out.parent.mkdir(parents=True, exist_ok=True)

    browser = find_chromium()
    band_h, overlay_y = subtitle_band_geometry(height, font_size, y_fraction)
    rows_per_launch = max(1, min(32, int(max_sheet_height) // max(1, band_h)))
    result = {}

    pending = [(text, out) for text, out in items if not out.is_file()]
    for _, out in items:
        result[str(out)] = overlay_y
    if not pending:
        return result

    font_uri = font.resolve().as_uri()
    with tempfile.TemporaryDirectory(prefix="dub_sub_batch_") as td:
        td = Path(td)
        for batch_index in range(0, len(pending), rows_per_launch):
            batch = pending[batch_index:batch_index + rows_per_launch]
            sheet_h = band_h * len(batch)
            html_path = td / f"subtitles_{batch_index//rows_per_launch:03d}.html"
            sheet_path = td / f"sheet_{batch_index//rows_per_launch:03d}.png"
            html_path.write_text(
                _page_html([text for text, _ in batch], width, band_h, font_uri, font_size),
                encoding="utf-8",
            )
            cmd = [
                browser, "--headless=new", "--hide-scrollbars", "--force-device-scale-factor=1",
                "--run-all-compositor-stages-before-draw", "--virtual-time-budget=800",
                "--default-background-color=00000000", f"--window-size={int(width)},{int(sheet_h)}",
                f"--screenshot={str(sheet_path.resolve())}", html_path.resolve().as_uri(),
            ]
            proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=45)
            if proc.returncode != 0 or not sheet_path.is_file():
                raise RuntimeError("Chromium subtitle batch render failed: " + ((proc.stderr or proc.stdout or "unknown")[-800:]))
            with Image.open(sheet_path).convert("RGBA") as sheet:
                # Some Chromium builds may return a slightly different canvas height;
                # crop only inside the actual image while preserving row boundaries.
                if sheet.width < int(width) or sheet.height < sheet_h:
                    raise RuntimeError(
                        f"Chromium subtitle sheet size mismatch: got {sheet.width}x{sheet.height}, "
                        f"need at least {width}x{sheet_h}"
                    )
                for i, (_, out) in enumerate(batch):
                    top = i * band_h
                    crop = sheet.crop((0, top, int(width), top + band_h))
                    crop.save(out, "PNG", optimize=False)
    return result


def render_subtitle_png(text: str, width: int, height: int, out_png, font_path: str,
                        font_size: int = 64, y_fraction: float = 0.82):
    """Backward-compatible single subtitle wrapper."""
    render_subtitle_pngs([(text, out_png)], width, height, font_path, font_size, y_fraction)
    return Path(out_png)



def render_brand_text_png(text: str, width: int, height: int, out_png, font_path: str,
                          font_size: int = 48, opacity: float = 1.0,
                          plate: bool = False):
    """Render one Unicode/Burmese-safe branding text image with Chromium.

    The returned PNG is tightly cropped around visible pixels. `plate=True` adds a
    soft dark title plate; watermark text normally uses plate=False. Empty text is
    deliberately accepted and returns None so optional UI fields never fail render.
    """
    text = " ".join(str(text or "").split()).strip()
    if not text:
        return None
    width, height = max(160, int(width)), max(80, int(height))
    font_size = max(12, int(font_size))
    opacity = max(0.0, min(1.0, float(opacity)))
    out = Path(out_png)
    out.parent.mkdir(parents=True, exist_ok=True)
    if opacity == 0 and not plate:
        return None
    font = resolve_font(font_path)
    try:
        from PIL import Image
    except ImportError:
        raise RuntimeError("Branding PNG crop အတွက် Pillow လိုပါတယ်။ pip install Pillow") from None

    from playwright.sync_api import sync_playwright
    # Inline bytes avoid file-origin/font-loading differences on customers' PCs.
    font_uri = "data:font/ttf;base64," + base64.b64encode(font.read_bytes()).decode("ascii")
    safe = html.escape(text)
    plate_css = (
        "background:rgba(0,0,0,.62);border-radius:.32em;padding:.20em .52em .30em;"
        if plate else "padding:.12em .20em .18em;"
    )
    pad = max(4, int(round(font_size * .18)))
    page = f"""<!doctype html><html><head><meta charset='utf-8'><style>
@font-face {{ font-family:'DubBurma'; src:url('{font_uri}') format('truetype'); font-display:block; }}
html,body {{ margin:0;width:{width}px;background:transparent; }}
body {{ padding:{pad}px;box-sizing:border-box; }}
.cell {{ display:flex;align-items:center;justify-content:center;background:transparent; }}
.txt {{ display:inline-block;max-width:100%;box-sizing:border-box;text-align:center;color:rgba(255,255,255,{opacity:.4f});
font-family:'DubBurma','Segoe UI',sans-serif;font-size:{font_size}px;line-height:1.35;font-weight:600;
{plate_css}text-shadow:0 2px 4px rgba(0,0,0,.95),0 0 8px rgba(0,0,0,.65);white-space:normal;overflow-wrap:anywhere; }}
</style></head><body><div class='cell'><div class='txt'>{safe}</div></div></body></html>"""

    with tempfile.TemporaryDirectory(prefix="dub_brand_text_") as td:
        td = Path(td)
        sheet_path = td / "brand.png"
        with sync_playwright() as pw:
            # The installer ships this Chromium. An installed Edge/Chrome also works in a source checkout.
            executable = Path(pw.chromium.executable_path)
            browser = pw.chromium.launch(headless=True, executable_path=str(executable) if executable.is_file() else find_chromium())
            try:
                tab = browser.new_page(viewport={"width": width, "height": min(720, height)}, device_scale_factor=1)
                tab.set_default_timeout(30000)
                tab.set_content(page, wait_until="load")
                tab.evaluate("() => document.fonts.ready")
                # Measure after shaping, so wrapped Myanmar titles are never clipped by a fixed-height sheet.
                size = font_size
                while True:
                    needed = math.ceil(tab.locator(".txt").bounding_box()["height"]) + 2 * pad
                    if needed <= height:
                        break
                    if size <= 12:
                        raise RuntimeError("Title စာသားက video frame ထက်ရှည်နေပါသည်။ Title ကို တိုပေးပါ။")
                    size = max(12, min(size - 1, int(size * height / needed)))
                    tab.locator(".txt").evaluate("(node, size) => node.style.fontSize = size + 'px'", size)
                tab.set_viewport_size({"width": width, "height": max(1, needed)})
                tab.screenshot(path=str(sheet_path), omit_background=True, animations="disabled", full_page=True)
            finally:
                browser.close()
        with Image.open(sheet_path).convert("RGBA") as im:
            alpha = im.getchannel("A")
            bbox = alpha.getbbox()
            if not bbox:
                raise RuntimeError("Title / watermark ပုံဖိုင် အလွတ်ထွက်နေပါသည်။ START / RESUME ပြန်နှိပ်ပါ။")
            # Small transparent margin keeps shadows/rounded plates from clipping.
            l, t, r, b = bbox
            pad = max(4, int(round(font_size * 0.18)))
            l = max(0, l - pad); t = max(0, t - pad)
            r = min(im.width, r + pad); b = min(im.height, b + pad)
            part = out.with_name(out.stem + ".part.png")
            im.crop((l, t, r, b)).save(part, "PNG", optimize=False)
            part.replace(out)
    return out
