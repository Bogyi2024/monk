from __future__ import annotations

import re

from .config import voice_for
from .media import wav_duration

# Gemini sometimes keeps the English original in brackets after a Burmese word or name
# ("ဇွန်ဘီ (Zombie)", "အဲလက်စ်ကာတာ (Alex Carter)"). Edge TTS reads both, so the word is heard twice.
_BRACKETED_LATIN = re.compile(r"\s*[(（]\s*[A-Za-z][A-Za-z0-9 .,'’&:/!?-]*[)）]")


def spoken_text(text: str, language: str) -> str:
    """The Burmese line without bracketed English; used for the voice and the subtitle alike."""
    if language != "my":
        return text
    cleaned = _BRACKETED_LATIN.sub("", text)
    cleaned = re.sub(r"\s+([၊။,!?])", r"\1", cleaned)
    return " ".join(cleaned.split()) or text


def fit_from_translation(cfg, segment, language, translated_text, speech, cache, media,
                         visual_window_seconds=None, voice=None):
    """Generate one TTS WAV only. VoxCPM exact Smart Sync happens later in render.py.

    `voice` overrides the language's main voice (male/female routing).
    """
    voice = voice or voice_for(cfg, language)
    window = float(visual_window_seconds or (segment["end"] - segment["start"]))
    original = str(translated_text or "").strip()
    text = spoken_text(original, language)
    if not text:
        raise ValueError(f"{segment['id']}: empty translated text")
    if text != original and hasattr(cache.control, "log"):
        dropped = " ".join(m.group(0).strip() for m in _BRACKETED_LATIN.finditer(original))
        cache.control.log(f"{language}/{segment['id']}: dropped {dropped} (TTS would say it twice)")
    key = {
        "v": 900, "segment": segment, "language": language, "text": text,
        "voice": voice.identity(), "dry": cfg.dry_run,
        "timestamp_window_seconds": window,
        "sync_policy": "voxcpm_bundle7_exact_plus_gap_keep",
    }
    cached = cache.get("aligned", key)
    if cached is not None:
        return cached
    cache.control.check()
    raw = speech.synthesize(text, language, window, 0, cache_salt=segment["id"], voice=voice)
    measured = wav_duration(raw)
    result = {
        "id": segment["id"], "source_start": float(segment["start"]),
        "source_end": float(segment["end"]), "source_text": segment.get("text", ""),
        "text": text, "language": language, "voice": voice.voice,
        "provider": voice.provider,
        "fixed_voice_rate_percent": voice.rate_percent if voice.provider == "edge" else None,
        "audio_tempo": 1.0, "audio": str(raw), "seconds": measured,
        "tts_duration": measured, "timestamp_window_seconds": window,
        "decision": "TTS_READY_FOR_VOXCPM_EXACT_SYNC", "status": "ready",
    }
    return cache.put("aligned", key, result, [raw])


def fit_segment(cfg, segment, language, context, translator, speech, cache, media,
                visual_window_seconds=None):
    translated = translator.adapt(segment, language, context)["text"]
    return fit_from_translation(cfg, segment, language, translated, speech, cache, media,
                                visual_window_seconds=visual_window_seconds)
