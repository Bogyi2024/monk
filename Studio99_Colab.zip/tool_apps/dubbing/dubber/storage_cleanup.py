"""Remove generated DUB media 24h after all Telegram deliveries succeed."""
from __future__ import annotations
import json
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from .runtime import JobLock, atomic_json

MEDIA = {'.mp4', '.mkv', '.mov', '.webm', '.wav', '.mp3', '.m4a', '.flac',
         '.ogg', '.aac', '.png', '.jpg', '.jpeg', '.webp', '.npy', '.npz'}
_MONITORS = {}
_MONITOR_LOCK = threading.Lock()

def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def parse(value):
    date = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    return (date if date.tzinfo else date.astimezone()).astimezone(timezone.utc)

def delivered_at(folder: Path):
    if load(folder / 'checkpoint.json').get('status') != 'complete': return None
    report = load(folder / 'alignment_report.json')
    outputs = report.get('outputs') or {}
    if not outputs: return None
    times=[]
    for row in outputs.values():
        delivery = row.get('telegram') or {}
        if row.get('status') != 'complete' or delivery.get('status') != 'sent' or not delivery.get('message_id'):
            return None
        # Older successful reports did not persist sent_at. The final report
        # write is later than delivery and therefore a conservative timestamp.
        times.append(parse(delivery['sent_at']) if delivery.get('sent_at') else
                     datetime.fromtimestamp((folder/'alignment_report.json').stat().st_mtime, timezone.utc))
    return max(times)

def cleanup(output_root, *, dry_run=False, now=None):
    root = Path(output_root).resolve()
    now = now or datetime.now(timezone.utc)
    result={'dry_run':dry_run,'deleted_files':0,'freed_bytes':0,'eligible_bytes':0,'errors':[]}
    if not root.exists(): return result
    for folder in sorted(root.glob('dub_*')):
        if not folder.is_dir() or folder.is_symlink() or folder.resolve().parent != root: continue
        try:
            # Use the same OS lock as rendering. A stale .lock filename alone
            # does not identify a running job.
            with JobLock(folder):
                at=delivered_at(folder)
                if not at or now-at < timedelta(hours=24): continue
                report=load(folder/'alignment_report.json')
                preserved={Path(p).resolve() for p in report.get('preserve_paths') or [] if p}
                for path in folder.rglob('*'):
                    if path.suffix.lower() not in MEDIA or not path.is_file() or path.is_symlink(): continue
                    if not path.resolve().is_relative_to(folder.resolve()) or path.resolve() in preserved: continue
                    size=path.stat().st_size; result['eligible_bytes']+=size
                    if not dry_run:
                        path.unlink();result['deleted_files']+=1;result['freed_bytes']+=size
                if not dry_run:
                    atomic_json(folder/'media_cleanup.json', {'cleaned_at':now.isoformat(),'delivered_at':at.isoformat(),'retention_hours':24})
        except Exception as exc:
            result['errors'].append(f'{folder.name}: {type(exc).__name__}: {exc}')
    if not dry_run:
        atomic_json(root/'cleanup_last_run.json', {**result,'ran_at':now.isoformat()})
    return result

def start_monitor(output_root, log=print):
    key=str(Path(output_root).resolve()).casefold()
    with _MONITOR_LOCK:
        if key in _MONITORS: return _MONITORS[key]
        stop=threading.Event()
        _MONITORS[key]=stop
    def run():
        while not stop.is_set():
            try:
                result=cleanup(output_root)
                log(f"24h DUB cleanup: files={result['deleted_files']} freed={result['freed_bytes']/1024**3:.2f}GB errors={result['errors']}")
            except Exception as exc:
                log(f'24h DUB cleanup warning: {exc}')
            stop.wait(3600)
    threading.Thread(target=run,daemon=True,name='dub-24h-cleanup').start()
    return stop

if __name__ == '__main__':
    result=cleanup(Path(__file__).resolve().parents[1]/'outputs')
    print(f"🧹 24h DUB cleanup: files={result['deleted_files']} freed={result['freed_bytes']/1024**3:.2f}GB errors={result['errors']}",flush=True)
