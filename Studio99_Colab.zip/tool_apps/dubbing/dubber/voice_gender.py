"""Male / female line routing: Gemini listens to the original voices; pitch is the fallback.

Pitch alone cannot tell a man shouting from a woman: in dub_444cf6b7d3b49532 Alex begging
"Mom, Dad, please!" measured 336-390 Hz and 30 of 42 lines got the female voice. So when a
Gemini key is available every line is heard by Gemini (timbre + who is speaking in the story),
about one request per 10 minutes of video; pitch decides only when Gemini cannot answer.
Since 2026-10-07 this runs before the translation (pipeline._speaker_hints): the same answer
gives the speaker's words (ကျွန်တော် / ကျွန်မ, ခင်ဗျား / ရှင်) and the male/female voice.

Pitch rule (fallback):

Each timestamped source segment gets the median fundamental frequency (F0) of its
voiced frames. Only clear cases are routed:

    median F0 >= FEMALE_MIN_HZ  -> "female" (uses the panel's Female voice)
    median F0 <= MALE_MAX_HZ    -> "male"   (main voice)
    in between / too little voiced audio -> "unsure" (main voice)

V3.4's pyannote + Wav2Vec2 Speaker AI was removed for mis-labelling speakers, so this
deliberately prefers "unsure" (main voice) over guessing.
"""
from __future__ import annotations

import json
import wave
from pathlib import Path

import numpy as np

ANALYSIS_SR = 16000
FEMALE_MIN_HZ = 180.0
MALE_MAX_HZ = 160.0
MIN_VOICED_FRAMES = 15          # 10 ms hop -> at least 0.15 s of voiced speech
_FRAME = 1024                   # 64 ms, covers a 70 Hz period with margin
_HOP = 160                      # 10 ms
_FMIN, _FMAX = 70.0, 400.0
_VERSION = 2  # 2: Gemini listens first
CHUNK_SECONDS = 600.0  # audio per Gemini request

LISTEN_PROMPT = """You hear the original soundtrack of part of a video (it may contain music and sound effects).
Below are the spoken lines in this audio: each has an id, its time range from the start of THIS audio, and
its words (speech recognition, may be imperfect).
For each line decide who says it and whether that VOICE is male or female.
- Judge the voice itself (timbre, resonance), not pitch alone: a man shouting, screaming, begging or crying
  is still male; a woman with a low voice is still female.
- Use the story to help (names, "I am your son", "Mom", who answers whom), but the voice you hear decides.
- If no clear voice is heard in that time range, or you cannot tell, answer "unsure".
Speakers met earlier in this video: {speakers}
Return only JSON: {{"lines": [{{"id": "...", "speaker": "short name or role", "gender": "male" | "female" | "unsure"}}]}}
with every id below exactly once.
LINES:
{lines}"""


def _read_range(handle, start: float, end: float) -> np.ndarray:
    """One segment of the open 16 kHz mono WAV (the whole file of a 5-hour video would be ~1.7 GB as floats)."""
    if handle.getnchannels() != 1 or handle.getsampwidth() != 2:
        raise ValueError("voice-gender analysis expects 16-bit mono WAV")
    a = max(0, int(start * ANALYSIS_SR))
    b = min(handle.getnframes(), int(end * ANALYSIS_SR))
    if b <= a:
        return np.zeros(0, dtype=np.float32)
    handle.setpos(a)
    return np.frombuffer(handle.readframes(b - a), dtype="<i2").astype(np.float32) / 32768.0


def segment_f0(samples: np.ndarray, sr: int = ANALYSIS_SR) -> tuple[float | None, int]:
    """(median F0 in Hz of voiced frames, voiced frame count) for one segment."""
    if samples.size < _FRAME:
        return None, 0
    count = 1 + (samples.size - _FRAME) // _HOP
    idx = np.arange(_FRAME)[None, :] + _HOP * np.arange(count)[:, None]
    frames = samples[idx]
    frames = frames - frames.mean(axis=1, keepdims=True)
    rms = np.sqrt((frames ** 2).mean(axis=1))
    loud = rms >= max(1e-3, 0.25 * float(np.percentile(rms, 95)))
    if not loud.any():
        return None, 0
    frames = frames[loud]
    spec = np.fft.rfft(frames, n=2 * _FRAME, axis=1)
    ac = np.fft.irfft(np.abs(spec) ** 2, axis=1)[:, :_FRAME]
    energy = ac[:, :1]
    energy[energy <= 0] = 1e-12
    lags = np.arange(_FRAME)
    nac = (ac / energy) * (_FRAME / np.maximum(1, _FRAME - lags))[None, :]
    lo, hi = int(sr / _FMAX), int(sr / _FMIN)
    band = nac[:, lo:hi + 1]
    peak = band.max(axis=1)
    voiced = peak >= 0.60
    if not voiced.any():
        return None, 0
    f0s = []
    for row, best in zip(band[voiced], peak[voiced]):
        # Smallest lag close to the best peak: avoids picking a multiple of the
        # true period (which would halve F0 and turn a female line "male").
        candidates = np.nonzero(row >= 0.90 * best)[0]
        lag = lo + int(candidates[0])
        f0s.append(sr / lag)
    return float(np.median(f0s)), len(f0s)


def classify(f0: float | None, voiced: int) -> str:
    if f0 is None or voiced < MIN_VOICED_FRAMES:
        return "unsure"
    if f0 >= FEMALE_MIN_HZ:
        return "female"
    if f0 <= MALE_MAX_HZ:
        return "male"
    return "unsure"


def _clock(seconds: float) -> str:
    seconds = max(0.0, seconds)
    return f"{int(seconds // 60)}:{seconds % 60:04.1f}"


def _pieces(segments: list[dict]) -> list[list[dict]]:
    """Neighbouring lines in pieces of at most CHUNK_SECONDS of audio."""
    pieces: list[list[dict]] = []
    for seg in sorted(segments, key=lambda s: float(s["start"])):
        if pieces and float(seg["end"]) - float(pieces[-1][0]["start"]) <= CHUNK_SECONDS:
            pieces[-1].append(seg)
        else:
            pieces.append([seg])
    return pieces


def listen_genders(media, audio: Path, segments: list[dict], folder: Path, listen, log=print) -> dict[str, dict]:
    """{segment id: {"gender", "speaker"}} as Gemini hears the original voices (lines it skipped are absent)."""
    heard: dict[str, dict] = {}
    known: dict[str, str] = {}
    for number, piece in enumerate(_pieces(segments), 1):
        start = max(0.0, float(piece[0]["start"]) - 0.5)
        end = float(piece[-1]["end"]) + 0.5
        clip = Path(folder) / f"voice_gender_listen_{number:02d}.mp3"
        if not clip.is_file():
            tmp = clip.with_name(clip.stem + ".part.mp3")
            media.ff(["-v", "error", "-ss", f"{start:.3f}", "-i", audio, "-t", f"{end - start:.3f}",
                      "-ac", "1", "-c:a", "libmp3lame", "-b:a", "48k", tmp])
            tmp.replace(clip)
        lines = "\n".join(
            f"{s['id']} [{_clock(float(s['start']) - start)}-{_clock(float(s['end']) - start)}] "
            f"{' '.join(str(s.get('text') or '').split())}" for s in piece)
        speakers = ", ".join(f"{name} ({gender})" for name, gender in known.items()) or "none yet"
        answer = listen({"action": "audio_json", "audio": str(clip), "mime_type": "audio/mp3",
                         "prompt": LISTEN_PROMPT.format(speakers=speakers, lines=lines)})
        rows = answer.get("lines") if isinstance(answer, dict) else answer
        ids = {str(s["id"]) for s in piece}
        for row in rows or []:
            if not isinstance(row, dict) or str(row.get("id")) not in ids:
                continue
            gender = str(row.get("gender") or "").strip().lower()
            gender = gender if gender in ("male", "female") else "unsure"
            speaker = " ".join(str(row.get("speaker") or "").split())[:40]
            heard[str(row["id"])] = {"gender": gender, "speaker": speaker}
            if speaker and gender != "unsure":
                known.setdefault(speaker, gender)
    return heard


def segment_genders(media, source: str, segments: list[dict], folder: Path, log=print,
                    listen=None) -> dict[str, dict]:
    """{segment id: {"gender", "f0", "voiced", "pitch"[, "speaker"]}} for every segment, cached per job.

    listen(request) -> JSON runs a Gemini request (the translator's key/model fallback); without
    it, or when it fails, the pitch rule decides. A pitch-only cache is retried when listen exists.
    """
    folder = Path(folder)
    cache_file = folder / "voice_gender.json"
    signature = {"v": _VERSION, "female_min": FEMALE_MIN_HZ, "male_max": MALE_MAX_HZ,
                 "segments": [[str(s["id"]), round(float(s["start"]), 3), round(float(s["end"]), 3)] for s in segments]}
    if cache_file.is_file():
        try:
            saved = json.loads(cache_file.read_text(encoding="utf-8"))
            if saved.get("signature") == signature and (listen is None or saved.get("method") == "gemini"):
                return saved["items"]
        except Exception:
            pass
    audio = folder / "voice_gender_16k.wav"
    if not audio.is_file():
        tmp = audio.with_suffix(".part.wav")
        media.ff(["-v", "error", "-i", source, "-vn", "-ac", "1", "-ar", str(ANALYSIS_SR), "-c:a", "pcm_s16le", tmp])
        tmp.replace(audio)
    items: dict[str, dict] = {}
    with wave.open(str(audio), "rb") as handle:
        for seg in segments:
            samples = _read_range(handle, float(seg["start"]), float(seg["end"]))
            f0, voiced = segment_f0(samples) if samples.size else (None, 0)
            pitch = classify(f0, voiced)
            items[str(seg["id"])] = {"gender": pitch, "f0": round(f0, 1) if f0 else None, "voiced": voiced,
                                     "pitch": pitch}
    method = "pitch"
    if listen is not None:
        try:
            heard = listen_genders(media, audio, segments, folder, listen, log)
        except Exception as exc:  # never stop a dub for this; pitch decides and the next run asks again
            heard = {}
            log(f"Voice gender: Gemini could not listen ({str(exc)[:160]}); using pitch")
        if heard:
            method = "gemini"
            for seg_id, item in items.items():
                if seg_id in heard:
                    item.update(gender=heard[seg_id]["gender"], speaker=heard[seg_id]["speaker"])
    tmp_json = cache_file.with_suffix(".tmp")
    tmp_json.write_text(json.dumps({"signature": signature, "method": method, "items": items},
                                   ensure_ascii=False, indent=1), encoding="utf-8")
    tmp_json.replace(cache_file)
    counts = {g: sum(1 for x in items.values() if x["gender"] == g) for g in ("male", "female", "unsure")}
    if method == "gemini":
        changed = sum(1 for x in items.values() if x["gender"] != x["pitch"])
        log(f"Voice gender (Gemini listened): male={counts['male']} · female={counts['female']} · "
            f"unsure={counts['unsure']} (unsure → main voice) · {changed} line(s) differ from pitch · "
            f"details: {cache_file.name}")
    else:
        log(f"Voice gender (pitch): male={counts['male']} · female={counts['female']} · unsure={counts['unsure']} "
            f"(unsure → main voice) · details: {cache_file.name}")
    return items
