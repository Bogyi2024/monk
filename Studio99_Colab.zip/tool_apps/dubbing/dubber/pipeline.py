from __future__ import annotations

import concurrent.futures
import math
import os
from pathlib import Path
import sys

from .alignment import fit_from_translation
from .config import Config, load_selected_env
from .config import voice_for
from .languages import file_label as language_file_label, label as language_label
from .media import Media
from .providers import GeminiKeyPool, Speech, Translator
from .render import BRANDING_RENDER_VERSION, render_motion_safe, validate_output, validate_srt, write_srt
from .runtime import Cache, Cancelled, Control, JobLock, atomic_json, file_hash
from .telegram_delivery import send_output as telegram_send_output
from .storage_cleanup import start_monitor
from .chromium_subtitles import font_identity


def publish(source, target, control):
    source, target = Path(source), Path(target)
    if target.exists() and file_hash(source, control) == file_hash(target, control):
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + ".part")
    with source.open("rb") as src, tmp.open("wb") as dst:
        while data := src.read(4 * 1024 * 1024):
            control.check(); dst.write(data)
    os.replace(tmp, target)


def _voxcpm_exact_plan(cfg, folder, media, control, progress, speaker_hints=None):
    """Run the original Bundle(7) sentence-lock + story-context + Burmese translation planner.

    The planner prompt/atomic segmentation code is copied from the user's working VoxCPM bundle.
    Only transport fallback and caller Whisper settings are adapted, plus speaker_hints: who
    speaks each unit, so a man's line gets ကျွန်တော် / ခင်ဗျား / မင်း and a woman's ကျွန်မ / ရှင် / နင်.
    """
    import sys
    project_root = Path(__file__).resolve().parents[1]
    exact_root = project_root / "voxcpm_exact"
    if str(exact_root) not in sys.path:
        sys.path.insert(0, str(exact_root))
    from recap_planner import RecapPlanBuilder

    language = None if cfg.source_language == "auto" else cfg.source_language
    planner = RecapPlanBuilder(
        runtime_root=str(exact_root / "recap_runtime"),
        gemini_env_path=cfg.env_file,
        ffprobe_path=media.ffprobe,
        log=control.log,
        progress=lambda cur, total, label: progress(5 + 25 * (cur / max(1, total)), f"VoxCPM exact planner · {label}"),
        should_stop=lambda: bool(control.event.is_set() or (control.stop_file and control.stop_file.exists())),
        translation_batch_max_items=40,
        story_context_batch_max_items=80,
        context_overlap=6,
        lookahead=6,
        translation_audit=True,
        atomic_max_duration=10.0,
        atomic_target_duration=6.5,
        gemini_request_timeout_seconds=cfg.request_timeout,
        gemini_text_model=cfg.translation_models[0],
        gemini_model_plan=list(cfg.translation_models),
        whisper_model=cfg.whisper_model,
        whisper_device=("cuda" if cfg.device == "auto" else cfg.device),
        whisper_compute_type=cfg.whisper_compute_type,
        whisper_language=language,
        speaker_hints=speaker_hints,
    )
    plan_path, plan = planner.build(
        source=Path(cfg.input),
        job_dir=folder / "voxcpm_exact_plan",
        source_title=Path(cfg.input).stem,
        reuse=cfg.resume,
    )
    return plan_path, plan


def _segments_from_voxcpm_plan(plan):
    """Use actual Whisper speech timestamps, not the recap planner's midpoint full-coverage windows."""
    out = []
    my_text = {}
    for i, item in enumerate(plan.get("segments") or [], 1):
        start = float(item.get("whisper_start", item.get("video_start", 0.0)))
        end = float(item.get("whisper_end", item.get("video_end", start)))
        text = str(item.get("source_text") or "").strip()
        tr = str(item.get("narration") or item.get("translation") or "").strip()
        if not text or not tr or end <= start + 0.001:
            continue
        atomic = int(item.get("atomic_id", i))
        sid = f"s{atomic:06d}"
        out.append({
            "id": sid, "start": start, "end": end, "text": text,
            "atomic_id": atomic,
            "source_whisper_ids": list(item.get("source_segment_ids") or []),
        })
        my_text[sid] = tr
    if not out:
        raise ValueError("VoxCPM exact planner produced no timestamped units")
    return out, my_text


def _segments_from_units(units):
    """The planner's units before translation as the same DUB segments (ids, times) as above, so
    voice_gender.json heard for the translation is reused for the male/female voices."""
    out = []
    for unit in units:
        start, end = float(unit["speech_start"]), float(unit["speech_end"])
        text = str(unit.get("source_text") or "").strip()
        if text and end > start + 0.001:
            out.append({"id": f"s{int(unit['id']):06d}", "start": start, "end": end, "text": text,
                        "atomic_id": int(unit["id"])})
    return out


def _with_speakers(segments, plan):
    """Copies of the segments that say who speaks (for languages whose grammar marks the speaker's gender)."""
    heard = {f"s{int(x['atomic_id']):06d}": x for x in plan.get("segments") or [] if x.get("speaker_gender")}
    return [dict(seg, speaker=heard[seg["id"]].get("speaker", ""), speaker_gender=heard[seg["id"]]["speaker_gender"])
            if seg["id"] in heard else seg for seg in segments]


class Pipeline:
    def __init__(self, config: Config, control=None, progress=None):
        self.cfg = config
        self.control = control or Control()
        self.progress = progress or (lambda percent, label: self.control.log(f"{percent:.1f}% {label}"))

    def run(self):
        desktop_app = str(Path(__file__).resolve().parents[3] / "app")
        if desktop_app not in sys.path:
            sys.path.append(desktop_app)
        from membership_access import desktop_context, require_vip
        if not desktop_context():
            return self._run()
        require_vip("Dubbing")
        return self._run()

    def _run(self):
        cfg, ctl = self.cfg, self.control
        if cfg.env_file:
            cfg.env_key = load_selected_env(cfg.env_file, cfg.env_key, override=True)
        cfg.validate()
        if not cfg.dry_run:
            start_monitor(Path(cfg.output).resolve(), ctl.log)
        media = Media(ctl)
        self.progress(1, "Input fingerprint / probe")
        source_hash = file_hash(cfg.input, ctl)
        folder = Path(cfg.output).resolve() / (("dry_run_" if cfg.dry_run else "dub_") + source_hash[:16])
        folder.mkdir(parents=True, exist_ok=True)
        ctl.log(f"Job folder: {folder}")
        with JobLock(folder):
            old_log = ctl.log
            with (folder / "run.log").open("a", encoding="utf-8", buffering=1) as log:
                def log_message(text):
                    log.write(str(text) + "\n"); old_log(text)
                ctl.log = log_message
                try:
                    ctl.log(f"Python runtime: {sys.executable} ({sys.version.split()[0]})")
                    ctl.log("Mode: DUB · VoxCPM Bundle(7) exact translation/sync · source audio OFF")
                    ctl.log("Smart Sync: timestamped units = original VoxCPM algorithm; untimestamped gaps = KEEP 1.0x")
                    ctl.log("No custom continuous-warp sync; no midpoint gap absorption")
                    return self._run_locked(folder, source_hash, media)
                except Cancelled:
                    atomic_json(folder / "checkpoint.json", {"status": "cancelled", "resumable": True})
                    raise
                except Exception as exc:
                    atomic_json(folder / "checkpoint.json", {"status": "failed", "resumable": True, "error": str(exc)})
                    raise
                finally:
                    ctl.log = old_log

    def _translate_language(self, folder, segments, lang, story_context, translator, stage_start, stage_end):
        cfg, ctl = self.cfg, self.control
        batches = translator.batches(
            segments, cfg.translation_batch_max_items, cfg.translation_batch_max_chars)
        translated_all = []
        translation_dir = folder / "translation"
        translation_dir.mkdir(parents=True, exist_ok=True)
        checkpoint_file = translation_dir / f"{lang}_checkpoint.json"
        segment_index = {str(x["id"]): i for i, x in enumerate(segments)}

        ctl.log(
            f"{lang}: Gemini batch translation · {len(segments)} segments → {len(batches)} batch(es) "
            f"(max {cfg.translation_batch_max_items} / {cfg.translation_batch_max_chars} chars)")
        for bi, batch in enumerate(batches, 1):
            ctl.check()
            first_idx = segment_index[str(batch[0]["id"])]
            last_idx = segment_index[str(batch[-1]["id"])]
            previous = translated_all[-cfg.context_overlap:] if cfg.context_overlap else []
            next_context = segments[last_idx + 1:last_idx + 1 + cfg.lookahead] if cfg.lookahead else []
            ctl.log(f"{lang}: Translate batch {bi}/{len(batches)} · {batch[0]['id']}–{batch[-1]['id']}")
            translated = translator.translate_batch(batch, lang, story_context, previous, next_context)
            if [str(x["id"]) for x in translated] != [str(x["id"]) for x in batch]:
                raise RuntimeError(f"{lang}: translation batch ID sequence mismatch")
            for source, item in zip(batch, translated):
                translated_all.append({
                    "id": str(source["id"]),
                    "source_start": float(source["start"]),
                    "source_end": float(source["end"]),
                    "source_text": source.get("text", ""),
                    "translated_text": item["text"],
                    # Keep text too so previous-context validation can inspect it consistently.
                    "text": item["text"],
                })
            atomic_json(checkpoint_file, {
                "schema": "dub.batch_translation.v1", "language": lang,
                "completed": len(translated_all), "total": len(segments),
                "batch": bi, "batches": len(batches), "items": translated_all,
            })
            pct = stage_start + (stage_end - stage_start) * bi / max(1, len(batches))
            self.progress(pct, f"{lang.upper()} translation batch {bi}/{len(batches)}")
        return translated_all

    def _speaker_hints(self, folder, media, translator):
        """Planner hook: Gemini hears who speaks each unit BEFORE the translation is written.

        The same voice_gender.json then picks the male/female TTS voice, so words and voice agree.
        A dry run has no Gemini: None keeps the planner exactly as before.
        """
        cfg, ctl = self.cfg, self.control
        if cfg.dry_run:
            return None

        def hints(units):
            from .voice_gender import segment_genders
            segments = _segments_from_units(units)
            self._genders = segment_genders(media, cfg.input, segments, folder, ctl.log,
                                            listen=translator._call_translation)
            return {seg["atomic_id"]: self._genders.get(seg["id"]) or {} for seg in segments}
        return hints

    @staticmethod
    def _visual_window(segments, index, source_duration):
        # IMPORTANT: DUB uses only the real timestamped speech interval.
        # Untimestamped scenes between rows are separate untouched GAP parts.
        start = max(0.0, float(segments[index]["start"]))
        end = min(float(source_duration), float(segments[index]["end"]))
        return max(.05, end - start)

    def _tts_rows(self, translated, source_segments, language, speech, cache, media, stage_start, stage_end):
        cfg, ctl = self.cfg, self.control
        voice = voice_for(cfg, language)
        workers = {
            "edge": cfg.edge_tts_workers,
            "gemini": cfg.gemini_tts_workers,
            "voxcpm": cfg.voxcpm_tts_workers,
        }[voice.provider]
        # Gemini key-pool mutation is deliberately serialized. Edge gets the speed boost.
        if voice.provider == "gemini":
            workers = 1
        ctl.log(f"{language}: {voice.provider} TTS · workers={workers}" +
                (f" · rate={voice.rate_percent:+d}%" if voice.provider == "edge" else ""))

        female_voice = None
        genders: dict = {}
        if voice.gender_split and voice.female_voice.strip():
            from dataclasses import replace
            from .voice_gender import segment_genders
            female_voice = replace(voice, voice=voice.female_voice.strip(), gender_split=False, female_voice="")
            genders = getattr(self, "_genders", None)  # heard before the translation: words and voice agree
            if genders is None:
                translator = getattr(self, "_translator", None)
                listen = translator._call_translation if translator is not None and not cfg.dry_run else None
                genders = segment_genders(media, cfg.input, source_segments, cache.root.parent, ctl.log, listen=listen)
            ctl.log(f"{language}: Male/Female split ON · main={voice.voice} · female={female_voice.voice}")

        def build_one(i):
            ctl.check()
            source = source_segments[i]
            window = self._visual_window(source_segments, i, self._source_duration)
            row_voice = None
            if female_voice is not None and (genders.get(str(source["id"])) or {}).get("gender") == "female":
                row_voice = female_voice
            return fit_from_translation(
                cfg, source, language, translated[i]["translated_text"], speech, cache, media,
                visual_window_seconds=window, voice=row_voice)

        rows = [None] * len(source_segments)
        completed = 0
        if workers <= 1:
            for i in range(len(source_segments)):
                rows[i] = build_one(i)
                completed += 1
                pct = stage_start + (stage_end - stage_start) * completed / len(source_segments)
                self.progress(pct, f"{language.upper()} TTS {completed}/{len(source_segments)}")
                if completed % 10 == 0 or completed == len(source_segments):
                    atomic_json(cache.root.parent / f"tts_{language}_checkpoint.json", {
                        "completed": completed, "total": len(source_segments), "provider": voice.provider})
            return rows

        # Parallel Edge/VoxCPM path. Results are stored by source index so timestamps never reorder.
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers, thread_name_prefix=f"{language}-{voice.provider}") as pool:
            future_to_index = {pool.submit(build_one, i): i for i in range(len(source_segments))}
            try:
                for future in concurrent.futures.as_completed(future_to_index):
                    ctl.check()
                    i = future_to_index[future]
                    rows[i] = future.result()
                    completed += 1
                    pct = stage_start + (stage_end - stage_start) * completed / len(source_segments)
                    self.progress(pct, f"{language.upper()} TTS {completed}/{len(source_segments)} · {workers} workers")
                    if completed % 10 == 0 or completed == len(source_segments):
                        atomic_json(cache.root.parent / f"tts_{language}_checkpoint.json", {
                            "completed": completed, "total": len(source_segments),
                            "provider": voice.provider, "workers": workers})
            except BaseException:
                for future in future_to_index:
                    future.cancel()
                raise
        return rows

    def _run_locked(self, folder, source_hash, media):
        cfg, ctl = self.cfg, self.control
        cache = Cache(folder / "cache", ctl, cfg.resume)
        info = media.probe(cfg.input)
        video = next((s for s in info["streams"] if s["codec_type"] == "video"), None)
        audio = next((s for s in info["streams"] if s["codec_type"] == "audio"), None)
        if not video or not audio:
            raise ValueError("Input video must contain video and source audio")
        duration = float(video.get("duration") or info["format"]["duration"])
        if not math.isfinite(duration) or duration <= 0:
            raise ValueError("Invalid source duration")
        self._source_duration = duration

        source_w, source_h = int(video.get("width") or 0), int(video.get("height") or 0)
        rotation = 0
        for sd in video.get("side_data_list") or []:
            if "rotation" in sd:
                try: rotation = int(round(float(sd["rotation"])))
                except Exception: pass
        if not rotation:
            try: rotation = int(round(float((video.get("tags") or {}).get("rotate", 0))))
            except Exception: rotation = 0
        if abs(rotation) % 180 == 90:
            source_w, source_h = source_h, source_w
        source_aspect = (source_w / source_h) if source_w > 0 and source_h > 0 else None
        ctl.log(f"Input checked: {duration:.3f}s")
        if source_aspect:
            ctl.log(f"Video geometry: {source_w}x{source_h} · aspect={source_aspect:.6f} · output=SOURCE RATIO")

        # Current provider layer is retained for TTS, the other languages and listening to the voices.
        # Burmese text comes from the proven VoxCPM planner output (told who speaks each line).
        key_pool = None if cfg.dry_run else GeminiKeyPool(cfg, ctl)
        if key_pool is not None:
            ctl.log(f"Gemini rotation ready: {key_pool.count} FREE key(s); secrets hidden")
            ctl.log("Gemini model fallback plan: " + " → ".join(cfg.translation_models))
        translator = Translator(cfg, cache, ctl, key_pool)
        self._translator = translator  # Gemini hears male/female voices through it
        self._genders = None
        speech = Speech(cfg, cache, ctl, media, key_pool)

        atomic_json(folder / "checkpoint.json", {"status": "running", "stage": "voxcpm_exact_planner"})
        ctl.log("VoxCPM EXACT MODE: Bundle(7) Whisper word timestamps + sentence-lock + original Burmese translation prompt")
        ctl.log("Only DUB timeline change: untimestamped source gaps are kept 1.0x instead of being absorbed/cut")
        plan_path, exact_plan = _voxcpm_exact_plan(cfg, folder, media, ctl, self.progress,
                                                   speaker_hints=self._speaker_hints(folder, media, translator))
        segments, exact_my_text = _segments_from_voxcpm_plan(exact_plan)
        story_context = exact_plan.get("story_context") or {}
        atomic_json(folder / "transcript.json", {
            "engine": "voxcpm_bundle7_exact_planner",
            "segments": segments,
            "plan_path": str(plan_path),
        })
        self.progress(30, f"VoxCPM exact plan ready: {len(segments)} sentence-locked units")

        report = {
            "schema": "dub_alignment.voxcpm_exact_gap_preserve.v1",
            "source_sha256": source_hash,
            "source_duration": duration,
            "source_video_width": source_w, "source_video_height": source_h,
            "source_video_aspect": source_aspect,
            "whisper_engine": "voxcpm_bundle7_word_timestamp_planner",
            "translation_models": list(cfg.translation_models),
            "translation_batch_max_items": cfg.translation_batch_max_items,
            "edge_tts_rate_percent_my": cfg.my.rate_percent if cfg.my.provider == "edge" else None,
            "edge_tts_rate_percent_en": cfg.en.rate_percent if cfg.en.provider == "edge" else None,
            "sync_mode": "voxcpm_exact_timestamp_parts_plus_untouched_gaps",
            "source_audio": "OFF",
            "mirror_video": cfg.mirror_video,
            "blur_original_subtitles": cfg.blur_original_subtitles,
            "blur_box": cfg.blur_box,
            "blur_box2": getattr(cfg, "blur_box2", None),
            "custom_subtitles": getattr(cfg, "burn_custom_subtitles", False),
            "branding": {
                "logo": bool(str(getattr(cfg, "logo_path", "") or "").strip()),
                "watermark": bool(str(getattr(cfg, "watermark_text", "") or "").strip()),
                "title": bool(str(getattr(cfg, "title_base", "") or "").strip()),
                "title_index": int(getattr(cfg, "title_index", 0) or 0),
            },
            "telegram_auto_send": bool(getattr(cfg, "telegram_auto_send", False)),
            "preserve_paths": [str(Path(cfg.input).resolve()), str(getattr(cfg, 'logo_path', '') or '')],
            "outputs": {},
        }
        failures = []

        # Per-language windows: translation first (large batches), then TTS, then DUB Smart Sync render.
        languages = cfg.output_languages()
        span = 69.0 / max(1, len(languages))
        stage_ranges = {
            lang: ((30 + i * span, 30 + (i + .37) * span), (30 + (i + .37) * span, 30 + (i + .86) * span),
                   (30 + (i + .86) * span, 30 + (i + 1) * span))
            for i, lang in enumerate(languages)
        }
        ctl.log("Output languages: " + " + ".join(language_label(x) for x in languages))
        background = None
        if getattr(cfg, "keep_background", False) and not cfg.dry_run:
            from .background import separate_background
            self.progress(30, "Preparing original music / effects (voices removed)")
            background = separate_background(media, cfg.input, folder, ctl, device=cfg.device)
            if background is None:
                raise RuntimeError("Requested background soundtrack is missing; resume after separation is available")
        report["background"] = {"requested": bool(cfg.keep_background), "included": background is not None,
                                "volume_percent": int(cfg.background_volume_percent), "track": str(background or "")}
        for li, lang in enumerate(languages):
            label = language_label(lang).upper()
            voice = voice_for(cfg, lang)
            ctl.log(f"[{li+1}/{len(languages)}] {label} · {voice.provider} TTS")
            rows = []
            try:
                tr_range, tts_range, render_range = stage_ranges[lang]
                atomic_json(folder / "checkpoint.json", {"status": "running", "language": lang, "stage": "batch_translation"})
                if lang == "my":
                    # Do NOT retranslate Burmese here. This is the exact Bundle(7) output.
                    translated = [
                        {
                            "id": str(seg["id"]),
                            "source_start": float(seg["start"]),
                            "source_end": float(seg["end"]),
                            "source_text": seg.get("text", ""),
                            "translated_text": exact_my_text[str(seg["id"])],
                            "text": exact_my_text[str(seg["id"])],
                        }
                        for seg in segments
                    ]
                    atomic_json(folder / "translation" / "my_voxcpm_exact.json", {
                        "schema": "voxcpm.bundle7.exact_burmese",
                        "plan_path": str(plan_path),
                        "items": translated,
                    })
                    ctl.log(f"my: using exact VoxCPM Bundle(7) Burmese translation · {len(translated)} units")
                    self.progress(tr_range[1], "MY exact VoxCPM translation ready")
                else:
                    # English grammar does not mark the speaker's gender: its cached translations stay valid.
                    source = segments if lang == "en" else _with_speakers(segments, exact_plan)
                    translated = self._translate_language(
                        folder, source, lang, story_context, translator, tr_range[0], tr_range[1])

                atomic_json(folder / "checkpoint.json", {"status": "running", "language": lang, "stage": "tts"})
                rows = self._tts_rows(
                    translated, segments, lang, speech, cache, media, tts_range[0], tts_range[1])

                logo_path = str(getattr(cfg, "logo_path", "") or "").strip()
                logo_hash = ""
                if logo_path:
                    expanded_logo = Path(os.path.expandvars(logo_path)).expanduser()
                    if expanded_logo.is_file():
                        logo_hash = file_hash(expanded_logo, ctl)

                render_key = {
                    "v": 817, "source": source_hash, "rows": rows,
                    "quality": cfg.quality, "sync": "voxcpm_exact_timestamp_sync_plus_untouched_gaps_v1_subtitle_track_branding_v4",
                    "mirror": cfg.mirror_video, "blur": cfg.blur_original_subtitles,
                    # Only a non-default volume enters the key, so existing outputs stay cached.
                    **({"voice_volume": int(cfg.voice_volume_percent)} if int(cfg.voice_volume_percent) != 100 else {}),
                    "blur_box": cfg.blur_box, "blur_box2": getattr(cfg, "blur_box2", None),
                    "custom_subtitles": getattr(cfg, "burn_custom_subtitles", False),
                    "subtitle_font": font_identity(getattr(cfg, "subtitle_font_path", "")),
                    "subtitle_size": getattr(cfg, "subtitle_font_size", 64),
                    "subtitle_x": getattr(cfg, "subtitle_x_fraction", 0.50),
                    "subtitle_y": getattr(cfg, "subtitle_y_fraction", 0.82),
                    "subtitle_width": getattr(cfg, "subtitle_width_fraction", 0.90),
                    "subtitle_style": "white_soft_darker_plate_readable_2line_v2",
                    "branding": {
                        "renderer": BRANDING_RENDER_VERSION,
                        "logo_hash": logo_hash,
                        "logo_size": float(getattr(cfg, "logo_size_fraction", .12)),
                        "logo_opacity": float(getattr(cfg, "logo_opacity", 1.0)),
                        "logo_x": float(getattr(cfg, "logo_x_fraction", .90)),
                        "logo_y": float(getattr(cfg, "logo_y_fraction", .10)),
                        "watermark_text": str(getattr(cfg, "watermark_text", "") or "").strip(),
                        "watermark_size": int(getattr(cfg, "watermark_font_size", 34)),
                        "watermark_opacity": float(getattr(cfg, "watermark_opacity", .34)),
                        "watermark_x": float(getattr(cfg, "watermark_x_fraction", .86)),
                        "watermark_y": float(getattr(cfg, "watermark_y_fraction", .92)),
                        "title_base": str(getattr(cfg, "title_base", "") or "").strip(),
                        "title_index": int(getattr(cfg, "title_index", 0) or 0),
                        "title_size": int(getattr(cfg, "title_font_size", 64)),
                        "title_duration": float(getattr(cfg, "title_duration_seconds", 5.0)),
                        "title_x": float(getattr(cfg, "title_x_fraction", .50)),
                        "title_y": float(getattr(cfg, "title_y_fraction", .12)),
                    },
                    "dry_run": cfg.dry_run,
                    "audio_hashes": [file_hash(r["audio"], ctl) for r in rows],
                    # Only present when background sounds are kept, so earlier outputs stay cached.
                    **({"background": {"volume": int(cfg.background_volume_percent),
                                       "track": [background.stat().st_size, background.stat().st_mtime_ns]}}
                       if background else {}),
                }
                result = cache.get("render", render_key)
                title_required = bool(str(getattr(cfg, "title_base", "") or "").strip())
                if result is not None and title_required and not any(
                        item.get("kind") == "title" for item in result["retime_plan"].get("branding", [])):
                    ctl.log("Cached export lacks the requested title; rebuilding the final overlay")
                    result = None
                if result is None:
                    target = cache.path("render", render_key, ".mp4")
                    self.progress(render_range[0], f"{label} DUB Smart Sync render")
                    temp, retime_plan, output_rows, encoder = render_motion_safe(
                        cfg, media, cache, rows, duration, source_hash, target, background=background)
                    if title_required and not any(item.get("kind") == "title" for item in retime_plan.get("branding", [])):
                        raise RuntimeError("Title မပါသော export ကို မထုတ်ပါ။ START / RESUME ပြန်နှိပ်ပါ။")
                    validation = validate_output(media, temp, retime_plan["output_duration"], output_rows, source_aspect)
                    os.replace(temp, target)
                    result = {"cached_video": str(target), "retime_plan": retime_plan,
                              "rows": output_rows, "validation": validation, "encoder": encoder}
                    cache.put("render", render_key, result, [target])

                output_rows = result["rows"]
                output_duration = result["retime_plan"]["output_duration"]
                name = ("DRY_RUN_" if cfg.dry_run else "") + language_file_label(lang)
                output = folder / f"{name}.mp4"
                publish(result["cached_video"], output, ctl)
                subtitle = None
                if cfg.subtitles:
                    subtitle = folder / f"{name}.srt"
                    write_srt(subtitle, output_rows)
                    result["validation"]["srt"] = validate_srt(subtitle, output_rows, output_duration)
                report["outputs"][lang] = {
                    **result, "video": str(output), "segments": output_rows,
                    "subtitle": str(subtitle) if subtitle else None, "status": "complete"}
                ctl.log(f"{label}: DONE → {output}")

                # Delivery happens only after a valid local output exists. Telegram failures
                # never invalidate translation/TTS/render caches or delete the local file.
                if getattr(cfg, "telegram_auto_send", False) and not cfg.dry_run:
                    try:
                        report["outputs"][lang]["telegram"] = telegram_send_output(
                            cfg=cfg, media=media, control=ctl, folder=folder, video=str(output),
                            lang=lang, source_title=Path(cfg.input).stem)
                    except Cancelled:
                        raise
                    except Exception as tg_exc:
                        report["outputs"][lang]["telegram"] = {
                            "status": "failed", "error": str(tg_exc)}
                        ctl.log(f"Telegram: {label} delivery failed ⚠️ · {tg_exc}")

                self.progress(render_range[1], f"{label} complete")
            except (RuntimeError, ValueError, OSError, TimeoutError) as exc:
                if isinstance(exc, Cancelled):
                    raise
                failures.append(f"{lang}: {exc}")
                ctl.log(failures[-1])
                report["outputs"][lang] = {"status": "failed", "error": str(exc), "segments": rows}
            atomic_json(folder / "alignment_report.json", report)

        report["cache"] = {"hits": cache.hits, "writes": cache.writes}
        if failures:
            atomic_json(folder / "checkpoint.json", {"status": "partial_failed", "resumable": True,
                                                     "errors": failures})
            raise RuntimeError(" | ".join(failures))
        atomic_json(folder / "checkpoint.json", {"status": "complete", "resumable": True})
        atomic_json(folder / "alignment_report.json", report)
        self.progress(100, " + ".join(language_label(x) for x in languages) + " complete")
        return report
