from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
import json
import math
import os
import re
from .fonts import DEFAULT_FONT

_PROJECT_RE = re.compile(r"^GEMINI_IMAGE_PROJECT_(\d+)_KEY$", re.I)
_FREE_EXACT = {"GEMINI_TEXT_FREE_KEY", "GEMINI_TTS_FREE_KEY"}


def gemini_key_names(path):
    """Return eligible FREE Gemini key aliases only; never expose secret values."""
    if not path:
        return []
    env_path = Path(path)
    if not env_path.is_file():
        raise ValueError("ရွေးထားတဲ့ .env ဖိုင် မတွေ့ပါ။")
    try:
        from dotenv import dotenv_values
    except ImportError:
        raise RuntimeError(".env ဖတ်ရန် python-dotenv install လုပ်ပါ။") from None
    values = dotenv_values(env_path)
    ranked = []
    for raw_name, raw_value in values.items():
        name = str(raw_name or "").strip()
        value = str(raw_value or "").strip()
        if not value:
            continue
        upper = name.upper()
        if upper in _FREE_EXACT:
            rank = 0 if upper == "GEMINI_TEXT_FREE_KEY" else 1
            ranked.append((rank, name))
            continue
        match = _PROJECT_RE.match(name)
        if match:
            ranked.append((1000 + int(match.group(1)), name))
    # Keep aliases stable, dedupe by alias here. Secret-value dedupe happens in GeminiKeyPool.
    by_name = {name: (rank, name) for rank, name in ranked}
    return [name for _, name in sorted(by_name.values())]


def voice_for(cfg, lang: str):
    """cfg.voice(lang) for a Config; plain attribute for older/simple config objects (tests)."""
    getter = getattr(cfg, "voice", None)
    return getter(lang) if callable(getter) else getattr(cfg, lang)


def load_selected_env(path, key_name="", override=False):
    """Set one FREE Gemini key as compatibility env; the pool still rotates all aliases."""
    if not path:
        return ""
    env_path = Path(path)
    if not env_path.is_file():
        raise ValueError("ရွေးထားတဲ့ .env ဖိုင် မတွေ့ပါ။")
    try:
        from dotenv import dotenv_values
    except ImportError:
        raise RuntimeError(".env ဖတ်ရန် python-dotenv install လုပ်ပါ။") from None
    values = dotenv_values(env_path)
    names = gemini_key_names(env_path)
    if not names:
        raise ValueError("ဒီ .env ထဲမှာ eligible FREE Gemini key မတွေ့ပါ။")
    selected = key_name.strip() if key_name and key_name.strip() in names else names[0]
    if override or not os.getenv("GEMINI_API_KEY"):
        os.environ["GEMINI_API_KEY"] = str(values[selected])
    return selected


def find_default_env(root: Path) -> str:
    """Prefer this project, then the user's existing recap_personal .env."""
    candidates = [
        root / ".env",
        root.parent / "recap_personal" / ".env",
        root.parent.parent / "recap_personal" / ".env",
    ]
    for path in candidates:
        if path.is_file():
            return str(path.resolve())
    return ""


@dataclass
class VoiceConfig:
    provider: str = "edge"  # edge | gemini | voxcpm
    voice: str = ""
    api_url: str = ""
    api_name: str = "/generate"
    voices_api: str = "/voices"
    model: str = "gemini-3.1-flash-tts-preview"
    engine_id: str = "voxcpm-default"
    style: str = "Natural, clear narration; steady pace; consistent voice."
    # TT Master recap Edge baseline requested by the user.
    rate_percent: int = 35
    # Male/female routing by source pitch (dubber/voice_gender.py). `voice` stays the
    # main/male voice; lines that clearly sound female use `female_voice`.
    gender_split: bool = False
    female_voice: str = ""

    def identity(self):
        data = asdict(self)
        data.pop("api_url", None)  # public Gradio URLs may rotate without changing voice identity.
        data.pop("voices_api", None)
        # Routing settings are not the voice itself; keep existing TTS caches valid.
        data.pop("gender_split", None)
        data.pop("female_voice", None)
        if self.provider != "edge":
            data.pop("rate_percent", None)
        return data


_DEFAULT_TRANSLATION_MODELS = [
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.6-flash",
    "gemini-3.7-flash",
    "gemini-3.1-flash-lite",
]


def default_voice(language: str) -> VoiceConfig:
    from .languages import get
    info = get(language)
    return VoiceConfig(voice=info["male"], female_voice=info["female"],
                       rate_percent=info["rate"], gender_split=True)


def load_voice(language: str, values: dict, *, migrate_routing: bool = False) -> VoiceConfig:
    """Migrate the old default-OFF routing once; newly saved single-voice choices stay valid."""
    from .languages import LANGUAGES
    data = dict(values)
    provider = data.get("provider", "edge")
    info = LANGUAGES.get(language, {})
    if "female_voice" not in data or (migrate_routing and not data.get("female_voice")):
        data["female_voice"] = "Kore" if provider == "gemini" else info.get("female", "") if provider == "edge" else ""
    if "gender_split" not in data or (migrate_routing and provider in {"edge", "gemini"}):
        data["gender_split"] = provider in {"edge", "gemini"} and bool(data["female_voice"])
    return VoiceConfig(**{k: v for k, v in data.items() if k in VoiceConfig.__dataclass_fields__})


@dataclass
class Config:
    input: str = ""
    # Keep outputs inside the tool by default, not beside a Desktop source video.
    output: str = "outputs"
    source_language: str = "zh"
    my: VoiceConfig = field(default_factory=lambda: default_voice("my"))
    en: VoiceConfig = field(default_factory=lambda: default_voice("en"))

    # Model-aware FREE translation fallback. Unsupported/unavailable IDs are skipped safely.
    translation_models: list[str] = field(default_factory=lambda: list(_DEFAULT_TRANSLATION_MODELS))

    # VoxCPM planner ideas ported into this dub tool: context pass + large translation batches.
    translation_batch_max_items: int = 40
    translation_batch_max_chars: int = 16000
    story_context_enabled: bool = True
    story_context_batch_max_items: int = 80
    story_context_batch_max_chars: int = 24000
    context_overlap: int = 2
    lookahead: int = 2

    env_file: str = ""
    env_key: str = ""

    quality: str = "balanced"
    device: str = "cuda"
    whisper_model: str = "medium"
    whisper_compute_type: str = "int8_float16"
    whisper_chunk_minutes: float = 10.0

    # Compatibility field only. Production render uses Bundle(7) exact timestamp Smart Sync;
    # untimestamped source gaps are the only 1.0x-kept intervals.
    dub_keep_video_when_tts_shorter: bool = True

    # Provider-specific TTS concurrency. Edge is safe/useful to parallelize; Gemini is kept serial.
    edge_tts_workers: int = 4
    voxcpm_tts_workers: int = 1
    gemini_tts_workers: int = 1

    mirror_video: bool = False
    # Final narration loudness (100 = unchanged). Applied once at the final mux with a limiter.
    voice_volume_percent: int = 100
    # Legacy Burmese/English switches (older configs). output_langs below is what the UI sets now.
    output_burmese: bool = True
    output_english: bool = True
    # Output languages (dubber/languages.py codes); made in the table's order: my, en, th, es, pt, hi ...
    output_langs: list[str] = field(default_factory=lambda: ["my", "en"])
    # Voices of the languages other than my/en, by code; missing ones come from the language table.
    voices: dict = field(default_factory=dict)
    # Keep the original music/sound effects: the source voices are removed (dubber/background.py) and
    # the rest is laid under the dub, stretched like the picture in speech parts.
    keep_background: bool = True
    background_volume_percent: int = 100
    # Before this schema, the UI saved its default-OFF switch even when the user never chose it.
    # The first load now enables automatic routing; subsequent explicit OFF choices remain OFF.
    voice_routing_version: int = 1

    def output_languages(self) -> list[str]:
        from .languages import ORDER
        chosen = set(self.output_langs or [])
        legacy_off = {code for code, on in (("my", self.output_burmese), ("en", self.output_english)) if not on}
        return [code for code in ORDER if code in chosen and code not in legacy_off]

    def voice(self, lang: str) -> "VoiceConfig":
        """The language's voice settings; a language without saved settings gets its table defaults."""
        if lang == "my":
            return self.my
        if lang == "en":
            return self.en
        from . import languages
        found = self.voices.get(lang)
        if not isinstance(found, VoiceConfig):
            if isinstance(found, dict):
                found = VoiceConfig(**{k: v for k, v in found.items() if k in VoiceConfig.__dataclass_fields__})
            else:
                info = languages.get(lang)
                found = default_voice(lang)
            self.voices[lang] = found
        return found
    blur_original_subtitles: bool = False
    # Normalized rectangle on the POST-MIRROR preview: [x, y, w, h], each 0..1.
    blur_box: list[float] | None = None
    blur_box2: list[float] | None = None
    burn_custom_subtitles: bool = True
    subtitle_font_path: str = DEFAULT_FONT
    # Subtitle visual controls. 64px is intentionally readable on 1080p/vertical video.
    subtitle_font_size: int = 64
    # Drag/drop position stores the CENTER of the subtitle plate in normalized frame coordinates.
    subtitle_x_fraction: float = 0.50
    subtitle_y_fraction: float = 0.82
    subtitle_width_fraction: float = 0.90

    # Optional branding overlays. Empty logo/text/title fields are intentionally valid
    # and simply skip that layer, so branding can be left unused without render errors.
    logo_path: str = ""
    logo_size_fraction: float = 0.12
    logo_opacity: float = 1.0
    logo_x_fraction: float = 0.90
    logo_y_fraction: float = 0.10

    watermark_text: str = ""
    watermark_font_size: int = 34
    watermark_opacity: float = 0.34
    watermark_x_fraction: float = 0.86
    watermark_y_fraction: float = 0.92

    # UI stores the common base title. Folder batch mode sets title_index=1,2,3...
    # for each file; a single-file run keeps title_index=0 and uses the base unchanged.
    title_base: str = ""
    title_index: int = 0
    title_font_size: int = 64
    title_duration_seconds: float = 5.0  # 0 = show for the full video
    title_x_fraction: float = 0.50
    title_y_fraction: float = 0.12

    # Telegram delivery. Token/chat id/API base stay only in the selected .env.
    # Cloud API is the default; set TELEGRAM_BOT_API_BASE=http://127.0.0.1:8081
    # after a local Bot API server is running to send large originals without TG-only recompression.
    telegram_auto_send: bool = False

    request_timeout: int = 360
    subtitles: bool = False
    resume: bool = True
    dry_run: bool = False

    @classmethod
    def load(cls, path):
        data = json.loads(Path(path).read_text(encoding="utf-8-sig"))

        # Backward compatibility with PATCH1–PATCH7 configs.
        if "translation_models" not in data:
            legacy_models = [
                data.get("translation_model"),
                data.get("translation_fallback_model"),
                data.get("translation_final_fallback_model"),
            ]
            legacy_models = [str(x).strip() for x in legacy_models if str(x or "").strip()]
            if legacy_models:
                for extra in _DEFAULT_TRANSLATION_MODELS:
                    if extra not in legacy_models:
                        legacy_models.append(extra)
                data["translation_models"] = legacy_models
        for obsolete in (
            "translation_model", "translation_fallback_model", "translation_final_fallback_model",
            "max_video_speed", "max_video_slow", "freeze_when_audio_longer",
            "max_visual_speedup", "max_visual_slowdown", "rewrite_attempts", "chunk_seconds",
            "max_segment_seconds", "translation_mode", "translations_json", "background_audio",
            "max_rate", "transcript_json",
        ):
            data.pop(obsolete, None)

        # V3.2 had a fixed 36px subtitle with no size control. Treat that exact
        # legacy value as the old default and migrate it to the new readable size.
        try:
            if int(data.get("subtitle_font_size", 64) or 64) == 36:
                data["subtitle_font_size"] = 64
        except Exception:
            data["subtitle_font_size"] = 64

        migrate_routing = data.get("voice_routing_version") != 1
        data["voice_routing_version"] = 1
        for lang in ("my", "en"):
            if lang in data and isinstance(data[lang], dict):
                # Old configs used +18%; the final integrated baseline is +35% unless the user
                # explicitly saved another non-18 value.
                if lang == "my" and int(data[lang].get("rate_percent", 35) or 35) == 18:
                    data[lang]["rate_percent"] = 35
                data[lang] = load_voice(lang, data[lang], migrate_routing=migrate_routing)
        if "output_langs" not in data:  # configs from before the language checkboxes
            data["output_langs"] = [code for code, flag in (("my", "output_burmese"), ("en", "output_english"))
                                    if data.get(flag, True)]
            data["output_burmese"] = data["output_english"] = True
        if isinstance(data.get("voices"), dict):
            data["voices"] = {code: load_voice(code, vc, migrate_routing=migrate_routing)
                              for code, vc in data["voices"].items() if isinstance(vc, dict)}
        clean = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        return cls(**clean)

    def save(self, path):
        Path(path).write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8")

    def validate(self):
        if not Path(self.input).is_file():
            raise ValueError("Input video file မတွေ့ပါ။")
        if self.source_language not in ("auto", "zh", "en", "ko", "ja", "th"):
            raise ValueError("Source language မမှန်ပါ။")
        if self.device not in ("cuda", "cpu", "auto"):
            raise ValueError("Device မမှန်ပါ။")
        if self.quality not in ("fast", "balanced", "high"):
            raise ValueError("Quality မမှန်ပါ။")
        if not 30 <= int(self.request_timeout) <= 900:
            raise ValueError("Gemini timeout မမှန်ပါ။")
        models = [str(x).strip() for x in self.translation_models if str(x or "").strip()]
        if not models:
            raise ValueError("Gemini translation model plan မရှိပါ။")
        self.translation_models = list(dict.fromkeys(models))
        if not 5 <= int(self.translation_batch_max_items) <= 100:
            raise ValueError("translation_batch_max_items မမှန်ပါ။")
        if not 2000 <= int(self.translation_batch_max_chars) <= 100000:
            raise ValueError("translation_batch_max_chars မမှန်ပါ။")
        if not 10 <= int(self.story_context_batch_max_items) <= 200:
            raise ValueError("story_context_batch_max_items မမှန်ပါ။")
        if not 2000 <= int(self.story_context_batch_max_chars) <= 100000:
            raise ValueError("story_context_batch_max_chars မမှန်ပါ။")
        for name in ("edge_tts_workers", "voxcpm_tts_workers", "gemini_tts_workers"):
            n = int(getattr(self, name))
            if not 1 <= n <= 8:
                raise ValueError(f"{name} မမှန်ပါ။")

        if self.blur_original_subtitles:
            boxes = [b for b in (self.blur_box, self.blur_box2) if b]
            if not boxes:
                raise ValueError("Subtitle blur ဖွင့်ထားပါက preview ပေါ်မှာ blur box အနည်းဆုံးတစ်ခု ဆွဲပါ။")
            for box in boxes:
                if len(box) != 4:
                    raise ValueError("Blur box မမှန်ပါ။")
                x, y, w, h = (float(v) for v in box)
                if any(not math.isfinite(v) for v in (x, y, w, h)) or x < 0 or y < 0 or w <= 0 or h <= 0 or x + w > 1.0001 or y + h > 1.0001:
                    raise ValueError("Blur box မမှန်ပါ။")
        if not 24 <= int(self.subtitle_font_size) <= 140:
            raise ValueError("Subtitle font size မမှန်ပါ။ (24–140 px)")
        if not 0.0 <= float(self.subtitle_x_fraction) <= 1.0:
            raise ValueError("Subtitle X position မမှန်ပါ။")
        if not 0.0 <= float(self.subtitle_y_fraction) <= 1.0:
            raise ValueError("Subtitle Y position မမှန်ပါ။")
        if not 0.40 <= float(self.subtitle_width_fraction) <= 1.0:
            raise ValueError("Subtitle width မမှန်ပါ။")

        # Branding is optional. Empty values skip cleanly; non-empty values are validated.
        self.logo_path = str(self.logo_path or "").strip()
        self.watermark_text = str(self.watermark_text or "").strip()
        self.title_base = str(self.title_base or "").strip()
        if self.logo_path and not Path(os.path.expandvars(self.logo_path)).expanduser().is_file():
            raise ValueError("Logo file မတွေ့ပါ။")
        if not 0.02 <= float(self.logo_size_fraction) <= 0.50:
            raise ValueError("Logo size မမှန်ပါ။ (2–50% video width)")
        if not 0.0 <= float(self.logo_opacity) <= 1.0:
            raise ValueError("Logo opacity မမှန်ပါ။")
        if not 12 <= int(self.watermark_font_size) <= 140:
            raise ValueError("Watermark font size မမှန်ပါ။")
        if not 0.0 <= float(self.watermark_opacity) <= 1.0:
            raise ValueError("Watermark opacity မမှန်ပါ။")
        if not 12 <= int(self.title_font_size) <= 180:
            raise ValueError("Title font size မမှန်ပါ။")
        if not 0.0 <= float(self.title_duration_seconds) <= 36000.0:
            raise ValueError("Title duration မမှန်ပါ။")
        if int(self.title_index) < 0:
            raise ValueError("Title sequence number မမှန်ပါ။")
        for name in (
            "logo_x_fraction", "logo_y_fraction",
            "watermark_x_fraction", "watermark_y_fraction",
            "title_x_fraction", "title_y_fraction",
        ):
            value = float(getattr(self, name))
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} မမှန်ပါ။")

        if not 25 <= int(self.voice_volume_percent) <= 400:
            raise ValueError("Voice volume 25%–400% ကြားထားပါ။")
        from . import languages
        unknown = [code for code in (self.output_langs or []) if code not in languages.LANGUAGES]
        if unknown:
            raise ValueError(f"Output language မမှန်ပါ: {', '.join(unknown)}")
        if not self.output_languages():
            raise ValueError("Output language အနည်းဆုံး တစ်ခု ရွေးပါ။")
        if not 0 <= int(self.background_volume_percent) <= 200:
            raise ValueError("Background volume 0%–200% ကြားထားပါ။")
        for lang in self.output_languages():
            v = self.voice(lang)
            name = languages.label(lang)
            if v.provider not in ("edge", "gemini", "voxcpm"):
                raise ValueError(f"{name}: TTS provider မမှန်ပါ။")
            if not v.voice.strip():
                raise ValueError(f"{name}: voice ရွေးပါ။")
            if not -50 <= int(v.rate_percent) <= 100:
                raise ValueError(f"{name}: speed -50% – +100% ကြားထားပါ။")
            if v.provider == "edge":
                if not languages.edge_voice_ok(lang, v.voice):
                    raise ValueError(f"{name}: Edge voice language မကိုက်ပါ။")
                if v.gender_split and v.female_voice and not languages.edge_voice_ok(lang, v.female_voice):
                    raise ValueError(f"{name}: Female Edge voice language မကိုက်ပါ။")
            if v.gender_split and not v.female_voice.strip():
                raise ValueError(f"{lang}: Male/Female split ဖွင့်ထားရင် Female voice ရွေးပါ။")
            if v.provider == "voxcpm":
                from urllib.parse import urlparse
                u = urlparse(v.api_url)
                if not self.dry_run and (u.scheme not in ("http", "https") or not u.hostname or u.username or u.password):
                    raise ValueError(f"{lang}: valid VoxCPM API URL ထည့်ပါ။")

        if not self.dry_run:
            if not self.env_file or not Path(self.env_file).is_file():
                raise ValueError("recap_personal .env ကိုရွေးပါ။")
            if not gemini_key_names(self.env_file):
                raise ValueError("eligible FREE Gemini key မတွေ့ပါ။")
            if self.telegram_auto_send:
                from .telegram_delivery import validate_telegram_env
                validate_telegram_env(self.env_file)
