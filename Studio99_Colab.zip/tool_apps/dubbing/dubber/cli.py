from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys

from .config import Config, load_selected_env
from .pipeline import Pipeline
from .runtime import Cancelled, Control


def load_own_env():
    # Never search parent/sibling projects for secrets.
    path = Path(__file__).resolve().parent.parent / ".env"
    if path.exists():
        try:
            from dotenv import load_dotenv
        except ImportError:
            raise RuntimeError("Install requirements.txt to load this tool's .env") from None
        load_dotenv(path, override=False)


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(description="Standalone Burmese + English full-video dubber")
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("ui")
    sub.add_parser("doctor")
    init = sub.add_parser("init-config")
    init.add_argument("path", nargs="?", default="config.json")
    run = sub.add_parser("run")
    run.add_argument("--config", required=True)
    run.add_argument("--dry-run", action="store_true", help="Synthetic tone timing test; no APIs")
    run.add_argument("--no-resume", action="store_true")
    run.add_argument("--stop-file", help="Create this file to cancel; remove it before resuming")
    args = p.parse_args(argv)
    try:
        if args.command == "init-config":
            if Path(args.path).exists():
                raise ValueError("Config already exists; choose a new path")
            Config().save(args.path)
            return 0
        if args.command == "doctor":
            import shutil
            load_own_env()
            packages = {}
            for name in ("numpy", "tkinter", "faster_whisper", "edge_tts", "google.genai", "gradio_client", "dotenv"):
                try:
                    packages[name] = importlib.util.find_spec(name) is not None
                except ModuleNotFoundError:
                    packages[name] = False
            try:
                from .worker import gpu_check
                gpu = gpu_check()
            except Exception as exc:
                gpu = {"ready": False, "device_count": 0,
                       "reason": f"GPU check failed: {type(exc).__name__}"}
            result = {"python": sys.version.split()[0], "packages": packages,
                      "ffmpeg": bool(shutil.which("ffmpeg") or os.getenv("FFMPEG_PATH")),
                      "ffprobe": bool(shutil.which("ffprobe") or os.getenv("FFPROBE_PATH")),
                      "gpu": gpu,
                      "gemini_key_present": bool(os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"))}
            print(json.dumps(result, indent=2))
            return 0 if all(packages.values()) and result["ffmpeg"] and result["ffprobe"] else 1
        load_own_env()
        if args.command == "ui":
            from .ui import launch
            launch()
            return 0
        cfg = Config.load(args.config)
        load_selected_env(cfg.env_file, cfg.env_key, override=True)
        cfg.dry_run = args.dry_run or cfg.dry_run
        cfg.resume = not args.no_resume and cfg.resume
        ctl = Control(stop_file=args.stop_file, log=print)
        signal.signal(signal.SIGINT, lambda *_: ctl.event.set())
        Pipeline(cfg, ctl).run()
        return 0
    except Cancelled as exc:
        print(str(exc), file=sys.stderr)
        return 130
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
