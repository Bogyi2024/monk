import os
import asyncio
import mimetypes
import re
import requests
import time 
import json 
from google import genai 
from google.genai import types 
from dotenv import load_dotenv

load_dotenv()

class AIService:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("⚠️ GEMINI_API_KEY မတွေ့ပါ! .env ဖိုင်ကို စစ်ဆေးပါ။")
        
        self._enable_proxy()
        self.client = genai.Client(api_key=self.api_key)
        self._disable_proxy()
        
        self.text_model = os.getenv('GEMINI_TEXT_MODEL', 'gemini-3.5-flash')
        self.video_model = os.getenv('GEMINI_VIDEO_MODEL', self.text_model)
        self.image_model = "imagen-4.0-generate-001"
        
        self.history_file = "downloads/drama_history.json"
        self.history_topics_file = "downloads/history_topics.json"
        
        os.makedirs("downloads", exist_ok=True)

    def _enable_proxy(self):
        pass  # networking is controlled by the OS / external VPN

    def _disable_proxy(self):
        pass  # networking is controlled by the OS / external VPN

    def _save_history(self, user_id, chat_session):
        try:
            history_data = []
            for message in chat_session.get_history():
                parts = [{"text": part.text} for part in message.parts if part.text]
                history_data.append({"role": message.role, "parts": parts})
            all_data = {}
            if os.path.exists(self.history_file):
                with open(self.history_file, 'r', encoding='utf-8') as f: all_data = json.load(f)
            all_data[user_id] = history_data
            with open(self.history_file, 'w', encoding='utf-8') as f: json.dump(all_data, f, ensure_ascii=False, indent=4)
        except Exception as e: print(f"⚠️ Drama History Error: {e}")

    def _load_history_contents(self, user_id):
        if not os.path.exists(self.history_file): return None
        try:
            with open(self.history_file, 'r', encoding='utf-8') as f: all_data = json.load(f)
            if user_id in all_data:
                return [types.Content(role=m["role"], parts=[types.Part.from_text(text=p["text"]) for p in m["parts"]]) for m in all_data[user_id]]
        except Exception as e: print(f"⚠️ Drama History Load Error: {e}")
        return None

    def _save_used_topic(self, menu, topic):
        try:
            data = {}
            if os.path.exists(self.history_topics_file):
                with open(self.history_topics_file, 'r', encoding='utf-8') as f: data = json.load(f)
            if menu not in data: data[menu] = []
            if topic not in data[menu]: data[menu].append(topic)
            with open(self.history_topics_file, 'w', encoding='utf-8') as f: json.dump(data, f, ensure_ascii=False, indent=4)
        except Exception as e: print(f"⚠️ Topic Save Error: {e}")

    def _get_used_topics(self, menu):
        if not os.path.exists(self.history_topics_file): return []
        try:
            with open(self.history_topics_file, 'r', encoding='utf-8') as f:
                return json.load(f).get(menu, [])
        except Exception as e: print(f"⚠️ Topic Load Error: {e}"); return []

    async def fetch_football_data(self, topic):
        news_api_key = os.getenv("NEWS_API_KEY")
        default_text = f"{topic} အကြောင်း အချက်အလက်များ ရှာမတွေ့ပါ။"
        default_image = "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?q=80&w=1080"
        if not news_api_key: return default_text, default_image
        try:
            url = f"https://newsapi.org/v2/everything?q={topic} football&sortBy=publishedAt&language=en&apiKey={news_api_key}"
            data = requests.get(url).json()
            if data.get("articles"):
                art = data["articles"][0]
                return f"Title: {art.get('title')}\nDesc: {art.get('description')}\nContent: {art.get('content')}", art.get('urlToImage') or default_image
            return default_text, default_image
        except Exception as e: print(f"❌ Football API Error: {e}"); return default_text, default_image

    # ==========================================
    # ✍️ ပုံမှန် TEXT POST စနစ် (စာလုံးရေ ၃၀၀ ကျော် အရှည်ကြီး ထုတ်မည်)
    # ==========================================
    async def generate_post_content(self, menu, sub_menu, topic, user_id="ko_thar_main"):
        img_prompt = None
        real_image_url = None
        strict_rule = "\n\n⚠️ စည်းကမ်းချက်: 'ခေါင်းစဉ်-' ဟုတပ်ခြင်း၊ 'ရေးပေးလိုက်ပါတယ်'၊ 'ဟုတ်ကဲ့ပါ' စသည့် အပိုစကားများ လုံးဝမပါရပါ။ Facebook တွင် တိုက်ရိုက်တင်မည့် စာသား (Caption) သက်သက်ကိုသာ တိုက်ရိုက် ရေးပေးပါ။"
        try:
            if menu == "world_history":
                prompt = f"ကမ္ဘာ့သမိုင်းအကြောင်းကို ဆွဲဆောင်မှုရှိအောင် ရေးပေးပါ။ အနည်းဆုံး မြန်မာစာလုံးရေ ၃၀၀ ကျော်ပါစေ။ ခေါင်းစဉ်: {topic} {strict_rule}"
                img_prompt = f"Historical epic cinematic illustration of {topic}, ultra detailed, 8k resolution, dramatic lighting"
            elif menu == "mm_history":
                prompt = f"မြန်မာ့သမိုင်းအကြောင်းကို ဂုဏ်ယူဖွယ်ရာကောင်းအောင် ရေးပေးပါ။ အနည်းဆုံး မြန်မာစာလုံးရေ ၃၀၀ ကျော်ပါစေ။ ခေါင်းစဉ်: {topic} {strict_rule}"
                img_prompt = f"Ancient Myanmar historical scene of {topic}, traditional Burmese architecture, majestic, cinematic lighting"
            elif menu == "motivation":
                prompt = f"ဘဝအတွက် ခွန်အားဖြစ်စေမယ့် Motivation စာသားလေး ရေးပေးပါ။ အနည်းဆုံး မြန်မာစာလုံးရေ ၃၀၀ ကျော်ပါစေ။ အကြောင်းအရာ: {topic} {strict_rule}"
                img_prompt = f"Inspiring scene representing {topic}, glowing warm light, cinematic composition, photorealistic"
            elif menu == "football":
                raw_data, real_image_url = await self.fetch_football_data(topic)
                if "foot_results" in sub_menu: prompt = f"ဂိုးရလဒ်နှင့် ပွဲအခြေအနေများကို အခြေခံ၍ ဘောလုံးသုံးသပ်ချက် ပိုစ့်ရေးပေးပါ။ အချက်အလက်: {raw_data} {strict_rule}"
                else: prompt = f"breaking news အပြောင်းအရွှေ့/သတင်း ပိုစ့်ရေးပေးပါ။ အချက်အလက်: {raw_data} {strict_rule}"
            elif menu == "drama":
                drama_instruction = "ဝါကျအဆုံးသတ်တွင် '၏၊ တယ်' မျှတအောင်သုံးပါ။ 'သည်' ကို လုံးဝမသုံးပါနဲ့။ တစ်ခါရေးလျှင် အနည်းဆုံး မြန်မာစာလုံးရေ ၈၀၀ ကျော်ပါစေ။" + strict_rule
                saved_history = self._load_history_contents(user_id)
                if saved_history is None or "drama_new" in sub_menu: prompt = f"{drama_instruction}\nဝတ္ထုအသစ်တစ်ခုကို အပိုင်း (၁) စရေးပေးပါ။ ဇာတ်လမ်းအကျဉ်း: {topic}"
                else: prompt = f"{drama_instruction}\nစောစောက ရေးလက်စ ဇာတ်လမ်းကိုပဲ အချိတ်အဆက်မိမိ နောက်တစ်ပိုင်း ဆက်ရေးပေးပါ။ အချက်အလက်: {topic}"
                img_prompt = f"Cinematic scene for a drama novel representing {topic}, emotional depth, 8k"
            elif menu == "astrology":
                prompt = f"'{topic}' အတွက် ဟောစာတမ်းကို ရေးပေးပါ။ ငွေကြေး၊ အလုပ်၊ အချစ်ရေး၊ ကျန်းမာရေးနှင့် ယတြာ သေချာပါဝင်ပါစေ။ {strict_rule}"
                if sub_menu == "sub_astro_card": img_prompt = f"Three mysterious tarot cards labeled '1', '2', '3' side-by-side on a mystic table, glowing magical atmosphere, 8k"
                else: img_prompt = f"Mystical astrology background, zodiac signs, glowing constellation, aesthetic, 8k"
            else: return {"caption": "⚠️ မသိသော Menu ဖြစ်နေသည်။", "image_prompt": None, "real_image_url": None}
            
            self._enable_proxy() 
            try:
                if menu == "drama":
                    saved_history = self._load_history_contents(user_id)
                    chat = self.client.chats.create(model=self.text_model, history=saved_history if (saved_history and "drama_new" not in sub_menu) else None)
                    response = chat.send_message(prompt)
                    self._save_history(user_id, chat)
                else: response = self.client.models.generate_content(model=self.text_model, contents=prompt)
                return {"caption": response.text, "image_prompt": img_prompt, "real_image_url": real_image_url}
            finally: self._disable_proxy()
        except Exception as e: return {"caption": f"❌ Error: {e}", "image_prompt": None, "real_image_url": None}

    # ==========================================
    # 🎬 🌟 VIDEO RECAP SCRIPT (စာလုံးရေ အထူးတိုတောင်းရမည့် စနစ်သစ်)
    # ==========================================
    async def generate_recap_script(self, raw_context_text):
        """ဗီဒီယိုထဲက Context ကို ယူပြီး စာလုံးရေ ၆၀-၈၀ အတွင်း ကွက်တိ ဇာတ်ညွှန်းတို ထုတ်ပေးရန်"""
        prompt = f"""
        မင်းက Facebook Reels / TikTok တင်မယ့် Content Creator တစ်ယောက်ပါ။
        အောက်မှာ ပေးထားတဲ့ Context ကို အခြေခံပြီး မြန်မာလို စိတ်လှုပ်ရှားစရာ ဗီဒီယို ဇာတ်ညွှန်းတို (VoiceScript) ရေးပေးပါ။
        
        [မူရင်း Context]:
        {raw_context_text}
        
        ⚠️ တင်းကြပ်သော စည်းကမ်းချက်များ (လုံးဝလိုက်နာရန် - သေရေးရှင်ရေး):
        ၁။ "ဟုတ်ကဲ့ပါ"၊ "ရေးပေးလိုက်ပါတယ်"၊ "Channel 99shorts ကနေ တင်ဆက်ပေးမှာကတော့" စသည့် မည်သည့် နိဒါန်း၊ နိဂုံး၊ နှုတ်ဆက်စကားများ လုံးဝ (လုံးဝ) မထည့်ပါနှင့်။
        ၂။ ဗီဒီယိုပေါ်မှာ စာတန်းထိုးမှာ ဖြစ်တဲ့အတွက် စာလုံးရေ အလွန်အမင်း တိုရပါမည်။ (အများဆုံး မြန်မာစာလုံးရေ ၆0 မှ ၈၀ လောက်သာ ဖြစ်ရမည်။ ဝါကျ ၂ ကြောင်း သို့မဟုတ် ၃ ကြောင်းထက် လုံးဝ မပိုစေရ။)
        ၃။ ဖတ်ရတာ ချောမွေ့ပြီး ဆွဲဆောင်မှု ရှိပါစေ။ ဝါကျအဆုံးသတ်ကို "တယ်၊ ပါတယ်" သုံးပါ။ "သည်" ကို လုံးဝ မသုံးပါနှင့်။
        ၄။ Facebook Caption ပုံစံမဟုတ်ဘဲ Edge-TTS ဖြင့် ချက်ချင်း ဖတ်ရမည့် ဇာတ်ညွှန်းစာသား သက်သက်ကိုသာ ချက်ချင်း အစပြု၍ တိုက်ရိုက် ထုတ်ပေးပါ။
        """
        self._enable_proxy()
        try:
            response = self.client.models.generate_content(model=self.text_model, contents=prompt)
            script_text = response.text.strip()
            fluff_phrases = ["ဟုတ်ကဲ့ပါ", "ရေးပေးလိုက်ပါတယ်", "ဇာတ်ညွှန်းစာသား-", "Channel 99shorts"]
            for phrase in fluff_phrases:
                script_text = script_text.replace(phrase, "")
            return script_text.strip()
        except Exception as e:
            print(f"❌ Recap Script error: {e}")
            return "စိတ်ဝင်စားဖွယ် သမိုင်းဝင် ဇာတ်လမ်းတိုလေးကို ဆက်လက်ကြည့်ရှုလိုက်ရအောင်။"
        finally: self._disable_proxy()


    # ==========================================
    # 🎞️ GEMINI VIDEO → SMART SYNC PLAN
    # ==========================================
    @staticmethod
    def _extract_json_payload(raw_text):
        """Gemini response ထဲမှ JSON object ကို code fence ပါ/မပါ ခွဲထုတ်ပေးသည်။"""
        raw_text = (raw_text or "").strip()
        if raw_text.startswith("```"):
            raw_text = re.sub(r"^```(?:json)?\s*", "", raw_text, flags=re.IGNORECASE)
            raw_text = re.sub(r"\s*```$", "", raw_text)
        try:
            return json.loads(raw_text)
        except json.JSONDecodeError:
            start = raw_text.find("{")
            end = raw_text.rfind("}")
            if start >= 0 and end > start:
                return json.loads(raw_text[start:end + 1])
            raise

    @staticmethod
    def _file_state_name(file_obj):
        state = getattr(file_obj, "state", None)
        if state is None:
            return ""
        name = getattr(state, "name", None)
        return str(name or state).upper()

    async def analyze_video_for_smart_sync(
        self,
        video_path,
        source_title="",
        min_segments=3,
        max_segments=7,
        processing_timeout_seconds=600,
    ):
        """
        Video အစစ်ကို Gemini Files API သို့ပို့ပြီး Smart-Sync JSON plan ပြန်ယူသည်။

        Return format:
        {
          "title": "...",
          "caption": "...",
          "summary": "...",
          "segments": [
            {
              "video_start": 0.0,
              "video_end": 4.5,
              "narration": "...",
              "visual_reason": "..."
            }
          ]
        }
        """
        video_path = os.path.abspath(video_path)
        if not os.path.isfile(video_path):
            raise FileNotFoundError(f"Video file မတွေ့ပါ: {video_path}")

        min_segments = max(1, int(min_segments))
        max_segments = max(min_segments, int(max_segments))

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "caption": {"type": "string"},
                "summary": {"type": "string"},
                "segments": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "video_start": {"type": "number"},
                            "video_end": {"type": "number"},
                            "narration": {"type": "string"},
                            "visual_reason": {"type": "string"},
                        },
                        "required": [
                            "video_start",
                            "video_end",
                            "narration",
                            "visual_reason",
                        ],
                    },
                },
            },
            "required": ["title", "caption", "summary", "segments"],
        }

        prompt = f"""
မင်းက Facebook Reels အတွက် မြန်မာ recap editor တစ်ယောက်ပါ။
ဒီ video ရဲ့ အသံနဲ့ ရုပ်ပုံနှစ်ခုလုံးကို လေ့လာပြီး Smart Sync plan တစ်ခုထုတ်ပါ။
မူရင်းခေါင်းစဉ်: {source_title or 'မပေးထားပါ'}

စည်းကမ်းများ:
1. Video ထဲက တကယ်မြင်ရ/ကြားရတာကိုသာ အသုံးပြုပါ။ မသေချာတာ မထည့်ပါနှင့်။
2. စိတ်ဝင်စားစရာ visual moments ကို အချိန်အစဉ်လိုက် {min_segments} မှ {max_segments} ပိုင်းရွေးပါ။
3. Segment များ မထပ်ရ။ video_start < video_end ဖြစ်ရမည်။ Decimal seconds သုံးပါ။
4. Segment တစ်ခုလျှင် အများအားဖြင့် 2–10 seconds ဖြစ်ပါစေ။ မြန်မြန်လှုပ်ရှားတဲ့ moment ကို မဖြတ်တောက်ပါနှင့်။
5. narration တစ်ခုစီက အဲဒီ visual segment နဲ့ တိတိကျကျကိုက်ညီတဲ့ မြန်မာဝါကျတို ဖြစ်ရမည်။
6. narration တွေကို ဆက်ဖတ်လိုက်ရင် ဇာတ်လမ်းတစ်ခုလို သဘာဝကျရမည်။ “သည်” မသုံးဘဲ “တယ်/ပါတယ်” သုံးပါ။
7. “ဟုတ်ကဲ့ပါ”, “ရေးပေးလိုက်ပါတယ်”, channel နာမည်နဲ့ intro/outro မထည့်ပါနှင့်။
8. caption ကို Facebook တင်လို့ရတဲ့ စာတိုအဖြစ်ရေးပြီး hashtag မထည့်ပါနှင့်။
9. title ကို တိုတိုနဲ့ curiosity ဖြစ်အောင်ရေးပါ။
10. JSON schema အတိုင်းသာ ပြန်ပေးပါ။
"""

        uploaded = None
        self._enable_proxy()
        try:
            print(f"☁️ Gemini သို့ video upload လုပ်နေပါသည်: {os.path.basename(video_path)}")
            uploaded = await asyncio.to_thread(self.client.files.upload, file=video_path)

            deadline = time.monotonic() + processing_timeout_seconds
            while True:
                state_name = self._file_state_name(uploaded)
                if state_name == "ACTIVE":
                    break
                if state_name == "FAILED":
                    raise RuntimeError("Gemini video processing FAILED ဖြစ်သွားပါသည်။")
                if time.monotonic() >= deadline:
                    raise TimeoutError("Gemini video processing အချိန်ကျော်သွားပါသည်။")
                print(f"⏳ Gemini video processing... state={state_name or 'UNKNOWN'}")
                await asyncio.sleep(5)
                uploaded = await asyncio.to_thread(self.client.files.get, name=uploaded.name)

            contents_options = [
                [uploaded, prompt],
                [
                    types.Part.from_uri(
                        file_uri=uploaded.uri,
                        mime_type=getattr(uploaded, "mime_type", None)
                        or mimetypes.guess_type(video_path)[0]
                        or "video/mp4",
                    ),
                    prompt,
                ],
            ]
            config_options = [
                {"response_format": {"text": {"mime_type": "application/json", "schema": schema}}},
                {"response_mime_type": "application/json", "response_schema": schema},
                None,
            ]

            last_error = None
            response = None
            for contents in contents_options:
                for config in config_options:
                    try:
                        kwargs = {
                            "model": self.video_model,
                            "contents": contents,
                        }
                        if config is not None:
                            kwargs["config"] = config
                        response = await asyncio.to_thread(
                            self.client.models.generate_content,
                            **kwargs,
                        )
                        if response and getattr(response, "text", None):
                            break
                    except Exception as exc:
                        last_error = exc
                        response = None
                if response and getattr(response, "text", None):
                    break

            if not response or not getattr(response, "text", None):
                raise RuntimeError(f"Gemini video analysis response မရပါ: {last_error}")

            plan = self._extract_json_payload(response.text)
            segments = plan.get("segments") or []
            cleaned_segments = []
            for item in segments:
                try:
                    start = float(item.get("video_start", 0))
                    end = float(item.get("video_end", 0))
                except (TypeError, ValueError):
                    continue
                narration = str(item.get("narration", "")).strip()
                if end <= start or not narration:
                    continue
                cleaned_segments.append({
                    "video_start": round(max(0.0, start), 3),
                    "video_end": round(max(0.0, end), 3),
                    "narration": narration,
                    "visual_reason": str(item.get("visual_reason", "")).strip(),
                })

            cleaned_segments.sort(key=lambda item: item["video_start"])
            if not cleaned_segments:
                raise RuntimeError("Gemini က valid Smart Sync segments မထုတ်ပေးပါ။")

            plan["segments"] = cleaned_segments[:max_segments]
            plan["title"] = str(plan.get("title", "")).strip()
            plan["caption"] = str(plan.get("caption", "")).strip()
            plan["summary"] = str(plan.get("summary", "")).strip()
            return plan

        finally:
            if uploaded is not None and getattr(uploaded, "name", None):
                try:
                    await asyncio.to_thread(self.client.files.delete, name=uploaded.name)
                except Exception as cleanup_error:
                    print(f"⚠️ Gemini temp file delete မအောင်မြင်ပါ: {cleanup_error}")
            self._disable_proxy()


    # ==========================================
    # 🎙️ LOCAL WHISPER TIMESTAMPS → GEMINI RECAP PLAN
    # ==========================================
    async def analyze_whisper_transcript_for_recap(
        self,
        transcript,
        source_title="",
        source_duration=0.0,
        min_segments=10,
        max_segments=14,
        coverage_mode="full",
        semantic_audit=True,
        audit_rounds=2,
        max_source_ids_per_group=3,
    ):
        """
        V5 LOSSLESS RETELL

        Local Whisper IDs/timestamps remain the timing source of truth.
        Gemini may only group consecutive Whisper IDs and rewrite their meaning
        into Burmese narrator-retell. In full mode every Whisper ID must be used
        exactly once.

        V5 adds a second-pass semantic audit:
          1) draft narration
          2) compare each group against its exact Whisper source text
          3) detect missing facts / invented facts
          4) automatically rewrite only failed groups
          5) audit corrected groups again (up to audit_rounds)
        """
        raw_segments = transcript.get("segments") or []
        if not raw_segments:
            raise ValueError("Whisper transcript segments မရှိပါ။")

        min_segments = max(1, int(min_segments))
        max_segments = max(min_segments, int(max_segments))
        audit_rounds = max(0, int(audit_rounds))
        max_source_ids_per_group = max(1, int(max_source_ids_per_group))
        coverage_mode = str(coverage_mode or "full").lower()

        # V5.2 title hardening: treat the YouTube title as optional metadata,
        # never mistake a video id / placeholder for a real source title.
        source_title_clean = str(source_title or "").strip()
        if source_title_clean.casefold() in {"", "none", "null", "n/a", "na", "youtube video", "video"}:
            source_title_clean = ""
        transcript_video_id = str(transcript.get("video_id") or "").strip()
        if transcript_video_id and source_title_clean == transcript_video_id:
            source_title_clean = ""

        compact_segments = [
            {
                "id": int(seg["id"]),
                "start": round(float(seg["start"]), 3),
                "end": round(float(seg["end"]), 3),
                "text": str(seg.get("text", "")).strip(),
            }
            for seg in raw_segments
            if str(seg.get("text", "")).strip()
        ]
        if not compact_segments:
            raise ValueError("Whisper transcript text မရှိပါ။")

        all_ids = [item["id"] for item in compact_segments]
        segment_by_id = {item["id"]: item for item in compact_segments}

        # V5.3 dynamic grouping: keep the preferred small-group size, but never
        # create a mathematically impossible rule such as 62 Whisper IDs, max 3 IDs/group,
        # and max 14 groups. In full-coverage mode, expand the per-group cap only as much
        # as necessary to fit every source ID inside effective_max_segments.
        effective_max_segments = min(max_segments, len(all_ids))
        effective_min_segments = min(min_segments, effective_max_segments)
        requested_group_cap = max_source_ids_per_group
        if coverage_mode == "full" and effective_max_segments > 0:
            required_group_cap = (len(all_ids) + effective_max_segments - 1) // effective_max_segments
            effective_source_ids_per_group = max(requested_group_cap, required_group_cap)
        else:
            effective_source_ids_per_group = requested_group_cap

        minimum_groups_from_size = (
            len(all_ids) + effective_source_ids_per_group - 1
        ) // effective_source_ids_per_group
        effective_min_segments = max(
            effective_min_segments,
            minimum_groups_from_size if coverage_mode == "full" else 1,
        )
        effective_min_segments = min(effective_min_segments, effective_max_segments)

        if effective_source_ids_per_group != requested_group_cap:
            print(
                f"🧩 Gemini V5.3 dynamic grouping: Whisper IDs={len(all_ids)}, "
                f"group cap {requested_group_cap}→{effective_source_ids_per_group}, "
                f"max groups={effective_max_segments}"
            )

        plan_schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "source_title_translation": {"type": "string"},
                "caption": {"type": "string"},
                "summary": {"type": "string"},
                "hashtags": {"type": "array", "items": {"type": "string"}},
                "segments": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "source_segment_ids": {
                                "type": "array",
                                "items": {"type": "integer"},
                            },
                            "narration": {"type": "string"},
                            "reason": {"type": "string"},
                        },
                        "required": ["source_segment_ids", "narration", "reason"],
                    },
                },
            },
            "required": [
                "title",
                "source_title_translation",
                "caption",
                "summary",
                "hashtags",
                "segments",
            ],
        }

        audit_schema = {
            "type": "object",
            "properties": {
                "overall_pass": {"type": "boolean"},
                "groups": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "source_segment_ids": {
                                "type": "array",
                                "items": {"type": "integer"},
                            },
                            "pass": {"type": "boolean"},
                            "missing_facts": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                            "invented_facts": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                            "corrected_narration": {"type": "string"},
                        },
                        "required": [
                            "source_segment_ids",
                            "pass",
                            "missing_facts",
                            "invented_facts",
                            "corrected_narration",
                        ],
                    },
                },
            },
            "required": ["overall_pass", "groups"],
        }

        transcript_json = json.dumps(compact_segments, ensure_ascii=False)
        if coverage_mode == "full":
            coverage_rule = """
FULL COVERAGE MODE:
- Whisper segment ID အားလုံးကို အစဉ်လိုက် တစ်ကြိမ်တိတိ အသုံးပြုရမည်။
- ID တစ်ခုမှ မကျန်ရ၊ မထပ်ရ။
- Group တစ်ခုထဲရှိ IDs များသည် consecutive ဖြစ်ရမည်။
- source_segment_ids ကိုသာ ပြန်ပေးပါ။ timestamp ကို ကိုယ်တိုင်မထုတ်ပါနှင့်။
"""
        else:
            coverage_rule = """
HIGHLIGHT MODE:
- စိတ်ဝင်စားဆုံး consecutive Whisper segment groups များကိုသာ ရွေးနိုင်သည်။
- source_segment_ids ကိုသာ ပြန်ပေးပါ။ timestamp ကို ကိုယ်တိုင်မထုတ်ပါနှင့်။
"""

        prompt = f"""
မင်းက Facebook Reels / TikTok အတွက် မြန်မာ narrator-retell editor တစ်ယောက်ပါ။
Local Whisper က timestamp တိတိကျကျနဲ့ source transcript ထုတ်ထားပြီးသားဖြစ်တယ်။
Whisper IDs/timestamps ကို timing source of truth အဖြစ်ယူရမယ်။

မူရင်း English/Source title: {source_title_clean or 'မပေးထားပါ'}
Source duration: {float(source_duration or 0.0):.3f} seconds
Detected language: {transcript.get('language', '')}

Whisper segments JSON:
{transcript_json}

V5 LOSSLESS RETELL RULES:
1. Timestamp မထုတ်ပါနှင့်။ source_segment_ids ပဲသုံးပါ။
2. Segment groups ကို အချိန်အစဉ်လိုက်ထားပါ။
3. Group တစ်ခုတွင် Whisper IDs အများဆုံး {effective_source_ids_per_group} ခုသာထည့်ပါ။
4. Source sentence တစ်ကြောင်းချင်းမှာပါတဲ့ meaningful fact တစ်ခုမှ မဖျက်ရ။
5. Action, dialogue meaning, reaction, relationship, location, evidence, cause/effect, result တို့ကို summary ချပြီး မပျောက်စေရ။
6. Dialogue ကို narrator က ပြန်ပြောတဲ့ပုံစံနဲ့ထည့်ပါ။ Pure summary မလုပ်ပါနှင့်။
7. Source ထဲမပါတဲ့ event, reaction, arrival, rescue, result စတာ အသစ်မတီထွင်ရ။
8. narration ကို source facts အားလုံးပါအောင်ရေးပါ။ တိုအောင်ဆိုပြီး fact မဖျက်ရ။
9. Burmese စကားပြောသဘာဝ narrator style ဖြစ်ရမယ်။ “သည်” ကိုရှောင်ပြီး “တယ်/ပါတယ်” ကိုသဘာဝကျကျသုံးပါ။
10. Group တစ်ခုရဲ့ narration ကို နောက် group ရဲ့ fact နဲ့ မရောရ။
11. Narration အားလုံးဆက်ဖတ်ရင် ဇာတ်လမ်းအဆက်မပြတ်ရမယ်။
12. title ကို transcript context + source title ရှိရင် အဲဒီ source title ကို reference အဖြစ်သုံးပြီး truthful Burmese curiosity/clickbait title ရေးပါ။ title ကို ဘယ်တော့မှ အလွတ်မထားရ။
13. Source title ကို final title အဖြစ် literal copy မလုပ်ရ။ Transcript နဲ့ကိုက်ညီတဲ့ Burmese hook title အသစ်ရေးပါ။ Clickbait ဖြစ်လို့ရပေမယ့် video ထဲမပါတာ မလိမ်ရ။ Spoiler အကုန်မဖော်ပါနှင့်။
14. source_title_translation: source title တကယ်ပေးထားမှ သဘာဝကျတဲ့ Burmese translation ပြန်ရေးပါ။ Source title မပေးထားရင် empty string "" ပဲပြန်ပေးရမယ်; title အသစ်ကို source_title_translation အဖြစ်မတီထွင်ရ။
15. caption ကို title နဲ့မတူတဲ့ 1–2 ဝါကျ Burmese hook/teaser အဖြစ်ရေးပါ။
16. hashtags 3–6 ခုသာထုတ်ပါ။
17. Group count ကို ဖြစ်နိုင်သလောက် {effective_min_segments} မှ {effective_max_segments} အတွင်းထားပါ။
{coverage_rule}
JSON schema အတိုင်းသာ ပြန်ပေးပါ။
"""

        def _validate_groups(plan):
            groups = plan.get("segments") or []
            cleaned = []
            seen = []
            valid_id_set = set(all_ids)

            for group in groups:
                ids = []
                for value in group.get("source_segment_ids") or []:
                    try:
                        ivalue = int(value)
                    except Exception:
                        continue
                    if ivalue in valid_id_set:
                        ids.append(ivalue)
                ids = sorted(dict.fromkeys(ids))
                if not ids:
                    continue
                if any(b != a + 1 for a, b in zip(ids, ids[1:])):
                    raise ValueError(f"Gemini non-consecutive IDs ပြန်ပေးသည်: {ids}")
                if len(ids) > effective_source_ids_per_group:
                    raise ValueError(
                        f"Group အရမ်းကြီးသည်: {ids}; max={effective_source_ids_per_group}"
                    )
                narration = str(group.get("narration", "")).strip()
                if not narration:
                    raise ValueError(f"Narration အလွတ်ဖြစ်နေသည်: IDs={ids}")
                cleaned.append({
                    "source_segment_ids": ids,
                    "narration": narration,
                    "reason": str(group.get("reason", "")).strip(),
                })
                seen.extend(ids)

            if not cleaned:
                raise ValueError("Gemini recap groups valid မဖြစ်ပါ။")
            if len(seen) != len(set(seen)):
                raise ValueError("Gemini segment IDs overlap ဖြစ်နေသည်။")
            if coverage_mode == "full" and seen != all_ids:
                missing = [x for x in all_ids if x not in set(seen)]
                extra = [x for x in seen if x not in set(all_ids)]
                raise ValueError(f"Full coverage မပြည့်ပါ။ missing={missing}, extra={extra}")
            if coverage_mode == "full" and len(cleaned) < effective_min_segments:
                raise ValueError(
                    f"Lossless group count နည်းလွန်းသည်: {len(cleaned)} < {effective_min_segments}"
                )
            if len(cleaned) > effective_max_segments:
                raise ValueError(
                    f"Group count များလွန်းသည်: {len(cleaned)} > {effective_max_segments}"
                )
            plan["segments"] = cleaned
            return plan

        def _source_payload_for_groups(groups):
            payload = []
            for group in groups:
                ids = [int(x) for x in group.get("source_segment_ids") or []]
                source_items = [segment_by_id[x] for x in ids if x in segment_by_id]
                payload.append({
                    "source_segment_ids": ids,
                    "source_sentences": [
                        {"id": item["id"], "text": item["text"]}
                        for item in source_items
                    ],
                    "narration": str(group.get("narration", "")).strip(),
                })
            return payload

        async def _semantic_audit_once(groups, round_number):
            audit_payload = _source_payload_for_groups(groups)
            audit_prompt = f"""
မင်းက translation/recap quality auditor တစ်ယောက်ပါ။
အောက်က group တစ်ခုချင်းမှာ English Whisper source sentence တွေနဲ့ Burmese narration ကို semantic fidelity စစ်ပါ။

AUDIT STANDARD — LOSSLESS MEANING, NOT LITERAL WORDING:
- source_sentences ထဲက plot ကိုသက်ရောက်စေသော meaningful fact တစ်ခုချင်း Burmese narration ထဲမှာ အဓိပ္ပါယ်တူစွာ ပါရမယ်။
- action, dialogue meaning, reaction, identity/relationship, location, evidence, reason, sequence, result စတဲ့ အရေးပါတဲ့ story facts မပျောက်ရ။
- source မှာမပါတဲ့ plot event/fact အသစ် မတီထွင်ရ။
- Literal translation မလိုပါ။ Natural Burmese retell, pronoun replacement, synonym, sentence merge/compression အားလုံး PASS လုပ်နိုင်တယ် — source meaning အကုန်ထိန်းထားရင်ပဲ။
- article, filler wording, discourse marker, emphasis, “soon / at that moment” စတဲ့ စကားဆက်သေးသေးများကို မထည့်ထားတာတစ်ခုတည်းနဲ့ FAIL မလုပ်ရ၊ chronology/cause ကိုပြောင်းသွားမှသာ fail လုပ်ပါ။
- “rich woman” ကို “သူဌေးမလေး/ချမ်းသာတဲ့အမျိုးသမီး” လို့ပြောင်းတာလို equivalent wording ကို FAIL မလုပ်ရ။
- missing_facts နဲ့ invented_facts နှစ်ခုလုံး အလွတ်ဖြစ်ရင် pass=true မဖြစ်မနေထားပါ။ Style preference ကြောင့် FAIL မလုပ်ရ။
- Burmese narration ဟာ narrator-retell ပုံစံဖြစ်ရမယ်။
- “သည်” ကိုရှောင်ပြီး “တယ်/ပါတယ်” သုံးပါ။
- PASS ဖြစ်ရင် corrected_narration မှာ လက်ရှိ narration ကို အဓိပ္ပါယ်မပြောင်းဘဲ ပြန်ပေးပါ။
- FAIL ဖြစ်ရင် missing_facts / invented_facts ကို တိတိကျကျရေးပြီး corrected_narration မှာ source facts အကုန်ပါအောင် Burmese narration အသစ် ပြန်ရေးပါ။
- corrected_narration ထဲမှာ source ထဲမပါတာ မထည့်ရ။

Audit round: {round_number}
Groups JSON:
{json.dumps(audit_payload, ensure_ascii=False)}

JSON schema အတိုင်းသာ ပြန်ပေးပါ။
"""
            response = await asyncio.to_thread(
                self.client.models.generate_content,
                model=self.text_model,
                contents=audit_prompt,
                config={
                    "response_mime_type": "application/json",
                    "response_schema": audit_schema,
                },
            )
            audit = self._extract_json_payload(response.text)
            audit_groups = audit.get("groups") or []
            by_key = {}
            for item in audit_groups:
                try:
                    ids = tuple(int(x) for x in (item.get("source_segment_ids") or []))
                except Exception:
                    continue
                if ids:
                    by_key[ids] = item

            result_groups = []
            failures = []
            for group in groups:
                ids = tuple(int(x) for x in group["source_segment_ids"])
                result = by_key.get(ids)
                if result is None:
                    failures.append({
                        "source_segment_ids": list(ids),
                        "missing_facts": ["Audit result missing for this group"],
                        "invented_facts": [],
                    })
                    result_groups.append(dict(group))
                    continue

                passed = bool(result.get("pass", False))
                missing = [str(x).strip() for x in (result.get("missing_facts") or []) if str(x).strip()]
                invented = [str(x).strip() for x in (result.get("invented_facts") or []) if str(x).strip()]
                corrected = str(result.get("corrected_narration", "")).strip()

                # Auditor sometimes returns pass=false for style/wording preferences even when
                # it lists no actual missing or invented fact. Treat that as a semantic PASS.
                if not missing and not invented:
                    passed = True

                updated = dict(group)
                if not passed:
                    if corrected:
                        updated["narration"] = corrected
                    failures.append({
                        "source_segment_ids": list(ids),
                        "missing_facts": missing,
                        "invented_facts": invented,
                    })
                result_groups.append(updated)

            return result_groups, failures

        self._enable_proxy()
        try:
            last_error = None
            plan = None
            for attempt in range(3):
                attempt_prompt = prompt
                if attempt > 0:
                    attempt_prompt += (
                        "\nIMPORTANT RETRY: Previous draft failed deterministic coverage/group-size validation. "
                        "Use every required Whisper ID exactly once, keep consecutive IDs, do not over-group, and do not omit facts."
                    )
                try:
                    response = await asyncio.to_thread(
                        self.client.models.generate_content,
                        model=self.text_model,
                        contents=attempt_prompt,
                        config={
                            "response_mime_type": "application/json",
                            "response_schema": plan_schema,
                        },
                    )
                    plan = self._extract_json_payload(response.text)
                    plan = _validate_groups(plan)
                    break
                except Exception as exc:
                    last_error = exc
                    print(f"⚠️ Gemini V5 draft validation attempt {attempt + 1}/3 failed: {exc}")

            if plan is None:
                raise RuntimeError(f"Gemini V5 lossless draft မရပါ: {last_error}")

            plan["title"] = str(plan.get("title", "")).strip()
            plan["source_title_translation"] = str(plan.get("source_title_translation", "")).strip()
            plan["caption"] = str(plan.get("caption", "")).strip()
            plan["summary"] = str(plan.get("summary", "")).strip()

            # Never allow Gemini to invent a "translation" when there was no source title.
            if not source_title_clean:
                plan["source_title_translation"] = ""

            # Final title is guaranteed non-empty.  Normally Gemini supplies the Burmese
            # hook title. These fallbacks are only for API/schema edge cases.
            if not plan["title"]:
                if plan["source_title_translation"]:
                    plan["title"] = plan["source_title_translation"]
                elif source_title_clean:
                    plan["title"] = source_title_clean
                elif plan["summary"]:
                    summary_parts = [x.strip() for x in re.split(r"(?<=[။!?])\s*", plan["summary"]) if x.strip()]
                    plan["title"] = summary_parts[0] if summary_parts else plan["summary"]
                else:
                    plan["title"] = "ဒီဇာတ်လမ်းမှာ ဘာတွေဖြစ်သွားတာလဲ"

            plan["hashtags"] = [
                str(tag).strip() for tag in (plan.get("hashtags") or []) if str(tag).strip()
            ]

            audit_history = []
            total_rewrites = 0
            final_failures = []

            if semantic_audit and audit_rounds > 0:
                current_groups = plan["segments"]

                # audit_rounds = normal correction rounds.  A correction produced by the
                # last normal round MUST be verified once more before we declare failure.
                max_total_audits = audit_rounds + 2
                for audit_round in range(1, max_total_audits + 1):
                    phase = "correction" if audit_round <= audit_rounds else "final verification"
                    print(
                        f"🔎 Gemini V5.1 semantic audit {phase} "
                        f"{audit_round}/{max_total_audits}..."
                    )
                    current_groups, failures = await _semantic_audit_once(current_groups, audit_round)
                    audit_history.append({
                        "round": audit_round,
                        "phase": phase,
                        "failed_groups": failures,
                        "failed_count": len(failures),
                    })
                    final_failures = failures

                    if not failures:
                        print("✅ Semantic audit PASS — source facts all covered.")
                        break

                    total_rewrites += len(failures)
                    print(f"🛠️ Semantic audit rewrote {len(failures)} group(s).")

                    if audit_round == audit_rounds:
                        print("🔁 Last normal correction applied — corrected narration ကို final verification ပြန်စစ်ပါမည်။")
                    elif audit_round > audit_rounds:
                        print("🔁 Final verification မှာ issue ကျန်သေးလို့ failed groups ကိုတစ်ကြိမ်ထပ်ပြင်ပြီး verify ဆက်လုပ်ပါမည်။")

                plan["segments"] = current_groups

            plan["semantic_audit"] = {
                "enabled": bool(semantic_audit),
                "version": "v5.1",
                "rounds_requested": audit_rounds,
                "rounds_run": len(audit_history),
                "rewrite_count": total_rewrites,
                "passed": len(final_failures) == 0 if semantic_audit else None,
                "remaining_failures": final_failures,
                "history": audit_history,
            }
            plan["timing_source"] = "local_whisper"
            plan["coverage_mode"] = coverage_mode
            plan["retell_mode"] = "lossless_v5_2_title_hardened"
            plan["source_title_used"] = source_title_clean
            plan["whisper_id_coverage"] = {
                "expected_ids": all_ids,
                "used_ids": [
                    int(x)
                    for group in plan["segments"]
                    for x in group.get("source_segment_ids", [])
                ],
                "complete": True if coverage_mode == "full" else None,
            }

            if semantic_audit and final_failures:
                # Save the corrected-but-still-failing plan so debugging never loses the
                # exact groups / facts that the auditor objected to.
                try:
                    os.makedirs("downloads", exist_ok=True)
                    with open("downloads/semantic_audit_last_failure.json", "w", encoding="utf-8") as debug_file:
                        json.dump(plan, debug_file, ensure_ascii=False, indent=2)
                    print("🧾 Audit debug saved: downloads/semantic_audit_last_failure.json")
                except Exception as debug_error:
                    print(f"⚠️ Audit debug save failed: {debug_error}")

                raise RuntimeError(
                    "Gemini V5.1 semantic audit မအောင်မြင်သေးပါ။ "
                    f"remaining failed groups={len(final_failures)}. "
                    "downloads/semantic_audit_last_failure.json ထဲမှာ exact failed facts ကိုသိမ်းထားပါတယ်။"
                )

            return plan
        finally:
            self._disable_proxy()

    async def generate_and_download_image(self, image_prompt, save_path="downloads/ai_generated_image.jpg"):
        if not image_prompt: return None
        print("🎨 Imagen 4.0 ဖြင့် ပုံစတင်ဆွဲနေပါပြီ...")
        self._enable_proxy() 
        try:
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    result = self.client.models.generate_images(model=self.image_model, prompt=image_prompt, config=dict(number_of_images=1, output_mime_type="image/jpeg"))
                    with open(save_path, 'wb') as f: f.write(result.generated_images[0].image.image_bytes)
                    print("✅ Imagen 4.0 ဖြင့် ပုံဆွဲခြင်း အောင်မြင်ပါပြီ!")
                    return save_path
                except Exception as api_error:
                    if "503" in str(api_error) and attempt < max_retries - 1:
                        print(f"⚠️ Server Busy. 10 စက္ကန့်နေလျှင် ပြန်ကြိုးစားပါမည်..."); time.sleep(10)
                    else: raise api_error
        except Exception as e: print(f"❌ Imagen Error: {e}"); raise e
        finally: self._disable_proxy()
