from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Optional


_DEFAULT_LANGUAGE = object()


class NoUsableSpeechError(RuntimeError):
    """Source downloaded correctly, but Recap cannot obtain usable speech."""


class WhisperTimestampService:
    """
    Local Whisper timestamp engine.

    Preferred backend: faster-whisper (fast, low VRAM, accurate segment/word timestamps)
    Fallback backend: openai-whisper

    Gemini never invents timestamps in V4. This service is the local timing source of truth.
    """

    def __init__(
        self,
        model_size: Optional[str] = None,
        backend: str = "auto",
        device: Optional[str] = None,
        compute_type: Optional[str] = None,
        language: Optional[str] = None,
    ) -> None:
        self.model_size = model_size or os.getenv("WHISPER_MODEL", "medium")
        self.backend = (backend or os.getenv("WHISPER_BACKEND", "auto")).lower()
        self.device = device or os.getenv("WHISPER_DEVICE", "cuda")
        self.compute_type = compute_type or os.getenv("WHISPER_COMPUTE_TYPE", "float16")
        self.language = language or os.getenv("WHISPER_LANGUAGE") or None
        self._model: Any = None
        self._active_backend: Optional[str] = None

    def _load_faster_whisper(self) -> bool:
        try:
            from faster_whisper import WhisperModel
        except Exception:
            return False

        try:
            print(
                f"🧠 Loading faster-whisper: model={self.model_size}, "
                f"device={self.device}, compute={self.compute_type}"
            )
            self._model = WhisperModel(
                self.model_size,
                device=self.device,
                compute_type=self.compute_type,
            )
            self._active_backend = "faster-whisper"
            return True
        except Exception as exc:
            print(f"⚠️ faster-whisper GPU load failed: {exc}")
            if self.device != "cpu":
                try:
                    print("↩️ faster-whisper CPU fallback (int8)")
                    self._model = WhisperModel(self.model_size, device="cpu", compute_type="int8")
                    self._active_backend = "faster-whisper"
                    self.device = "cpu"
                    self.compute_type = "int8"
                    return True
                except Exception as cpu_exc:
                    print(f"⚠️ faster-whisper CPU fallback failed: {cpu_exc}")
            return False

    def _load_openai_whisper(self) -> bool:
        try:
            import whisper
        except Exception:
            return False

        try:
            print(f"🧠 Loading openai-whisper: model={self.model_size}, device={self.device}")
            self._model = whisper.load_model(self.model_size, device=self.device)
            self._active_backend = "openai-whisper"
            return True
        except Exception as exc:
            print(f"⚠️ openai-whisper GPU load failed: {exc}")
            if self.device != "cpu":
                try:
                    self._model = whisper.load_model(self.model_size, device="cpu")
                    self._active_backend = "openai-whisper"
                    self.device = "cpu"
                    return True
                except Exception as cpu_exc:
                    print(f"⚠️ openai-whisper CPU fallback failed: {cpu_exc}")
            return False

    def _ensure_model(self) -> None:
        if self._model is not None:
            return

        backends = []
        if self.backend in {"auto", "faster", "faster-whisper"}:
            backends.append("faster")
        if self.backend in {"auto", "openai", "openai-whisper", "whisper"}:
            backends.append("openai")

        for backend in backends:
            if backend == "faster" and self._load_faster_whisper():
                return
            if backend == "openai" and self._load_openai_whisper():
                return

        raise RuntimeError(
            "Local Whisper backend မတွေ့ပါ။ faster-whisper သို့မဟုတ် openai-whisper "
            "install/config ကိုစစ်ပါ။"
        )

    @staticmethod
    def _clean_text(text: str) -> str:
        return " ".join((text or "").strip().split())

    @staticmethod
    def _fmt_clock(seconds: float) -> str:
        seconds = max(0, int(seconds or 0))
        h, rem = divmod(seconds, 3600)
        m, sec = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{sec:02d}" if h else f"{m:02d}:{sec:02d}"

    def _transcribe_faster(self, media_path: str, vad_filter: bool = True, media_duration: Optional[float] = None, language_override: Any = _DEFAULT_LANGUAGE) -> dict[str, Any]:
        # FAST-SYNC profile: keep word timestamps, but avoid expensive beam search.
        # The source audio for this workflow is English narration, so language is fixed
        # through recap_pages.json (en) unless explicitly overridden.
        kwargs: dict[str, Any] = {
            "beam_size": 1,
            "best_of": 1,
            "vad_filter": bool(vad_filter),
            "word_timestamps": True,
            "condition_on_previous_text": False,
            "temperature": 0.0,
        }
        active_language = self.language if language_override is _DEFAULT_LANGUAGE else language_override
        if active_language:
            kwargs["language"] = active_language

        segments_iter, info = self._model.transcribe(media_path, **kwargs)
        segments: list[dict[str, Any]] = []
        words_total = 0
        avg_logprob_values: list[float] = []
        no_speech_values: list[float] = []
        compression_ratio_values: list[float] = []
        next_progress = 5
        total_duration = float(media_duration or 0.0)
        for idx, seg in enumerate(segments_iter):
            text = self._clean_text(getattr(seg, "text", ""))
            start = float(getattr(seg, "start", 0.0) or 0.0)
            end = float(getattr(seg, "end", 0.0) or 0.0)
            if total_duration > 0 and end > 0:
                pct = min(99, int((end / total_duration) * 100))
                if pct >= next_progress:
                    print(
                        f"⏳ Whisper {pct:02d}% | "
                        f"{self._fmt_clock(end)} / {self._fmt_clock(total_duration)}",
                        flush=True,
                    )
                    next_progress = ((pct // 5) + 1) * 5
            if not text or end <= start:
                continue
            words = []
            for word in getattr(seg, "words", None) or []:
                w_text = self._clean_text(getattr(word, "word", ""))
                w_start = float(getattr(word, "start", start) or start)
                w_end = float(getattr(word, "end", w_start) or w_start)
                if not w_text or w_end <= w_start:
                    continue
                words.append({
                    "start": round(w_start, 3),
                    "end": round(w_end, 3),
                    "text": w_text,
                })
            words_total += len(words)

            avg_logprob = getattr(seg, "avg_logprob", None)
            no_speech_prob = getattr(seg, "no_speech_prob", None)
            compression_ratio = getattr(seg, "compression_ratio", None)
            try:
                if avg_logprob is not None:
                    avg_logprob_values.append(float(avg_logprob))
            except Exception:
                pass
            try:
                if no_speech_prob is not None:
                    no_speech_values.append(float(no_speech_prob))
            except Exception:
                pass
            try:
                if compression_ratio is not None:
                    compression_ratio_values.append(float(compression_ratio))
            except Exception:
                pass

            segments.append({
                "id": len(segments),
                "start": round(start, 3),
                "end": round(end, 3),
                "text": text,
                "words": words,
                "avg_logprob": float(avg_logprob) if avg_logprob is not None else None,
                "no_speech_prob": float(no_speech_prob) if no_speech_prob is not None else None,
                "compression_ratio": float(compression_ratio) if compression_ratio is not None else None,
            })

        return {
            "backend": "faster-whisper",
            "model": self.model_size,
            "language": getattr(info, "language", self.language or "") or "",
            "language_probability": float(getattr(info, "language_probability", 0.0) or 0.0),
            "segments": segments,
            "word_count": words_total,
            "avg_logprob": (sum(avg_logprob_values) / len(avg_logprob_values)) if avg_logprob_values else None,
            "avg_no_speech_prob": (sum(no_speech_values) / len(no_speech_values)) if no_speech_values else None,
            "avg_compression_ratio": (sum(compression_ratio_values) / len(compression_ratio_values)) if compression_ratio_values else None,
        }

    def _transcribe_openai(self, media_path: str) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "verbose": False,
            "word_timestamps": True,
            "fp16": self.device != "cpu",
        }
        if self.language:
            kwargs["language"] = self.language
        result = self._model.transcribe(media_path, **kwargs)

        segments: list[dict[str, Any]] = []
        words_total = 0
        for raw in result.get("segments") or []:
            text = self._clean_text(raw.get("text", ""))
            start = float(raw.get("start", 0.0) or 0.0)
            end = float(raw.get("end", 0.0) or 0.0)
            if not text or end <= start:
                continue
            words = []
            for word in raw.get("words") or []:
                w_text = self._clean_text(word.get("word", ""))
                w_start = float(word.get("start", start) or start)
                w_end = float(word.get("end", w_start) or w_start)
                if not w_text or w_end <= w_start:
                    continue
                words.append({
                    "start": round(w_start, 3),
                    "end": round(w_end, 3),
                    "text": w_text,
                })
            words_total += len(words)
            segments.append({
                "id": len(segments),
                "start": round(start, 3),
                "end": round(end, 3),
                "text": text,
                "words": words,
            })

        return {
            "backend": "openai-whisper",
            "model": self.model_size,
            "language": result.get("language") or self.language or "",
            "language_probability": None,
            "segments": segments,
            "word_count": words_total,
        }

    @staticmethod
    def _probe_audio_stream(media_path: str) -> Optional[bool]:
        """Return True/False when ffprobe is available, otherwise None."""
        ffprobe = shutil.which("ffprobe")
        if not ffprobe:
            return None
        try:
            result = subprocess.run(
                [
                    ffprobe,
                    "-v", "error",
                    "-select_streams", "a:0",
                    "-show_entries", "stream=index",
                    "-of", "csv=p=0",
                    media_path,
                ],
                capture_output=True,
                text=True,
                timeout=20,
                check=False,
            )
        except Exception:
            return None
        if result.returncode != 0:
            return None
        return bool((result.stdout or "").strip())


    @staticmethod
    def _assess_vad_fallback_quality(result: dict[str, Any]) -> dict[str, Any]:
        """Conservatively decide whether a VAD-OFF rescue looks like real speech.

        This guard runs ONLY after VAD=ON returned zero segments. In that state,
        tiny/repetitive VAD-OFF transcripts are commonly music/noise hallucinations.
        """
        segments = result.get("segments") or []
        transcript = " ".join(str(seg.get("text") or "") for seg in segments).strip()
        tokens = [
            token.strip(".,!?;:'\"()[]{}<>-_—–…").lower()
            for token in transcript.split()
        ]
        tokens = [token for token in tokens if token]
        meaningful = [token for token in tokens if any(ch.isalnum() for ch in token)]
        unique_ratio = (len(set(meaningful)) / len(meaningful)) if meaningful else 0.0

        spoken_seconds = 0.0
        for seg in segments:
            try:
                start = float(seg.get("start", 0.0) or 0.0)
                end = float(seg.get("end", 0.0) or 0.0)
                if end > start:
                    spoken_seconds += end - start
            except Exception:
                pass

        media_duration = float(result.get("media_duration") or 0.0)
        coverage = (spoken_seconds / media_duration) if media_duration > 0 else None
        language_probability = result.get("language_probability")
        try:
            language_probability = float(language_probability) if language_probability is not None else None
        except Exception:
            language_probability = None

        avg_logprob = result.get("avg_logprob")
        avg_no_speech_prob = result.get("avg_no_speech_prob")
        try:
            avg_logprob = float(avg_logprob) if avg_logprob is not None else None
        except Exception:
            avg_logprob = None
        try:
            avg_no_speech_prob = float(avg_no_speech_prob) if avg_no_speech_prob is not None else None
        except Exception:
            avg_no_speech_prob = None

        reasons: list[str] = []
        min_words = max(4, int(os.getenv("WHISPER_FALLBACK_MIN_WORDS", "10")))
        min_spoken_seconds = max(1.0, float(os.getenv("WHISPER_FALLBACK_MIN_SPEECH_SECONDS", "5.0")))
        min_unique_ratio = min(1.0, max(0.0, float(os.getenv("WHISPER_FALLBACK_MIN_UNIQUE_RATIO", "0.42"))))
        min_language_probability = min(1.0, max(0.0, float(os.getenv("WHISPER_FALLBACK_MIN_LANGUAGE_PROB", "0.35"))))
        min_coverage = min(1.0, max(0.0, float(os.getenv("WHISPER_FALLBACK_MIN_COVERAGE", "0.08"))))
        max_no_speech_prob = min(1.0, max(0.0, float(os.getenv("WHISPER_FALLBACK_MAX_NO_SPEECH_PROB", "0.65"))))
        min_avg_logprob = float(os.getenv("WHISPER_FALLBACK_MIN_AVG_LOGPROB", "-1.20"))

        if len(meaningful) < min_words:
            reasons.append(f"too_few_words={len(meaningful)}<{min_words}")
        if spoken_seconds < min_spoken_seconds:
            reasons.append(f"speech_seconds={spoken_seconds:.2f}<{min_spoken_seconds:.2f}")
        if len(meaningful) >= 6 and unique_ratio < min_unique_ratio:
            reasons.append(f"repetitive_unique_ratio={unique_ratio:.2f}<{min_unique_ratio:.2f}")
        if language_probability is not None and language_probability > 0 and language_probability < min_language_probability:
            reasons.append(f"language_probability={language_probability:.2f}<{min_language_probability:.2f}")
        if coverage is not None and media_duration >= 20.0 and coverage < min_coverage:
            reasons.append(f"speech_coverage={coverage:.2f}<{min_coverage:.2f}")
        if avg_no_speech_prob is not None and avg_no_speech_prob > max_no_speech_prob:
            reasons.append(f"avg_no_speech={avg_no_speech_prob:.2f}>{max_no_speech_prob:.2f}")
        if avg_logprob is not None and avg_logprob < min_avg_logprob:
            reasons.append(f"avg_logprob={avg_logprob:.2f}<{min_avg_logprob:.2f}")

        return {
            "usable": not reasons,
            "reasons": reasons,
            "word_count": len(meaningful),
            "spoken_seconds": round(spoken_seconds, 3),
            "speech_coverage": round(coverage, 4) if coverage is not None else None,
            "unique_ratio": round(unique_ratio, 4),
            "language_probability": language_probability,
            "avg_logprob": avg_logprob,
            "avg_no_speech_prob": avg_no_speech_prob,
        }


    @staticmethod
    def _norm_text(text: str) -> str:
        text = " ".join((text or "").lower().split())
        return "".join(ch for ch in text if ch.isalnum())

    @staticmethod
    def _overlap_seconds(a: dict[str, Any], b: dict[str, Any]) -> float:
        return max(0.0, min(float(a.get("end", 0.0)), float(b.get("end", 0.0))) -
                   max(float(a.get("start", 0.0)), float(b.get("start", 0.0))))

    @staticmethod
    def _clip_to_free_time(cand: dict[str, Any], occupied: list[dict[str, Any]],
                           min_duration: float = 0.25) -> Optional[dict[str, Any]]:
        """Trim a rescued segment so it never overlaps already-accepted speech.

        Rescue windows are padded 0.40 s into neighbouring speech, so a recovered
        line can start before the previous segment ends (e.g. "Kids!" 27.08-28.36
        over "...so well?" ending 27.48).  Overlapping units put words out of order
        and make the DUB render abort.  Returns None when too little free time is left.
        """
        start = float(cand.get("start", 0.0))
        end = float(cand.get("end", start))
        for old in sorted(occupied, key=lambda x: float(x.get("start", 0.0))):
            os_, oe = float(old.get("start", 0.0)), float(old.get("end", 0.0))
            if oe <= start or os_ >= end:
                continue
            if os_ <= start:
                start = max(start, oe)
            else:
                end = min(end, os_)
            if end - start < min_duration:
                return None
        if end - start < min_duration:
            return None
        out = dict(cand)
        out["start"], out["end"] = round(start, 3), round(end, 3)
        words = []
        for word in cand.get("words") or []:
            ws = max(start, float(word.get("start", start)))
            we = min(end, float(word.get("end", ws)))
            if we - ws >= 0.05:
                nw = dict(word)
                nw["start"], nw["end"] = round(ws, 3), round(we, 3)
                words.append(nw)
        if cand.get("words") and not words:
            return None
        out["words"] = words
        return out

    @classmethod
    def _near_duplicate(cls, candidate: dict[str, Any], existing: list[dict[str, Any]], radius: float = 5.0) -> bool:
        token = cls._norm_text(str(candidate.get("text") or ""))
        if not token:
            return True
        mid = (float(candidate.get("start", 0.0)) + float(candidate.get("end", 0.0))) / 2.0
        for old in existing:
            old_token = cls._norm_text(str(old.get("text") or ""))
            if not old_token:
                continue
            old_mid = (float(old.get("start", 0.0)) + float(old.get("end", 0.0))) / 2.0
            if abs(mid - old_mid) <= radius and (token == old_token or token in old_token or old_token in token):
                return True
        return False

    @staticmethod
    def _coverage_candidate_ok(seg: dict[str, Any], require_latin: bool = False) -> bool:
        text = str(seg.get("text") or "").strip()
        if not text or float(seg.get("end", 0.0)) <= float(seg.get("start", 0.0)):
            return False
        if require_latin and sum(ch.isascii() and ch.isalpha() for ch in text) < 3:
            return False
        try:
            no_speech = seg.get("no_speech_prob")
            if no_speech is not None and float(no_speech) > 0.72:
                return False
        except Exception:
            pass
        try:
            avg_logprob = seg.get("avg_logprob")
            if avg_logprob is not None and float(avg_logprob) < -1.20:
                return False
        except Exception:
            pass
        try:
            compression = seg.get("compression_ratio")
            if compression is not None and float(compression) > 2.7:
                return False
        except Exception:
            pass
        return True

    @staticmethod
    def _coverage_windows(segments: list[dict[str, Any]], duration: float,
                          min_gap: float = 1.8, tail_seconds: float = 15.0,
                          max_windows: int = 28) -> list[tuple[float, float, str]]:
        """Find transcript holes to re-listen to without changing any existing timestamp.

        The final 15 seconds are ALWAYS checked.  This matters for short end-card/system
        lines that can be omitted even when an earlier segment ends close to EOF.
        Substantial leading/internal timestamp gaps are also checked.  Smart Sync never
        sees these windows directly; it only receives any genuinely recovered speech.
        """
        duration = max(0.0, float(duration or 0.0))
        ordered = sorted(segments or [], key=lambda x: (float(x.get("start", 0.0)), float(x.get("end", 0.0))))
        windows: list[tuple[float, float, str]] = []
        if ordered:
            first = max(0.0, float(ordered[0].get("start", 0.0)))
            if first >= min_gap:
                windows.append((0.0, min(duration, first + 0.60), "LEADING_GAP"))
            prev_end = max(0.0, float(ordered[0].get("end", 0.0)))
            for seg in ordered[1:]:
                start = max(0.0, float(seg.get("start", 0.0)))
                if start - prev_end >= min_gap:
                    windows.append((max(0.0, prev_end - 0.40), min(duration, start + 0.40), "INTERNAL_GAP"))
                prev_end = max(prev_end, float(seg.get("end", 0.0)))
        elif duration > 0:
            windows.append((0.0, duration, "EMPTY_TRANSCRIPT"))

        if duration > 0:
            windows.append((max(0.0, duration - tail_seconds), duration, "EOF_TAIL"))

        priority = {"EOF_TAIL": 0, "EMPTY_TRANSCRIPT": 0, "LEADING_GAP": 1, "INTERNAL_GAP": 2}
        windows.sort(key=lambda x: (priority.get(x[2], 9), -(x[1] - x[0]), x[0]))
        selected: list[tuple[float, float, str]] = []
        for item in windows:
            a, b, reason = item
            if b - a < 0.40:
                continue
            # Exact duplicate windows are unnecessary; partial overlap is intentional,
            # especially for the mandatory EOF pass.
            if any(abs(a-x) < 0.03 and abs(b-y) < 0.03 for x,y,_ in selected):
                continue
            selected.append((a,b,reason))
            if len(selected) >= max_windows:
                break
        return selected

    @staticmethod
    def _offset_segment(seg: dict[str, Any], offset: float, window_end: float) -> dict[str, Any]:
        out = dict(seg)
        out["start"] = round(max(offset, min(window_end, float(seg.get("start", 0.0)) + offset)), 3)
        out["end"] = round(max(out["start"], min(window_end, float(seg.get("end", 0.0)) + offset)), 3)
        words = []
        for word in seg.get("words") or []:
            nw = dict(word)
            nw["start"] = round(max(offset, min(window_end, float(word.get("start", 0.0)) + offset)), 3)
            nw["end"] = round(max(nw["start"], min(window_end, float(word.get("end", 0.0)) + offset)), 3)
            words.append(nw)
        out["words"] = words
        return out

    def repair_missing_speech_coverage(self, media_path: str, result: dict[str, Any],
                                       media_duration: Optional[float]) -> dict[str, Any]:
        """Add only missed speech from gap/tail second passes; never rewrite first-pass timing/text.

        For EOF we try configured source language, auto language, and English VAD.  The
        explicit English pass is deliberate: many Chinese/Korean/Japanese clips finish
        with a short spoken UI/system phrase such as "... System activated", which a
        forced source-language Whisper pass can omit or transliterate incorrectly.
        """
        if self._active_backend != "faster-whisper" or not media_duration:
            return result
        duration = float(media_duration)
        existing = [dict(x) for x in (result.get("segments") or [])]
        windows = self._coverage_windows(existing, duration)
        if not windows:
            result["coverage_rescue_version"] = 2
            return result
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            return result

        import tempfile
        additions: list[dict[str, Any]] = []
        checked = 0
        print(f"🔎 Whisper coverage rescue: checking {len(windows)} gap/tail window(s)")
        with tempfile.TemporaryDirectory(prefix="whisper_coverage_") as td:
            for wi, (start, end, reason) in enumerate(windows, 1):
                clip = str(Path(td) / f"coverage_{wi:03d}.wav")
                proc = subprocess.run(
                    [ffmpeg, "-y", "-v", "error", "-ss", f"{start:.3f}", "-t", f"{end-start:.3f}",
                     "-i", media_path, "-vn", "-ac", "1", "-ar", "16000", clip],
                    capture_output=True, timeout=60, check=False,
                )
                if proc.returncode != 0:
                    continue
                checked += 1
                if reason == "EOF_TAIL":
                    # Prefer auto first so a code-switched final line can keep its real
                    # language. English is next because system/UI voice lines are often
                    # English; configured source language remains a fallback, not a rewrite.
                    passes: list[tuple[Any, bool, str, bool]] = [
                        (None, True, "auto+VAD", False),
                    ]
                    if (self.language or "").lower() != "en":
                        passes.append(("en", True, "en+VAD", True))
                    passes.append((_DEFAULT_LANGUAGE, True, "source+VAD", False))
                    passes.append((None, False, "auto+noVAD", False))
                else:
                    passes = [(_DEFAULT_LANGUAGE, True, "source+VAD", False)]
                    if self.language:
                        passes.append((None, True, "auto+VAD", False))

                local_additions: list[dict[str, Any]] = []
                for lang_override, use_vad, pass_name, require_latin in passes:
                    try:
                        partial = self._transcribe_faster(
                            clip, vad_filter=use_vad, media_duration=end-start,
                            language_override=lang_override,
                        )
                    except Exception as exc:
                        print(f"⚠️ Coverage {reason} {pass_name} failed: {exc}")
                        continue
                    for raw in partial.get("segments") or []:
                        cand = self._offset_segment(raw, start, end)
                        cand["coverage_reason"] = reason
                        cand["coverage_pass"] = pass_name
                        if not self._coverage_candidate_ok(cand, require_latin=require_latin):
                            continue
                        cand_dur = max(0.001, float(cand["end"]) - float(cand["start"]))
                        overlap = max((self._overlap_seconds(cand, old) for old in existing + additions + local_additions), default=0.0)
                        # Coverage rescue is additive. If most of a candidate already belongs
                        # to a first-pass segment, do not replace/retime that original segment.
                        if overlap / cand_dur > 0.55:
                            continue
                        if self._near_duplicate(cand, existing + additions + local_additions):
                            continue
                        cand = self._clip_to_free_time(cand, existing + additions + local_additions)
                        if cand is None:
                            continue
                        local_additions.append(cand)

                if local_additions:
                    local_additions.sort(key=lambda x: (float(x["start"]), float(x["end"])))
                    additions.extend(local_additions)
                    for cand in local_additions:
                        print(
                            f"✅ Coverage rescued {reason} {cand['start']:.3f}-{cand['end']:.3f}s "
                            f"[{cand.get('coverage_pass')}] {cand.get('text','')}",
                            flush=True,
                        )

        if additions:
            merged = existing + additions
            merged.sort(key=lambda x: (float(x.get("start", 0.0)), float(x.get("end", 0.0))))
            for idx, seg in enumerate(merged):
                seg["id"] = idx
            result["segments"] = merged
            result["word_count"] = sum(len(x.get("words") or []) for x in merged)
            result["coverage_rescued_segments"] = len(additions)
            print(f"✅ Whisper coverage rescue complete: +{len(additions)} missed segment(s)")
        else:
            result["coverage_rescued_segments"] = 0
            print("✅ Whisper coverage rescue complete: no confident missing speech found")
        result["coverage_windows_checked"] = checked
        result["coverage_rescue_version"] = 2
        return result

    def _rescue_eof_tail(self, media_path: str, result: dict[str, Any], media_duration: Optional[float]):
        # Backward-compatible method name. V2 now performs full gap + mandatory EOF coverage rescue.
        return self.repair_missing_speech_coverage(media_path, result, media_duration)

    def transcribe(self, media_path: str, media_duration: Optional[float] = None) -> dict[str, Any]:
        path = Path(media_path).resolve()
        if not path.exists() or not path.is_file():
            raise FileNotFoundError(f"Whisper input မတွေ့ပါ: {path}")

        audio_probe = self._probe_audio_stream(str(path))
        if audio_probe is False:
            raise NoUsableSpeechError("NO_USABLE_SPEECH: ffprobe found no audio stream in source media.")

        self._ensure_model()
        print(f"🎙️ Local Whisper timestamp transcription: {path.name}")

        if self._active_backend == "faster-whisper":
            result = self._transcribe_faster(str(path), vad_filter=True, media_duration=media_duration)
            if not result.get("segments"):
                print("⚠️ Whisper VAD=ON returned 0 segments — retrying SAME source once with VAD=OFF...")
                result = self._transcribe_faster(str(path), vad_filter=False, media_duration=media_duration)
                result["vad_fallback_used"] = True
        elif self._active_backend == "openai-whisper":
            result = self._transcribe_openai(str(path))
        else:
            raise RuntimeError("Whisper backend မရွေးရသေးပါ။")

        result = self._rescue_eof_tail(str(path), result, media_duration)

        if not result.get("segments"):
            raise NoUsableSpeechError(
                "NO_USABLE_SPEECH: Whisper returned 0 usable transcript segments after fallback."
            )

        if media_duration is not None:
            result["media_duration"] = round(float(media_duration), 3)
        else:
            result["media_duration"] = round(float(result["segments"][-1]["end"]), 3)

        result["text"] = " ".join(seg["text"] for seg in result["segments"]).strip()

        if bool(result.get("vad_fallback_used")):
            quality = self._assess_vad_fallback_quality(result)
            result["vad_fallback_quality"] = quality
            if not bool(quality.get("usable")):
                reasons = ", ".join(quality.get("reasons") or ["low_confidence_fallback_transcript"])
                print(
                    "🎵 VAD-OFF rescue rejected as likely music/noise or too-thin speech → "
                    f"{reasons}"
                )
                raise NoUsableSpeechError(
                    "MUSIC_ONLY_OR_TRANSCRIPT_TOO_THIN: " + reasons
                )
            print(
                "✅ VAD-OFF rescue passed speech-quality guard → "
                f"words={quality.get('word_count')}, "
                f"speech={quality.get('spoken_seconds')}s, "
                f"unique={quality.get('unique_ratio')}"
            )

        print(
            f"✅ Whisper done: {len(result['segments'])} segments, "
            f"language={result.get('language') or 'auto'}"
        )
        return result
