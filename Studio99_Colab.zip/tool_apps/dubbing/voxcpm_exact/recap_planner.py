from __future__ import annotations

import gc
import hashlib
import importlib.util
import json
import math
import os
import re
import difflib
import shutil
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable

LogFn = Callable[[str], None]
ProgressFn = Callable[[int, int, str], None]
PLANNER_MODE = "timestamp_translation_sentence_locked_v4_coverage_rescue_video_master"
LEGACY_PLANNER_MODES = {
    "timestamp_translation_sentence_locked_v3_video_master",
    "timestamp_translation_atomic_v2_video_master",
}
# 2026-10-07: DUB passes speaker_hints (Gemini heard who speaks each line, dubber/voice_gender.py), so
# lines are marked "(Alex Carter · male)" and the Burmese gets that speaker's words: a man had said
# "ရှင်တို့" (a woman's "you"). Without hints every prompt below is byte-for-byte the Bundle(7) one.
SPEAKER_STYLE = "speaker_gender_v1"


class GeminiKeyPoolExhaustedError(RuntimeError):
    """Every configured Gemini key was rejected by quota/auth limits."""


def _is_gemini_key_rejection(exc: BaseException) -> bool:
    text = str(exc).lower()
    return (
        "monthly spending cap" in text
        or "project-spend-caps" in text
        or "resource_exhausted" in text
        or "api_key_invalid" in text
        or "api key not valid" in text
        or "unauthenticated" in text
        or "permission_denied" in text
        or "permission denied" in text
        or bool(re.search(r"\b(?:401|403|429)\b", text))
    )


def _gemini_key_pool_message(pool_size: int) -> str:
    return (
        f"Gemini key pool ထဲက key {pool_size} ခုလုံး quota/auth error ဖြစ်နေပါတယ်။\n\n"
        "GEMINI_IMAGE_PROJECT_N_KEY / GEMINI_TEXT_FREE_KEY aliases ကို စစ်ပါ၊ "
        "သို့မဟုတ် https://ai.studio/spend မှာ project spend cap ကို တိုးပါ။\n"
        "ပြီးရင် START ကိုပြန်နှိပ်ပါ။ Whisper နဲ့ ပြီးထားတဲ့ translation checkpoint ကို "
        "ပြန်သုံးပြီး ကျန်တဲ့ batch ကနေ ဆက်လုပ်ပါမယ်။"
    )


def _configure_gemini_key_pool(
    ai: Any,
    key_pool: list[tuple[str, str]],
    *,
    client_factory: Callable[..., Any],
    log: LogFn,
    request_timeout_seconds: int = 120,
) -> None:
    """Attach Gemini clients. Key position is tracked separately for every model.

    This leaves the proven VoxCPM translation/context prompts untouched. Only the
    transport/retry layer is upgraded so per-model daily quota does not poison a
    key for a different fallback model.
    """
    if not key_pool:
        return
    timeout_seconds = max(30, min(int(request_timeout_seconds), 600))
    http_options = {
        "timeout": timeout_seconds * 1000,
        "retryOptions": {"attempts": 1},
    }

    def build_client(key: str) -> Any:
        ai._enable_proxy()
        try:
            return client_factory(api_key=key, http_options=http_options)
        finally:
            ai._disable_proxy()

    ai._recap_key_pool_entries = list(key_pool)
    ai._recap_key_index_by_model = {}
    ai._recap_client_factory = build_client
    ai._recap_key_pool_size = len(key_pool)

    def activate(model: str, key_index: int) -> None:
        key_index = max(0, min(int(key_index), len(key_pool) - 1))
        label, key = key_pool[key_index]
        ai.text_model = model
        ai.client = build_client(key)
        ai.api_key = key
        ai._recap_active_key_label = label
        ai._recap_key_index_by_model[model] = key_index
        os.environ["GEMINI_API_KEY"] = key
        os.environ["GEMINI_TEXT_MODEL"] = model

    def rotate_for_model() -> bool:
        model = str(ai.text_model)
        current = int(ai._recap_key_index_by_model.get(model, 0))
        nxt = current + 1
        if nxt >= len(key_pool):
            return False
        old_label = ai._recap_active_key_label
        activate(model, nxt)
        log(
            f"🔄 Gemini key switched from {old_label} → {ai._recap_active_key_label} "
            f"({nxt + 1}/{len(key_pool)}) for {model}"
        )
        return True

    first_model = str(getattr(ai, "text_model", "gemini-3.5-flash"))
    activate(first_model, 0)
    ai._recap_activate_model_key = activate
    ai._recap_rotate_gemini_key = rotate_for_model
    log(f"🔑 Gemini FREE key pool ready — {len(key_pool)} key(s); active: {key_pool[0][0]}")
    log(f"⏱️ Gemini request hard timeout: {timeout_seconds}s; exact VoxCPM prompts retained")


def _configure_gemini_model_fallback(ai: Any, model_plan: list[str], *, log: LogFn) -> None:
    plan = [str(x).strip() for x in model_plan if str(x or "").strip()]
    if not plan:
        plan = [str(getattr(ai, "text_model", "gemini-3.5-flash"))]
    plan = list(dict.fromkeys(plan))
    current = str(getattr(ai, "text_model", plan[0]))
    if current in plan:
        index = plan.index(current)
    else:
        plan.insert(0, current)
        index = 0
    ai._recap_model_plan = plan
    ai._recap_model_index = index

    def next_model() -> bool:
        idx = int(getattr(ai, "_recap_model_index", 0)) + 1
        if idx >= len(plan):
            return False
        old = str(ai.text_model)
        model = plan[idx]
        ai._recap_model_index = idx
        activate = getattr(ai, "_recap_activate_model_key", None)
        if callable(activate):
            # Quota is per project/model, so a new model starts from the first free key.
            activate(model, int(getattr(ai, "_recap_key_index_by_model", {}).get(model, 0)))
        else:
            ai.text_model = model
            os.environ["GEMINI_TEXT_MODEL"] = model
        log(f"🔄 Gemini model fallback: {old} → {model}")
        return True

    ai._recap_next_gemini_model = next_model
    log("🤖 Gemini model plan: " + " → ".join(plan))


def _retry_after_seconds(exc: BaseException) -> int | None:
    text = str(exc)
    for pattern in (
        r"retryDelay['\"]?\s*:\s*['\"]?(\d+)s",
        r"retry in\s+([0-9]+(?:\.[0-9]+)?)s",
    ):
        m = re.search(pattern, text, flags=re.I)
        if m:
            try:
                return max(1, min(60, int(float(m.group(1))) + 1))
            except Exception:
                pass
    return None


def _gemini_error_kind(exc: BaseException) -> str:
    text = str(exc).lower()
    if any(x in text for x in ("api_key_invalid", "api key not valid", "unauthenticated", "permission_denied", "permission denied")) or re.search(r"\b(?:401|403)\b", text):
        return "auth"
    if "429" in text or "resource_exhausted" in text:
        if any(x in text for x in (
            "perday", "per_day", "requestsperday", "requests_per_day",
            "generaterequestsperdayperprojectpermodel", "free_tier_requests, limit",
        )):
            return "quota_daily"
        return "rate_limit"
    if "503" in text or "unavailable" in text or "high demand" in text or "overloaded" in text:
        return "high_demand"
    if any(x in text for x in ("not found", "unsupported model", "model is not found", "404")):
        return "model_unavailable"
    return "other"

def _load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Python module load မရပါ: {path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


@contextmanager
def _pushd(path: Path):
    old = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(old)


def _probe_video_duration(ffprobe: str, source: Path) -> float:
    """Use the primary VIDEO stream as the source-of-truth duration.

    Some downloaded/trimmed MP4s contain a valid ~13 minute video stream but an
    accidentally long audio stream (for example ~44 minutes). format.duration then
    follows the long audio tail and makes Whisper transcribe audio that has no video.
    Recap sync is visual, so v:0 duration is authoritative.
    """
    cmd = [
        ffprobe, "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(source),
    ]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if p.returncode == 0:
        raw = (p.stdout or "").strip().splitlines()
        for line in raw:
            try:
                value = float(line.strip())
                if value > 0.05:
                    return value
            except Exception:
                pass

    # Fallback for unusual files where stream.duration is unavailable.
    p2 = subprocess.run(
        [ffprobe, "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(source)],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    if p2.returncode != 0:
        raise RuntimeError("ffprobe duration failed:\n" + (p2.stderr or p.stderr)[-3000:])
    return float((p2.stdout or "0").strip())


def _probe_audio_duration(ffprobe: str, source: Path) -> float | None:
    p = subprocess.run(
        [ffprobe, "-v", "error", "-select_streams", "a:0",
         "-show_entries", "stream=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(source)],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    if p.returncode != 0:
        return None
    for line in (p.stdout or "").strip().splitlines():
        try:
            value = float(line.strip())
            if value > 0.0:
                return value
        except Exception:
            pass
    return None


def _prepare_whisper_audio(ffmpeg: str, source: Path, job_dir: Path, video_duration: float, log: LogFn) -> Path:
    """Decode only the portion that has video into a 16 kHz mono WAV for Whisper."""
    out = job_dir / "_whisper_audio_16k.wav"
    # Reuse only if it already exists and is non-trivial. Planner mode/fingerprint
    # invalidation ensures stale transcripts from the old 44-minute logic are ignored.
    if out.is_file() and out.stat().st_size > 4096:
        log(f"♻️ Whisper trimmed audio reuse: {out.name}")
        return out
    cmd = [
        ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
        "-i", str(source), "-map", "0:a:0", "-vn",
        "-t", f"{video_duration:.6f}",
        "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(out),
    ]
    log(f"✂️ Preparing Whisper audio: trim to video duration {video_duration:.3f}s")
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if p.returncode != 0 or not out.is_file():
        raise RuntimeError("Whisper audio trim failed:\n" + (p.stderr or "")[-3000:])
    return out


def _atomic_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _source_fingerprint_for_mode(source: Path, planner_mode: str) -> str:
    st = source.stat()
    raw = json.dumps({
        "path": str(source.resolve()),
        "size": st.st_size,
        "mtime_ns": st.st_mtime_ns,
        "planner_mode": planner_mode,
    }, sort_keys=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _source_fingerprint(source: Path) -> str:
    return _source_fingerprint_for_mode(source, PLANNER_MODE)


def _fmt_ts(seconds: float) -> str:
    ms = max(0, int(round(float(seconds) * 1000)))
    h, rem = divmod(ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"


def _clean(s: Any) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip()


def _word_ends_clause(text: str) -> bool:
    return bool(re.search(r"[.!?;,:…][\"'’”)]?$", text.strip()))


_COMMON_ABBREVIATIONS = {
    "mr.", "mrs.", "ms.", "dr.", "prof.", "sr.", "jr.", "st.",
    "vs.", "etc.", "e.g.", "i.e.",
}


def _word_ends_sentence(text: str) -> bool:
    cleaned = _clean(text).lower()
    if cleaned in _COMMON_ABBREVIATIONS:
        return False
    # Whisper occasionally splits a person's name as "N." + "Ben".  Treat a
    # lone Latin initial as part of the following name instead of inventing a
    # standalone translation ID.
    if re.fullmatch(r"[a-z]\.['’\"”)]?", cleaned):
        return False
    return bool(re.search(r"[.!?…][\"'’”)]?$", cleaned))


def _word_ends_soft_clause(text: str) -> bool:
    return bool(re.search(r"[;,:][\"'’”)]?$", _clean(text)))


def _fallback_word_tokens(text: str, start: float, end: float, whisper_id: int) -> list[dict[str, Any]]:
    words = re.findall(r"\S+", _clean(text))
    if not words or end <= start:
        return []
    step = (end - start) / len(words)
    return [
        {
            "text": word,
            "start": start + index * step,
            "end": start + (index + 1) * step,
            "source_whisper_id": whisper_id,
        }
        for index, word in enumerate(words)
    ]


def _transcript_word_tokens(transcript: dict[str, Any]) -> list[dict[str, Any]]:
    """Flatten Whisper words while retaining their measured timestamps and source IDs."""
    tokens: list[dict[str, Any]] = []
    rescued: list[dict[str, Any]] = []
    for raw_index, raw in enumerate(transcript.get("segments") or []):
        text = _clean(raw.get("text"))
        start = float(raw.get("start", 0.0) or 0.0)
        end = float(raw.get("end", start) or start)
        if not text or end <= start:
            continue
        whisper_id = int(raw.get("id", raw_index))
        measured: list[dict[str, Any]] = []
        for word in raw.get("words") or []:
            wt = _clean(word.get("text"))
            ws = float(word.get("start", start) or start)
            we = float(word.get("end", ws) or ws)
            if wt and we > ws:
                measured.append({
                    "text": wt,
                    "start": ws,
                    "end": we,
                    "source_whisper_id": whisper_id,
                })
        seg_tokens = measured or _fallback_word_tokens(text, start, end, whisper_id)
        (rescued if raw.get("coverage_reason") else tokens).extend(seg_tokens)
    tokens.extend(_clip_rescued_tokens(rescued, tokens))
    tokens.sort(key=lambda item: (float(item["start"]), float(item["end"])))
    return tokens


def _plan_overlap_warning(plan: dict[str, Any], log=None, max_overlap: float = 0.5) -> bool:
    """True when a cached plan has speech units overlapping beyond render tolerance."""
    prev_end = None
    for seg in sorted(plan.get("segments") or [], key=lambda s: float(s.get("whisper_start", 0.0))):
        start = float(seg.get("whisper_start", 0.0))
        if prev_end is not None and prev_end - start > max_overlap:
            if log:
                log(f"⚠️ Cached plan has overlapping units near ID {seg.get('atomic_id')} "
                    f"({start:.3f} < {prev_end:.3f}) — rebuilding plan from cached Whisper")
            return True
        prev_end = max(prev_end or 0.0, float(seg.get("whisper_end", start)))
    return False


def _clip_rescued_tokens(rescued: list[dict[str, Any]], first_pass: list[dict[str, Any]],
                         min_duration: float = 0.08) -> list[dict[str, Any]]:
    """Keep coverage-rescue words only inside time not already owned by first-pass words.

    Older cached transcripts contain rescued segments that overlap real first-pass
    speech (the rescue window is padded 0.40 s).  Left as-is, sorting by start
    interleaves them mid-sentence and produces overlapping sentence units, which the
    DUB renderer rejects ("Overlapping timestamp units").
    """
    occupied = sorted(first_pass, key=lambda t: float(t["start"]))
    kept: list[dict[str, Any]] = []
    for token in sorted(rescued, key=lambda t: float(t["start"])):
        start, end = float(token["start"]), float(token["end"])
        for other in occupied:
            os_, oe = float(other["start"]), float(other["end"])
            if oe <= start or os_ >= end:
                continue
            if os_ <= start:
                start = max(start, oe)
            else:
                end = min(end, os_)
            if end - start < min_duration:
                break
        if end - start >= min_duration:
            item = dict(token)
            item["start"], item["end"] = start, end
            kept.append(item)
            occupied.append(item)
            occupied.sort(key=lambda t: float(t["start"]))
    return kept


def atomicize_whisper_segments(
    transcript: dict[str, Any],
    *,
    max_duration: float = 10.0,
    target_duration: float = 6.5,
    max_words: int = 24,
) -> list[dict[str, Any]]:
    """Build complete sentence/clause units from word timestamps across Whisper cuts.

    Whisper segment boundaries are acoustic and frequently end mid-sentence. Translating
    those fragments encourages Gemini to borrow the next ID's event. This reconstruction
    closes on real sentence punctuation, or on a complete soft clause when a sentence is
    long. Only a very long punctuation-free passage receives a flagged forced boundary.
    """
    tokens = _transcript_word_tokens(transcript)
    units: list[dict[str, Any]] = []
    current: list[dict[str, Any]] = []
    hard_duration = max(float(max_duration) * 2.5, 24.0)
    hard_words = max(int(max_words) * 3, 72)

    def close_current(boundary: str) -> None:
        nonlocal current
        if not current:
            return
        source_ids = list(dict.fromkeys(int(word["source_whisper_id"]) for word in current))
        units.append({
            "source_whisper_id": source_ids[0],
            "source_whisper_ids": source_ids,
            "speech_start": round(float(current[0]["start"]), 3),
            "speech_end": round(float(current[-1]["end"]), 3),
            "source_text": _clean(" ".join(str(word["text"]) for word in current)),
            "semantic_boundary": boundary,
            "forced_boundary": boundary == "forced",
        })
        current = []

    for token in tokens:
        current.append(token)
        duration = float(current[-1]["end"]) - float(current[0]["start"])
        text = str(token["text"])
        if _word_ends_sentence(text):
            close_current("sentence")
        elif duration >= float(target_duration) and _word_ends_soft_clause(text):
            close_current("clause")
        elif duration >= hard_duration or len(current) >= hard_words:
            close_current("forced")
    close_current("end_of_transcript")

    # A repeated name can also arrive as a measured 40–120 ms sentence of its
    # own (for example "Han." + "Han accidentally ...").  It is not useful as
    # narration and would create a false semantic ID, so fold only these tiny
    # one/two-token artifacts into the following complete unit.
    merged_units: list[dict[str, Any]] = []
    index = 0
    while index < len(units):
        unit = units[index]
        duration = float(unit["speech_end"]) - float(unit["speech_start"])
        token_count = len(re.findall(r"\S+", str(unit["source_text"])))
        if duration <= 0.5 and token_count <= 2 and index + 1 < len(units):
            following = dict(units[index + 1])
            left_text = _clean(unit["source_text"])
            right_text = _clean(following["source_text"])
            left_word = _comparison_text(left_text.rstrip(".!?…"))
            right_first = _comparison_text(right_text.split(maxsplit=1)[0] if right_text else "")
            combined_text = right_text if left_word and left_word == right_first else _clean(f"{left_text} {right_text}")
            following["speech_start"] = unit["speech_start"]
            following["source_text"] = combined_text
            following["source_whisper_ids"] = list(dict.fromkeys(
                list(unit["source_whisper_ids"]) + list(following["source_whisper_ids"])
            ))
            following["source_whisper_id"] = following["source_whisper_ids"][0]
            units[index + 1] = following
            index += 1
            continue
        merged_units.append(unit)
        index += 1
    units = merged_units

    for i, unit in enumerate(units, 1):
        unit["id"] = i
        unit["timestamp"] = f"{_fmt_ts(unit['speech_start'])} --> {_fmt_ts(unit['speech_end'])}"
    return units


def assign_full_coverage_boundaries(units: list[dict[str, Any]], video_duration: float) -> list[dict[str, Any]]:
    """Give every atomic narration unit a contiguous visual interval.

    Whisper speech timestamps remain stored as speech_start/speech_end. Gaps between
    spoken units are split at the midpoint so the final rendered video retains full
    source coverage without merging narration IDs.
    """
    if not units:
        return []
    out = [dict(x) for x in units]
    out[0]["video_start"] = 0.0
    for i in range(len(out) - 1):
        left = out[i]
        right = out[i + 1]
        le = float(left["speech_end"])
        rs = float(right["speech_start"])
        boundary = (le + rs) / 2.0 if rs >= le else max(le, rs)
        boundary = max(0.0, min(float(video_duration), boundary))
        left["video_end"] = round(boundary, 3)
        right["video_start"] = round(boundary, 3)
    out[-1]["video_end"] = round(float(video_duration), 3)
    for i, unit in enumerate(out):
        unit.setdefault("video_start", 0.0 if i == 0 else out[i - 1]["video_end"])
        unit.setdefault("video_end", round(float(unit["speech_end"]), 3))
    return out


def _batch_by_size(items: list[dict[str, Any]], *, max_items: int, max_chars: int) -> list[list[dict[str, Any]]]:
    batches: list[list[dict[str, Any]]] = []
    current: list[dict[str, Any]] = []
    chars = 0
    for item in items:
        cost = len(str(item.get("source_text", ""))) + 96
        if current and (len(current) >= max_items or chars + cost > max_chars):
            batches.append(current)
            current = []
            chars = 0
        current.append(item)
        chars += cost
    if current:
        batches.append(current)
    return batches


def _speaker_tag(item: dict[str, Any]) -> str:
    """'(Alex Carter · male) ' for a unit whose speaker was heard; '' otherwise (old prompt text)."""
    gender = _clean(item.get("speaker_gender"))
    if not gender:
        return ""
    name = _clean(item.get("speaker"))
    return f"({name} · {gender}) " if name else f"({gender}) "


def _source_lines(items: list[dict[str, Any]]) -> str:
    return "\n".join(
        f"[ID {int(x['id']):05d}] [{x['timestamp']}] {_speaker_tag(x)}{_clean(x['source_text'])}"
        for x in items
    )


def _translation_lines(items: list[dict[str, Any]]) -> str:
    return "\n".join(
        f"[ID {int(x['id']):05d}] [{x['timestamp']}] {_speaker_tag(x)}SOURCE: {_clean(x['source_text'])}\n"
        f"BURMESE: {_clean(x.get('translation'))}"
        for x in items
    )


# Burmese words that belong to one speaker's gender. Only clear cases: ရှင် counts as "you" at the
# start of a word (ရုပ်ရှင်, ပိုင်ရှင်, အသက်ရှင် are other words) and as a woman's ending after ပါ / တယ် ….
_WORD_START = r"(?:^|(?<=[\s\"'“‘(\[၊။!?,.…]))"
_WORD_END = r"(?=[\s\"'”’)\]၊။!?,.…]|$)"
_YOU_FOLLOWS = r"(?=တို့|ကို|က(?![ါ-ှ])|ရဲ့|ဟာ|လည်း|နဲ့|မှာ|ပဲ|လား|ကော|ရော|[\s\"'”’)\]၊။!?,.…]|$)"
_AFTER_ENDING = r"(?:(?<=ပါ)|(?<=တယ်)|(?<=နော်)|(?<=ကဲ့)|(?<=လေ))"
_WOMAN_WORDS = re.compile(
    r"ကျွန်မ(?![ါ-ှ])"            # I
    rf"|{_WORD_START}ရှင်{_YOU_FOLLOWS}"     # you
    rf"|{_WORD_START}ရှင့်"                   # your
    rf"|{_AFTER_ENDING}ရှင်{_WORD_END}"       # polite ending
)
_MAN_WORDS = re.compile(
    r"ကျွန်တော့?်"                            # I / my
    r"|ခင်ဗျ(?:ား|ာ)?"                        # you / polite ending
    rf"|{_AFTER_ENDING}ဗျာ?{_WORD_END}"       # polite ending
)


def speaker_form_issues(text: Any, gender: Any) -> list[str]:
    """Words of the other gender in one speaker's Burmese line (hints for the audit, never a hard error)."""
    words = {"male": _WOMAN_WORDS, "female": _MAN_WORDS}.get(_clean(gender).lower())
    if words is None:
        return []
    return list(dict.fromkeys(m.group(0) for m in words.finditer(_clean(text))))


def _speaker_flags(items: list[dict[str, Any]]) -> list[str]:
    flags = []
    for x in items:
        words = speaker_form_issues(x.get("translation"), x.get("speaker_gender"))
        if words:
            flags.append(f"ID {int(x['id']):05d} ({_clean(x.get('speaker_gender'))} speaker): {' / '.join(words)}")
    return flags


def _foreign_letters(text: Any) -> list[str]:
    """Letters that are neither Myanmar nor Latin outside ( ): Gemini once wrote Georgian ტ inside ကျွန်တော့်."""
    bare = re.sub(r"\([^()]*\)", "", str(text or ""))
    return list(dict.fromkeys(
        ch for ch in bare
        if ch.isalpha() and not (0x1000 <= ord(ch) <= 0x109F or 0xA9E0 <= ord(ch) <= 0xA9FF
                                 or 0xAA60 <= ord(ch) <= 0xAA7F or ord(ch) <= 0x024F
                                 or 0x1E00 <= ord(ch) <= 0x1EFF)
    ))


def _drop_foreign_letters(items: list[dict[str, Any]], log: LogFn) -> list[dict[str, Any]]:
    """Last resort after the re-asks: drop the stray letters and name the line for review."""
    out = []
    for item in items:
        letters = _foreign_letters(item.get("translation"))
        if letters:
            text = _clean("".join(ch for ch in str(item["translation"]) if ch not in letters))
            log(f"⚠️ ID {int(item['id']):05d}: removed letters of another script ({' '.join(letters)}); check this line")
            item = {**item, "translation": text}
        out.append(item)
    return out


_SPEAKER_RULE = """
12. SPEAKER: a line marked (NAME · male) or (NAME · female) is spoken by that person, and male/female is the VOICE heard in the original audio ("unsure" = not clear: decide from the story). The mark is metadata: never write it into the translation. When the line is the speaker's own words, use the Burmese of THAT speaker's gender: a man says ကျွန်တော် / ငါ for "I" and ခင်ဗျား / မင်း for "you"; a woman says ကျွန်မ / ငါ for "I" and ရှင် / နင် for "you". A man's line never uses ကျွန်မ, or ရှင် / ရှင်တို့ (a woman's "you" and ending); a woman's line never uses ကျွန်တော်, ခင်ဗျား or ဗျ; never mix both in one line. Choose the level from the relationship and the tone: anger, contempt, coldness, threats, and talk among equals or to younger people → ငါ / မင်း (man), ငါ / နင် (woman), even toward parents or elders the speaker resents; respect, pleading and polite talk to strangers or superiors → ကျွန်တော် / ခင်ဗျား (man), ကျွန်မ / ရှင် (woman). Family words such as သား, အမေ, အဖေ, အစ်ကို are fine where a Burmese speaker would use them."""

_SPEAKER_AUDIT = """
- pronouns fit the speaker's gender in ( ): a man says ကျွန်တော် / ငါ and ခင်ဗျား / မင်း; a woman says ကျွန်မ / ငါ and ရှင် / နင်. Repair a line that uses the other gender's words or mixes both (a man saying ရှင်တို့ must say မင်းတို့ or ခင်ဗျားတို့)."""


def _comparison_text(value: Any) -> str:
    return re.sub(r"[^\w\u1000-\u109f]+", "", _clean(value).lower(), flags=re.UNICODE)


def find_suspicious_adjacent_duplicates(
    items: list[dict[str, Any]],
    previous_context: list[dict[str, Any]] | None = None,
) -> list[tuple[int, int]]:
    """Find adjacent Burmese rows that repeat despite materially different sources."""
    sequence = list(previous_context[-1:] if previous_context else []) + list(items)
    suspicious: list[tuple[int, int]] = []
    for left, right in zip(sequence, sequence[1:]):
        left_tr = _comparison_text(left.get("translation"))
        right_tr = _comparison_text(right.get("translation"))
        if min(len(left_tr), len(right_tr)) < 12:
            continue
        translation_similarity = difflib.SequenceMatcher(None, left_tr, right_tr).ratio()
        if translation_similarity < 0.94:
            continue
        left_source = _comparison_text(left.get("source_text"))
        right_source = _comparison_text(right.get("source_text"))
        source_similarity = difflib.SequenceMatcher(None, left_source, right_source).ratio()
        if source_similarity < 0.86:
            suspicious.append((int(left["id"]), int(right["id"])))
    return suspicious


def _assert_no_adjacent_translation_duplicates(
    items: list[dict[str, Any]],
    previous_context: list[dict[str, Any]] | None = None,
) -> None:
    pairs = find_suspicious_adjacent_duplicates(items, previous_context)
    if pairs:
        labels = ", ".join(f"{left}/{right}" for left, right in pairs)
        raise ValueError(f"Suspicious adjacent duplicate Burmese translation IDs: {labels}")


def _extract_json_payload(raw_text: str) -> Any:
    raw = (raw_text or "").strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.IGNORECASE)
        raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        for opener, closer in (("{", "}"), ("[", "]")):
            a, b = raw.find(opener), raw.rfind(closer)
            if a >= 0 and b > a:
                try:
                    return json.loads(raw[a:b + 1])
                except json.JSONDecodeError:
                    pass
        raise


def _gemini_json(ai: Any, prompt: str, *, retries: int = 3, log: LogFn | None = None) -> Any:
    """Exact VoxCPM JSON request with model-aware FREE fallback.

    Prompt/content logic is intentionally unchanged; only request routing differs.
    """
    last: Exception | None = None
    validation_attempt = 1
    transient_attempt = 0
    while validation_attempt <= retries:
        try:
            ai._enable_proxy()
            try:
                response = ai.client.models.generate_content(model=ai.text_model, contents=prompt)
            finally:
                ai._disable_proxy()
            return _extract_json_payload(getattr(response, "text", ""))
        except Exception as exc:
            last = exc
            kind = _gemini_error_kind(exc)
            active = str(getattr(ai, "_recap_active_key_label", "GEMINI_API_KEY"))
            model = str(getattr(ai, "text_model", "gemini"))

            if kind in {"auth", "quota_daily"}:
                rotate = getattr(ai, "_recap_rotate_gemini_key", None)
                if callable(rotate) and rotate():
                    if log:
                        log(f"⚠️ {kind} on {active} / {model}; retry exact same VoxCPM prompt with next key")
                    transient_attempt = 0
                    continue
                nxt = getattr(ai, "_recap_next_gemini_model", None)
                if callable(nxt) and nxt():
                    if log:
                        log(f"⚠️ {model} key pool exhausted for {kind}; trying next model with fresh per-model key state")
                    transient_attempt = 0
                    continue
                pool_size = int(getattr(ai, "_recap_key_pool_size", 1) or 1)
                raise GeminiKeyPoolExhaustedError(_gemini_key_pool_message(pool_size)) from exc

            if kind == "rate_limit":
                waits = []
                retry_after = _retry_after_seconds(exc)
                if retry_after is not None:
                    waits.append(retry_after)
                waits.extend([5, 12])
                waits = waits[:2]
                if transient_attempt < len(waits):
                    wait = waits[transient_attempt]
                    transient_attempt += 1
                    if log:
                        log(f"⚠️ Gemini 429 temporary on {active} / {model}; same key retry in {wait}s ({transient_attempt}/{len(waits)})")
                    time.sleep(wait)
                    continue
                nxt = getattr(ai, "_recap_next_gemini_model", None)
                if callable(nxt) and nxt():
                    transient_attempt = 0
                    continue

            if kind == "high_demand":
                waits = (3, 8, 20)
                if transient_attempt < len(waits):
                    wait = waits[transient_attempt]
                    transient_attempt += 1
                    if log:
                        log(f"⚠️ Gemini 503/high demand on {active} / {model}; key kept, backoff {wait}s ({transient_attempt}/3)")
                    time.sleep(wait)
                    continue
                nxt = getattr(ai, "_recap_next_gemini_model", None)
                if callable(nxt) and nxt():
                    transient_attempt = 0
                    continue

            if kind == "model_unavailable":
                nxt = getattr(ai, "_recap_next_gemini_model", None)
                if callable(nxt) and nxt():
                    transient_attempt = 0
                    continue

            if log:
                log(f"⚠️ Gemini JSON attempt {validation_attempt}/{retries} failed on {model}: {exc}")
            if validation_attempt < retries:
                time.sleep(1.2 * validation_attempt)
            validation_attempt += 1
            transient_attempt = 0
    raise RuntimeError(f"Gemini JSON response failed after {retries} attempts: {last}")

def _load_runtime_config(runtime_root: Path) -> dict[str, Any]:
    path = runtime_root / "config" / "recap_pages.json"
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def build_story_context(
    ai: Any,
    units: list[dict[str, Any]],
    *,
    batch_max_items: int,
    log: LogFn,
    should_stop: Callable[[], bool],
    checkpoint_path: Path | None = None,
    source_fingerprint: str = "",
    reuse: bool = True,
) -> dict[str, Any]:
    """Create durable context memory in a separate pass before translation, resumably."""
    batches = _batch_by_size(units, max_items=batch_max_items, max_chars=24000)
    memory: dict[str, Any] = {
        "characters": [], "relationships": [], "places": [], "terms": [],
        "plot_state": [], "name_consistency": [], "unresolved": []
    }
    completed = 0
    if reuse and checkpoint_path and checkpoint_path.is_file():
        try:
            saved = json.loads(checkpoint_path.read_text(encoding="utf-8"))
            if saved.get("planner_mode") == PLANNER_MODE and saved.get("source_fingerprint") == source_fingerprint:
                completed = int(saved.get("completed_batches", 0) or 0)
                saved_memory = saved.get("context")
                if 0 <= completed <= len(batches) and isinstance(saved_memory, dict):
                    memory = saved_memory
                    if completed:
                        log(f"♻️ Story Context resume — {completed}/{len(batches)} batches already done")
                else:
                    completed = 0
        except Exception:
            completed = 0
    for i, batch in enumerate(batches, 1):
        if i <= completed:
            continue
        if should_stop():
            raise InterruptedError("STOP requested during story-context pass")
        prompt = f"""
You are building CONTEXT MEMORY for a later translation task.
Do not translate the transcript now. Do not write narration. Do not summarize away named facts.
Read this next chronological source chunk and UPDATE the existing compact context memory.
The memory exists only to keep names, relationships, terminology, locations, identities,
and the current story state consistent when later translation requests are sent in separate API calls.

RULES:
- Preserve exact character/place/object names as they appear in the source when known.
- Keep important relationships, aliases, roles, reveals, and terminology.
- Keep plot_state chronological but compact. Do not invent anything.
- If an earlier assumption is corrected by this chunk, update it.
- Return JSON only with these keys:
  characters, relationships, places, terms, plot_state, name_consistency, unresolved
- Each key must contain a compact JSON array. Keep the total memory concise enough to reuse in every later request.

EXISTING MEMORY:
{json.dumps(memory, ensure_ascii=False)}

SOURCE CHUNK {i}/{len(batches)}:
{_source_lines(batch)}
"""
        data = _gemini_json(ai, prompt, log=log)
        if not isinstance(data, dict):
            raise RuntimeError("Story context response must be a JSON object")
        memory = {
            "characters": list(data.get("characters") or []),
            "relationships": list(data.get("relationships") or []),
            "places": list(data.get("places") or []),
            "terms": list(data.get("terms") or []),
            "plot_state": list(data.get("plot_state") or []),
            "name_consistency": list(data.get("name_consistency") or []),
            "unresolved": list(data.get("unresolved") or []),
        }
        if checkpoint_path:
            _atomic_json(checkpoint_path, {
                "planner_mode": PLANNER_MODE,
                "source_fingerprint": source_fingerprint,
                "completed_batches": i,
                "total_batches": len(batches),
                "context": memory,
            })
        log(f"🧠 Story Context {i}/{len(batches)} updated")
    return memory


def _validate_translation_items(
    source_batch: list[dict[str, Any]],
    payload: Any,
    *,
    log: LogFn | None = None,
) -> list[dict[str, Any]]:
    items = payload.get("items") if isinstance(payload, dict) else None
    if not isinstance(items, list):
        raise ValueError("Translation response must contain an items array")
    expected = [int(x["id"]) for x in source_batch]
    got: list[int] = []
    by_id: dict[int, dict[str, Any]] = {}
    for item in items:
        if not isinstance(item, dict):
            continue
        try:
            uid = int(item.get("id"))
        except Exception:
            continue
        if uid in by_id:
            raise ValueError(f"Duplicate translation ID: {uid}")
        tr = _clean(item.get("translation"))
        if not tr:
            raise ValueError(f"Empty translation ID: {uid}")
        by_id[uid] = item
        got.append(uid)
    if got != expected:
        raise ValueError(f"ID mismatch. expected={expected[:3]}...{expected[-3:]} got={got[:3]}...{got[-3:]}")
    out = []
    for src in source_batch:
        uid = int(src["id"])
        raw = by_id[uid]
        # Gemini does not own timing. Older/cached prompt variants may still return a
        # timestamp and models occasionally typo or copy a neighbouring row's value.
        # Never let that discard an otherwise ID-complete translation batch: the
        # locally measured Whisper timestamp remains authoritative in ``src``.
        returned_ts = _clean(raw.get("timestamp"))
        if returned_ts and returned_ts != src["timestamp"] and log:
            log(
                f"ℹ️ Ignored Gemini timestamp for ID {uid}: {returned_ts}; "
                f"using local {src['timestamp']}"
            )
        out.append({**src, "translation": _clean(raw.get("translation"))})
    return out


def translate_batch(
    ai: Any,
    *,
    story_context: dict[str, Any],
    previous_context: list[dict[str, Any]],
    current: list[dict[str, Any]],
    next_context: list[dict[str, Any]],
    log: LogFn,
) -> list[dict[str, Any]]:
    speaker_rule = _SPEAKER_RULE if any(_speaker_tag(x) for x in current) else ""
    prompt = f"""
You are a CONTEXT-AWARE BURMESE NARRATION TRANSLATOR.
This is a TRANSLATION task, but it must NOT sound like a literal machine translation.
Translate ONLY the CURRENT ITEMS into smooth, natural spoken Burmese that sounds as if it was originally written by a fluent Burmese movie/story narrator.

CORE PRINCIPLE:
Preserve the SOURCE MEANING and VISUAL EVENTS 100%, NOT the original English wording or sentence structure.

CONTENT OWNERSHIP:
Context is READ-ONLY. Each CURRENT ID owns only the actions, people, objects, dialogue,
and facts written in that ID's SOURCE. Never finish an incomplete idea by borrowing an
event from the next ID, never move an event into the previous ID, and never compensate
near the end of the batch by duplicating or compressing another ID.

HARD RULES — MUST FOLLOW:
1. Do NOT remove, condense away, or omit meaningful source information. Every action, event, object, person, relationship, cause/effect, and important visual detail in EACH source item must remain in that same item's Burmese translation.
2. Do NOT translate word-for-word when the result sounds stiff, unnatural, overly formal, or machine-like in Burmese. You MAY freely restructure wording and clause order INSIDE THE SAME ID to make the narration flow naturally.
3. Use expressions a real Burmese narrator would naturally say. Use natural Burmese connectors and transitions where needed.
4. Small expansion is allowed ONLY when it improves clarity or natural spoken flow. Do NOT exaggerate intensity, drama, quantity, or meaning. Do NOT add unrelated filler.
5. Do not invent new plot events, opinions, hooks, intros, outros, or facts that are not supported by the source/context.
6. Keep every CURRENT ID exactly once. Do not delete IDs. Do not merge IDs. Do not split an ID into new IDs. Do not reorder IDs.
7. Timestamps are LOCAL-ONLY metadata. Do NOT return, rewrite, infer, or copy timestamps in your JSON. Return only each ID and its Burmese translation.
8. PREVIOUS CONTEXT and NEXT CONTEXT are context only. Do NOT copy or translate their events into a CURRENT ID. STORY CONTEXT is memory only.
9. Maintain consistent character names, relationships, places, objects, and terminology across batches.
10. Prefer conversational narrator Burmese over awkward literal phrases. Example principle: an English phrase such as “the situation escalates into a more explosive development” should become a natural meaning-preserving Burmese narration such as “အဲ့ဒီနောက်မှာတော့ အခြေအနေက ရုတ်တရက် ပိုပြီးဆိုးရွားလာပါတော့တယ်” when that matches the context — not a word-for-word phrase like “ပေါက်ကွဲအားပြင်းတဲ့ ဖြစ်ပေါ်တိုးတက်မှု”.
11. Return JSON ONLY in exactly this shape (NO timestamp field):
{{"items":[{{"id":1,"translation":"..."}}]}}{speaker_rule}

STORY CONTEXT MEMORY:
{json.dumps(story_context, ensure_ascii=False)}

PREVIOUS CONTEXT (context only):
{_translation_lines(previous_context) if previous_context else '(none)'}

CURRENT ITEMS — TRANSLATE ALL OF THESE, ONE-FOR-ONE:
{_source_lines(current)}

NEXT CONTEXT (look-ahead only):
{_source_lines(next_context) if next_context else '(none)'}
"""
    last: Exception | None = None
    for attempt in range(1, 4):
        try:
            payload = _gemini_json(ai, prompt, retries=1, log=log)
            translated = _validate_translation_items(current, payload, log=log)
            _assert_no_adjacent_translation_duplicates(translated, previous_context)
            stray = [f"ID {int(x['id']):05d}: {' '.join(_foreign_letters(x['translation']))}"
                     for x in translated if _foreign_letters(x["translation"])]
            if stray and attempt < 3:  # the last answer is kept; build() drops the letters and logs the line
                raise ValueError("letters of another script inside the Burmese (" + "; ".join(stray) +
                                 "); write every word in Burmese script")
            return translated
        except GeminiKeyPoolExhaustedError:
            raise
        except Exception as exc:
            last = exc
            log(f"⚠️ Translation validation attempt {attempt}/3 failed: {exc}")
            prompt += f"\n\nCORRECTION REQUIRED: Previous response was invalid because: {exc}. Return the full CURRENT batch again, following every rule exactly."
    raise RuntimeError(f"Translation batch could not be validated: {last}")


def audit_and_repair_batch(
    ai: Any,
    translated: list[dict[str, Any]],
    *,
    story_context: dict[str, Any],
    previous_context: list[dict[str, Any]] | None = None,
    next_context: list[dict[str, Any]] | None = None,
    log: LogFn,
) -> list[dict[str, Any]]:
    """Mandatory per-ID ownership audit; only failed rows may be rewritten."""
    previous_context = list(previous_context or [])
    next_context = list(next_context or [])
    expected_ids = [int(item["id"]) for item in translated]
    speaker_check = _SPEAKER_AUDIT if any(_speaker_tag(x) for x in translated) else ""
    flags = _speaker_flags(translated)
    flagged = ("\nMACHINE CHECK — words of the other gender were found here (check each; ရုပ်ရှင် or ပိုင်ရှင် "
               "is not \"you\"):\n" + "\n".join(f"- {line}" for line in flags)) if flags else ""
    base_prompt = f"""
You are a STRICT BURMESE NARRATION ALIGNMENT AUDITOR.
The Burmese must remain fluent and natural, but every action/fact/object/dialogue must
stay inside the same ID as its SOURCE. PREVIOUS and NEXT context are READ-ONLY.

For EVERY CURRENT ID, check all of these:
- semantic completeness against that ID's SOURCE;
- no event borrowed from the previous or next ID;
- no shifted chain where each row translates the following row;
- no adjacent duplicate/near-duplicate Burmese for different sources;
- natural spoken Burmese, stable names and pronouns.{speaker_check}

Return JSON ONLY in this exact shape, with every CURRENT ID once and in order:
{{"checks":[
  {{"id":1,"status":"pass"}},
  {{"id":2,"status":"repair","translation":"complete corrected natural Burmese for ID 2 only"}}
]}}
Use status=pass to preserve a good translation byte-for-byte. Use status=repair only
when necessary, and include a complete replacement translation. Never move facts
between IDs to improve flow.

STORY CONTEXT:
{json.dumps(story_context, ensure_ascii=False)}

PREVIOUS APPROVED CONTEXT (READ-ONLY):
{_translation_lines(previous_context) if previous_context else '(none)'}

CURRENT ITEMS TO AUDIT:
{_translation_lines(translated)}{flagged}

NEXT SOURCE CONTEXT (READ-ONLY):
{_source_lines(next_context) if next_context else '(none)'}
"""

    prompt = base_prompt
    last_error: Exception | None = None
    for attempt in range(1, 3):
        try:
            payload = _gemini_json(ai, prompt, retries=2, log=log)
            checks = payload.get("checks") if isinstance(payload, dict) else None
            if not isinstance(checks, list):
                raise ValueError("audit response must contain a checks array")
            got_ids: list[int] = []
            by_id = {int(item["id"]): dict(item) for item in translated}
            repaired = 0
            for check in checks:
                if not isinstance(check, dict):
                    raise ValueError("every audit check must be an object")
                uid = int(check.get("id"))
                got_ids.append(uid)
                status = _clean(check.get("status")).lower()
                if status == "pass":
                    continue
                if status != "repair":
                    raise ValueError(f"invalid audit status for ID {uid}: {status}")
                replacement = _clean(check.get("translation"))
                if uid not in by_id or not replacement:
                    raise ValueError(f"missing repair translation for ID {uid}")
                by_id[uid]["translation"] = replacement
                repaired += 1
            if got_ids != expected_ids:
                raise ValueError(f"audit ID mismatch expected={expected_ids} got={got_ids}")
            audited = [by_id[uid] for uid in expected_ids]
            _assert_no_adjacent_translation_duplicates(audited, previous_context)
            if repaired:
                log(f"🛠️ Sentence-lock audit repaired {repaired} item(s)")
            else:
                log("✅ Sentence-lock audit: every ID passed")
            return audited
        except GeminiKeyPoolExhaustedError:
            raise
        except Exception as exc:
            last_error = exc
            log(f"⚠️ Sentence-lock audit attempt {attempt}/2 failed: {exc}")
            prompt = base_prompt + (
                f"\n\nCORRECTION REQUIRED: {exc}. Return the full checks array for every CURRENT ID. "
                "Repair any duplicate or neighbor-shifted row; preserve rows that already pass."
            )
    raise RuntimeError(f"Sentence-lock translation audit could not be validated: {last_error}")


def make_translation_plan(units: list[dict[str, Any]], video_duration: float, *, source_title: str, transcript: dict[str, Any], story_context: dict[str, Any]) -> dict[str, Any]:
    covered = assign_full_coverage_boundaries(units, video_duration)
    segments = []
    for unit in covered:
        tr = _clean(unit.get("translation"))
        if not tr:
            raise RuntimeError(f"Missing Burmese translation for ID {unit.get('id')}")
        source_ids = [int(value) for value in (unit.get("source_whisper_ids") or [unit["source_whisper_id"]])]
        segments.append({
            "source_segment_ids": source_ids,
            "atomic_id": int(unit["id"]),
            "whisper_start": round(float(unit["speech_start"]), 3),
            "whisper_end": round(float(unit["speech_end"]), 3),
            "timestamp": unit["timestamp"],
            "video_start": round(float(unit["video_start"]), 3),
            "video_end": round(float(unit["video_end"]), 3),
            "source_text": unit["source_text"],
            "narration": tr,
            "translation": tr,
            "semantic_boundary": str(unit.get("semantic_boundary") or ""),
            "forced_boundary": bool(unit.get("forced_boundary", False)),
            "visual_reason": "Sentence-locked Whisper word-timestamp translation",
            **({"speaker": _clean(unit.get("speaker")), "speaker_gender": _clean(unit.get("speaker_gender"))}
               if _speaker_tag(unit) else {}),
        })
    return {
        "planner_mode": PLANNER_MODE,
        "translation_task": True,
        "summary_task": False,
        "original_title": source_title,
        "source_duration": round(float(video_duration), 3),
        "whisper_backend": transcript.get("backend", ""),
        "whisper_model": transcript.get("model", ""),
        "whisper_language": transcript.get("language", ""),
        "story_context": story_context,
        "segments": segments,
    }


class RecapPlanBuilder:
    def __init__(
        self,
        *,
        runtime_root: str,
        gemini_env_path: str = "",
        ffprobe_path: str,
        log: LogFn,
        progress: ProgressFn,
        should_stop: Callable[[], bool],
        translation_batch_max_items: int = 40,
        story_context_batch_max_items: int = 80,
        context_overlap: int = 6,
        lookahead: int = 6,
        translation_audit: bool = True,
        atomic_max_duration: float = 10.0,
        atomic_target_duration: float = 6.5,
        gemini_request_timeout_seconds: int = 120,
        gemini_text_model: str = "gemini-3.5-flash",
        gemini_model_plan: list[str] | None = None,
        whisper_model: str | None = None,
        whisper_device: str | None = None,
        whisper_compute_type: str | None = None,
        whisper_language: str | None = None,
        speaker_hints: Callable[[list[dict[str, Any]]], dict[int, dict[str, Any]]] | None = None,
    ):
        # speaker_hints(units) -> {unit id: {"gender": male|female|unsure, "speaker": name}} (DUB: Gemini listens)
        self.speaker_hints = speaker_hints
        self.runtime_root = Path(runtime_root).resolve()
        self.gemini_env_path = Path(gemini_env_path).expanduser().resolve() if str(gemini_env_path or "").strip() else None
        self.ffprobe = ffprobe_path
        # Prefer ffmpeg next to ffprobe; fallback to PATH.
        fp = Path(ffprobe_path)
        sibling = fp.with_name("ffmpeg.exe" if fp.suffix.lower() == ".exe" else "ffmpeg")
        self.ffmpeg = str(sibling) if sibling.is_file() else (shutil.which("ffmpeg") or "ffmpeg")
        self.log = log
        self.progress = progress
        self.should_stop = should_stop
        self.translation_batch_max_items = max(5, int(translation_batch_max_items))
        self.story_context_batch_max_items = max(10, int(story_context_batch_max_items))
        self.context_overlap = max(0, int(context_overlap))
        self.lookahead = max(0, int(lookahead))
        self.translation_audit = bool(translation_audit)
        self.atomic_max_duration = max(4.0, float(atomic_max_duration))
        self.atomic_target_duration = max(2.5, min(float(atomic_target_duration), self.atomic_max_duration))
        self.gemini_request_timeout_seconds = max(30, min(int(gemini_request_timeout_seconds), 600))
        self.gemini_text_model = _clean(gemini_text_model) or "gemini-3.5-flash"
        plan = [_clean(x) for x in (gemini_model_plan or []) if _clean(x)]
        if self.gemini_text_model not in plan:
            plan.insert(0, self.gemini_text_model)
        self.gemini_model_plan = list(dict.fromkeys(plan or [self.gemini_text_model]))
        self.whisper_model = _clean(whisper_model) if whisper_model else None
        self.whisper_device = _clean(whisper_device) if whisper_device else None
        self.whisper_compute_type = _clean(whisper_compute_type) if whisper_compute_type else None
        self.whisper_language = _clean(whisper_language) if whisper_language else None

    def _validate_runtime(self) -> None:
        required = [
            self.runtime_root / "services" / "whisper_service.py",
            self.runtime_root / "services" / "ai_service.py",
        ]
        missing = [str(p) for p in required if not p.is_file()]
        if missing:
            raise FileNotFoundError("Bundled runtime မပြည့်စုံပါ:\n" + "\n".join(missing))

    @staticmethod
    def _release_whisper_gpu(whisper_obj: Any) -> None:
        try:
            if hasattr(whisper_obj, "_model"):
                whisper_obj._model = None
        except Exception:
            pass
        try:
            del whisper_obj
        except Exception:
            pass
        gc.collect()

    def build(self, *, source: Path, job_dir: Path, source_title: str = "", reuse: bool = True) -> tuple[Path, dict[str, Any]]:
        self._validate_runtime()
        source = source.resolve()
        job_dir.mkdir(parents=True, exist_ok=True)
        transcript_file = job_dir / "whisper_transcript.json"
        atomic_file = job_dir / "atomic_units.json"
        context_file = job_dir / "story_context.json"
        context_checkpoint_file = job_dir / "story_context_checkpoint.json"
        translations_file = job_dir / "timestamp_translations.json"
        plan_file = job_dir / "smart_sync_plan.json"
        state_file = job_dir / "planner_checkpoint.json"
        fp = _source_fingerprint(source)
        compatible_transcript_fingerprints = {fp}
        compatible_transcript_fingerprints.update(
            _source_fingerprint_for_mode(source, mode) for mode in LEGACY_PLANNER_MODES
        )

        # With speaker hints the plan is rebuilt from its checkpoints instead (cheap): who speaks
        # each line is only known after the units exist, and a changed answer must re-translate.
        if reuse and self.speaker_hints is None and plan_file.is_file() and transcript_file.is_file() and state_file.is_file():
            try:
                state = json.loads(state_file.read_text(encoding="utf-8"))
                plan = json.loads(plan_file.read_text(encoding="utf-8"))
                if (
                    state.get("source_fingerprint") == fp
                    and state.get("plan_ready") is True
                    and state.get("planner_mode") == PLANNER_MODE
                    and plan.get("planner_mode") == PLANNER_MODE
                    and not _plan_overlap_warning(plan, self.log)
                ):
                    self.log("♻️ Whisper + Timestamp Translation plan reuse")
                    self.progress(4, 4, "Plan reused")
                    return plan_file, plan
            except Exception:
                pass

        duration = _probe_video_duration(self.ffprobe, source)
        audio_duration = _probe_audio_duration(self.ffprobe, source)
        self.log(f"🎬 Source: {source}")
        self.log(f"⏱️ Video duration (MASTER): {duration:.3f}s")
        if audio_duration is not None:
            self.log(f"🎧 Source audio duration: {audio_duration:.3f}s")
            if audio_duration > duration + 1.0:
                self.log(f"⚠️ Audio tail detected: +{audio_duration-duration:.3f}s beyond video; Whisper will trim it.")

        whisper_mod = _load_module("timestamp_whisper_service", self.runtime_root / "services" / "whisper_service.py")
        ai_mod = _load_module("timestamp_ai_service", self.runtime_root / "services" / "ai_service.py")

        # Reuse raw Whisper independently when source matches, even if translation plan does not.
        transcript = None
        if reuse and transcript_file.is_file() and state_file.is_file():
            try:
                state = json.loads(state_file.read_text(encoding="utf-8"))
                if (
                    state.get("source_fingerprint") in compatible_transcript_fingerprints
                    and state.get("transcript_ready") is True
                ):
                    transcript = json.loads(transcript_file.read_text(encoding="utf-8"))
                    self.log("♻️ Full Whisper transcript reuse (planner-safe across V2/V3 modes)")
            except Exception:
                transcript = None

        if transcript is None:
            if self.should_stop():
                raise InterruptedError("STOP requested before Whisper")
            runtime_cfg = _load_runtime_config(self.runtime_root)
            whisper = whisper_mod.WhisperTimestampService(
                model_size=self.whisper_model or str(runtime_cfg.get("whisper_model", os.getenv("WHISPER_MODEL", "medium"))),
                backend=str(runtime_cfg.get("whisper_backend", os.getenv("WHISPER_BACKEND", "auto"))),
                device=self.whisper_device or str(runtime_cfg.get("whisper_device", os.getenv("WHISPER_DEVICE", "cuda"))),
                compute_type=self.whisper_compute_type or str(runtime_cfg.get("whisper_compute_type", os.getenv("WHISPER_COMPUTE_TYPE", "float16"))),
                language=self.whisper_language or runtime_cfg.get("whisper_language") or os.getenv("WHISPER_LANGUAGE") or None,
            )
            self.progress(0, 4, "Whisper full transcript")
            self.log("🎙️ [1/4] Local Whisper — full video timestamp transcript...")
            whisper_media = _prepare_whisper_audio(self.ffmpeg, source, job_dir, duration, self.log)
            transcript = whisper.transcribe(str(whisper_media), duration)
            transcript["source_title"] = source_title or source.stem
            _atomic_json(transcript_file, transcript)
            self.log(f"✅ Whisper raw segments: {len(transcript.get('segments') or [])}")
            self._release_whisper_gpu(whisper)

        # V4 migration path: reuse the proven old transcript cache, but do NOT trust it
        # as complete until the new additive gap/EOF coverage pass has run. This avoids
        # a full Whisper rerun just to recover one omitted line such as a final system phrase.
        if int(transcript.get("coverage_rescue_version") or 0) < 2:
            if self.should_stop():
                raise InterruptedError("STOP requested before Whisper coverage rescue")
            runtime_cfg = _load_runtime_config(self.runtime_root)
            whisper = whisper_mod.WhisperTimestampService(
                model_size=self.whisper_model or str(runtime_cfg.get("whisper_model", os.getenv("WHISPER_MODEL", "medium"))),
                backend=str(runtime_cfg.get("whisper_backend", os.getenv("WHISPER_BACKEND", "auto"))),
                device=self.whisper_device or str(runtime_cfg.get("whisper_device", os.getenv("WHISPER_DEVICE", "cuda"))),
                compute_type=self.whisper_compute_type or str(runtime_cfg.get("whisper_compute_type", os.getenv("WHISPER_COMPUTE_TYPE", "float16"))),
                language=self.whisper_language or runtime_cfg.get("whisper_language") or os.getenv("WHISPER_LANGUAGE") or None,
            )
            self.progress(0, 4, "Whisper gap/EOF coverage rescue")
            self.log("🔎 Whisper V4 coverage rescue — existing timestamps stay untouched; only missed speech is added...")
            whisper_media = _prepare_whisper_audio(self.ffmpeg, source, job_dir, duration, self.log)
            # repair_missing_speech_coverage loads the same local Whisper model only once and
            # re-listens to short holes/tail windows instead of retranscribing the whole video.
            whisper._ensure_model()
            transcript = whisper.repair_missing_speech_coverage(str(whisper_media), transcript, duration)
            transcript["source_title"] = source_title or source.stem
            _atomic_json(transcript_file, transcript)
            self.log(
                f"✅ Whisper coverage-ready: {len(transcript.get('segments') or [])} segments "
                f"(+{int(transcript.get('coverage_rescued_segments') or 0)} rescued)"
            )
            self._release_whisper_gpu(whisper)

        units = atomicize_whisper_segments(
            transcript,
            max_duration=self.atomic_max_duration,
            target_duration=self.atomic_target_duration,
        )
        if not units:
            raise RuntimeError("Whisper atomic timestamp units မရှိပါ။")
        _atomic_json(atomic_file, {"planner_mode": PLANNER_MODE, "units": units})
        forced_units = sum(1 for unit in units if unit.get("forced_boundary"))
        self.log(
            f"🧩 Sentence-locked sync units: {len(units)} "
            f"(forced punctuation-free boundaries={forced_units})"
        )

        _atomic_json(state_file, {
            "version": 4,
            "planner_mode": PLANNER_MODE,
            "source_fingerprint": fp,
            "source_path": str(source),
            "transcript_ready": True,
            "plan_ready": False,
        })

        if self.should_stop():
            raise InterruptedError("STOP requested after Whisper")

        if self.speaker_hints is not None:
            self.progress(1, 4, "Who speaks each line")
            hints = self.speaker_hints(units) or {}
            for unit in units:
                hint = hints.get(int(unit["id"])) or {}
                gender, name = _clean(hint.get("gender")).lower(), _clean(hint.get("speaker"))[:40]
                if gender in ("male", "female") or (gender == "unsure" and name):
                    unit["speaker_gender"] = gender
                    if name:
                        unit["speaker"] = name
        speaker_style = SPEAKER_STYLE if any(_speaker_tag(x) for x in units) else ""
        if speaker_style:
            self.log("🗣️ Translation knows who speaks: " + " · ".join(
                f"{g}={sum(1 for x in units if x.get('speaker_gender') == g)}" for g in ("male", "female", "unsure")))

        env_file = self.gemini_env_path
        key_pool: list[tuple[str, str]] = []
        if env_file and env_file.is_file():
            from dotenv import dotenv_values, load_dotenv
            load_dotenv(env_file, override=True)
            self.log(f"🔑 Gemini .env loaded: {env_file}")
            env_values = dotenv_values(env_file)
            seen_keys: set[str] = set()
            ranked: list[tuple[int, str, str]] = []
            for label, raw_key in env_values.items():
                label = str(label or "").strip()
                key = str(raw_key or "").strip()
                if not label or not key:
                    continue
                upper = label.upper()
                m = re.fullmatch(r"GEMINI_IMAGE_PROJECT_(\d+)_KEY", upper)
                if m:
                    ranked.append((100 + int(m.group(1)), label, key))
                elif upper == "GEMINI_TEXT_FREE_KEY":
                    ranked.append((0, label, key))
                elif upper == "GEMINI_TTS_FREE_KEY":
                    ranked.append((1, label, key))
            for _, label, key in sorted(ranked):
                if key not in seen_keys:
                    key_pool.append((label, key))
                    seen_keys.add(key)
            # Backward compatibility for a conventional single-key .env.
            if not key_pool:
                key = str(env_values.get("GEMINI_API_KEY") or "").strip()
                if key:
                    key_pool.append(("GEMINI_API_KEY", key))
        if not key_pool:
            inherited_key = str(os.getenv("GEMINI_API_KEY") or "").strip()
            if inherited_key:
                key_pool.append(("GEMINI_API_KEY", inherited_key))
        if key_pool:
            # The numbered project pool is authoritative for this standalone run.
            os.environ["GEMINI_API_KEY"] = key_pool[0][1]
        os.environ["GEMINI_TEXT_MODEL"] = self.gemini_text_model
        if not os.getenv("GEMINI_API_KEY"):
            raise RuntimeError(
                "Gemini API key မတွေ့ပါ။ .env ထဲမှာ GEMINI_IMAGE_PROJECT_1_KEY ... "
                "GEMINI_IMAGE_PROJECT_10_KEY (သို့) GEMINI_API_KEY ထည့်ပေးပါ။"
            )

        with _pushd(self.runtime_root):
            ai = ai_mod.AIService()
            self.log(f"🤖 Gemini text model: {ai.text_model}")
            _configure_gemini_key_pool(
                ai,
                key_pool,
                client_factory=ai_mod.genai.Client,
                log=self.log,
                request_timeout_seconds=self.gemini_request_timeout_seconds,
            )
            _configure_gemini_model_fallback(ai, self.gemini_model_plan, log=self.log)

            self.progress(1, 4, "Story context memory")
            self.log("🧠 [2/4] Gemini Story Context Memory pass...")
            story_context = build_story_context(
                ai, units,
                batch_max_items=self.story_context_batch_max_items,
                log=self.log,
                should_stop=self.should_stop,
                checkpoint_path=context_checkpoint_file,
                source_fingerprint=fp,
                reuse=reuse,
            )
            _atomic_json(context_file, {
                "planner_mode": PLANNER_MODE,
                "source_fingerprint": fp,
                "context": story_context,
            })

            self.progress(2, 4, "Timestamp translation")
            self.log("🌐 [3/4] Gemini timestamp TRANSLATION — no summary / no shortening...")
            batches = _batch_by_size(units, max_items=self.translation_batch_max_items, max_chars=16000)
            translated_all: list[dict[str, Any]] = []
            if reuse and translations_file.is_file():
                try:
                    saved = json.loads(translations_file.read_text(encoding="utf-8"))
                    saved_items = saved.get("items") or []
                    if (saved.get("planner_mode") == PLANNER_MODE and saved.get("source_fingerprint") == fp
                            and saved.get("speaker_style", "") == speaker_style and isinstance(saved_items, list)):
                        n = len(saved_items)
                        expected_prefix = units[:n]
                        # IDs alone are not enough: a rebuilt unit list (e.g. after the
                        # rescued-word overlap fix) can keep IDs but change their text,
                        # or Gemini may now hear another speaker for a line.
                        if n <= len(units) and [
                            (int(x.get("id", -1)), _clean(x.get("source_text")), _speaker_tag(x)) for x in saved_items
                        ] == [(int(x["id"]), _clean(x.get("source_text")), _speaker_tag(x)) for x in expected_prefix]:
                            translated_all = saved_items
                            if translated_all:
                                self.log(f"♻️ Timestamp Translation resume — {len(translated_all)}/{len(units)} units already done")
                except Exception as exc:
                    self.log(f"⚠️ Translation checkpoint ignored: {exc}")
                    translated_all = []

            unit_index = {int(x["id"]): idx for idx, x in enumerate(units)}
            completed_ids = {int(x["id"]) for x in translated_all}
            for bi, batch in enumerate(batches, 1):
                batch_ids = [int(x["id"]) for x in batch]
                if all(uid in completed_ids for uid in batch_ids):
                    continue
                if any(uid in completed_ids for uid in batch_ids):
                    # Checkpoints are written at complete-batch boundaries; a partial batch is unsafe to reuse.
                    translated_all = [x for x in translated_all if int(x["id"]) < batch_ids[0]]
                    completed_ids = {int(x["id"]) for x in translated_all}
                if self.should_stop():
                    raise InterruptedError("STOP requested during timestamp translation")
                last_index = unit_index[int(batch[-1]["id"])]
                prev = translated_all[-self.context_overlap:] if self.context_overlap else []
                nxt = units[last_index + 1:last_index + 1 + self.lookahead] if self.lookahead else []
                self.log(f"🌐 Translate batch {bi}/{len(batches)} — IDs {batch[0]['id']:05d}–{batch[-1]['id']:05d}")
                try:
                    translated = translate_batch(
                        ai,
                        story_context=story_context,
                        previous_context=prev,
                        current=batch,
                        next_context=nxt,
                        log=self.log,
                    )
                except GeminiKeyPoolExhaustedError as exc:
                    saved = len(translated_all)
                    remaining = len(units) - saved
                    self.log(f"💾 Translation checkpoint safe — {saved}/{len(units)} units saved; {remaining} remaining")
                    raise GeminiKeyPoolExhaustedError(
                        f"{exc}\n\nSaved progress: {saved}/{len(units)} units; "
                        f"remaining: {remaining}. Resume will start at ID {batch_ids[0]:05d}."
                    ) from exc
                if self.translation_audit:
                    translated = audit_and_repair_batch(
                        ai,
                        translated,
                        story_context=story_context,
                        previous_context=prev,
                        next_context=nxt,
                        log=self.log,
                    )
                translated = _drop_foreign_letters(translated, self.log)
                for flag in _speaker_flags(translated):
                    self.log(f"⚠️ Check the speaker's words: {flag}")
                translated_all.extend(translated)
                completed_ids.update(int(x["id"]) for x in translated)
                _atomic_json(translations_file, {
                    "planner_mode": PLANNER_MODE,
                    "source_fingerprint": fp,
                    "speaker_style": speaker_style,
                    "completed": len(translated_all),
                    "total": len(units),
                    "items": translated_all,
                })

        if [int(x["id"]) for x in translated_all] != [int(x["id"]) for x in units]:
            raise RuntimeError("Final translation ID sequence mismatch")

        self.progress(3, 4, "Build Smart Sync plan")
        self.log("🧩 [4/4] Sentence-locked timestamps → Smart Sync plan...")
        plan = make_translation_plan(
            translated_all,
            duration,
            source_title=source_title or source.stem,
            transcript=transcript,
            story_context=story_context,
        )
        plan["standalone_source_path"] = str(source)
        plan["speaker_style"] = speaker_style
        plan["translation_batch_count"] = len(batches)
        plan["atomic_unit_count"] = len(translated_all)
        plan["translation_rules"] = {
            "task": "translate",
            "summarize": False,
            "shorten": False,
            "merge_ids": False,
            "delete_ids": False,
            "reorder_ids": False,
            "natural_expansion_allowed": True,
            "new_plot_invention_allowed": False,
            "sentence_or_complete_clause_boundaries": True,
            "context_read_only_for_each_id": True,
            "adjacent_duplicate_rejected": True,
            "mandatory_per_id_alignment_audit": bool(self.translation_audit),
        }
        _atomic_json(plan_file, plan)
        _atomic_json(state_file, {
            "version": 4,
            "planner_mode": PLANNER_MODE,
            "source_fingerprint": fp,
            "source_path": str(source),
            "transcript_ready": True,
            "context_ready": True,
            "translation_ready": True,
            "plan_ready": True,
            "speaker_style": speaker_style,
            "atomic_units": len(translated_all),
        })
        self.progress(4, 4, "Plan ready")
        self.log(f"✅ smart_sync_plan.json READY — sentence-locked timestamp units={len(plan['segments'])}")
        return plan_file, plan
