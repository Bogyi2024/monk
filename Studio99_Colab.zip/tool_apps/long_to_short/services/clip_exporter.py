from __future__ import annotations

import shutil
import subprocess
from pathlib import Path


def _escape_filter_path(path: str | Path) -> str:
    # FFmpeg filter parser needs ':' escaped on Windows drive paths.  Forward
    # slashes are accepted by FFmpeg on Windows and avoid backslash ambiguity.
    p = str(Path(path).resolve()).replace("\\", "/")
    p = p.replace(":", r"\:").replace("'", r"\'")
    return p


def export_center_crop(
    src: str | Path,
    out: str | Path,
    start: float,
    end: float,
    width=1080,
    height=1920,
    fps=30,
    subtitle_ass: str | Path | None = None,
):
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg not found in PATH")
    dur = max(0.1, end - start)
    filters = [
        f"scale={width}:{height}:force_original_aspect_ratio=increase",
        f"crop={width}:{height}",
        f"fps={fps}",
    ]
    if subtitle_ass:
        filters.append(f"subtitles=filename='{_escape_filter_path(subtitle_ass)}'")
    vf = ",".join(filters)

    base = [ffmpeg, "-y", "-ss", f"{start:.3f}", "-i", str(src), "-t", f"{dur:.3f}", "-vf", vf]
    nv = base + ["-c:v", "h264_nvenc", "-preset", "p4", "-cq", "21", "-c:a", "aac", "-b:a", "160k", str(out)]
    r = subprocess.run(nv, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        cpu = base + ["-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-c:a", "aac", "-b:a", "160k", str(out)]
        r = subprocess.run(cpu, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-4000:])
