"""Load the same Whisper model for transcription and narration alignment.

A Hub snapshot can exist after an interrupted download without model.bin. CPU
fallback cannot repair that snapshot. Check it first and repair model files once;
only a device load failure should fall back from CUDA to CPU.
"""
from __future__ import annotations

import json
from pathlib import Path
import re


_FILES = ["config.json", "preprocessor_config.json", "model.bin", "tokenizer.json", "vocabulary.*"]


class WhisperModelFilesError(RuntimeError):
    """A model/download failure that cannot be fixed by changing the device."""


def _invalid_files(folder: Path, *, local_model=False) -> list[str]:
    bad = []
    required = ["model.bin", "config.json"]
    if not local_model or (folder / "tokenizer.json").exists():
        required.append("tokenizer.json")
    for name in required:
        path = folder / name
        try:
            with path.open("rb") as stream:
                if not stream.read(1):
                    raise ValueError("empty file")
            if name.endswith(".json") and not isinstance(json.loads(path.read_text(encoding="utf-8")), dict):
                raise ValueError("not an object")
        except (OSError, ValueError):
            bad.append(name)
    return bad


def _model_file_error(error: Exception) -> bool:
    text = str(error).lower()
    return isinstance(error, (WhisperModelFilesError, json.JSONDecodeError)) or any(term in text for term in (
        "model.bin", "config.json", "tokenizer.json", "unsupported model binary version",
        "failed to read model", "invalid model file", "incomplete model",
    ))


def load_whisper_model(model_name="medium", device="cuda", compute_type="float16"):
    """Return (model, actual_device, actual_compute), without loading CUDA in the UI."""
    try:
        from faster_whisper import WhisperModel, download_model
        # Use the installed SDK's model aliases, including its turbo/distil aliases.
        from faster_whisper.utils import _MODELS
        from huggingface_hub import snapshot_download
    except ImportError as exc:
        raise RuntimeError("Long to Short အတွက် faster-whisper မတွေ့ပါ။ Studio99 ကို ပြန်သွင်းပါ။") from exc

    name = str(model_name)
    local = Path(name).expanduser()
    explicit_path = local.is_dir() or local.is_absolute() or name.startswith((".", "~"))
    repo = None if explicit_path else _MODELS.get(name)
    if not explicit_path and repo is None:
        if not re.fullmatch(r"[\w.-]+/[\w.-]+", name):
            raise ValueError(f"Whisper model အမည် မမှန်ပါ: {name}")
        repo = name

    repaired = False

    def repair(folder: Path, files: list[str]) -> Path:
        nonlocal repaired
        if explicit_path:
            raise WhisperModelFilesError(f"Whisper model ဖိုင် မပြည့်စုံပါ: {folder} ({', '.join(files)})")
        repaired = True
        print(f"⬇️ Whisper {name}: model ဖိုင် ပြန်ဒေါင်းနေပါတယ် ({', '.join(files)})…", flush=True)
        # Pin a cached snapshot's revision so weights and its config stay together.
        revision = folder.name if re.fullmatch(r"[0-9a-f]{40}", folder.name) else None
        try:
            result = Path(snapshot_download(repo, revision=revision, allow_patterns=files, force_download=True))
        except Exception as exc:
            raise WhisperModelFilesError(
                f"Whisper {name} model ပြန်ဒေါင်းမရပါ။ Internet / disk space / antivirus ကို စစ်ပြီး Start ပြန်နှိပ်ပါ။ "
                f"({type(exc).__name__}: {str(exc)[-400:]})"
            ) from exc
        return result

    print(f"🧠 Whisper model စစ်နေပါတယ်: {name} ({device}/{compute_type})", flush=True)
    if explicit_path:
        folder = local.resolve()
    else:
        try:
            folder = Path(download_model(name, local_files_only=True))
        except Exception:
            print(f"⬇️ Whisper {name} model ဒေါင်းနေပါတယ်။ ပထမအကြိမ် အချိန်ယူနိုင်ပါတယ်…", flush=True)
            try:
                folder = Path(download_model(name))
            except Exception as exc:
                raise WhisperModelFilesError(
                    f"Whisper {name} model ဒေါင်းမရပါ။ Internet / disk space ကို စစ်ပြီး Start ပြန်နှိပ်ပါ။ "
                    f"({type(exc).__name__}: {str(exc)[-400:]})"
                ) from exc
    bad = _invalid_files(folder, local_model=explicit_path)
    if bad:
        folder = repair(folder, bad)
        bad = _invalid_files(folder)
        if bad:
            raise WhisperModelFilesError(f"Whisper model ဖိုင် ဖွင့်မရသေးပါ: {folder} ({', '.join(bad)})")

    def create(active_device, active_compute):
        nonlocal folder
        try:
            return WhisperModel(str(folder), device=active_device, compute_type=active_compute, local_files_only=True)
        except Exception as exc:
            if not _model_file_error(exc):
                raise
            if repaired or explicit_path:
                raise WhisperModelFilesError(f"Whisper model ဖိုင် ဖွင့်မရပါ: {folder}. {exc}") from exc
            folder = repair(folder, _FILES)
            bad = _invalid_files(folder)
            if bad:
                raise WhisperModelFilesError(f"Whisper model ဖိုင် မပြည့်စုံသေးပါ: {folder} ({', '.join(bad)})")
            try:
                return WhisperModel(str(folder), device=active_device, compute_type=active_compute, local_files_only=True)
            except Exception as retry_exc:
                if not _model_file_error(retry_exc):
                    raise
                raise WhisperModelFilesError(f"Whisper model ပြန်ဒေါင်းပြီးလည်း load မရပါ: {folder}. {retry_exc}") from retry_exc

    try:
        model = create(device, compute_type)
    except Exception as exc:
        if str(device).lower() == "cpu" or _model_file_error(exc):
            raise
        print(f"⚠️ Whisper {device} load မရလို့ CPU/int8 နဲ့ ဆက်လုပ်ပါမယ်: {exc}", flush=True)
        model = create("cpu", "int8")
        return model, "cpu", "int8"
    return model, device, compute_type
