from __future__ import annotations
from pathlib import Path

from services.whisper_runtime import load_whisper_model


def transcribe(video_path: str | Path, model_name="medium", device="cuda", compute_type="float16") -> dict:
    model, actual_device, actual_compute = load_whisper_model(model_name, device, compute_type)

    print(f"🎙️ Transcribing on {actual_device}/{actual_compute} ...")
    # Word timestamps cost very little compared with decoding and make future
    # subtitle timing / sub-segment cuts more exact. Cached old transcripts are
    # still fully supported by proportional timing fallbacks.
    segments, info = model.transcribe(
        str(video_path), vad_filter=True, beam_size=5, word_timestamps=True
    )
    out = []
    last_progress_bucket = -1
    for s in segments:
        text = (s.text or "").strip()
        if not text:
            continue
        item = {
            "start": round(float(s.start), 3),
            "end": round(float(s.end), 3),
            "text": text,
        }
        words = []
        for w in (getattr(s, "words", None) or []):
            wt = str(getattr(w, "word", "") or "").strip()
            if not wt:
                continue
            words.append({
                "start": round(float(w.start), 3),
                "end": round(float(w.end), 3),
                "word": wt,
            })
        if words:
            item["words"] = words
        out.append(item)
        bucket = int(float(s.end) // 300)
        if bucket > last_progress_bucket:
            last_progress_bucket = bucket
            mm = int(float(s.end) // 60)
            ss = int(float(s.end) % 60)
            print(f"   ↳ transcript reached {mm:02d}:{ss:02d} | {len(out)} segments")

    if not out:
        raise RuntimeError("Whisper returned no transcript segments")
    return {"language": getattr(info, "language", None), "segments": out}
