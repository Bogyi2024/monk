from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from services.gemini_moment_selector import (
    resolve_api_keys,
    _proxy_if_listening,
    _restore_proxy,
    _is_key_rotatable_error,
    _is_model_unavailable_error,
    _is_transient_service_error,
    _is_request_timeout_error,
    _model_chain,
)

ROOT = Path(__file__).resolve().parents[1]
PROMPT_VERSION = "transformative_commentary_v2_en_only"


@dataclass
class CommentaryConfig:
    # User preference for this build: keep text work on Gemini 3.5.
    model: str = "gemini-3.5-flash"
    model_fallbacks: tuple[str, ...] = ("gemini-3.5-flash-lite",)
    temperature: float = 0.35
    min_segments: int = 12
    max_segments: int = 16
    target_words_min: int = 180
    target_words_max: int = 230
    allow_paid_fallback: bool = False
    retries_per_key: int = 1
    backoff_seconds: float = 4.0
    profile: str = "generic"
    reuse_compatible_cache: bool = True




def _profile_guidance(profile: str) -> str:
    key = str(profile or "generic").strip().lower().replace("-", "_")
    return {
        "motivation": "Use an uplifting but grounded documentary tone. Explain the mindset/life lesson without hype or empty slogans.",
        "psychology": "Use a thoughtful educational tone focused on behavior, relationships, communication, or emotional patterns actually supported by the source. Do not diagnose people.",
        "horror": "Use a dark restrained storytelling tone. Build unease from the source moment, preserve uncertainty when the source is uncertain, and end on the strongest eerie takeaway/reveal rather than inventing facts.",
        "crime": "Use a factual mystery/documentary tone. Distinguish claims, allegations, evidence, and confirmed facts as the source does; do not sensationalize beyond the transcript.",
        "knowledge": "Use a clear educational explainer tone. Make one idea easy to understand, add context, and finish with what the viewer should remember.",
        "comedy": "Use a light, quick commentary tone that protects the original setup/punchline context. Do not explain the joke to death; add just enough framing and takeaway.",
        "business": "Use a practical business/leadership analysis tone with concrete lessons and minimal motivational fluff.",
        "celebrity": "Use a respectful entertainment-documentary tone focused on the story/career lesson, not gossip amplification.",
        "tech_ai": "Use a concise tech explainer tone focused on practical implications and what the idea changes for viewers/builders.",
        "sports": "Use an energetic but grounded sports-documentary tone focused on competition, training, tactics, team dynamics, or resilience.",
        "generic": "Use a neutral documentary/commentary tone matched to the source moment.",
    }.get(key, "Use a neutral documentary/commentary tone matched to the source moment.")

def _schema(count: int, cfg: CommentaryConfig) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "clips": {
                "type": "array",
                "minItems": count,
                "maxItems": count,
                "items": {
                    "type": "object",
                    "properties": {
                        "index": {"type": "integer"},
                        "title": {"type": "string"},
                        "segments": {
                            "type": "array",
                            "minItems": cfg.min_segments,
                            "maxItems": cfg.max_segments,
                            "items": {
                                "type": "object",
                                "properties": {"en": {"type": "string"}},
                                "required": ["en"],
                            },
                        },
                    },
                    "required": ["index", "title", "segments"],
                },
            }
        },
        "required": ["clips"],
    }


def _candidate_payload(candidates: list[dict]) -> str:
    rows = []
    for i, c in enumerate(candidates, 1):
        rows.append({
            "index": i,
            "title": str(c.get("title") or "").strip(),
            "reason": str(c.get("reason") or "").strip(),
            "hook_summary": str(c.get("hook_summary") or "").strip(),
            "source_transcript": str(c.get("text") or "").strip(),
        })
    return json.dumps(rows, ensure_ascii=False, indent=2)


def _prompt(candidates: list[dict], cfg: CommentaryConfig) -> str:
    return f"""
You are writing ORIGINAL transformative commentary for short-form videos based on interview excerpts.

For each of the {len(candidates)} source moments below, create one ENGLISH narration package.
Myanmar subtitle translation is handled later from the ACTUAL synthesized narration timing, so DO NOT translate here.

CORE PURPOSE
- Content profile: {cfg.profile}. {_profile_guidance(cfg.profile)}
- The final video must feel like analysis/commentary, NOT a repost of the source interview.
- Explain why the moment matters, add context, interpretation, and a useful takeaway.
- Use a neutral third-person narrator. Do NOT impersonate the source speaker and do NOT write as if you are them.
- Do not simply summarize line-by-line.
- Do not reproduce long verbatim passages. Avoid copying any run of more than 8 consecutive words from the source transcript.
- It is okay to name the public speaker/topic when it is already clear from the source metadata.

ENGLISH NARRATION
- Total narration per clip: about {cfg.target_words_min}-{cfg.target_words_max} words.
- Split it into {cfg.min_segments}-{cfg.max_segments} short natural segments.
- Segment 1 must be a strong original hook.
- Middle segments: context + analysis + insight.
- Last segment: a clean takeaway/conclusion.
- Each segment should usually be one sentence or a short two-clause sentence.
- Natural international English, documentary/commentary tone, not clickbait spam.

Return JSON only. Keep clip index order exactly 1..{len(candidates)}.

SOURCE MOMENTS:
{_candidate_payload(candidates)}
""".strip()


def _extract_json(text: str) -> dict:
    raw = (text or "").strip()
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
    raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        a, b = raw.find("{"), raw.rfind("}")
        if a >= 0 and b > a:
            return json.loads(raw[a:b+1])
        raise


def _hash_job(candidates: list[dict], cfg: CommentaryConfig) -> str:
    obj = {
        "v": PROMPT_VERSION,
        "models": _model_chain(cfg.model, cfg.model_fallbacks),
        "count": len(candidates),
        "profile": str(cfg.profile or "generic"),
        "items": [
            {
                "start": round(float(c.get("start", 0)), 3),
                "end": round(float(c.get("end", 0)), 3),
                "title": c.get("title"),
                "text": c.get("text"),
            }
            for c in candidates
        ],
    }
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()[:20]


def _validate(raw: dict, candidates: list[dict], cfg: CommentaryConfig) -> list[dict]:
    clips = raw.get("clips") if isinstance(raw, dict) else None
    if not isinstance(clips, list) or len(clips) != len(candidates):
        raise RuntimeError(f"Commentary JSON requires exactly {len(candidates)} clips")
    by_index: dict[int, dict] = {}
    for item in clips:
        if not isinstance(item, dict):
            continue
        try:
            idx = int(item.get("index"))
        except Exception:
            continue
        if not 1 <= idx <= len(candidates):
            continue
        segs = item.get("segments")
        if not isinstance(segs, list) or not (cfg.min_segments <= len(segs) <= cfg.max_segments):
            raise RuntimeError(f"Commentary clip {idx}: segments must be {cfg.min_segments}-{cfg.max_segments}")
        cleaned = []
        for s in segs:
            en = re.sub(r"\s+", " ", str((s or {}).get("en") or "")).strip()
            if not en:
                raise RuntimeError(f"Commentary clip {idx}: empty English segment")
            # Old V0.3/V0.3.1 caches may contain an mm field. Intentionally ignore it:
            # V0.3.4 re-translates the ACTUAL TTS-aligned spoken chunks later.
            cleaned.append({"en": en})
        wc = sum(len(s["en"].split()) for s in cleaned)
        minimum_words = max(min(120, max(20, round(cfg.target_words_min * .65))), cfg.target_words_min - 45)
        if wc < minimum_words or wc > cfg.target_words_max + 60:
            raise RuntimeError(f"Commentary clip {idx}: English word count {wc} looks off-target")
        by_index[idx] = {
            "index": idx,
            "title": str(item.get("title") or candidates[idx-1].get("title") or "").strip(),
            "segments": cleaned,
            "english_voiceover": " ".join(s["en"] for s in cleaned),
            "word_count": wc,
            "prompt_version": str(item.get("prompt_version") or PROMPT_VERSION),
        }
    if sorted(by_index) != list(range(1, len(candidates) + 1)):
        raise RuntimeError("Commentary indexes are incomplete/out of order")
    return [by_index[i] for i in range(1, len(candidates) + 1)]


def _titles_match(packages: list[dict], candidates: list[dict]) -> bool:
    if len(packages) != len(candidates):
        return False
    for pkg, cand in zip(packages, candidates):
        a = re.sub(r"\s+", " ", str(pkg.get("title") or "")).strip().casefold()
        b = re.sub(r"\s+", " ", str(cand.get("title") or "")).strip().casefold()
        if a and b and a != b:
            return False
    return True


def _find_compatible_old_cache(cache_dir: Path, exact_file: Path, candidates: list[dict], cfg: CommentaryConfig) -> tuple[list[dict], Path] | tuple[None, None]:
    if not cfg.reuse_compatible_cache:
        return None, None
    files = [p for p in cache_dir.glob("*.json") if p != exact_file]
    files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    for p in files:
        try:
            raw = json.loads(p.read_text(encoding="utf-8"))
            packages = _validate(raw, candidates, cfg)
            if _titles_match(packages, candidates):
                return packages, p
        except Exception:
            continue
    return None, None


def _call_text(prompt: str, model_cfg: CommentaryConfig, api_key: str, count: int, request_timeout_ms: int = 120_000) -> str:
    from google import genai
    from google.genai import types
    client = genai.Client(api_key=api_key, http_options=types.HttpOptions(timeout=max(1_000, request_timeout_ms), retry_options=types.HttpRetryOptions(attempts=1)))
    try:
        response = client.models.generate_content(
            model=model_cfg.model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=model_cfg.temperature,
                response_mime_type="application/json",
                response_schema=_schema(count, model_cfg),
            ),
        )
    except (TypeError, AttributeError):
        response = client.models.generate_content(model=model_cfg.model, contents=prompt)
    return str(getattr(response, "text", "") or "")


def generate_commentary_packages(candidates: list[dict], cfg: CommentaryConfig) -> tuple[list[dict], dict]:
    cache_dir = ROOT / "state" / "commentary_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_key = _hash_job(candidates, cfg)
    cache_file = cache_dir / f"{cache_key}.json"

    if cache_file.exists():
        try:
            cached = json.loads(cache_file.read_text(encoding="utf-8"))
            packages = _validate(cached, candidates, cfg)
            print(f"♻️ Commentary cache hit → {cache_file.name} (0 API calls)")
            return packages, {"cached": True, "cache": str(cache_file), "key_alias": "cached", "compatible_old_cache": False}
        except Exception:
            pass

    packages, old_file = _find_compatible_old_cache(cache_dir, cache_file, candidates, cfg)
    if packages is not None and old_file is not None:
        # Promote to the new cache key, EN-only. This preserves the user's existing
        # successful English narration/TTS cache while allowing new spoken-MM subtitles.
        cache_file.write_text(json.dumps({"clips": packages}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"♻️ Compatible commentary cache reused → {old_file.name} (0 API calls, EN narration preserved)")
        return packages, {
            "cached": True,
            "cache": str(cache_file),
            "reused_from": str(old_file),
            "key_alias": "compatible_cached",
            "compatible_old_cache": True,
        }

    pool = resolve_api_keys(cfg.allow_paid_fallback)
    print("📝 Commentary Gemini key pool: " + " → ".join(f"{e.alias}[{e.fingerprint}]" for e in pool))
    if not cfg.allow_paid_fallback:
        print("🛡️ Commentary paid fallback: DISABLED")
    prompt = _prompt(candidates, cfg)
    errors: list[str] = []
    proxy_state = _proxy_if_listening()
    deadline = time.monotonic() + 360
    try:
        models = _model_chain(cfg.model, cfg.model_fallbacks)
        for model in models:
            print(f"🧠 Commentary model → {model}")
            switch_model = False
            for entry in pool:
                transient_try = 0
                while True:
                    remaining_ms = int((deadline - time.monotonic()) * 1000)
                    if remaining_ms <= 0:
                        raise RuntimeError('Commentary Gemini overall timeout after 360s; cached source/selection kept')
                    try:
                        model_cfg = CommentaryConfig(**{**cfg.__dict__, "model": model})
                        request_limit = 120_000 if model == models[-1] else 45_000
                        text = _call_text(prompt, model_cfg, entry.value, len(candidates), min(request_limit, remaining_ms))
                        raw = _extract_json(text)
                        packages = _validate(raw, candidates, cfg)
                        cache_file.write_text(json.dumps({"clips": packages}, ensure_ascii=False, indent=2), encoding="utf-8")
                        return packages, {
                            "cached": False,
                            "cache": str(cache_file),
                            "key_alias": entry.alias,
                            "key_source": entry.source,
                            "key_fingerprint": entry.fingerprint,
                            "paid_key_used": entry.paid,
                            "model_used": model,
                        }
                    except Exception as exc:
                        if _is_model_unavailable_error(exc):
                            print(f"   ⚠️ Commentary model unavailable → fallback model ({model})")
                            errors.append(f"{model}: {exc}")
                            switch_model = True
                            break
                        if _is_key_rotatable_error(exc):
                            print(f"   ⚠️ Commentary key unavailable/quota/access → rotate ({entry.alias})")
                            errors.append(f"{model}/{entry.alias}: {exc}")
                            break
                        if _is_request_timeout_error(exc):
                            switch_model = model != models[-1]
                            action = 'fallback model' if switch_model else 'rotate free key'
                            print(f'   ⏱️ Commentary request timeout → {action} ({entry.alias})')
                            errors.append(f'{model}/{entry.alias}: {exc}')
                            break
                        if _is_transient_service_error(exc):
                            if transient_try < max(0, int(cfg.retries_per_key)):
                                delay = max(0.0, float(cfg.backoff_seconds)) * (2 ** transient_try)
                                transient_try += 1
                                print(f"   ⏳ Commentary service busy → retry same key {transient_try}/{cfg.retries_per_key} in {delay:.0f}s")
                                if delay:
                                    time.sleep(delay)
                                continue
                            print(f"   ⚠️ Commentary model still busy → fallback model before burning all free keys ({model})")
                            errors.append(f"{model}/{entry.alias}: {exc}")
                            switch_model = True
                            break
                        raise
                if switch_model:
                    break
            if switch_model:
                continue
    finally:
        _restore_proxy(proxy_state)
    raise RuntimeError("Commentary Gemini failed across model/key fallbacks. " + " | ".join(errors[-6:]))
