from __future__ import annotations

"""Standalone YouTube/channel source inbox for TT Long-to-Short night prep.

TT Master only passes category source URLs through the thin bridge.  This file
lives inside long_to_short and owns remote discovery/download/dedupe state.
"""

import hashlib
import json
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

try:
    import yt_dlp  # type: ignore
except Exception:  # pragma: no cover - surfaced clearly at runtime
    yt_dlp = None


VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".webm", ".m4v"}


def _atomic_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    os.close(fd)
    tmp = Path(name)
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


def _clean_key(value: str) -> str:
    out = re.sub(r"[^a-z0-9_-]+", "_", str(value or "").strip().lower()).strip("_")
    return out or "general"


def _video_id_from_url(url: str) -> str:
    text = str(url or "").strip()
    m = re.search(r"(?:v=|youtu\.be/|/shorts/|/live/)([A-Za-z0-9_-]{6,})", text)
    return m.group(1) if m else ""


class TTSourceScanner:
    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.state_path = self.root / "state" / "tt_bridge" / "remote_source_registry.json"
        self.download_root = self.root / "input" / "_tt_sources"
        self.download_root.mkdir(parents=True, exist_ok=True)
        self.proxy = str(os.getenv("DOWNLOAD_PROXY") or os.getenv("HTTPS_PROXY") or "").strip() or None
        self.registry = self._load()

    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8")) if self.state_path.exists() else {}
        except Exception:
            data = {}
        if not isinstance(data, dict):
            data = {}
        data.setdefault("version", 1)
        data.setdefault("items", {})
        return data

    def _save(self) -> None:
        self.registry["updated_at"] = datetime.now(timezone.utc).isoformat()
        _atomic_json(self.state_path, self.registry)

    @staticmethod
    def _is_direct_video(url: str) -> bool:
        text = str(url or "").lower()
        return bool(_video_id_from_url(text)) or "youtube.com/watch" in text

    @staticmethod
    def _scan_url(url: str) -> str:
        clean = str(url or "").strip().rstrip("/")
        if not clean:
            return clean
        if TTSourceScanner._is_direct_video(clean) or "playlist?" in clean or "/playlist" in clean:
            return clean
        if "youtube.com/@" in clean or "/channel/" in clean or "/c/" in clean or "/user/" in clean:
            if clean.endswith(("/videos", "/streams", "/podcasts", "/shorts")):
                return clean
            # Long-to-Short needs long uploads, not Shorts by default.
            return clean + "/videos"
        return clean

    def _base_opts(self) -> dict[str, Any]:
        opts: dict[str, Any] = {"quiet": True, "no_warnings": True, "ignoreerrors": True}
        if self.proxy:
            opts["proxy"] = self.proxy
        return opts

    @staticmethod
    def _item_key(category: str, video_id: str) -> str:
        return f"{_clean_key(category)}:{video_id}"

    def _flat_scan(self, url: str, scan_limit: int) -> list[dict[str, Any]]:
        if yt_dlp is None:
            raise RuntimeError("yt-dlp is required for Long-to-Short channel scanning. Run: python -m pip install -U yt-dlp")
        target = self._scan_url(url)
        opts = self._base_opts()
        if self._is_direct_video(target):
            opts.update({"skip_download": True, "noplaylist": True})
            info = self._extract_with_cookie_fallback(target, opts, purpose="direct source scan")
            vid = str(info.get("id") or _video_id_from_url(target) or "").strip()
            return [self._entry(info, vid, target, 0)] if vid else []
        opts.update({
            "extract_flat": "in_playlist", "skip_download": True,
            "playlistend": max(1, int(scan_limit)), "lazy_playlist": False,
        })
        info = self._extract_with_cookie_fallback(target, opts, purpose="channel scan")
        rows: list[dict[str, Any]] = []
        for rank, entry in enumerate(info.get("entries") or []):
            if not entry:
                continue
            vid = str(entry.get("id") or "").strip()
            if not vid:
                continue
            raw_url = str(entry.get("webpage_url") or entry.get("url") or "").strip()
            if not raw_url.startswith("http"):
                raw_url = f"https://www.youtube.com/watch?v={vid}"
            rows.append(self._entry(entry, vid, raw_url, rank))
        return rows

    @staticmethod
    def _entry(info: dict[str, Any], video_id: str, url: str, rank: int) -> dict[str, Any]:
        try:
            duration = float(info.get("duration") or 0.0)
        except Exception:
            duration = 0.0
        try:
            timestamp = float(info.get("timestamp") or info.get("release_timestamp") or 0.0)
        except Exception:
            timestamp = 0.0
        return {
            "video_id": video_id,
            "url": url,
            "title": str(info.get("title") or "").strip(),
            "channel": str(info.get("channel") or info.get("uploader") or "").strip(),
            "duration": duration,
            "timestamp": timestamp,
            "upload_date": str(info.get("upload_date") or ""),
            "rank": int(rank),
        }

    def discover(self, category: str, source_urls: Iterable[str], scan_limit: int = 12) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        seen: set[str] = set()
        for raw in source_urls:
            url = str(raw or "").strip()
            if not url:
                continue
            try:
                found = self._flat_scan(url, scan_limit)
            except Exception as exc:
                print(f"⚠️ LTS category source scan failed → {url}: {exc}")
                continue
            for item in found:
                vid = str(item.get("video_id") or "").strip()
                if not vid or vid in seen:
                    continue
                seen.add(vid)
                key = self._item_key(category, vid)
                reg = self.registry["items"].setdefault(key, {})
                reg.update({
                    "category": _clean_key(category), "video_id": vid,
                    "url": item.get("url"), "title": item.get("title"),
                    "channel": item.get("channel"), "duration": item.get("duration"),
                    "last_seen_at": datetime.now(timezone.utc).isoformat(),
                })
                rows.append(item)
        self._save()
        # Most channel scans are already newest-first; timestamp is a useful tie breaker.
        rows.sort(key=lambda x: (float(x.get("timestamp") or 0.0), -int(x.get("rank") or 0)), reverse=True)
        return rows

    @staticmethod
    def _antibot(exc: Exception | str) -> bool:
        """Match the proven Recap YouTube anti-bot/login challenge policy."""
        msg = str(exc or "").casefold()
        markers = (
            "sign in to confirm you’re not a bot",
            "sign in to confirm you're not a bot",
            "confirm you’re not a bot",
            "confirm you're not a bot",
            "use --cookies-from-browser or --cookies for the authentication",
            "use --cookies-from-browser",
        )
        return any(x in msg for x in markers)

    @staticmethod
    def _firefox_cookie_opts() -> dict[str, Any]:
        # Keep parity with the stable Recap downloader.  Do not force cookies
        # on every request; only use the logged-in Firefox profile after an
        # explicit YouTube anti-bot/login challenge.
        return {"cookiesfrombrowser": ("firefox",)}

    def _extract_with_cookie_fallback(
        self,
        url: str,
        opts: dict[str, Any],
        *,
        purpose: str,
    ) -> dict[str, Any]:
        if yt_dlp is None:
            raise RuntimeError("yt-dlp is required for Long-to-Short YouTube access")

        def run(extra: dict[str, Any] | None = None) -> dict[str, Any]:
            merged = dict(opts)
            if extra:
                merged.update(extra)
            # yt-dlp's ignoreerrors mode prints an anti-bot failure and returns
            # an empty result.  The fallback can only run when the challenge is
            # raised to this wrapper as an exception.
            merged["ignoreerrors"] = False
            with yt_dlp.YoutubeDL(merged) as ydl:
                return ydl.extract_info(url, download=False) or {}

        try:
            return run()
        except Exception as first:
            if not self._antibot(first):
                raise
            print(f"🤖 YouTube anti-bot challenge during {purpose}.")
            print("🍪 Firefox login cookies နဲ့ auto-retry လုပ်နေပါသည်...")
            try:
                info = run(self._firefox_cookie_opts())
                print(f"✅ Firefox cookie fallback {purpose} အောင်မြင်ပါပြီ။")
                return info
            except Exception as cookie_error:
                raise RuntimeError(
                    f"YouTube anti-bot challenge during {purpose}; Firefox cookie fallback also failed: "
                    f"{cookie_error}"
                ) from cookie_error

    def _metadata(self, url: str) -> dict[str, Any]:
        if yt_dlp is None:
            raise RuntimeError("yt-dlp is required for Long-to-Short source metadata")
        opts = self._base_opts(); opts.update({"skip_download": True, "noplaylist": True})
        return self._extract_with_cookie_fallback(url, opts, purpose="metadata")

    def _download(self, category: str, item: dict[str, Any]) -> Path:
        if yt_dlp is None:
            raise RuntimeError("yt-dlp is required for Long-to-Short channel downloads")
        cat = _clean_key(category); vid = str(item.get("video_id") or "").strip()
        if not vid:
            raise RuntimeError("remote source has no video_id")
        folder = self.download_root / cat
        folder.mkdir(parents=True, exist_ok=True)
        output = folder / f"{vid}.mp4"
        if output.exists() and output.stat().st_size > 50_000:
            return output
        url = str(item.get("url") or f"https://www.youtube.com/watch?v={vid}")
        base = self._base_opts()
        base.update({
            "format": "bestvideo[height<=1080]+bestaudio/best[height<=1080]/best",
            "merge_output_format": "mp4", "outtmpl": str(output), "noplaylist": True,
            "retries": 10, "fragment_retries": 10, "continuedl": True,
        })
        def run(extra: dict[str, Any] | None = None) -> None:
            opts = dict(base)
            if extra: opts.update(extra)
            # Do not swallow YouTube login/anti-bot failures.  A swallowed
            # DownloadError used to skip the Firefox retry and surface later as
            # the misleading "Downloaded source is incomplete" error.
            opts["ignoreerrors"] = False
            with yt_dlp.YoutubeDL(opts) as ydl:
                ydl.download([url])
        try:
            run()
        except Exception as first:
            if not self._antibot(first):
                raise
            print("🤖 YouTube anti-bot challenge detected during source download.")
            print("🍪 Firefox login cookies နဲ့ auto-retry လုပ်နေပါသည်...")
            try:
                run(self._firefox_cookie_opts())
                print("✅ Firefox cookie fallback source download အောင်မြင်ပါပြီ။")
            except Exception as cookie_error:
                raise RuntimeError(
                    "YouTube anti-bot challenge during source download; Firefox cookie fallback also failed: "
                    f"{cookie_error}"
                ) from cookie_error
        if not output.exists() or output.stat().st_size < 50_000:
            raise RuntimeError(f"Downloaded source is incomplete: {output}")
        return output

    def next_download(
        self, category: str, source_urls: Iterable[str], *, excluded_paths: set[str] | None = None,
        scan_limit: int = 12, min_source_seconds: float = 600.0,
    ) -> Path | None:
        excluded = {str(Path(p).resolve()) for p in (excluded_paths or set()) if p}
        for item in self.discover(category, source_urls, scan_limit=scan_limit):
            vid = str(item.get("video_id") or "").strip()
            key = self._item_key(category, vid)
            reg = self.registry["items"].setdefault(key, {})
            if bool(reg.get("rejected")):
                continue
            existing = str(reg.get("local_path") or "").strip()
            if existing:
                p = Path(existing)
                if p.exists() and str(p.resolve()) not in excluded:
                    return p.resolve()
                if str(p.resolve()) in excluded:
                    continue
            duration = float(item.get("duration") or reg.get("duration") or 0.0)
            if duration <= 0:
                try:
                    meta = self._metadata(str(item.get("url") or ""))
                    duration = float(meta.get("duration") or 0.0)
                    reg["duration"] = duration
                    if meta.get("title"): reg["title"] = str(meta.get("title"))
                except Exception as exc:
                    reg["last_error"] = f"metadata: {type(exc).__name__}: {exc}"
                    self._save()
                    continue
            if duration and duration < max(0.0, float(min_source_seconds)):
                reg.update({"rejected": True, "rejected_reason": f"source_too_short_{duration:.0f}s"})
                self._save()
                continue
            try:
                print(f"📥 LTS remote source → {_clean_key(category)} | {reg.get('title') or item.get('title') or vid}")
                path = self._download(category, item).resolve()
                reg.update({
                    "local_path": str(path), "downloaded_at": datetime.now(timezone.utc).isoformat(),
                    "last_error": "", "duration": duration,
                })
                self._save()
                return path
            except Exception as exc:
                reg["last_error"] = f"download: {type(exc).__name__}: {exc}"
                reg["last_attempt_at"] = datetime.now(timezone.utc).isoformat()
                self._save()
                print(f"⚠️ LTS remote download failed → {vid}: {exc}")
        return None
