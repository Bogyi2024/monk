from __future__ import annotations

import math
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_YUNET = ROOT / "models" / "face_detection_yunet_2023mar.onnx"


def _area(b):
    return max(0.0, float(b[2])) * max(0.0, float(b[3]))


def _dedupe_boxes(boxes: list[tuple[float, float, float, float]], iou_threshold: float = 0.38) -> list[tuple[float, float, float, float]]:
    def iou(a, b):
        ax1, ay1, aw, ah = a; ax2, ay2 = ax1 + aw, ay1 + ah
        bx1, by1, bw, bh = b; bx2, by2 = bx1 + bw, by1 + bh
        ix1, iy1 = max(ax1, bx1), max(ay1, by1)
        ix2, iy2 = min(ax2, bx2), min(ay2, by2)
        inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
        union = _area(a) + _area(b) - inter
        return inter / union if union else 0.0

    out: list[tuple[float, float, float, float]] = []
    for box in sorted(boxes, key=_area, reverse=True):
        if all(iou(box, kept) < iou_threshold for kept in out):
            out.append(box)
    return out


def _filter_realistic_faces(
    boxes: list[tuple[float, float, float, float]],
    *,
    min_width_ratio: float = 0.055,
    min_height_ratio: float = 0.075,
    min_area_ratio: float = 0.0042,
    second_face_min_relative_area: float = 0.48,
) -> list[tuple[float, float, float, float]]:
    """Reject tiny framed-photo / wall-art detections.

    Interview subjects are usually much larger than faces inside picture frames.
    We keep the largest credible face and only keep a second face when its size is
    reasonably close to the first. This is deliberately conservative: a missed
    face becomes fit+blur, which is much better than a wrong portrait crop.
    """
    good = [
        b for b in boxes
        if b[2] >= min_width_ratio
        and b[3] >= min_height_ratio
        and _area(b) >= min_area_ratio
        and 0.0 <= b[0] <= 1.0 and 0.0 <= b[1] <= 1.0
    ]
    good = _dedupe_boxes(good)
    if not good:
        return []
    good.sort(key=_area, reverse=True)
    primary = good[0]
    out = [primary]
    if len(good) >= 2 and _area(good[1]) >= _area(primary) * second_face_min_relative_area:
        out.append(good[1])
    return out


def _classify_boxes(boxes: list[tuple[float, float, float, float]]) -> tuple[str, float | None, str]:
    faces = _filter_realistic_faces(boxes)
    if not faces:
        return "fit_blur", None, "no_credible_face"

    # Two similarly large faces far apart are a real two-shot. Until active-speaker
    # tracking lands, protect both people instead of cropping one of them out.
    if len(faces) >= 2:
        centers = sorted(b[0] + b[2] / 2.0 for b in faces)
        if centers[-1] - centers[0] >= 0.34:
            return "fit_blur", None, "two_large_faces_safe_fit"

    primary = max(faces, key=_area)
    cx = primary[0] + primary[2] / 2.0
    cx = min(0.80, max(0.20, float(cx)))
    return "smart_crop", cx, "credible_primary_face"


def _merge_segments(segments: list[dict], *, center_tolerance: float = 0.05) -> list[dict]:
    if not segments:
        return []
    merged: list[dict] = []
    for seg in segments:
        if float(seg["end"]) - float(seg["start"]) <= 0.02:
            continue
        if not merged:
            merged.append(dict(seg))
            continue
        prev = merged[-1]
        same_mode = prev["mode"] == seg["mode"]
        centers_close = (
            prev["mode"] != "smart_crop"
            or abs(float(prev.get("center_x", 0.5)) - float(seg.get("center_x", 0.5))) <= center_tolerance
        )
        if same_mode and centers_close and abs(float(prev["end"]) - float(seg["start"])) <= 0.08:
            old_d = max(0.001, float(prev["end"]) - float(prev["start"]))
            new_d = max(0.001, float(seg["end"]) - float(seg["start"]))
            if prev["mode"] == "smart_crop":
                prev["center_x"] = (
                    float(prev.get("center_x", 0.5)) * old_d + float(seg.get("center_x", 0.5)) * new_d
                ) / (old_d + new_d)
            prev["end"] = seg["end"]
            prev["reason"] = prev.get("reason") or seg.get("reason")
        else:
            merged.append(dict(seg))
    return merged


def _suppress_short_mode_flips(
    segments: list[dict], *, no_face_hold_seconds: float, face_hold_seconds: float
) -> list[dict]:
    if len(segments) < 2:
        return segments
    work = [dict(x) for x in segments]
    changed = True
    while changed and len(work) >= 2:
        changed = False
        for i, seg in enumerate(work):
            dur = float(seg["end"]) - float(seg["start"])
            threshold = no_face_hold_seconds if seg["mode"] == "fit_blur" else face_hold_seconds
            if dur + 1e-6 >= threshold:
                continue
            left = work[i - 1] if i > 0 else None
            right = work[i + 1] if i + 1 < len(work) else None
            replacement = None
            if left and right and left["mode"] == right["mode"]:
                replacement = left
            elif left:
                replacement = left
            elif right:
                replacement = right
            if replacement is None:
                continue
            seg["mode"] = replacement["mode"]
            seg["center_x"] = float(replacement.get("center_x", 0.5))
            seg["reason"] = replacement.get("reason", "hysteresis")
            changed = True
        work = _merge_segments(work)
    return work


def decide_framing_from_samples(
    samples: list[dict],
    duration: float,
    *,
    no_face_hold_seconds: float = 1.0,
    face_hold_seconds: float = 0.55,
) -> dict:
    duration = max(0.1, float(duration))
    if not samples:
        return {
            "mode": "fit_blur",
            "reason": "no_samples_safe_fit",
            "center_x": 0.5,
            "segments": [{"start": 0.0, "end": duration, "mode": "fit_blur", "center_x": 0.5}],
        }

    ordered = sorted(samples, key=lambda x: float(x.get("time", 0.0)))
    points = []
    for s in ordered:
        mode, cx, why = _classify_boxes(list(s.get("boxes") or []))
        points.append({
            "time": min(duration, max(0.0, float(s.get("time", 0.0)))),
            "mode": mode,
            "center_x": 0.5 if cx is None else cx,
            "reason": why,
        })

    bounds = [0.0]
    for a, b in zip(points, points[1:]):
        bounds.append(min(duration, max(0.0, (a["time"] + b["time"]) / 2.0)))
    bounds.append(duration)

    raw: list[dict] = []
    for i, p in enumerate(points):
        st, en = bounds[i], bounds[i + 1]
        if en <= st + 0.01:
            continue
        raw.append({
            "start": round(st, 3),
            "end": round(en, 3),
            "mode": p["mode"],
            "center_x": round(float(p.get("center_x", 0.5)), 5),
            "reason": p.get("reason"),
        })

    segments = _merge_segments(raw)
    segments = _suppress_short_mode_flips(
        segments,
        no_face_hold_seconds=float(no_face_hold_seconds),
        face_hold_seconds=float(face_hold_seconds),
    )
    segments = _merge_segments(segments)
    if not segments:
        segments = [{"start": 0.0, "end": duration, "mode": "fit_blur", "center_x": 0.5, "reason": "empty_safe_fit"}]
    segments[0]["start"] = 0.0
    segments[-1]["end"] = duration

    face_seconds = sum(float(s["end"]) - float(s["start"]) for s in segments if s["mode"] == "smart_crop")
    blur_seconds = sum(float(s["end"]) - float(s["start"]) for s in segments if s["mode"] == "fit_blur")

    main_mode = segments[0]["mode"] if len(segments) == 1 else "dynamic"
    reason = segments[0].get("reason", "single_segment") if len(segments) == 1 else "yunet_segment_aware_safe_fallback"
    return {
        "mode": main_mode,
        "reason": reason,
        "center_x": float(segments[0].get("center_x", 0.5)),
        "segments": segments,
        "face_seconds": round(face_seconds, 3),
        "blur_seconds": round(blur_seconds, 3),
        "sample_frames": len(points),
    }


def _opencv_capability():
    try:
        import cv2
    except Exception as exc:
        return None, {"reason": "opencv_unavailable_safe_fit", "opencv_detail": type(exc).__name__}
    required = ("VideoCapture", "CAP_PROP_POS_MSEC", "resize")
    missing = [name for name in required if not hasattr(cv2, name)]
    if missing:
        return None, {
            "reason": "opencv_incomplete_safe_fit",
            "opencv_detail": "missing=" + ",".join(missing),
            "opencv_module": str(getattr(cv2, "__file__", "unknown")),
        }
    return cv2, None


def _create_yunet(cv2, model_path: Path, input_size: tuple[int, int], score_threshold: float):
    if not model_path.exists() or model_path.stat().st_size < 100_000:
        return None
    try:
        if hasattr(cv2, "FaceDetectorYN") and hasattr(cv2.FaceDetectorYN, "create"):
            return cv2.FaceDetectorYN.create(
                str(model_path), "", input_size,
                float(score_threshold), 0.3, 5000,
            )
        if hasattr(cv2, "FaceDetectorYN_create"):
            return cv2.FaceDetectorYN_create(
                str(model_path), "", input_size,
                float(score_threshold), 0.3, 5000,
            )
    except Exception:
        return None
    return None


def _detect_yunet(detector, frame, cv2, *, score_threshold: float) -> list[tuple[float, float, float, float]]:
    h, w = frame.shape[:2]
    detector.setInputSize((w, h))
    _ok, faces = detector.detect(frame)
    if faces is None:
        return []
    out = []
    for row in faces:
        if len(row) < 5:
            continue
        x, y, bw, bh = map(float, row[:4])
        score = float(row[-1])
        if score < score_threshold:
            continue
        out.append((x / w, y / h, bw / w, bh / h))
    return out


def _detect_haar_strict(frame, cv2, frontal, profile=None) -> list[tuple[float, float, float, float]]:
    h, w = frame.shape[:2]
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)
    boxes = []
    if frontal is not None and not frontal.empty():
        found = frontal.detectMultiScale(gray, scaleFactor=1.08, minNeighbors=7, minSize=(40, 40))
        boxes.extend([tuple(map(float, b)) for b in found])
    # Profile cascade is only a last resort and is intentionally stricter.
    if not boxes and profile is not None and not profile.empty():
        found = profile.detectMultiScale(gray, scaleFactor=1.08, minNeighbors=8, minSize=(44, 44))
        boxes.extend([tuple(map(float, b)) for b in found])
    return [(x / w, y / h, bw / w, bh / h) for x, y, bw, bh in boxes]


def analyze_clip_framing(
    src: str | Path,
    start: float,
    end: float,
    *,
    sample_count: int = 14,
    detection_width: int = 640,
    sample_interval_seconds: float = 1.25,
    max_samples: int = 120,
    no_face_hold_seconds: float = 1.0,
    face_hold_seconds: float = 0.55,
    yunet_model_path: str | Path | None = None,
    yunet_score_threshold: float = 0.88,
) -> dict:
    """YuNet-first interview framing.

    - credible live face -> full 9:16 smart crop
    - no credible face   -> temporary fit+blur
    - two large faces    -> safe fit+blur until active-speaker tracking arrives

    Haar is kept only as a strict emergency fallback. The old loose Haar logic
    was prone to locking onto framed artwork and is intentionally not trusted.
    """
    duration = max(0.25, float(end) - float(start))
    cv2, capability_error = _opencv_capability()
    if cv2 is None:
        return {
            "mode": "fit_blur",
            "reason": capability_error["reason"],
            "center_x": 0.5,
            "segments": [{"start": 0.0, "end": duration, "mode": "fit_blur", "center_x": 0.5}],
            **{k: v for k, v in capability_error.items() if k != "reason"},
        }

    src = str(Path(src).resolve())
    cap = cv2.VideoCapture(src)
    if not cap.isOpened():
        return {
            "mode": "fit_blur",
            "reason": "video_open_failed_safe_fit",
            "center_x": 0.5,
            "segments": [{"start": 0.0, "end": duration, "mode": "fit_blur", "center_x": 0.5}],
        }

    model_path = Path(yunet_model_path).expanduser() if yunet_model_path else DEFAULT_YUNET
    interval = max(0.6, float(sample_interval_seconds))
    auto_count = int(math.ceil(duration / interval))
    count = min(max(8, int(sample_count), auto_count), max(8, int(max_samples)))
    times_rel = [duration * ((i + 0.5) / count) for i in range(count)]
    samples: list[dict] = []
    detector_kind = "yunet"

    try:
        detector = None
        frontal = profile = None
        # Detector is created after the first frame establishes the resized dimensions.
        for rel_t in times_rel:
            cap.set(cv2.CAP_PROP_POS_MSEC, (float(start) + rel_t) * 1000.0)
            ok, frame = cap.read()
            if not ok or frame is None:
                samples.append({"time": rel_t, "boxes": []})
                continue
            h, w = frame.shape[:2]
            if w <= 0 or h <= 0:
                samples.append({"time": rel_t, "boxes": []})
                continue
            scale = min(1.0, float(detection_width) / float(w))
            small = cv2.resize(frame, (max(1, int(w * scale)), max(1, int(h * scale))))

            if detector is None:
                detector = _create_yunet(cv2, model_path, (small.shape[1], small.shape[0]), float(yunet_score_threshold))
                if detector is None:
                    detector_kind = "haar_strict"
                    haar_root = getattr(getattr(cv2, "data", None), "haarcascades", None)
                    if haar_root and hasattr(cv2, "CascadeClassifier"):
                        frontal = cv2.CascadeClassifier(str(haar_root) + "haarcascade_frontalface_default.xml")
                        profile = cv2.CascadeClassifier(str(haar_root) + "haarcascade_profileface.xml")

            if detector is not None:
                boxes = _detect_yunet(detector, small, cv2, score_threshold=float(yunet_score_threshold))
            elif frontal is not None:
                boxes = _detect_haar_strict(small, cv2, frontal, profile)
            else:
                boxes = []
            boxes = _filter_realistic_faces(boxes)
            samples.append({"time": rel_t, "boxes": boxes})

        decision = decide_framing_from_samples(
            samples,
            duration,
            no_face_hold_seconds=float(no_face_hold_seconds),
            face_hold_seconds=float(face_hold_seconds),
        )
        decision["analyzer"] = "opencv_yunet_2023mar_v1" if detector_kind == "yunet" else "opencv_haar_strict_fallback_v1"
        decision["yunet_model"] = str(model_path)
        decision["yunet_available"] = bool(detector_kind == "yunet")
        return decision
    except Exception as exc:
        return {
            "mode": "fit_blur",
            "reason": "face_analysis_failed_safe_fit",
            "center_x": 0.5,
            "segments": [{"start": 0.0, "end": duration, "mode": "fit_blur", "center_x": 0.5}],
            "opencv_detail": f"{type(exc).__name__}: {exc}",
        }
    finally:
        cap.release()
