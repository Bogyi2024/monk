from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from services.original_audio_mm_service import OriginalMMConfig, translate_texts_cached
from services.whisper_runtime import load_whisper_model

ROOT = Path(__file__).resolve().parents[1]
ALIGN_CACHE_VERSION = "voiceover_word_alignment_v2_complete_end"


def _norm_ws(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _join_words(words: list[str]) -> str:
    text = " ".join(w.strip() for w in words if w and w.strip())
    text = re.sub(r"\s+([,.;:!?%])", r"\1", text)
    text = re.sub(r"([\(\[\{])\s+", r"\1", text)
    return _norm_ws(text)


def _cache_key(path: str | Path) -> str:
    p = Path(path)
    h = hashlib.sha256()
    h.update(ALIGN_CACHE_VERSION.encode("utf-8"))
    h.update(str(p.stat().st_size).encode("ascii"))
    with p.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()[:24]


class VoiceoverAligner:
    """Whisper-align synthesized English narration once, then reuse the model.

    This fixes the old V0.3 proportional timing behavior. Burmese captions are
    now based on what the narrator ACTUALLY said and on Whisper word timestamps.
    """

    def __init__(self, model_name: str = "medium", device: str = "cuda", compute_type: str = "float16"):
        self.model_name = model_name
        self.device = device
        self.compute_type = compute_type
        self._model = None
        self.actual_device = None
        self.actual_compute = None

    def _ensure_model(self):
        if self._model is not None:
            return self._model
        print(f"🧭 Loading VO alignment Whisper once: model={self.model_name} device={self.device} compute={self.compute_type}")
        self._model, self.actual_device, self.actual_compute = load_whisper_model(
            self.model_name, self.device, self.compute_type)
        return self._model

    def transcribe_words_cached(self, wav_path: str | Path) -> tuple[list[dict], dict]:
        wav = Path(wav_path).resolve()
        cache_dir = ROOT / "state" / "voiceover_alignment_cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        key = _cache_key(wav)
        cache_file = cache_dir / f"{key}.json"
        if cache_file.exists():
            try:
                obj = json.loads(cache_file.read_text(encoding="utf-8"))
                words = list(obj.get("words") or [])
                if words:
                    return words, {"cached": True, "cache": str(cache_file), "word_count": len(words)}
            except Exception:
                pass

        model = self._ensure_model()
        print(f"   🎧 Aligning narrator words → {wav.name} on {self.actual_device}/{self.actual_compute}")
        segments, info = model.transcribe(
            str(wav),
            vad_filter=False,
            beam_size=1,
            word_timestamps=True,
            condition_on_previous_text=False,
            temperature=0.0,
        )
        words: list[dict] = []
        fallback_segments: list[dict] = []
        for seg in segments:
            seg_text = _norm_ws(getattr(seg, "text", "") or "")
            if seg_text:
                fallback_segments.append({
                    "start": float(getattr(seg, "start", 0.0) or 0.0),
                    "end": float(getattr(seg, "end", 0.0) or 0.0),
                    "text": seg_text,
                })
            for w in (getattr(seg, "words", None) or []):
                text = str(getattr(w, "word", "") or "").strip()
                if not text:
                    continue
                words.append({
                    "start": round(float(getattr(w, "start", 0.0) or 0.0), 3),
                    "end": round(float(getattr(w, "end", 0.0) or 0.0), 3),
                    "word": text,
                })

        if not words and fallback_segments:
            # Rare fallback: approximate word timing inside Whisper's own segment.
            for seg in fallback_segments:
                toks = seg["text"].split()
                if not toks:
                    continue
                dur = max(0.05, seg["end"] - seg["start"])
                for i, tok in enumerate(toks):
                    a = seg["start"] + dur * (i / len(toks))
                    b = seg["start"] + dur * ((i + 1) / len(toks))
                    words.append({"start": round(a, 3), "end": round(b, 3), "word": tok})

        if not words:
            raise RuntimeError("VO alignment Whisper returned no words")

        payload = {
            "version": ALIGN_CACHE_VERSION,
            "language": getattr(info, "language", None),
            "model": self.model_name,
            "words": words,
        }
        cache_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return words, {"cached": False, "cache": str(cache_file), "word_count": len(words)}


def _ends_sentence(text: str) -> bool:
    text = _norm_ws(text)
    if not text:
        return False
    if re.search(r"(?:\.\.\.|…|[-–—])\s*$", text):
        return False
    return bool(re.search(r"[.!?][\"\'’”)]*$", text))


def group_spoken_words(
    words: list[dict],
    *,
    max_words: int = 8,
    max_seconds: float = 3.2,
    min_words_before_punctuation_break: int = 3,
    min_seconds_before_punctuation_break: float = 1.0,
) -> list[dict]:
    """Turn word timestamps into short spoken subtitle beats.

    V0.3.5 waits a little past the soft word/time limit for a natural sentence
    boundary. This avoids ugly chunks such as ``who you truly`` followed by
    ``are. Self-awareness ...``. Hard limits still protect readability.
    """
    clean = [w for w in words if _norm_ws(w.get("word") or "")]
    if not clean:
        return []

    events: list[dict] = []
    current: list[dict] = []
    strong_end = re.compile(r"[.!?][\"'’”)]*$")
    soft_end = re.compile(r"[,;:][\"'’”)]*$")
    soft_word_limit = max(2, int(max_words))
    hard_word_limit = soft_word_limit + 2
    soft_time_limit = max(1.0, float(max_seconds))
    hard_time_limit = soft_time_limit + 0.9

    def flush():
        nonlocal current
        if not current:
            return
        events.append({
            "start": float(current[0]["start"]),
            "end": max(float(current[-1]["end"]), float(current[0]["start"]) + 0.08),
            "en": _join_words([str(x.get("word") or "") for x in current]),
        })
        current = []

    for w in clean:
        current.append(w)
        start = float(current[0]["start"])
        end = float(current[-1]["end"])
        dur = end - start
        text = str(w.get("word") or "")

        # Prefer an actual sentence ending whenever possible.
        if strong_end.search(text) and len(current) >= min_words_before_punctuation_break:
            flush()
            continue
        if soft_end.search(text) and len(current) >= max(4, min_words_before_punctuation_break) and dur >= min_seconds_before_punctuation_break:
            flush()
            continue

        # Soft limit: hold briefly for punctuation instead of chopping a phrase.
        if len(current) >= hard_word_limit or dur >= hard_time_limit:
            flush()
        elif len(current) >= soft_word_limit or dur >= soft_time_limit:
            # Deliberately wait up to +2 words / +0.9s for a natural stop.
            pass
    flush()

    # Merge tiny tails so viewers don't get 1-2 word flashes.
    if len(events) >= 2:
        last = events[-1]
        prev = events[-2]
        last_wc = len(last["en"].split())
        last_dur = float(last["end"]) - float(last["start"])
        if last_wc <= 2 or last_dur < 0.7:
            prev["end"] = last["end"]
            prev["en"] = _join_words([prev["en"], last["en"]])
            events.pop()

    if events and events[0]["start"] < 0.35:
        events[0]["start"] = 0.0
    return events


def enforce_complete_spoken_ending(
    en_events: list[dict],
    mm_events: list[dict],
    *,
    wav_duration: float,
    min_keep_ratio: float = 0.72,
    tail_hold_seconds: float = 0.18,
) -> tuple[list[dict], list[dict], float, dict]:
    """Never publish a narrator clip that visibly/audio-wise ends mid-sentence.

    Streaming TTS can occasionally stop cleanly at the transport layer while the
    spoken sentence itself is unfinished. We inspect the *actual Whisper aligned*
    narration, walk back to the last complete English sentence, drop the dangling
    subtitle beat, and trim the rendered narration/video to that clean stop.
    No new Gemini/TTS call is required.
    """
    if not en_events:
        return en_events, mm_events, float(wav_duration), {"trimmed": False, "reason": "no_events"}

    n = min(len(en_events), len(mm_events)) if mm_events else len(en_events)
    en_events = list(en_events[:n])
    mm_events = list(mm_events[:n])
    last_text = _norm_ws(en_events[-1].get("en") or "")
    if _ends_sentence(last_text):
        return en_events, mm_events, float(wav_duration), {"trimmed": False, "reason": "already_complete"}

    keep_idx = None
    for i in range(n - 2, -1, -1):
        if _ends_sentence(str(en_events[i].get("en") or "")):
            keep_end = float(en_events[i].get("end") or 0.0)
            if keep_end >= float(wav_duration) * float(min_keep_ratio):
                keep_idx = i
                break

    if keep_idx is None:
        # Safety: do not throw away a huge portion of a clip. Keep it and mark QA.
        return en_events, mm_events, float(wav_duration), {
            "trimmed": False,
            "reason": "no_safe_complete_sentence_near_end",
            "last_en": last_text,
        }

    en_events = en_events[: keep_idx + 1]
    mm_events = mm_events[: keep_idx + 1]

    # Ensure the final Burmese caption looks finished too.
    if mm_events:
        mm_last = _norm_ws(mm_events[-1].get("text") or "")
        mm_last = re.sub(r"(?:\.\.\.|…)+\s*$", "", mm_last).rstrip(" ၊,;:")
        if mm_last and not re.search(r"[။!?]$", mm_last):
            mm_last += "။"
        mm_events[-1] = {**mm_events[-1], "text": mm_last}

    clean_end = min(float(wav_duration), float(en_events[-1]["end"]) + max(0.05, float(tail_hold_seconds)))
    return en_events, mm_events, clean_end, {
        "trimmed": True,
        "reason": "actual_narration_ended_mid_sentence",
        "original_duration": round(float(wav_duration), 3),
        "clean_duration": round(clean_end, 3),
        "dropped_event_count": n - (keep_idx + 1),
        "dropped_last_en": last_text,
        "kept_last_en": _norm_ws(en_events[-1].get("en") or ""),
    }


def build_spoken_mm_events_from_voiceover(
    aligner: VoiceoverAligner,
    wav_path: str | Path,
    mm_cfg: OriginalMMConfig,
    *,
    max_words: int = 8,
    max_seconds: float = 3.2,
) -> tuple[list[dict], list[dict], dict]:
    words, align_meta = aligner.transcribe_words_cached(wav_path)
    en_events = group_spoken_words(words, max_words=max_words, max_seconds=max_seconds)
    if not en_events:
        raise RuntimeError("No spoken subtitle chunks were created from narrator audio")

    mm_texts, trans_meta = translate_texts_cached([e["en"] for e in en_events], mm_cfg)
    mm_events = [
        {"start": e["start"], "end": e["end"], "text": mm, "en": e["en"]}
        for e, mm in zip(en_events, mm_texts)
    ]
    return en_events, mm_events, {"alignment": align_meta, "translation": trans_meta}


def build_english_events_from_voiceover(
    aligner: VoiceoverAligner,
    wav_path: str | Path,
    *,
    max_words: int = 8,
    max_seconds: float = 3.2,
) -> tuple[list[dict], dict]:
    words, align_meta = aligner.transcribe_words_cached(wav_path)
    en_events = group_spoken_words(words, max_words=max_words, max_seconds=max_seconds)
    if not en_events:
        raise RuntimeError("No English spoken subtitle chunks were created from narrator audio")
    return en_events, align_meta


def attach_spoken_myanmar_to_english_events(
    en_events: list[dict],
    mm_cfg: OriginalMMConfig,
) -> tuple[list[dict], dict]:
    mm_texts, trans_meta = translate_texts_cached([e["en"] for e in en_events], mm_cfg)
    mm_events = [
        {"start": e["start"], "end": e["end"], "text": mm, "en": e["en"]}
        for e, mm in zip(en_events, mm_texts)
    ]
    return mm_events, trans_meta


def narration_coverage(expected_text: str, en_events: list[dict]) -> dict:
    """Compare requested narration with what Whisper heard from the actual TTS WAV.

    This catches the important failure mode where Gemini TTS returns a perfectly
    valid audio file but silently stops before reading the entire transcript.
    """
    from difflib import SequenceMatcher

    def tokens(text: str) -> list[str]:
        return re.findall(r"[a-z0-9]+(?:'[a-z0-9]+)?", str(text or "").lower())

    expected = tokens(expected_text)
    actual = tokens(" ".join(str(e.get("en") or "") for e in en_events))
    if not expected:
        return {"coverage": 1.0, "tail_similarity": 1.0, "expected_words": 0, "heard_words": len(actual)}
    sm = SequenceMatcher(None, expected, actual, autojunk=False)
    matched = sum(m.size for m in sm.get_matching_blocks())
    coverage = matched / max(1, len(expected))

    tail_n = min(18, len(expected))
    expected_tail = expected[-tail_n:]
    actual_tail = actual[-max(tail_n * 2, tail_n):]
    tail_similarity = SequenceMatcher(None, expected_tail, actual_tail, autojunk=False).ratio() if actual_tail else 0.0
    return {
        "coverage": round(float(coverage), 4),
        "tail_similarity": round(float(tail_similarity), 4),
        "expected_words": len(expected),
        "heard_words": len(actual),
        "matched_words": int(matched),
        "expected_tail": " ".join(expected_tail),
        "heard_tail": " ".join(actual[-tail_n:]),
    }
