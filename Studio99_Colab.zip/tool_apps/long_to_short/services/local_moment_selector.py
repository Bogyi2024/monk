from __future__ import annotations
import re

def _score(text: str) -> float:
    t = text.lower()
    score = min(len(text)/120.0, 2.0)
    hooks = ["but", "however", "then", "suddenly", "why", "how", "secret", "never", "most", "first", "finally", "actually", "problem", "mistake", "truth"]
    score += sum(0.45 for h in hooks if h in t)
    score += 0.35 * len(re.findall(r"[!?]", text))
    return score

def select_candidates(segments: list[dict], count=5, min_seconds=25, max_seconds=75) -> list[dict]:
    if not segments: return []
    candidates=[]
    n=len(segments)
    for i in range(n):
        start=segments[i]["start"]
        text_parts=[]
        end=start
        j=i
        while j<n and end-start < min_seconds:
            text_parts.append(segments[j]["text"])
            end=segments[j]["end"]
            j+=1
        while j<n and end-start < max_seconds and len(" ".join(text_parts)) < 900:
            text_parts.append(segments[j]["text"])
            end=segments[j]["end"]
            j+=1
        dur=end-start
        if min_seconds <= dur <= max_seconds+5:
            txt=" ".join(text_parts)
            candidates.append({"start":round(start,3),"end":round(end,3),"duration":round(dur,3),"score":round(_score(txt),3),"text":txt})
    # diversity: greedily keep candidates that don't overlap too much
    candidates.sort(key=lambda x:x["score"], reverse=True)
    chosen=[]
    for c in candidates:
        overlap=False
        for p in chosen:
            inter=max(0,min(c["end"],p["end"])-max(c["start"],p["start"]))
            if inter/min(c["duration"],p["duration"]) > 0.5:
                overlap=True; break
        if not overlap:
            chosen.append(c)
        if len(chosen)>=count: break
    return chosen
