from __future__ import annotations

"""Cached Burmese social copy for Long-to-Short exports.

This is deliberately separate from the clip selector and narration writer: it
creates publishing metadata only and never changes a selected clip or its video.
"""

import hashlib
import json
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from services.gemini_moment_selector import (
    _is_key_rotatable_error,
    _is_model_unavailable_error,
    _is_transient_service_error,
    _is_request_timeout_error,
    _model_chain,
    _proxy_if_listening,
    _restore_proxy,
    resolve_api_keys,
)


ROOT = Path(__file__).resolve().parents[1]
PROMPT_VERSION = "lts_social_metadata_mm_title_en_hashtags_v2"


@dataclass
class SocialMetadataConfig:
    enabled: bool = True
    model: str = "gemini-3.5-flash"
    model_fallbacks: tuple[str, ...] = ("gemini-3.5-flash-lite",)
    temperature: float = 0.55
    hashtag_limit: int = 6
    allow_paid_fallback: bool = False
    retries_per_key: int = 1
    backoff_seconds: float = 4.0
    reuse_cache: bool = True


def _schema(count: int) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "clips": {
                "type": "array", "minItems": count, "maxItems": count,
                "items": {
                    "type": "object",
                    "properties": {
                        "index": {"type": "integer"},
                        "title": {"type": "string"},
                        "hook": {"type": "string"},
                        "fb_caption": {"type": "string"},
                        "tt_caption": {"type": "string"},
                        "hashtags": {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["index", "title", "hook", "fb_caption", "tt_caption", "hashtags"],
                },
            }
        },
        "required": ["clips"],
    }


def _clean(value: Any, maximum: int) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()[:maximum]


def _contains_myanmar(value: str) -> bool:
    return bool(re.search(r"[\u1000-\u109f\uaa60-\uaa7f]", str(value or "")))


def _hashtags(values: Any, limit: int) -> list[str]:
    out: list[str] = []
    for value in values if isinstance(values, list) else []:
        tag = _clean(value, 50).replace(" ", "")
        if not tag:
            continue
        if not tag.startswith("#"):
            tag = "#" + tag
        # Publishing copy stays Burmese, but discovery tags are intentionally
        # English/ASCII so the route cannot leak Burmese tags from a model reply.
        if not re.fullmatch(r"#[A-Za-z0-9_]+", tag):
            continue
        if len(tag) > 1 and tag.casefold() not in {x.casefold() for x in out}:
            out.append(tag)
    return out[:max(1, limit)]


def _payload(candidates: list[dict], packages: list[dict]) -> str:
    rows = []
    for index, (candidate, package) in enumerate(zip(candidates, packages), 1):
        rows.append({
            "index": index,
            "content_profile": candidate.get("selector_profile") or "generic",
            "editorial_title": candidate.get("title") or package.get("title") or "",
            "hook_summary": candidate.get("hook_summary") or "",
            "source_moment": candidate.get("text") or "",
            "commentary_summary": package.get("english_voiceover") or "",
        })
    return json.dumps(rows, ensure_ascii=False, indent=2)


def _prompt(candidates: list[dict], packages: list[dict], cfg: SocialMetadataConfig) -> str:
    return f"""
You are a Burmese social-media editor for vertical video. Write accurate,
attention-grabbing publishing copy for every supplied clip.

Return Burmese copy. You may keep a well-known English name or term where natural.
The title must be a compact click-worthy hook (maximum 90 characters), but it must
not invent events, exaggerate a claim beyond the source, promise a result, or use
misleading "you won't believe" filler. It should make a viewer want to watch.

For every clip return:
- title: one strong Burmese hook/title, no hashtag.
- hook: a short first-line hook, no hashtag.
- fb_caption: 1-2 natural Burmese lines; put the hook first and invite a relevant
  reaction/viewing without generic spam. Do not include hashtags.
- tt_caption: short Burmese TikTok caption, no hashtag.
- hashtags: {max(1, cfg.hashtag_limit - 2)} to {cfg.hashtag_limit} relevant English-only
  ASCII hashtags such as #Motivation or #SelfImprovement. Do not return Burmese
  hashtags, spaces, or unrelated trending tags. Never use more than {cfg.hashtag_limit}.

Return JSON only. Preserve the input index exactly.

CLIPS:
{_payload(candidates, packages)}
""".strip()


def _extract_json(text: str) -> dict[str, Any]:
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", str(text or "").strip(), flags=re.I)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        start, end = raw.find("{"), raw.rfind("}")
        if start >= 0 and end > start:
            return json.loads(raw[start:end + 1])
        raise


def _validate(raw: dict[str, Any], count: int, cfg: SocialMetadataConfig) -> list[dict[str, Any]]:
    rows = raw.get("clips") if isinstance(raw, dict) else None
    if not isinstance(rows, list) or len(rows) != count:
        raise RuntimeError(f"Social metadata JSON requires exactly {count} clips")
    result: dict[int, dict[str, Any]] = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        index = int(row.get("index") or 0)
        if not 1 <= index <= count:
            continue
        title, hook = _clean(row.get("title"), 90), _clean(row.get("hook"), 140)
        fb, tt = _clean(row.get("fb_caption"), 500), _clean(row.get("tt_caption"), 300)
        tags = _hashtags(row.get("hashtags"), cfg.hashtag_limit)
        if not title or not _contains_myanmar(title) or not hook or not fb or not tt or not tags:
            raise RuntimeError(f"Social metadata clip {index} is missing required copy")
        result[index] = {"index": index, "title": title, "hook": hook, "fb_caption": fb, "tt_caption": tt, "hashtags": tags}
    if sorted(result) != list(range(1, count + 1)):
        raise RuntimeError("Social metadata indexes are incomplete/out of order")
    return [result[index] for index in range(1, count + 1)]


def _cache_path(candidates: list[dict], packages: list[dict], cfg: SocialMetadataConfig) -> Path:
    digest = hashlib.sha256(json.dumps({
        "v": PROMPT_VERSION, "model": _model_chain(cfg.model, cfg.model_fallbacks),
        "profile": [x.get("selector_profile") for x in candidates],
        "candidates": [{"start": x.get("start"), "end": x.get("end"), "text": x.get("text")} for x in candidates],
        "commentary": [x.get("english_voiceover") for x in packages],
    }, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()[:24]
    folder = ROOT / "state" / "social_metadata_cache"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / f"{digest}.json"


def _call(prompt: str, model: str, temperature: float, api_key: str, count: int, request_timeout_ms: int = 120_000) -> str:
    from google import genai
    from google.genai import types
    client = genai.Client(api_key=api_key, http_options=types.HttpOptions(timeout=max(1_000, request_timeout_ms), retry_options=types.HttpRetryOptions(attempts=1)))
    try:
        response = client.models.generate_content(
            model=model, contents=prompt,
            config=types.GenerateContentConfig(temperature=temperature, response_mime_type="application/json", response_schema=_schema(count)),
        )
    except (TypeError, AttributeError):
        response = client.models.generate_content(model=model, contents=prompt)
    return str(getattr(response, "text", "") or "")


def generate_social_metadata(candidates: list[dict], packages: list[dict], cfg: SocialMetadataConfig) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if len(candidates) != len(packages):
        raise ValueError("Social metadata requires matching candidates and commentary packages")
    if not cfg.enabled:
        raise RuntimeError("Long-to-Short social metadata is required; social_metadata.enabled cannot be false")
    cache = _cache_path(candidates, packages, cfg)
    if cfg.reuse_cache and cache.exists():
        try:
            rows = _validate(json.loads(cache.read_text(encoding="utf-8")), len(candidates), cfg)
            print(f"♻️ Social title/caption cache hit → {cache.name} (0 API calls)")
            return rows, {"schema": PROMPT_VERSION, "cached": True, "cache": str(cache)}
        except Exception:
            pass

    prompt, errors = _prompt(candidates, packages, cfg), []
    proxy_state = _proxy_if_listening()
    deadline = time.monotonic() + 360
    try:
        models = _model_chain(cfg.model, cfg.model_fallbacks)
        for model in models:
            for entry in resolve_api_keys(cfg.allow_paid_fallback):
                retry = 0
                while True:
                    remaining_ms = int((deadline - time.monotonic()) * 1000)
                    if remaining_ms <= 0:
                        raise RuntimeError('AI social metadata overall timeout after 360s; cached media kept')
                    try:
                        request_limit = 120_000 if model == models[-1] else 45_000
                        rows = _validate(_extract_json(_call(prompt, model, cfg.temperature, entry.value, len(candidates), min(request_limit, remaining_ms))), len(candidates), cfg)
                        cache.write_text(json.dumps({"clips": rows}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                        print(f"✨ AI social hooks ready → {len(rows)} clips | {model}")
                        return rows, {"schema": PROMPT_VERSION, "cached": False, "cache": str(cache), "model_used": model, "key_alias": entry.alias, "paid_key_used": entry.paid}
                    except Exception as exc:
                        if _is_key_rotatable_error(exc):
                            errors.append(f"{model}/{entry.alias}: {exc}"); break
                        if _is_model_unavailable_error(exc):
                            errors.append(f"{model}: {exc}"); retry = cfg.retries_per_key + 1; break
                        if _is_request_timeout_error(exc):
                            switch_model = model != models[-1]
                            if switch_model: retry = cfg.retries_per_key + 1
                            action = 'fallback model' if switch_model else 'rotate free key'
                            print(f'⏱️ Social metadata request timeout → {action} ({entry.alias})')
                            errors.append(f'{model}/{entry.alias}: {exc}'); break
                        if _is_transient_service_error(exc) and retry < max(0, cfg.retries_per_key):
                            delay = max(0.0, cfg.backoff_seconds) * (2 ** retry); retry += 1
                            if delay: time.sleep(delay)
                            continue
                        errors.append(f"{model}/{entry.alias}: {exc}"); break
                if retry > cfg.retries_per_key:
                    break
    finally:
        _restore_proxy(proxy_state)
    raise RuntimeError("AI social metadata failed; this video will not enter READY inventory. " + " | ".join(errors[-3:]))
