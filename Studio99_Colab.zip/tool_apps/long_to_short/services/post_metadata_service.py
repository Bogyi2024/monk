from pathlib import Path
import json, hashlib

class PostMetadataService:
    def __init__(self, cache_dir="state/metadata_cache"):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def make_key(self, payload):
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()
        ).hexdigest()

    def build(self, *, category="generic", language="my",
              output_profile="unknown", title="",
              description="", hashtags=None):
        return {
            "content_category": category,
            "metadata_language": language,
            "output_profile": output_profile,
            "title": title,
            "description": description,
            "hashtags": hashtags or []
        }