from __future__ import annotations

import hashlib
import json
import math
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from services.gemini_moment_selector import (
    resolve_api_keys,
    _proxy_if_listening,
    _restore_proxy,
    _is_key_rotatable_error,
    _is_model_unavailable_error,
    _is_transient_service_error,
    _is_request_timeout_error,
    _model_chain,
)

ROOT = Path(__file__).resolve().parents[1]
CACHE_VERSION = "mm_spoken_translation_cache_v2"


@dataclass
class OriginalMMConfig:
    enabled: bool = True
    model: str = "gemini-3.5-flash"
    model_fallbacks: tuple[str, ...] = ("gemini-3.5-flash-lite",)
    temperature: float = 0.15
    allow_paid_fallback: bool = False
    retries_per_key: int = 1
    backoff_seconds: float = 4.0
    max_words_per_event: int = 10
    max_seconds_per_event: float = 4.0


def _norm_ws(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _norm_match(text: str) -> str:
    return re.sub(r"[^a-z0-9']+", " ", _norm_ws(text).lower()).strip()


def _find_phrase_span(text: str, phrase: str) -> tuple[int, int] | None:
    """Find a short phrase in text, allowing punctuation/spacing differences."""
    pwords = _norm_match(phrase).split()
    if not pwords:
        return None
    # Use the raw words from text and a normalized parallel list so we can
    # reconstruct the original punctuation/casing around the match.
    raw_words = re.findall(r"\S+", text)
    norm_words = [_norm_match(w) for w in raw_words]
    norm_words = [w for w in norm_words]
    target = pwords
    for i in range(0, max(0, len(norm_words) - len(target) + 1)):
        if norm_words[i:i+len(target)] == target:
            return i, i + len(target)
    return None


def _trim_first_text_to_candidate(seg_text: str, candidate_text: str) -> str:
    words = _norm_ws(candidate_text).split()
    for n in (7, 6, 5, 4, 3):
        if len(words) < n:
            continue
        phrase = " ".join(words[:n])
        span = _find_phrase_span(seg_text, phrase)
        if span:
            raw_words = re.findall(r"\S+", seg_text)
            return " ".join(raw_words[span[0]:]).strip()
    return _norm_ws(seg_text)


def _trim_last_text_to_candidate(seg_text: str, candidate_text: str) -> str:
    words = _norm_ws(candidate_text).split()
    for n in (7, 6, 5, 4, 3):
        if len(words) < n:
            continue
        phrase = " ".join(words[-n:])
        span = _find_phrase_span(seg_text, phrase)
        if span:
            raw_words = re.findall(r"\S+", seg_text)
            return " ".join(raw_words[:span[1]]).strip()
    return _norm_ws(seg_text)


def _trim_by_time_fraction(text: str, seg_start: float, seg_end: float, clip_start: float, clip_end: float) -> str:
    words = _norm_ws(text).split()
    if not words:
        return ""
    dur = max(0.001, seg_end - seg_start)
    a = max(0.0, min(1.0, (clip_start - seg_start) / dur))
    b = max(a, min(1.0, (clip_end - seg_start) / dur))
    i0 = min(len(words) - 1, max(0, int(math.floor(a * len(words)))))
    i1 = min(len(words), max(i0 + 1, int(math.ceil(b * len(words)))))
    return " ".join(words[i0:i1]).strip()


def _split_text_units(text: str, max_words: int) -> list[str]:
    text = _norm_ws(text)
    if not text:
        return []
    # Keep natural clause/sentence boundaries when possible.
    rough = [p.strip() for p in re.split(r"(?<=[.!?])\s+", text) if p.strip()]
    out: list[str] = []
    for part in rough:
        words = part.split()
        while len(words) > max_words:
            out.append(" ".join(words[:max_words]))
            words = words[max_words:]
        if words:
            out.append(" ".join(words))
    return out or [text]


def _split_event(event: dict, max_words: int, max_seconds: float) -> list[dict]:
    start, end = float(event["start"]), float(event["end"])
    duration = max(0.05, end - start)
    text = _norm_ws(event.get("en") or "")
    words = text.split()
    target_parts = max(1, int(math.ceil(duration / max(0.5, max_seconds))), int(math.ceil(len(words) / max(1, max_words))))
    units = _split_text_units(text, max_words)
    if len(units) < target_parts and len(words) > 1:
        # Re-chunk evenly to hit a readable time cadence.
        per = max(1, int(math.ceil(len(words) / target_parts)))
        units = [" ".join(words[i:i+per]) for i in range(0, len(words), per)]
    weights = [max(1, len(u.split())) for u in units]
    total = sum(weights)
    out = []
    cursor = start
    for i, (unit, w) in enumerate(zip(units, weights)):
        if i == len(units) - 1:
            nxt = end
        else:
            nxt = cursor + duration * (w / total)
        out.append({"start": cursor, "end": max(cursor + 0.05, nxt), "en": unit})
        cursor = nxt
        duration = max(0.05, end - cursor)
        total -= w
    if out:
        out[-1]["end"] = end
    return out


def build_original_english_events(candidate: dict, transcript_segments: list[dict], *, max_words: int = 14, max_seconds: float = 5.5) -> list[dict]:
    cstart = float(candidate["start"])
    cend = float(candidate["end"])
    cand_text = _norm_ws(candidate.get("text") or "")
    overlaps: list[dict] = []
    for seg in transcript_segments:
        s0, s1 = float(seg.get("start", 0)), float(seg.get("end", 0))
        if s1 <= cstart or s0 >= cend:
            continue
        a, b = max(cstart, s0), min(cend, s1)
        if b - a < 0.04:
            continue
        text = _norm_ws(seg.get("text") or "")
        if a > s0 + 0.02 or b < s1 - 0.02:
            text = _trim_by_time_fraction(text, s0, s1, a, b)
        overlaps.append({"start": a - cstart, "end": b - cstart, "en": text, "_abs_start": a, "_abs_end": b})

    if not overlaps:
        return []

    # Candidate text is already boundary-refined; use it to remove partial
    # spoken fragments from first/last Whisper segments when possible.
    overlaps[0]["en"] = _trim_first_text_to_candidate(overlaps[0]["en"], cand_text)
    overlaps[-1]["en"] = _trim_last_text_to_candidate(overlaps[-1]["en"], cand_text)

    refined: list[dict] = []
    for ev in overlaps:
        if not _norm_ws(ev["en"]):
            continue
        refined.extend(_split_event(ev, max_words=max_words, max_seconds=max_seconds))

    # Normalize to zero and exact candidate duration bounds.
    clip_dur = max(0.05, cend - cstart)
    for ev in refined:
        ev["start"] = max(0.0, min(clip_dur, float(ev["start"])))
        ev["end"] = max(ev["start"] + 0.05, min(clip_dur, float(ev["end"])))
        ev.pop("_abs_start", None)
        ev.pop("_abs_end", None)
    if refined:
        refined[0]["start"] = 0.0
        refined[-1]["end"] = clip_dur
    return refined


def _has_forbidden_script(text: str) -> bool:
    """Reject accidental Arabic/Georgian/etc. contamination in Myanmar lines.

    ASCII words are allowed for proper names/brands. Myanmar Unicode blocks,
    punctuation, digits, spaces, and ASCII are allowed.
    """
    for ch in str(text or ""):
        cp = ord(ch)
        if ch.isspace() or ch.isdigit() or ch.isascii():
            continue
        if 0x1000 <= cp <= 0x109F or 0xAA60 <= cp <= 0xAA7F or 0xA9E0 <= cp <= 0xA9FF:
            continue
        if ch in "၊။“”‘’…–—•":
            continue
        return True
    return False


def _looks_too_formal(text: str) -> bool:
    """Catch the essay/literary Burmese style the user explicitly rejected."""
    t = str(text or "")
    formal_markers = (
        "ဖြစ်သည်", "ဖြစ်ပါသည်", "ရှိပါသည်", "ပြုလုပ်သည်", "ဆောင်ရွက်သည်",
        "မည်သည်", "မည်သည့်", "၎င်း", "ရရှိသည်", "လိုအပ်သည်", "ဖြစ်လာသည်",
    )
    return any(x in t for x in formal_markers)


def _cache_path() -> Path:
    p = ROOT / "state" / "mm_spoken_translation_cache_v2.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _load_cache() -> dict[str, str]:
    p = _cache_path()
    if not p.exists():
        return {}
    try:
        obj = json.loads(p.read_text(encoding="utf-8"))
        return dict(obj.get("items") or {}) if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _save_cache(items: dict[str, str]) -> None:
    _cache_path().write_text(json.dumps({"version": CACHE_VERSION, "items": items}, ensure_ascii=False, indent=2), encoding="utf-8")


def _text_key(en: str) -> str:
    return hashlib.sha256(_norm_ws(en).encode("utf-8")).hexdigest()[:24]


def _schema(count: int) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "translations": {
                "type": "array",
                "minItems": count,
                "maxItems": count,
                "items": {
                    "type": "object",
                    "properties": {"i": {"type": "integer"}, "mm": {"type": "string"}},
                    "required": ["i", "mm"],
                },
            }
        },
        "required": ["translations"],
    }


def _prompt(texts: list[str], *, repair: bool = False) -> str:
    rows = [{"i": i, "en": _norm_ws(t)} for i, t in enumerate(texts)]
    extra = "These lines need repair. Remove any foreign-script contamination AND rewrite any stiff literary Burmese into natural spoken Burmese. Do not preserve formal essay wording." if repair else ""
    return f"""
Translate each English line into NATURAL SPOKEN Myanmar (Burmese) for fast mobile subtitles.
The viewer should feel like a Burmese person is naturally saying the same thought, NOT reading an essay or article.

STRICT SUBTITLE STYLE
- Preserve the exact meaning. Do not add facts or explanations.
- Keep each line short, direct, conversational, and easy to read while listening.
- Prefer everyday spoken endings such as တယ် / မယ် / နိုင်တယ် / ပဲ when natural.
- Avoid stiff literary/formal endings and constructions such as သည်, ဖြစ်သည်, ပြုလုပ်သည်, ရှိပါသည်, မည်သည်, ၎င်း unless genuinely unavoidable.
- Do not turn a short spoken phrase into a long paragraph.
- Keep names understandable. Use Myanmar script for Burmese words.
- No romanization.
- Do NOT output Arabic, Georgian, Thai, Chinese, Japanese, Korean, Devanagari, or other unrelated scripts.
{extra}
Return JSON only with exactly one translation for every input index.
INPUT:
{json.dumps(rows, ensure_ascii=False)}
""".strip()


def _extract_json(text: str) -> dict:
    raw = _norm_ws(text)
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
    raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except Exception:
        a, b = raw.find("{"), raw.rfind("}")
        if a >= 0 and b > a:
            return json.loads(raw[a:b+1])
        raise


def _call_translation(texts: list[str], model: str, temperature: float, api_key: str, *, repair: bool = False, request_timeout_ms: int = 120_000) -> list[str]:
    from google import genai
    from google.genai import types
    client = genai.Client(api_key=api_key, http_options=types.HttpOptions(timeout=max(1_000, request_timeout_ms), retry_options=types.HttpRetryOptions(attempts=1)))
    prompt = _prompt(texts, repair=repair)
    response = client.models.generate_content(
        model=model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=temperature,
            response_mime_type="application/json",
            response_schema=_schema(len(texts)),
        ),
    )
    raw = _extract_json(str(getattr(response, "text", "") or ""))
    rows = raw.get("translations") if isinstance(raw, dict) else None
    if not isinstance(rows, list) or len(rows) != len(texts):
        raise RuntimeError(f"Myanmar translation JSON count mismatch: expected {len(texts)}")
    by_i: dict[int, str] = {}
    for row in rows:
        i = int(row.get("i"))
        mm = _norm_ws(row.get("mm") or "")
        if not mm:
            raise RuntimeError(f"Myanmar translation {i} is empty")
        by_i[i] = mm
    if sorted(by_i) != list(range(len(texts))):
        raise RuntimeError("Myanmar translation indexes are incomplete")
    return [by_i[i] for i in range(len(texts))]


def translate_texts_cached(texts: list[str], cfg: OriginalMMConfig, *, force_refresh_indexes: set[int] | None = None) -> tuple[list[str], dict]:
    texts = [_norm_ws(t) for t in texts]
    cache = _load_cache()
    force_refresh_indexes = force_refresh_indexes or set()
    results: list[str | None] = [None] * len(texts)
    missing_indexes: list[int] = []
    for i, t in enumerate(texts):
        key = _text_key(t)
        cached = cache.get(key)
        if i not in force_refresh_indexes and cached and not _has_forbidden_script(cached) and not _looks_too_formal(cached):
            results[i] = cached
        else:
            missing_indexes.append(i)

    if not missing_indexes:
        return [str(x) for x in results], {"cached": True, "api_calls": 0}

    missing_texts = [texts[i] for i in missing_indexes]
    pool = resolve_api_keys(cfg.allow_paid_fallback)
    print("🌐 Original/MM translation key pool: " + " → ".join(f"{e.alias}[{e.fingerprint}]" for e in pool))
    if not cfg.allow_paid_fallback:
        print("🛡️ Original/MM paid fallback: DISABLED")

    errors: list[str] = []
    proxy_state = _proxy_if_listening()
    deadline = time.monotonic() + 360
    try:
        translated: list[str] | None = None
        used_meta: dict = {}
        models = _model_chain(cfg.model, cfg.model_fallbacks)
        for model in models:
            print(f'🧠 Myanmar translation model → {model}')
            switch_model = False
            for entry in pool:
                transient_try = 0
                while True:
                    remaining_ms = int((deadline - time.monotonic()) * 1000)
                    if remaining_ms <= 0:
                        raise RuntimeError('Myanmar translation overall timeout after 360s; cached media kept')
                    try:
                        request_limit = 120_000 if model == models[-1] else 45_000
                        translated = _call_translation(missing_texts, model, cfg.temperature, entry.value, request_timeout_ms=min(request_limit, remaining_ms))
                        # Targeted repair pass for either foreign-script contamination OR
                        # the old stiff essay style (e.g. ဖြစ်သည် / ပါသည်).
                        bad = [
                            j for j, mm in enumerate(translated)
                            if _has_forbidden_script(mm) or _looks_too_formal(mm)
                        ]
                        if bad:
                            repaired = _call_translation([missing_texts[j] for j in bad], model, cfg.temperature, entry.value, repair=True, request_timeout_ms=min(request_limit, max(1_000, int((deadline-time.monotonic())*1000))))
                            for pos, mm in zip(bad, repaired):
                                translated[pos] = mm
                        bad2 = [j for j, mm in enumerate(translated) if _has_forbidden_script(mm)]
                        formal2 = [j for j, mm in enumerate(translated) if _looks_too_formal(mm)]
                        if bad2:
                            raise RuntimeError(f"Myanmar translation still contains foreign-script contamination at {bad2[:8]}")
                        if formal2:
                            raise RuntimeError(f"Myanmar translation still looks too formal/essay-like at {formal2[:8]}")
                        used_meta = {
                            "cached": False,
                            "api_calls": 1 + (1 if bad else 0),
                            "model_used": model,
                            "key_alias": entry.alias,
                            "key_source": entry.source,
                            "key_fingerprint": entry.fingerprint,
                            "paid_key_used": entry.paid,
                        }
                        break
                    except Exception as exc:
                        if _is_model_unavailable_error(exc):
                            errors.append(f"{model}: {exc}")
                            switch_model = True
                            break
                        if _is_key_rotatable_error(exc):
                            errors.append(f"{model}/{entry.alias}: {exc}")
                            break
                        if _is_request_timeout_error(exc):
                            switch_model = model != models[-1]
                            action = 'fallback model' if switch_model else 'rotate free key'
                            print(f'⏱️ Myanmar translation request timeout → {action} ({entry.alias})')
                            errors.append(f'{model}/{entry.alias}: {exc}')
                            break
                        if _is_transient_service_error(exc):
                            if transient_try < max(0, int(cfg.retries_per_key)):
                                delay = max(0.0, float(cfg.backoff_seconds)) * (2 ** transient_try)
                                transient_try += 1
                                print(f"   ⏳ MM translation temporary error → retry {transient_try}/{cfg.retries_per_key} in {delay:.0f}s")
                                if delay:
                                    time.sleep(delay)
                                continue
                            errors.append(f"{model}/{entry.alias}: {exc}")
                            switch_model = True
                            break
                        # Validation/format failures get one model fallback instead of burning keys.
                        errors.append(f"{model}/{entry.alias}: {exc}")
                        switch_model = True
                        break
                if translated is not None:
                    break
                if switch_model:
                    break
            if translated is not None:
                for local_i, mm in enumerate(translated):
                    global_i = missing_indexes[local_i]
                    results[global_i] = mm
                    cache[_text_key(texts[global_i])] = mm
                _save_cache(cache)
                return [str(x) for x in results], used_meta
        raise RuntimeError("Myanmar translation failed across model/key fallbacks. " + " | ".join(errors[-6:]))
    finally:
        _restore_proxy(proxy_state)


def attach_myanmar(events: list[dict], cfg: OriginalMMConfig) -> tuple[list[dict], dict]:
    texts = [e["en"] for e in events]
    mm, meta = translate_texts_cached(texts, cfg)
    return [{"start": e["start"], "end": e["end"], "text": m, "en": e["en"]} for e, m in zip(events, mm)], meta


def repair_commentary_foreign_scripts(packages: list[dict], cfg: OriginalMMConfig) -> tuple[list[dict], dict]:
    refs: list[tuple[int, int, str]] = []
    for pi, pkg in enumerate(packages):
        for si, seg in enumerate(pkg.get("segments") or []):
            if _has_forbidden_script(str(seg.get("mm") or "")):
                refs.append((pi, si, str(seg.get("en") or "")))
    if not refs:
        return packages, {"repaired_lines": 0, "api_calls": 0}
    print(f"🧹 Myanmar QA: repairing {len(refs)} commentary line(s) with foreign-script contamination")
    repaired, meta = translate_texts_cached([r[2] for r in refs], cfg, force_refresh_indexes=set(range(len(refs))))
    for (pi, si, _), mm in zip(refs, repaired):
        packages[pi]["segments"][si]["mm"] = mm
    return packages, {"repaired_lines": len(refs), **meta}
