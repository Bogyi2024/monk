from __future__ import annotations

import base64
import html
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path


def find_myanmar_font() -> Path | None:
    env_font = os.getenv("SUBTITLE_FONT_PATH")
    if env_font and Path(env_font).is_file():
        return Path(env_font).resolve()

    # V0.3.4 preferred font requested by user: Burma-020 Thin.
    # Check the per-user Windows font folder BEFORE project fallbacks so an
    # installed BURMA020-THIN.TTF actually wins over Pyidaungsu/Noto.
    user_font_dirs = []
    if os.getenv("LOCALAPPDATA"):
        user_font_dirs.append(Path(os.environ["LOCALAPPDATA"]) / "Microsoft/Windows/Fonts")
    if os.getenv("USERPROFILE"):
        user_font_dirs.append(Path(os.environ["USERPROFILE"]) / "AppData/Local/Microsoft/Windows/Fonts")
    exact_names = {"burma020-thin.ttf", "burma020thin.ttf"}
    for d in user_font_dirs:
        if not d.is_dir():
            continue
        try:
            for fp in d.iterdir():
                if fp.name.lower() in exact_names and fp.is_file():
                    return fp.resolve()
        except OSError:
            pass

    root = Path(__file__).resolve().parents[1]
    project_candidates = [
        root / "assets/fonts/Pyidaungsu-Regular.ttf",
        root / "assets/fonts/Pyidaungsu.ttf",
        root / "assets/fonts/NotoSansMyanmar-Regular.ttf",
        root.parent / "recap_personal/assets/fonts/Pyidaungsu-Regular.ttf",
        root.parent / "recap_personal/assets/fonts/Pyidaungsu.ttf",
        root.parent / "recap_personal/assets/fonts/NotoSansMyanmar-Regular.ttf",
    ]
    for p in project_candidates:
        if p.is_file():
            return p.resolve()

    dirs = []
    if os.getenv("LOCALAPPDATA"):
        dirs.append(Path(os.environ["LOCALAPPDATA"]) / "Microsoft/Windows/Fonts")
    if os.getenv("USERPROFILE"):
        dirs.append(Path(os.environ["USERPROFILE"]) / "AppData/Local/Microsoft/Windows/Fonts")
    dirs += [Path(r"C:\Windows\Fonts"), Path("/usr/share/fonts/truetype/noto")]
    preferred = [
        "burma020-thin", "burma020thin",
        "pyidaungsu-regular", "pyidaungsu",
        "notosansmyanmar-regular", "notosansmyanmar-bold", "notosansmyanmar",
        "myanmartext", "burma",
    ]
    found: list[tuple[int, Path]] = []
    for d in dirs:
        if not d.is_dir():
            continue
        try:
            for p in d.iterdir():
                if p.suffix.lower() not in {".ttf", ".otf", ".ttc"}:
                    continue
                compact = re.sub(r"[-_ ]", "", p.name.lower())
                for pri, kw in enumerate(preferred):
                    if re.sub(r"[-_ ]", "", kw) in compact:
                        found.append((pri, p))
                        break
        except OSError:
            pass
    if found:
        found.sort(key=lambda x: x[0])
        return found[0][1].resolve()
    return None


def find_english_font() -> Path | None:
    env_font = os.getenv("SUBTITLE_EN_FONT_PATH")
    if env_font and Path(env_font).is_file():
        return Path(env_font).resolve()
    for path in (
        Path(r"C:\Windows\Fonts\segoeui.ttf"),
        Path(r"C:\Windows\Fonts\arial.ttf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    ):
        if path.is_file():
            return path.resolve()
    return None


def build_mm_timing(segments: list[dict], duration: float) -> list[dict]:
    """Allocate TTS time to bilingual script segments by English speech weight.

    TTS is generated in one continuous call to keep one narrator identity. Exact
    forced alignment can be added later; this proportional map is deterministic
    and keeps each Burmese caption attached to the sentence it translates.
    """
    if not segments:
        return []
    weights = [max(1, len(str(s.get("en") or "").split())) for s in segments]
    total = float(sum(weights))
    cursor = 0.0
    events = []
    for i, (seg, w) in enumerate(zip(segments, weights)):
        end = duration if i == len(segments) - 1 else cursor + duration * (w / total)
        events.append({"start": cursor, "end": end, "text": str(seg.get("mm") or "").strip()})
        cursor = end
    return events


def _render_one_png(text: str, out_path: Path, width: int, height: int, font_path: Path | None, font_size: int, min_font_size: int) -> None:
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:
        raise RuntimeError("playwright is required for Unicode-safe Myanmar PNG subtitles. Run: pip install playwright") from exc

    font_face = ""
    if font_path and font_path.is_file():
        b64 = base64.b64encode(font_path.read_bytes()).decode("ascii")
        font_face = f"@font-face{{font-family:'MyanmarCaption';src:url(data:font/ttf;base64,{b64}) format('truetype');}}"
    safe = html.escape(" ".join(str(text or "").split()))
    doc = f"""<!doctype html><html><head><meta charset='UTF-8'><style>
{font_face}
html,body{{margin:0;width:{width}px;height:{height}px;background:transparent;overflow:hidden;}}
body{{display:flex;align-items:center;justify-content:center;}}
.wrap{{box-sizing:border-box;width:calc(100% - 18px);height:calc(100% - 4px);padding:12px 20px;border-radius:20px;background:rgba(0,0,0,.10);display:flex;align-items:center;justify-content:center;overflow:hidden;}}
.txt{{font-family:'MyanmarCaption','Pyidaungsu','Myanmar Text','Noto Sans Myanmar',sans-serif;font-size:{font_size}px;line-height:1.28;font-weight:400;color:#fff;text-align:center;white-space:normal;word-break:normal;overflow-wrap:break-word;text-shadow:-2px -2px 0 #0d0d0d,2px -2px 0 #0d0d0d,-2px 2px 0 #0d0d0d,2px 2px 0 #0d0d0d,0 4px 10px rgba(0,0,0,.72);}}
</style></head><body><div class='wrap' id='wrap'><div class='txt' id='txt'>{safe}</div></div><script>
(()=>{{const e=document.getElementById('txt'),w=document.getElementById('wrap');let s={font_size};const m={min_font_size};function f(){{const lh=parseFloat(getComputedStyle(e).lineHeight)||s*1.34;const lines=Math.ceil(e.scrollHeight/lh);return e.scrollHeight<=w.clientHeight-4&&lines<=3;}}while(s>m&&!f()){{s--;e.style.fontSize=s+'px';}}}})();
</script></body></html>"""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with sync_playwright() as p:
            try:
                browser = p.chromium.launch(headless=True)
            except Exception:
                # Reuse an already-installed system Chrome/Edge/Chromium before
                # asking for a separate Playwright browser download.
                candidates = [
                    shutil.which("chromium"), shutil.which("chromium-browser"),
                    shutil.which("google-chrome"), shutil.which("chrome"),
                    shutil.which("msedge"),
                    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
                ]
                executable = next((x for x in candidates if x and Path(x).is_file()), None)
                if not executable:
                    raise
                browser = p.chromium.launch(headless=True, executable_path=str(executable))
            page = browser.new_page(viewport={"width": width, "height": height})
            page.set_content(doc, wait_until="load")
            page.wait_for_timeout(150)
            page.screenshot(path=str(out_path), omit_background=True)
            browser.close()
        return
    except Exception:
        # Unicode-safe image fallback: Pillow with RAQM/HarfBuzz shaping.
        # We still render Myanmar into a transparent PNG first; FFmpeg never
        # draws Burmese text directly.
        try:
            from PIL import Image, ImageDraw, ImageFont, features
            if not font_path or not font_path.is_file():
                raise RuntimeError("No Myanmar font file available for PNG fallback")
            if not features.check("raqm"):
                raise RuntimeError("Pillow was built without RAQM complex-text shaping")
            img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)
            size = int(font_size)
            lines = []
            while size >= int(min_font_size):
                font = ImageFont.truetype(str(font_path), size=size, layout_engine=ImageFont.Layout.RAQM)
                words = safe.replace("&amp;", "&").split()
                trial_lines = []
                cur = ""
                for word in words:
                    proposal = (cur + " " + word).strip()
                    box = draw.textbbox((0,0), proposal, font=font, stroke_width=2)
                    tw = box[2]-box[0]
                    if cur and tw > width - 60:
                        trial_lines.append(cur)
                        cur = word
                    else:
                        cur = proposal
                if cur:
                    trial_lines.append(cur)
                line_h = int(size * 1.30)
                if len(trial_lines) <= 3 and len(trial_lines) * line_h <= height - 24:
                    lines = trial_lines
                    break
                size -= 1
            if not lines:
                lines = [safe.replace("&amp;", "&")]
                font = ImageFont.truetype(str(font_path), size=int(min_font_size), layout_engine=ImageFont.Layout.RAQM)
                line_h = int(min_font_size * 1.30)
            else:
                font = ImageFont.truetype(str(font_path), size=size, layout_engine=ImageFont.Layout.RAQM)
                line_h = int(size * 1.30)
            total_h = len(lines) * line_h
            y = max(0, (height-total_h)//2)
            # subtle translucent plate
            plate_top = max(0, y-8); plate_bottom = min(height, y+total_h+8)
            draw.rounded_rectangle((6, plate_top, width-6, plate_bottom), radius=20, fill=(0,0,0,26))
            for line in lines:
                box = draw.textbbox((0,0), line, font=font, stroke_width=2)
                tw = box[2]-box[0]
                x = max(10, (width-tw)//2)
                draw.text((x,y), line, font=font, fill=(255,255,255,255), stroke_width=2, stroke_fill=(13,13,13,255), direction="ltr")
                y += line_h
            img.save(out_path)
            return
        except Exception as exc:
            raise RuntimeError(
                "Myanmar PNG subtitle renderer unavailable. Install Playwright Chromium or Pillow with RAQM, and set SUBTITLE_FONT_PATH if needed."
            ) from exc


def render_mm_png_events(events: list[dict], work_dir: str | Path, *, width: int = 1040, height: int = 250, font_size: int = 54, min_font_size: int = 38) -> list[dict]:
    return render_subtitle_png_events(
        events, work_dir, language="mm", width=width, height=height,
        font_size=font_size, min_font_size=min_font_size,
    )


def render_subtitle_png_events(
    events: list[dict],
    work_dir: str | Path,
    *,
    language: str = "mm",
    width: int = 1040,
    height: int = 250,
    font_size: int = 54,
    min_font_size: int = 38,
) -> list[dict]:
    """Render Unicode subtitle events to PNGs for either MM or EN routes."""
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    lang = "en" if str(language).lower().startswith("en") else "mm"
    font_path = find_myanmar_font() if lang == "mm" else find_english_font()
    label = "Myanmar" if lang == "mm" else "English"
    print(f"🔤 {label} subtitle font → {font_path or 'Chromium system fallback'}")
    rendered = []
    for i, e in enumerate(events):
        p = work / f"{lang}_sub_{i:03d}.png"
        text = str(e.get("text") or e.get("en") or e.get("mm") or "").strip()
        if not text:
            continue
        _render_one_png(text, p, width, height, font_path, font_size, min_font_size)
        rendered.append({**e, "text": text, "png": str(p.resolve()), "width": width, "height": height})
    return rendered


def _escape_filter_path(path: str | Path) -> str:
    p = str(Path(path).resolve()).replace("\\", "/")
    return p.replace(":", r"\:").replace("'", r"\'")


def _framing_filter_parts(
    *,
    input_label: str,
    target_width: int,
    target_height: int,
    fps: int,
    mode: str,
    center_x: float,
    out_label: str,
) -> list[str]:
    mode = str(mode or "center_crop").lower()
    if mode == "original":
        return [f"{input_label}scale={target_width}:{target_height},"
                f"fps={fps},setpts=PTS-STARTPTS{out_label}"]
    if mode in {"smart_crop", "center_crop", "full_crop"}:
        cx = 0.5 if mode in {"center_crop", "full_crop"} else min(0.78, max(0.22, float(center_x)))
        return [
            f"{input_label}scale=-2:{target_height},"
            f"crop={target_width}:{target_height}:x='max(0,min(iw-{target_width},iw*{cx:.5f}-{target_width/2:.1f}))':y=0,"
            f"fps={fps},setpts=PTS-STARTPTS{out_label}"
        ]

    # Temporary fallback ONLY for no-face sections. Keep the full 16:9 image
    # visible over an enlarged blurred duplicate instead of applying it to the
    # entire short.
    return [
        f"{input_label}split=2[bgsrc][fgsrc]",
        f"[bgsrc]scale={target_width}:{target_height}:force_original_aspect_ratio=increase,"
        f"crop={target_width}:{target_height},boxblur=18:2[bg]",
        f"[fgsrc]scale={target_width}:-2[fg]",
        f"[bg][fg]overlay=x=(W-w)/2:y=(H-h)/2:shortest=1,"
        f"fps={fps},setpts=PTS-STARTPTS{out_label}",
    ]


def _run_video_encode(base: list[str], out: str | Path, *, intermediate: bool = False) -> None:
    """NVENC first, CPU fallback, with conservative filter/thread settings."""
    out = str(out)
    common = ["-filter_complex_threads", "1", "-threads", "4"]
    cq = "17" if intermediate else "21"
    crf = "17" if intermediate else "21"
    nv = base + common + [
        "-c:v", "h264_nvenc", "-preset", "p4", "-cq", cq,
        "-pix_fmt", "yuv420p", out,
    ]
    r = subprocess.run(nv, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        cpu = base + common + [
            "-c:v", "libx264", "-preset", "veryfast", "-crf", crf,
            "-pix_fmt", "yuv420p", out,
        ]
        r = subprocess.run(cpu, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-5000:])


def _render_visual_segment(
    src: str | Path,
    out: str | Path,
    *,
    absolute_start: float,
    duration: float,
    mode: str,
    center_x: float,
    target_width: int,
    target_height: int,
    fps: int,
) -> None:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg not found in PATH")
    cmd = [
        ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
        "-ss", f"{absolute_start:.3f}", "-t", f"{duration:.3f}", "-i", str(src),
    ]
    filters = _framing_filter_parts(
        input_label="[0:v]", target_width=target_width, target_height=target_height,
        fps=fps, mode=mode, center_x=center_x, out_label="[vout]",
    )
    base = cmd + [
        "-filter_complex", ";".join(filters), "-map", "[vout]", "-an",
        "-t", f"{duration:.3f}", "-movflags", "+faststart",
    ]
    _run_video_encode(base, out, intermediate=True)


def prepare_framed_base_video(
    src: str | Path,
    out: str | Path,
    *,
    source_start: float,
    source_end: float,
    framing: dict | None,
    target_width: int = 1080,
    target_height: int = 1920,
    fps: int = 30,
) -> None:
    """Create one portrait visual base that both final modes can reuse.

    Segment-aware framing is rendered sequentially, so a no-face interval can
    use fit_blur while face-visible intervals stay full-screen. This also keeps
    FFmpeg memory bounded instead of building a huge all-at-once filter graph.
    """
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg not found in PATH")
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    source_duration = max(0.1, float(source_end) - float(source_start))
    framing = dict(framing or {})
    segments = list(framing.get("segments") or [])
    if not segments:
        segments = [{
            "start": 0.0, "end": source_duration,
            "mode": str(framing.get("mode") or "center_crop"),
            "center_x": float(framing.get("center_x", 0.5)),
        }]

    # Sanitize/cover the full clip. Tiny bad segments are ignored.
    clean = []
    cursor = 0.0
    for raw in sorted(segments, key=lambda s: float(s.get("start", 0.0))):
        st = max(cursor, min(source_duration, float(raw.get("start", cursor))))
        en = max(st, min(source_duration, float(raw.get("end", source_duration))))
        if en - st < 0.04:
            continue
        clean.append({
            "start": st, "end": en,
            "mode": str(raw.get("mode") or "center_crop"),
            "center_x": float(raw.get("center_x", 0.5)),
        })
        cursor = en
    if not clean:
        clean = [{"start": 0.0, "end": source_duration, "mode": "center_crop", "center_x": 0.5}]
    clean[0]["start"] = 0.0
    clean[-1]["end"] = source_duration

    with tempfile.TemporaryDirectory(prefix="lts_frame_") as td:
        td = Path(td)
        part_files: list[Path] = []
        for i, seg in enumerate(clean):
            part = td / f"part_{i:03d}.mp4"
            _render_visual_segment(
                src, part,
                absolute_start=float(source_start) + float(seg["start"]),
                duration=float(seg["end"]) - float(seg["start"]),
                mode=seg["mode"], center_x=float(seg.get("center_x", 0.5)),
                target_width=target_width, target_height=target_height, fps=fps,
            )
            part_files.append(part)

        if len(part_files) == 1:
            shutil.copy2(part_files[0], out)
            return

        concat_file = td / "concat.txt"
        concat_file.write_text(
            "".join(f"file '{p.name}'\n" for p in part_files), encoding="utf-8"
        )
        copy_cmd = [
            ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
            "-f", "concat", "-safe", "0", "-i", str(concat_file),
            "-c", "copy", "-movflags", "+faststart", str(out),
        ]
        r = subprocess.run(copy_cmd, cwd=str(td), capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode == 0:
            return

        # Rare timestamp/extradata mismatch fallback: one controlled re-encode.
        base = [
            ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
            "-f", "concat", "-safe", "0", "-i", str(concat_file),
            "-an", "-movflags", "+faststart",
        ]
        _run_video_encode(base, out, intermediate=True)


def _create_blank_rgba_png(ffmpeg: str, out: Path, width: int, height: int) -> None:
    cmd = [
        ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
        "-f", "lavfi", "-i", f"color=c=black@0.0:s={width}x{height},format=rgba",
        "-frames:v", "1", str(out),
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-3000:])


def _build_subtitle_track(
    events: list[dict],
    duration: float,
    fps: int,
    work: Path,
) -> Path | None:
    """Turn many PNG caption inputs into ONE alpha video stream.

    This replaces the old 30-50 simultaneous looping PNG inputs that caused
    large FFmpeg commit/pagefile spikes and `Cannot allocate memory` failures.
    """
    if not events:
        return None
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg not found in PATH")
    duration = max(0.1, float(duration))
    width = int(events[0].get("width", 1040))
    height = int(events[0].get("height", 220))
    blank = work / "blank.png"
    _create_blank_rgba_png(ffmpeg, blank, width, height)

    timeline: list[tuple[Path, float]] = []
    cursor = 0.0
    for i, ev in enumerate(sorted(events, key=lambda x: float(x.get("start", 0.0)))):
        st = max(0.0, min(duration, float(ev.get("start", 0.0))))
        en = max(st, min(duration, float(ev.get("end", st))))
        if st > cursor + 0.001:
            timeline.append((blank, st - cursor))
            cursor = st
        if en <= cursor + 0.01:
            continue
        copied = work / f"sub_{i:03d}.png"
        shutil.copy2(str(ev["png"]), copied)
        timeline.append((copied, en - cursor))
        cursor = en
    if cursor < duration - 0.001:
        timeline.append((blank, duration - cursor))
    if not timeline:
        timeline = [(blank, duration)]

    concat_file = work / "subtitles.ffconcat"
    lines = ["ffconcat version 1.0\n"]
    for path, dur in timeline:
        lines.append(f"file '{path.name}'\n")
        lines.append(f"duration {max(0.01, dur):.6f}\n")
    lines.append(f"file '{timeline[-1][0].name}'\n")
    concat_file.write_text("".join(lines), encoding="utf-8")

    track = work / "subtitle_track.mov"
    cmd = [
        ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
        "-f", "concat", "-safe", "0", "-i", str(concat_file),
        "-vf", f"fps={fps},format=argb", "-t", f"{duration:.3f}",
        "-an", "-c:v", "qtrle", str(track),
    ]
    r = subprocess.run(cmd, cwd=str(work), capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-5000:])
    return track


def render_commentary_video(
    framed_video: str | Path,
    out: str | Path,
    *,
    voice_wav: str | Path,
    subtitle_png_events: list[dict],
    source_duration: float,
    target_width: int = 1080,
    target_height: int = 1920,
    fps: int = 30,
    subtitle_y_fraction: float = 0.78,
    voice_end_seconds: float | None = None,
) -> None:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg not found in PATH")
    import wave
    with wave.open(str(voice_wav), "rb") as wf:
        voice_duration = wf.getnframes() / float(wf.getframerate() or 1)
    source_duration = max(0.1, float(source_duration))
    render_duration = min(voice_duration, max(0.1, float(voice_end_seconds))) if voice_end_seconds is not None else voice_duration
    pad = max(0.0, render_duration - source_duration)

    with tempfile.TemporaryDirectory(prefix="lts_sub_") as td:
        work = Path(td)
        track = _build_subtitle_track(subtitle_png_events, render_duration, fps, work)
        cmd = [
            ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
            "-i", str(framed_video), "-i", str(voice_wav),
        ]
        if track:
            cmd += ["-i", str(track)]

        filters = [f"[0:v]fps={fps},setpts=PTS-STARTPTS[basev]"]
        vf0 = "[basev]"
        if pad > 0.01:
            vf0 += f"tpad=stop_mode=clone:stop_duration={pad:.3f},"
        vf0 += f"trim=duration={render_duration:.3f}[v0]"
        filters.append(vf0)
        current = "[v0]"
        if track:
            plate_height = int(subtitle_png_events[0].get("height", 250))
            sub_y = max(0, min(int(target_height * subtitle_y_fraction - plate_height / 2),
                               max(0, target_height - plate_height)))
            filters.append(
                f"[v0][2:v]overlay=x=(W-w)/2:y={sub_y}:shortest=0:eof_action=pass[vsub]"
            )
            current = "[vsub]"
        filters.append(
            f"[1:a]aresample=48000:async=1:first_pts=0,loudnorm=I=-16:TP=-1.5:LRA=11,"
            f"atrim=duration={render_duration:.3f},asetpts=PTS-STARTPTS[aout]"
        )
        base = cmd + [
            "-filter_complex", ";".join(filters), "-map", current, "-map", "[aout]",
            "-t", f"{render_duration:.3f}", "-movflags", "+faststart",
            "-c:a", "aac", "-b:a", "160k",
        ]
        _run_video_encode(base, out, intermediate=False)


def render_original_audio_video(
    framed_video: str | Path,
    src: str | Path,
    out: str | Path,
    *,
    source_start: float,
    source_end: float,
    subtitle_png_events: list[dict],
    target_width: int = 1080,
    target_height: int = 1920,
    fps: int = 30,
    subtitle_y_fraction: float = 0.79,
) -> None:
    """Render original interview audio + pre-rendered Unicode PNG subtitles."""
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg not found in PATH")
    source_duration = max(0.1, float(source_end) - float(source_start))

    with tempfile.TemporaryDirectory(prefix="lts_sub_") as td:
        work = Path(td)
        track = _build_subtitle_track(subtitle_png_events, source_duration, fps, work)
        cmd = [
            ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
            "-i", str(framed_video),
            "-ss", f"{source_start:.3f}", "-t", f"{source_duration:.3f}", "-i", str(src),
        ]
        if track:
            cmd += ["-i", str(track)]

        filters = [f"[0:v]fps={fps},setpts=PTS-STARTPTS[v0]"]
        current = "[v0]"
        if track:
            plate_height = int(subtitle_png_events[0].get("height", 250))
            sub_y = max(0, min(int(target_height * subtitle_y_fraction - plate_height / 2),
                               max(0, target_height - plate_height)))
            filters.append(
                f"[v0][2:v]overlay=x=(W-w)/2:y={sub_y}:shortest=0:eof_action=pass[vsub]"
            )
            current = "[vsub]"
        base = cmd + [
            "-filter_complex", ";".join(filters), "-map", current, "-map", "1:a:0?",
            "-t", f"{source_duration:.3f}", "-movflags", "+faststart",
            "-c:a", "aac", "-b:a", "160k",
        ]
        _run_video_encode(base, out, intermediate=False)
