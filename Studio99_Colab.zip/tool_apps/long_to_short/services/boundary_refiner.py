from __future__ import annotations

import re
from typing import Iterable

_TERMINAL_RE = re.compile(r"[.!?][\"')\]]*\s*$")
_SENTENCE_END_RE = re.compile(r"[.!?][\"')\]]*(?=\s|$)")
_CONTINUATION_START_RE = re.compile(
    r"^(?:because|about|of|to|from|with|which|that|who|whose|where|when|while|"
    r"as|than|then|though|although|unless|until|if|but|or|so|and|also|just|"
    r"do|did|does|gotten|getting|having|being|life|first marriage)\b",
    re.I,
)


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _ends_terminal(text: str) -> bool:
    return bool(_TERMINAL_RE.search(_norm(text)))


def _starts_like_fragment(text: str) -> bool:
    t = _norm(text)
    if not t:
        return True
    first_alpha = next((c for c in t if c.isalpha()), "")
    if first_alpha and first_alpha.islower():
        return True
    return bool(_CONTINUATION_START_RE.match(t))


def _ratio_time(seg: dict, char_pos: int, *, before: bool = False) -> float:
    """Approximate a punctuation boundary inside a Whisper segment.

    Use word-count ratio rather than character ratio so this calculation stays
    aligned with the cached-transcript subtitle fallback. Fresh transcripts
    with true word timestamps are handled more exactly by subtitle_service.
    """
    text = _norm(seg.get("text", ""))
    start = float(seg["start"])
    end = float(seg["end"])
    if not text or end <= start:
        return start if before else end
    all_words = re.findall(r"\S+", text)
    before_words = re.findall(r"\S+", text[:char_pos])
    if not all_words:
        return start if before else end
    ratio = max(0.0, min(1.0, len(before_words) / len(all_words)))
    t = start + (end - start) * ratio
    # Start a hair after a dropped fragment; end a hair before a dangling one.
    guard = 0.015
    return min(end, t + guard) if before else max(start, t - guard)


def _trim_leading_fragment(seg: dict) -> tuple[float | None, str | None]:
    """If the segment begins with a short orphan sentence, start after it."""
    text = _norm(seg.get("text", ""))
    if not _starts_like_fragment(text):
        return None, None

    matches = list(_SENTENCE_END_RE.finditer(text))
    if not matches:
        return None, None

    # Only discard a small leading fragment.  This catches examples such as
    # "do with mine. Dave Chappelle..." and "life was almost gone. Do you..."
    # without deleting a meaningful full opening sentence.
    for m in matches[:2]:
        leading = text[: m.end()].strip()
        remaining = text[m.end() :].strip()
        words = re.findall(r"\b[\w'’-]+\b", leading)
        if remaining and len(words) <= 6:
            pos = m.end()
            return _ratio_time(seg, pos, before=True), remaining
        break
    return None, None


def _trim_trailing_fragment(seg: dict) -> tuple[float | None, str | None]:
    """Trim dangling words after the last complete sentence in a segment."""
    text = _norm(seg.get("text", ""))
    if _ends_terminal(text):
        return None, None
    matches = list(_SENTENCE_END_RE.finditer(text))
    if not matches:
        return None, None
    m = matches[-1]
    complete = text[: m.end()].strip()
    trailing = text[m.end() :].strip()
    trailing_words = re.findall(r"\b[\w'’-]+\b", trailing)
    # A long unfinished tail is safer to handle by extending to later segments.
    if complete and trailing and len(trailing_words) <= 14:
        return _ratio_time(seg, m.end(), before=False), complete
    return None, None


def _rebuild_text(segments: list[dict], start: float, end: float) -> str:
    pieces: list[str] = []
    for seg in segments:
        s0, s1 = float(seg["start"]), float(seg["end"])
        if s1 <= start or s0 >= end:
            continue
        text = _norm(seg.get("text", ""))
        if not text:
            continue
        words = text.split()
        if words and s1 > s0:
            kept = []
            step = (s1 - s0) / len(words)
            for i, word in enumerate(words):
                ws = s0 + i * step
                we = s0 + (i + 1) * step
                if we <= start or ws >= end:
                    continue
                kept.append(word)
            text = " ".join(kept).strip()
        if text:
            pieces.append(text)
    return " ".join(pieces).strip()


def refine_candidate_boundaries(
    candidates: list[dict],
    segments: list[dict],
    *,
    min_seconds: float = 70.0,
    max_seconds: float = 150.0,
) -> list[dict]:
    """Locally clean Gemini's rough boundaries without another API call.

    Rules:
    * trim short orphan phrases inside the first/last Whisper segment;
    * if the first segment is still a continuation, walk backward to a nearby
      sentence boundary when the max duration allows it;
    * if the end is still incomplete, walk forward to the next terminal
      sentence when the max duration allows it;
    * never knowingly push a clip outside min/max duration.
    """
    if not candidates:
        return []

    refined: list[dict] = []
    for raw in candidates:
        c = dict(raw)
        # Cached V0.2.2+ candidates may already have been locally refined.
        # Do not progressively trim/expand them again on every rerun.
        if c.get("boundary_refined") and c.get("boundary_notes"):
            refined.append(c)
            continue
        si = int(c.get("start_index", 0))
        ei = int(c.get("end_index", si))
        original_start = float(c["start"])
        original_end = float(c["end"])
        start = original_start
        end = original_end
        notes: list[str] = []

        # 1) Intra-segment leading orphan trim.
        t, _ = _trim_leading_fragment(segments[si])
        if t is not None and t < end and (end - t) >= min_seconds:
            start = t
            notes.append("trimmed leading fragment inside first segment")

        # 2) If still clearly mid-thought and previous segment joins directly,
        # walk backward until a sentence break (bounded by max duration).
        first_text = _norm(segments[si].get("text", ""))
        if (
            start == original_start
            and _starts_like_fragment(first_text)
            and si > 0
            and not _ends_terminal(segments[si - 1].get("text", ""))
        ):
            j = si
            while j > 0:
                prev = segments[j - 1]
                gap = float(segments[j]["start"]) - float(prev["end"])
                proposed = float(prev["start"])
                if end - proposed > max_seconds:
                    break
                if gap > 1.35:
                    break
                j -= 1
                start = proposed
                if _ends_terminal(prev.get("text", "")):
                    break
            if j != si:
                si = j
                notes.append("expanded start to nearby sentence context")

        # 3) Intra-segment dangling-tail trim (best because it avoids padding).
        t, _ = _trim_trailing_fragment(segments[ei])
        if t is not None and t > start and (t - start) >= min_seconds:
            end = t
            notes.append("trimmed trailing fragment inside last segment")

        # 4) Otherwise extend to a nearby terminal sentence, but only inside max.
        if end == original_end and not _ends_terminal(segments[ei].get("text", "")):
            j = ei
            while j + 1 < len(segments):
                nxt = segments[j + 1]
                gap = float(nxt["start"]) - float(segments[j]["end"])
                proposed = float(nxt["end"])
                if proposed - start > max_seconds:
                    break
                if gap > 1.6:
                    break
                j += 1
                end = proposed
                if _ends_terminal(nxt.get("text", "")):
                    break
            if j != ei:
                ei = j
                notes.append("extended end to nearby complete sentence")

        # Keep original if an edge case somehow violated the hard envelope.
        duration = end - start
        if duration < min_seconds - 0.01 or duration > max_seconds + 0.01:
            start, end = original_start, original_end
            si = int(c.get("start_index", 0))
            ei = int(c.get("end_index", si))
            notes = ["refinement skipped: hard duration envelope"]
            duration = end - start

        c["original_start"] = round(original_start, 3)
        c["original_end"] = round(original_end, 3)
        c["start"] = round(start, 3)
        c["end"] = round(end, 3)
        c["duration"] = round(duration, 3)
        c["start_index"] = si
        c["end_index"] = ei
        c["boundary_refined"] = bool(notes and not notes[0].startswith("refinement skipped"))
        c["boundary_notes"] = notes
        c["text"] = _rebuild_text(segments, start, end)
        refined.append(c)

    return refined
