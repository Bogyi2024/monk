from __future__ import annotations

import math
import re
from pathlib import Path


def _words_with_times(seg: dict) -> list[tuple[str, float, float]]:
    """Approximate word timestamps inside a Whisper segment.

    Future fresh transcriptions may contain true `words` timestamps; use them
    when present.  Cached V0.1/V0.2 transcripts only have segment timestamps,
    so proportional timing is used as a safe compatibility fallback.
    """
    true_words = seg.get("words")
    if isinstance(true_words, list) and true_words:
        out = []
        for w in true_words:
            text = str(w.get("word", "")).strip()
            if not text:
                continue
            try:
                out.append((text, float(w["start"]), float(w["end"])))
            except Exception:
                continue
        if out:
            return out

    text = re.sub(r"\s+", " ", str(seg.get("text", ""))).strip()
    words = text.split()
    if not words:
        return []
    start, end = float(seg["start"]), float(seg["end"])
    span = max(0.05, end - start)
    step = span / len(words)
    return [(w, start + i * step, start + (i + 1) * step) for i, w in enumerate(words)]


def build_caption_blocks(
    segments: list[dict],
    clip_start: float,
    clip_end: float,
    *,
    max_words: int = 7,
    max_seconds: float = 2.6,
    min_seconds: float = 0.55,
) -> list[dict]:
    words: list[tuple[str, float, float]] = []
    for seg in segments:
        if float(seg["end"]) <= clip_start or float(seg["start"]) >= clip_end:
            continue
        for text, ws, we in _words_with_times(seg):
            if we <= clip_start or ws >= clip_end:
                continue
            words.append((text, max(ws, clip_start), min(we, clip_end)))

    blocks: list[dict] = []
    cur: list[tuple[str, float, float]] = []
    for item in words:
        if not cur:
            cur = [item]
            continue
        prospective_dur = item[2] - cur[0][1]
        previous_word = cur[-1][0]
        should_break = (
            len(cur) >= max_words
            or prospective_dur > max_seconds
            or (len(cur) >= 4 and re.search(r"[.!?][\"')\]]*$", previous_word))
        )
        if should_break:
            blocks.append(_finalize_block(cur, clip_start, clip_end, min_seconds))
            cur = [item]
        else:
            cur.append(item)
    if cur:
        blocks.append(_finalize_block(cur, clip_start, clip_end, min_seconds))

    # Merge tiny 1-2 word tails/heads when the neighboring caption can absorb
    # them. This avoids ugly single-word flashes such as a final "you.".
    i = 0
    while i < len(blocks):
        wc = len(blocks[i]["text"].split())
        if wc <= 2 and i > 0:
            prev_wc = len(blocks[i - 1]["text"].split())
            merged_dur = blocks[i]["end"] - blocks[i - 1]["start"]
            if prev_wc + wc <= max_words + 1 and merged_dur <= max_seconds + 0.5:
                blocks[i - 1]["text"] = (blocks[i - 1]["text"] + " " + blocks[i]["text"]).strip()
                blocks[i - 1]["end"] = blocks[i]["end"]
                blocks.pop(i)
                continue
        if wc <= 2 and i == 0 and len(blocks) > 1:
            next_wc = len(blocks[1]["text"].split())
            merged_dur = blocks[1]["end"] - blocks[0]["start"]
            if next_wc + wc <= max_words + 1 and merged_dur <= max_seconds + 0.5:
                blocks[1]["text"] = (blocks[0]["text"] + " " + blocks[1]["text"]).strip()
                blocks[1]["start"] = blocks[0]["start"]
                blocks.pop(0)
                continue
        i += 1

    # Prevent overlaps introduced by minimum display expansion.
    for i in range(len(blocks) - 1):
        if blocks[i]["end"] > blocks[i + 1]["start"]:
            blocks[i]["end"] = max(blocks[i]["start"] + 0.2, blocks[i + 1]["start"] - 0.02)
    return [b for b in blocks if b["end"] > b["start"]]


def _finalize_block(items, clip_start, clip_end, min_seconds):
    start = items[0][1]
    end = items[-1][2]
    if end - start < min_seconds:
        end = min(clip_end, start + min_seconds)
    return {
        "start": max(0.0, start - clip_start),
        "end": max(0.0, end - clip_start),
        "text": " ".join(x[0] for x in items).strip(),
    }


def _srt_time(seconds: float) -> str:
    ms = int(round(max(0.0, seconds) * 1000))
    h, rem = divmod(ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _ass_time(seconds: float) -> str:
    cs = int(round(max(0.0, seconds) * 100))
    h, rem = divmod(cs, 360_000)
    m, rem = divmod(rem, 6_000)
    s, cs = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _escape_ass(text: str) -> str:
    return text.replace("\\", r"\\").replace("{", r"\{").replace("}", r"\}")


def _wrap_ass(text: str, max_chars_per_line: int = 28) -> str:
    words = text.split()
    if not words:
        return ""
    lines = [""]
    for word in words:
        proposal = (lines[-1] + " " + word).strip()
        if lines[-1] and len(proposal) > max_chars_per_line and len(lines) < 2:
            lines.append(word)
        else:
            lines[-1] = proposal
    return r"\N".join(_escape_ass(line) for line in lines if line)


def write_subtitles(
    segments: list[dict],
    clip_start: float,
    clip_end: float,
    srt_path: str | Path,
    ass_path: str | Path,
    *,
    width: int = 1080,
    height: int = 1920,
    font_name: str = "Arial",
    font_size: int = 64,
    outline: int = 4,
    margin_v: int = 220,
    max_words: int = 7,
    max_seconds: float = 2.6,
    max_chars_per_line: int = 28,
) -> list[dict]:
    blocks = build_caption_blocks(
        segments,
        clip_start,
        clip_end,
        max_words=max_words,
        max_seconds=max_seconds,
    )
    srt_path = Path(srt_path)
    ass_path = Path(ass_path)
    srt_path.parent.mkdir(parents=True, exist_ok=True)
    ass_path.parent.mkdir(parents=True, exist_ok=True)

    srt_lines = []
    for i, b in enumerate(blocks, 1):
        srt_lines.extend([
            str(i),
            f"{_srt_time(b['start'])} --> {_srt_time(b['end'])}",
            b["text"],
            "",
        ])
    srt_path.write_text("\n".join(srt_lines), encoding="utf-8")

    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Caption,{font_name},{font_size},&H00FFFFFF,&H0000FFFF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,{outline},0,2,70,70,{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    events = []
    for b in blocks:
        wrapped = _wrap_ass(b["text"], max_chars_per_line=max_chars_per_line)
        events.append(
            f"Dialogue: 0,{_ass_time(b['start'])},{_ass_time(b['end'])},Caption,,0,0,0,,{wrapped}"
        )
    ass_path.write_text(header + "\n".join(events) + "\n", encoding="utf-8")
    return blocks
