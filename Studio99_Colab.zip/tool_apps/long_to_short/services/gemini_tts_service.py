from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import time
import wave
import shutil
import subprocess
from contextlib import contextmanager
from pathlib import Path

from services.gemini_moment_selector import (
    resolve_api_keys,
    _proxy_if_listening,
    _restore_proxy,
    _is_key_rotatable_error,
    _is_model_unavailable_error,
    _is_transient_service_error,
    _model_chain,
)

ROOT = Path(__file__).resolve().parents[1]
_PROXY_ENV_KEYS = (
    "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
    "http_proxy", "https_proxy", "all_proxy",
)


def wav_duration(path: str | Path) -> float:
    with wave.open(str(path), "rb") as wf:
        frames = wf.getnframes()
        rate = wf.getframerate()
        return frames / float(rate or 1)


def _write_wav(path: Path, pcm: bytes, rate: int = 24000) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(pcm)


def _tts_prompt(text: str) -> str:
    return f"""
AUDIO PROFILE:
Use one neutral adult English documentary/commentary narrator.
Sound clear, grounded, intelligent, natural and conversational.
Calm medium-slow pace, roughly 145-160 spoken words per minute, strong diction, no exaggerated trailer voice.
Maintain one continuous vocal identity from the first word to the last: same timbre, pitch range, cadence, energy, accent, microphone distance and narration style throughout.
Do NOT imitate, impersonate, or sound like the public figure being discussed in the source video.
Do not add words, introductions, labels, sound effects, or commentary that is not in the transcript.
Read the transcript exactly once, completely, without stopping early.

TRANSCRIPT:
{text}
""".strip()


def _decode_inline_data(data) -> bytes:
    if data is None:
        return b""
    if isinstance(data, str):
        try:
            return base64.b64decode(data)
        except Exception:
            return data.encode("latin1", errors="ignore")
    return bytes(data or b"")


def _extract_pcm_generate_content(response) -> bytes:
    try:
        data = response.candidates[0].content.parts[0].inline_data.data
    except Exception as exc:
        raise RuntimeError(f"Gemini TTS returned no audio payload: {exc}") from exc
    return _decode_inline_data(data)


def _supports_tts_streaming(model: str) -> bool:
    """Google documents TTS streaming for Gemini 3.1+ TTS models."""
    m = re.search(r"gemini-(\d+)\.(\d+)", str(model or "").lower())
    if not m:
        return False
    major, minor = int(m.group(1)), int(m.group(2))
    return (major, minor) >= (3, 1)


def _is_transport_disconnect(exc: Exception) -> bool:
    text = f"{type(exc).__name__}: {exc}".lower()
    return any(token in text for token in (
        "remoteprotocolerror", "remote protocol error",
        "server disconnected without sending a response", "server disconnected",
        "connection closed", "peer closed", "readerror", "connecterror",
        "proxyerror", "broken pipe", "connection reset", "eof occurred",
    ))


@contextmanager
def _without_env_proxy():
    """Temporarily bypass env proxy for one transport-recovery attempt only."""
    old = {k: os.environ.get(k) for k in _PROXY_ENV_KEYS}
    try:
        for k in _PROXY_ENV_KEYS:
            os.environ.pop(k, None)
        yield
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


def _make_client(api_key: str, timeout_ms: int):
    from google import genai
    from google.genai import types
    # Gen AI SDK exposes HttpOptions.timeout. A generous timeout avoids treating
    # normal TTS generation time as a client failure.
    return genai.Client(
        api_key=api_key,
        http_options=types.HttpOptions(timeout=max(30_000, int(timeout_ms))),
    )


def _call_tts(
    text: str,
    api_key: str,
    model: str,
    voice: str,
    *,
    use_streaming: bool = True,
    timeout_ms: int = 180_000,
) -> bytes:
    from google.genai import types

    client = _make_client(api_key, timeout_ms)
    prompt = _tts_prompt(text)
    config = types.GenerateContentConfig(
        response_modalities=["AUDIO"],
        speech_config=types.SpeechConfig(
            voice_config=types.VoiceConfig(
                prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name=voice)
            )
        ),
    )

    # Gemini 3.1+ TTS officially supports streaming. It is safer for a local
    # proxy because response bytes begin arriving earlier instead of leaving an
    # HTTP connection idle until the whole voice track is ready.
    if use_streaming and _supports_tts_streaming(model):
        pcm_parts: list[bytes] = []
        response_stream = client.models.generate_content_stream(
            model=model,
            contents=prompt,
            config=config,
        )
        for chunk in response_stream:
            try:
                data = chunk.candidates[0].content.parts[0].inline_data.data
            except (IndexError, AttributeError, TypeError):
                continue
            piece = _decode_inline_data(data)
            if piece:
                pcm_parts.append(piece)
        pcm = b"".join(pcm_parts)
    else:
        response = client.models.generate_content(
            model=model,
            contents=prompt,
            config=config,
        )
        pcm = _extract_pcm_generate_content(response)

    if len(pcm) < 1000:
        raise RuntimeError("Gemini TTS audio payload is empty/too small")
    return pcm


def synthesize_cached(
    text: str,
    *,
    model: str = "gemini-3.1-flash-tts-preview",
    model_fallbacks: tuple[str, ...] | list[str] = ("gemini-2.5-flash-preview-tts",),
    voice: str = "Charon",
    allow_paid_fallback: bool = False,
    retries_per_key: int = 2,
    backoff_seconds: float = 3.0,
    use_streaming: bool = True,
    timeout_ms: int = 180_000,
    direct_fallback_after_proxy_disconnect: bool = True,
    cache_variant: str = "default",
) -> tuple[Path, dict]:
    clean = " ".join(str(text or "").split()).strip()
    if not clean:
        raise ValueError("TTS text is empty")
    cache_key = hashlib.sha256(json.dumps({"model": model, "voice": voice, "text": clean, "cache_variant": str(cache_variant or "default")}, sort_keys=True).encode("utf-8")).hexdigest()[:24]
    cache_dir = ROOT / "state" / "tts_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    wav_path = cache_dir / f"{cache_key}.wav"
    meta_path = cache_dir / f"{cache_key}.json"
    if wav_path.exists() and wav_path.stat().st_size > 1000:
        dur = wav_duration(wav_path)
        print(f"♻️ TTS cache hit → {wav_path.name} | {dur:.1f}s")
        meta = {"cached": True, "path": str(wav_path), "duration": dur, "model": model, "voice": voice, "cache_variant": str(cache_variant or "default")}
        if meta_path.exists():
            try:
                meta.update(json.loads(meta_path.read_text(encoding="utf-8")))
                meta["cached"] = True
            except Exception:
                pass
        return wav_path, meta

    pool = resolve_api_keys(allow_paid_fallback)
    if not allow_paid_fallback:
        print("🛡️ TTS paid fallback: DISABLED")
    proxy_state = _proxy_if_listening()
    proxy_active = bool(proxy_state)
    errors: list[str] = []
    try:
        for active_model in _model_chain(model, model_fallbacks):
            stream_this_model = bool(use_streaming and _supports_tts_streaming(active_model))
            print(f"      🧠 TTS model → {active_model}" + (" [streaming]" if stream_this_model else " [non-stream]"))
            switch_model = False
            for entry in pool:
                print(f"      🔑 TTS trying {entry.alias}[{entry.fingerprint}]" + (" [PAID]" if entry.paid else ""))
                transient_try = 0
                direct_recovery_used = False
                while True:
                    try:
                        pcm = _call_tts(
                            clean, entry.value, active_model, voice,
                            use_streaming=use_streaming,
                            timeout_ms=timeout_ms,
                        )
                        _write_wav(wav_path, pcm)
                        dur = wav_duration(wav_path)
                        meta = {
                            "cached": False,
                            "path": str(wav_path),
                            "duration": dur,
                            "model": active_model,
                            "requested_model": model,
                            "voice": voice,
                            "key_alias": entry.alias,
                            "key_source": entry.source,
                            "key_fingerprint": entry.fingerprint,
                            "paid_key_used": entry.paid,
                            "streaming": stream_this_model,
                            "proxy_active": proxy_active,
                            "direct_transport_recovery_used": direct_recovery_used,
                            "cache_variant": str(cache_variant or "default"),
                        }
                        meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
                        print(f"🎙️ Gemini EN VO → {wav_path.name} | {dur:.1f}s | voice={voice} | model={active_model}")
                        return wav_path, meta
                    except Exception as exc:
                        # A local HTTP proxy can drop a long TTS connection before
                        # Gemini returns headers/audio. This is transport failure,
                        # not a bad/free API key. Retry same model/key first.
                        if _is_transport_disconnect(exc) and proxy_active and direct_fallback_after_proxy_disconnect and not direct_recovery_used:
                            errors.append(f"{active_model}/{entry.alias}/proxy: {type(exc).__name__}: {exc}")
                            print("      🔌 TTS proxy connection dropped → one direct same-key recovery attempt")
                            direct_recovery_used = True
                            try:
                                with _without_env_proxy():
                                    pcm = _call_tts(
                                        clean, entry.value, active_model, voice,
                                        use_streaming=use_streaming,
                                        timeout_ms=timeout_ms,
                                    )
                                _write_wav(wav_path, pcm)
                                dur = wav_duration(wav_path)
                                meta = {
                                    "cached": False,
                                    "path": str(wav_path),
                                    "duration": dur,
                                    "model": active_model,
                                    "requested_model": model,
                                    "voice": voice,
                                    "key_alias": entry.alias,
                                    "key_source": entry.source,
                                    "key_fingerprint": entry.fingerprint,
                                    "paid_key_used": entry.paid,
                                    "streaming": stream_this_model,
                                    "proxy_active": proxy_active,
                                    "direct_transport_recovery_used": True,
                                }
                                meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
                                print(f"      ✅ TTS direct transport recovery succeeded ({entry.alias})")
                                print(f"🎙️ Gemini EN VO → {wav_path.name} | {dur:.1f}s | voice={voice} | model={active_model}")
                                return wav_path, meta
                            except Exception as direct_exc:
                                errors.append(f"{active_model}/{entry.alias}/direct: {type(direct_exc).__name__}: {direct_exc}")
                                print("      ⚠️ direct recovery did not work → restore proxy and continue safe retry logic")
                                # Continue classification using the original proxy
                                # exception so this does not rotate the API key.

                        if _is_model_unavailable_error(exc):
                            print(f"      ⚠️ TTS model unavailable → fallback model ({active_model})")
                            errors.append(f"{active_model}: {exc}")
                            switch_model = True
                            break
                        if _is_key_rotatable_error(exc):
                            print(f"      ⚠️ TTS key unavailable/quota/access → rotate ({entry.alias})")
                            errors.append(f"{active_model}/{entry.alias}: {exc}")
                            break
                        if _is_transient_service_error(exc):
                            if transient_try < max(0, int(retries_per_key)):
                                delay = max(0.0, float(backoff_seconds)) * (2 ** transient_try)
                                transient_try += 1
                                print(f"      ⏳ TTS transient transport/service error → retry same key {transient_try}/{retries_per_key} in {delay:.0f}s")
                                if delay:
                                    time.sleep(delay)
                                continue
                            print(f"      ⚠️ TTS still unavailable → fallback model before burning free keys ({active_model})")
                            errors.append(f"{active_model}/{entry.alias}: {exc}")
                            switch_model = True
                            break
                        raise
                if switch_model:
                    break
            if switch_model:
                continue
    finally:
        _restore_proxy(proxy_state)
    raise RuntimeError("Gemini TTS failed across model/key/transport fallbacks. " + " | ".join(errors[-8:]))


def _group_segment_texts(segments: list[str], max_words: int = 68) -> list[str]:
    """Group commentary beats into short TTS requests to avoid preview-model truncation."""
    max_words = max(28, int(max_words))
    chunks: list[str] = []
    current: list[str] = []
    count = 0
    for raw in segments:
        text = " ".join(str(raw or "").split()).strip()
        if not text:
            continue
        wc = len(text.split())
        if current and count + wc > max_words:
            chunks.append(" ".join(current).strip())
            current, count = [], 0
        current.append(text)
        count += wc
    if current:
        chunks.append(" ".join(current).strip())
    return chunks


def _concat_wavs(paths: list[Path], out: Path, pause_ms: int = 100) -> None:
    if not paths:
        raise ValueError("No WAV chunks to concatenate")
    rate = channels = sampwidth = None
    pcm_parts: list[bytes] = []
    for i, p in enumerate(paths):
        with wave.open(str(p), "rb") as wf:
            r, c, sw = wf.getframerate(), wf.getnchannels(), wf.getsampwidth()
            if rate is None:
                rate, channels, sampwidth = r, c, sw
            elif (r, c, sw) != (rate, channels, sampwidth):
                raise RuntimeError("TTS WAV chunk format mismatch")
            pcm_parts.append(wf.readframes(wf.getnframes()))
        if i + 1 < len(paths) and pause_ms > 0:
            frames = int((rate or 24000) * max(0, int(pause_ms)) / 1000.0)
            pcm_parts.append(b"\x00" * frames * (channels or 1) * (sampwidth or 2))
    out.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out), "wb") as wf:
        wf.setnchannels(channels or 1)
        wf.setsampwidth(sampwidth or 2)
        wf.setframerate(rate or 24000)
        wf.writeframes(b"".join(pcm_parts))


def synthesize_chunked_cached(
    segments: list[str],
    *,
    model: str = "gemini-3.1-flash-tts-preview",
    model_fallbacks: tuple[str, ...] | list[str] = ("gemini-2.5-flash-preview-tts",),
    voice: str = "Charon",
    allow_paid_fallback: bool = False,
    retries_per_key: int = 2,
    backoff_seconds: float = 3.0,
    use_streaming: bool = True,
    timeout_ms: int = 180_000,
    direct_fallback_after_proxy_disconnect: bool = True,
    chunk_max_words: int = 68,
    pause_ms: int = 100,
) -> tuple[Path, dict]:
    """Synthesize long narration in several cached requests, then concatenate.

    Gemini preview TTS can occasionally return a valid WAV that simply stops
    before the requested transcript is finished. Small requests are much more
    reliable. This fallback keeps the same voice/model and only activates after
    local Whisper proves the one-shot audio is incomplete.
    """
    clean_segments = [" ".join(str(x or "").split()).strip() for x in segments]
    clean_segments = [x for x in clean_segments if x]
    if not clean_segments:
        raise ValueError("Chunked TTS segments are empty")
    chunks = _group_segment_texts(clean_segments, max_words=chunk_max_words)
    cache_dir = ROOT / "state" / "tts_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_key = hashlib.sha256(json.dumps({
        "v": "chunked_complete_v2",
        "model": model,
        "voice": voice,
        "chunks": chunks,
        "pause_ms": int(pause_ms),
    }, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()[:24]
    wav_path = cache_dir / f"{cache_key}.wav"
    meta_path = cache_dir / f"{cache_key}.json"
    if wav_path.exists() and wav_path.stat().st_size > 1000:
        dur = wav_duration(wav_path)
        print(f"♻️ Complete chunked TTS cache hit → {wav_path.name} | {dur:.1f}s | chunks={len(chunks)}")
        meta = {
            "cached": True, "path": str(wav_path), "duration": dur,
            "model": model, "voice": voice, "strategy": "chunked_complete_v2",
            "chunk_count": len(chunks),
        }
        if meta_path.exists():
            try:
                meta.update(json.loads(meta_path.read_text(encoding="utf-8")))
                meta["cached"] = True
            except Exception:
                pass
        return wav_path, meta

    chunk_paths: list[Path] = []
    chunk_meta: list[dict] = []
    print(f"      🧩 TTS completeness fallback → {len(chunks)} smaller requests")
    for i, chunk in enumerate(chunks, 1):
        print(f"         chunk {i}/{len(chunks)}: {len(chunk.split())} words")
        p, m = synthesize_cached(
            chunk,
            model=model,
            model_fallbacks=model_fallbacks,
            voice=voice,
            allow_paid_fallback=allow_paid_fallback,
            retries_per_key=retries_per_key,
            backoff_seconds=backoff_seconds,
            use_streaming=use_streaming,
            timeout_ms=timeout_ms,
            direct_fallback_after_proxy_disconnect=direct_fallback_after_proxy_disconnect,
            cache_variant=f"chunked_complete_v2_{cache_key}_{i:02d}",
        )
        chunk_paths.append(Path(p))
        chunk_meta.append(m)
    _concat_wavs(chunk_paths, wav_path, pause_ms=pause_ms)
    dur = wav_duration(wav_path)
    meta = {
        "cached": False,
        "path": str(wav_path),
        "duration": dur,
        "model": model,
        "voice": voice,
        "strategy": "chunked_complete_v2",
        "chunk_count": len(chunks),
        "chunk_words": [len(x.split()) for x in chunks],
        "pause_ms": int(pause_ms),
        "paid_key_used": any(bool(x.get("paid_key_used")) for x in chunk_meta),
        "chunks": chunk_meta,
    }
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"      ✅ Continuity-fallback chunked TTS assembled → {wav_path.name} | {dur:.1f}s")
    return wav_path, meta


def stretch_wav_min_duration_cached(
    wav_path: str | Path,
    *,
    min_seconds: float,
    target_seconds: float | None = None,
) -> tuple[Path, dict]:
    """Slow narration slightly when a complete narration is still too short.

    This is local FFmpeg work only; it does not call Gemini again. Typical use is
    a small adjustment from ~64-69s to ~72s, keeping speech natural.
    """
    src = Path(wav_path).resolve()
    dur = wav_duration(src)
    minimum = max(0.0, float(min_seconds))
    if dur >= minimum or minimum <= 0:
        return src, {"stretched": False, "duration": dur, "source_duration": dur}
    target = max(minimum, float(target_seconds or minimum))
    # Never slow more than 25% in this automatic safeguard.
    target = min(target, dur / 0.75)
    atempo = dur / target
    if atempo >= 0.999:
        return src, {"stretched": False, "duration": dur, "source_duration": dur}
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg not found for local TTS duration safeguard")
    key = hashlib.sha256(json.dumps({
        "v": "tts_min_duration_v1",
        "src_size": src.stat().st_size,
        "src_name": src.name,
        "target": round(target, 3),
    }, sort_keys=True).encode()).hexdigest()[:24]
    out = ROOT / "state" / "tts_cache" / f"{key}.wav"
    if not out.exists() or out.stat().st_size < 1000:
        cmd = [
            ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
            "-i", str(src), "-filter:a", f"atempo={atempo:.8f}",
            "-c:a", "pcm_s16le", str(out),
        ]
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode != 0:
            raise RuntimeError(r.stderr[-3000:])
    new_dur = wav_duration(out)
    print(f"      🕒 Local narration pace safeguard: {dur:.1f}s → {new_dur:.1f}s (no API call)")
    return out, {
        "stretched": True,
        "source_duration": dur,
        "duration": new_dur,
        "target_seconds": target,
        "atempo": atempo,
    }
