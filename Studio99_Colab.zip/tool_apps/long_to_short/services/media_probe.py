from __future__ import annotations
import json, shutil, subprocess
from pathlib import Path

def _which(name: str) -> str:
    p = shutil.which(name)
    if not p:
        raise RuntimeError(f"{name} not found in PATH")
    return p

def probe(path: str | Path) -> dict:
    ffprobe = _which("ffprobe")
    cmd = [ffprobe, "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip() or "ffprobe failed")
    data = json.loads(r.stdout)
    fmt = data.get("format", {})
    streams = data.get("streams", [])
    v = next((s for s in streams if s.get("codec_type") == "video"), {})
    a = next((s for s in streams if s.get("codec_type") == "audio"), {})
    width, height = int(v.get("width") or 0), int(v.get("height") or 0)
    rotation = (v.get("tags") or {}).get("rotate", 0)
    for side in v.get("side_data_list") or []:
        if "rotation" in side:
            rotation = side["rotation"]
    try:
        if abs(round(float(rotation))) % 180 == 90:
            width, height = height, width
    except (ValueError, TypeError):
        pass
    return {
        "duration": float(fmt.get("duration") or 0.0),
        "size": int(fmt.get("size") or 0),
        "video": {"codec": v.get("codec_name"), "width": width, "height": height, "fps": v.get("avg_frame_rate")},
        "audio": {"codec": a.get("codec_name"), "sample_rate": a.get("sample_rate")}
    }
