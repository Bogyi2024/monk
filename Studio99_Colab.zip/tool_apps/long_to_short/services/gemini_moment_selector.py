from __future__ import annotations

import hashlib
import json
import os
import re
import socket
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]


@dataclass
class SelectionConfig:
    count: int = 5
    min_seconds: float = 70.0
    preferred_min_seconds: float = 90.0
    preferred_max_seconds: float = 130.0
    max_seconds: float = 150.0
    max_overlap_ratio: float = 0.25
    model: str = "gemini-3.5-flash"
    model_fallbacks: tuple[str, ...] = ("gemini-3.5-flash-lite",)
    temperature: float = 0.25
    max_attempts: int = 2
    allow_paid_fallback: bool = False
    transient_retries_per_key: int = 1
    transient_backoff_seconds: float = 4.0
    request_timeout_ms: int = 120_000
    total_timeout_seconds: float = 360.0
    profile: str = "generic"


@dataclass
class KeyEntry:
    alias: str
    source: str
    value: str
    paid: bool = False

    @property
    def fingerprint(self) -> str:
        return hashlib.sha256(self.value.encode("utf-8", errors="ignore")).hexdigest()[:8]


def _load_env_file(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    if not path.exists():
        return data
    for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and v:
            data[k] = v
    return data


def _numbered_keys(env: dict[str, str], source: str) -> list[KeyEntry]:
    patterns = [
        (re.compile(r"^GEMINI_TEXT_PROJECT_(\d+)_KEY$", re.I), 100),
        (re.compile(r"^GEMINI_API_PROJECT_(\d+)_KEY$", re.I), 200),
        (re.compile(r"^GEMINI_API_KEY_(\d+)$", re.I), 300),
        # Existing recap_personal free Gemini projects are named this way.
        (re.compile(r"^GEMINI_IMAGE_PROJECT_(\d+)_KEY$", re.I), 400),
    ]
    found: list[tuple[int, KeyEntry]] = []
    for name, value in env.items():
        for pat, base in patterns:
            m = pat.match(name)
            if not m:
                continue
            n = int(m.group(1))
            found.append((base + n, KeyEntry(alias=f"free_project_{n}", source=f"{source}:{name}", value=value, paid=False)))
            break
    found.sort(key=lambda x: x[0])
    return [x[1] for x in found]


def resolve_api_keys(allow_paid_fallback: bool = False) -> list[KeyEntry]:
    """Free-key-first pool. API key values are never printed.

    Order:
      1) numbered free keys in long_to_short/.env or config/.env
      2) numbered GEMINI_IMAGE_PROJECT_N_KEY keys in sibling recap_personal/.env
      3) generic key in long_to_short/.env (explicit standalone choice)
      4) Windows/process GEMINI_API_KEY only when paid fallback is enabled
    """
    entries: list[KeyEntry] = []
    seen_values: set[str] = set()

    def add(entry: KeyEntry):
        v = entry.value.strip()
        if not v or v in seen_values:
            return
        seen_values.add(v)
        entries.append(entry)

    own_env_paths = [ROOT / ".env", ROOT / "config" / ".env"]
    own_maps = [(p, _load_env_file(p)) for p in own_env_paths]
    for p, env in own_maps:
        for entry in _numbered_keys(env, str(p)):
            add(entry)

    recap_dir = Path(os.getenv("RECAP_PERSONAL_DIR", "")).expanduser() if os.getenv("RECAP_PERSONAL_DIR") else ROOT.parent / "recap_personal"
    recap_env_path = recap_dir / ".env"
    recap_env = _load_env_file(recap_env_path)
    # Only numbered project keys from recap are treated as free by default.
    for entry in _numbered_keys(recap_env, str(recap_env_path)):
        add(entry)

    # Explicit standalone generic keys are allowed before any paid fallback.
    for p, env in own_maps:
        for name in ("GEMINI_API_KEY", "GOOGLE_API_KEY"):
            value = str(env.get(name) or "").strip()
            if value:
                add(KeyEntry(alias="standalone_generic", source=f"{p}:{name}", value=value, paid=False))

    if allow_paid_fallback:
        # User identified the process-level GEMINI_API_KEY as the paid key.
        paid = str(os.getenv("GEMINI_API_KEY") or "").strip()
        if paid:
            add(KeyEntry(alias="paid_process_fallback", source="process environment:GEMINI_API_KEY", value=paid, paid=True))
        # Existing recap image paid reserve is also last-resort only.
        recap_paid = str(recap_env.get("GEMINI_IMAGE_PAID_KEY") or "").strip()
        if recap_paid:
            add(KeyEntry(alias="paid_recap_fallback", source=f"{recap_env_path}:GEMINI_IMAGE_PAID_KEY", value=recap_paid, paid=True))

    if not entries:
        extra = " Paid fallback is disabled." if not allow_paid_fallback else ""
        raise RuntimeError(
            "No Gemini API key found for Long-to-Short. Expected numbered free keys such as "
            "GEMINI_IMAGE_PROJECT_1_KEY in sibling recap_personal/.env, or a key in long_to_short/.env."
            + extra
        )
    return entries


def _proxy_if_listening() -> dict[str, str | None]:
    return {}  # use the OS route; never select a local VPN port


def _restore_proxy(old: dict[str, str | None]) -> None:
    if not old:
        return
    for key, value in old.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value




def _profile_guidance(profile: str) -> str:
    key = str(profile or "generic").strip().lower().replace("-", "_")
    guides = {
        "motivation": "Prioritize mindset shifts, resilience, discipline, self-development, life lessons, transformation, and quotable practical takeaways. Avoid generic motivational filler unless the source provides a concrete story or insight.",
        "psychology": "Prioritize clear human-behavior or relationship insights, emotional patterns, communication, boundaries, attachment/trauma discussion when actually present in the source, and a useful standalone takeaway. Do not invent diagnoses or clinical claims.",
        "horror": "Prioritize complete eerie/scary stories, escalating suspense, unsettling firsthand experiences, paranormal or unexplained moments, and a strong reveal/payoff. Never cut before the scary payoff just to hit duration.",
        "crime": "Prioritize self-contained crime/mystery moments with a clear factual setup, evidence/clue, turning point, interrogation insight, or reveal. Keep attribution grounded in the transcript; do not turn allegations into facts.",
        "knowledge": "Prioritize surprising but understandable facts, explanations, history/science/education insights, useful demonstrations, and moments where the viewer learns one complete thing with a clear conclusion.",
        "comedy": "Prioritize complete comedic stories, strong setup-to-punchline sequences, funny misunderstandings, banter, or callbacks. Preserve enough setup and never cut before the punchline/reaction payoff.",
        "business": "Prioritize entrepreneurship, leadership, money/business lessons, strategy, failure/recovery, negotiation, teams, and concrete operating insights with a clean takeaway.",
        "celebrity": "Prioritize revealing personal stories, behind-the-scenes experiences, career turning points, candid lessons, and memorable anecdotes that stand alone without gossip-padding.",
        "tech_ai": "Prioritize clear technology/AI explanations, practical implications, surprising developments, founder/build lessons, and complete arguments about how technology changes work or life.",
        "sports": "Prioritize athlete stories, competition mindset, training, tactical insight, comeback/failure lessons, team dynamics, and complete sports anecdotes with a strong payoff.",
        "generic": "Prioritize the strongest standalone story, insight, reveal, lesson, or emotionally resonant moment in the source.",
    }
    return guides.get(key, guides["generic"])

def _transcript_lines(segments: list[dict]) -> str:
    lines = []
    for idx, seg in enumerate(segments):
        txt = re.sub(r"\s+", " ", str(seg.get("text", ""))).strip()
        lines.append(f"{idx}|{float(seg['start']):.3f}|{float(seg['end']):.3f}|{txt}")
    return "\n".join(lines)


def _prompt(segments: list[dict], cfg: SelectionConfig, validation_feedback: str = "") -> str:
    feedback = f"\nPREVIOUS VALIDATION PROBLEMS TO FIX:\n{validation_feedback}\n" if validation_feedback else ""
    return f"""
You are the final editorial decision-maker for a vertical short-form video cutter.
The input is a complete time-coded English interview transcript. Choose exactly {cfg.count} UNIQUE standalone clips from anywhere in the full transcript.

EDITORIAL GOAL
- Content profile: {cfg.profile}. {_profile_guidance(cfg.profile)}
- A viewer who never watched the original interview must understand each clip by itself.
- Prefer a strong hook, clear setup/context, meaningful development, and a payoff or clean concluding thought.
- Prefer emotionally resonant, surprising, useful, quotable, controversial-with-context, or story-driven moments.
- Do NOT choose a fragment merely because individual keywords look exciting.

BOUNDARY RULES
- Choose start_index and end_index from transcript segment indexes below; indexes are inclusive.
- Preferred duration: {cfg.preferred_min_seconds:.0f}-{cfg.preferred_max_seconds:.0f} seconds.
- Allowed duration: {cfg.min_seconds:.0f}-{cfg.max_seconds:.0f} seconds.
- A naturally complete {cfg.min_seconds:.0f}-{max(cfg.min_seconds, cfg.preferred_min_seconds-1):.0f} second clip is better than padding it to the preferred duration.
- A complete clip up to {cfg.max_seconds:.0f} seconds is allowed when the story/payoff genuinely needs it.
- Never intentionally begin mid-thought or end before the payoff.
- When the best moment is an answer, include enough of the question/setup when needed.
- Local post-processing can make a tiny punctuation-level trim inside the first/last Whisper segment, so prioritize the best semantic moment rather than forcing awkward padding.

DIVERSITY RULES
- All {cfg.count} clips must cover substantially different moments/topics.
- Pairwise time overlap must be <= {cfg.max_overlap_ratio:.0%} of the shorter clip. Prefer zero overlap.
- Do not select two versions of the same conversation moment.

SCORING
Give each clip editorial_score from 0.0 to 10.0 based on hook, standalone clarity, payoff, retention potential, and emotional/intellectual value.
Also provide a concise English title, reason, and hook_summary.

Return JSON ONLY with this exact top-level shape:
{{
  "clips": [
    {{
      "start_index": 0,
      "end_index": 0,
      "editorial_score": 0.0,
      "title": "...",
      "reason": "...",
      "hook_summary": "..."
    }}
  ]
}}
{feedback}
FULL TRANSCRIPT (index|start_sec|end_sec|text):
{_transcript_lines(segments)}
""".strip()


def _extract_json(text: str) -> dict[str, Any]:
    raw = (text or "").strip()
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
    raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        a, b = raw.find("{"), raw.rfind("}")
        if a >= 0 and b > a:
            return json.loads(raw[a : b + 1])
        raise


def _overlap_ratio(a: dict, b: dict) -> float:
    inter = max(0.0, min(a["end"], b["end"]) - max(a["start"], b["start"]))
    denom = max(0.001, min(a["duration"], b["duration"]))
    return inter / denom


def _validate(raw: dict[str, Any], segments: list[dict], cfg: SelectionConfig) -> tuple[list[dict], list[str]]:
    problems: list[str] = []
    validated: list[dict] = []
    clips = raw.get("clips") if isinstance(raw, dict) else None
    if not isinstance(clips, list):
        return [], ["Top-level clips is missing or not a list."]

    for pos, item in enumerate(clips, 1):
        if not isinstance(item, dict):
            problems.append(f"clip {pos}: not an object")
            continue
        try:
            si = int(item["start_index"])
            ei = int(item["end_index"])
        except Exception:
            problems.append(f"clip {pos}: invalid start_index/end_index")
            continue
        if not (0 <= si <= ei < len(segments)):
            problems.append(f"clip {pos}: indexes out of range ({si}, {ei})")
            continue
        start = float(segments[si]["start"])
        end = float(segments[ei]["end"])
        duration = end - start
        if duration < cfg.min_seconds - 0.01 or duration > cfg.max_seconds + 0.01:
            problems.append(f"clip {pos}: duration {duration:.1f}s outside allowed {cfg.min_seconds:.0f}-{cfg.max_seconds:.0f}s")
            continue
        text = " ".join(str(s.get("text", "")).strip() for s in segments[si : ei + 1]).strip()
        clip = {
            "start": round(start, 3),
            "end": round(end, 3),
            "duration": round(duration, 3),
            "start_index": si,
            "end_index": ei,
            "score": round(float(item.get("editorial_score", 0.0)), 3),
            "editorial_score": round(float(item.get("editorial_score", 0.0)), 3),
            "title": str(item.get("title", "")).strip(),
            "reason": str(item.get("reason", "")).strip(),
            "hook_summary": str(item.get("hook_summary", "")).strip(),
            "text": text,
            "selector": "gemini",
        }
        bad_overlap = None
        for prior in validated:
            ratio = _overlap_ratio(clip, prior)
            if ratio > cfg.max_overlap_ratio:
                bad_overlap = ratio
                break
        if bad_overlap is not None:
            problems.append(f"clip {pos}: overlaps a prior accepted clip by {bad_overlap:.0%}")
            continue
        validated.append(clip)

    if len(validated) != cfg.count:
        problems.append(f"Need exactly {cfg.count} valid unique clips; got {len(validated)}.")
    validated.sort(key=lambda x: x["editorial_score"], reverse=True)
    return validated[: cfg.count], problems


def _schema(count: int) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "clips": {
                "type": "array",
                "minItems": count,
                "maxItems": count,
                "items": {
                    "type": "object",
                    "properties": {
                        "start_index": {"type": "integer"},
                        "end_index": {"type": "integer"},
                        "editorial_score": {"type": "number"},
                        "title": {"type": "string"},
                        "reason": {"type": "string"},
                        "hook_summary": {"type": "string"},
                    },
                    "required": ["start_index", "end_index", "editorial_score", "title", "reason", "hook_summary"],
                },
            }
        },
        "required": ["clips"],
    }


def _call_model(
    prompt: str,
    model: str,
    temperature: float,
    api_key: str,
    count: int,
    request_timeout_ms: int,
) -> str:
    try:
        from google import genai
        from google.genai import types
    except Exception as exc:
        raise RuntimeError("google-genai is required. Run: pip install -U google-genai") from exc

    client = genai.Client(
        api_key=api_key,
        http_options=types.HttpOptions(timeout=max(1_000, int(request_timeout_ms))),
    )
    # Use the stable generateContent path. Structured output is configured by
    # response_mime_type + response_schema; this also avoids the experimental
    # Interactions warning seen in V0.2.
    try:
        response = client.models.generate_content(
            model=model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=temperature,
                response_mime_type="application/json",
                response_schema=_schema(count),
            ),
        )
    except (TypeError, AttributeError):
        response = client.models.generate_content(model=model, contents=prompt)
    return str(getattr(response, "text", "") or "")


def _is_key_rotatable_error(exc: Exception) -> bool:
    text = f"{type(exc).__name__}: {exc}".lower()
    tokens = [
        "429", "resource_exhausted", "quota", "rate limit", "rate_limit",
        "401", "unauthenticated", "api key not valid", "api_key_invalid", "invalid api key",
        "403", "permission_denied", "permission denied", "not authorized", "access denied",
    ]
    return any(t in text for t in tokens)


def _is_model_unavailable_error(exc: Exception) -> bool:
    text = f"{type(exc).__name__}: {exc}".lower()
    tokens = [
        "404", "model not found", "not found for api version", "not supported for",
        "unsupported model", "unsupported modality", "does not support",
    ]
    return any(t in text for t in tokens)


def _is_transient_service_error(exc: Exception) -> bool:
    """Errors that should be retried/backed off rather than crashing the run.

    Gemini documents 503 UNAVAILABLE / overload as transient. 5xx and common
    network timeout wording are treated the same way here.
    """
    text = f"{type(exc).__name__}: {exc}".lower()
    tokens = [
        "503", "unavailable", "high demand", "overloaded", "temporarily unavailable",
        "500", "502", "504", "internal server error", "bad gateway", "gateway timeout",
        "timeout", "timed out", "connection reset", "connection aborted",
        # httpx/httpcore/proxy transport failures. These are not key failures and
        # should never crash/rotate a paid key decision path.
        "remoteprotocolerror", "remote protocol error",
        "server disconnected without sending a response", "server disconnected",
        "connection closed", "peer closed connection", "readerror", "read error",
        "connecterror", "connect error", "proxyerror", "proxy error",
        "networkerror", "network error", "broken pipe", "eof occurred",
    ]
    return any(t in text for t in tokens)


def _is_request_timeout_error(exc: Exception) -> bool:
    if isinstance(exc, TimeoutError):
        return True
    text = f"{type(exc).__name__}: {exc}".lower()
    return any(token in text for token in (
        "timeout", "timed out", "deadline exceeded", "deadline_exceeded",
        "readtimeout", "connecttimeout",
    ))


def _remaining_request_timeout_ms(cfg: SelectionConfig, deadline: float) -> int:
    remaining_ms = int((deadline - time.monotonic()) * 1_000)
    if remaining_ms <= 0:
        raise TimeoutError(
            f"Gemini selector overall timeout after {float(cfg.total_timeout_seconds):g}s"
        )
    return max(1_000, min(max(1_000, int(cfg.request_timeout_ms)), remaining_ms))


def _model_chain(primary: str, fallbacks) -> list[str]:
    out: list[str] = []
    for value in [primary, *(fallbacks or [])]:
        model = str(value or "").strip()
        if model and model not in out:
            out.append(model)
    return out


def _call_with_key_pool(prompt: str, cfg: SelectionConfig, pool: list[KeyEntry], preferred_index: int = 0) -> tuple[str, int, str]:
    """Call Gemini with model-first failover.

    503/high-demand is normally model/service capacity, so after the configured
    same-key retry we switch MODEL before burning through every free key.
    Quota/auth errors rotate keys on the current model.
    """
    errors: list[str] = []
    order = list(range(preferred_index, len(pool))) + list(range(0, preferred_index))
    retries_per_key = max(0, int(cfg.transient_retries_per_key))
    base_backoff = max(0.0, float(cfg.transient_backoff_seconds))
    deadline = time.monotonic() + max(1.0, float(cfg.total_timeout_seconds))

    for model in _model_chain(cfg.model, cfg.model_fallbacks):
        print(f"      🧠 selector model → {model}")
        switch_model = False
        for idx in order:
            entry = pool[idx]
            label = f"{entry.alias} [{entry.fingerprint}]" + (" [PAID]" if entry.paid else "")
            print(f"      🔑 trying {label}")
            transient_try = 0
            while True:
                try:
                    request_timeout_ms = _remaining_request_timeout_ms(cfg, deadline)
                    return _call_model(
                        prompt, model, cfg.temperature, entry.value, cfg.count,
                        request_timeout_ms,
                    ), idx, model
                except Exception as exc:
                    if _is_model_unavailable_error(exc):
                        print(f"      ⚠️ model unavailable/unsupported → fallback model ({model})")
                        errors.append(f"{model}: {type(exc).__name__}: {exc}")
                        switch_model = True
                        break
                    if _is_key_rotatable_error(exc):
                        print(f"      ⚠️ key unavailable/quota/access → rotate ({entry.alias})")
                        errors.append(f"{model}/{entry.alias}: {type(exc).__name__}: {exc}")
                        break
                    if _is_request_timeout_error(exc):
                        errors.append(f"{model}/{entry.alias}: {type(exc).__name__}: {exc}")
                        print(
                            f"      ⏱️ Gemini request timeout → rotate key ({entry.alias}); "
                            f"overall limit={float(cfg.total_timeout_seconds):g}s"
                        )
                        break
                    if _is_transient_service_error(exc):
                        errors.append(f"{model}/{entry.alias}: {type(exc).__name__}: {exc}")
                        if transient_try < retries_per_key:
                            delay = base_backoff * (2 ** transient_try)
                            transient_try += 1
                            print(f"      ⏳ Gemini service busy → retry same key {transient_try}/{retries_per_key} in {delay:.0f}s")
                            if delay > 0:
                                time.sleep(delay)
                            continue
                        print(f"      ⚠️ model still busy → fallback model before rotating all keys ({model})")
                        switch_model = True
                        break
                    raise
            if switch_model:
                break
        if switch_model:
            continue

    detail = " | ".join(errors[-6:])
    raise RuntimeError(
        "Gemini selector failed across configured model/key fallbacks. "
        "Transcript/output state was kept; rerun later and it can reuse cached work. " + detail
    )


def select_candidates_with_gemini(segments: list[dict], cfg: SelectionConfig) -> tuple[list[dict], dict]:
    if not segments:
        return [], {}
    pool = resolve_api_keys(cfg.allow_paid_fallback)
    print("🔑 Gemini key pool: " + " → ".join(
        f"{e.alias}[{e.fingerprint}]" + ("[PAID]" if e.paid else "") for e in pool
    ))
    if not cfg.allow_paid_fallback:
        print("🛡️ Paid process-environment fallback: DISABLED")
    print(f"🧠 Gemini editorial selector: models={' → '.join(_model_chain(cfg.model, cfg.model_fallbacks))} | full transcript={len(segments)} segments")

    feedback = ""
    active_idx = 0
    proxy_state = _proxy_if_listening()
    try:
        for attempt in range(1, max(1, cfg.max_attempts) + 1):
            print(f"   ↳ Gemini selection attempt {attempt}/{cfg.max_attempts} ...")
            prompt = _prompt(segments, cfg, feedback)
            text, active_idx, used_model = _call_with_key_pool(prompt, cfg, pool, preferred_index=active_idx)
            raw = _extract_json(text)
            chosen, problems = _validate(raw, segments, cfg)
            if len(chosen) == cfg.count and not problems:
                entry = pool[active_idx]
                return chosen, {
                    "key_alias": entry.alias,
                    "key_source": entry.source,
                    "key_fingerprint": entry.fingerprint,
                    "paid_key_used": entry.paid,
                    "model_used": used_model,
                }
            if len(chosen) == cfg.count:
                entry = pool[active_idx]
                return chosen, {
                    "key_alias": entry.alias,
                    "key_source": entry.source,
                    "key_fingerprint": entry.fingerprint,
                    "paid_key_used": entry.paid,
                    "model_used": used_model,
                }
            feedback = "\n".join(f"- {p}" for p in problems[:20])
            print("⚠️ Gemini selection validation needs repair:")
            for p in problems[:8]:
                print(f"   - {p}")
        raise RuntimeError(f"Gemini did not return {cfg.count} valid unique clips after {cfg.max_attempts} attempts. {feedback}")
    finally:
        _restore_proxy(proxy_state)

# ---------------------------------------------------------------------------
# TT NIGHT-PREP QUALITY SELECTOR (non-breaking extension)
# ---------------------------------------------------------------------------
def _tt_overlap_with_excluded(clip: dict, excluded_ranges: list[dict] | None) -> bool:
    for raw in excluded_ranges or []:
        try:
            a0, a1 = float(clip['start']), float(clip['end'])
            b0, b1 = float(raw.get('start')), float(raw.get('end'))
            inter = max(0.0, min(a1, b1) - max(a0, b0))
            denom = max(0.001, min(a1-a0, b1-b0))
            if inter / denom > 0.20:
                return True
        except Exception:
            continue
    return False


def _tt_prompt_up_to(
    segments: list[dict], cfg: SelectionConfig, *, min_score: float,
    excluded_ranges: list[dict] | None = None, validation_feedback: str = ''
) -> str:
    excluded = ''
    if excluded_ranges:
        lines=[]
        for r in excluded_ranges:
            try: lines.append(f"- {float(r.get('start')):.2f}-{float(r.get('end')):.2f}s")
            except Exception: pass
        if lines:
            excluded = "\nALREADY USED RANGES — DO NOT REUSE OR SUBSTANTIALLY OVERLAP:\n" + "\n".join(lines) + "\n"
    feedback = f"\nPREVIOUS VALIDATION PROBLEMS TO FIX:\n{validation_feedback}\n" if validation_feedback else ''
    return f"""
You are the final editorial decision-maker for a vertical short-form video cutter.
The input is a complete time-coded English interview transcript.

Choose UP TO {cfg.count} UNIQUE standalone clips. Quality is more important than quantity.
It is valid to return fewer than {cfg.count}, including ZERO, when the source does not contain enough strong standalone moments.
NEVER invent or pad weak clips merely to hit a quota.

CONTENT PROFILE
- Profile: {cfg.profile}
- {_profile_guidance(cfg.profile)}

QUALITY GATE
- start_index/end_index MUST be the zero-based integers in the FIRST transcript column.
- Valid inclusive boundaries: 0 <= start_index <= end_index <= {len(segments)-1}.
- Do NOT put timestamps (seconds), word indexes, or invented indexes in these fields.
- Return ONLY clips with editorial_score >= {min_score:.1f}/10.
- A viewer who never watched the source must understand the clip by itself.
- Require a strong hook/setup, meaningful development, and a clean payoff/concluding thought.
- Preferred duration: {cfg.preferred_min_seconds:.0f}-{cfg.preferred_max_seconds:.0f}s.
- Allowed duration: {cfg.min_seconds:.0f}-{cfg.max_seconds:.0f}s.
- Complete thought beats exact duration.
- Do not begin mid-thought or end before the payoff.
- Pairwise overlap must be <= {cfg.max_overlap_ratio:.0%} of the shorter clip.
{excluded}
Return JSON ONLY:
{{"clips":[{{"start_index":0,"end_index":0,"editorial_score":9.0,"title":"...","reason":"...","hook_summary":"..."}}]}}
If nothing clears the quality gate, return exactly: {{"clips":[]}}
{feedback}
FULL TRANSCRIPT (index|start_sec|end_sec|text):
{_transcript_lines(segments)}
""".strip()


def _tt_schema_up_to(count: int, segment_count: int | None = None) -> dict[str, Any]:
    index_schema: dict[str, Any] = {'type': 'integer', 'minimum': 0}
    if segment_count is not None:
        index_schema['maximum'] = max(0, int(segment_count) - 1)
    return {
        'type':'object',
        'properties':{
            'clips':{
                'type':'array','minItems':0,'maxItems':max(0,int(count)),
                'items':{
                    'type':'object',
                    'properties':{
                        'start_index':dict(index_schema),'end_index':dict(index_schema),
                        'editorial_score':{'type':'number'},'title':{'type':'string'},
                        'reason':{'type':'string'},'hook_summary':{'type':'string'},
                    },
                    'required':['start_index','end_index','editorial_score','title','reason','hook_summary'],
                },
            }
        },
        'required':['clips'],
    }


def _tt_call_model_up_to(
    prompt: str,
    model: str,
    temperature: float,
    api_key: str,
    count: int,
    request_timeout_ms: int,
    segment_count: int | None = None,
) -> str:
    try:
        from google import genai
        from google.genai import types
    except Exception as exc:
        raise RuntimeError('google-genai is required. Run: pip install -U google-genai') from exc
    client=genai.Client(
        api_key=api_key,
        http_options=types.HttpOptions(timeout=max(1_000, int(request_timeout_ms))),
    )
    try:
        response=client.models.generate_content(
            model=model,contents=prompt,
            config=types.GenerateContentConfig(
                temperature=temperature,response_mime_type='application/json',
                response_schema=_tt_schema_up_to(count, segment_count),
            ),
        )
    except (TypeError,AttributeError):
        response=client.models.generate_content(model=model,contents=prompt)
    return str(getattr(response,'text','') or '')


def _tt_validate_up_to(
    raw: dict[str, Any], segments: list[dict], cfg: SelectionConfig, *,
    min_score: float, excluded_ranges: list[dict] | None = None,
) -> tuple[list[dict], list[str]]:
    clips=raw.get('clips') if isinstance(raw,dict) else None
    if not isinstance(clips,list):
        return [],['Top-level clips is missing or not a list.']
    problems=[];validated=[]
    for pos,item in enumerate(clips,1):
        if not isinstance(item,dict):
            problems.append(f'clip {pos}: not an object');continue
        try: si=int(item['start_index']);ei=int(item['end_index'])
        except Exception:
            problems.append(f'clip {pos}: invalid start_index/end_index');continue
        if not (0<=si<=ei<len(segments)):
            problems.append(f'clip {pos}: indexes out of range ({si}, {ei}); use FIRST-column segment indexes 0..{len(segments)-1}, not seconds');continue
        start=float(segments[si]['start']);end=float(segments[ei]['end']);duration=end-start
        if duration < cfg.min_seconds-0.01 or duration > cfg.max_seconds+0.01:
            problems.append(f'clip {pos}: duration {duration:.1f}s outside allowed range');continue
        score=float(item.get('editorial_score') or 0.0)
        if score < float(min_score):
            # Low-score clips are intentionally dropped, not treated as a model error.
            continue
        text=' '.join(str(s.get('text','')).strip() for s in segments[si:ei+1]).strip()
        clip={
            'start':round(start,3),'end':round(end,3),'duration':round(duration,3),
            'start_index':si,'end_index':ei,'score':round(score,3),'editorial_score':round(score,3),
            'title':str(item.get('title','')).strip(),'reason':str(item.get('reason','')).strip(),
            'hook_summary':str(item.get('hook_summary','')).strip(),'text':text,
            'selector':'gemini_tt_quality',
        }
        if _tt_overlap_with_excluded(clip,excluded_ranges):
            continue
        if any(_overlap_ratio(clip,prior)>cfg.max_overlap_ratio for prior in validated):
            continue
        validated.append(clip)
    validated.sort(key=lambda x:x['editorial_score'],reverse=True)
    return validated[:max(0,int(cfg.count))],problems


def _tt_call_with_key_pool_up_to(prompt: str, cfg: SelectionConfig, pool: list[KeyEntry], preferred_index: int = 0, segment_count: int | None = None) -> tuple[str,int,str]:
    errors=[]
    order=list(range(preferred_index,len(pool)))+list(range(0,preferred_index))
    retries_per_key=max(0,int(cfg.transient_retries_per_key));base_backoff=max(0.0,float(cfg.transient_backoff_seconds))
    deadline=time.monotonic()+max(1.0,float(cfg.total_timeout_seconds))
    for model in _model_chain(cfg.model,cfg.model_fallbacks):
        print(f'      🧠 TT quality selector model → {model}')
        switch_model=False
        for idx in order:
            entry=pool[idx];label=f"{entry.alias} [{entry.fingerprint}]"+(' [PAID]' if entry.paid else '')
            print(f'      🔑 trying {label}')
            transient_try=0
            while True:
                try:
                    request_timeout_ms=_remaining_request_timeout_ms(cfg,deadline)
                    return _tt_call_model_up_to(
                        prompt,model,cfg.temperature,entry.value,cfg.count,request_timeout_ms,segment_count,
                    ),idx,model
                except Exception as exc:
                    if _is_model_unavailable_error(exc):
                        errors.append(f'{model}: {type(exc).__name__}: {exc}');switch_model=True;break
                    if _is_key_rotatable_error(exc):
                        errors.append(f'{model}/{entry.alias}: {type(exc).__name__}: {exc}');break
                    if _is_request_timeout_error(exc):
                        errors.append(f'{model}/{entry.alias}: {type(exc).__name__}: {exc}')
                        print(
                            f'      ⏱️ Gemini request timeout → rotate key ({entry.alias}); '
                            f'overall limit={float(cfg.total_timeout_seconds):g}s'
                        )
                        break
                    if _is_transient_service_error(exc):
                        errors.append(f'{model}/{entry.alias}: {type(exc).__name__}: {exc}')
                        if transient_try < retries_per_key:
                            delay=base_backoff*(2**transient_try);transient_try+=1
                            print(f'      ⏳ Gemini service busy → retry same key {transient_try}/{retries_per_key} in {delay:.0f}s')
                            if delay>0: time.sleep(delay)
                            continue
                        switch_model=True;break
                    raise
            if switch_model: break
        if switch_model: continue
    raise RuntimeError('Gemini TT quality selector failed across model/key fallbacks. '+' | '.join(errors[-6:]))


def select_candidates_up_to_with_gemini(
    segments: list[dict], cfg: SelectionConfig, *, min_score: float = 8.8,
    excluded_ranges: list[dict] | None = None,
) -> tuple[list[dict], dict]:
    """TT night-prep selector: 0..N strong clips, never quota-padding.

    Existing select_candidates_with_gemini() remains untouched for manual/test runs.
    """
    if not segments or int(cfg.count)<=0:
        return [],{}
    pool=resolve_api_keys(cfg.allow_paid_fallback)
    print('🔑 TT quality key pool: '+' → '.join(f"{e.alias}[{e.fingerprint}]"+('[PAID]' if e.paid else '') for e in pool))
    if not cfg.allow_paid_fallback: print('🛡️ TT quality paid fallback: DISABLED')
    feedback='';active_idx=0;proxy_state=_proxy_if_listening();last_structural=[]
    try:
        for attempt in range(1,max(1,cfg.max_attempts)+1):
            print(f'   ↳ TT variable selection attempt {attempt}/{cfg.max_attempts} | up_to={cfg.count} | min_score={min_score:.1f}')
            prompt=_tt_prompt_up_to(segments,cfg,min_score=min_score,excluded_ranges=excluded_ranges,validation_feedback=feedback)
            text,active_idx,used_model=_tt_call_with_key_pool_up_to(prompt,cfg,pool,preferred_index=active_idx,segment_count=len(segments))
            try:
                raw=_extract_json(text)
                chosen,problems=_tt_validate_up_to(raw,segments,cfg,min_score=min_score,excluded_ranges=excluded_ranges)
            except (ValueError, TypeError, KeyError) as exc:
                chosen=[]
                problems=[f'Invalid/empty selection JSON ({type(exc).__name__}); return only the required clips object.']
            last_structural=problems
            # A syntactically valid zero or partial list is an intentional quality result.
            if not problems or chosen:
                entry=pool[active_idx]
                return chosen,{
                    'key_alias':entry.alias,'key_source':entry.source,'key_fingerprint':entry.fingerprint,
                    'paid_key_used':entry.paid,'model_used':used_model,'quality_mode':'up_to_n','min_score':float(min_score),
                }
            feedback='\n'.join(f'- {p}' for p in problems[:20])
            print('⚠️ TT AI selection needs repair: ' + ' | '.join(problems[:8]))
            active_idx=(active_idx+1)%len(pool)
        if last_structural:
            raise RuntimeError('Gemini TT quality selector returned structurally invalid clips. '+ ' | '.join(last_structural[:8]))
        return [],{}
    finally:
        _restore_proxy(proxy_state)
