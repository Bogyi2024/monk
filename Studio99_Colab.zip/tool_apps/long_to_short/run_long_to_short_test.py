from __future__ import annotations

import gc
import json
import os
import sys
from datetime import datetime
from pathlib import Path

from services.media_probe import probe
from services.transcript_service import transcribe
from services.gemini_moment_selector import SelectionConfig, select_candidates_with_gemini
from services.boundary_refiner import refine_candidate_boundaries
from services.subtitle_service import write_subtitles
from services.clip_exporter import export_center_crop
from services.commentary_service import CommentaryConfig, generate_commentary_packages
from services.social_metadata_service import SocialMetadataConfig, generate_social_metadata
from services.gemini_tts_service import synthesize_cached, synthesize_chunked_cached, stretch_wav_min_duration_cached
from services.mm_subtitle_overlay import (
    render_mm_png_events, render_subtitle_png_events, prepare_framed_base_video,
    render_commentary_video, render_original_audio_video
)
from services.original_audio_mm_service import (
    OriginalMMConfig, build_original_english_events, attach_myanmar
)
from services.voiceover_alignment_service import (
    VoiceoverAligner, build_spoken_mm_events_from_voiceover, enforce_complete_spoken_ending,
    build_english_events_from_voiceover, attach_spoken_myanmar_to_english_events, narration_coverage
)
from services.smart_framing_service import analyze_clip_framing

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parents[1] / "app"))
from lts_options import normalize_export_options, export_config, apply_source_geometry

EXPORT_OPTIONS = normalize_export_options(**json.loads(os.getenv("LTS_EXPORT_OPTIONS") or "{}"))
CFG = json.loads((ROOT / "config/config.json").read_text(encoding="utf-8"))
CFG = export_config(CFG, EXPORT_OPTIONS)
SUBTITLES_ENABLED = EXPORT_OPTIONS["subtitles_enabled"]
LTS_CONTENT_PROFILE = str(os.getenv("LTS_CONTENT_PROFILE") or "generic").strip().lower().replace("-", "_") or "generic"
ALL_OUTPUT_MODES = {
    "transformative_envo_mm", "original_audio_mm",
    "transformative_envo_en", "original_audio_en",
}
_raw_output_modes = str(os.getenv("LTS_OUTPUT_MODES") or "").strip()
LTS_OUTPUT_MODES = {
    mode.strip() for mode in _raw_output_modes.split(",") if mode.strip() in ALL_OUTPUT_MODES
} if _raw_output_modes else set(ALL_OUTPUT_MODES)
WANT_ENVO_MM = "transformative_envo_mm" in LTS_OUTPUT_MODES
WANT_ENVO_EN = "transformative_envo_en" in LTS_OUTPUT_MODES
WANT_ORIGINAL_MM = "original_audio_mm" in LTS_OUTPUT_MODES
WANT_ORIGINAL_EN = "original_audio_en" in LTS_OUTPUT_MODES



def _matching_cached_transcript(src: Path, meta: dict) -> tuple[dict | None, Path | None]:
    if not bool(CFG.get("reuse_matching_transcript", True)):
        return None, None
    outputs = ROOT / "outputs"
    if not outputs.exists():
        return None, None
    src_size = int(src.stat().st_size)
    src_duration = float(meta.get("duration", 0.0))
    for folder in sorted((p for p in outputs.iterdir() if p.is_dir()), key=lambda p: p.name, reverse=True):
        media_path = folder / "media.json"
        transcript_path = folder / "transcript.json"
        if not media_path.exists() or not transcript_path.exists():
            continue
        try:
            old_meta = json.loads(media_path.read_text(encoding="utf-8"))
            if int(old_meta.get("size", -1)) != src_size:
                continue
            if abs(float(old_meta.get("duration", -9999)) - src_duration) > 0.75:
                continue
            tr = json.loads(transcript_path.read_text(encoding="utf-8"))
            if tr.get("segments"):
                return tr, transcript_path
        except Exception:
            continue
    return None, None




def _matching_cached_gemini_candidates(src: Path, meta: dict, count: int, profile: str = "generic") -> tuple[list[dict] | None, Path | None, dict | None]:
    """Reuse a prior successful Gemini selection for the exact same source.

    This makes reruns (subtitle/style/boundary changes) zero-cost and avoids
    re-hitting Gemini when the service is temporarily busy.
    """
    if not bool(CFG.get("reuse_matching_gemini_candidates", True)):
        return None, None, None
    outputs = ROOT / "outputs"
    if not outputs.exists():
        return None, None, None
    src_size = int(src.stat().st_size)
    src_duration = float(meta.get("duration", 0.0))
    for folder in sorted((p for p in outputs.iterdir() if p.is_dir()), key=lambda p: p.name, reverse=True):
        media_path = folder / "media.json"
        candidates_path = folder / "candidates.json"
        manifest_path = folder / "run_manifest.json"
        if not media_path.exists() or not candidates_path.exists():
            continue
        try:
            old_meta = json.loads(media_path.read_text(encoding="utf-8"))
            if int(old_meta.get("size", -1)) != src_size:
                continue
            if abs(float(old_meta.get("duration", -9999)) - src_duration) > 0.75:
                continue
            cands = json.loads(candidates_path.read_text(encoding="utf-8"))
            if not isinstance(cands, list) or len(cands) < count:
                continue
            chosen = cands[:count]
            if any(not float(CFG.get("clip_min_seconds", 70)) - .05 <= float(c["end"]) - float(c["start"])
                       <= float(CFG.get("clip_max_seconds", 150)) + .05 for c in chosen):
                continue
            if not all(str(c.get("selector", "")).lower().startswith("gemini") for c in chosen):
                continue
            manifest = {}
            if manifest_path.exists():
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            cached_profile = str(manifest.get("content_profile") or manifest.get("selector_profile") or "generic").strip().lower().replace("-", "_")
            requested_profile = str(profile or "generic").strip().lower().replace("-", "_")
            # Legacy/manual candidate caches are compatible with Motivation only.
            if cached_profile == "generic" and requested_profile == "motivation":
                pass
            elif cached_profile != requested_profile:
                continue
            return chosen, candidates_path, manifest
        except Exception:
            continue
    return None, None, None


def _candidate_framing(src, candidate):
    frame = dict(CFG.get("video_framing") or {})
    if str(frame.get("mode", "auto_safe")).lower() == "auto_safe":
        return analyze_clip_framing(
            src, float(candidate["start"]), float(candidate["end"]),
            sample_count=int(frame.get("sample_count", 14)), detection_width=int(frame.get("detection_width", 640)),
            sample_interval_seconds=float(frame.get("sample_interval_seconds", 1.5)),
            max_samples=int(frame.get("max_samples", 96)), no_face_hold_seconds=float(frame.get("no_face_hold_seconds", 1)),
            face_hold_seconds=float(frame.get("face_hold_seconds", .55)),
            yunet_model_path=str(ROOT / str(frame.get("yunet_model", "models/face_detection_yunet_2023mar.onnx"))),
            yunet_score_threshold=float(frame.get("yunet_score_threshold", .88)),
        )
    return {"mode": str(frame.get("mode") or "center_crop"), "center_x": .5, "reason": "configured"}


def _export_clean_originals(src, candidates, out, meta, selector_meta):
    """CapCut handoff: selected source clips, with no new caption/TTS generation."""
    rows = []
    width, height, fps = int(CFG["target_width"]), int(CFG["target_height"]), int(CFG.get("fps", 30))
    for index, candidate in enumerate(candidates, 1):
        framed = out / f"candidate_{index:02d}._framed_base.mp4"
        framing = _candidate_framing(src, candidate)
        prepare_framed_base_video(src, framed, source_start=float(candidate["start"]),
                                  source_end=float(candidate["end"]), framing=framing,
                                  target_width=width, target_height=height, fps=fps)
        row = {"index": index, "source_start": candidate["start"], "source_end": candidate["end"],
               "title": candidate.get("title") or f"Clip {index}", "video_framing": framing,
               "final_video": None, "transformative_envo_en_video": None,
               "original_audio_mm_video": None, "original_audio_en_video": None,
               "original_audio_mm_subtitle_count": 0, "original_audio_en_subtitle_count": 0}
        for enabled, tag, field in ((WANT_ORIGINAL_MM, "ORIGINAL_AUDIO_MM", "original_audio_mm_video"),
                                    (WANT_ORIGINAL_EN, "ORIGINAL_AUDIO_EN", "original_audio_en_video")):
            if enabled:
                target = out / f"candidate_{index:02d}_{tag}.mp4"
                render_original_audio_video(framed, src, target, source_start=float(candidate["start"]),
                                            source_end=float(candidate["end"]), subtitle_png_events=[],
                                            target_width=width, target_height=height, fps=fps)
                row[field] = str(target)
                print(f"       ✅ Original audio, subtitles OFF → {target.name}")
        framed.unlink(missing_ok=True)
        rows.append(row)
    manifest = {"version": "studio99_export_options_v1", "source": str(src),
                "source_size": int(src.stat().st_size), "source_duration": float(meta["duration"]),
                "content_profile": LTS_CONTENT_PROFILE, "requested_output_modes": sorted(LTS_OUTPUT_MODES),
                "export_options": EXPORT_OPTIONS, "candidate_count": len(candidates), "gemini_key": selector_meta,
                "transformative_commentary": False, "source_audio_in_final": True, "finals": rows}
    (out / "run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"✅ DONE → {out}")


def main():
    if len(sys.argv) < 2:
        print("Usage: python run_long_to_short_test.py <video.mp4>")
        raise SystemExit(2)
    src = Path(sys.argv[1]).resolve()
    if not src.exists():
        raise FileNotFoundError(src)

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = ROOT / "outputs" / run_id
    out.mkdir(parents=True, exist_ok=True)

    print(f"🎬 LONG-TO-SHORT V0.3.9 Four-Route Render → {src.name}")
    print(f"🗂️ Content profile: {LTS_CONTENT_PROFILE}")
    meta = probe(src)
    apply_source_geometry(CFG, meta)
    if EXPORT_OPTIONS["clip_minutes"] is not None and float(meta["duration"]) < CFG["clip_min_seconds"]:
        raise ValueError("မူရင်း video က ရွေးထားတဲ့ clip အရှည်ထက် တိုနေပါတယ်။ မိနစ်ကို လျှော့ရွေးပါ။")
    (out / "media.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"⏱️ Source duration: {meta['duration']:.1f}s")
    print(f"🎞️ Output: {EXPORT_OPTIONS['output_ratio']} {CFG['target_width']}x{CFG['target_height']} | subtitles={'ON' if SUBTITLES_ENABLED else 'OFF'}")

    tr, cached_from = _matching_cached_transcript(src, meta)
    if tr is not None:
        word_ts = any(bool(s.get("words")) for s in tr.get("segments", []))
        print(f"♻️ Reusing matching Whisper transcript → {cached_from.parent.name} ({len(tr['segments'])} segments, word_ts={'yes' if word_ts else 'compat'})")
    else:
        tr = transcribe(src, CFG["whisper_model"], CFG["whisper_device"], CFG["whisper_compute_type"])
    (out / "transcript.json").write_text(json.dumps(tr, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"📝 Whisper: {len(tr['segments'])} segments | language={tr.get('language')}")

    if not bool(CFG.get("gemini_enabled", True)):
        raise RuntimeError("This build requires gemini_enabled=true; Gemini is the final editorial decision layer.")

    scfg = SelectionConfig(
        count=max(1, int(os.getenv("LTS_CANDIDATE_COUNT", str(CFG.get("candidate_count", 5))) or CFG.get("candidate_count", 5))),
        min_seconds=float(CFG.get("clip_min_seconds", 70)),
        preferred_min_seconds=float(CFG.get("clip_preferred_min_seconds", 90)),
        preferred_max_seconds=float(CFG.get("clip_preferred_max_seconds", 130)),
        max_seconds=float(CFG.get("clip_max_seconds", 150)),
        max_overlap_ratio=float(CFG.get("max_pairwise_overlap_ratio", 0.25)),
        model=str(CFG.get("gemini_model", "gemini-3.5-flash")),
        model_fallbacks=tuple(CFG.get("gemini_model_fallbacks") or ["gemini-3.5-flash-lite"]),
        temperature=float(CFG.get("gemini_temperature", 0.25)),
        max_attempts=int(CFG.get("gemini_max_attempts", 2)),
        allow_paid_fallback=bool(CFG.get("gemini_allow_paid_fallback", False)),
        transient_retries_per_key=int(CFG.get("gemini_transient_retries_per_key", 1)),
        transient_backoff_seconds=float(CFG.get("gemini_transient_backoff_seconds", 4.0)),
        request_timeout_ms=int(CFG.get("gemini_request_timeout_ms", 120000)),
        total_timeout_seconds=float(CFG.get("gemini_total_timeout_seconds", 360.0)),
        profile=LTS_CONTENT_PROFILE,
    )

    cands, cached_candidates_from, cached_manifest = _matching_cached_gemini_candidates(
        src, meta, scfg.count, LTS_CONTENT_PROFILE
    )
    if cands is not None:
        print(f"♻️ Reusing matching Gemini candidates → {cached_candidates_from.parent.name} (0 API calls)")
        key_meta = {
            "key_alias": "cached_selection",
            "key_source": str(cached_candidates_from),
            "key_fingerprint": None,
            "paid_key_used": bool((cached_manifest or {}).get("gemini_key", {}).get("paid_key_used", False)),
        }
    else:
        cands, key_meta = select_candidates_with_gemini(tr["segments"], scfg)

    cands = refine_candidate_boundaries(
        cands,
        tr["segments"],
        min_seconds=scfg.min_seconds,
        max_seconds=scfg.max_seconds,
    )
    (out / "candidates.json").write_text(json.dumps(cands, ensure_ascii=False, indent=2), encoding="utf-8")
    if not SUBTITLES_ENABLED and not (WANT_ENVO_MM or WANT_ENVO_EN):
        _export_clean_originals(src, cands, out, meta, key_meta)
        return

    # ------------------------------------------------------------------
    # Transformative layer: original English analysis/commentary + Gemini TTS
    # + Myanmar translation rendered as Unicode-safe transparent PNG overlays.
    # Source interview audio is NOT used in the final commentary render.
    # ------------------------------------------------------------------
    ccfg_raw = dict(CFG.get("commentary") or {})
    ccfg = CommentaryConfig(
        model=str(ccfg_raw.get("model", "gemini-3.5-flash")),
        model_fallbacks=tuple(ccfg_raw.get("model_fallbacks") or ["gemini-3.5-flash-lite"]),
        temperature=float(ccfg_raw.get("temperature", 0.35)),
        min_segments=int(ccfg_raw.get("min_segments", 12)),
        max_segments=int(ccfg_raw.get("max_segments", 16)),
        target_words_min=int(ccfg_raw.get("target_words_min", 180)),
        target_words_max=int(ccfg_raw.get("target_words_max", 230)),
        allow_paid_fallback=bool(ccfg_raw.get("allow_paid_fallback", False)),
        retries_per_key=int(ccfg_raw.get("retries_per_key", 1)),
        backoff_seconds=float(ccfg_raw.get("backoff_seconds", 4.0)),
        profile=LTS_CONTENT_PROFILE,
        reuse_compatible_cache=bool(ccfg_raw.get("reuse_compatible_cache", True)) and LTS_CONTENT_PROFILE in {"generic", "motivation"},
    )
    packages, commentary_key_meta = generate_commentary_packages(cands, ccfg)
    social_raw = dict(CFG.get("social_metadata") or {})
    social_cfg = SocialMetadataConfig(
        enabled=bool(social_raw.get("enabled", True)),
        model=str(social_raw.get("model", "gemini-3.5-flash")),
        model_fallbacks=tuple(social_raw.get("model_fallbacks") or ["gemini-3.5-flash-lite"]),
        temperature=float(social_raw.get("temperature", 0.55)),
        hashtag_limit=int(social_raw.get("hashtag_limit", 6)),
        allow_paid_fallback=bool(social_raw.get("allow_paid_fallback", False)),
        retries_per_key=int(social_raw.get("retries_per_key", 1)),
        backoff_seconds=float(social_raw.get("backoff_seconds", 4.0)),
        reuse_cache=bool(social_raw.get("reuse_cache", True)),
    )
    social_rows, social_key_meta = generate_social_metadata(cands, packages, social_cfg)

    # Shared SPOKEN Myanmar translation config. V0.3.4 deliberately ignores
    # the old paragraph-style Myanmar text stored in commentary packages.
    omm_raw = dict(CFG.get("original_audio_mm") or {})
    ommcfg = OriginalMMConfig(
        enabled=bool(omm_raw.get("enabled", True)),
        model=str(omm_raw.get("model", "gemini-3.5-flash")),
        model_fallbacks=tuple(omm_raw.get("model_fallbacks") or ["gemini-3.5-flash-lite"]),
        temperature=float(omm_raw.get("temperature", 0.15)),
        allow_paid_fallback=bool(omm_raw.get("allow_paid_fallback", False)),
        retries_per_key=int(omm_raw.get("retries_per_key", 1)),
        backoff_seconds=float(omm_raw.get("backoff_seconds", 4.0)),
        max_words_per_event=int(omm_raw.get("max_words_per_event", 10)),
        max_seconds_per_event=float(omm_raw.get("max_seconds_per_event", 4.0)),
    )
    (out / "commentary_packages.json").write_text(
        json.dumps({"clips": packages}, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    ttscfg = dict(CFG.get("english_voiceover") or {})
    mmcfg = dict(CFG.get("myanmar_subtitle") or {})
    aligncfg = dict(CFG.get("voiceover_subtitle_alignment") or {})
    framecfg = dict(CFG.get("video_framing") or {})
    aligner = VoiceoverAligner(
        model_name=str(aligncfg.get("whisper_model", CFG.get("whisper_model", "medium"))),
        device=str(aligncfg.get("device", CFG.get("whisper_device", "cuda"))),
        compute_type=str(aligncfg.get("compute_type", CFG.get("whisper_compute_type", "float16"))),
    )
    final_rows = []
    print(f"🎯 Building {len(cands)} transformative commentary clips:")
    for idx, (c, package, social) in enumerate(zip(cands, packages, social_rows), 1):
        title = social.get("title") or c.get("title") or package.get("title") or "Untitled"
        print(f"  • #{idx} {title}")
        print(f"       Source: {c['start']:.1f}-{c['end']:.1f}s | editorial_score={c['editorial_score']:.1f}")
        print(f"       Commentary: {package.get('word_count', 0)} English words / {len(package['segments'])} EN beats")

        framing = _candidate_framing(src, c)
        seg_count = len(framing.get("segments") or [])
        blur_s = float(framing.get("blur_seconds", 0.0) or 0.0)
        print(f"       🎥 Framing: {framing.get('mode')} | {framing.get('reason')} | segments={seg_count} | blur={blur_s:.1f}s")

        # Keep an optional raw source clip for inspection/reference. It is NOT
        # the publish-target output because its original audio remains reused content.
        raw_path = out / f"candidate_{idx:02d}_source.mp4"
        if bool(CFG.get("export_source_reference_clips", False)):
            export_center_crop(
                src, raw_path, c["start"], c["end"],
                CFG["target_width"], CFG["target_height"], CFG["fps"],
                subtitle_ass=None,
            )
            print(f"       🎞️ source reference → {raw_path.name}")

        tts_kwargs = dict(
            model=str(ttscfg.get("model", "gemini-3.1-flash-tts-preview")),
            model_fallbacks=tuple(ttscfg.get("model_fallbacks") or ["gemini-2.5-flash-preview-tts"]),
            voice=str(ttscfg.get("voice", "Charon")),
            allow_paid_fallback=bool(ttscfg.get("allow_paid_fallback", False)),
            retries_per_key=int(ttscfg.get("retries_per_key", 2)),
            backoff_seconds=float(ttscfg.get("backoff_seconds", 3.0)),
            use_streaming=bool(ttscfg.get("use_streaming", True)),
            timeout_ms=int(ttscfg.get("timeout_ms", 180000)),
            direct_fallback_after_proxy_disconnect=bool(ttscfg.get("direct_fallback_after_proxy_disconnect", True)),
        )
        voice_wav, tts_meta = synthesize_cached(package["english_voiceover"], **tts_kwargs)
        voice_copy = out / f"candidate_{idx:02d}.en_vo.wav"
        voice_copy.write_bytes(Path(voice_wav).read_bytes())
        vo_duration = float(tts_meta["duration"])

        # V0.3.7 completeness QA happens BEFORE Myanmar translation.  The old
        # one-shot Gemini TTS cache may contain a valid WAV that silently stops
        # before reading all 15 commentary beats. Local Whisper proves what was
        # actually spoken; only an incomplete narration triggers extra TTS calls.
        en_vo_events, align_meta = build_english_events_from_voiceover(
            aligner,
            voice_copy,
            max_words=int(aligncfg.get("max_words", 8)),
            max_seconds=float(aligncfg.get("max_seconds", 3.2)),
        )
        coverage_meta = narration_coverage(package["english_voiceover"], en_vo_events)
        min_cov = float(ttscfg.get("min_alignment_coverage", 0.92))
        min_tail = float(ttscfg.get("min_tail_similarity", 0.55))
        incomplete = (
            float(coverage_meta.get("coverage", 0.0)) < min_cov
            or float(coverage_meta.get("tail_similarity", 0.0)) < min_tail
        )
        # V0.3.8 continuity policy: never jump straight from an incomplete
        # one-shot narration to chunked TTS. First make fresh FULL-SCRIPT
        # attempts with the same Charon voice. A complete full-script take has
        # one acoustic identity and avoids the audible voice seam users heard
        # around chunk boundaries in V0.3.7. Each retry has a distinct cache
        # variant, so an old incomplete WAV cannot short-circuit the retry.
        if incomplete:
            initial_one_shot_meta = dict(tts_meta)
            full_retry_attempts = max(0, int(ttscfg.get("full_script_retry_attempts", 2)))
            for full_try in range(1, full_retry_attempts + 1):
                # Retry #1 keeps the proven streaming transport. Retry #2 can
                # optionally use non-streaming as a second full-script path.
                retry_kwargs = dict(tts_kwargs)
                if full_try >= 2 and bool(ttscfg.get("full_script_second_retry_nonstream", True)):
                    retry_kwargs["use_streaming"] = False
                print(
                    f"       🎙️ TTS incomplete: coverage={coverage_meta.get('coverage', 0):.1%} "
                    f"tail={coverage_meta.get('tail_similarity', 0):.1%} → FULL-SCRIPT Charon retry {full_try}/{full_retry_attempts}"
                )
                retry_wav, retry_meta = synthesize_cached(
                    package["english_voiceover"],
                    **retry_kwargs,
                    cache_variant=f"one_voice_full_retry_v1_{full_try}",
                )
                voice_copy.write_bytes(Path(retry_wav).read_bytes())
                vo_duration = float(retry_meta["duration"])
                en_vo_events, align_meta = build_english_events_from_voiceover(
                    aligner,
                    voice_copy,
                    max_words=int(aligncfg.get("max_words", 8)),
                    max_seconds=float(aligncfg.get("max_seconds", 3.2)),
                )
                coverage_meta = narration_coverage(package["english_voiceover"], en_vo_events)
                incomplete = (
                    float(coverage_meta.get("coverage", 0.0)) < min_cov
                    or float(coverage_meta.get("tail_similarity", 0.0)) < min_tail
                )
                print(
                    f"       {'✅' if not incomplete else '⚠️'} Full-script retry check: "
                    f"coverage={coverage_meta.get('coverage', 0):.1%} "
                    f"tail={coverage_meta.get('tail_similarity', 0):.1%} | {vo_duration:.1f}s"
                )
                tts_meta = {
                    **retry_meta,
                    "strategy": "one_voice_full_script_retry_v1",
                    "full_script_retry_index": full_try,
                    "initial_one_shot_meta": initial_one_shot_meta,
                }
                if not incomplete:
                    break

        # Emergency-only fallback. This is intentionally last because separate
        # Gemini generations can vary slightly in timbre even with the same
        # prebuilt voice. It exists for completeness, not as the normal path.
        if bool(ttscfg.get("chunked_fallback_enabled", True)) and incomplete:
            print(
                f"       🧩 Full-script retries still incomplete: coverage={coverage_meta.get('coverage', 0):.1%} "
                f"tail={coverage_meta.get('tail_similarity', 0):.1%} → emergency chunk fallback"
            )
            pre_chunk_meta = dict(tts_meta)
            chunk_wav, chunk_meta = synthesize_chunked_cached(
                [str(x.get("en") or "") for x in package.get("segments", [])],
                **tts_kwargs,
                chunk_max_words=int(ttscfg.get("chunk_max_words", 68)),
                pause_ms=int(ttscfg.get("chunk_pause_ms", 100)),
            )
            voice_copy.write_bytes(Path(chunk_wav).read_bytes())
            vo_duration = float(chunk_meta["duration"])
            tts_meta = {
                **chunk_meta,
                "strategy": "emergency_chunk_fallback_v2",
                "full_script_attempts_exhausted": True,
                "pre_chunk_meta": pre_chunk_meta,
            }
            en_vo_events, align_meta = build_english_events_from_voiceover(
                aligner,
                voice_copy,
                max_words=int(aligncfg.get("max_words", 8)),
                max_seconds=float(aligncfg.get("max_seconds", 3.2)),
            )
            coverage_meta = narration_coverage(package["english_voiceover"], en_vo_events)
            incomplete = (
                float(coverage_meta.get("coverage", 0.0)) < min_cov
                or float(coverage_meta.get("tail_similarity", 0.0)) < min_tail
            )
            print(
                f"       ✅ Emergency TTS recheck: coverage={coverage_meta.get('coverage', 0):.1%} "
                f"tail={coverage_meta.get('tail_similarity', 0):.1%} | {vo_duration:.1f}s"
            )
            if incomplete and bool(ttscfg.get("fail_if_still_incomplete", True)):
                raise RuntimeError(
                    f"Narrator TTS is still incomplete after full-script retries and emergency chunk fallback "
                    f"(coverage={coverage_meta.get('coverage')}, tail={coverage_meta.get('tail_similarity')})"
                )

        # Guarantee that publish-target commentary is not an accidental sub-60s
        # short. If the COMPLETE narration is only slightly fast, slow it locally;
        # no extra Gemini call is needed. This is capped to a 25% slowdown.
        min_publish = float(ttscfg.get("min_publish_seconds", 70.0))
        target_publish = float(ttscfg.get("target_publish_seconds", 72.0))
        if vo_duration < min_publish and not incomplete:
            paced_wav, pace_meta = stretch_wav_min_duration_cached(
                voice_copy,
                min_seconds=min_publish,
                target_seconds=target_publish,
            )
            if pace_meta.get("stretched"):
                voice_copy.write_bytes(Path(paced_wav).read_bytes())
                vo_duration = float(pace_meta["duration"])
                tts_meta = {**tts_meta, "local_pace_safeguard": pace_meta}
                en_vo_events, align_meta = build_english_events_from_voiceover(
                    aligner,
                    voice_copy,
                    max_words=int(aligncfg.get("max_words", 8)),
                    max_seconds=float(aligncfg.get("max_seconds", 3.2)),
                )
                coverage_meta = narration_coverage(package["english_voiceover"], en_vo_events)

        # Translate only the final, verified narrator events. This keeps Myanmar
        # subtitles locked to the audio that will actually be published.
        mm_events, trans_meta = (attach_spoken_myanmar_to_english_events(en_vo_events, ommcfg)
                                 if SUBTITLES_ENABLED and WANT_ENVO_MM else ([], {"skipped": True}))
        spoken_mm_meta = {
            "alignment": align_meta,
            "translation": trans_meta,
            "narration_coverage": coverage_meta,
            "tts_strategy": tts_meta.get("strategy", "one_shot"),
        }
        en_vo_events, mm_events, clean_vo_end, ending_meta = enforce_complete_spoken_ending(
            en_vo_events, mm_events, wav_duration=vo_duration,
            min_keep_ratio=float(aligncfg.get("complete_end_min_keep_ratio", 0.72)),
            tail_hold_seconds=float(aligncfg.get("complete_end_tail_hold_seconds", 0.18)),
        )
        if clean_vo_end < min_publish and float(c["end"]) - float(c["start"]) >= min_publish:
            raise RuntimeError(
                f"Publish-target narration fell below {min_publish:.0f}s after ending QA ({clean_vo_end:.2f}s); refusing short/incomplete output"
            )
        spoken_mm_meta["ending_guard"] = ending_meta
        if ending_meta.get("trimmed"):
            print(f"       ✂️ Clean-ending guard: {vo_duration:.2f}s → {clean_vo_end:.2f}s | dropped dangling narrator tail")
        elif ending_meta.get("reason") != "already_complete":
            print(f"       ⚠️ Clean-ending QA: {ending_meta.get('reason')}")
        (out / f"candidate_{idx:02d}.en_voice_alignment.json").write_text(
            json.dumps(en_vo_events, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        mm_json = out / f"candidate_{idx:02d}.mm_subtitles.json"
        mm_json.write_text(json.dumps(mm_events, ensure_ascii=False, indent=2), encoding="utf-8")
        png_dir = out / f"candidate_{idx:02d}_mm_png"
        png_events = render_mm_png_events(
            mm_events,
            png_dir,
            width=int(mmcfg.get("plate_width", 1040)),
            height=int(mmcfg.get("plate_height", 220)),
            font_size=int(mmcfg.get("font_size", 58)),
            min_font_size=int(mmcfg.get("min_font_size", 42)),
        ) if SUBTITLES_ENABLED and WANT_ENVO_MM else []
        en_vo_png_events = []
        if WANT_ENVO_EN and SUBTITLES_ENABLED:
            en_vo_png_dir = out / f"candidate_{idx:02d}_envo_en_png"
            en_vo_png_events = render_subtitle_png_events(
                en_vo_events,
                en_vo_png_dir,
                language="en",
                width=int(mmcfg.get("plate_width", 1040)),
                height=int(mmcfg.get("plate_height", 220)),
                font_size=int(mmcfg.get("font_size", 58)),
                min_font_size=int(mmcfg.get("min_font_size", 42)),
            )
        # Build portrait visual ONCE per candidate. Face-visible intervals stay
        # full-screen; only no-face intervals use fit+blur. The same base is
        # reused by all four output modes, avoiding duplicate heavy framing work.
        framed_base_path = out / f"candidate_{idx:02d}._framed_base.mp4"
        prepare_framed_base_video(
            src, framed_base_path,
            source_start=float(c["start"]),
            source_end=float(c["end"]),
            framing=framing,
            target_width=int(CFG.get("target_width", 1080)),
            target_height=int(CFG.get("target_height", 1920)),
            fps=int(CFG.get("fps", 30)),
        )

        final_path = None
        print(f"       🎙️ EN voiceover: {vo_duration:.1f}s | {ttscfg.get('voice', 'Charon')}")
        if WANT_ENVO_MM:
            final_path = out / f"candidate_{idx:02d}_FINAL_ENVO_MM.mp4"
            render_commentary_video(
                framed_base_path,
                final_path,
                voice_wav=voice_copy,
                subtitle_png_events=png_events,
                source_duration=max(0.1, float(c["end"]) - float(c["start"])),
                target_width=int(CFG.get("target_width", 1080)),
                target_height=int(CFG.get("target_height", 1920)),
                fps=int(CFG.get("fps", 30)),
                subtitle_y_fraction=float(mmcfg.get("y_fraction", 0.79)),
                voice_end_seconds=clean_vo_end,
            )
            print(f"       🇲🇲 Spoken MM captions: {len(png_events)} | narrator-word aligned → {png_dir.name}")
            print(f"       ✅ {final_path.name}")
        envo_en_path = None
        if WANT_ENVO_EN:
            envo_en_path = out / f"candidate_{idx:02d}_FINAL_ENVO_EN.mp4"
            render_commentary_video(
                framed_base_path,
                envo_en_path,
                voice_wav=voice_copy,
                subtitle_png_events=en_vo_png_events,
                source_duration=max(0.1, float(c["end"]) - float(c["start"])),
                target_width=int(CFG.get("target_width", 1080)),
                target_height=int(CFG.get("target_height", 1920)),
                fps=int(CFG.get("fps", 30)),
                subtitle_y_fraction=float(mmcfg.get("y_fraction", 0.79)),
                voice_end_seconds=clean_vo_end,
            )
            print(f"       🇬🇧 Voiceover + English subtitles: {len(en_vo_png_events)} → {envo_en_path.name}")
        original_mm_meta = None
        original_mm_count = 0
        original_mm_path = None
        original_mm_error = None
        original_en_count = 0
        original_en_path = None
        original_en_error = None
        if not SUBTITLES_ENABLED:
            for enabled, tag in ((WANT_ORIGINAL_MM, "MM"), (WANT_ORIGINAL_EN, "EN")):
                if enabled:
                    target = out / f"candidate_{idx:02d}_ORIGINAL_AUDIO_{tag}.mp4"
                    render_original_audio_video(framed_base_path, src, target,
                                                source_start=float(c["start"]), source_end=float(c["end"]),
                                                subtitle_png_events=[], target_width=int(CFG["target_width"]),
                                                target_height=int(CFG["target_height"]), fps=int(CFG.get("fps", 30)))
                    if tag == "MM": original_mm_path = target
                    else: original_en_path = target
        if SUBTITLES_ENABLED and ommcfg.enabled and (WANT_ORIGINAL_MM or WANT_ORIGINAL_EN):
            try:
                en_source_events = build_original_english_events(
                    c, tr["segments"],
                    max_words=ommcfg.max_words_per_event,
                    max_seconds=ommcfg.max_seconds_per_event,
                )
                original_en_json = out / f"candidate_{idx:02d}.original_en_subtitles.json"
                original_en_json.write_text(json.dumps(en_source_events, ensure_ascii=False, indent=2), encoding="utf-8")
                if WANT_ORIGINAL_EN:
                    original_en_png_dir = out / f"candidate_{idx:02d}_original_en_png"
                    original_en_png_events = render_subtitle_png_events(
                        en_source_events,
                        original_en_png_dir,
                        language="en",
                        width=int(mmcfg.get("plate_width", 1040)),
                        height=int(mmcfg.get("plate_height", 220)),
                        font_size=int(mmcfg.get("font_size", 58)),
                        min_font_size=int(mmcfg.get("min_font_size", 42)),
                    )
                    original_en_path = out / f"candidate_{idx:02d}_ORIGINAL_AUDIO_EN.mp4"
                    render_original_audio_video(
                        framed_base_path, src, original_en_path,
                        source_start=float(c["start"]),
                        source_end=float(c["end"]),
                        subtitle_png_events=original_en_png_events,
                        target_width=int(CFG.get("target_width", 1080)),
                        target_height=int(CFG.get("target_height", 1920)),
                        fps=int(CFG.get("fps", 30)),
                        subtitle_y_fraction=float(mmcfg.get("y_fraction", 0.79)),
                    )
                    original_en_count = len(en_source_events)
                    print(f"       🎧 Original audio + English subtitles: {original_en_count} → {original_en_path.name}")
            except Exception as exc:
                original_en_error = f"{type(exc).__name__}: {exc}"
                if original_en_path and original_en_path.exists():
                    try:
                        original_en_path.unlink()
                    except OSError:
                        pass
                en_source_events = []
                print(f"       ⚠️ ORIGINAL_AUDIO_EN failed; continuing batch → {type(exc).__name__}: {str(exc)[-260:]}")

            try:
                if not WANT_ORIGINAL_MM:
                    raise StopIteration
                if not en_source_events:
                    raise RuntimeError("English source subtitle events were unavailable")
                original_mm_events, original_mm_meta = attach_myanmar(en_source_events, ommcfg)
                original_mm_json = out / f"candidate_{idx:02d}.original_mm_subtitles.json"
                original_mm_json.write_text(json.dumps(original_mm_events, ensure_ascii=False, indent=2), encoding="utf-8")
                original_png_dir = out / f"candidate_{idx:02d}_original_mm_png"
                original_png_events = render_mm_png_events(
                    original_mm_events,
                    original_png_dir,
                    width=int(mmcfg.get("plate_width", 1040)),
                    height=int(mmcfg.get("plate_height", 220)),
                    font_size=int(mmcfg.get("font_size", 58)),
                    min_font_size=int(mmcfg.get("min_font_size", 42)),
                )
                original_mm_path = out / f"candidate_{idx:02d}_ORIGINAL_AUDIO_MM.mp4"
                render_original_audio_video(
                    framed_base_path, src, original_mm_path,
                    source_start=float(c["start"]),
                    source_end=float(c["end"]),
                    subtitle_png_events=original_png_events,
                    target_width=int(CFG.get("target_width", 1080)),
                    target_height=int(CFG.get("target_height", 1920)),
                    fps=int(CFG.get("fps", 30)),
                    subtitle_y_fraction=float(mmcfg.get("y_fraction", 0.79)),
                )
                original_mm_count = len(original_mm_events)
                print(f"       🎧 Original audio + MM subtitles: {original_mm_count} → {original_mm_path.name}")
            except StopIteration:
                pass
            except Exception as exc:
                # Secondary output must never kill the 5-candidate primary batch.
                original_mm_error = f"{type(exc).__name__}: {exc}"
                if original_mm_path and original_mm_path.exists():
                    try:
                        original_mm_path.unlink()
                    except OSError:
                        pass
                print(f"       ⚠️ ORIGINAL_AUDIO_MM failed; continuing batch → {type(exc).__name__}: {str(exc)[-260:]}")

        # The framed intermediate is intentionally temporary. All four outputs have
        # already consumed it, so release disk/handles before the next candidate.
        try:
            framed_base_path.unlink(missing_ok=True)
        except OSError:
            pass
        gc.collect()

        final_rows.append({
            "index": idx,
            "source_start": c["start"],
            "source_end": c["end"],
            "title": title,
            "hook": social.get("hook") or "",
            "fb_caption": social.get("fb_caption") or title,
            "tt_caption": social.get("tt_caption") or title,
            "hashtags": list(social.get("hashtags") or []),
            "commentary_words": package.get("word_count"),
            "voiceover_duration": vo_duration,
            "effective_voiceover_duration": clean_vo_end,
            "voiceover_ending_guard": ending_meta,
            "video_framing": framing,
            "tts": tts_meta,
            "myanmar_subtitle_count": len(mm_events),
            "myanmar_subtitle_mode": "spoken_mm_from_actual_tts_whisper_words",
            "myanmar_subtitle_meta": spoken_mm_meta,
            "final_video": str(final_path) if final_path else None,
            "transformative_envo_en_video": str(envo_en_path) if envo_en_path else None,
            "original_audio_mm_video": str(original_mm_path) if original_mm_path else None,
            "original_audio_mm_subtitle_count": original_mm_count,
            "original_audio_mm_translation": original_mm_meta,
            "original_audio_mm_error": original_mm_error,
            "original_audio_en_video": str(original_en_path) if original_en_path else None,
            "original_audio_en_subtitle_count": original_en_count,
            "original_audio_en_error": original_en_error,
        })

    manifest = {
        "version": "0.3.9",
        "source": str(src),
        "content_profile": LTS_CONTENT_PROFILE,
        "requested_output_modes": sorted(LTS_OUTPUT_MODES),
        "export_options": EXPORT_OPTIONS,
        "source_size": int(src.stat().st_size),
        "source_duration": float(meta["duration"]),
        "transcript_reused_from": str(cached_from) if cached_from else None,
        "selector": "gemini_cached_or_full_transcript_editorial_free_pool",
        "gemini_candidates_reused_from": str(cached_candidates_from) if cached_candidates_from else None,
        "gemini_model": scfg.model,
        "gemini_key": key_meta,
        "candidate_count": len(cands),
        "boundary_refiner": "local_punctuation_subsegment_v1",
        "transformative_commentary": True,
        "commentary_model": ccfg.model,
        "commentary_model_fallbacks": list(ccfg.model_fallbacks),
        "commentary_key": commentary_key_meta,
        "social_metadata": social_key_meta,
        "myanmar_subtitle_style": "natural_spoken_burmese",
        "myanmar_subtitle_alignment": "local_faster_whisper_word_timestamps_on_tts",
        "voiceover_complete_ending_guard": True,
        "video_framing_mode": str(framecfg.get("mode", "auto_safe")),
        "original_audio_mm_enabled": ommcfg.enabled,
        "original_audio_mm_model": ommcfg.model,
        "original_audio_mm_model_fallbacks": list(ommcfg.model_fallbacks),
        "english_tts_model": str(ttscfg.get("model", "gemini-3.1-flash-tts-preview")),
        "english_tts_model_fallbacks": list(ttscfg.get("model_fallbacks") or ["gemini-2.5-flash-preview-tts"]),
        "english_tts_voice": str(ttscfg.get("voice", "Charon")),
        "source_audio_in_final": False,
        "myanmar_subtitle_renderer": "chromium_png_overlay",
        "finals": final_rows,
    }
    (out / "run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"✅ DONE → {out}")
    print("ℹ️ FINAL videos use original visuals + ORIGINAL English commentary narration; source interview audio is muted.")
    print("ℹ️ Myanmar subtitles translate the commentary and are rendered to transparent PNGs before FFmpeg overlay (no FFmpeg drawtext for Burmese).")
    print(f"ℹ️ Route-driven outputs generated: {', '.join(sorted(LTS_OUTPUT_MODES))}.")
    print("ℹ️ Myanmar subtitle style is conversational/spoken; old paragraph-style commentary MM is ignored.")
    print("ℹ️ Text tasks are pinned to Gemini 3.5 Flash first; paid fallback stays disabled.")
    print("ℹ️ Commentary/TTS/alignment/translation have persistent caches, so reruns avoid repeat work where possible.")
    print("ℹ️ One-voice TTS continuity, YuNet-first framing, memory-safe PNG overlays, and local TTS completeness QA remain enabled.")


if __name__ == "__main__":
    main()
