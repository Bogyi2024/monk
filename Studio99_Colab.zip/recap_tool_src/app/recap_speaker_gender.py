"""Gemini Audio speaker/gender listener for Studio99 Recap.

Listens to the original video audio in 10-minute chunks (cached per job) so the
Burmese translator knows whether each line is spoken by a Male, Female, or Narrator —
fixing Burmese pronoun mix-ups (ရှင် vs မင်း/ခင်ဗျား/နင်, ကျွန်တော် vs ကျွန်မ).
"""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any

CHUNK_SECONDS = 600.0
CACHE_VERSION = 1

LISTEN_PROMPT = """You are listening to the original audio of a video (may include BGM/SFX).
Below are the spoken lines in this audio chunk, each with its integer ID, relative time range, and transcript.
For EVERY line ID, determine who is speaking based on the VOICE you hear (timbre/resonance, not pitch alone) and story context:
- gender: "male", "female", "narrator" (if an off-screen storyteller/narrator is recapping), or "unsure".
- speaker: short role/name (e.g. "Father", "Girl", "Narrator", "Boss").
Speakers heard earlier in this video: {speakers}

Return JSON ONLY:
{{"lines": [{{"id": 1, "speaker": "Role", "gender": "male" | "female" | "narrator" | "unsure"}}]}}
Include every ID below exactly once.

LINES:
{lines}"""


def _clock(sec: float) -> str:
    sec = max(0.0, float(sec))
    return f"{int(sec // 60)}:{sec % 60:04.1f}"


def _chunks(units: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    groups: list[list[dict[str, Any]]] = []
    for u in sorted(units, key=lambda x: float(x.get("video_start", 0.0))):
        if groups and float(u.get("video_end", 0.0)) - float(groups[-1][0].get("video_start", 0.0)) <= CHUNK_SECONDS:
            groups[-1].append(u)
        else:
            groups.append([u])
    return groups


def _extract_chunk_mp3(ffmpeg: str, source: Path, start: float, duration: float, out_mp3: Path) -> bool:
    if out_mp3.is_file() and out_mp3.stat().st_size > 1000:
        return True
    out_mp3.parent.mkdir(parents=True, exist_ok=True)
    tmp = out_mp3.with_suffix(".part.mp3")
    cmd = [
        ffmpeg, "-y", "-v", "error",
        "-ss", f"{max(0.0, start):.3f}", "-i", str(source),
        "-t", f"{max(1.0, duration):.3f}",
        "-vn", "-ac", "1", "-ar", "16000", "-c:a", "libmp3lame", "-b:a", "48k",
        str(tmp),
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    if r.returncode == 0 and tmp.is_file() and tmp.stat().st_size > 500:
        tmp.replace(out_mp3)
        return True
    tmp.unlink(missing_ok=True)
    return False


def _call_gemini_audio(mp3_path: Path, prompt: str, keys: list[str], models: list[str]) -> dict | None:
    from google import genai
    from google.genai import types

    audio_bytes = mp3_path.read_bytes()
    for key in keys[:4]:
        client = genai.Client(api_key=key)
        for model_name in models:
            try:
                resp = client.models.generate_content(
                    model=model_name,
                    contents=[
                        types.Part.from_bytes(data=audio_bytes, mime_type="audio/mp3"),
                        prompt,
                    ],
                    config=types.GenerateContentConfig(response_mime_type="application/json"),
                )
                text = str(getattr(resp, "text", "") or "").strip()
                if text.startswith("```"):
                    text = text.strip("`").lstrip("json").strip()
                if text:
                    return json.loads(text)
            except Exception:
                continue
    return None


def _format_hint(gender: str, speaker: str) -> str:
    g = str(gender or "").strip().lower()
    sp = " ".join(str(speaker or "").split())[:32]
    if g == "male":
        return f"Male ({sp})" if sp else "Male"
    if g == "female":
        return f"Female ({sp})" if sp else "Female"
    if g == "narrator":
        return f"Narrator ({sp})" if sp else "Narrator"
    return ""


def attach_speaker_hints(
    source_path: Path,
    units: list[dict[str, Any]],
    job_dir: Path,
    keys: list[str],
    *,
    ffmpeg: str = "ffmpeg",
    primary_model: str = "gemini-2.5-flash",
    reuse: bool = True,
    log=print,
) -> dict[int, dict[str, str]]:
    """Listen to source audio in chunks, cache speaker gender hints, and attach `speaker_hint` to `units`.
    Never raises — if audio listening fails, units continue cleanly without hints."""
    if not units or not keys:
        return {}
    source_path = Path(source_path)
    if not source_path.is_file():
        return {}
    ff = shutil.which(ffmpeg) or ffmpeg
    job_dir = Path(job_dir)
    cache_path = job_dir / "speaker_gender_hints.json"
    sig = {
        "v": CACHE_VERSION,
        "count": len(units),
        "first_id": int(units[0]["id"]),
        "last_id": int(units[-1]["id"]),
    }

    heard: dict[str, dict[str, str]] = {}
    if reuse and cache_path.is_file():
        try:
            saved = json.loads(cache_path.read_text(encoding="utf-8"))
            if saved.get("signature") == sig and isinstance(saved.get("items"), dict):
                heard = saved["items"]
                log(f"♻️ Speaker gender hints reused ({len(heard)} lines)")
        except Exception:
            heard = {}

    if not heard:
        log("🎧 Listening to original audio for speaker gender hints (ရှင် / မင်း / နင် accuracy)...")
        audio_dir = job_dir / "_speaker_audio"
        known: dict[str, str] = {}
        models = list(dict.fromkeys([m for m in ("gemini-2.5-flash", "gemini-2.5-flash-lite", primary_model) if m]))
        groups = _chunks(units)
        for idx, group in enumerate(groups, 1):
            start = max(0.0, float(group[0].get("video_start", 0.0)) - 0.5)
            end = float(group[-1].get("video_end", 0.0)) + 0.5
            mp3 = audio_dir / f"chunk_{idx:02d}.mp3"
            if not _extract_chunk_mp3(ff, source_path, start, end - start, mp3):
                continue
            lines_text = "\n".join(
                f"{int(u['id'])} [{_clock(float(u.get('video_start', 0.0)) - start)}-{_clock(float(u.get('video_end', 0.0)) - start)}] "
                f"{' '.join(str(u.get('source_text') or '').split())}"
                for u in group
            )
            speakers_text = ", ".join(f"{name} ({g})" for name, g in list(known.items())[:20]) or "none yet"
            prompt = LISTEN_PROMPT.format(speakers=speakers_text, lines=lines_text)
            try:
                ans = _call_gemini_audio(mp3, prompt, keys, models)
            except Exception as exc:
                log(f"⚠️ Speaker listen chunk {idx}/{len(groups)} skipped: {exc}")
                ans = None
            rows = (ans.get("lines") if isinstance(ans, dict) else ans) or []
            valid_ids = {int(u["id"]) for u in group}
            for row in rows:
                if not isinstance(row, dict):
                    continue
                try:
                    uid = int(row.get("id"))
                except Exception:
                    continue
                if uid not in valid_ids:
                    continue
                g = str(row.get("gender") or "").strip().lower()
                if g not in {"male", "female", "narrator", "unsure"}:
                    g = "unsure"
                sp = " ".join(str(row.get("speaker") or "").split())[:32]
                heard[str(uid)] = {"gender": g, "speaker": sp}
                if sp and g in {"male", "female"}:
                    known.setdefault(sp, g)
        if heard:
            try:
                tmp = cache_path.with_suffix(".tmp")
                tmp.write_text(
                    json.dumps({"signature": sig, "items": heard}, ensure_ascii=False, indent=1),
                    encoding="utf-8",
                )
                tmp.replace(cache_path)
            except Exception:
                pass
            counts = {g: sum(1 for v in heard.values() if v.get("gender") == g) for g in ("male", "female", "narrator", "unsure")}
            log(
                f"✅ Speaker gender hints ready: male={counts['male']} · female={counts['female']} · "
                f"narrator={counts['narrator']} · unsure={counts['unsure']}"
            )
        else:
            log("ℹ️ Speaker audio listen unavailable — continuing with text-based pronoun rules.")

    attached: dict[int, dict[str, str]] = {}
    for u in units:
        uid = int(u["id"])
        rec = heard.get(str(uid))
        if rec:
            hint = _format_hint(rec.get("gender", ""), rec.get("speaker", ""))
            if hint:
                u["speaker_hint"] = hint
                attached[uid] = rec
    return attached
