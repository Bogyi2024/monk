"""Script Review (2026-10-24, user): instead of going straight from the translation to the voice and the video,
the Recap translates part by part (40 lines a part, as the planner's batches) and this window shows every part as
soon as it is written. When the whole script is there the job stops before the voice: read it, fix lines with Edit
Text, export it (TXT), then "▶ အသံ + Video ဆက်လုပ်မယ်" goes on (the translation is reused, nothing asked again).
"Auto" mode is the old way: everything in one go."""
from __future__ import annotations

import json
import os
import subprocess
import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk
from typing import Any, Callable

BG, FG, MUTED = "#151922", "#e7eaf0", "#9da7b6"
PART_LINES = 40
PREVIEW_W, PREVIEW_H = 448, 252          # the picture box; 9:16 / 1:1 outputs are drawn inside it
THUMB_W = 144
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
RUN_MODES = {"auto": "Auto — အစအဆုံး တစ်ခါတည်း (အရင်အတိုင်း)",
             "review": "Script Review — စာပြင် / ကိုယ်ပိုင်အသံသွင်းမယ်"}


def _clock(text: str) -> str:
    """'[00:01:02.500 --> …]' or seconds → 01:02 / 1:01:02."""
    raw = str(text or "").strip("[] ")
    first = raw.split("-->")[0].strip()
    try:
        if ":" in first:
            h, m, s = (["0"] + first.split(":"))[-3:]
            total = int(h) * 3600 + int(m) * 60 + float(s)
        else:
            total = float(first)
    except ValueError:
        return first[:12]
    h, rest = divmod(int(total), 3600)
    m, s = divmod(rest, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def _seconds(text) -> float | None:
    text = str(text if text is not None else "").strip("[] ")
    try:
        total = 0.0
        for part in text.split(":"):
            total = total * 60.0 + float(part)
        return total
    except ValueError:
        return None


def _secs(value, timestamp, side: int) -> float:
    """A plan's video_start/video_end, else the start (side 0) / end (side 1) of '[a --> b]'."""
    if value not in (None, ""):
        got = _seconds(value)
        if got is not None:
            return round(got, 3)
    pieces = str(timestamp or "").strip("[] ").split("-->")
    got = _seconds(pieces[min(side, len(pieces) - 1)].strip()) if pieces[0].strip() else None
    return round(got or 0.0, 3)


def read_script(job: Path) -> tuple[list[dict], int, bool]:
    """(lines [{id, time, source, text}], total lines expected, finished). Finished = the plan is ready: its
    narration (Edit Text changes included) is shown; before that, the translation as it is being written."""
    plan_file, tr_file = job / "smart_sync_plan.json", job / "timestamp_translations.json"
    try:
        state = json.loads((job / "planner_checkpoint.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        state = {}
    if state.get("plan_ready") and plan_file.is_file():
        try:
            plan = json.loads(plan_file.read_text(encoding="utf-8"))
            segs = plan.get("segments") or []
            lines = [{"id": i + 1, "time": _clock(s.get("start", s.get("timestamp", ""))),
                      "source": str(s.get("source_text") or s.get("source") or ""),
                      "text": str(s.get("narration") or s.get("translation") or ""),
                      "start": _secs(s.get("video_start", s.get("start")), s.get("timestamp"), 0),
                      "end": _secs(s.get("video_end", s.get("end")), s.get("timestamp"), 1)}
                     for i, s in enumerate(segs)]
            try:                                   # Edit Text numbers the plan's usable lines in time order
                from core import normalize_segments
                for seg in normalize_segments(plan):
                    lines[seg["source_index"]]["segment"] = seg["segment_id"]
            except Exception:  # noqa: BLE001
                pass
            return lines, len(lines), True
        except (OSError, ValueError):
            pass
    try:
        saved = json.loads(tr_file.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return [], 0, False
    items = saved.get("items") or []
    lines = [{"id": int(x.get("id") or i + 1), "time": _clock(x.get("timestamp", "")),
              "source": str(x.get("source_text") or ""), "text": str(x.get("translation") or ""),
              "start": _secs(None, x.get("timestamp"), 0), "end": _secs(None, x.get("timestamp"), 1)}
             for i, x in enumerate(items)]
    return lines, int(saved.get("total") or len(lines)), False


def script_rows(lines: list[dict], *, with_source: bool) -> tuple[list[str], list[int | None]]:
    """The script's text rows and, for every row, the index of the line it belongs to (None = part title / gap)."""
    out: list[str] = []
    owner: list[int | None] = []
    for n in range(0, len(lines), PART_LINES):
        part = lines[n:n + PART_LINES]
        out.append(f"══ အပိုင်း {n // PART_LINES + 1}  ({part[0]['time']} – {part[-1]['time']}) ══")
        owner.append(None)
        for k, line in enumerate(part, n):
            out.append(f"[{line['time']}]  {line['text']}")
            owner.append(k)
            if with_source and line["source"]:
                out.append(f"          {line['source']}")
                owner.append(k)
        out.append("")
        owner.append(None)
    return out, owner


def script_text(lines: list[dict], *, with_source: bool) -> str:
    return "\r\n".join(script_rows(lines, with_source=with_source)[0])


def export(job: Path, title: str, folder: str = "") -> list[Path]:
    """<job>/script_<title>.txt (+ <folder>/Scripts/<title>_script.txt when an output folder is set):
    one plain Burmese script for reading / voice-over, and one with the source line under each."""
    lines, _total, _done = read_script(job)
    if not lines:
        raise RuntimeError("Script မရှိသေးပါ။")
    plain = "\r\n".join(line["text"] for line in lines) + "\r\n"
    timed = script_text(lines, with_source=True)
    made = []
    targets = [job]
    if folder and folder.strip():
        targets.append(Path(folder) / "Scripts")
    for place in targets:
        place.mkdir(parents=True, exist_ok=True)
        stem = f"{title}_script" if place != job else f"script_{title}"
        (place / f"{stem}.txt").write_text(plain, encoding="utf-8-sig")
        (place / f"{stem}_timed.txt").write_text(timed, encoding="utf-8-sig")
        made += [place / f"{stem}.txt", place / f"{stem}_timed.txt"]
    return made


def frame_times(line: dict) -> list[tuple[str, float]]:
    """The moments shown for a line: its picture's start, middle and end (a little inside the cuts)."""
    start, end = float(line.get("start") or 0.0), float(line.get("end") or 0.0)
    if end <= start:
        end = start + 1.0
    pad = min(0.15, (end - start) / 4)
    return [("အစ", round(start + pad, 2)), ("အလယ်", round((start + end) / 2, 2)), ("အဆုံး", round(end - pad, 2))]


def preview_size(ratio: str, source_size: tuple[int, int]) -> tuple[int, int]:
    """The output frame's shape fitted into the preview box (even sizes, like the render)."""
    try:
        from core import output_canvas
        fw, fh = output_canvas(ratio, int(source_size[0] or 0), int(source_size[1] or 0))
    except Exception:  # noqa: BLE001
        fw, fh = 1920, 1080
    scale = min(PREVIEW_W / fw, PREVIEW_H / fh)
    return max(16, int(fw * scale)) // 2 * 2, max(16, int(fh * scale)) // 2 * 2


class _TkBox:
    """Fallback when RichEdit is not there (not Windows): a plain Tk Text with the same few calls."""

    def __init__(self, frame: tk.Frame) -> None:
        self.text = tk.Text(frame, bg="#0a0c10", fg=FG, wrap="word", font=("Myanmar Text", 11), insertbackground=FG)
        self.text.pack(fill="both", expand=True)

    def set(self, value: str) -> None:
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        self.text.insert("1.0", value.replace("\r\n", "\n"))
        self.text.configure(state="disabled")

    def caret_row(self, _starts: list[int]) -> int:
        return int(self.text.index("insert").split(".")[0]) - 1

    def select_row(self, row: int, _starts: list[int], _rows: list[str]) -> None:
        self.text.mark_set("insert", f"{row + 1}.0")
        self.text.tag_remove("sel", "1.0", "end")
        self.text.tag_add("sel", f"{row + 1}.0", f"{row + 1}.end")
        self.text.see(f"{row + 1}.0")


class _RichBox:
    """The RichEdit box of the Edit Text window (shapes Burmese right), read-only, caret read for the preview."""

    EM_EXGETSEL, EM_EXSETSEL, EM_SCROLLCARET, EM_SETREADONLY = 0x0434, 0x0437, 0x00B7, 0x00CF

    def __init__(self, frame: tk.Frame) -> None:
        import ctypes
        from narration_editor import NativeTextBox

        frame.update_idletasks()
        self.box = NativeTextBox(frame, font="Myanmar Text", size_pt=11, bg="#0a0c10", fg=FG)
        self.box.user32.SendMessageW(self.box.hwnd, self.EM_SETREADONLY, 1, 0)

        class CHARRANGE(ctypes.Structure):
            _fields_ = [("cpMin", ctypes.c_long), ("cpMax", ctypes.c_long)]

        self._range = CHARRANGE()
        self._ctypes = ctypes

    def set(self, value: str) -> None:
        self.box.set(value)

    def caret_row(self, starts: list[int]) -> int:
        self.box.user32.SendMessageW(self.box.hwnd, self.EM_EXGETSEL, 0, self._ctypes.addressof(self._range))
        pos = int(self._range.cpMin)
        lo, hi = 0, len(starts) - 1
        while lo < hi:                          # the last row starting at or before the caret
            mid = (lo + hi + 1) // 2
            if starts[mid] <= pos:
                lo = mid
            else:
                hi = mid - 1
        return lo

    def select_row(self, row: int, starts: list[int], rows: list[str]) -> None:
        self._range.cpMin = starts[row]
        self._range.cpMax = starts[row] + _u16(rows[row])
        u = self.box.user32
        u.SendMessageW(self.box.hwnd, self.EM_EXSETSEL, 0, self._ctypes.addressof(self._range))
        u.SendMessageW(self.box.hwnd, self.EM_SCROLLCARET, 0, 0)


def _u16(text: str) -> int:
    """RichEdit counts characters in UTF-16 units."""
    return len(text.encode("utf-16-le")) // 2


class ScriptReviewWindow(tk.Toplevel):
    def __init__(self, master: tk.Misc, *, job: Path, title: str, on_continue: Callable[[], None],
                 on_edit: Callable[..., None], output_folder: Callable[[], str], source: str = "",
                 frame_style: Callable[[], dict[str, Any]] | None = None) -> None:
        super().__init__(master, bg=BG)
        self.job, self.title_text = job, title
        self.on_continue, self.on_edit, self.output_folder = on_continue, on_edit, output_folder
        self.source = str(source or "")
        self.frame_style = frame_style
        self.title(f"Script Review — {title}")
        self.geometry("1360x800")
        self.minsize(1100, 640)
        self.transient(master.winfo_toplevel())
        self.status = tk.StringVar(value="")
        self.with_source = tk.BooleanVar(value=False)
        self._shown = None
        self.lines: list[dict] = []
        self.done = False
        self.rows: list[str] = []
        self.owner: list[int | None] = []
        self.starts: list[int] = []
        self.current: int | None = None       # index into self.lines of the line in the preview
        self._caret = -1
        self._gen = 0                         # preview requests: only the newest one's pictures are shown
        self._results: list[tuple[int, str, Any]] = []
        self._lock = threading.Lock()
        self._photos: dict[str, tk.PhotoImage] = {}
        self._size: tuple[int, int] | None = None
        self._pending = None

        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", padx=14, pady=(12, 6))
        tk.Label(top, text="📜 Script Review", bg=BG, fg=FG, font=("Segoe UI Semibold", 13)).pack(side="left")
        tk.Label(top, textvariable=self.status, bg=BG, fg=MUTED, font=("Myanmar Text", 10)).pack(side="left", padx=14)
        ttk.Checkbutton(top, text="မူရင်းစာပါ ပြမယ်", variable=self.with_source, command=self._refresh).pack(side="right")

        bar = tk.Frame(self, bg=BG)
        bar.pack(side="bottom", fill="x", padx=14, pady=10)
        self.edit_btn = ttk.Button(bar, text="✏️ Edit Text (စာကြောင်း ပြင်မယ်)", command=lambda: self.on_edit(),
                                   state="disabled")
        self.edit_btn.pack(side="left")
        self.export_btn = ttk.Button(bar, text="📄 Script ထုတ်မယ် (TXT)", command=self._export, state="disabled")
        self.export_btn.pack(side="left", padx=8)
        self.own_voice_btn = ttk.Button(bar, text="🎙 ကိုယ်ပိုင်အသံ · VIP", command=self._own_voice, state="disabled")
        self.own_voice_btn.pack(side="left", padx=8)
        self.go_btn = ttk.Button(bar, text="▶ အသံ + Video ဆက်လုပ်မယ်", style="Accent.TButton", command=self._continue,
                                 state="disabled")
        self.go_btn.pack(side="right")

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=14)
        self._build_preview(body)
        frame = tk.Frame(body, bg="#0a0c10", highlightthickness=1, highlightbackground="#303744")
        frame.pack(side="left", fill="both", expand=True)
        frame.pack_propagate(False)
        try:
            self.box = _RichBox(frame)
        except Exception:  # noqa: BLE001
            self.box = _TkBox(frame)
        self._poll()
        self._tick()

    # ── the preview panel ──────────────────────────────────────────────────────────────────────
    def _build_preview(self, body: tk.Frame) -> None:
        side = tk.Frame(body, bg=BG, width=PREVIEW_W + 24)
        side.pack(side="right", fill="y", padx=(12, 0))
        side.pack_propagate(False)
        tk.Label(side, text="🎬 ရုပ်ကြည့်ပြီး ပြင်မယ်", bg=BG, fg=FG, font=("Segoe UI Semibold", 11)).pack(anchor="w")
        self.info = tk.Label(side, text="ဘယ်ဘက်က စာကြောင်းတစ်ကြောင်းကို နှိပ်ပါ — အဲ့အပိုင်းရဲ့ ပုံ ပေါ်လာပါမယ်",
                             bg=BG, fg=MUTED, font=("Myanmar Text", 9), justify="left", wraplength=PREVIEW_W)
        self.info.pack(anchor="w", pady=(2, 6))
        self.big = tk.Label(side, bg="#000000", width=PREVIEW_W, height=PREVIEW_H, bd=0)
        self.big.pack(anchor="w")
        self.big_blank = tk.PhotoImage(width=PREVIEW_W, height=PREVIEW_H)
        self.big.configure(image=self.big_blank)
        thumbs = tk.Frame(side, bg=BG)
        thumbs.pack(anchor="w", pady=(6, 0))
        self.thumb_labels = []
        self.thumb_blank = tk.PhotoImage(width=THUMB_W, height=THUMB_W * 9 // 16)
        for k in range(3):
            cell = tk.Frame(thumbs, bg=BG)
            cell.pack(side="left", padx=(0 if k == 0 else 8, 0))
            img = tk.Label(cell, bg="#000000", image=self.thumb_blank, bd=0, cursor="hand2")
            img.pack()
            cap = tk.Label(cell, text="", bg=BG, fg=MUTED, font=("Myanmar Text", 8))
            cap.pack()
            img.bind("<Button-1>", lambda _e, n=k: self._show_big(n))
            self.thumb_labels.append((img, cap))
        self.line_text = tk.Label(side, text="", bg=BG, fg=FG, font=("Myanmar Text", 12), justify="left",
                                  wraplength=PREVIEW_W, anchor="w")
        self.line_text.pack(anchor="w", fill="x", pady=(10, 2))
        self.line_source = tk.Label(side, text="", bg=BG, fg=MUTED, font=("Segoe UI", 9), justify="left",
                                    wraplength=PREVIEW_W, anchor="w")
        self.line_source.pack(anchor="w", fill="x")
        nav = tk.Frame(side, bg=BG)
        nav.pack(anchor="w", fill="x", pady=(10, 0))
        ttk.Button(nav, text="◀ အရင်", width=8, command=lambda: self._step(-1)).pack(side="left")
        ttk.Button(nav, text="နောက် ▶", width=8, command=lambda: self._step(1)).pack(side="left", padx=(6, 0))
        self.clip_btn = ttk.Button(nav, text="🔊 Clip ဖွင့်ကြည့်မယ်", command=self._play_clip, state="disabled")
        self.clip_btn.pack(side="left", padx=(6, 0))
        self.line_edit_btn = ttk.Button(side, text="✏️ ဒီစာကြောင်း ပြင်မယ်", command=self._edit_line, state="disabled")
        self.line_edit_btn.pack(anchor="w", pady=(8, 0))
        self.frames: list[tuple[str, float, str]] = []

    def _style(self) -> dict[str, Any]:
        try:
            style = dict(self.frame_style() if self.frame_style else {})
        except Exception:  # noqa: BLE001
            style = {}
        style.setdefault("ffmpeg", "ffmpeg")
        style.setdefault("ratio", "16:9")
        style.setdefault("fill", "blur")
        style.setdefault("zoom", 1.0)
        style.setdefault("mirror", False)
        return style

    def _select(self, index: int, *, move_caret: bool) -> None:
        if not (0 <= index < len(self.lines)):
            return
        self.current = index
        line = self.lines[index]
        if move_caret and index in self.owner:
            row = self.owner.index(index)
            self.box.select_row(row, self.starts, self.rows)
            self._caret = self.box.caret_row(self.starts)
        self.info.configure(text=f"စာကြောင်း {line['id']} · ရုပ် {_clock(str(line['start']))} – "
                                 f"{_clock(str(line['end']))}  ({max(0.0, line['end'] - line['start']):.1f} s)")
        self.line_text.configure(text=line["text"])
        self.line_source.configure(text=line["source"])
        has_video = bool(self.source) and Path(self.source).is_file()
        self.clip_btn.configure(state="normal" if has_video else "disabled")
        self.line_edit_btn.configure(state="normal" if self.done and line.get("segment") else "disabled")
        if not has_video:
            self.info.configure(text=self.info.cget("text") + "\nSource video မတွေ့လို့ ပုံ မပြနိုင်ပါ။")
            return
        if self._pending:
            self.after_cancel(self._pending)
        self._pending = self.after(250, self._load_frames)       # quick arrow / clicks: only the last line

    def _load_frames(self) -> None:
        self._pending = None
        if self.current is None:
            return
        self._gen += 1
        gen, line, style = self._gen, dict(self.lines[self.current]), self._style()
        self.big.configure(image=self.big_blank)
        for img, cap in self.thumb_labels:
            img.configure(image=self.thumb_blank)
            cap.configure(text="…")
        threading.Thread(target=self._frames_worker, args=(gen, line, style), daemon=True).start()

    def _frames_worker(self, gen: int, line: dict, style: dict[str, Any]) -> None:
        from preview_tools import extract_preview_frame

        try:
            size = tuple(style.get("source_size") or (0, 0))
            if not size[0] and style.get("ffprobe"):
                if self._size is None:
                    from core import probe_video_size
                    self._size = probe_video_size(style["ffprobe"], self.source)
                size = self._size
            w, h = preview_size(style["ratio"], size)
            tw = THUMB_W if w >= h else max(16, THUMB_W * w // h // 2 * 2)
            th = max(16, int(tw * h / w)) // 2 * 2
            folder = self.job / "script_preview"
            mark = f"{style['ratio'].replace(':', 'x')}_{style['fill']}_{float(style['zoom']):.2f}_{int(bool(style['mirror']))}"
            for k, (label, at) in enumerate(frame_times(line)):
                if gen != self._gen:
                    return
                made = []
                for kind, (fw, fh) in (("big", (w, h)), ("thumb", (tw, th))):
                    out = folder / f"{kind}_{int(at * 1000):09d}_{fw}x{fh}_{mark}.png"
                    if not out.is_file():
                        extract_preview_frame(style["ffmpeg"], self.source, at, float(style["zoom"]),
                                              bool(style["mirror"]), str(out), fw, fh, ratio=style["ratio"],
                                              fill=style["fill"], source_size=size)
                    made.append(str(out))
                with self._lock:
                    self._results.append((gen, "frame", (k, label, at, made[0], made[1])))
        except Exception as exc:  # noqa: BLE001
            with self._lock:
                self._results.append((gen, "error", str(exc)[-300:]))

    def _show_big(self, k: int) -> None:
        if k < len(self.frames):
            self.big.configure(image=self._photo(self.frames[k][2]))

    def _photo(self, path: str) -> tk.PhotoImage:
        if path not in self._photos:
            if len(self._photos) > 60:
                self._photos.clear()
            self._photos[path] = tk.PhotoImage(file=path)
        return self._photos[path]

    def _step(self, delta: int) -> None:
        if not self.lines:
            return
        target = 0 if self.current is None else self.current + delta
        self._select(max(0, min(len(self.lines) - 1, target)), move_caret=True)

    def _edit_line(self) -> None:
        if self.current is not None and self.lines[self.current].get("segment"):
            self.on_edit(int(self.lines[self.current]["segment"]))

    def _play_clip(self) -> None:
        if self.current is None:
            return
        line, style = dict(self.lines[self.current]), self._style()
        self.clip_btn.configure(state="disabled")
        self.status.set(f"🔊 စာကြောင်း {line['id']} ရဲ့ clip ထုတ်နေပါတယ်…")
        threading.Thread(target=self._clip_worker, args=(line, style), daemon=True).start()

    def _clip_worker(self, line: dict, style: dict[str, Any]) -> None:
        """The line's own picture with the original sound, small, opened in the PC's video player."""
        start, end = float(line["start"]), float(line["end"])
        out = self.job / "script_preview" / f"clip_{int(start * 1000):09d}_{int(end * 1000):09d}.mp4"
        try:
            if not out.is_file():
                out.parent.mkdir(parents=True, exist_ok=True)
                cmd = [style["ffmpeg"], "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{start:.3f}",
                       "-i", self.source, "-t", f"{max(0.5, end - start):.3f}", "-vf", "scale=-2:480",
                       "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-c:a", "aac", "-b:a", "128k",
                       "-movflags", "+faststart", str(out.with_suffix(".part.mp4"))]
                p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                                   creationflags=NO_WINDOW)
                if p.returncode != 0:
                    raise RuntimeError(p.stderr[-300:] or "ffmpeg failed")
                out.with_suffix(".part.mp4").replace(out)
            os.startfile(out)
            result = ("clip", f"🔊 Clip ဖွင့်ပြီးပါပြီ — စာကြောင်း {line['id']}")
        except Exception as exc:  # noqa: BLE001
            result = ("clip", f"⚠️ Clip မထုတ်နိုင်ပါ: {exc}")
        with self._lock:
            self._results.append((-1, *result))

    def _tick(self) -> None:
        """Every 150 ms: a click in the script moves the preview; finished pictures are put up."""
        if not self.winfo_exists():
            return
        try:
            if self.starts:
                row = self.box.caret_row(self.starts)
                if row != self._caret:
                    self._caret = row
                    index = self.owner[row] if row < len(self.owner) else None
                    if index is not None and index != self.current:
                        self._select(index, move_caret=False)
        except Exception:  # noqa: BLE001
            pass
        with self._lock:
            results, self._results = self._results, []
        for gen, kind, payload in results:
            if kind == "clip":
                self.status.set(payload)
                if self.current is not None:
                    self.clip_btn.configure(state="normal")
            elif gen != self._gen:
                continue
            elif kind == "error":
                self.info.configure(text=f"⚠️ ပုံ မထုတ်နိုင်ပါ: {payload}")
            elif kind == "frame":
                k, label, at, big, thumb = payload
                if k == 0:
                    self.frames = []
                self.frames.append((label, at, big))
                img, cap = self.thumb_labels[k]
                img.configure(image=self._photo(thumb))
                cap.configure(text=f"{label} {_clock(str(at))}")
                if k == 1 or (k == 0 and not self.frames[1:]):
                    self.big.configure(image=self._photo(big))
        self.after(150, self._tick)

    # ── the script ─────────────────────────────────────────────────────────────────────────────
    def _refresh(self) -> None:
        self._shown = None
        self._poll(once=True)

    def _poll(self, once: bool = False) -> None:
        if not self.winfo_exists():
            return
        lines, total, done = read_script(self.job)
        key = (len(lines), done, self.with_source.get(), hash(tuple(line["text"] for line in lines)))
        if key != self._shown:
            self._shown = key
            self.lines, self.done = lines, done
            parts = (len(lines) + PART_LINES - 1) // PART_LINES
            all_parts = (total + PART_LINES - 1) // PART_LINES if total else 0
            if lines:
                self.rows, self.owner = script_rows(lines, with_source=self.with_source.get())
                self.starts, pos = [], 0
                for row in self.rows:
                    self.starts.append(pos)
                    pos += _u16(row) + 1               # RichEdit keeps one character per line break
                self.box.set("\r\n".join(self.rows))
            else:
                self.rows, self.owner, self.starts = [], [], []
                self.box.set("ဘာသာပြန်တာ စနေပါတယ်… (transcript + story memory ပြီးရင် အပိုင်းလိုက် ပေါ်လာပါမယ်)")
            self._caret = -1
            if self.current is not None and self.current < len(lines):
                self._select(self.current, move_caret=True)       # stay on the line being looked at
            if done:
                self.status.set(f"✅ Script ပြီးပါပြီ — စာကြောင်း {len(lines)} ကြောင်း · အပိုင်း {parts}။ "
                                "စာကြောင်းကို နှိပ်ရင် ရုပ်ပေါ်မယ်၊ ပြင်ပြီးရင် ▶ ဆက်လုပ်မယ်")
            elif lines:
                self.status.set(f"ဘာသာပြန်နေ — အပိုင်း {parts}/{all_parts or '?'} · စာကြောင်း {len(lines)}/{total or '?'}")
            for b in (self.edit_btn, self.go_btn, self.own_voice_btn):
                b.configure(state="normal" if done else "disabled")
            self.export_btn.configure(state="normal" if lines else "disabled")
        if not once:
            self.after(2000, self._poll)

    def _export(self) -> None:
        try:
            made = export(self.job, self.title_text, self.output_folder())
        except Exception as exc:  # noqa: BLE001
            self.status.set(f"⚠️ {exc}")
            return
        self.status.set("📄 ထုတ်ပြီးပါပြီ: " + ", ".join(p.name for p in made[:2]))
        try:
            os.startfile(made[-1].parent)
        except OSError:
            pass

    def _continue(self) -> None:
        self.go_btn.configure(state="disabled")
        self.status.set("▶ အသံ + Video ဆက်လုပ်နေပါတယ် (Recap window မှာ ကြည့်ပါ)")
        self.on_continue()

    def _own_voice(self) -> None:
        import sys
        studio_app = Path(__file__).resolve().parents[2] / "app"
        if str(studio_app) not in sys.path:
            sys.path.append(str(studio_app))
        from core import normalize_segments
        from own_voice_editor import OwnVoiceEditor
        from membership_access import require_vip_audio
        try:
            require_vip_audio()
        except RuntimeError as exc:
            from tkinter import messagebox
            messagebox.showinfo("VIP", str(exc), parent=self)
            return
        plan = json.loads((self.job / "smart_sync_plan.json").read_text(encoding="utf-8"))
        rows = [{"id": str(s["segment_id"]), "text": s["narration"]} for s in normalize_segments(plan)]
        OwnVoiceEditor(self, self.job, rows, ffmpeg=self._style()["ffmpeg"])
