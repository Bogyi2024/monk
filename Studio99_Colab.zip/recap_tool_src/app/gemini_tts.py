"""Gemini voice adapter for the Recap Smart Sync pipeline, using Profile keys."""
from __future__ import annotations

import hashlib
import re
import sys
from pathlib import Path

DESKTOP_APP = Path(__file__).resolve().parents[2] / "app"
if str(DESKTOP_APP) not in sys.path:
    sys.path.append(str(DESKTOP_APP))

from story_motion.voice import synth, gemini_prompt
from gemini_narrator import VOICES

GEMINI_VOICES = tuple(f"gemini:{name}" for name, _gender in VOICES)


def read_keys(env_file: str) -> list[str]:
    from dotenv import dotenv_values
    values = dotenv_values(env_file) if env_file and Path(env_file).is_file() else {}
    numbered = sorted((int(m.group(1)), str(value).strip()) for label, value in values.items()
                      if (m := re.fullmatch(r"GEMINI_IMAGE_PROJECT_(\d+)_KEY", label)) and value)
    keys = [value for _number, value in numbered]
    if not keys and values.get("GEMINI_API_KEY"):
        keys = [str(values["GEMINI_API_KEY"]).strip()]
    return list(dict.fromkeys(keys))


class GeminiTTSEngine:
    def __init__(self, *, ffmpeg: str, work_dir: Path, rate: str, env_file: str, direction: str, log):
        self.ffmpeg, self.work_dir = ffmpeg, work_dir
        self.rate = int(rate.strip().rstrip("%"))
        self.keys, self.direction, self.log = read_keys(env_file), direction, log
        if not self.keys:
            raise RuntimeError("Profile မှာ Gemini API key ထည့်ပြီး Recap ပြန်ဖွင့်ပါ။")

    def fingerprint(self, voice: str) -> str:
        profile = gemini_prompt("", voice, "my", self.direction)
        return voice + "|gemini|" + hashlib.sha256(f"{profile}|{self.rate}".encode()).hexdigest()

    def generate_channel99_voice(self, text: str, voice: str) -> Path:
        return synth(text, voice, self.rate, self.work_dir, "recap", self.ffmpeg,
                     keys=self.keys, language="my", direction=self.direction, log=self.log)
