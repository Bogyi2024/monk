from __future__ import annotations

import json
import sys
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from core import EdgeSmartSync

PREFIX = "@@VRS_EVENT@@"


def emit(kind: str, **data) -> None:
    payload = {"kind": kind, **data}
    print(PREFIX + json.dumps(payload, ensure_ascii=False), flush=True)


def main() -> int:
    if len(sys.argv) != 2:
        emit("error", message="render_worker requires one JSON config path")
        return 2
    cfg_path = Path(sys.argv[1]).resolve()
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    stop_file = Path(cfg["stop_file"]).resolve()
    env_file = Path(str(cfg.get("gemini_env_path") or ""))
    if env_file.is_file():                      # only the proxy settings: Edge TTS needs no key
        try:
            import os
            from dotenv import dotenv_values
            for name, value in dotenv_values(env_file).items():
                if name in ("EDGE_TTS_PROXY", "GEMINI_PROXY") and value:
                    os.environ[name] = str(value)
        except Exception:
            pass

    def log(msg: str) -> None:
        emit("log", text=str(msg))

    def progress(current: int, total: int, label: str) -> None:
        text = str(label).lower()
        stage = ("blur" if "auto blur" in text else "overlay" if "overlay" in text
                 else "mux" if "mux" in text else "video" if "video" in text else "tts")
        emit("progress", current=int(current), total=int(total), label=str(label), stage=stage)

    try:
        runner = EdgeSmartSync(
            job_dir=cfg["job_dir"],
            source_path=cfg["source_path"],
            plan_path=cfg["plan_path"],
            voice=cfg["voice"],
            edge_tts_rate=cfg.get("edge_tts_rate", "+0%"),
            edge_tts_pitch=cfg.get("edge_tts_pitch", "+0Hz"),
            ffmpeg_path=cfg.get("ffmpeg_path"),
            ffprobe_path=cfg.get("ffprobe_path"),
            max_video_speed=float(cfg.get("max_video_speed", 1.5)),
            max_video_slow=float(cfg.get("max_video_slow", 1.35)),
            mirror_video=bool(cfg.get("mirror_video", True)),
            zoom_factor=float(cfg.get("zoom_factor", 1.05)),
            smooth_freeze_fallback=bool(cfg.get("smooth_freeze_fallback", False)),
            max_freeze_hold=float(cfg.get("max_freeze_hold", 0.75)),
            render_final_video=bool(cfg.get("render_final_video", True)),
            output_ratio=str(cfg.get("output_ratio", "Original")),
            auto_blur_original_subtitles=bool(cfg.get("auto_blur_original_subtitles", True)),
            frame_fill=str(cfg.get("frame_fill", "blur")),
            video_quality=str(cfg.get("video_quality", "1080")),
            overlays=cfg.get("overlays") or {},
            log=log,
            progress=progress,
            should_stop=stop_file.exists,
        )
        runner.voice_volume_percent = int(cfg.get("voice_volume_percent", 100) or 100)
        runner.short_pauses = bool(cfg.get("short_pauses", False))
        runner.gemini_env_path = str(cfg.get("gemini_env_path") or "")
        runner.gemini_direction = str(cfg.get("gemini_direction") or "")
        runner.voxcpm_ref_audio = str(cfg.get("voxcpm_ref_audio") or "")
        runner.voxcpm_prompt_text = str(cfg.get("voxcpm_prompt_text") or "")
        runner.voxcpm_design = str(cfg.get("voxcpm_design") or "")
        runner.voxcpm_steps = int(cfg.get("voxcpm_steps", 0) or 0)
        runner.narration_voice_mode = str(cfg.get("narration_voice_mode") or "single")
        runner.male_voice = str(cfg.get("male_voice") or "voxcpm2:male_narrator")
        runner.male_ref_audio = str(cfg.get("male_ref_audio") or "")
        runner.male_prompt_text = str(cfg.get("male_prompt_text") or "")
        runner.female_voice = str(cfg.get("female_voice") or "voxcpm2:female_narrator")
        runner.female_ref_audio = str(cfg.get("female_ref_audio") or "")
        runner.female_prompt_text = str(cfg.get("female_prompt_text") or "")
        runner.dual_default_gender = str(cfg.get("dual_default_gender") or "female")
        runner.tts_pronunciation_fix = bool(cfg.get("tts_pronunciation_fix", False))
        result = runner.run()
        emit("result", result=result)
        return 0
    except InterruptedError as exc:
        emit("stopped", message=str(exc))
        return 10
    except Exception as exc:
        emit("log", text=traceback.format_exc())
        emit("error", message=str(exc))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
