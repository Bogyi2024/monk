"""Validated, atomic PCM preparation for Recap; interrupted WAVs are never reused."""
from __future__ import annotations

import json
import os
import subprocess
import time
import uuid
import wave
from pathlib import Path


def wav_duration(path: Path) -> float | None:
    try:
        with wave.open(str(path), "rb") as stream:
            frames, rate = stream.getnframes(), stream.getframerate()
            if (rate != 16000 or stream.getnchannels() != 1 or stream.getsampwidth() != 2
                    or frames <= 0 or path.stat().st_size < frames * 2):
                return None
            return frames / rate
    except (OSError, EOFError, wave.Error):
        return None


def _expected(video_duration: float, audio_duration: float | None) -> float:
    return min(video_duration, audio_duration) if audio_duration and audio_duration > 0 else video_duration


def _stamp(source: Path, video_duration: float, audio_duration: float | None) -> dict:
    stat = source.stat()
    return {"source": str(source.resolve()), "bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns,
            "video_duration": round(video_duration, 3),
            "audio_duration": round(audio_duration, 3) if audio_duration else None}


def cache_valid(source: Path, job_dir: Path, video_duration: float,
                audio_duration: float | None = None, *, allow_legacy: bool = False) -> bool:
    out = job_dir / "_whisper_audio_16k.wav"
    actual = wav_duration(out)
    if actual is None:
        return False
    expected = _expected(video_duration, audio_duration)
    meta = job_dir / "_whisper_audio_16k.json"
    if meta.is_file():
        try:
            saved = json.loads(meta.read_text(encoding="utf-8"))
            if saved.get("source_stamp") != _stamp(source, video_duration, audio_duration):
                return False
            # If the source container has no audio duration, a completed decode's
            # measured PCM duration is authoritative (a genuine short audio track).
            if audio_duration is None:
                expected = float(saved["actual_duration"])
        except (OSError, ValueError, KeyError, TypeError):
            return False
    elif not allow_legacy or out.stat().st_mtime_ns < source.stat().st_mtime_ns:
        return False
    return abs(actual - expected) <= max(.25, expected * .002)


def prepare_audio(ffmpeg: str, source: Path, job_dir: Path, video_duration: float, log,
                  *, audio_duration: float | None = None, reuse: bool = True,
                  allow_legacy: bool = False, progress=lambda _c, _t, _s: None,
                  should_stop=lambda: False) -> Path:
    job_dir.mkdir(parents=True, exist_ok=True)
    out = job_dir / "_whisper_audio_16k.wav"
    meta = job_dir / "_whisper_audio_16k.json"
    expected = _expected(video_duration, audio_duration)
    if reuse and cache_valid(source, job_dir, video_duration, audio_duration, allow_legacy=allow_legacy):
        log(f"♻️ Validated Whisper audio reuse: {wav_duration(out):.3f}s")
        return out
    if should_stop():
        raise InterruptedError("STOP requested before Whisper audio preparation")
    if out.exists():
        log("⚠️ Incomplete/stale Whisper audio cache — rebuilding from the source")
    temp = job_dir / f"_whisper_audio_{uuid.uuid4().hex}.partial.wav"
    meta_temp = job_dir / f"_whisper_audio_{uuid.uuid4().hex}.partial.json"
    cmd = [ffmpeg, "-y", "-nostdin", "-hide_banner", "-loglevel", "error", "-i", str(source),
           "-map", "0:a:0", "-vn", "-t", f"{video_duration:.6f}",
           "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(temp)]
    log(f"✂️ Preparing Whisper audio: source video {video_duration:.3f}s; expected audio {expected:.3f}s")
    progress(0, 100, "Preparing Whisper audio")
    proc = None
    try:
        proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        last_size, last_growth, last_log = 0, time.monotonic(), 0.0
        while True:
            if should_stop():
                raise InterruptedError("STOP requested during Whisper audio preparation")
            try:
                _stdout, stderr = proc.communicate(timeout=1)
                break
            except subprocess.TimeoutExpired:
                size = temp.stat().st_size if temp.exists() else 0
                now = time.monotonic()
                if size > last_size:
                    last_size, last_growth = size, now
                if now - last_growth > 90:
                    raise RuntimeError("Whisper audio preparation made no progress for 90 seconds. "
                                       "Source audio ဖတ်မရပါ။ Log ကိုစစ်ပြီး START / RESUME ပြန်နှိပ်ပါ။")
                pct = min(99, max(0, round((size - 80) / 32000 / max(.01, expected) * 100)))
                progress(pct, 100, "Preparing Whisper audio")
                if now - last_log >= 5:
                    log(f"⏳ Preparing Whisper audio {pct}%")
                    last_log = now
        if proc.returncode:
            raise RuntimeError("Whisper audio preparation failed:\n" + stderr.decode("utf-8", "replace")[-3000:])
        actual = wav_duration(temp)
        if actual is None:
            raise RuntimeError("Whisper audio preparation produced an incomplete WAV; it was not cached.")
        if audio_duration is not None and abs(actual - expected) > max(.25, expected * .002):
            raise RuntimeError(f"Whisper audio is incomplete: {actual:.3f}s / expected {expected:.3f}s. "
                               "အသံဖိုင်အပိုင်းတိုကို အသုံးမပြုပါ။ START / RESUME ပြန်နှိပ်ပါ။")
        if actual > video_duration + .25:
            raise RuntimeError("Prepared Whisper audio exceeds the source video duration")
        meta_temp.write_text(json.dumps({"source_stamp": _stamp(source, video_duration, audio_duration),
                                         "actual_duration": actual}), encoding="utf-8")
        os.replace(temp, out)
        os.replace(meta_temp, meta)
        log(f"✅ Whisper audio ready: {actual:.3f}s (validated)")
        progress(100, 100, "Whisper audio ready")
        return out
    finally:
        if proc is not None and proc.poll() is None:
            proc.kill()
            proc.communicate()
        temp.unlink(missing_ok=True)
        meta_temp.unlink(missing_ok=True)
