"""VoxCPM2 adapter for the Recap Smart Sync pipeline (Colab GPU)."""
from __future__ import annotations

import sys
import uuid
from pathlib import Path

DESKTOP_APP = Path(__file__).resolve().parents[2] / "app"
if str(DESKTOP_APP) not in sys.path:
    sys.path.append(str(DESKTOP_APP))

import voxcpm2_local  # noqa: E402

VOXCPM2_VOICES = voxcpm2_local.VOXCPM2_VOICES


class VoxCPM2TTSEngine:
    def __init__(
        self,
        *,
        ffmpeg: str,
        work_dir: Path,
        ref_audio: str = "",
        prompt_text: str = "",
        design: str = "",
        steps: int = 0,
        log=print,
    ):
        self.ffmpeg = ffmpeg
        self.work_dir = Path(work_dir)
        self.work_dir.mkdir(parents=True, exist_ok=True)
        self.ref_audio = str(ref_audio or "").strip()
        self.prompt_text = str(prompt_text or "").strip()
        self.design = str(design or "").strip()
        self.steps = int(steps or 0)
        self.log = log

    @property
    def workers(self) -> int:
        return int(voxcpm2_local.detect_hardware().get("workers", 1))

    def fingerprint(self, voice: str) -> str:
        return voxcpm2_local.fingerprint(
            voice,
            ref_audio=self.ref_audio,
            prompt_text=self.prompt_text,
            design=self.design,
            steps=self.steps,
        )

    def generate_channel99_voice(self, text: str, voice: str) -> Path:
        out = self.work_dir / f"voxcpm2_{uuid.uuid4().hex[:10]}.wav"
        return voxcpm2_local.synthesize(
            text,
            voice,
            out,
            ref_audio=self.ref_audio,
            prompt_text=self.prompt_text,
            design=self.design,
            steps=self.steps,
            ffmpeg=self.ffmpeg,
            work_dir=self.work_dir,
            log=self.log,
        )
