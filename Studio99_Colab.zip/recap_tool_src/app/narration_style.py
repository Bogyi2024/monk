"""Narration style dialog (test mode, 2026-10-24): Original = the translation as before; Test = a ready-made style,
the user's own instructions and an optional sample paragraph (its wording and rhythm are imitated, never its story).
"👀 နမူနာ" tells 30-60 s of the current video (already transcribed by one START) in the chosen style next to its
current translation, so the instructions can be tuned before the whole video is translated again."""
from __future__ import annotations

import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk
from typing import Callable

from recap_planner import STYLE_PRESETS, preview_style, style_key

BG, FG, MUTED = "#151922", "#e7eaf0", "#9da7b6"
MODES = {"original": "Original — အရင်အတိုင်း ဘာသာပြန်", "test": "Test mode — ရေးဟန် ရွေးမယ်"}
EXAMPLE = ("သူငယ်ချင်းကို ဇာတ်လမ်းပြောသလို ရေးပါ။ စာကြောင်းတိုတို၊ သဘာဝကျတဲ့ မြန်မာစကားသုံးပါ။ တိုက်ခိုက်တဲ့အပိုင်းမှာ "
           "သွက်သွက်ပြောပြီး ဝမ်းနည်းတဲ့အပိုင်းမှာ တည်ငြိမ်ပါ။ “ပါတယ်” နဲ့ စာကြောင်းတိုင်းမဆုံးပါနဲ့။ “ဗျာ၊ ခင်ဗျာ” မထည့်ပါနဲ့။")


def summary(style: dict | None) -> str:
    if not style_key(style):
        return MODES["original"]
    label = STYLE_PRESETS.get(str(style.get("preset") or ""), ("ကိုယ်တိုင်သတ်မှတ်မယ်", ""))[0]
    extra = [x for x, k in (("ညွှန်ကြားချက်", "instructions"), ("နမူနာစာ", "sample")) if str(style.get(k) or "").strip()]
    return f"Test — {label}" + (f" + {' + '.join(extra)}" if extra else "")


def _text_box(parent: tk.Misc, height: int) -> tuple[tk.Frame, object]:
    """A Burmese-safe multi-line box (Windows RichEdit; Tk's Text puts the caret in the wrong place)."""
    frame = tk.Frame(parent, height=height, bg="#0a0c10", highlightthickness=1, highlightbackground="#303744")
    frame.pack_propagate(False)
    try:
        from narration_editor import NativeTextBox
        frame.update_idletasks()
        return frame, NativeTextBox(frame, font="Myanmar Text", size_pt=11, bg="#0a0c10", fg=FG)
    except Exception:  # noqa: BLE001 - not Windows: Tk's own box
        box = tk.Text(frame, bg="#0a0c10", fg=FG, insertbackground=FG, wrap="word", font=("Myanmar Text", 11))
        box.pack(fill="both", expand=True)

        class _Plain:
            def get(self):
                return box.get("1.0", "end").strip()

            def set(self, text):
                box.delete("1.0", "end")
                box.insert("1.0", text)
        return frame, _Plain()


class NarrationStyleDialog(tk.Toplevel):
    def __init__(self, master: tk.Misc, *, style: dict | None, on_save: Callable[[dict], None],
                 job_dir: Callable[[], Path | None], env_file: Callable[[], str], runtime_root: Path,
                 text_model: str = "gemini-3.5-flash") -> None:
        super().__init__(master, bg=BG)
        self.title("Narration style (test)")
        self.geometry("980x780")
        self.transient(master.winfo_toplevel())
        self.on_save, self.job_dir, self.env_file = on_save, job_dir, env_file
        self.runtime_root, self.text_model = runtime_root, text_model
        style = dict(style or {})
        self.mode = tk.StringVar(value=MODES["test" if style.get("mode") == "test" else "original"])
        labels = {k: v[0] for k, v in STYLE_PRESETS.items()}
        self.labels = labels
        self.preset = tk.StringVar(value=labels.get(str(style.get("preset") or "light"), labels["light"]))
        self.status = tk.StringVar(value="")
        pad = {"padx": 16}

        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", pady=(14, 4), **pad)
        ttk.Label(top, text="Mode").pack(side="left")
        ttk.Combobox(top, textvariable=self.mode, values=tuple(MODES.values()), state="readonly", width=34).pack(
            side="left", padx=8)
        ttk.Label(top, text="ရေးဟန်").pack(side="left", padx=(16, 0))
        ttk.Combobox(top, textvariable=self.preset, values=tuple(labels.values()), state="readonly", width=34).pack(
            side="left", padx=8)
        tk.Label(self, text="Original = အရင်အတိုင်း။ Test = အဓိပ္ပာယ်/အချက်အလက် မပြောင်းဘဲ ပြောဟန်ပဲ ပြောင်းမယ် (စာကြောင်းတစ်ကြောင်းချင်း "
                            "အချိန်နဲ့ ကိုက်အောင် အရှည်ကို ဒီလောက်ပဲ ထားမယ်)။ ဟန်ပြောင်းရင် ဘာသာပြန်တာကို ပြန်လုပ်ပြီး transcript ကို ပြန်မလုပ်ပါ။",
                 bg=BG, fg=MUTED, font=("Myanmar Text", 9), wraplength=940, justify="left").pack(anchor="w", **pad)

        tk.Label(self, text="ကိုယ်ပိုင် ညွှန်ကြားချက် (မထည့်လည်းရ)", bg=BG, fg=FG, font=("Myanmar Text", 10, "bold")).pack(
            anchor="w", pady=(10, 2), **pad)
        frame, self.instructions = _text_box(self, 90)
        frame.pack(fill="x", **pad)
        self.instructions.set(str(style.get("instructions") or ""))
        tk.Label(self, text="ဥပမာ — " + EXAMPLE, bg=BG, fg=MUTED, font=("Myanmar Text", 9), wraplength=940,
                 justify="left").pack(anchor="w", **pad)

        tk.Label(self, text="နမူနာ စာပိုဒ် (မထည့်လည်းရ) — စကားအသုံး၊ စာကြောင်းအရှည်၊ ဆက်ပြောပုံကို ယူမယ်။ ဇာတ်လမ်းအချက်အလက်ကို မယူပါ။",
                 bg=BG, fg=FG, font=("Myanmar Text", 10, "bold")).pack(anchor="w", pady=(10, 2), **pad)
        frame, self.sample = _text_box(self, 90)
        frame.pack(fill="x", **pad)
        self.sample.set(str(style.get("sample") or ""))

        buttons = tk.Frame(self, bg=BG)
        buttons.pack(fill="x", pady=10, **pad)
        ttk.Button(buttons, text="👀 နမူနာ ကြည့်မယ် (၃၀–၆၀ စက္ကန့်)", command=self._preview).pack(side="left")
        ttk.Button(buttons, text="✅ သိမ်းမယ်", style="Accent.TButton", command=self._save).pack(side="left", padx=8)
        ttk.Button(buttons, text="ပိတ်မယ်", command=self.destroy).pack(side="left")
        tk.Label(buttons, textvariable=self.status, bg=BG, fg=MUTED, font=("Myanmar Text", 9)).pack(side="left", padx=12)

        tk.Label(self, text="နမူနာ — အရင် ဘာသာပြန် / ✍️ ဟန်သစ်", bg=BG, fg=FG, font=("Myanmar Text", 10, "bold")).pack(
            anchor="w", **pad)
        frame, self.result = _text_box(self, 260)
        frame.pack(fill="both", expand=True, pady=(2, 14), **pad)

    def style(self) -> dict:
        mode = next((k for k, v in MODES.items() if v == self.mode.get()), "original")
        preset = next((k for k, v in self.labels.items() if v == self.preset.get()), "light")
        return {"mode": mode, "preset": preset, "instructions": self.instructions.get().strip(),
                "sample": self.sample.get().strip()}

    def _save(self) -> None:
        self.on_save(self.style())
        self.status.set("သိမ်းပြီးပါပြီ — နောက် START မှာ " + summary(self.style()))

    def _preview(self) -> None:
        style = dict(self.style(), mode="test")         # the preview is always the chosen style
        job = self.job_dir()
        if job is None:
            self.status.set("Source Video အရင်ရွေးပါ")
            return
        self.status.set("Gemini နဲ့ ရေးနေပါတယ်…")
        lines: list[str] = []

        def work():
            try:
                rows = preview_style(runtime_root=self.runtime_root, gemini_env_path=self.env_file(), job_dir=job,
                                     style=style, log=lambda m: None, text_model=self.text_model)
                for r in rows:
                    lines.append(f"[{r['timestamp']}]  {r['source']}")
                    if r["original"]:
                        lines.append(f"   အရင်:      {r['original']}")
                    lines.append(f"   ✍️ ဟန်သစ်: {r['styled']}")
                    lines.append("")
                text, status = "\r\n".join(lines), f"စာကြောင်း {len(rows)} ကြောင်း — ကြိုက်ရင် ✅ သိမ်းမယ်၊ မကြိုက်ရင် ညွှန်ကြားချက် ပြင်ပြီး ထပ်ကြည့်ပါ"
            except Exception as exc:  # noqa: BLE001
                text, status = "", f"⚠️ {str(exc)[:200]}"
            self._done = (text, status)                  # picked up on the Tk thread by _poll

        self._done = None
        threading.Thread(target=work, daemon=True).start()
        self._poll()

    def _poll(self) -> None:
        if not self.winfo_exists():
            return
        if self._done is None:
            self.after(300, self._poll)
            return
        text, status = self._done
        if text:
            self.result.set(text)
        self.status.set(status)
