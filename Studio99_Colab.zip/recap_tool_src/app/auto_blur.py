"""Recap Personal's five-sample subtitle-band flow; never scan the entire movie.

OCR is optional and never downloads models. The bundled OpenCV fallback uses
the same middle/lower text bands and recurrence scoring when OCR is unavailable.
Coordinates refer to the framed video, before new subtitles are added.
"""
from __future__ import annotations

import io
import subprocess
from pathlib import Path
from typing import Callable

_reader = None
_reader_checked = False


def sample_times(duration: float) -> list[float]:
    end = max(0.0, duration - 0.05)
    return sorted({min(end, max(0.0, duration * fraction))
                   for fraction in (0.12, 0.30, 0.48, 0.66, 0.84)})


def _ocr_reader():
    global _reader, _reader_checked
    if not _reader_checked:
        _reader_checked = True
        try:
            import easyocr
            _reader = easyocr.Reader(["en"], gpu=False, verbose=False, download_enabled=False)
        except Exception:
            _reader = None
    return _reader


def _sample_frame(ffmpeg: str, video: Path, time: float, width: int, height: int):
    from PIL import Image
    result = subprocess.run(
        [ffmpeg, "-v", "error", "-ss", f"{time:.6f}", "-i", str(video),
         "-frames:v", "1", "-vf", f"scale={width}:{height}",
         "-f", "image2pipe", "-vcodec", "png", "pipe:1"],
        capture_output=True, timeout=20,
    )
    if result.returncode or not result.stdout:
        return None
    with Image.open(io.BytesIO(result.stdout)) as image:
        return image.convert("RGB")


def _choose_band(items: list, width: int, height: int):
    # Recap Personal: recurrence dominates; keep unrelated heights separate.
    clusters: list[list] = []
    for item in sorted(items, key=lambda b: b[2] + b[4] / 2):
        cy = item[2] + item[4] / 2
        for cluster in clusters:
            center = sum(b[2] + b[4] / 2 for b in cluster) / len(cluster)
            if abs(cy - center) <= max(18.0, height * 0.055):
                cluster.append(item)
                break
        else:
            clusters.append([item])
    scored = []
    for cluster in clusters:
        recurrence = len({b[0] for b in cluster})
        left, top = min(b[1] for b in cluster), min(b[2] for b in cluster)
        right = max(b[1] + b[3] for b in cluster)
        bottom = max(b[2] + b[4] for b in cluster)
        score = (recurrence * 4 + min(1, (right - left) / (width * .55)) * 2
                 + sum(b[5] for b in cluster) / len(cluster)
                 + (.2 if (top + bottom) / 2 >= height * .52 else 0)
                 - (4 if bottom - top > height * .20 else 0))
        scored.append((score, recurrence, right - left, cluster))
    return max(scored, key=lambda row: row[:3])[3] if scored else None


def detect_subtitle_box(video: Path, ffmpeg: str, duration: float,
                        frame_size: tuple[int, int], *,
                        log: Callable[[str], None] = lambda _s: None,
                        should_stop: Callable[[], bool] = lambda: False) -> dict:
    """Return one normalized blur box after reading at most five individual frames."""
    times = sample_times(duration)
    fw, fh = frame_size
    scale = min(1.0, 960 / max(fw, fh))
    width, height = max(2, round(fw * scale)), max(2, round(fh * scale))
    fallback = {"x": .04, "y": .775, "w": .92, "h": .11, "method": "lower-band fallback"}
    if should_stop():
        raise InterruptedError("STOP requested — auto blur stopped")
    log(f"🔍 Auto blur — {len(times)} sample frames only (Recap Personal flow)")
    try:
        import cv2
        import numpy as np
    except ImportError:
        log("ℹ️ Auto blur: text detector unavailable; using the lower subtitle band")
        return fallback
    reader = _ocr_reader()
    ocr_boxes, visual_boxes = [], []
    for frame_index, time in enumerate(times):
        if should_stop():
            raise InterruptedError("STOP requested — auto blur stopped")
        try:
            image = _sample_frame(ffmpeg, video, time, width, height)
            if image is None:
                continue
            frame = np.asarray(image)
            results = []
            if reader is not None:
                try:
                    results = reader.readtext(frame)
                except Exception:
                    reader = None
            for bbox, text, confidence in results:
                x, y = bbox[0]
                w, h = bbox[2][0] - x, bbox[2][1] - y
                if (confidence >= .18 and height * .25 <= y + h / 2 <= height * .96
                        and w >= width * .035 and max(5, height * .006) <= h <= height * .10
                        and (len(str(text).strip()) > 1 or confidence >= .55)):
                    ocr_boxes.append((frame_index, x, y, w, h, float(confidence)))
            y0, y1 = int(height * .24), int(height * .97)
            gray = cv2.cvtColor(frame[y0:y1], cv2.COLOR_RGB2GRAY)
            gray = cv2.GaussianBlur(gray, (3, 3), 0)
            grad = cv2.morphologyEx(gray, cv2.MORPH_GRADIENT,
                                    cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))
            _, binary = cv2.threshold(grad, 28, 255, cv2.THRESH_BINARY)
            joined = cv2.morphologyEx(binary, cv2.MORPH_CLOSE,
                                      cv2.getStructuringElement(cv2.MORPH_RECT, (max(15, width // 35), 3)),
                                      iterations=2)
            contours, _ = cv2.findContours(joined, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for contour in contours:
                x, y, w, h = cv2.boundingRect(contour)
                y += y0
                if (w >= width * .16 and max(5, height * .008) <= h <= height * .11
                        and height * .25 <= y + h / 2 <= height * .96):
                    visual_boxes.append((frame_index, x, y, w, h, min(1, w / (width * .55))))
        except Exception as exc:
            log(f"⚠️ Auto blur sample {frame_index + 1} unavailable: {exc}")
    if should_stop():
        raise InterruptedError("STOP requested — auto blur stopped")
    chosen = _choose_band(ocr_boxes, width, height) or _choose_band(visual_boxes, width, height)
    if not chosen:
        log("ℹ️ Auto blur: no text band found; using the lower subtitle band")
        return fallback
    x0, y0 = min(b[1] for b in chosen), min(b[2] for b in chosen)
    x1, y1 = max(b[1] + b[3] for b in chosen), max(b[2] + b[4] for b in chosen)
    x = max(0, x0 - width * .045)
    w = min(width - x, x1 - x0 + width * .09)
    # Personal V5.9: retain the detected vertical center, cap height at 14.5%.
    h = min(height * .145, max(height * .045, y1 - y0 + height * .044))
    y = max(0, min(height - h, (y0 + y1 - h) / 2))
    method = "OCR" if ocr_boxes else "OpenCV"
    box = {"x": float(x / width), "y": float(y / height),
           "w": float(w / width), "h": float(h / height), "method": method}
    log(f"🎯 Auto blur: {method} subtitle band at y={box['y']:.3f}, h={box['h']:.3f}")
    return box
