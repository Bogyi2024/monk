"""Work-based pipeline percentage; elapsed time never invents completed work."""

def overall_progress(stage: str, current: int, total: int) -> int:
    ranges = {"planner": (0, 6000), "tts": (6000, 7800), "video": (7800, 9400),
              "blur": (9400, 9500), "overlay": (9500, 9900), "mux": (9900, 9999),
              "render": (6000, 9900)}
    start, end = ranges.get(stage, (0, 9999))
    fraction = max(0.0, min(1.0, current / total)) if total > 0 else 0.0
    return min(9999, round(start + (end - start) * fraction))
