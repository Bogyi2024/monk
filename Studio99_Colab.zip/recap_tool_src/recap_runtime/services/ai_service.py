"""Gemini / OpenAI-compatible / Anthropic-compatible AI service for Studio99 Recap."""
import os
import sys
from pathlib import Path
from google import genai
from google.genai import types  # noqa: F401

_APP_DIR = Path(__file__).resolve().parents[3] / "app"
if str(_APP_DIR) not in sys.path:
    sys.path.append(str(_APP_DIR))


def gemini_proxy() -> str:
    return ""


class AIService:
    def __init__(self):
        import custom_llm_client
        cfg = custom_llm_client.load_config()
        self.api_key = cfg["api_key"] or os.getenv("GEMINI_API_KEY") or ""
        if not self.api_key and not cfg["base_url"]:
            raise ValueError("API key မတွေ့ပါ။ Profile → Keys မှာ ထည့်ပါ။")
        self.client = custom_llm_client.make_client(api_key=self.api_key)
        models = cfg["models"]
        self.text_model = models[0] if models else os.getenv("GEMINI_TEXT_MODEL", "gemini-3.5-flash")

    def _enable_proxy(self):
        pass

    def _disable_proxy(self):
        pass
